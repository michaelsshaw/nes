-- Premake script for the wx.NET "Wizard" sample.
-- See http://premake.sourceforge.net/ for more info about Premake.

package.name     = "Wizard"
package.language = "c#"
package.kind     = "winexe"
package.target   = "wizard"
project.bindir   = "../Bin"

package.links    = { "System.Drawing", "wx.NET" }

package.files    = { "Wizard.cs" }
