//-----------------------------------------------------------------------------
// wx.NET/Samples - HtmlHelp.cs
//
// wx.NET "HtmlHelpController" sample.
//
// Written by Alexander Olk (xenomorph2@onlinehome.de)
// (C) 2004 by Alexander Olk
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: HtmlHelp.cs,v 1.9 2008/04/19 21:08:40 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Drawing;

/** Sample that demonstrates how to integrate a help browser into an application.
 * This demonstrates the use of \c wx.HtmlHelpController. please note, that with 0.8
 * \e wx.NET also has a wrapper for help data. This class is relevant to those people
 * that implement want to implement an integrated view of help files (not using its
 * own frame).
 */
namespace wx.SampleHtmlHelp
{

	public class MyFrame : Frame
	{
		public enum Cmd 
		{ 
			HtmlHelp_Quit,
			HtmlHelp_About,
			HtmlHelp_Help
		}
		
		private Html.Help.HtmlHelpController help;
		
		public MyFrame( Window parent, string title, Point pos, Size size ) 
			: base( parent, -1, title, pos, size )
		{
			Menu menuFile = new Menu();
			
			menuFile.AppendWL( (int)Cmd.HtmlHelp_Help, "&Help", "Test Help...", new EventListener( OnHelp ) );
			menuFile.AppendWL( (int)Cmd.HtmlHelp_About, "&About", "About the sample...", new EventListener( OnAbout ) );
			menuFile.AppendWL( (int)Cmd.HtmlHelp_Quit, "E&xit\tAlt-X", "Quit this program", new EventListener( OnQuit ) );
			
			MenuBar menuBar = new MenuBar();
			menuBar.Append( menuFile, "&File" );
			
			MenuBar = menuBar;

            help = new Html.Help.HtmlHelpController(Html.Help.HtmlHelpController.Style.DEFAULT_STYLE | Html.Help.HtmlHelpController.Style.OPEN_FILES);
			
			help.UseConfig( Config.Get() );
			
			help.TempDir = "." ;
			
			bool ret = help.AddBook( "../Samples/HtmlHelp/helpfiles/testing.hhp" );
			if ( !ret )
				MessageDialog.MessageBox( "Failed adding book ../Samples/HtmlHelp/helpfiles/testing.hhp" );
				
			ret = help.AddBook( "../Samples/HtmlHelp/helpfiles/another.hhp" );
			if ( !ret )
				MessageDialog.MessageBox( "Failed adding book ../Samples/HtmlHelp/helpfiles/another.hhp" );
				
			this.Closing += new EventListener(OnClosing);
		}
		
		//---------------------------------------------------------------------
		
		public void OnQuit( object sender, Event e )
		{
			Close();
		}
		
		//---------------------------------------------------------------------
		
		public void OnHelp( object sender, Event e )
		{
			help.Display( "Test HELPFILE" );
		}
		
		//---------------------------------------------------------------------
		
		public void OnClosing( object sender, Event e )
		{
			if ( help.Frame != null )
				help.Frame.Close();
			e.Skip();
		}
		
		//---------------------------------------------------------------------
		
		public void OnAbout( object sender, Event e )
		{
			MessageDialog.ShowModal( this, "HtmlHelpController class sample.\n" +
				"\n" +
				"Ported to wx.NET by Alexander Olk", "About HtmlHelpController", wx.WindowStyles.DIALOG_OK | wx.WindowStyles.ICON_INFORMATION );
		}
	}
	
	//---------------------------------------------------------------------

	public class HtmlHelp : wx.App
	{
		public override bool OnInit()
		{
            // This simply adds the zip file handler in case you want to load hyper text books.
            wx.FileSys.FileSystem.AddHandler(new wx.FileSys.ZipFSHandler());
			MyFrame frame = new MyFrame( null, "HtmlHelpController sample", Window.wxDefaultPosition, Window.wxDefaultSize );
			frame.Show( true );

			return true;
		}

		//---------------------------------------------------------------------

		[STAThread]
		static void Main()
		{
			HtmlHelp app = new HtmlHelp();
			app.Run();
		}
	}		
}

