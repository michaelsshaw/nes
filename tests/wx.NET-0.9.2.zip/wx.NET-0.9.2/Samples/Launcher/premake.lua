-- Premake script for the wx.NET samples "Launcher".
-- See http://premake.sourceforge.net/ for more info about Premake.

package.name     = "Launcher"
package.language = "c#"
package.kind     = "winexe"
package.target   = "launcher"
project.bindir   = "../Bin"

package.links    = { "System", "System.Drawing", "wx.NET" }

package.files    = { "Launcher.cs" }
