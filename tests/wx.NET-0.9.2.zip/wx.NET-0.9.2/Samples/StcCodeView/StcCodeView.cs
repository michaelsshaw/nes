/** Sample application for the STC structured text control.
 * 
 * \file
 *
 * (c) 2008 Dr. Harald Meyer auf'm Hofe, harald_meyer@sourceforge.net
 * Licensed under the wxWidgets license, see LICENSE.txt for details.
 * 
 */


#if WXNET_STYLEDTEXTCTRL

using System;
using System.Collections.Generic;
using System.Drawing;

using wx.StyledText;

/** Namespace of the sample demonstrating wx.StyledText. 
 * The main class is StcCodeFrame implementing the main styled text editor frame.
 * 
 * \image html stcsample.PNG "The STC Sample Program"
 */
namespace wx.SampleStyledText
{
    public class StcCodeFrame : wx.Frame
    {
        #region Enumerations
        /** Use this to configure the view.
         */
        [Flags]
        public enum Styles
        {
            /** Use this to specify: No style.
             */
            NoStyle = 0,
            /** Style flags will be loaded from the configuration.
             * All other flags will only be relevant as default if nothing is found in 
             * the configuration.
             */
            LoadFromConfig = 0x004,
            /** This turns on display of the list of available files.
             */
            WithList = 0x001,
            /** This turns on display of projects, groups of files, in a tree ctrl.
             */
            WithProjects = 0x008,
            /** Turns toolbar on.
             */
            WithToolbar = 0x002,
        };

        [wx.Globalization.EnumValueTranslations(301, "Toggle List View", "de", "Liste ein-/ausblenden")]
        [wx.Globalization.EnumValueTranslations(302, "Toggle Project View", "de", "Projektbaum ein-/ausblenden")]
        [wx.Globalization.EnumValueTranslations(303, "Toggle Project Mode", "de", "Projektdateien ein-/ausblenden")]
        [wx.Globalization.EnumValueTranslations(400, "Contract Folds", "de", "Gliederungen einklappen")]
        [wx.Globalization.EnumValueTranslations(401, "Expand Folds", "de", "Gliederungen aufklappen")]
        enum Cmd
        {
            New,
            Save,
            Copy,
            Cut,
            Paste,
            Help,
            Quit,

            Undo,
            Redo,

            ToggleVisibilityList=301,
            ToggleVisibilityProject=302,
            ToggleModeProject=303,

            ContractFoldAll=400,
            ExpandFoldAll=401,

            SortAscWrtColumn,
            SortDescWrtColumn,
        }

        #endregion

        #region State
        wx.ToolBar _toolbar = null;
        wx.SplitterWindow _splitter = null;
        wx.SplitterWindow _listSplitter = null;
        wx.ListCtrl _listCtrl = null;
        wx.TreeCtrl _treeCtrl = null;
        bool _projectTreeSelectAllSiblings = false;

        wx.StyledText.StcStyleConfiguration _styles = new wx.StyledText.StcStyleConfiguration();

        object _popupContext = null;

        wx.StyledText.StyledTextCtrl _srcText = null;
        ClientDataReferringToFile _currentFile = null;

        wx.Config _config;
        List<ClientDataReferringToFile> _allFilenames = new List<ClientDataReferringToFile>();
        #endregion

        #region CTor
        public StcCodeFrame(Window parent, int id, string title, Point pos, Size size)
            : this(null, parent, id, title, pos, size, Styles.WithList|Styles.WithProjects|Styles.WithToolbar)
        {
        }
        public StcCodeFrame(Config config, Window parent, int id, string title, Point pos, Size size, Styles style)
            : base(parent, id, title, pos, size)
        {
            this.Icon = new wx.Icon("StcCodeView.zrs", "doc32.png");
            if (config == null)
                this._config = wx.Config.Get();
            else
                this._config = config;

            if ((style & Styles.LoadFromConfig) != Styles.NoStyle)
            {
                int newStyle = 0;
                if (this._config.ReadInt("Style", ref newStyle))
                    style = (Styles)newStyle;
            }

            this.MenuBar = new MenuBar();
            Menu fileMenu = new Menu();
            fileMenu.Append((int)Cmd.New, _(Cmd.New), _("Creates a new document."));
            fileMenu.Append((int)Cmd.Save, _(Cmd.Save), _("Saves changes."));
            fileMenu.AppendSeparator();
            fileMenu.Append((int)Cmd.Quit, _(Cmd.Quit), _("Quits the application."));
            this.MenuBar.Append(fileMenu, _("File"));
            Menu editMenu = new Menu();
            editMenu.Append((int)Cmd.Undo, _(Cmd.Undo), _("Undoes the last change."));
            editMenu.Append((int)Cmd.Redo, _(Cmd.Redo), _("Undoes the last change."));
            this.MenuBar.Append(editMenu, _("Edit"));
            Menu viewMenu = new Menu();
            viewMenu.Append(Cmd.ExpandFoldAll, _("Expands folds: Full content gets visible."));
            viewMenu.Append(Cmd.ContractFoldAll, _("Contract folds: Most content gets hidden."));
            this.MenuBar.Append(viewMenu, _("View"));

            if ((style & (Styles.WithList | Styles.WithProjects)) != Styles.NoStyle)
            {
                Menu projectMenu = new Menu();
                projectMenu.Append((int)Cmd.ToggleVisibilityList, _(Cmd.ToggleVisibilityList), _("Toggles visibility of the list of files in the project."));
                projectMenu.Append((int)Cmd.ToggleVisibilityProject, _(Cmd.ToggleVisibilityProject), _("Toggles visibility of the project tree."));
                projectMenu.Append((int)Cmd.ToggleModeProject, _(Cmd.ToggleModeProject), _("Toggles mode of the project tree - are all files in sub-folders in the list or not."));
                this.MenuBar.Append(projectMenu, _("Project"));
            }

            if ((style&Styles.WithToolbar)==Styles.WithToolbar)
            {
                this._toolbar = this.CreateToolBar(wx.WindowStyles.TB_DOCKABLE | wx.WindowStyles.ORIENT_HORIZONTAL);
                this._toolbar.SetMargins(2,2);
                this._toolbar.AddTool((int)Cmd.New,
                    new Bitmap("StcCodeView.zrs", "new.png"),
                    _("Create a new file."));
                this._toolbar.AddTool((int)Cmd.Save,
                    new Bitmap("StcCodeView.zrs", "save.png"),
                    _("Saves content of the currently selected file."));
                this._toolbar.EnableTool((int)Cmd.Save, false);

                this._toolbar.AddSeparator();
                this._toolbar.AddTool((int)Cmd.Undo, new Bitmap("StcCodeView.zrs", "undo.png"),
                    _("Undoes the last change to the text."));
                this._toolbar.EnableTool((int)Cmd.Undo, false);
                this._toolbar.AddTool((int)Cmd.Redo, new Bitmap("StcCodeView.zrs", "redo.png"),
                    _("Redoes the lates undone change."));
                this._toolbar.EnableTool((int)Cmd.Redo, false);

                if ((style & (Styles.WithList | Styles.WithProjects)) != Styles.NoStyle)
                {
                    this._toolbar.AddSeparator();
                    if ((style & Styles.WithList) == Styles.WithList)
                    {
                        this._toolbar.AddCheckTool((int)Cmd.ToggleVisibilityList,
                            _("Visibility File List"),
                            new Bitmap("StcCodeView.zrs", "list.png"),
                            Bitmap.NullBitmap,
                            _("Toggles visibility of the file list."),
                            _("Use these action toggle between shown or hidden file lists."));
                        this._toolbar.ToggleTool((int)Cmd.ToggleVisibilityList, true);
                    }
                    if ((style & Styles.WithProjects) == Styles.WithProjects)
                    {
                        this._toolbar.AddCheckTool((int)Cmd.ToggleVisibilityProject,
                            _("Visibility Project Tree"),
                            new Bitmap("StcCodeView.zrs", "tree.png"),
                            Bitmap.NullBitmap,
                            _("Toggles visibility of the project tree."),
                            _("Use these action toggle between shown or hidden project trees."));
                        this._toolbar.ToggleTool((int)Cmd.ToggleVisibilityProject, true);
                        this._toolbar.AddCheckTool((int)Cmd.ToggleModeProject,
                            _("Mode Project Tree"),
                            new Bitmap("StcCodeView.zrs", "tree-mode2.png"),
                            Bitmap.NullBitmap,
                            _("Turns on or off recursive mode of the project tree."),
                            _("Use these action to turn on or off the recursive effect of the project tree on the file list."));
                    }
                }

                this._toolbar.SetMargins(2, 2);
                this._toolbar.Realize();
            }
			CreateStatusBar();

            EVT_MENU((int)Cmd.ToggleVisibilityList, new EventListener(OnToggleVisibilityList));
            EVT_MENU((int)Cmd.ToggleVisibilityProject, new EventListener(OnToggleVisibilityProject));
            EVT_MENU((int)Cmd.ToggleModeProject, new EventListener(OnToggleProjectTreeMode));
            EVT_MENU(Cmd.SortAscWrtColumn, new EventListener(OnSortListAscending));
            EVT_MENU(Cmd.SortDescWrtColumn, new EventListener(OnSortListDescending));
            EVT_MENU(Cmd.ExpandFoldAll, new EventListener(OnExpandFoldAll));
            EVT_MENU(Cmd.ContractFoldAll, new EventListener(OnContractFoldAll));
            EVT_MENU(Cmd.Save, new EventListener(OnSaveCurrentDocument));
            EVT_MENU(Cmd.Undo, new EventListener(OnUndo));
            EVT_MENU(Cmd.Redo, new EventListener(OnRedo));
            EVT_MENU(Cmd.Quit, new EventListener(OnQuit));

            if ((style & Styles.WithList) == Styles.WithList)
            {
                this._splitter = new SplitterWindow(this, -1, wxDefaultPosition, wxDefaultSize, wx.WindowStyles.SP_3D | wx.WindowStyles.SP_LIVE_UPDATE | wx.WindowStyles.CLIP_CHILDREN);
                this._srcText = new wx.StyledText.StyledTextCtrl(this._splitter);
                this._srcText.CallTipUseStyle(50);
                this._srcText.EVT_KEY_DOWN(new EventListener(this.OnUpdateStatus));
                this._srcText.EVT_LEFT_DOWN(new EventListener(this.OnUpdateStatus));
                if ((style & Styles.WithProjects) != Styles.NoStyle)
                {
                    this._listSplitter = new SplitterWindow(this._splitter, -1, wxDefaultPosition, wxDefaultSize, wx.WindowStyles.SP_3D | wx.WindowStyles.SP_LIVE_UPDATE | wx.WindowStyles.CLIP_CHILDREN);
                    this._listCtrl = new ListCtrl(this._listSplitter, wxDefaultPosition, wxDefaultSize, WindowStyles.LC_SINGLE_SEL | WindowStyles.LC_REPORT | WindowStyles.LC_HRULES);
                    this._listCtrl.MinHeight = 100;
                    this._treeCtrl = new TreeCtrl(this._listSplitter, wxDefaultPosition, wxDefaultSize, wx.WindowStyles.TR_HAS_BUTTONS);
                    this._treeCtrl.MinHeight = 100;
                    this._splitter.SplitVertically(this._listSplitter, this._srcText, 300);
                    this._listSplitter.SplitHorizontally(this._treeCtrl, this._listCtrl, 100);

                    this._treeCtrl.AddRoot(_("all"), 6, 7);
                    this._treeCtrl.SelectItem(this._treeCtrl.RootItem);

                    EVT_TREE_SEL_CHANGING(-1, new EventListener(OnTreeSelChanging));
                    EVT_TREE_SEL_CHANGED(-1, new EventListener(OnTreeSelChanged));
                    EVT_TREE_ITEM_EXPANDED(-1, new EventListener(OnTreeExpanded));
                }
                else
                {
                    this._listCtrl = new ListCtrl(this._splitter, wxDefaultPosition, wxDefaultSize, WindowStyles.LC_SINGLE_SEL | WindowStyles.LC_REPORT | WindowStyles.LC_HRULES);
                    this._splitter.SplitVertically(this._listCtrl, this._srcText, 300);
                }

                wx.ImageList imageList = new ImageList(16, 16);
                imageList.Add(new wx.Bitmap("StcCodeView.zrs", "doc.png"));
                imageList.Add(new wx.Bitmap("StcCodeView.zrs", "doc_sel.png"));
                imageList.Add(new wx.Bitmap("StcCodeView.zrs", "csharp.png"));
                imageList.Add(new wx.Bitmap("StcCodeView.zrs", "csharp_sel.png"));
                imageList.Add(new wx.Bitmap("StcCodeView.zrs", "cpp.png"));
                imageList.Add(new wx.Bitmap("StcCodeView.zrs", "cpp_sel.png"));
                imageList.Add(new wx.Bitmap("StcCodeView.zrs", "dir.png"));
                imageList.Add(new wx.Bitmap("StcCodeView.zrs", "dir_sel.png"));
                this._listCtrl.SetImageList(imageList, wxImageList.Normal);
                this._listCtrl.SetImageList(imageList, wxImageList.Small);
                if (this._treeCtrl != null)
                {
                    this._treeCtrl.SetImageList(imageList);
                }

                EVT_LIST_ITEM_SELECTED(-1, new EventListener(this.OnListSelChanging));
                EVT_LIST_COL_CLICK(-1, new EventListener(this.OnSelectColumn));
                this.InitListItems();
            }
            else
                this._srcText = new wx.StyledText.StyledTextCtrl(this);

            this._srcText.Change += new EventListener(this.OnEditText);
        }
        #endregion

        #region Event Handler
        public void OnQuit(object sender, Event e)
        {
            if (this.AskToVetoFileChange())
                Close();
        }

        void OnUndo(object sender, Event evt)
        {
            if (this._srcText.CanUndo)
            {
                this._srcText.Undo();
            }
            this._toolbar.EnableTool((int)Cmd.Undo, this._srcText.CanUndo);
            this._toolbar.EnableTool((int)Cmd.Redo, this._srcText.CanRedo);
        }

        void OnRedo(object sender, Event evt)
        {
            if (this._srcText.CanRedo)
            {
                this._srcText.Redo();
            }
            this._toolbar.EnableTool((int)Cmd.Undo, this._srcText.CanUndo);
            this._toolbar.EnableTool((int)Cmd.Redo, this._srcText.CanRedo);
        }

        /** This will conduct all those actions that are necessary to reset changes to the current document.
         * This will
         * \li disable SAVE button
         * \li remove "*" asterisk from file names in list and tree
         * \li remove label unsaved changes from client data
         * \li empty undo/redo buffer
         * \li diable undo and redo.
         */
        void SetCurrentSavedOrUnchanged()
        {
            this._toolbar.EnableTool((int)Cmd.Save, false);
            if (this._currentFile != null
                && this._currentFile.TreeId != null
                && this._currentFile.TreeId.IsOk()
                && this._treeCtrl != null
                && this._treeCtrl.GetItemText(this._currentFile.TreeId).EndsWith("*"))
            {
                string currentText = this._treeCtrl.GetItemText(this._currentFile.TreeId);
                this._treeCtrl.SetItemText(this._currentFile.TreeId,
                    currentText.Substring(0, currentText.Length - 1));
            }
            if (this._currentFile != null
                && this._listCtrl != null
                && this._currentFile.IndexInListCtrl >= 0)
            {
                ListItem item = this._listCtrl[this._currentFile.IndexInListCtrl];
                item.Image = ImageUnselected(item.Image);
                if (item.Text.EndsWith("*"))
                    item.Text = item.Text.Substring(0, item.Text.Length - 1);
                this._listCtrl[this._currentFile.IndexInListCtrl] = item;
            }
            if (this._currentFile != null)
                this._currentFile.UnsavedChanges = false;
            this._srcText.EmptyUndoBuffer();
            this._toolbar.EnableTool((int)Cmd.Undo, false);
            this._toolbar.EnableTool((int)Cmd.Redo, false);
        }

        /** Event implementing commands to save the current document.
         */
        void OnSaveCurrentDocument(object sender, Event evt)
        {
            this.SaveCurrentDocument();
        }

        /** Saves changes to the current document.
         */
        void SaveCurrentDocument()
        {
            if (this._srcText.CanUndo && this._currentFile!=null)
            {
                this._srcText.SaveFile(this._currentFile.Filename);
                this.SetCurrentSavedOrUnchanged();
            }
        }

        void OnUpdateStatus(object sender, Event evt)
        {
            SetStatusText(this._srcText.GetLexerStateNameAtPos(this._srcText.CurrentPos)
                +" "+this._srcText.GetFoldLevel(this._srcText.CurrentLine).ToString("X")
                + " "+this._srcText.GetFoldLevelFlags(this._srcText.CurrentLine)
                + " " + this._srcText.GetFoldLevelNumber(this._srcText.CurrentLine)
                + " " + this._srcText.GetFoldParent(this._srcText.CurrentLine));
            evt.Skip();
        }

        void OnToggleVisibilityList(object sender, Event evt)
        {
            if (this._listCtrl != null)
            {
                if (this._listCtrl.IsShown)
                {
                    this._listCtrl.Show(false);
                    if (this._listSplitter == null)
                    {
                        this.Refresh();
                    }
                    else if (this._listSplitter.IsSplit)
                    {
                        this._listSplitter.Unsplit(this._listCtrl);
                    }
                    else
                    {
                        this._splitter.Unsplit(this._listSplitter);
                    }
                }
                else
                {
                    bool isOtherShown = this._treeCtrl.IsShown;
                    this._listCtrl.Show(true);
                    if (!this._splitter.IsSplit)
                        this._splitter.SplitVertically(this._listSplitter, this._srcText);
                    this._listSplitter.SplitHorizontally(this._treeCtrl, this._listCtrl);
                    if (!isOtherShown)
                        this._listSplitter.Unsplit(this._treeCtrl);
                }
            }
        }

        void OnToggleVisibilityProject(object sender, Event evt)
        {
            if (this._treeCtrl != null)
            {
                if (this._treeCtrl.IsShown)
                {
                    this._treeCtrl.Show(false);
                    if (this._listSplitter == null)
                    {
                        this.Refresh();
                    }
                    else if (this._listSplitter.IsSplit)
                    {
                        this._listSplitter.Unsplit(this._treeCtrl);
                    }
                    else
                    {
                        this._splitter.Unsplit(this._listSplitter);
                    }
                }
                else
                {
                    bool isOtherShown=this._listCtrl.IsShown;
                    this._treeCtrl.Show(true);
                    if (!this._splitter.IsSplit)
                        this._splitter.SplitVertically(this._listSplitter, this._srcText);
                    this._listSplitter.SplitHorizontally(this._treeCtrl, this._listCtrl);
                    if (!isOtherShown)
                        this._listSplitter.Unsplit(this._listCtrl);
                }
            }
        }

        void OnToggleProjectTreeMode(object sender, Event evt)
        {
            this._projectTreeSelectAllSiblings = !this._projectTreeSelectAllSiblings;
            this.UpdateList();
        }

        void OnEditText(object sender, Event evt)
        {
            if (this._srcText.Modify && !this._srcText.ReadOnly)
            {
                this._toolbar.EnableTool((int)Cmd.Save, true);
                if (this._currentFile != null && !this._currentFile.UnsavedChanges)
                {
                    this._currentFile.UnsavedChanges = true;
                    if (this._currentFile.TreeId != null
                        && this._currentFile.TreeId.IsOk()
                        && this._treeCtrl != null)
                    {
                        this._treeCtrl.SetItemText(this._currentFile.TreeId,
                            this._treeCtrl.GetItemText(this._currentFile.TreeId) + "*");
                    }
                    if (this._listCtrl != null
                        && this._currentFile.IndexInListCtrl >= 0)
                    {
                        ListItem item = this._listCtrl[this._currentFile.IndexInListCtrl];
                        item.Image = ImageSelected(item.Image);
                        item.Text = item.Text + "*";
                        this._listCtrl[this._currentFile.IndexInListCtrl] = item;
                    }
                }
                this._toolbar.EnableTool((int)Cmd.Undo, this._srcText.CanUndo);
                this._toolbar.EnableTool((int)Cmd.Redo, this._srcText.CanRedo);
            }
            evt.Skip(true);
        }

        void UpdateList()
        {
            if (!this._listCtrl.IsShown)
                return;
            Queue<TreeItemId> agenda = new Queue<TreeItemId>();
            foreach (TreeItemId selection in this._treeCtrl.Selections())
            {
                if (this._treeCtrl.GetChildrenCount(selection) > 0)
                    agenda.Enqueue(selection);
                else
                {
                    TreeItemId parent=this._treeCtrl.GetItemParent(selection);
                    ClientDataReferringToFile data = this._treeCtrl.GetItemData(selection).Data as ClientDataReferringToFile;
                    if (data.RowInList != null
                        && (data.IndexInListCtrl < 0 || this._listCtrl.ItemCount==0)
                        && parent.IsOk())
                        agenda.Enqueue(parent);
                }
            }
            if (agenda.Count > 0)
            {
                // we will only change the list view, if a non-leaf has been selected
                // because this indicates the purpose to select 
                this._listCtrl.Show(false);
                this._listCtrl.ClearAll();
                foreach (ClientDataReferringToFile data in this._allFilenames)
                {
                    data.IndexInListCtrl=-1;
                }
                // Please note, that also the column descriptors has been cleared
                wx.ListItem itemCol = new wx.ListItem();
                itemCol.Text = _("Name");
                itemCol.Align = wx.ListColumnFormat.LEFT;
                itemCol.Image = -1;
                this._listCtrl.InsertColumn(0, itemCol);

                itemCol.Text = _("Type");
                itemCol.Align = wx.ListColumnFormat.LEFT;
                this._listCtrl.InsertColumn(1, itemCol);

                itemCol.Text = _("Directory");
                itemCol.Align = wx.ListColumnFormat.LEFT;
                this._listCtrl.InsertColumn(2, itemCol);

                itemCol.Text = _("Last Change");
                itemCol.Align = wx.ListColumnFormat.RIGHT;
                this._listCtrl.InsertColumn(3, itemCol);

                itemCol.Text = _("Project");
                itemCol.Align = wx.ListColumnFormat.RIGHT;
                this._listCtrl.InsertColumn(4, itemCol);

                bool firstLevel = true;
                while (agenda.Count > 0)
                {
                    TreeItemId current = agenda.Dequeue();
                    TreeItemData itemData = this._treeCtrl.GetItemData(current);
                    ClientDataReferringToFile data = itemData.Data as ClientDataReferringToFile;
                    if (data != null && data.RowInList != null)
                    {
                        if (data.UnsavedChanges)
                        {
                            data.RowInList[0].Image = ImageSelected(data.IconIndex);
                        }
                        else
                            data.RowInList[0].Image = data.IconIndex;
                        int pos = this._listCtrl.AppendItemRow(data.RowInList);
                        data.IndexInListCtrl = pos;
                        if (data.UnsavedChanges)
                            this._listCtrl.SetItemText(pos, data.RowInList[0].Text + "*");
                    }

                    TreeItemId[] children = this._treeCtrl.GetChildren(current);
                    if (children != null && (this._projectTreeSelectAllSiblings || firstLevel))
                    {
                        foreach (TreeItemId child in children)
                            agenda.Enqueue(child);
                    }
                    firstLevel = false;
                }

                this._listCtrl.SetColumnWidth(0, ListCtrl.SymbolicColumnWidth.AUTOSIZE_USEHEADER);
                this._listCtrl.SetColumnWidth(1, ListCtrl.SymbolicColumnWidth.AUTOSIZE_USEHEADER);
                this._listCtrl.SetColumnWidth(2, ListCtrl.SymbolicColumnWidth.AUTOSIZE_USEHEADER);
                this._listCtrl.SetColumnWidth(3, ListCtrl.SymbolicColumnWidth.AUTOSIZE_USEHEADER);
                this._listCtrl.SetColumnWidth(4, ListCtrl.SymbolicColumnWidth.AUTOSIZE_USEHEADER);
                this._listCtrl.Show(true);
            }
        }

        /** This will raise a message box if the text editor can undo and ask for confirmation.
         * Call this before any action changing the current file.
         * \return true if either the text editor does not have unsaved changes or the user confirmed loss of these changes.
         */
        bool AskToVetoFileChange()
        {
            if (this._srcText.CanUndo)
            {
                ShowModalResult result = MessageDialog.MessageBox(_("Unsafed changes will get lost.\nPress OK to proceed or CANCEL to abort action."),
                    _("Warning"), WindowStyles.ICON_WARNING | WindowStyles.DIALOG_CANCEL | WindowStyles.DIALOG_OK, this);
                return result == ShowModalResult.OK;
            }
            return true;
        }

        void OnListSelChanging(object sender, Event evt)
        {
            ListEvent levt = (ListEvent)evt;
            ClientDataReferringToFile data = ((wx.SystemObjectClientData)levt.Data).Data as ClientDataReferringToFile;
            if (this._treeCtrl != null)
            {
                if (this._treeCtrl.IsExpanded(data.TreeGroupId)
                    && (data.State & ClientDataReferringToFile.States.InTreeSelection) != ClientDataReferringToFile.States.InTreeSelection)
                {
                    this._treeCtrl.SelectItem(data.TreeId);
                    data.State = data.State | ClientDataReferringToFile.States.InTreeSelection;
                }
            }
            this.LoadTextFile(data);
        }

        void OnSelectColumn(object sender, Event evt)
        {
            this._popupContext = ((ListEvent)evt).Column;
            Menu popup = new Menu(_("Column Options"));
            popup.Append(Cmd.SortAscWrtColumn, _("Sort Ascending"));
            popup.Append(Cmd.SortDescWrtColumn, _("Sort Descending"));
            this.PopupMenu(popup);
        }

        int ColumnComparer(ClientData item1, ClientData item2, int column)
        {
            int sign = 1;
            if (column < 0)
            {
                sign = -1;
                column = -column;
            }
            --column;

            ClientDataReferringToFile data1 = (ClientDataReferringToFile)((SystemObjectClientData)item1).Data;
            ClientDataReferringToFile data2 = (ClientDataReferringToFile)((SystemObjectClientData)item2).Data;

            string text1 = data1.RowInList[column].Text;
            string text2 = data2.RowInList[column].Text;

            return sign*text1.CompareTo(text2);
        }

        void OnSortListAscending(object sender, Event evt)
        {
            if (this._popupContext != null && this._popupContext is int)
            {
                ListCtrl.wxListCtrlCompare cmp = new ListCtrl.wxListCtrlCompare(this.ColumnComparer);
                this._listCtrl.SortItems(cmp, 1+(int)this._popupContext);

                for (int i = 0; i < this._listCtrl.ItemCount; ++i)
                {
                    this.UpdateClientDataForListIndex((ClientDataReferringToFile) ((SystemObjectClientData)this._listCtrl.GetItemData(i)).Data, i);
                }
            }
        }

        void OnSortListDescending(object sender, Event evt)
        {
            if (this._popupContext != null && this._popupContext is int)
            {
                ListCtrl.wxListCtrlCompare cmp = new ListCtrl.wxListCtrlCompare(this.ColumnComparer);
                this._listCtrl.SortItems(cmp, -1 - (int)this._popupContext);

                for (int i = 0; i < this._listCtrl.ItemCount; ++i)
                {
                    this.UpdateClientDataForListIndex((ClientDataReferringToFile)((SystemObjectClientData)this._listCtrl.GetItemData(i)).Data, i);
                }
            }
        }

        /** Loads a new text file into the STC control.
         */
        void LoadTextFile(ClientDataReferringToFile filedata)
        {
            this.SaveCurrentDocument();

            // first deselect current file to avoid side-effects on event processing
            if (this._currentFile != null)
            {
                this._styles.ForFilename(this._currentFile.Filename).DeactivateFor(this._srcText);
                this._currentFile.State = ClientDataReferringToFile.States.Unselected;
                this._currentFile = null;
            }
            if (this._srcText != null)
            {
                this._srcText.LoadFile(filedata.Filename);
                filedata.State = filedata.State | ClientDataReferringToFile.States.Selected;
            }
            this._styles.ForFilename(filedata.Filename).Apply(this._srcText);

            this._srcText.EmptyUndoBuffer();
            // this must be done after loading because loading edits the text and that will enable the tool
            // We will ensure that the edit event has been executed yielding the application. then, we will
            // disable the tool for saving.
            wx.App.TheApp.SafeYield();
            this._toolbar.EnableTool((int)Cmd.Save, filedata.UnsavedChanges);
            this._currentFile = filedata;
        }

        void OnTreeSelChanging(object sender, Event evt)
        {
                evt.Skip(true);
        }

        void OnTreeSelChanged(object sender, Event evt)
        {
            this.UpdateList();

            TreeEvent tevt = (TreeEvent)evt;
            TreeItemId item = tevt.Item;
            ClientDataReferringToFile clientData = (ClientDataReferringToFile)this._treeCtrl.GetItemData(item).Data;
            if (clientData != null && clientData.IndexInListCtrl >= 0)
            {
                if (this._listCtrl.GetItemState(clientData.IndexInListCtrl, ListItemState.SELECTED) != ListItemState.SELECTED
                    && (clientData.State&ClientDataReferringToFile.States.InListSelection) != ClientDataReferringToFile.States.InListSelection)
                {
                    clientData.State = clientData.State | ClientDataReferringToFile.States.InListSelection;
                    this._listCtrl.SetItemState(clientData.IndexInListCtrl, ListItemState.SELECTED, ListItemState.SELECTED);
                }
                this._listCtrl.EnsureVisible(clientData.IndexInListCtrl);

                this.LoadTextFile(clientData);
            }

            evt.Skip(true);
        }

        void OnTreeExpanded(object sender, Event evt)
        {
            TreeEvent tevt = (TreeEvent)evt;
            TreeItemId item = tevt.Item;
            IEnumerator<ListItem> enumerator = new ListCtrl.ItemEnumerator(this._listCtrl, ListItemState.SELECTED);
            while (enumerator.MoveNext())
            {
                ClientDataReferringToFile data = ((SystemObjectClientData)enumerator.Current.Data).Data as ClientDataReferringToFile;
                if (data.TreeGroupId == item)
                {
                    if (!this._treeCtrl.IsSelected(data.TreeId))
                        this._treeCtrl.SelectItem(data.TreeId);
                }
            }
            evt.Skip(true);
        }

        /** Implements the menu event unfolding everything.
         */
        void OnExpandFoldAll(object sender, Event evt)
        {
            for (int lineNo = 0; lineNo < this._srcText.LineCount; ++lineNo)
            {
                if ((this._srcText.GetFoldLevelFlags(lineNo)&FoldLevel.HEADERFLAG) == FoldLevel.HEADERFLAG
                    && !this._srcText.GetFoldExpanded(lineNo))
                {
                    this._srcText.ToggleFold(lineNo);
                }
            }
        }

        /** Implements the menu event folding up everything.
         */
        void OnContractFoldAll(object sender, Event evt)
        {
            for (int lineNo = 0; lineNo < this._srcText.LineCount; ++lineNo)
            {
                if ((this._srcText.GetFoldLevelFlags(lineNo)&FoldLevel.HEADERFLAG) == FoldLevel.HEADERFLAG
                    && this._srcText.GetFoldExpanded(lineNo))
                {
                    this._srcText.ToggleFold(lineNo);
                }
            }
        }
        #endregion

        #region Helpers
        /** Instances of this represent client data for each node referring to a file either in list or tree control.
         */
        class ClientDataReferringToFile
        {
            public int IndexInListCtrl;
            public int IndexInFullList;
            public TreeItemId TreeId;
            public TreeItemId TreeGroupId;
            public string Basename;
            public string Filename;
            public IList<string> ProjectPath;

            [Flags]
            public enum States
            {
                Unselected=0x000,
                InListSelection=0x01,
                InTreeSelection = 0x02,
                Selected = 0x07
            }
            public States State = States.Unselected;

            /** Index of the icon to use.
             * Some operations may change the item that is actually displayed but not this property.
             */
            public int IconIndex=-1;

            public bool UnsavedChanges = false;

            /** Currently 5 columns in the file list control.
             */
            public ListItem[] RowInList = null;

            public ClientDataReferringToFile(TreeItemId treeId, TreeItemId treeGroupId, string filename, IList<string> projectPath)
            {
                this.IndexInListCtrl = -1;
                this.IndexInFullList = -1;
                this.TreeId = treeId;
                this.TreeGroupId = treeGroupId;
                this.Filename = filename;
                this.Basename = System.IO.Path.GetFileName(filename);
                this.ProjectPath = projectPath;
            }
        }

        /** Finds or creates a project of the provided path on the tree control (path description without root node) and add the provided file to that project.
         * If the \c projectPath is \c null or empty, the root project will be used.
         * If \c filename is \c null or empty, this will only create the project.
         * 
         * This will return the tree id of the provided file of if file is \c null the
         * id of te project.
         */
        ClientDataReferringToFile AddToProject(string filename, IList<string> projectPath)
        {
            if (this._treeCtrl==null)
                return null;
            ClientDataReferringToFile clientData = null;
            TreeItemId node = this._treeCtrl.RootItem;
            int depth=0;
            if (projectPath != null && projectPath.Count > 0)
            {
                foreach (string name in projectPath)
                {
                    bool found = false;
                    if (this._treeCtrl.GetChildrenCount(node, false) > 0)
                    {
                        foreach (TreeItemId child in this._treeCtrl.GetChildren(node))
                        {
                            if (this._treeCtrl.GetItemText(child).ToLower().Equals(name.ToLower()))
                            {
                                found = true;
                                node = child;
                                break;
                            }
                        }
                    }
                    if (!found)
                    {
                        while (depth < projectPath.Count)
                        {
                            TreeItemId newNode = this._treeCtrl.AppendItem(node,
                                projectPath[depth],
                                this.GetImageIndex(projectPath[depth], true, false),
                                this.GetImageIndex(projectPath[depth], true, true));
                            IList<string> localProjectPath = new List<string>();
                            for(int i=0; i <= depth; ++i)
                                localProjectPath.Add(projectPath[i]);
                            clientData=new ClientDataReferringToFile(newNode, newNode, null, localProjectPath);
                            this._treeCtrl.SetItemData(newNode, new TreeItemData(clientData));
                            node = newNode;
                            ++depth;
                        }
                        break;
                    }
                    ++depth;
                }
            }
            if (filename != null && filename.Length > 0)
            {
                string basename = System.IO.Path.GetFileName(filename);
                TreeItemId newNode = this._treeCtrl.AppendItem(node,
                    basename,
                    this.GetImageIndex(filename, false, false),
                    this.GetImageIndex(filename, false, true));
                clientData = new ClientDataReferringToFile(newNode, node, filename, projectPath);
                this._treeCtrl.SetItemData(newNode, new TreeItemData(clientData));
                node = newNode;
            }
            return clientData;
        }

        /** Returns the image index (referring to the standard image list) for a file of the given name (filename plu extension).
         * \param isDirectory shall be true iff \c filename is supposed to be a directory
         * \param isSelected shall be true iff the caller desires the index of the selected image.
         */
        int GetImageIndex(string filename, bool isDirectory, bool isSelected)
        {
            int result = 6;
            if (!isDirectory)
            {
                string ext = System.IO.Path.GetExtension(filename).ToLower();
                if (ext == ".cpp" || ext == ".cc" || ext == ".cxx")
                    result = 4;
                else if (ext == ".cs")
                    result = 2;
                else
                    result = 0;
            }
            if (isSelected)
                result=ImageSelected(result);
            return result;
        }

        /** Return image index for an icon that is \c imageIndex but selected.
         */
        static int ImageSelected(int imageIndex)
        {
            if (imageIndex % 2 == 0)
                ++imageIndex;
            return imageIndex;
        }

        /** Return image index for an icon that is \c imageIndex but unselected.
         */
        static int ImageUnselected(int imageIndex)
        {
            if (imageIndex % 2 == 1)
                --imageIndex;
            return imageIndex;
        }

        wx.Colour LightBgColour = wx.Colour.wxWHITE;
        wx.Colour DarkBgColour = new wx.Colour(220, 220, 220); //wx.Colour.wxLIGHT_GREY;

        /** This will be called whenever the item that \c data refers to changes its index to \c data.
         */
        void UpdateClientDataForListIndex(ClientDataReferringToFile data, int index)
        {
            data.IndexInListCtrl = index;

            wx.Colour bgColour = this.LightBgColour;
            if (index % 2 == 0)
                bgColour = this.DarkBgColour;
            data.RowInList[0].BackgroundColour = bgColour;
            data.RowInList[1].BackgroundColour = bgColour;
            data.RowInList[2].BackgroundColour = bgColour;
            data.RowInList[3].BackgroundColour = bgColour;
            data.RowInList[4].BackgroundColour = bgColour;

            if (this._listCtrl.ItemCount > index) 
                this._listCtrl.SetItemBackgroundColour(index, bgColour);
        }

        /** Adds the designated file to the list control if the file exists.
         * Returns \c true on success.
         * 
         * \c projectPath is a list of strings describing the path to th project that
         * \c filename belongs to without the root. So, this may be empty or \c null
         * to denote the root node.
         */
        bool AddFileToList(string filename, IList<string> projectPath)
        {
            if (System.IO.File.Exists(filename))
            {
                ClientDataReferringToFile clientData=null;
                if (this._treeCtrl == null)
                    clientData = new ClientDataReferringToFile(null, null, filename, projectPath);
                else
                    clientData=this.AddToProject(filename, projectPath);

                wx.ListItem colName = new ListItem();
                colName.Column = 0;
                wx.ListItem colType = new ListItem();
                colType.Column = 1;
                wx.ListItem colPath = new ListItem();
                colPath.Column = 2;
                wx.ListItem colDate = new ListItem();
                colDate.Column = 3;
                wx.ListItem colProject = new ListItem();
                colDate.Column = 4;

                if (clientData.UnsavedChanges)
                    colName.Text = System.IO.Path.GetFileNameWithoutExtension(filename)+"*";
                else
                    colName.Text = System.IO.Path.GetFileNameWithoutExtension(filename);
                colName.Data = new SystemObjectClientData(clientData);
                colType.Text = System.IO.Path.GetExtension(filename).ToLower();
                clientData.IconIndex = this.GetImageIndex(filename, false, false);
                if (clientData.UnsavedChanges)
                    colName.Image = ImageSelected(clientData.IconIndex);
                else
                    colName.Image = clientData.IconIndex;
                colPath.Text = System.IO.Path.GetDirectoryName(filename);
                colDate.Text = System.IO.File.GetLastWriteTime(filename).ToString();

                int counter = 0;
                string colProjectText = "";
                foreach (string pathcomponent in projectPath)
                {
                    if (counter != 0)
                        colProjectText += ", ";
                    colProjectText += pathcomponent;
                    ++counter;
                }
                colProject.Text = colProjectText;

                clientData.RowInList = new ListItem[] { colName, colType, colPath, colDate, colProject };
                this.UpdateClientDataForListIndex(clientData, this._allFilenames.Count);

                clientData.IndexInFullList = this._allFilenames.Count;
                this._allFilenames.Add(clientData);
                return true;
            }
            return false;
        }

        /** Fill the list view.
         * Either reads configured configured files into the list (if the files still exist)
         * or searches for the \e wx.NET sources.
         */
        void InitListItems()
        {
            this._listCtrl.Hide();
            bool loadWxNetSource = true;
            for (int counter=0; ;++counter )
            {
                string entryName=string.Format("ProjectFile{0}", counter);
                if (this._config.HasEntry(entryName))
                {
                    string filename = this._config.Read(entryName,"");
                    if (this.AddFileToList(filename, null))
                        loadWxNetSource = false;
                }
                else
                    break;
            }
            if (loadWxNetSource)
            {
                string basedir = "..";
                string srcdir = System.IO.Path.Combine(basedir, "Src");
                string wxnetdir = System.IO.Path.Combine(srcdir, "wx.NET");
                string wxcdir = System.IO.Path.Combine(srcdir, "wx-c");

                if (System.IO.Directory.Exists(wxnetdir))
                {
                    foreach (string filename in System.IO.Directory.GetFiles(wxnetdir, "*.cs"))
                        this.AddFileToList(filename, new string[] { "Src", "wx.NET" });
                }
                if (System.IO.Directory.Exists(wxcdir))
                {
                    foreach (string filename in System.IO.Directory.GetFiles(wxcdir, "*.cxx"))
                        this.AddFileToList(filename, new string[] { "Src", "wx-c" });
                }
            }
            this.UpdateList();
            this._listCtrl.Show();
        }
        #endregion
    }


    /** Main application of the sample.
     */
    public class StcCodeViewApp : wx.App
    {
        public StcCodeViewApp()
        {
            this.AppName = "STC Code Viewer";
            this.VendorName = "wx.NET Project";
        }

        public override bool OnInit()
        {
            wx.Archive.ZipResource.AddCatalogLookupPrefix(@"../Samples/StcCodeView");
            wx.Archive.ZipResource.AddCatalogLookupPrefix(@"../..");
            wx.Archive.ZipResource.AddCatalogLookupPrefix(@".");

            wx.ToolTip.Enabled = true;
            wx.ToolTip.Delay = 500;

            wx.Frame frame = new StcCodeFrame(null, -1, _("wx.NET STC code viewer"), wx.Window.wxDefaultPosition, new Size(800, 600));
            return frame.Show(true);
        }

        /** This will start the main frame trying to load all files as named by the arguments.
         * The result is \c true on success on loading all named files.
         */
        [STAThread]
        static public int Main(string[] arg)
        {
            int errCode = 0;
            try
            {
                System.Diagnostics.Trace.Listeners.Add(new System.Diagnostics.ConsoleTraceListener());
                wx.FileSys.FileSystem.AddHandler(new wx.FileSys.IOStreamFSHandler());
                wx.FileSys.FileSystem.AddHandler(new wx.FileSys.ZipFSHandler());
                
                StcCodeViewApp app = new StcCodeViewApp();
                app.Run();
            }
            catch (Exception exc)
            {
                System.Diagnostics.Trace.WriteLine(exc);
                System.Diagnostics.Trace.WriteLine(exc.StackTrace);
                errCode = 100;
            }
            return errCode;
        }
    }
}

#else

#warning "This sample requires WXNET_STYLEDTEXTCTRL to be defined."
#endif
