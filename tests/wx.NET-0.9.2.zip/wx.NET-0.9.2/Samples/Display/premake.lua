-- Premake script for the wx.NET "Notebook" sample.
-- See http://premake.sourceforge.net/ for more info about Premake.

package.name     = "Display"
package.language = "c#"
package.kind     = "winexe"
package.target   = "display"
project.bindir   = "../Bin"

package.links    = { "System.Drawing", "wx.NET" }

package.files    = { "Display.cs", "CompareModesDialog.cs" }
