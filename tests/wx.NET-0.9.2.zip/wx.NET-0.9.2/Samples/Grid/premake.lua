-- Premake script for the wx.NET "Grid" sample.
-- See http://premake.sourceforge.net/ for more info about Premake.

package.name     = "Grid"
package.language = "c#"
package.kind     = "winexe"
package.target   = "grid"
project.bindir   = "../Bin"

package.links    = { "System.Drawing", "wx.NET" }

package.files    = { "Grid.cs" }
