-- Premake script for the wx.NET "Thread" sample.
-- See http://premake.sourceforge.net/ for more info about Premake.

package.name     = "Thread"
package.language = "c#"
package.kind     = "winexe"
package.target   = "thread"
project.bindir   = "../Bin"

package.links    = { "System.Drawing", "wx.NET" }

package.files    = { "Thread.cs" }
