-- Premake script for the wx.NET samples
-- See http://premake.sourceforge.net/ for more info about Premake.

project.name   = "Samples"
project.bindir = "../Bin"

addoption("with-display", "Enable Display sample")

dopackage("Controls/premake.lua")
dopackage("Dialogs/premake.lua")
dopackage("Minimal/premake.lua")
dopackage("Printing/premake.lua")
dopackage("Splitter/premake.lua")
dopackage("TreeCtrl/premake.lua")
dopackage("Tutorial/premake.lua")
dopackage("Wizard/premake.lua")
dopackage("StcCodeView/premake.lua")
dopackage("Dnd/premake.lua")
dopackage("HTML/premake.lua")
dopackage("Font/premake.lua")
dopackage("Notebook/premake.lua")
dopackage("Mdi/premake.lua")
dopackage("Grid/premake.lua")
dopackage("HtmlListBox/premake.lua")
if (options["with-display"]) then
	dopackage("Display/premake.lua")
end
dopackage("Xrc/premake.lua")
dopackage("EventDemo/premake.lua")
dopackage("Listbook/premake.lua")
dopackage("SashWindow/premake.lua")
dopackage("Launcher/premake.lua")
dopackage("ListView/premake.lua")
dopackage("HtmlHelp/premake.lua")
dopackage("Internat/premake.lua")
dopackage("ListCtrl/premake.lua")
dopackage("Thread/premake.lua")

