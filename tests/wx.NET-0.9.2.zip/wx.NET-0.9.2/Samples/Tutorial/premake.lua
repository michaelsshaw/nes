-- Premake script for the tutorial.
-- See http://premake.sourceforge.net/ for more info about Premake.

package.name     = "ImageView"
package.language = "c#"
package.kind     = "winexe"
package.target   = "imgview"
project.bindir   = "../Bin"

package.links    = { "System.Drawing", "wx.NET" }

package.files    = { "ImageView.cs", "ImageList.cs", "Thumbnail.cs", "ImageViewer.cs" }

