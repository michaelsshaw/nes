-- Premake script for the wx.NET "TreeCtrl" sample.
-- See http://premake.sourceforge.net/ for more info about Premake.

package.name     = "TreeCtrl"
package.language = "c#"
package.kind     = "winexe"
package.target   = "treectrl"
project.bindir   = "../Bin"

package.links    = { "System", "System.Drawing", "wx.NET" }

package.files    = { "TreeCtrl.cs" }
