/** Doxygen documentation introducing into all samples.
 \file
 
 Written by Harald Meyer auf'm Hofe harald_meyer@users.sourceforge.net

 (C) Harald Meyer auf'm Hofe 2009

 Licensed under the wxWidgets license, see LICENSE.txt for details.

 $Id: SamplesDoxMainpage.cs,v 1.2 2010/06/11 18:46:44 harald_meyer Exp $
*/

/** \mainpage

\image html logo2.png 
 
This is the documentation on samples and tools shipped with \e wx.NET.
This page will give a short list of the samples. This documentation provides the declarations
of the implemented classes and methods and also listings of the complete source code. 

\li wx.SampleControls demonstates controls that are available with \e wx.NET.
\li wx.SampleDialogs demonstrates standard dialogs.
\li wx.SampleGrid introduces into the \e wxWidgets grid control.
\li wx.SampleHTML and wx.SampleHtmlHelp demonstate the \e wxWidgets HTML control and its use within a help controller.
\li wx.SampleInternat is a port of the original sample on i18n support in conjunction with \e gettext. Please note, that \e wx.NET offers additional opportunities to provide translations for classes and enumerations.
\li wx.SampleListCtrl demonstrates the capabilities of the list control.
\li wx.SampleTreeCtrl exemplifies the use of the tree control.
\li wx.SampleDisplay demonstrates manipulations of screen resolution.
\li wx.SampleStyledText is a sample demonstration of the styled text control (STC) contributed to \e wxWidgets. This will grow more and more to be a tool for managing and extending the code of the project. By the way, this demo will enable you to investigate all the code that implements \e wx.NET.

Please have a look at the namespaces listed in the appropriate HTML page for more samples.

*/