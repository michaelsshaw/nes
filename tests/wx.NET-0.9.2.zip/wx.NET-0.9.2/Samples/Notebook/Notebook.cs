//-----------------------------------------------------------------------------
// wx.NET/Samples - Notebook.cs
//
// wx.NET "Notebook" sample.
//
// Written by Alexander Olk (xenomorph2@onlinehome.de)
// (C) 2003 by Alexander Olk
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: Notebook.cs,v 1.9 2009/02/21 16:55:24 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Drawing;

namespace wx.SampleNotebook
{ 
	public class MyFrame : wx.Frame
	{
		enum ID_CONTROLS 
		{
			ID_RADIO_ORIENT = 5999,
			ID_CHK_SHOWIMAGES,
			ID_BTN_ADD_PAGE,
			ID_BTN_INSERT_PAGE,
			ID_BTN_DELETE_CUR_PAGE,
			ID_BTN_DELETE_LAST_PAGE,
			ID_BTN_NEXT_PAGE,
			ID_NOTEBOOK
		}
		
		public const int ORIENT_TOP = 0;
		public const int ORIENT_BOTTOM = 1;
		public const int ORIENT_LEFT = 2;
		public const int ORIENT_RIGHT = 3;
		public const int ORIENT_MAX = 4;		
		
		private Panel m_panel;
		private RadioBox m_radioOrient;
		private CheckBox m_chkShowImages;
		
		private Button m_btnAddPage;
		private Button m_btnInsertPage;
		private Button m_btnDeleteCurPage;
		private Button m_btnDeleteLastPage;
		private Button m_btnNextPage;
		private Button m_btnExit;
		
		private MyNotebook m_notebook;
		private TextCtrl m_text;
		
		private BoxSizer m_sizerFrame;
		private BoxSizer m_sizerTop;
		private ImageList m_imageList;
		
		public static int s_pageAdded = 0;
		public static int s_pageIns = 0;
		public static int s_numNotebookEvents = 0;
		public static int s_nPages = -1;
		public static int s_nSel = -1;
		
		//---------------------------------------------------------------------

		public MyFrame( string title, Point pos, Size size )
			: base( title, pos, size )
		{
			Size imageSize = new Size( 32, 32 );
			
			m_imageList = new ImageList( imageSize.Width, imageSize.Height );
			
			m_imageList.Add( ArtProvider.GetIcon( ArtID.wxART_INFORMATION, ArtClient.wxART_OTHER, imageSize ) );
			
			m_imageList.Add( ArtProvider.GetIcon( ArtID.wxART_QUESTION, ArtClient.wxART_OTHER, imageSize ) );
			
			m_imageList.Add( ArtProvider.GetIcon( ArtID.wxART_WARNING, ArtClient.wxART_OTHER, imageSize ) );
			
			m_imageList.Add( ArtProvider.GetIcon( ArtID.wxART_ERROR, ArtClient.wxART_OTHER, imageSize ) );
			
			m_panel = new Panel( this, -1, wxDefaultPosition, wxDefaultSize,
                wx.WindowStyles.TAB_TRAVERSAL | wx.WindowStyles.CLIP_CHILDREN | wx.WindowStyles.BORDER_NONE);
			
			string[] strOrientations =
			{
				"&Top",
				"&Bottom",
				"&Left",
				"&Right"
			};
			
			m_radioOrient = new RadioBox(
				m_panel, (int)ID_CONTROLS.ID_RADIO_ORIENT,
				"&Tab orientation",
				wxDefaultPosition, wxDefaultSize,
				strOrientations,
                1, wx.WindowStyles.RA_SPECIFY_COLS);
			
			m_chkShowImages = new CheckBox( m_panel, (int)ID_CONTROLS.ID_CHK_SHOWIMAGES, "&Show images" );
			
			m_btnAddPage = new Button( m_panel, (int)ID_CONTROLS.ID_BTN_ADD_PAGE, "&Add page" );
			
			m_btnInsertPage = new Button( m_panel, (int)ID_CONTROLS.ID_BTN_INSERT_PAGE, "&Insert page" );
			
			m_btnDeleteCurPage = new Button( m_panel, (int)ID_CONTROLS.ID_BTN_DELETE_CUR_PAGE, "&Delete current page" );
			
			m_btnDeleteLastPage = new Button( m_panel, (int)ID_CONTROLS.ID_BTN_DELETE_LAST_PAGE, "Delete las&t page" );
			
			m_btnNextPage = new Button( m_panel, (int)ID_CONTROLS.ID_BTN_NEXT_PAGE, "&Next page" );
			
			m_btnExit = new Button( m_panel, wxID_OK, "&Exit" );
			m_btnExit.SetDefault();
			
			m_notebook = new MyNotebook( m_panel, (int)ID_CONTROLS.ID_NOTEBOOK );

            m_text = new TextCtrl(m_panel, -1, "", wxDefaultPosition, wxDefaultSize, wx.WindowStyles.TE_MULTILINE | wx.WindowStyles.TE_READONLY);
			
			Log.SetActiveTarget( m_text );
			Log.AddTraceMask( "focus" );			
			
			m_notebook.CreateInitialPages();
			
			m_sizerFrame = new BoxSizer( Orientation.wxVERTICAL );
			
			m_sizerTop = new BoxSizer( Orientation.wxHORIZONTAL );
			
			BoxSizer sizerLeft = new BoxSizer( Orientation.wxVERTICAL );
			
			sizerLeft.Add( m_radioOrient, 0, wx.SizerFlag.wxEXPAND );
			sizerLeft.Add( m_chkShowImages, 0, wx.SizerFlag.wxEXPAND | wx.SizerFlag.wxTOP, 4 );
			
			//sizerLeft.Add( 0, 0, 1 );

            sizerLeft.Add(m_btnAddPage, 0, wx.SizerFlag.wxEXPAND | (wx.SizerFlag.wxTOP | wx.SizerFlag.wxBOTTOM), 4);
            sizerLeft.Add(m_btnInsertPage, 0, wx.SizerFlag.wxEXPAND | (wx.SizerFlag.wxTOP | wx.SizerFlag.wxBOTTOM), 4);
            sizerLeft.Add(m_btnDeleteCurPage, 0, wx.SizerFlag.wxEXPAND | (wx.SizerFlag.wxTOP | wx.SizerFlag.wxBOTTOM), 4);
            sizerLeft.Add(m_btnDeleteLastPage, 0, wx.SizerFlag.wxEXPAND | (wx.SizerFlag.wxTOP | wx.SizerFlag.wxBOTTOM), 4);
            sizerLeft.Add(m_btnNextPage, 0, wx.SizerFlag.wxEXPAND | (wx.SizerFlag.wxTOP | wx.SizerFlag.wxBOTTOM), 4);
			
			//sizerLeft.Add( 0, 0, 1 );

            sizerLeft.Add(m_btnExit, 0, wx.SizerFlag.wxEXPAND);

            m_sizerTop.Add(sizerLeft, 0, wx.SizerFlag.wxEXPAND | wx.SizerFlag.wxALL, 4);

            m_sizerFrame.Add(m_sizerTop, 1, wx.SizerFlag.wxEXPAND);
            m_sizerFrame.Add(m_text, 0, wx.SizerFlag.wxEXPAND);
			
			ReInitNotebook();
			
			m_panel.Sizer = m_sizerFrame;
			
			m_panel.AutoLayout = true;
			
			m_sizerFrame.Fit( this );
			
			Centre( Orientation.wxBOTH );
			
			EVT_RADIOBOX( (int)ID_CONTROLS.ID_RADIO_ORIENT, new EventListener( OnCheckOrRadioBox) );
			EVT_CHECKBOX( (int)ID_CONTROLS.ID_CHK_SHOWIMAGES, new EventListener( OnCheckOrRadioBox ) );

			EVT_BUTTON( (int)ID_CONTROLS.ID_BTN_ADD_PAGE, new EventListener( OnButtonAddPage ) );
			EVT_BUTTON( (int)ID_CONTROLS.ID_BTN_INSERT_PAGE, new EventListener( OnButtonInsertPage ) );
			EVT_BUTTON( (int)ID_CONTROLS.ID_BTN_DELETE_CUR_PAGE, new EventListener( OnButtonDeleteCurPage ) );
			EVT_BUTTON( (int)ID_CONTROLS.ID_BTN_DELETE_LAST_PAGE, new EventListener( OnButtonDeleteLastPage ) );
			EVT_BUTTON( (int)ID_CONTROLS.ID_BTN_NEXT_PAGE, new EventListener( OnButtonNextPage ) );
			EVT_BUTTON( wxID_OK, new EventListener( OnButtonExit ) );

			EVT_UPDATE_UI( (int)ID_CONTROLS.ID_BTN_DELETE_CUR_PAGE, new EventListener( OnUpdateUIBtnDeleteCurPage ) );
			EVT_UPDATE_UI( (int)ID_CONTROLS.ID_BTN_DELETE_LAST_PAGE, new EventListener( OnUpdateUIBtnDeleteLastPage ) );

			EVT_NOTEBOOK_PAGE_CHANGED( (int)ID_CONTROLS.ID_NOTEBOOK, new EventListener( OnNotebook ) );
			EVT_NOTEBOOK_PAGE_CHANGING( (int)ID_CONTROLS.ID_NOTEBOOK, new EventListener( OnNotebook ) );

			EVT_IDLE( new EventListener( OnIdle ) );
		}
		
		public void ReInitNotebook()
		{
			wx.WindowStyles flags = wx.WindowStyles.NO_STYLE;
			
			switch ( m_radioOrient.Selection )
			{
				default: Log.LogError( "unknown notebook orientation" ); break;
				case ORIENT_TOP :
                    flags = wx.WindowStyles.NB_TOP;
					break;
				case ORIENT_BOTTOM :
                    flags = wx.WindowStyles.NB_BOTTOM;
					break;
				case ORIENT_LEFT :
                    flags = wx.WindowStyles.NB_LEFT;
					break;
				case ORIENT_RIGHT :
                    flags = wx.WindowStyles.NB_RIGHT;
					break;
			}
			
			MyNotebook notebook = m_notebook;
			
			m_notebook = new MyNotebook( m_panel, (int)ID_CONTROLS.ID_NOTEBOOK,
				wxDefaultPosition, wxDefaultSize, flags );
			
			if ( m_chkShowImages.IsChecked )
			{
				m_notebook.Images = m_imageList;
			}
			
			if ( notebook != null )
			{
				int sel = notebook.Selection;
				
				int count = notebook.PageCount;
				
				for ( int n = 0; n < count; n++ )
				{
					string str = notebook.GetPageText( n );
					
					Window page = m_notebook.CreatePage( str );
					m_notebook.AddPage( page, str, false, m_notebook.IconIndex );
				}
				
                m_sizerTop.Remove(m_notebook);
				
				notebook.Dispose();
				notebook = null;
				
				if ( sel != -1 )
				{
					m_notebook.Selection = sel;
				}
			}
			
			m_sizerTop.Add( m_notebook, 1, wx.SizerFlag.wxEXPAND | wx.SizerFlag.wxALL, 4 );
            m_sizerTop.Layout();
		}
		
		public void OnCheckOrRadioBox( object sender, Event e )
		{
			ReInitNotebook();
		}
		
		public void OnButtonAddPage( object sender, Event e )
		{
			Panel panel = new Panel( m_notebook, -1 );
			new Button( panel, -1, "First button", new Point( 10, 10 ), new Size( -1, -1 ) );
			new Button( panel, -1, "Second button", new Point( 50, 100 ), new Size( -1, -1 ) );
			
			m_notebook.AddPage( panel, "Added " + ( ++s_pageAdded).ToString(), true, m_notebook.IconIndex );
		}
		
		public void OnButtonInsertPage( object sender, Event e )
		{
			Panel panel = m_notebook.CreateUserCreatedPage();
			
			m_notebook.InsertPage( 0, panel, "Inserted " + ( ++s_pageIns).ToString(), false, m_notebook.IconIndex );
			
			m_notebook.Selection = 0;
		}
		
		public void OnButtonDeleteCurPage( object sender, Event e )
		{
			int sel = m_notebook.Selection;
			
			if ( sel != -1 )
			{
				m_notebook.DeletePage( sel );
			}
		}
		
		public void OnButtonDeleteLastPage( object sender, Event e )
		{
			int page = m_notebook.PageCount;
			
			if ( page != 0 )
			{
				m_notebook.DeletePage( page -1 );
			}
		}
		
		public void OnButtonNextPage( object sender, Event e )
		{
			m_notebook.AdvanceSelection( true );
		}
		
		public void OnButtonExit( object sender, Event e )
		{
			Close();
		}
		
		public void OnNotebook( object sender, Event e )
		{
			string str = "Unknown notebook event";
			
			NotebookEvent ne = (NotebookEvent) e;
			
			int eventType = ne.EventType;
			
			if ( eventType == Event.wxEVT_COMMAND_NOTEBOOK_PAGE_CHANGED )
			{
				str = "Notebook changed";
			}
			else if ( eventType == Event.wxEVT_COMMAND_NOTEBOOK_PAGE_CHANGING )
			{
				int idx = ne.OldSelection;
				
				if ( idx != -1 && m_notebook.GetPageText( idx ) == "Veto" )
				{
					MessageDialog md = new MessageDialog( this, "Are you sure you want to leave this notebook page?\n(This demonstrates veto-ing)",
							"Notebook sample", wx.WindowStyles.ICON_QUESTION | wx.WindowStyles.DIALOG_YES_NO );

                    if (md.ShowModal() != wx.ShowModalResult.YES)
					{
						ne.Veto();
						
						return;
					}		
				}
				
				str = "Notebook changing";
			}
			
			Log.LogMessage( "Notebook event #{0}: {1} ({2})", s_numNotebookEvents++, str, eventType );
			
			m_text.SetInsertionPointEnd();
			
			ne.Skip();
		}
		
		public void OnUpdateUIBtnDeleteCurPage( object sender, Event e )
		{
			UpdateUIEvent ue = (UpdateUIEvent) e;
			ue.Enabled = m_notebook.Selection != -1;
		}
		
		public void OnUpdateUIBtnDeleteLastPage( object sender, Event e )
		{
			UpdateUIEvent ue = (UpdateUIEvent) e;
			ue.Enabled = m_notebook.PageCount != 0;
		}
		
		public void OnIdle( object sender, Event e )
		{
			int nPages = m_notebook.PageCount;
			int nSel = m_notebook.Selection;
			if ( nPages != s_nPages || nSel != s_nSel )
			{
				s_nPages = nPages;
				s_nSel = nSel;
				
				string title = "Notebook (" + nPages + " pages, selection: " + nSel + ")";
				
				Title = title;
			}
		}
	}
	
	//---------------------------------------------------------------------
	
	public class MyNotebook : wx.Notebook
	{
		public MyNotebook( Window parent, int id )
			: this( parent, id, wxDefaultPosition, wxDefaultSize, 0 ) {}
		
		public MyNotebook( Window parent, int id, Point pos, Size size, wx.WindowStyles style )
			: base ( parent, id, pos, size, style )
		{
		}
		
		public void CreateInitialPages()
		{
			Panel panel = null;
			
			panel = CreateRadioButtonsPage();
			AddPage( panel, "Radiobuttons", false, IconIndex );
			
			panel = CreateVetoPage();
			AddPage( panel, "Veto", false, IconIndex );
			
			panel = CreateBigButtonPage();
			AddPage( panel, "Maximized button", false, IconIndex );
			
			panel = CreateInsertPage();
			InsertPage( 0, panel, "Inserted", false, IconIndex );
			
			Selection = 1;
		}
		
		public Panel CreatePage( string pageName )
		{
			if ( pageName.IndexOf( "Inserted " ) != -1 || pageName.IndexOf( "Added " ) != -1 )
			{
				return CreateUserCreatedPage();
			}
			
			if ( pageName == "Inserted" )
			{
				return CreateInsertPage();
			}
			
			if ( pageName == "Veto" )
			{
				return CreateVetoPage();
			}
			
			if ( pageName == "Radiobuttons" )
			{
				return CreateRadioButtonsPage();
			}
			
			if ( pageName == "Maximized button" )
			{
				return CreateBigButtonPage();
			}
			
			return CreateBigButtonPage();
		}
		
		public Panel CreateUserCreatedPage()
		{
			Panel panel = new Panel( this );
			
			new Button( panel, -1, "Button", new Point( 10, 10 ), new Size( -1, -1 ) );
			
			return panel;
		}
		
		public int IconIndex
		{
			get { 
				if ( Images != null )
				{
					int nImages = Images.ImageCount;
					if ( nImages > 0 )
					{
						return PageCount % nImages;
					}
				}
				return -1; 
			}
		}
		
		private Panel CreateInsertPage()
		{
			Panel panel = new Panel( this );
			
			panel.BackgroundColour = new Colour( "MAROON" );
			
			new StaticText( panel, -1, "This page has been inserted, not added.", new Point( 10, 10 ) );
			
			return panel;
		}
		
		private Panel CreateRadioButtonsPage()
		{
			Panel panel = new Panel( this );
			
			string[] animals = { "Fox", "Hare", "Rabbit", "Sabre-toothed tiger", "Rex" };
			
			RadioBox radiobox1 = new RadioBox( panel, -1, "Choose one", 
				wxDefaultPosition, wxDefaultSize, animals, 2, wx.WindowStyles.RA_SPECIFY_ROWS );
			
			string[] computers = { "Amiga", "Commodore 64", "PET", "Another" };
			
			RadioBox radiobox2 = new RadioBox( panel, -1, "Choose your favourite",
                wxDefaultPosition, wxDefaultSize, computers, 0, wx.WindowStyles.RA_SPECIFY_COLS);
			
			BoxSizer sizerPanel = new BoxSizer( Orientation.wxVERTICAL );
			sizerPanel.Add( radiobox1, 2, wx.SizerFlag.wxEXPAND );
            sizerPanel.Add(radiobox2, 1, wx.SizerFlag.wxEXPAND);
			panel.Sizer = sizerPanel;
			
			return panel;
		}
		
		private Panel CreateVetoPage()
		{
			Panel panel = new Panel( this );
			
			new StaticText( panel, -1, "This page intentionally left blank", new Point( 10, 10 ) );
			
			return panel;
		}
		
		private Panel CreateBigButtonPage()
		{
			Panel panel = new Panel( this );
			
			Button buttonBig = new Button( panel, -1, "Maximized button", new Point( 0, 0 ), new Size( 480, 360 ) );
			
			BoxSizer sizerPanel = new BoxSizer( Orientation.wxVERTICAL );
			sizerPanel.Add( buttonBig, 1, wx.SizerFlag.wxEXPAND );
			panel.Sizer = sizerPanel;
			
			return panel;
		}
	}
	
	//---------------------------------------------------------------------

	public class NOTEBOOK : wx.App
	{
		public override bool OnInit()
		{
			MyFrame frame = new MyFrame( "Notebook sample", Window.wxDefaultPosition, Window.wxDefaultSize );
			frame.Show( true );

			return true;
		}

		//---------------------------------------------------------------------

		[STAThread]
		static void Main()
		{
			NOTEBOOK app = new NOTEBOOK();
			app.Run();
		}
	}
}
