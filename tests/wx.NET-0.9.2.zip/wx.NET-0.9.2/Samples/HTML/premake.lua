-- Premake script for the wx.NET "HTML" sample.
-- See http://premake.sourceforge.net/ for more info about Premake.

package.name     = "HTML"
package.language = "c#"
package.kind     = "winexe"
package.target   = "html"
project.bindir   = "../Bin"

package.links    = { "System.Drawing", "wx.NET" }

package.files    = { "HTML.cs" }
