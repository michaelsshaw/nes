-- Premake script for the wx.NET "Minimal" sample.
-- See http://premake.sourceforge.net/ for more info about Premake.

package.name     = "Minimal"
package.language = "c#"
package.kind     = "winexe"
package.target   = "minimal"
project.bindir   = "../Bin"

package.links    = { "System.Drawing", "wx.NET" }

package.files    = { "Minimal.cs" }
