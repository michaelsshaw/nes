-- Premake script for the wx.NET "Controls" sample.
-- See http://premake.sourceforge.net/ for more info about Premake.

package.name     = "Controls"
package.language = "c#"
package.kind     = "winexe"
package.target   = "controls"
project.bindir   = "../Bin"

package.libpaths = { "../../Bin" }
package.links    = { "System.Drawing", "wx.NET" }

package.files    = { "Controls.cs" }
