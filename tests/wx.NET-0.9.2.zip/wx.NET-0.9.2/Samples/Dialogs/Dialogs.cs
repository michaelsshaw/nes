//-----------------------------------------------------------------------------
// wx.NET/Samples - Dialogs.cs
//
// A wx.NET version of the wxWidgets "dialogs" sample.
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: Dialogs.cs,v 1.35 2010/06/05 13:10:15 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Drawing;
using System.IO;


/** This sample shows the dialogs of \e wx.NET.
 * \image html dialogssmall.png "The dialogs sample"
 */
namespace wx.SampleDialogs
{
    /// <summary>
    /// This is an example for a task bar icon.
    /// This icon enables users to start the sample dialogs without using the main frame.
    /// </summary>
    public class MyTaskBarIcon : TaskBarIcon
    {
        /// <summary>
        /// Used to ensure that a main dialog lives on activating an event. 
        /// </summary>
        /// <remarks>
        /// The task bar icon runs events that are implemented by the main frame.
        /// Unfortunately, the user may have closed the main frame. In that case,
        /// the frame probably does not exist when the task bar is used.
        /// <para>
        /// Thus, instances of this class are used to create a new frame on starting
        /// an event handler by  the task item.
        /// </para>
        /// </remarks>
        class EventStub
        {
            MyTaskBarIcon _taskBar;
            string _methodName;
            public EventStub(MyTaskBarIcon taskBar, string eventMethod)
            {
                this._taskBar = taskBar;
                this._methodName = eventMethod;
            }

            public void OnRunningEventhandler(object sender, Event evt)
            {
                if (this._taskBar._mainFrame.IsNULL)
                {
                    this._taskBar._mainFrame = new MyFrame(); // Frame has been closed.
                    this._taskBar._mainFrame.m_taskBarIcon = this._taskBar;
                }
                System.Reflection.MethodInfo mi = this._taskBar._mainFrame.GetType().GetMethod(this._methodName);
                mi.Invoke(this._taskBar._mainFrame, new object[] { sender, evt });
            }

            public static EventListener CreateEventListener(MyTaskBarIcon taskBar, string eventMethod)
            {
                EventStub newStub = new EventStub(taskBar, eventMethod);
                EventListener result = new EventListener(newStub.OnRunningEventhandler);
                return result;
            }
        }

        MyFrame _mainFrame;
        public MyTaskBarIcon(MyFrame mainFrame)
        {
            this._mainFrame = mainFrame;
            this.SetIcon(new Icon("../Samples/Dialogs/mondrian.png"), _("wx.NET Dialogs in tool bar."));
        }

        public override Menu CreatePopupMenu()
        {
            wx.Menu popup = new Menu();
            popup.Append((int)MyFrame.Cmd.ReopenMainFrame, "Reopen main frame");
            popup.AppendSeparator();
            popup.Append((int)MyFrame.Cmd.ChooseColour, "&Choose Colour");
            popup.AppendSeparator();
            popup.Append((int)MyFrame.Cmd.ChooseFont, "Choose &Font");
            popup.AppendSeparator();
            popup.Append((int)MyFrame.Cmd.LogDialog, "&Log dialog\tCtrl-L");
            popup.Append((int)MyFrame.Cmd.MessageBox, "&Message Box\tCtrl-M");
            popup.Append((int)MyFrame.Cmd.TextEntry, "Text &entry\tCtrl-E");
            popup.Append((int)MyFrame.Cmd.PasswordEntry, "&Password entry\tCtrl-P");
            popup.Append((int)MyFrame.Cmd.NumEntry, "&Numeric entry\tCtrl-N");
            popup.Append((int)MyFrame.Cmd.SingleChoice, "&Single choice\tCtrl-C");
            popup.Append((int)MyFrame.Cmd.MultiChoice, "M&ultiple choice\tCtrl-U");
            popup.AppendSeparator();
            popup.Append((int)MyFrame.Cmd.Tip, "&Tip of the day\tCtrl-T");
            popup.AppendSeparator();
            popup.Append((int)MyFrame.Cmd.FileOpen, "&Open file\tCtrl-O");
            popup.Append((int)MyFrame.Cmd.FileOpen2, "&Second open file\tCtrl-2");
            popup.Append((int)MyFrame.Cmd.FilesOpen, "Open &files\tCtrl-Q");
            popup.Append((int)MyFrame.Cmd.FileSave, "Sa&ve file\tCtrl-S");
            popup.Append((int)MyFrame.Cmd.DirChoose, "Choose &Directory\tCtrl-D");
            popup.Append((int)MyFrame.Cmd.Progress, "Pro&gress dialog\tCtrl-G");
            popup.Append((int)MyFrame.Cmd.Busyinfo, "&Busy info dialog\tCtrl-B");
            popup.AppendSeparator();
            popup.Append((int)MyFrame.Cmd.Exit, "E&xit\tAlt-X");

            EVT_MENU((int)MyFrame.Cmd.ReopenMainFrame, EventStub.CreateEventListener(this, "OnReopenMainFrame"));

            EVT_MENU((int)MyFrame.Cmd.ChooseColour, EventStub.CreateEventListener(this, "OnChooseColour"));
            EVT_MENU((int)MyFrame.Cmd.ChooseFont, EventStub.CreateEventListener(this, "OnChooseFont"));

            EVT_MENU((int)MyFrame.Cmd.DirChoose, EventStub.CreateEventListener(this, "OnDirChoose"));

            EVT_MENU((int)MyFrame.Cmd.LogDialog, EventStub.CreateEventListener(this, "OnLogDialog"));
            EVT_MENU((int)MyFrame.Cmd.MessageBox, EventStub.CreateEventListener(this, "OnMessageBox"));
            EVT_MENU((int)MyFrame.Cmd.TextEntry, EventStub.CreateEventListener(this, "OnTextEntry"));
            EVT_MENU((int)MyFrame.Cmd.PasswordEntry, EventStub.CreateEventListener(this, "OnPasswordEntry"));
            EVT_MENU((int)MyFrame.Cmd.NumEntry, EventStub.CreateEventListener(this, "OnNumericEntry"));
            EVT_MENU((int)MyFrame.Cmd.SingleChoice, EventStub.CreateEventListener(this, "OnSingleChoice"));
            EVT_MENU((int)MyFrame.Cmd.MultiChoice, EventStub.CreateEventListener(this, "OnMultiChoice"));

            EVT_MENU((int)MyFrame.Cmd.Tip, EventStub.CreateEventListener(this, "OnTip"));

            EVT_MENU((int)MyFrame.Cmd.FileOpen, EventStub.CreateEventListener(this, "OnFileOpen"));
            EVT_MENU((int)MyFrame.Cmd.FileOpen2, EventStub.CreateEventListener(this, "OnFileOpen2"));
            EVT_MENU((int)MyFrame.Cmd.FilesOpen, EventStub.CreateEventListener(this, "OnFilesOpen"));
            EVT_MENU((int)MyFrame.Cmd.FileSave, EventStub.CreateEventListener(this, "OnFileSave"));
            EVT_MENU((int)MyFrame.Cmd.Progress, EventStub.CreateEventListener(this, "OnProgress"));
            EVT_MENU((int)MyFrame.Cmd.Busyinfo, EventStub.CreateEventListener(this, "OnBusyinfo"));
            EVT_MENU((int)MyFrame.Cmd.Find, EventStub.CreateEventListener(this, "OnFind"));
            EVT_MENU((int)MyFrame.Cmd.Replace, EventStub.CreateEventListener(this, "OnReplace"));
            EVT_MENU((int)MyFrame.Cmd.Modal, EventStub.CreateEventListener(this, "OnModal"));
            EVT_MENU((int)MyFrame.Cmd.Modeless, EventStub.CreateEventListener(this, "OnModeless"));

            EVT_MENU((int)MyFrame.Cmd.Exit, EventStub.CreateEventListener(this, "OnExit"));

            return popup;
        }

        void OnExit(object sender, Event evt)
        {
        }
    }

	public class MyFrame : Frame
	{
		public enum Cmd 
		{
			ChooseColour = 1, ChooseFont,
			MessageBox, SingleChoice, MultiChoice,
			TextEntry, PasswordEntry,
			FileOpen, FileOpen2, FilesOpen, FileSave,
			DirChoose, DirNewChoose,
			Tip, NumEntry, LogDialog,
			Modal, Modeless, ModelessBtn,
			Progress, Busyinfo,
			Find, Replace,
			Exit, Hide,

            ReopenMainFrame
		}

		// for FileOpen2
		public static string s_extDef;

		// for Find and Replace
		public FindReplaceData m_findData;
		public FindReplaceDialog m_dlgFind;
		public FindReplaceDialog m_dlgReplace;

		public MyModelessDialog m_dialog;

		private MyCanvas canvas;

        public MyTaskBarIcon m_taskBarIcon;

		//---------------------------------------------------------------------

        public MyFrame()
            : this("wxWidgets Dialogs Example", new Point(50, 50), new Size(450, 340))
        {
        }

		public MyFrame(string title, Point pos, Size size)
			: base(title, pos, size)
		{
			// Set the window icon
			this.Icon = new Icon("../Samples/Dialogs/mondrian.png");

			// Set up a menu
			Menu fileMenu = new Menu();
			fileMenu.Append((int)Cmd.ChooseColour,	"&Choose Colour");
			fileMenu.AppendSeparator();
			fileMenu.Append((int)Cmd.ChooseFont, 	"Choose &Font");
			fileMenu.AppendSeparator();
			fileMenu.Append((int)Cmd.LogDialog, 	"&Log dialog\tCtrl-L");
			fileMenu.Append((int)Cmd.MessageBox, 	"&Message Box\tCtrl-M");
			fileMenu.Append((int)Cmd.TextEntry, 	"Text &entry\tCtrl-E");
			fileMenu.Append((int)Cmd.PasswordEntry, 	"&Password entry\tCtrl-P");
			fileMenu.Append((int)Cmd.NumEntry, 		"&Numeric entry\tCtrl-N");
			fileMenu.Append((int)Cmd.SingleChoice, 	"&Single choice\tCtrl-C");
			fileMenu.Append((int)Cmd.MultiChoice, 	"M&ultiple choice\tCtrl-U");
			fileMenu.AppendSeparator();
			fileMenu.Append((int)Cmd.Tip,		"&Tip of the day\tCtrl-T");
			fileMenu.AppendSeparator();
			fileMenu.Append((int)Cmd.FileOpen, 		"&Open file\tCtrl-O");
			fileMenu.Append((int)Cmd.FileOpen2, 	"&Second open file\tCtrl-2");
			fileMenu.Append((int)Cmd.FilesOpen, 	"Open &files\tCtrl-3");
			fileMenu.Append((int)Cmd.FileSave, 		"Sa&ve file\tCtrl-S");
			fileMenu.Append((int)Cmd.DirChoose, 	"Choose &Directory\tCtrl-D");
			fileMenu.Append((int)Cmd.Progress, 		"Pro&gress dialog\tCtrl-G");
			fileMenu.Append((int)Cmd.Busyinfo, 		"&Busy info dialog\tCtrl-B");
			fileMenu.AppendCheckItem((int)Cmd.Find,	"&Find dialog\tCtrl-F", "");
			fileMenu.AppendCheckItem((int)Cmd.Replace,	"Find and &replace dialog\tShift-Ctrl-F", "");
			fileMenu.AppendSeparator();
			fileMenu.Append((int)Cmd.Modal,	"Mo&dal dialog\tCtrl-W");
			fileMenu.AppendCheckItem((int)Cmd.Modeless,	"Modeless &dialog\tCtrl-Z", "");

			fileMenu.AppendSeparator();
            fileMenu.Append((int)Cmd.Hide, "&Hide\tAlt-C");
            MenuItem exitItem=new MenuItem(fileMenu, Cmd.Exit, "E&xit\tAlt-X");
            fileMenu.Append(exitItem);

			MenuBar menuBar = new MenuBar();
			menuBar.Append(fileMenu, "&File");

			MenuBar = menuBar;

            this.AcceleratorTable = new AcceleratorTable(
                new AcceleratorEntry(AcceleratorEntry.AccelFlags.NORMAL, 'd', (int)Cmd.DirChoose),
                new AcceleratorEntry(AcceleratorEntry.AccelFlags.NORMAL, 'g', (int)Cmd.Progress),
                new AcceleratorEntry(AcceleratorEntry.AccelFlags.NORMAL, 'b', (int)Cmd.Busyinfo),
                new AcceleratorEntry(AcceleratorEntry.AccelFlags.CTRL, 'q', (int)Cmd.Exit, exitItem)
                );

			// Set up a status bar
			CreateStatusBar();

			// Create the canvas for drawing
			canvas = new MyCanvas(this);

			// Set up the event table
			EVT_MENU((int)Cmd.ChooseColour,     new EventListener(OnChooseColour));
			EVT_MENU((int)Cmd.ChooseFont,       new EventListener(OnChooseFont));

			EVT_MENU((int)Cmd.DirChoose,        new EventListener(OnDirChoose));

			EVT_MENU((int)Cmd.LogDialog,	new EventListener(OnLogDialog));
			EVT_MENU((int)Cmd.MessageBox,	new EventListener(OnMessageBox));
			EVT_MENU((int)Cmd.TextEntry,	new EventListener(OnTextEntry));
			EVT_MENU((int)Cmd.PasswordEntry,	new EventListener(OnPasswordEntry));
			EVT_MENU((int)Cmd.NumEntry,		new EventListener(OnNumericEntry));
			EVT_MENU((int)Cmd.SingleChoice,	new EventListener(OnSingleChoice));
			EVT_MENU((int)Cmd.MultiChoice,	new EventListener(OnMultiChoice));

			EVT_MENU((int)Cmd.Tip,		new EventListener(OnTip));

			EVT_MENU((int)Cmd.FileOpen,		new EventListener(OnFileOpen));
			EVT_MENU((int)Cmd.FileOpen2,	new EventListener(OnFileOpen2));
			EVT_MENU((int)Cmd.FilesOpen,	new EventListener(OnFilesOpen));
			EVT_MENU((int)Cmd.FileSave,		new EventListener(OnFileSave));
			EVT_MENU((int)Cmd.Progress,		new EventListener(OnProgress));
			EVT_MENU((int)Cmd.Busyinfo,		new EventListener(OnBusyinfo));
			EVT_MENU((int)Cmd.Find,		new EventListener(OnFind));
			EVT_MENU((int)Cmd.Replace,		new EventListener(OnReplace));
			EVT_MENU((int)Cmd.Modal,		new EventListener(OnModal));
			EVT_MENU((int)Cmd.Modeless,		new EventListener(OnModeless));

			EVT_FIND(-1,			new EventListener(OnFindEvent));
			EVT_FIND_NEXT(-1,			new EventListener(OnFindEvent));
			EVT_FIND_REPLACE(-1,		new EventListener(OnFindEvent));
			EVT_FIND_REPLACE_ALL(-1,		new EventListener(OnFindEvent));
			EVT_FIND_CLOSE(-1,			new EventListener(OnFindEvent));

            EVT_MENU((int)Cmd.Hide, new EventListener(OnHide));
            EVT_MENU((int)Cmd.Exit, new EventListener(OnExit));

			m_findData = new FindReplaceData();
		}

		//---------------------------------------------------------------------

		public void OnChooseColour(object sender, Event e)
		{
            if (!this.IsShown)
                this.Show(true);

			ColourData data = new ColourData();

			data.Colour = canvas.BackgroundColour;
			data.ChooseFull = true;

			for(int i = 0; i < 16; i++) 
			{
				byte rgb = (byte)(i * 16);
				Colour col = new Colour(rgb, rgb, rgb);
				data.SetCustomColour(i, col);
			}

			ColourDialog cd = new ColourDialog(this, data);
			cd.Title = "Choose the background colour";

            if (cd.ShowModal() == wx.ShowModalResult.OK) 
			{
				canvas.BackgroundColour = cd.ColourData.Colour;
				//canvas.Clear();
				canvas.Refresh();
			}
		}

		public void OnChooseFont(object sender, Event e)
		{
            if (!this.IsShown)
                this.Show(true);

            FontData data = new FontData();
			data.InitialFont = canvas.font;
			data.Colour = canvas.textColour;

			FontDialog fd = new FontDialog(this, data);

            if (fd.ShowModal() == wx.ShowModalResult.OK) 
			{
				canvas.font = fd.FontData.ChosenFont;
				canvas.textColour = fd.FontData.Colour;
				canvas.Refresh();
			}
		}

		public void OnDirChoose(object sender, Event e)
		{
            if (!this.IsShown)
                this.Show(true);
            
            string dirHome = Directory.GetCurrentDirectory();
			DirDialog dlg = new DirDialog(this, "Testing directory picker",
				dirHome);

            if (dlg.ShowModal() == wx.ShowModalResult.OK) 
			{
				Log.LogMessage("Selected path: " + dlg.Path);
			}
		}

		public void OnLogDialog(object sender, Event e)
		{
            if (!this.IsShown)
                this.Show(true);

            using (BusyCursor bc = new BusyCursor())
            {
                Log.LogMessage("This is some message - everything is ok so far.");
                Log.LogMessage("Another message...\n... this one is on multiple lines");
                Log.LogWarning("And then something went wrong!");

                //Utils.wxYield();
            }

			Log.LogError("Intermediary error handler decided to abort.");
			Log.LogError("The top level caller detected an unrecoverable error.");

			Log.FlushActive();

			Log.LogMessage("And this is the same dialog but with only one message.");
		}

		public void OnMessageBox(object sender, Event e)
		{
            if (!this.IsShown)
                this.Show(true);
            MessageDialog md = new MessageDialog(this, "This is a message box\nA long, long string to test out the message box properly",
				"Message box text", wx.WindowStyles.DIALOG_NO_DEFAULT|wx.WindowStyles.DIALOG_YES_NO|wx.WindowStyles.DIALOG_CANCEL|wx.WindowStyles.ICON_INFORMATION);

			switch (md.ShowModal())
			{
                case wx.ShowModalResult.YES: Log.LogStatus("You pressed \"Yes\"");
					break;
                case wx.ShowModalResult.NO: Log.LogStatus("You pressed \"No\"");
					break;
                case wx.ShowModalResult.CANCEL: Log.LogStatus("You pressed \"Cancel\"");
					break;
				default:			Log.LogStatus("Unexpected wxMessageDialog return code!");
					break;
			}
		}

		public void OnTextEntry(object sender, Event e)
		{
            if (!this.IsShown)
                this.Show(true);
            TextEntryDialog ted = new TextEntryDialog(this,
				"This is a small sample\n" +
				"A long, long string to test out the text entrybox",
				"Please enter a string",
				"Default value",
				wx.WindowStyles.DIALOG_OK | wx.WindowStyles.DIALOG_CANCEL);

            if (ted.ShowModal() == wx.ShowModalResult.OK)
			{
				MessageDialog md = new MessageDialog(this, ted.Value, "Got string");
				md.ShowModal();
			}
		}

		public void OnPasswordEntry(object sender, Event e)
		{
            if (!this.IsShown)
                this.Show(true);
            string pwd = new GetPasswordFromUser("Enter password:",
				"Password entry dialog",
				"",
				this);

			if (pwd.Length > 0)
			{
				MessageDialog md = new MessageDialog(this, "Your password is "+pwd, "Got password");
				md.ShowModal();
			}
		}

		public void OnNumericEntry(object sender, Event e)
		{
            if (!this.IsShown)
                this.Show(true);
            int res = GetNumberFromUser("This is some text, actually a lot of text.\n" +
				"Even two rows of text.",
				"Enter a number:",
				"Numeric input test",
				50, 0, 100, this );

			string msg;
			wx.WindowStyles icon;
			if ( res == -1 )
			{
				msg = "Invalid number entered or dialog cancelled.";
				icon = wx.WindowStyles.ICON_HAND;
			}
			else
			{
				msg = "You've entered " + res;
				icon = wx.WindowStyles.ICON_INFORMATION;
			}

			MessageDialog md = new MessageDialog(this, msg, "Numeric test result", wx.WindowStyles.DIALOG_OK | icon);
			md.ShowModal();
		}

		public void OnSingleChoice(object sender, Event e)
		{
            if (!this.IsShown)
                this.Show(true);

            string[] choices = { "One", "Two", "Three", "Four", "Five" };

			SingleChoiceDialog scd = new SingleChoiceDialog(this,"This is a small sample\n" +
				"A single-choice dialog",
				"Please select a value",
				choices);
			scd.SetSelection(2);

            if (scd.ShowModal() == wx.ShowModalResult.OK)
			{
				MessageDialog md = new MessageDialog(this, scd.GetStringSelection(), "Got string");
				md.ShowModal();
			}
		}

		public void OnMultiChoice(object sender, Event e)
		{
            if (!this.IsShown)
                this.Show(true);

            // OnMultiChoice uses MultiChoiceDialog instead of GetMultipleChoices which isn't implemented yet
			string[] choices = new string[] {
														  "One", "Two", "Three", "Four", "Five",
														  "Six", "Seven", "Eight", "Nine", "Ten",
														  "Eleven", "Twelve", "Seventeen" };

			MultiChoiceDialog mcd = new MultiChoiceDialog(this, "This is a small sample\n" +
				"A multi-choice convenience dialog",
				"Please select a value",
				choices);
            if (mcd.ShowModal() == wx.ShowModalResult.OK)
			{
				int[] selections = mcd.GetSelections();
				int count = selections.Length;
				string msg;
				msg = "You selected " + count + " items:\n";
				for (int n = 0; n < count; n++)
				{
					msg += "\t" + n + ": " + selections[n] + " (" + choices[selections[n]] + ")\n";
				}

				MessageDialog md = new MessageDialog(this, msg, "Information");
				md.ShowModal();
			}

		}

		static int s_tipIndex=-1;
		public void OnTip(object sender, Event e)
		{
            if (!this.IsShown)
                this.Show(true);

			if (s_tipIndex < 0)
				s_tipIndex=new Random().Next(5);
			else
				s_tipIndex=(s_tipIndex+1)%5;
			TipProvider.CreateFileTipProvider("../Samples/Dialogs/tips.txt", s_tipIndex);

			bool showAtStartup = TipProvider.ShowTip(this);
			if ( showAtStartup )
			{
				wx.MessageDialog.ShowModal(this, "Will show tips on startup", "Tips dialog",
					wx.WindowStyles.DIALOG_OK | wx.WindowStyles.ICON_INFORMATION);
			}

			// does nothing, only for example
			int s_index = TipProvider.CurrentTip;
		}

		public void OnFileOpen(object sender, Event e)
		{
            if (!this.IsShown)
                this.Show(true);

            FileDialog fd = new FileDialog(this,
				"Testing open file dialog",
				"",
				"",
				"cs files (*.cs)|*.cs");

			fd.Directory = Utils.GetHomeDir();

            if (fd.ShowModal() == wx.ShowModalResult.OK)
			{
				string info = "Full file name: " + fd.Path + "\n" +
					"Path: " + fd.Directory + "\n" +
					"Name: " + fd.Filename;
				MessageDialog md = new MessageDialog(this, info, "Selected file");
				md.ShowModal();
			}
		}

		public void OnFileOpen2(object sender, Event e)
		{
            if (!this.IsShown)
                this.Show(true);

            string path = new FileSelector("Select the file to load",
				"", "", s_extDef,
				"Waveform (*.wav)|*.wav|Plain text (*.txt)|*.txt|All files (*.*)|*.*",
				wx.WindowStyles.FD_CHANGE_DIR,
				this );
			if (path.Length == 0) return;

			s_extDef = path.Substring(path.LastIndexOf(".") + 1);

			MessageDialog md = new MessageDialog(this,
				"You selected the file '" + path +
				"', remembered extension '" + s_extDef + "'",
				"FileOpen2");
			md.ShowModal();
		}

		public void OnFilesOpen(object sender, Event e)
		{
            if (!this.IsShown)
                this.Show(true);

            FileDialog fd = new FileDialog(this,
				"Testing open multiple file dialog",
				"", "", "*",
				wx.WindowStyles.FD_MULTIPLE);

            if (fd.ShowModal() == wx.ShowModalResult.OK)
			{
				string[] paths, filenames;
				paths = fd.Paths;
				filenames = fd.Filenames;

				string msg = "";
				for (int n = 0; n < paths.Length; n++)
				{
					msg += "File " + n + ": " + paths[n] + " " +
						" (" + filenames[n] + ")\n";
				}

				MessageDialog md = new MessageDialog(this, msg, "Selected files");
				md.ShowModal();
			}
		}

		public void OnFileSave(object sender, Event e)
		{
            if (!this.IsShown)
                this.Show(true);

            FileDialog fd = new FileDialog(this,
				"Testing save file dialog",
				"",
				"myletter.doc",
				"Text files (*.txt)|*.txt|Document files (*.doc)|*.doc",
				wx.WindowStyles.FD_SAVE | wx.WindowStyles.FD_OVERWRITE_PROMPT);

			fd.FilterIndex = 1;

            if (fd.ShowModal() == wx.ShowModalResult.OK)
			{
				MessageDialog md = new MessageDialog(this, fd.Path + ", filter " + fd.FilterIndex, "FileSave");
				md.ShowModal();
			}
		}

		public void OnProgress(object sender, Event e)
		{
            if (!this.IsShown)
                this.Show(true);

            int max = 10;

			ProgressDialog pd = new ProgressDialog(
				"Progress dialog example",
				"An informative message",
				max,
				this,
                wx.WindowStyles.PD_CAN_ABORT |
                wx.WindowStyles.PD_APP_MODAL |
                // wx.WindowStyles.PD_AUTO_HIDE | -- try this as well
                wx.WindowStyles.PD_ELAPSED_TIME |
                wx.WindowStyles.PD_ESTIMATED_TIME |
                wx.WindowStyles.PD_REMAINING_TIME);

			bool cont = true;
			for ( int i = 0; i <= max; i++)
			{
				System.Threading.Thread.Sleep(1000);
				if ( i == max )
				{
					cont = pd.Update(i, "That's all, folks!");
				}
				else if ( i == max / 2 )
				{
					cont = pd.Update(i, "Only a half left (very long message)!");
				}
				else
				{
					cont = pd.Update(i);
				}
				if ( !cont )
				{
					MessageDialog md = new MessageDialog(this,
						"Do you really want to cancel?",
						"Progress dialog question",
						wx.WindowStyles.DIALOG_YES_NO | wx.WindowStyles.ICON_QUESTION);
                    if (md.ShowModal() == wx.ShowModalResult.YES)
					{
						// use Dispose() or Show(false) to close the ProgressDialog
						// otherwise the dialog won't get closed and the app hangs
						//pd.Dispose();
						pd.Show(false);					
						break;
					}
					pd.Resume();
				}
			}
		
			pd.Dispose();
		}

		public void OnBusyinfo(object sender, Event e)
		{
            if (!this.IsShown)
                this.Show(true);

            WindowDisabler disableAll = new WindowDisabler();

			BusyInfo info = new BusyInfo("Working, please wait...", this);

			for ( int i = 0; i < 18; i++ )
			{
				App.GetApp().Yield();
				// or Utils.wxYield();
			}

			System.Threading.Thread.Sleep(1500);

			// how can this be done automatically ???
			disableAll.Dispose();
			info.Dispose();
		}

		public void OnFind(object sender, Event e)
		{
			m_dlgFind = new FindReplaceDialog(
				this,
				m_findData,
				"Find Dialog",
				wx.WindowStyles.FR_NOWHOLEWORD);
			m_dlgFind.Show(true);
		}

		public void OnReplace(object sender, Event e)
		{
			m_dlgReplace = new FindReplaceDialog(
				this,
				m_findData,
				"Find and replace dialog",
				wx.WindowStyles.FR_REPLACEDIALOG);
			m_dlgReplace.Show(true);
		}

        public string DecodeFindDialogEventFlags(wx.FindReplaceFlags flags)
		{
			string 	str = (((flags & wx.FindReplaceFlags.DOWN) != 0) ? "down" : "up") + ", " +
				(((flags & wx.FindReplaceFlags.WHOLEWORD) != 0) ? "whole words only, " : "") +
				(((flags & wx.FindReplaceFlags.MATCHCASE) != 0) ? "" : "not ") +
				"case sensitive";

			return str;
		}

		public void OnFindEvent(object sender, Event e)
		{
			FindDialogEvent fre= (FindDialogEvent)e;
			int etype = fre.EventType;

			if ( etype == Event.wxEVT_COMMAND_FIND   || etype == Event.wxEVT_COMMAND_FIND_NEXT )
			{
				Log.LogMessage("Find {0}'{1}' (flags: {2})",
					etype == Event.wxEVT_COMMAND_FIND_NEXT ? "next " : "",
					fre.FindString,
					DecodeFindDialogEventFlags(fre.Flags));
			}
			else if ( etype == Event.wxEVT_COMMAND_FIND_REPLACE ||
				etype == Event.wxEVT_COMMAND_FIND_REPLACE_ALL )
			{
				Log.LogMessage("Replace {0}'{1}' with '{2}' (flags: {3})",
					etype == Event.wxEVT_COMMAND_FIND_REPLACE_ALL ? "all " : "",
					fre.FindString,
					fre.ReplaceString,
					DecodeFindDialogEventFlags(fre.Flags));
			}
			else if ( etype == Event.wxEVT_COMMAND_FIND_CLOSE )
			{
				FindReplaceDialog dlg = fre.Dialog;

				int idMenu;
				string txt;
				if ( dlg == m_dlgFind )
				{
					txt = "Find";
					idMenu = (int)Cmd.Find;
					m_dlgFind = null;
				}
				else if ( dlg == m_dlgReplace )
				{
					txt = "Replace";
					idMenu = (int)Cmd.Replace;
					m_dlgReplace = null;
				}
				else
				{
					txt = "Unknown";
					idMenu = -1;

					// wxFAIL_MSG...
					Log.LogError("unexpected event");
				}

				Log.LogMessage("{0} dialog is being closed.", txt);

				if ( idMenu != -1 )
				{
					MenuBar.Check(idMenu, false);
				}

				dlg.Destroy();
			}
			else
			{
				Log.LogError("Unknown find dialog event!");
			}
		}

		public void OnModal(object sender, Event e)
		{
			MyModalDialog dlg = new MyModalDialog(this);
			dlg.ShowModal();
		}

		public void OnModeless(object sender, Event e)
		{
			CommandEvent ce = (CommandEvent) e;
			bool show = MenuBar.IsChecked(ce.ID);

			if ( show )
			{
				m_dialog = new MyModelessDialog(this);
				m_dialog.Show(true);
			}
			else
			{
				m_dialog.Hide();
			}
		}

		//---------------------------------------------------------------------

        public void OnReopenMainFrame(object sender, Event evt)
        {
            if (this.Iconized)
                this.Iconized = false;
            else if (this.IsShown)
                this.Raise();
            else
                this.Show(true);
        }

        public void OnHide(object sender, Event e)
        {
            this.Show(false);
        }


        /** Since 
         */
		public void OnExit(object sender, Event e)
		{
            if (this.m_taskBarIcon != null)
            {
                this.m_taskBarIcon.RemoveIcon();
            }
            if (this.IsShown) // The GTK-Version does not like to be closed if already hidden.
               Close(true);
            Utils.Exit(); // this currently seems to be necessary in order to exit the application.
                         // since task bar is used.
		}

		//---------------------------------------------------------------------
	}

	public class MyCanvas : ScrolledWindow
	{
		public Font font;
		public Colour textColour;

		public MyCanvas(Window parent)
			: base(parent)
		{
			font = Font.wxNORMAL_FONT;
			textColour = new Colour(0, 0, 0);
			
			EVT_PAINT(new EventListener(OnPaint));
		}

		public void OnPaint(object sender, Event e)
		{
			PaintDC dc = new PaintDC(this);
			dc.Font = font;
			dc.TextForeground = textColour;
            dc.BackgroundMode = DCBackgroundMode.TRANSPARENT;
			dc.DrawText("wxWidgets common dialogs test application", 10, 10);
			dc.Dispose(); //needed
		}
	}

	//---------------------------------------------------------------------

	public class MyModelessDialog : Dialog
	{
		enum Id 
		{
			DIALOG_MODELESS_BTN = 1
		}

		public MyModelessDialog(Window parent)
			: base(parent, -1, "Modeless dialog")
		{
			BoxSizer sizerTop = new BoxSizer(Orientation.wxVERTICAL);

			Button btn = new Button(this, (int)Id.DIALOG_MODELESS_BTN, "Press me");
			CheckBox check = new CheckBox(this, -1, "Should be disabled");
			check.Disable();

			sizerTop.Add(btn, 1, wx.SizerFlag.wxEXPAND | wx.SizerFlag.wxALL, 5);
			sizerTop.Add(check, 1, wx.SizerFlag.wxEXPAND | wx.SizerFlag.wxALL, 5);

			AutoLayout = true;
			SetSizer(sizerTop);

			sizerTop.SetSizeHints(this);
			sizerTop.Fit(this);

			EVT_BUTTON((int)Id.DIALOG_MODELESS_BTN, new EventListener(OnButton));
			EVT_CLOSE(new EventListener(OnClose));
		}

		public void OnButton(object sender, Event e)
		{
			wx.MessageDialog.ShowModal(this, "Button pressed in modeless dialog", "Info",
				wx.WindowStyles.DIALOG_OK | wx.WindowStyles.ICON_INFORMATION);
		}

		public void OnClose(object sender, Event e)
		{
			// must add CloseEvent...
			// must add Event.Veto
		}
	}

	//---------------------------------------------------------------------

	public class MyModalDialog : Dialog
	{
		public Button m_btnFocused;
		public Button m_btnDelete;

		public MyModalDialog(Window parent)
			: base(parent, -1, "Modal dialog")
		{
			BoxSizer sizerTop = new BoxSizer(Orientation.wxHORIZONTAL);

			m_btnFocused = new Button(this, -1, "Default button");
			m_btnDelete = new Button(this, -1, "&Delete button");
			Button btnOk = new Button(this, wxID_CANCEL, "&Close");
			sizerTop.Add(m_btnFocused, 0, wx.SizerFlag.wxALIGN_CENTER | wx.SizerFlag.wxALL, 5);
			sizerTop.Add(m_btnDelete, 0, wx.SizerFlag.wxALIGN_CENTER | wx.SizerFlag.wxALL, 5);
			sizerTop.Add(btnOk, 0, wx.SizerFlag.wxALIGN_CENTER | wx.SizerFlag.wxALL, 5);

			AutoLayout = true;
			SetSizer(sizerTop);

			sizerTop.SetSizeHints(this);
			sizerTop.Fit(this);

			m_btnFocused.SetFocus();
			m_btnFocused.SetDefault();

			EVT_BUTTON(-1, new EventListener(OnButton));
		}

		public void OnButton(object sender, Event e)
		{
			CommandEvent ce = (CommandEvent) e;

			if ( ce.EventObject == m_btnDelete )
			{
				//m_btnFocused = null;
				m_btnDelete.Disable();
				m_btnFocused.Hide();
			}
			else if (ce.EventObject == m_btnFocused )
			{
				new GetTextFromUser("Dummy prompt",
					"Modal dialog called from dialog",
					"", this);
			}
			else
			{
				e.Skip();
			}
		}
	}

	public class Dialogs : App
	{
		//---------------------------------------------------------------------

		public override bool OnInit()
		{
			MyFrame frame = new MyFrame();
            frame.m_taskBarIcon = new MyTaskBarIcon(frame);
			frame.Show(true);

			return true;
		}

		//---------------------------------------------------------------------

		[STAThread]
		static void Main()
		{
			Dialogs app = new Dialogs();
			app.Run();
		}

		//---------------------------------------------------------------------
	}
}
