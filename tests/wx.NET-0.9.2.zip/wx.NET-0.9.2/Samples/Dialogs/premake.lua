-- Premake script for the wx.NET "Dialogs" sample.
-- See http://premake.sourceforge.net/ for more info about Premake.

package.name     = "Dialogs"
package.language = "c#"
package.kind     = "winexe"
package.target   = "dialogs"
project.bindir   = "../Bin"

package.links    = { "System.Drawing", "wx.NET" }

package.files    = { "Dialogs.cs" }
