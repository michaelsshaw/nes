-- Premake script for the wx.NET "EventDemo" sample.
-- See http://premake.sourceforge.net/ for more info about Premake.

package.name     = "EventDemo"
package.language = "c#"
package.kind     = "winexe"
package.target   = "eventdemo"
project.bindir   = "../Bin"

package.links    = { "System.Drawing", "wx.NET" }

package.files    = { "EventDemo.cs" }
