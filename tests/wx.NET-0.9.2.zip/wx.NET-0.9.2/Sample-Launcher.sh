#!/bin/bash

dir=`dirname $0`
cd $dir/Bin
exec mono launcher.exe
