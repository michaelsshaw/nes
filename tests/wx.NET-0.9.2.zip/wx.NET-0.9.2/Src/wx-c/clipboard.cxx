//-----------------------------------------------------------------------------
// wx.NET - clipboard.cxx
//
// The wxClipBoard proxy interface.
//
// Written by Bryan Bulten (bryan@bulten.ca)
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: clipboard.cxx,v 1.10 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/clipbrd.h>

#include "local_events.h"

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxClipboard*)
  wxClipboard_ctor()
{
	return WXNET_NEW(wxClipboard, ());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxClipboard_Open(wxClipboard* self)
{
    return self->Open()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxClipboard_Close(wxClipboard* self)
{
    self->Close();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxClipboard_IsOpened(wxClipboard* self)
{
    return self->IsOpened()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxClipboard_AddData(wxClipboard* self, wxDataObject* data)
{
    return self->AddData(data)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxClipboard_SetData(wxClipboard* self, wxDataObject* data)
{
    return self->SetData(data)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxClipboard_IsSupported(wxClipboard* self, wxDataFormat* format)
{
    return self->IsSupported(*format)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxClipboard_GetData(wxClipboard* self, wxDataObject* data)
{
    return self->GetData(*data)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxClipboard_Clear(wxClipboard* self)
{
    self->Clear();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxClipboard_Flush(wxClipboard* self)
{
    return self->Flush()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxClipboard_UsePrimarySelection(wxClipboard* self, bool primary)
{
	self->UsePrimarySelection(primary);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxClipboard*)
  wxTheClipboard_static()
{
	return wxTheClipboard;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxClipboardLocker*)
  wxClipBoardLocker_ctor(wxClipboard* clipboard)
{
	return WXNET_NEW(wxClipboardLocker, (clipboard));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxClipBoardLocker_dtor(wxClipboardLocker* self)
{
	WXNET_DEL(self);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxClipboardLocker_IsOpen(wxClipboardLocker* self)
{
	return !(*self)?1:0;
}
