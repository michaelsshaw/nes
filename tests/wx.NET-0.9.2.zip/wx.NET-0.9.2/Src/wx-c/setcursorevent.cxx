//-----------------------------------------------------------------------------
// wx.NET - setcursorevent.cxx
// 
// The wxSetCursorEvent proxy interface.
//
// Written by Alexander Olk (xenomorph2@onlinehome.de)
// (C) 2004 by Alexander Olk
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: setcursorevent.cxx,v 1.3 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include "wxnet_globals.h"

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxSetCursorEvent*)
  wxSetCursorEvent_ctor(wxEventType type)
{
    return new wxSetCursorEvent(type);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxSetCursorEvent_GetX(wxSetCursorEvent* self)
{
	return self->GetX();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxSetCursorEvent_GetY(wxSetCursorEvent* self)
{
	return self->GetY();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxSetCursorEvent_SetCursor(wxSetCursorEvent* self, wxCursor* cursor)
{
	self->SetCursor(*cursor);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxCursor*)
  wxSetCursorEvent_GetCursor(wxSetCursorEvent* self)
{
	return new wxCursor(self->GetCursor());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxSetCursorEvent_HasCursor(wxSetCursorEvent* self)
{
	return self->HasCursor()?1:0;
}

