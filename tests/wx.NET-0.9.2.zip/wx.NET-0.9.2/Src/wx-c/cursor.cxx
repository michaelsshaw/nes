//-----------------------------------------------------------------------------
// wx.NET - cursor.cxx
//
// The wxCursor proxy interface.
//
// Written by Jason Perkins (jason@379.com)
// (C) 2003 by 379, Inc.
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: cursor.cxx,v 1.6 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#ifndef WXNET_GLOBAL_H
#include "wxnet_globals.h"
#endif

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxCursor*)
  wxCursor_ctorImage(wxImage* image)

{
	return new wxCursor(*image);
}

WXNET_EXPORT(wxCursor*)
  wxCursor_ctorCopy(wxCursor* cursor)
{
	return new wxCursor(*cursor);
}

WXNET_EXPORT(wxCursor*)
  wxCursor_ctorById(int id)
{
	return new wxCursor(id);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxCursor_Ok(wxCursor* self)
{
	return self->Ok()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxCursor_SetCursor(const wxCursor* cursor)
{
	wxSetCursor(*cursor);
}
