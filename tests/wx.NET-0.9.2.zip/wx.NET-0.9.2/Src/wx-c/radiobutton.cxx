//-----------------------------------------------------------------------------
// wx.NET - radiobutton.cxx
//
// The wxRadioButton proxy interface
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 by Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: radiobutton.cxx,v 1.10 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/radiobut.h>
#include "local_events.h"

//-----------------------------------------------------------------------------

class _RadioButton : public wxRadioButton
{
public:
    DECLARE_OBJECTDELETED(_RadioButton)
};

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxRadioButton*)
  wxRadioButton_ctor()
{
	return new _RadioButton();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxRadioButton_Create(wxRadioButton* self, wxWindow* parent, int id,
                       const wxString* labelArg, int posX, int posY,
                       int width, int height, unsigned int style, const wxValidator* val,
                       const wxString* nameArg)
{
	if (val == NULL)
		val = &wxDefaultValidator;

   wxString name;
	if (nameArg == NULL)
		name = wxT("radioButton");
   else
      name=*nameArg;
   wxString label;
   if (labelArg)
      label=*labelArg;

	return self->Create(parent, id, label, wxPoint(posX, posY), wxSize(width, height), style,
	                    *val, name);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxRadioButton_GetValue(wxRadioButton* self)
{
	return self->GetValue();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxRadioButton_SetValue(wxRadioButton* self, bool state)
{
	self->SetValue(state);
}

//-----------------------------------------------------------------------------
