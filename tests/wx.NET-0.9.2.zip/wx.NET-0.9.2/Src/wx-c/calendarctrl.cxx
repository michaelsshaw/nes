//-----------------------------------------------------------------------------
// wx.NET - calendarctrl.cxx
//
// The wxCalendarCtrl proxy interface.
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 by Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: calendarctrl.cxx,v 1.14 2008/12/27 13:05:57 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/calctrl.h>
#include "local_events.h"

//-----------------------------------------------------------------------------

class _CalendarCtrl : public wxCalendarCtrl
{
public:
    DECLARE_OBJECTDELETED(_CalendarCtrl)
};

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxCalendarCtrl*)
  wxCalendarCtrl_ctor()
{
    return new _CalendarCtrl();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxCalendarCtrl_Create(wxCalendarCtrl* self, wxWindow* parent, wxWindowID id, const wxDateTime* date, int x, int y, int w, int h, unsigned int style, const wxString* nameArg)
{
   wxString name;
   if (nameArg == NULL)
        name = wxT("calendarCtrl");
   else
      name=*nameArg;

    return self->Create(parent, id, *date, wxPoint(x, y), wxSize(w, h), style, name)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxCalendarCtrl_SetDate(wxCalendarCtrl* self, wxDateTime* date)
{
    return self->SetDate(*date)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxDateTime*)
  wxCalendarCtrl_GetDate(wxCalendarCtrl* self)
{
    return new wxDateTime(self->GetDate());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxCalendarCtrl_SetLowerDateLimit(wxCalendarCtrl* self, wxDateTime* date)
{
    return self->SetLowerDateLimit(*date)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxDateTime*)
  wxCalendarCtrl_GetLowerDateLimit(wxCalendarCtrl* self)
{
    return new wxDateTime(self->GetLowerDateLimit());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxCalendarCtrl_SetUpperDateLimit(wxCalendarCtrl* self, wxDateTime* date)
{
    return self->SetUpperDateLimit(*date)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxDateTime*)
  wxCalendarCtrl_GetUpperDateLimit(wxCalendarCtrl* self)
{
    return new wxDateTime(self->GetUpperDateLimit());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxCalendarCtrl_SetDateRange(wxCalendarCtrl* self, wxDateTime* lowerdate, wxDateTime* upperdate)
{
    return self->SetDateRange(*lowerdate, *upperdate)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxCalendarCtrl_EnableYearChange(wxCalendarCtrl* self, bool enable)
{
    self->EnableYearChange(enable);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxCalendarCtrl_EnableMonthChange(wxCalendarCtrl* self, bool enable)
{
    self->EnableMonthChange(enable);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxCalendarCtrl_EnableHolidayDisplay(wxCalendarCtrl* self, bool display)
{
    self->EnableHolidayDisplay(display);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxCalendarCtrl_SetHeaderColours(wxCalendarCtrl* self, wxColour* colFg, wxColour* colBg)
{
    self->SetHeaderColours(*colFg, *colBg);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxColour*)
  wxCalendarCtrl_GetHeaderColourFg(wxCalendarCtrl* self)
{
    return new wxColour(self->GetHeaderColourFg());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxColour*)
  wxCalendarCtrl_GetHeaderColourBg(wxCalendarCtrl* self)
{
    return new wxColour(self->GetHeaderColourBg());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxCalendarCtrl_SetHighlightColours(wxCalendarCtrl* self, wxColour* colFg, wxColour* colBg)
{
    self->SetHighlightColours(*colFg, *colBg);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxColour*)
  wxCalendarCtrl_GetHighlightColourFg(wxCalendarCtrl* self)
{
    return new wxColour(self->GetHighlightColourFg());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxColour*)
  wxCalendarCtrl_GetHighlightColourBg(wxCalendarCtrl* self)
{
    return new wxColour(self->GetHighlightColourBg());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxCalendarCtrl_SetHolidayColours(wxCalendarCtrl* self, wxColour* colFg, wxColour* colBg)
{
    self->SetHolidayColours(*colFg, *colBg);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxColour*)
  wxCalendarCtrl_GetHolidayColourFg(wxCalendarCtrl* self)
{
    return new wxColour(self->GetHolidayColourFg());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxColour*)
  wxCalendarCtrl_GetHolidayColourBg(wxCalendarCtrl* self)
{
    return new wxColour(self->GetHolidayColourBg());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxCalendarDateAttr*)
  wxCalendarCtrl_GetAttr(wxCalendarCtrl* self, int day)
{
    return self->GetAttr(day);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxCalendarCtrl_SetAttr(wxCalendarCtrl* self, int day, wxCalendarDateAttr* attr)
{
    self->SetAttr(day, attr);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxCalendarCtrl_SetHoliday(wxCalendarCtrl* self, int day)
{
    self->SetHoliday(day);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxCalendarCtrl_ResetAttr(wxCalendarCtrl* self, int day)
{
    self->ResetAttr(day);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxCalendarHitTestResult)
  wxCalendarCtrl_HitTest(wxCalendarCtrl* self, int x, int y, wxDateTime* date, wxDateTime::WeekDay *wd)
{
    return self->HitTest(wxPoint(x, y), date, wd);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxCalendarDateAttr*)
  wxCalendarDateAttr_ctor()
{
    return new wxCalendarDateAttr();
}

WXNET_EXPORT(void)
  wxCalendarDateAttr_dtor(wxCalendarDateAttr* self)
{
		WXNET_DEL( self );
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxCalendarDateAttr*)
  wxCalendarDateAttr_ctor2(wxColour* colText, wxColour* colBack, wxColour* colBorder, wxFont* fontArg, wxCalendarDateBorder border)
{
    if (colBorder == NULL)
        colBorder = &wxNullColour;
    if (colText == NULL)
        colText = &wxNullColour;
    if (colBack == NULL)
        colBack = &wxNullColour;
    wxFont font;
    if (fontArg)
       font=*fontArg;
    return new wxCalendarDateAttr(*colText, *colBack, *colBorder, font, border);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxCalendarDateAttr*)
  wxCalendarDateAttr_ctor3(wxCalendarDateBorder border, wxColour* colBorder)
{
    if (colBorder == NULL)
        colBorder = &wxNullColour;

    return new wxCalendarDateAttr(border, *colBorder);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxCalendarDateAttr_SetTextColour(wxCalendarDateAttr* self, wxColour* colText)
{
   if (self && colText)
    self->SetTextColour(*colText);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxCalendarDateAttr_SetBackgroundColour(wxCalendarDateAttr* self, wxColour* colBack)
{
   if (self && colBack)
    self->SetBackgroundColour(*colBack);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxCalendarDateAttr_SetBorderColour(wxCalendarDateAttr* self, wxColour* col)
{
   if (self && col)
    self->SetBorderColour(*col);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxCalendarDateAttr_SetFont(wxCalendarDateAttr* self, wxFont* font)
{
   if (self && font)
    self->SetFont(*font);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxCalendarDateAttr_SetBorder(wxCalendarDateAttr* self, wxCalendarDateBorder border)
{
   if (self)
    self->SetBorder(border);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxCalendarDateAttr_SetHoliday(wxCalendarDateAttr* self, bool holiday)
{
   if (self)
    self->SetHoliday(holiday);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxCalendarDateAttr_HasTextColour(wxCalendarDateAttr* self)
{
    return self->HasTextColour();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxCalendarDateAttr_HasBackgroundColour(wxCalendarDateAttr* self)
{
    return self->HasBackgroundColour();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxCalendarDateAttr_HasBorderColour(wxCalendarDateAttr* self)
{
    return self->HasBorderColour();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxCalendarDateAttr_HasFont(wxCalendarDateAttr* self)
{
    return self->HasFont();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxCalendarDateAttr_HasBorder(wxCalendarDateAttr* self)
{
    return self->HasBorder();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxCalendarDateAttr_IsHoliday(wxCalendarDateAttr* self)
{
    return self->IsHoliday();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxColour*)
  wxCalendarDateAttr_GetTextColour(wxCalendarDateAttr* self)
{
    return new wxColour(self->GetTextColour());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxColour*)
  wxCalendarDateAttr_GetBackgroundColour(wxCalendarDateAttr* self)
{
    return new wxColour(self->GetBackgroundColour());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxColour*)
  wxCalendarDateAttr_GetBorderColour(wxCalendarDateAttr* self)
{
    return new wxColour(self->GetBorderColour());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxFont*)
  wxCalendarDateAttr_GetFont(wxCalendarDateAttr* self)
{
    return new wxFont(self->GetFont());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxCalendarDateBorder)
  wxCalendarDateAttr_GetBorder(wxCalendarDateAttr* self)
{
    return self->GetBorder();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxDateTime*)
  wxDateEvent_GetDate(wxDateEvent* self)
{
    return new wxDateTime(self->GetDate());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxCalendarEvent*)
  wxCalendarEvent_ctor(wxCalendarCtrl* cal, wxEventType type)
{
    return new wxCalendarEvent(cal, type);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxDateTime::WeekDay)
  GetWeekDay(wxCalendarEvent* self)
{
    return self->GetWeekDay();
}

//-----------------------------------------------------------------------------

