//-----------------------------------------------------------------------------
// wx.NET - dialog.cxx
//
// The wxDialog proxy interface
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 by Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: dialog.cxx,v 1.19 2009/10/11 16:23:28 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/dialog.h>
#include "local_events.h"

//-----------------------------------------------------------------------------

class _Dialog : public wxDialog, public ValidatorStub
{
public:
    DECLARE_OBJECTDELETED(_Dialog)
    
    DECLARE_SETFOCUS_OVERRIDING(wxDialog)

#include "panel.inc"
};

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxDialog*)
  wxDialog_ctor()
{
	return new _Dialog();
}

WXNET_EXPORT(void)
  wxDialog_dtor(wxDialog* self)
{
	WXNET_DEL( self );
}

//-----------------------------------------------------------------------------

IMPLEMENT_SETFOCUS_OVERRIDING(_Dialog, wxDialog)

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxDialog_Create(wxDialog* self, wxWindow* parent, int id,
				     const wxString* titleArg, int posX, int posY, int width, int height,
					 int style, const wxString* nameArg)
{
   wxString title;
   if (titleArg!=NULL)
      title=*titleArg;
   wxString name;
   if (nameArg==NULL)
      name=wxT("dialogBox");
   else
      name=*nameArg;

	return self->Create(parent, id, title, wxPoint(posX, posY),
					    wxSize(width, height), style, name)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxSizer*)
 wxDialog_CreateButtonSizer(wxDialog* self, unsigned int flags)
{
    if (self)
        return self->CreateButtonSizer(flags);
    else 
        return NULL;
}

WXNET_EXPORT(wxSizer*)
 wxDialog_CreateSeparatedButtonSizer(wxDialog* self, unsigned int flags)
{
    if (self)
        return self->CreateSeparatedButtonSizer(flags);
    else 
        return NULL;
}

WXNET_EXPORT(wxSizer*)
 wxDialog_CreateStdDialogButtonSizer(wxDialog* self, unsigned int flags)
{
    if (self)
        return self->CreateButtonSizer(flags);
    else 
        return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxDialog_SetReturnCode(wxDialog* self, int returnCode)
{
	self->SetReturnCode(returnCode);
}

WXNET_EXPORT(int)
  wxDialog_GetReturnCode(wxDialog* self)
{
	return self->GetReturnCode();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxDialog_GetTitle(wxDialog* self)
{
	return new wxString(self->GetTitle());
}

WXNET_EXPORT(void)
  wxDialog_SetTitle(wxDialog* self, const wxString* title)
{
   if (self && title)
	   self->SetTitle(*title);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxDialog_EndModal(wxDialog* self, int retCode)
{
	self->EndModal(retCode);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxDialog_IsModal(wxDialog* self)
{
	return self->IsModal()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxDialog_SetIcon(wxDialog* self, wxIcon* icon)
{
	self->SetIcon(*icon);
}

WXNET_EXPORT(void)
  wxDialog_SetIcons(wxDialog* self, wxIconBundle* icons)
{
	self->SetIcons(*icons);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxDialog_ShowModal(wxDialog* self)
{
	return self->ShowModal();
}

//-----------------------------------------------------------------------------
