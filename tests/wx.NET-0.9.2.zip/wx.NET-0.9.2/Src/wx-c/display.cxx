//-----------------------------------------------------------------------------
// wx.NET -	display.cxx
// 
// Mike	Muegel mike _at_ muegel dot org
// Complete Revision Harald Meyer auf'm Hofe.
//
// Licensed	under the wxWidgets	license, see LICENSE.txt for details.
//
// $Id: display.cxx,v 1.12 2009/12/12 10:30:54 harald_meyer Exp $
//
//-----------------------------------------------------------------------------

#ifdef WXNET_DISPLAY

#include <wx/wx.h>
#include <wx/display.h>
#ifndef WXNET_GLOBAL_H
#include "wxnet_globals.h"
#endif

// CALLBACK MAY BE ALREADY DEFINED
#ifndef CALLBACK 
# if defined(_WINDOWS)
#  define CALLBACK __stdcall
# else
#  define CALLBACK
# endif
#endif

typedef void (CALLBACK* Virtual_OnDispose) (void);

//-----------------------------------------------------------------------------

// Encapsulate wxDisplay as a member. So, ~wxDisplay will be called on
// destroying instances of this class.
class _wxDisplay
{
public:
   wxDisplay _display;
   Virtual_OnDispose _onDispose;
   _wxDisplay(int index);
   virtual ~_wxDisplay();
};

_wxDisplay::_wxDisplay(int index) : _display(index), _onDispose(NULL)
{
}

_wxDisplay::~_wxDisplay()
{
	if (this->_onDispose) (this->_onDispose)();
}


//-----------------------------------------------------------------------------

WXNET_EXPORT(_wxDisplay*)
  wxDisplay_ctor(int index)
{
	return new _wxDisplay(index);
}

WXNET_EXPORT(void)
  wxDisplay_RegisterOnDispose(_wxDisplay* self, Virtual_OnDispose callback)
{
   if (self)
      self->_onDispose=callback;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)	wxDisplay_GetCount()
{
	return wxDisplay::GetCount();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)	wxDisplay_GetFromPoint(wxPoint*	pt)
{
	return wxDisplay::GetFromPoint(*pt);
}

//-----------------------------------------------------------------------------

// Only WIN32 supports GetFromWindow :-(
WXNET_EXPORT(int)	wxDisplay_GetFromWindow(wxWindow* window)
{
#ifdef __WXMSW__
	return wxDisplay::GetFromWindow(window);
#else
	return -1;
#endif
}

//-----------------------------------------------------------------------------


WXNET_EXPORT(void)
  wxDisplay_GetGeometry(_wxDisplay* self, int*x, int*y, int*w, int*h)
{
	if (self)
	{
		wxRect rect = self->_display.GetGeometry();
		if (x) (*x)=rect.GetX();
		if (y) (*y)=rect.GetY();
		if (w) (*w)=rect.GetWidth();
		if (h) (*h)=rect.GetHeight();
	}
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxDisplay_GetName(_wxDisplay* self)
{
	return new wxString(self->_display.GetName());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxDisplay_IsPrimary(_wxDisplay*	self)
{
	// If I just return IsPrimary() it always returns true. I thought
	// this had something to do with how it is defined:
	//   bool IsPrimary() const { return m_index == 0; }
	// The const causing problems with Interop? The version
	// below works.
	return self->_display.IsPrimary();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxDisplay_GetCurrentMode(_wxDisplay* self, int* width, int* height, int* bpp, int* refresh)
{
	wxVideoMode result=self->_display.GetCurrentMode();
	if (width) (*width)=result.w;
	if (height) (*height)=result.h;
	if (bpp) (*bpp)=result.bpp;
	if (refresh) (*refresh)=result.refresh;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int) wxArrayVideoModes_Count(const wxArrayVideoModes* self)
{
	if (self)
		return (int)self->Count();
	else
		return 0;
}

WXNET_EXPORT(void) wxArrayVideoModes_Item(const wxArrayVideoModes* self, int index, int* w, int*h, int* bpp, int* freq)
{
	if (self)
	{
		wxVideoMode result=(*self)[index];
		if (w) (*w)=result.w;
		if(h) (*h)=result.h;
		if (bpp) (*bpp)=result.bpp;
		if (freq) (*freq)=result.refresh;
	}
}

WXNET_EXPORT(void) wxArrayVideoModes_Delete(wxArrayVideoModes* self)
{
	if (self)
		delete self;
}


WXNET_EXPORT(wxArrayVideoModes*)
  wxDisplay_GetModes(_wxDisplay* self, wxVideoMode mode)
{
    return new wxArrayVideoModes(self->_display.GetModes(mode));
}


//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxDisplay_ChangeMode(_wxDisplay* self, const wxVideoMode mode)
{
	return self->_display.ChangeMode(mode)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxDisplay_ResetMode(_wxDisplay*	self)
{
	self->_display.ResetMode();
}

#endif

