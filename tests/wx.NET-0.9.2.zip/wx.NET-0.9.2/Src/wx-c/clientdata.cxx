//-----------------------------------------------------------------------------
// wx.NET - clientdata.cxx
//
// The wxClientData proxy interface
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 by Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: clientdata.cxx,v 1.10 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/textctrl.h>
#include "local_events.h"

//-----------------------------------------------------------------------------

class _ClientData : public wxClientData
{
public:
	_ClientData()
		: wxClientData() {}

	DECLARE_DISPOSABLE(_ClientData)
};

WXNET_EXPORT(wxClientData*)
  wxClientData_ctor()
{
    return new _ClientData();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxClientData_dtor(wxClientData* self)
{
	WXNET_DEL(self);
}

WXNET_EXPORT(void)
  wxClientData_RegisterDisposable(_ClientData* self, Virtual_Dispose onDispose)
{
	self->RegisterDispose(onDispose);
}

//-----------------------------------------------------------------------------
// wxStringClientData

WXNET_EXPORT(wxStringClientData*)
  wxStringClientData_ctor(const wxString* data)
{
   if (data)
	   return new wxStringClientData(*data);
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStringClientData_dtor(wxStringClientData* self)
{
	WXNET_DEL(self);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStringClientData_SetData(wxStringClientData* self, const wxString* data)
{
   if (self && data)
	   self->SetData(*data);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxStringClientData_GetData(wxStringClientData* self)
{
   if (self)
	   return new wxString(self->GetData());
   return 0;
}


