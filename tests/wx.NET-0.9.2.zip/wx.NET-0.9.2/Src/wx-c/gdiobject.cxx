//-----------------------------------------------------------------------------
// wx.NET - gdiobject.cxx
//
// The wxGDIObject proxy interface.
//
// Written by Jason Perkins (jason@379.com)
// (C) 2003 by 379, Inc.
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: gdiobject.cxx,v 1.8 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include "local_events.h"

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGDIObj_dtor(wxGDIObject* self)
{
	WXNET_DEL( self );
}


