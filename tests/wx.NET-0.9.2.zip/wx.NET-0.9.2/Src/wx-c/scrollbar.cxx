//-----------------------------------------------------------------------------
// wx.NET - scrolbar.h
// 
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: scrollbar.cxx,v 1.7 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/scrolbar.h>
#include "local_events.h"

//-----------------------------------------------------------------------------

class _ScrollBar : public wxScrollBar
{
public:
    DECLARE_OBJECTDELETED(_ScrollBar)
};

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxScrollBar*)
  wxScrollBar_ctor()
{
    return new _ScrollBar();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxScrollBar_Create(wxScrollBar* self, wxWindow* parent, wxWindowID id, int posX, int posY, int width, int height, unsigned int style, const wxValidator* validator, const wxString* nameArg)
{
	if (validator == NULL)
		validator = &wxDefaultValidator;

   wxString name;
	if (nameArg == NULL)
		name = wxT("scrollbar");
   else
      name=*nameArg;
		
    return self->Create(parent, id, wxPoint(posX, posY), wxSize(width, height), style, *validator, name);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxScrollBar_GetThumbPosition(wxScrollBar* self)
{
    return self->GetThumbPosition();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxScrollBar_GetThumbSize(wxScrollBar* self)
{
    return self->GetThumbSize();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxScrollBar_GetPageSize(wxScrollBar* self)
{
    return self->GetPageSize();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxScrollBar_GetRange(wxScrollBar* self)
{
    return self->GetRange();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxScrollBar_IsVertical(wxScrollBar* self)
{
    return self->IsVertical()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxScrollBar_SetThumbPosition(wxScrollBar* self, int viewStart)
{
    self->SetThumbPosition(viewStart);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxScrollBar_SetScrollbar(wxScrollBar* self, int position, int thumbSize, int range, int pageSize, bool refresh)
{
    self->SetScrollbar(position, thumbSize, range, pageSize, refresh);
}

//-----------------------------------------------------------------------------

