//-----------------------------------------------------------------------------
// wx.NET - locale.cxx
//
// The wxLocale proxy interface.
//
// Written by Alexander Olk (xenomorph2@onlinehome.de)
// (C) 2004 by Alexander Olk
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: locale.cxx,v 1.8 2010/06/16 18:09:59 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include "local_events.h"

#if wxUSE_UNICODE
# ifdef _MSC_VER
# pragma message("Unicode build")
# elif __GNUC__
# warning Unicode Build
# endif
#else
# ifdef _MSC_VER
# pragma message("ANSI build")
# elif __GNUC__
# warning Unicode Build
# endif
#endif

WXNET_EXPORT(wxLocale*)
  wxLocale_ctor()
{
	return new wxLocale();
}

WXNET_EXPORT(wxLocale*)
  wxLocale_ctor2(int language, int flags)
{
#if wxUSE_UNICODE
   flags=flags&~wxLOCALE_CONV_ENCODING;
#endif
	return new wxLocale(language, flags);
}

WXNET_EXPORT(void)
  wxLocale_dtor(wxLocale* self)
{
	WXNET_DEL( self );
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxLocale_Init(wxLocale* self, int language, int flags)
{
   if (self)
	   return self->Init(language, flags)?1:0;
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxLocale_AddCatalog(wxLocale* self, const wxString* szDomain)
{
   if (self && szDomain)
	   return self->AddCatalog(*szDomain)?1:0;
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxLocale_AddCatalog2(wxLocale* self, const wxString* szDomain, wxLanguage msgIdLanguage, const wxString* msgIdCharset)
{
   if (self && szDomain && msgIdCharset)
	   return self->AddCatalog(*szDomain, msgIdLanguage, *msgIdCharset);
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxLocale_AddCatalogLookupPathPrefix(wxLocale* self, const wxString* prefix)
{
   if (self && prefix)
	   self->AddCatalogLookupPathPrefix(*prefix);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxLocale_AddLanguage(wxLanguageInfo* info)
{
   if (info)
	   wxLocale::AddLanguage(*info);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(const wxLanguageInfo*)
  wxLocale_FindLanguageInfo(const wxString* locale)
{
   if (locale)
	   return wxLocale::FindLanguageInfo(*locale);
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxLocale_GetCanonicalName(wxLocale* self)
{
   if (self)
	   return new wxString(self->GetCanonicalName());
   else
      return 0;
}
//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxLocale_GetLanguage(wxLocale* self)
{
   if (self)
	   return self->GetLanguage();
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(const wxLanguageInfo*)
  wxLocale_GetLanguageInfo(int lang)
{
	return wxLocale::GetLanguageInfo(lang);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxLocale_GetLanguageName(int lang)
{
	return new wxString(wxLocale::GetLanguageName(lang));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxLocale_GetLocale(wxLocale* self)
{
   if (self)
	   return new wxString(self->GetLocale());
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxLocale_GetName(wxLocale* self)
{
   if (self)
	   return new wxString(self->GetName());
   else
      return NULL;
}

//-----------------------------------------------------------------------------

// szDomain might be NULL
WXNET_EXPORT(wxString*)
  wxLocale_GetString(wxLocale* self, const wxString* szOrigString, const wxString* szDomain)
{
   if (self && szOrigString)
   {
      if (szDomain)
	      return new wxString(self->GetString(*szOrigString, *szDomain));
      else
	      return new wxString(self->GetString(*szOrigString));
   }
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxLocale_GetHeaderValue(wxLocale* self, const wxString* szHeader, const wxString* szDomain)
{
   if (self && szHeader && szDomain)
	   return new wxString(self->GetHeaderValue(*szHeader, *szDomain));
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxLocale_GetSysName(wxLocale* self)
{
   if (self)
	   return new wxString(self->GetSysName());
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxFontEncoding)
  wxLocale_GetSystemEncoding()
{
	return wxLocale::GetSystemEncoding();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxLocale_GetSystemEncodingName()
{
	return new wxString(wxLocale::GetSystemEncodingName());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxLocale_GetSystemLanguage()
{
	return wxLocale::GetSystemLanguage();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxLocale_IsLoaded(wxLocale* self, const wxString* domain)
{
   if (self && domain)
	   return self->IsLoaded(*domain)?1:0;
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxLocale_IsOk(wxLocale* self)
{
   if (self)
	   return self->IsOk()?1:0;
   else
      return 0;
}

//-----------------------------------------------------------------------------
// wxLanguageInfo

WXNET_EXPORT(wxLanguageInfo*)
  wxLanguageInfo_ctor()
{
	return new wxLanguageInfo();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxLanguageInfo_dtor(wxLanguageInfo* self)
{
	WXNET_DEL( self );
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxLanguageInfo_SetLanguage(wxLanguageInfo* self, int value)
{
   if (self)
	   self->Language = value;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxLanguageInfo_GetLanguage(wxLanguageInfo* self)
{
   if (self)
	   return self->Language;
   else
      return 0;
} 

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxLanguageInfo_SetCanonicalName(wxLanguageInfo* self, const wxString* name)
{
   if (self && name)
	   self->CanonicalName = *name;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxLanguageInfo_GetCanonicalName(wxLanguageInfo* self)
{
   if (self)
	   return new wxString(self->CanonicalName);
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxLanguageInfo_SetDescription(wxLanguageInfo* self, const wxString* name)
{
   if (self && name)
	   self->Description = *name;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxLanguageInfo_GetDescription(wxLanguageInfo* self)
{
   if (self)
	   return new wxString(self->Description);
   else
      return NULL;
}

