//-----------------------------------------------------------------------------
// wx.NET - colourdialog.cxx
//
// The wxColourDialog proxy interface.
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 by Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: colourdialog.cxx,v 1.10 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/colordlg.h>
#include "local_events.h"

//-----------------------------------------------------------------------------

class _ColourDialog : public wxColourDialog
{
public:
    DECLARE_OBJECTDELETED(_ColourDialog)
};

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxColourDialog*)
  wxColourDialog_ctor()
{
	return new _ColourDialog();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxColourDialog_Create(wxColourDialog* self, wxWindow *parent, wxColourData *data)
{
	return self->Create(parent, data)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxColourData*)
  wxColourDialog_GetColourData(wxColourDialog* self)
{
    return new wxColourData(self->GetColourData());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxColourDialog_ShowModal(wxColourDialog* self)
{
	return self->ShowModal();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxColour*)
  wxColourDialog_GetColourFromUser(wxWindow* parent, const wxColour* colInit)
{
	return new wxColour(wxGetColourFromUser(parent, *colInit));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxColourData*)
  wxColourData_ctor()
{
	return new wxColourData();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxColourData_SetChooseFull(wxColourData* self, bool flag)
{
	self->SetChooseFull(flag);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxColourData_GetChooseFull(wxColourData* self)
{
	return self->GetChooseFull()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxColourData_SetColour(wxColourData* self, const wxColour* colour)
{
	self->SetColour(*colour);
}

WXNET_EXPORT(wxColour*)
  wxColourData_GetColour(wxColourData* self)
{
    return new wxColour(self->GetColour());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxColourData_SetCustomColour(wxColourData* self, int i, const wxColour* colour)
{
	self->SetCustomColour(i, *colour);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxColour*)
  wxColourData_GetCustomColour(wxColourData* self, int i)
{
	return new wxColour(self->GetCustomColour(i));
}

//-----------------------------------------------------------------------------



