//-----------------------------------------------------------------------------
// wx.NET - statusbar.cxx
// 
// The wxStatusBar proxy interface.
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 by Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: statusbar.cxx,v 1.9 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include "local_events.h"

//-----------------------------------------------------------------------------

class _StatusBar : public wxStatusBar
{
public:
    DECLARE_OBJECTDELETED(_StatusBar)
};

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxStatusBar*)
  wxStatusBar_ctor()
{
    return new _StatusBar();
}

WXNET_EXPORT(char)
  wxStatusBar_Create(wxStatusBar* self, wxWindow* parent, wxWindowID id, unsigned int style, const wxString* nameArg)
{
   wxString name;
   if (nameArg == NULL)
        name = wxT("statusBar");
   else
      name=*nameArg;

    return self->Create(parent, id, style, name);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStatusBar_SetFieldsCount(wxStatusBar* self, int number, int *widths) 
{
    self->SetFieldsCount(number, widths);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxStatusBar_GetFieldRect(wxStatusBar* self, int i, wxRect* rect)
{
    return self->GetFieldRect(i, *rect)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStatusBar_GetBorderY(wxStatusBar* self)
{
    return self->GetBorderY();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxStatusBar_GetStatusText(wxStatusBar* self, int number)
{
    return new wxString(self->GetStatusText(number));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStatusBar_GetBorderX(wxStatusBar* self)
{
    return self->GetBorderX();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStatusBar_SetStatusText(wxStatusBar* self, const wxString* text, int number)
{
   if (self && text)
    self->SetStatusText(*text, number);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStatusBar_SetStatusWidths(wxStatusBar* self, int n, int* widths_field)
{
    self->SetStatusWidths(n, widths_field);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStatusBar_GetFieldsCount(wxStatusBar* self)
{
	return self->GetFieldsCount();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStatusBar_PopStatusText(wxStatusBar* self, int field)
{
	self->PopStatusText(field);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStatusBar_PushStatusText(wxStatusBar* self, const wxString* xstring, int field)
{
   if (self && xstring)
	   self->PushStatusText(*xstring, field);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStatusBar_SetMinHeight(wxStatusBar* self, int height)
{
	self->SetMinHeight(height);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStatusBar_SetStatusStyles(wxStatusBar* self, int n, int styles[])
{
	self->SetStatusStyles(n, styles);
}

