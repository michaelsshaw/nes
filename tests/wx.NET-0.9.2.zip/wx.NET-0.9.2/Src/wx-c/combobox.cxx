//-----------------------------------------------------------------------------
// wx.NET - combobox.cxx
//
// The wxComboBox proxy interface
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 by Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: combobox.cxx,v 1.12 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/combobox.h>
#include "local_events.h"

//-----------------------------------------------------------------------------

class _ComboBox : public wxComboBox
{
public:
    DECLARE_OBJECTDELETED(_ComboBox)
};

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxComboBox*)
  wxComboBox_ctor()
{
    return new _ComboBox();
}

WXNET_EXPORT(bool)
  wxComboBox_Create(wxComboBox* self, wxWindow* window, int id,
                       const wxString* value,
                       const wxPoint* pos, const wxSize* size,
                       const wxArrayString* choices, unsigned int style,
                       const wxValidator* validator, const wxString* nameArg)
{
    if (pos == NULL)
        pos = &wxDefaultPosition;

    if (size == NULL)
        size = &wxDefaultSize;

    if (validator == NULL)
        validator = &wxDefaultValidator;

    wxString name;
    if (nameArg) name=*nameArg;
    else         name=wxT("ComboBox");

    if (value && self)
    {
       if (choices)
          return self->Create(window, id, *value, *pos, *size,
                              *choices, style, *validator,
                              name)?1:0;
       else
          return self->Create(window, id, *value, *pos, *size,
                              0, NULL, style, *validator,
                              name)?1:0;
    }
    return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxComboBox_Copy(wxComboBox* self)
{
   if (self)
      self->Copy();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxComboBox_Cut(wxComboBox* self)
{
    self->Cut();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxComboBox_Paste(wxComboBox* self)
{
    self->Paste();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxComboBox_SetInsertionPoint(wxComboBox* self, int pos)
{
    self->SetInsertionPoint(pos);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxComboBox_GetInsertionPoint(wxComboBox* self)
{
    return (int)self->GetInsertionPoint();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxComboBox_GetLastPosition(wxComboBox* self)
{
    return self->GetLastPosition();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxComboBox_Replace(wxComboBox* self, int from, int to, const wxString* value)
{
   if (self && value)
    self->Replace(from, to, *value);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxComboBox_SetSelection(wxComboBox* self, int from, int to)
{
    self->SetSelection(from, to);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxComboBox_SetEditable(wxComboBox* self, bool editable)
{
    self->SetEditable(editable);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxComboBox_SetInsertionPointEnd(wxComboBox* self)
{
    self->SetInsertionPointEnd();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxComboBox_Remove(wxComboBox* self, int from, int to)
{
    self->Remove(from, to);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxComboBox_GetValue(wxComboBox* self)
{
    return new wxString(self->GetValue());
}

WXNET_EXPORT(void)
  wxComboBox_SetValue(wxComboBox* self, const wxString* text)
{
   if (self && text)
    self->SetValue(*text);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxComboBox_Select(wxComboBox* self, int n)
{
	self->Select(n);
}


