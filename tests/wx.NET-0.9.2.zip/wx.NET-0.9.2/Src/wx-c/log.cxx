//-----------------------------------------------------------------------------
// wx.NET - log.cxx
//
// The wxLog and wxLogXXX proxy interfaces.
//
// Written by Alexander Olk (xenomorph2@onlinehome.de)
// (C) 2003 by Alexander Olk
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: log.cxx,v 1.12 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/log.h>
#include "local_events.h"

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxLog*)
  wxLog_ctor()
{
    return new wxLog();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxLog_dtor(wxLog* self)
{
    WXNET_DEL( self );
}

//-----------------------------------------------------------------------------
// SetLogBuffer ???
//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxLog_IsEnabled()
{
    return wxLog::IsEnabled()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxLog_EnableLogging(bool doit)
{
    return wxLog::EnableLogging(doit)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxLog_Flush(wxLog* self)
{
    self->Flush();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxLog_HasPendingMessages(wxLog* self)
{
    return self->HasPendingMessages()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxLog_FlushActive()
{
    wxLog::FlushActive();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxLog*)
  wxLog_GetActiveTarget()
{
    return wxLog::GetActiveTarget();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxLog*)
  wxLog_SetActiveTargetTextCtrl(wxTextCtrl* pLogger)
{
    return wxLog::SetActiveTarget(new wxLogTextCtrl(pLogger));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxLog_Suspend(void)
{
    wxLog::Suspend();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxLog_Resume(void)
{
    wxLog::Resume();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxLog_SetVerbose(bool bVerbose)
{
    wxLog::SetVerbose(bVerbose);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxLog_SetLogLevel(wxLogLevel logLevel)
{
    wxLog::SetLogLevel(logLevel);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxLog_DontCreateOnDemand()
{
    wxLog::DontCreateOnDemand();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxLog_LogTraceStringMask(const wxString* mask, const wxString* msg)
{
   if (mask && msg)
     wxLogTrace(*mask, wxT("%s"), msg->c_str());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxLog_SetTraceMask(wxTraceMask ulMask)
{
    wxLog::SetTraceMask(ulMask);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxLog_AddTraceMask(const wxString* str)
{
   if (str)
      wxLog::AddTraceMask(*str);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxLog_RemoveTraceMask(const wxString* str)
{
   if (str)
    wxLog::RemoveTraceMask(*str);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxLog_ClearTraceMasks()
{
    wxLog::ClearTraceMasks();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxArrayString*)
  wxLog_GetTraceMasks()
{
    return new wxArrayString(wxLog::GetTraceMasks());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxLog_SetTimestamp(const wxString* ts)
{
   if (ts)
    wxLog::SetTimestamp(*ts);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxLog_GetVerbose()
{
    return wxLog::GetVerbose()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxTraceMask)
  wxLog_GetTraceMask()
{
    return wxLog::GetTraceMask();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxLog_IsAllowedTraceMask(const wxString* mask)
{
   if (mask)
    return wxLog::IsAllowedTraceMask(*mask);
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxLogLevel)
  wxLog_GetLogLevel()
{
    return wxLog::GetLogLevel();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxLog_GetTimestamp()
{
    return new wxString(wxLog::GetTimestamp());
}

//-----------------------------------------------------------------------------

enum {
	xLOGMESSAGE,
	xFATALERROR,
	xERROR,
	xWARNING,
	xINFO,
	xVERBOSE,
	xSTATUS,
	xSYSERROR
};

WXNET_EXPORT(void)
  wxLog_Log_Function(int what, const wxString* szFormat)
{
    if (!szFormat) return;
    // params are converted by csharp code

    switch (what) {
    	case xLOGMESSAGE: 	wxLogMessage(*szFormat);
				break;
	case xFATALERROR: 	wxLogFatalError(*szFormat);
				break;
	case xERROR:	  	wxLogError(*szFormat);
				break;
	case xWARNING:		wxLogWarning(*szFormat);
				break;
	case xINFO:		wxLogInfo(*szFormat);
				break;
	case xVERBOSE:		wxLogVerbose(*szFormat);
				break;
	case xSTATUS:		wxLogStatus(*szFormat);
				break;
	case xSYSERROR:		wxLogSysError(*szFormat);
				break;
    }
}





