//-----------------------------------------------------------------------------
// wx.NET - radiobox.cxx
//
// The wxRadioBox proxy interface.
//
// Written by Jason Perkins (jason@379.com)
// (C) 2003 by 379, Inc.
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: radiobox.cxx,v 1.16 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include "local_events.h"

//-----------------------------------------------------------------------------

class _RadioBox : public wxRadioBox
{
public:
    DECLARE_OBJECTDELETED(_RadioBox)
};

//-----------------------------------------------------------------------------
// C stubs for class methods

WXNET_EXPORT(wxRadioBox*)
  wxRadioBox_ctor()
{
	return new _RadioBox();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxRadioBox_Create(wxRadioBox* self, wxWindow* parent, int id, const wxString* labelArg,
                       const wxPoint* pos, const wxSize* size, const wxArrayString* choices,
                       int majorDimension, unsigned int style, const wxValidator* val, const wxString* nameArg)
{
	if (pos == NULL)
		pos = &wxDefaultPosition;

	if (size == NULL)
		size = &wxDefaultSize;

	if (val == NULL)
		val = &wxDefaultValidator;

   wxString label;
   if (labelArg) label=*labelArg;

   wxString name(wxT("radioBox"));
   if (nameArg) name=*nameArg;

   if (choices && choices->Count() > 0)
	   return self->Create(parent, id, label, *pos, *size, *choices, majorDimension, style, *val, name);
   else
	   return self->Create(parent, id, label, *pos, *size, 0, NULL, majorDimension, style, *val, name);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxRadioBox_Enable(wxRadioBox* self, int n, bool enable)
{
	self->Enable(n, enable);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxRadioBox_FindString(const wxRadioBox* self, const wxString* string)
{
   if (self && string)
	   return self->FindString(*string);
   else
      return -1;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxRadioBox_GetLabel(wxRadioBox* self)
{
   if (self)
	   return new wxString(self->GetLabel());
   else
      return new wxString();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxRadioBox_GetSelection(const wxRadioBox* self)
{
   if (self)
      return self->GetSelection();
   else
      return -1;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxRadioBox_GetStringSelection(const wxRadioBox* self)
{
   if (self)
      return new wxString(self->GetStringSelection());
   else
      return new wxString();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxRadioBox_GetString(const wxRadioBox* self, int n)
{
   if (self)
      return new wxString(self->GetString(n));
   else
      return new wxString();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxRadioBox_SetLabel(wxRadioBox* self, const wxString* label)
{
   if (self && label)
	   self->SetLabel(*label);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxRadioBox_SetSelection(wxRadioBox* self, int item)
{
   if (self)
      self->SetSelection(item);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxRadioBox_SetStringSelection(wxRadioBox* self, const wxString* string)
{
   if (self && string)
      self->SetStringSelection(*string);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxRadioBox_Show(wxRadioBox* self, int n, bool show)
{
	self->Show(n, show);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxRadioBox_GetCount(const wxRadioBox* self)
{
   if (self) return self->GetCount();
   else return 0;
}

