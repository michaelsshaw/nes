//-----------------------------------------------------------------------------
// wx.NET - icon.cxx
//
// The wxIcon proxy interface.
//
// Written by Jason Perkins (jason@379.com)
// (C) 2003 by 379, Inc.
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: icon.cxx,v 1.8 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#ifndef WXNET_GLOBAL_H
#include "wxnet_globals.h"
#endif

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxIcon*)
  wxIcon_ctor()
{
	return new wxIcon();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxIcon_CopyFromBitmap(wxIcon* self, const wxBitmap* bitmap)
{
	self->CopyFromBitmap(*bitmap);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxIcon_LoadFile(wxIcon* self, const wxString* name, wxBitmapType type)
{
   if (self && name)
	   return self->LoadFile(*name, type);
   else
      return false;
}
