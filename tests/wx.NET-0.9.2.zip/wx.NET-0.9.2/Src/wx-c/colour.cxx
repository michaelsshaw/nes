//-----------------------------------------------------------------------------
// wx.NET - colour.cxx
//
// The wxColour proxy interface.
//
// Written by Jason Perkins (jason@379.com)
// (C) 2003 by 379, Inc.
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: colour.cxx,v 1.16 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include "local_events.h"

//-----------------------------------------------------------------------------

/*class _Colour : public wxColour
{
public:
	_Colour()
		: wxColour() {}
		
	_Colour(const wxString& colourNname)
		: wxColour(colourNname) {}
		
	_Colour(const unsigned char red, const unsigned char green, const unsigned char blue)	
		: wxColour(red, green, blue) {}

	DECLARE_DISPOSABLE(_Colour)
};*/

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxColour*)
  wxColour_ctor()
{
	return new wxColour();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxColour_dtor(wxColour* self)
{
	WXNET_DEL(self);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxColour*)
  wxColour_ctorByName(const wxString* name)
{
   if (name)
	   return new wxColour(*name);
   else
      return new wxColour(wxT("BLACK"));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxColour*)
  wxColour_ctorByParts(unsigned char red, unsigned char green, unsigned char blue)
{
	return new wxColour(red, green, blue);
}

WXNET_EXPORT(wxColour*)
  wxColour_ctorByPartsWithAlpha(unsigned char red, unsigned char green, unsigned char blue, unsigned char alpha)
{
	return new wxColour(red, green, blue, alpha);
}


/*extern "C" WXEXPORT
void wxColour_RegisterDisposable(_Colour* self, Virtual_Dispose onDispose)
{
	self->RegisterDispose(onDispose);
}*/

//-----------------------------------------------------------------------------

WXNET_EXPORT(unsigned char)
  wxColour_Blue(wxColour* self)
{
	return self->Blue();
}

WXNET_EXPORT(unsigned char)
  wxColour_Red(wxColour* self)
{
	return self->Red();
}

WXNET_EXPORT(unsigned char)
  wxColour_Green(wxColour* self)
{
	return self->Green();
}

WXNET_EXPORT(unsigned char)
  wxColour_Alpha(wxColour* self)
{
   if (self)
      return self->Alpha();
   else
      return wxALPHA_OPAQUE;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxColour_Ok(wxColour* self)
{
	return self->Ok()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxColour_Set(wxColour* self, unsigned char red, unsigned char green, unsigned char blue, unsigned int alpha)
{
   if (self)
	   self->Set(red, green, blue, alpha);
}

WXNET_EXPORT(void)
  wxColour_SetFromString(wxColour* self, const wxString* str)
{
   if (self && str)
      self->Set(*str);
}

// HMaH
WXNET_EXPORT(void)
  wxColour_SetFromColour(wxColour* self, const wxColour* src)
{
    if (self && src)
        if (src) (*self)=(*src);
}

WXNET_EXPORT(wxString*)
  wxColour_GetAsString(const wxColour* self, unsigned int flags)
{
   return new wxString(self->GetAsString(flags));
}
