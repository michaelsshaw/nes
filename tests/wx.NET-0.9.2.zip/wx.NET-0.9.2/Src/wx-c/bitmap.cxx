//-----------------------------------------------------------------------------
// wx.NET - bitmap.cxx
//
// The wxBitmap proxy interface.
//
// Written by Jason Perkins (jason@379.com)
// (C) 2003 by 379, Inc.
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: bitmap.cxx,v 1.21 2009/07/03 18:45:13 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/bitmap.h>
#include <wx/image.h>
#ifndef WXNET_GLOBAL_H
#include "wxnet_globals.h"
#endif

//-----------------------------------------------------------------------------
// wxBitmap

WXNET_EXPORT(const wxBitmap*)
  wxBitmap_NullBitmap(void)
{
   return &wxNullBitmap;
}

WXNET_EXPORT(wxBitmap*)
  wxBitmap_ctor(void)
{
    return new wxBitmap();
}

WXNET_EXPORT(wxBitmap*)
  wxBitmap_ctorByImage(wxImage* image, int depth)
{
  if (image)
  {
    if (depth < 0)
      return new wxBitmap(*image);
    else
      return new wxBitmap(*image, depth);
  }
  return NULL;
}

WXNET_EXPORT(wxBitmap*)
  wxBitmap_ctorByName(const wxString* name, int type)
{
   if (name)
    return new wxBitmap(*name, type);
   else
      return NULL;
}

WXNET_EXPORT(wxBitmap*)
  wxBitmap_ctorBySize(int width, int height, int depth)
{
    return new wxBitmap(width, height, depth);
}

WXNET_EXPORT(wxBitmap*)
  wxBitmap_ctorByBitmap(wxBitmap* bitmap)
{
	return new wxBitmap(*bitmap);
}

/** Creates a bitmap from XPM text.
* XPM is ASCII-encoded, so we do not have a problem 
* with Unicode.
*/
WXNET_EXPORT(wxBitmap*)
wxBitmap_ctorFromXpmData(const char* const* xpm)
{
   if (xpm)
   {
      return new wxBitmap(xpm);
   }
   else
      return NULL;
}

WXNET_EXPORT(wxBitmap*)
wxBitmap_ctorFromBits(const char bits[], int width, int height)
{
   if (bits && width> 0 &&height > 0)
      return new wxBitmap(bits, width, height);
   else
      return NULL;
}

//-----------------------------------------------------------------------------
WXNET_EXPORT(void)
wxBitmap_CleanUpHandlers()
{
	wxBitmap::CleanUpHandlers();
}
//-----------------------------------------------------------------------------
WXNET_EXPORT(void)
wxBitmap_AddHandler(wxBitmapHandler* handler)
{
	wxBitmap::AddHandler(handler);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxImage*)
  wxBitmap_ConvertToImage(wxBitmap* self)
{
    return new wxImage(self->ConvertToImage());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxBitmap_GetHeight(wxBitmap* self)
{
    return self->GetHeight();
}

WXNET_EXPORT(void)
  wxBitmap_SetHeight(wxBitmap* self, int height)
{
    self->SetHeight(height);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxBitmap_GetWidth(wxBitmap* self)
{
    return self->GetWidth();
}

WXNET_EXPORT(void)
  wxBitmap_SetWidth(wxBitmap* self, int width)
{
    self->SetWidth(width);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxBitmap_LoadFile(wxBitmap* self, const wxString* name, wxBitmapType type)
{
   if (name && self)
    return self->LoadFile(*name, type);
   else
      return false;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxBitmap_SaveFile(wxBitmap* self, const wxString* name, wxBitmapType type, wxPalette* palette)
{
   if (self && name)
	   return self->SaveFile(*name, type, palette);
   else
      return false;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxBitmap_Ok(wxBitmap* self)
{
    return self->Ok()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxBitmap_GetDepth(wxBitmap* self)
{
	return self->GetDepth();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxBitmap_SetDepth(wxBitmap* self, int depth)
{
	self->SetDepth(depth);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxBitmap*)
  wxBitmap_GetSubBitmap(wxBitmap* self, wxRect* rect)
{
   if (self && rect)
	   return new wxBitmap(self->GetSubBitmap(*rect));
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxMask*)
  wxBitmap_GetMask(wxBitmap* self)
{
	return self->GetMask();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxBitmap_SetMask(wxBitmap* self, wxMask* mask)
{
	self->SetMask(mask);
}

WXNET_EXPORT(wxPalette*)
  wxBitmap_GetPalette(wxBitmap* self)
{
	return self->GetPalette();
}

WXNET_EXPORT(wxPalette*)
  wxBitmap_GetColourMap(wxBitmap* self)
{
	return self->GetPalette();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxBitmap_CopyFromIcon(wxBitmap* self, wxIcon* icon)
{
	return self->CopyFromIcon(*icon)?1:0;
}

//-----------------------------------------------------------------------------
//wxMask

WXNET_EXPORT(wxMask*)
  wxMask_ctor()
{
    return new wxMask();
}

WXNET_EXPORT(wxMask*)
  wxMask_ctorByBitmapColour(wxBitmap* bitmap, wxColour* colour)
{
	if (bitmap && colour)
    return new wxMask(*bitmap, *colour);
	else
	return NULL;
}

WXNET_EXPORT(wxMask*)
  wxMask_ctorByBitmapIndex(wxBitmap* bitmap, int paletteIndex)
{
	if (bitmap)
    return new wxMask(*bitmap, paletteIndex);
	else
	return NULL;
}

WXNET_EXPORT(wxMask*)
  wxMask_ctorByBitmap(wxBitmap* bitmap)
{
	if (bitmap)
    return new wxMask(*bitmap);
	else
	return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxMask_CreateByBitmapColour(wxMask* self, wxBitmap* bitmap, wxColour* colour)
{
	if (self)
	return self->Create(*bitmap, *colour)?1:0;
	else
	return 0;
}

WXNET_EXPORT(char)
  wxMask_CreateByBitmapIndex(wxMask* self, wxBitmap* bitmap, int paletteIndex)
{
	if (self)
	return self->Create(*bitmap, paletteIndex)?1:0;
	else
	return 0;
}

WXNET_EXPORT(char)
  wxMask_CreateByBitmap(wxMask* self, wxBitmap* bitmap)
{
	if (self)
	return self->Create(*bitmap)?1:0;
	else
	return 0;
}

