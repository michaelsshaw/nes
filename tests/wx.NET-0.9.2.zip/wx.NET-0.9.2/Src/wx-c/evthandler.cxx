//-----------------------------------------------------------------------------
// wx.NET - evthandler.cxx
//
// The wxEvtHandler proxy interface.
//
// Written by Jason Perkins (jason@379.com)
// (C) 2003 by 379, Inc.
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: evthandler.cxx,v 1.9 2010/04/11 15:17:08 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include "local_events.h"

//-----------------------------------------------------------------------------

// CALLBACK MAY BE ALREADY DEFINED
#ifndef CALLBACK 
# if defined(_WINDOWS)
#  define CALLBACK __stdcall
# else
#  define CALLBACK
# endif
#endif

typedef void (CALLBACK* EventListener)(wxEvent* event, int iListener);

//-----------------------------------------------------------------------------

struct wxProxyData : public wxObject
{
	int iListener;
};

class wxEvtProxy : public wxEvtHandler
{
public:
	void ForwardEvent(wxEvent& event)
	{
		wxProxyData* data = (wxProxyData*)event.m_callbackUserData;

		EventListener el = (EventListener)GetClientData();
		el(&event, data->iListener);
	}
};

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxEvtHandler_proxy(wxEvtHandler* self, EventListener listener)
{
	self->SetClientData((void*)listener);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxEvtHandler_Connect(wxEvtHandler* self, int evtType, int id, int lastId, int iListener)
{
	wxProxyData* data = new wxProxyData;
	data->iListener = iListener;
	
	self->Connect(id, lastId, evtType, (wxObjectEventFunction)&wxEvtProxy::ForwardEvent, data);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxEvtHandler_ProcessEvent(wxEvtHandler* self, wxEvent* event)
{
    return self->ProcessEvent(*event);
}

//-----------------------------------------------------------------------------


WXNET_EXPORT(void)
  wxEvtHandler_AddPendingEvent(wxEvtHandler* self, wxEvent* event)
{
	self->AddPendingEvent(*event);
}

