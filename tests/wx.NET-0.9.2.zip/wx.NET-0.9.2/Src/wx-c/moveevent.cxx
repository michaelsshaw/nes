//-----------------------------------------------------------------------------
// wx.NET - MoveEvent.cs
//
// The wxMoveEvent wrapper class.
//
// Written by Alexander Olk (xenomorph2@onlinehome.de)
// (C) 2004 by Alexander Olk
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// moveevent.cxx,v 1.4 2008/12/25 17:01:35 harald_meyer Exp
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#ifndef WXNET_GLOBAL_H
#include "wxnet_globals.h"
#endif

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxMoveEvent*)
  wxMoveEvent_ctor()
{
    return new wxMoveEvent();
}

WXNET_EXPORT(void)
  wxMoveEvent_GetPosition(wxMoveEvent* self, wxPoint* point)
{
    *point=self->GetPosition();
}
