//-----------------------------------------------------------------------------
// wx.NET - dataformat.cxx
// 
// wxDataFormat proxy interface.
//
// Written by Bryan Bulten (bryan@bulten.ca)
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: dataformat.cxx,v 1.8 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/dataobj.h>
#include "local_events.h"

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxDataFormat*)
  wxDataFormat_ctor()
{
    return new wxDataFormat();
}

WXNET_EXPORT(void)
  wxDataFormat_dtor(wxDataFormat* self)
{
	WXNET_DEL(self);
}

WXNET_EXPORT(wxDataFormat*)
  wxDataFormat_ctorByType(wxDataFormatId type)
{
    return new wxDataFormat(type);
}

WXNET_EXPORT(wxDataFormat*)
  wxDataFormat_ctorById(const wxString* id)
{
   if (id)
      return new wxDataFormat(*id);
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxDataFormat_GetId(wxDataFormat* self)
{
    return new wxString(self->GetId());
}

WXNET_EXPORT(void)
  wxDataFormat_SetId(wxDataFormat* self, const wxString* id)
{
   if (id)
    self->SetId(*id);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxDataFormatId)
  wxDataFormat_GetType(wxDataFormat* self)
{
    return (wxDataFormatId)self->GetType();
}

WXNET_EXPORT(void)
  wxDataFormat_SetType(wxDataFormat* self, wxDataFormatId type)
{
    self->SetType(type);
}

