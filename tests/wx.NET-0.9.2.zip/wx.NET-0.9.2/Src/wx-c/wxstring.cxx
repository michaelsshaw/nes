//-----------------------------------------------------------------------------
// wx.NET - wxstring.cxx
//
// The new wxString proxy interface
//
// Written by Harald Meyer auf'm Hofe
// (C) 2006 by Harald Meyer auf'm Hofe
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: wxstring.cxx,v 1.22 2010/06/16 18:11:11 uid233030 Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/strconv.h>
#include "local_events.h"

#if wxUSE_UNICODE
# ifdef __GNUC__
#  warning "Unicode build"
# elif _MSC_VER
#  pragma message("Unicode build")
# endif
#else
# ifdef __GNUC__
#  warning "ANSI build"
# elif _MSC_VER
#  pragma message("ANSI build")
# endif
#endif

enum Encoding
{
   Encoding_UTF8,
   Encoding_Local
};


/** Converts UTF 16 string into a byte string.
*/
class _wxWCharBuffer
{
public:
    wxWCharBuffer buffer;
    size_t length;
    _wxWCharBuffer()
        : buffer((const wchar_t*)NULL), length(0)
    {
    }

    _wxWCharBuffer(const wxString& src)
        : buffer(src.wc_str(*wxConvCurrent)), length(src.Length())
    {
    }
    
    // Encoding describes the goal of conversion that is usually fixed to UTF16
    _wxWCharBuffer(const wxString& src, Encoding encoding)
    {
      switch (encoding)
      {
        case Encoding_UTF8:
        {
          wxMBConvUTF8 wxConvUTF8;
          buffer=src.wc_str(wxConvUTF8);
          length=src.Length();
        }
        break;
        case Encoding_Local:
        {
          buffer=src.wc_str(*wxConvCurrent);
          length=src.Length();
        }
        break;
        default:
          length=0;
      }
    }

    _wxWCharBuffer(const char* src)
    {
      wxMBConvUTF16LE wxConvUTF16LE;
      wxString result(wxConvUTF16LE.cMB2WC(src), *wxConvCurrent);
      buffer=result.wc_str(*wxConvCurrent);
      length=result.Length();
    }

    _wxWCharBuffer(const char* src, Encoding encoding)
    {
       switch (encoding)
       {
       case Encoding_UTF8:
          {
            wxMBConvUTF8 wxConvUTF8;
            wxMBConvUTF16LE wxConvUTF16LE;
            wxString result(wxConvUTF16LE.cMB2WC(src), wxConvUTF8);
            buffer=result.wc_str(wxConvUTF8);
            length=result.Length();
          }
         break;
       case Encoding_Local:
          {
            wxMBConvUTF16LE wxConvUTF16LE;
            wxString result(wxConvUTF16LE.cMB2WC(src), *wxConvCurrent);
            buffer=result.wc_str(*wxConvCurrent);
            length=result.Length();
          }
         break;
       default:
          length=0;
       }
    }

    bool IsEmpty() const
    {
        if (!length) return true;
        if (!buffer.data()) return true;
        if (!buffer[(size_t)0]) return true;
        return false;
    }

    size_t Length() const
    {
        return this->length;
    }

    wchar_t operator[](size_t n) const
    {
        if (n < this->length)
            return this->buffer[n];
        else
            return 0;
    }
};

int wxString_calls=0;

WXNET_EXPORT(wxString*)
  wxString_ctorUTF16(const char* str)
{ 
  wxMBConvUTF16LE wxConvUTF16LE;
  return WXNET_NEW( wxString, (wxConvUTF16LE.cMB2WC(str), *wxConvCurrent));
}

WXNET_EXPORT(wxString*)
  wxString_ctorUTF8(const char* str)
{ 
  wxMBConvUTF8 wxConvUTF8;
  return WXNET_NEW( wxString, (wxConvUTF8.cMB2WC(str), *wxConvCurrent));
}


WXNET_EXPORT(void)
  wxString_dtor(wxString *self)
{
  if (self != NULL)
  {
      delete self;
  }
}

//-----------------------------------------------------------------------------

// this is the conversion from the local character encoding (e.g. latin-1)
WXNET_EXPORT(_wxWCharBuffer*)
  wxString_Conversion(const wxString* self)
{
    if (self)
        return WXNET_NEW( _wxWCharBuffer, (*self));
    else
        return WXNET_NEW( _wxWCharBuffer, ());
}
    
//-----------------------------------------------------------------------------

// this is the conversion into UTF 8.
WXNET_EXPORT(_wxWCharBuffer*)
  wxString_ConversionUTF8(const wxString* self)
{
  if (self)
    return WXNET_NEW( _wxWCharBuffer, (*self, Encoding_UTF8));
  else
    return WXNET_NEW( _wxWCharBuffer, ());
}
    
//-----------------------------------------------------------------------------

WXNET_EXPORT(size_t)
  wxString_GetLength(const wxString* self)
{
    if (self) return self->Length();
    else return 0;
}

//-----------------------------------------------------------------------------

/* This method only works well on Unicode builds. Otherwise, everything that
* is non-ASCII will be replaced by a blank.
*/
WXNET_EXPORT(wchar_t)
  wxString_CharAtUTF16(const wxString* self, size_t pos)
{
    if (self)
    {
#if wxUSE_UNICODE
        return self->GetChar(pos);
#else
        char result=self->GetChar(pos);
        if (result >= 0 && result < 128)
            return result;
        else
            return ' ';
#endif
    }
    else return 0;
}

//-----------------------------------------------------------------------------

const wxString _DisposableStringBox::empty=wxT("");

WXNET_EXPORT(_DisposableStringBox*)
  DisposableStringBox_CTor(wxString* str)
{
   return WXNET_NEW( _DisposableStringBox, (str));
}

WXNET_EXPORT(void)
  DisposableStringBox_RegisterDispose(_DisposableStringBox* self, Virtual_Dispose onDispose)
{
   if (self) self->RegisterDispose(onDispose);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(_wxWCharBuffer*)
  wxWCharBuffer_ctorUTF16(const char* buffer)
{
    return WXNET_NEW( _wxWCharBuffer, (buffer));
}

WXNET_EXPORT(_wxWCharBuffer*)
  wxWCharBuffer_ctorUTF8(const char* buffer)
{
    return WXNET_NEW( _wxWCharBuffer, (buffer, Encoding_UTF8));
}

WXNET_EXPORT(void)
  wxWCharBuffer_dtor(_wxWCharBuffer* self)
{
    if (self) delete self;
}

WXNET_EXPORT(char)
  wxWCharBuffer_IsEmpty(_wxWCharBuffer* self)
{
    if (self)
    {
        return self->IsEmpty();
    }
    else
        return true;
}

WXNET_EXPORT(wchar_t)
  wxWCharBuffer_WideCharAt(const _wxWCharBuffer* self, size_t pos)
{
  if (!self || self->IsEmpty())
    return 0;
  else
    return (*self)[pos];
}

WXNET_EXPORT(size_t)
  wxWCharBuffer_GetLength(const _wxWCharBuffer* self)
{
  if (!self)
    return 0;
  else
      return self->Length();
}

