//-----------------------------------------------------------------------------
// wx.NET - htmlhelpctrl.cxx
// 
// The wxHtmlHelpController proxy interface.
//
// Written by Alexander Olk (xenomorph2@onlinehome.de)
// (C) 2004 by Alexander Olk
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: htmlhelpctrl.cxx,v 1.4 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/html/helpctrl.h>
#ifndef WXNET_GLOBAL_H
#include "wxnet_globals.h"
#endif

WXNET_EXPORT(wxHtmlHelpController*)
  wxHtmlHelpController_ctor(int style)
{
	return new wxHtmlHelpController(style);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlHelpController_SetTitleFormat(wxHtmlHelpController* self, const wxString* format)
{
   if (self && format)
	self->SetTitleFormat(*format);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlHelpController_SetTempDir(wxHtmlHelpController* self, const wxString* path)
{
   if (self && path)
	   self->SetTempDir(*path);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxHtmlHelpController_AddBook(wxHtmlHelpController* self, const wxString* book_url)
{
   if (self && book_url)
	   return self->AddBook(*book_url);
   else
      return false;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxHtmlHelpController_Display(wxHtmlHelpController* self, const wxString* x)
{
   if (self && x)
	   return self->Display(*x);
   else 
      return false;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxHtmlHelpController_DisplayInt(wxHtmlHelpController* self, int id)
{
   if (self)
	   return self->Display(id);
   else
      return false;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxHtmlHelpController_DisplayContents(wxHtmlHelpController* self)
{
   if (self)
	   return self->DisplayContents();
   else
      return false;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxHtmlHelpController_DisplayIndex(wxHtmlHelpController* self)
{
   if (self)
	   return self->DisplayIndex();
   else
      return false;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxHtmlHelpController_KeywordSearch(wxHtmlHelpController* self, const wxString* keyword, wxHelpSearchMode mode)
{
   if (self && keyword)
	   return self->KeywordSearch(*keyword, mode);
   else
      return false;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlHelpController_UseConfig(wxHtmlHelpController* self, wxConfigBase* config, const wxString* rootpath)
{
   if (self && rootpath)
	   self->UseConfig(config, *rootpath);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlHelpController_ReadCustomization(wxHtmlHelpController* self, wxConfigBase *cfg, const wxString* path)
{
   if (self && path)
	   self->ReadCustomization(cfg, *path);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlHelpController_WriteCustomization(wxHtmlHelpController* self, wxConfigBase *cfg, const wxString* path)
{
   if (self && path)
	   self->WriteCustomization(cfg, *path);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxHtmlHelpFrame*)
  wxHtmlHelpController_GetFrame(wxHtmlHelpController* self)
{
   if (self)
	   return self->GetFrame();
   else return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlHelpController_OnCloseFrame(wxHtmlHelpController* self, wxCloseEvent* evt)
{
   if (self && evt)
      self->OnCloseFrame(*evt);
}



