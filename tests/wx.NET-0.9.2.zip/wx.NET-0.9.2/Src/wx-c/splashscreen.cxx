//-----------------------------------------------------------------------------
// wx.NET - splashscreen.cxx
//
// The wxSplashScreen proxy interface.
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 by Bryan Bulten 
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: splashscreen.cxx,v 1.5 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/splash.h>
#include "local_events.h"

//-----------------------------------------------------------------------------

class _SplashScreen : public wxSplashScreen
{
public:
    _SplashScreen(const wxBitmap& bitmap, int splashStyle, int milliseconds,
                  wxWindow* parent, wxWindowID id, const wxPoint& pos, 
                  const wxSize& size, unsigned int style)
        : wxSplashScreen(bitmap, splashStyle, milliseconds, parent, id, pos, 
                         size, style) { }

    DECLARE_OBJECTDELETED(_SplashScreen)
};

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxSplashScreen*)
  wxSplashScreen_ctor(wxBitmap* bitmap, int splashStyle, int milliseconds, wxWindow* parent, wxWindowID id, wxPoint* pos, wxSize* size, unsigned int style)
{
    return new _SplashScreen(*bitmap, splashStyle, milliseconds, parent, id, *pos, *size, style);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxSplashScreen_GetSplashStyle(wxSplashScreen* self)
{
    return self->GetSplashStyle();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxSplashScreenWindow*)
  wxSplashScreen_GetSplashWindow(wxSplashScreen* self)
{
    return self->GetSplashWindow();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxSplashScreen_GetTimeout(wxSplashScreen* self)
{
    return self->GetTimeout();
}

//-----------------------------------------------------------------------------

class _SplashScreenWindow : public wxSplashScreenWindow
{
public:
    _SplashScreenWindow(const wxBitmap& bitmap, wxWindow* parent, 
                        wxWindowID id, const wxPoint& pos, const wxSize& size,
                        int style)
        : wxSplashScreenWindow(bitmap, parent, id, pos, size, style) { }

    DECLARE_OBJECTDELETED(_SplashScreenWindow)
};



//-----------------------------------------------------------------------------

WXNET_EXPORT(wxSplashScreenWindow*)
  wxSplashScreenWindow_ctor(wxBitmap* bitmap, wxWindow* parent, wxWindowID id, wxPoint* pos, wxSize* size, unsigned int style)
{
    return new _SplashScreenWindow(*bitmap, parent, id, *pos, *size, style);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxSplashScreenWindow_SetBitmap(wxSplashScreenWindow* self, wxBitmap* bitmap)
{
    self->SetBitmap(*bitmap);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxBitmap*)
  wxSplashScreenWindow_GetBitmap(wxSplashScreenWindow* self)
{
    return &(self->GetBitmap());
}

