//-----------------------------------------------------------------------------
// wx.NET - global.cxx
//
// The proxy interface for wxWidgets global methods.
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 by Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: global.cxx,v 1.20 2009/12/20 14:23:14 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/busyinfo.h>
#include <wx/numdlg.h>
#include "local_events.h"

//-----------------------------------------------------------------------------
WXNET_EXPORT(void)
  wxGlobal_Bell(void)
{
   ::wxBell();
}

WXNET_EXPORT(void)
  wxGlobal_Exit(void)
{
   ::wxExit();
}


//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxGlobal_GetNumberFromUser(
                    const wxString* msg, const wxString* prompt, const wxString* caption,
                    int value, int min, int max, wxWindow* parent,
                    const wxPoint* pos
                )
{
    if (pos == NULL) {
        pos = &wxDefaultPosition;
    }

    if (msg && prompt && caption)
       return wxGetNumberFromUser(*msg, *prompt, *caption, value, min, max, parent, *pos);
    else
       return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxGlobal_GetHomeDir()
{
	return WXNET_NEW( wxString, (wxGetHomeDir()));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxGlobal_FileSelector(const wxString* message, const wxString* default_path,
				const wxString* default_filename, const wxString* default_extension,
				const wxString* wildcard, int flags,
				wxWindow* parent, int x, int y)
{
   if (message && default_path && default_filename && default_extension && wildcard)
	   return WXNET_NEW( wxString, (wxFileSelector(*message,*default_path,*default_filename,*default_extension,*wildcard,
		         		              flags, parent, x, y)));
   else
      return 0;
}

WXNET_EXPORT(wxString*)
  wxGlobal_DirSelector(const wxString* message, const wxString* default_path,
                int flags, wxWindow* parent, int x, int y)
{
    if (message && default_path)
        return WXNET_NEW( wxString, (wxDirSelector(*message, *default_path, flags, wxPoint(x, y), parent)));
    else
        return NULL;
}

//-----------------------------------------------------------------------------

#include <ostream>
std::ostream& operator<<(std::ostream& dest, const ByteBuffer& src)
{
   dest << "ByteBuffer(" << src._sizeFilled << "/" << src._sizeReserved << ":" << (size_t) src._buffer << ":";
   for(size_t i=0; i < src._sizeFilled; ++i)
      dest << " " << src._buffer[i];
   dest << ")";
   return dest;
}


WXNET_EXPORT(ByteBuffer*)
  ByteBuffer_ctor(size_t sizeReserved){
   return WXNET_NEW(ByteBuffer, (sizeReserved));
}


WXNET_EXPORT(size_t)
  ByteBuffer_reserved(const ByteBuffer* buffer){
   if (buffer)
   {
      WXNET_LOG_DEREF(buffer)
      return buffer->_sizeReserved;
   }
   return 0;
}


WXNET_EXPORT(size_t)
  ByteBuffer_filled(const ByteBuffer* buffer){
   if (buffer)
   {
      WXNET_LOG_DEREF(buffer)
      return buffer->_sizeFilled;
   }
   return 0;
}


WXNET_EXPORT(unsigned char)
  ByteBuffer_at(const ByteBuffer* buffer, size_t index){
   if (buffer && index < buffer->_sizeFilled)
   {
      WXNET_LOG_DEREF(buffer)
      return buffer->_buffer[index];
   }
   return 0;
}


WXNET_EXPORT(void)
  ByteBuffer_atSet(ByteBuffer* buffer, size_t index, unsigned char byte){
   if (buffer && index < buffer->_sizeReserved)
   {
      WXNET_LOG_DEREF(buffer)
      buffer->_buffer[index]=byte;
      if (index >= buffer->_sizeFilled) buffer->_sizeFilled=index+1;
   }
}

WXNET_EXPORT(const unsigned char*)
   ByteBuffer_ptrToBuffer(const ByteBuffer* buffer)
{
   if (buffer)
      return buffer->_buffer;
   else 
      return 0;
}

//-----------------------------------------------------------------------------


WXNET_EXPORT(wxArrayInt*)
  wxArrayInt_ctor()
{
	return WXNET_NEW( wxArrayInt, ());
}

WXNET_EXPORT(void)
  wxArrayInt_dtor(wxArrayInt* self)
{
	WXNET_DEL( self );
}

WXNET_EXPORT(void)
  wxArrayInt_Add(wxArrayInt* self, int toadd)
{
   if (self)
   {
      WXNET_LOG_DEREF(self)
	   self->Add(toadd);
   }
}

WXNET_EXPORT(int)
  wxArrayInt_Item(wxArrayInt* self, int num)
{
   if (self)
   {
      WXNET_LOG_DEREF(self)
   	return self->Item(num);
   }
   else
      return 0;
}

WXNET_EXPORT(int)
  wxArrayInt_GetCount(wxArrayInt* self)
{
   if (self)
   {
      WXNET_LOG_DEREF(self)
   	return self->GetCount();
   }
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void**)
  wxArrayIntPtr_ctor(int length)
{
   return WXNET_NEW(void*,[length]);
}

WXNET_EXPORT(void)
  wxArrayIntPtr_dtor(void** self)
{
   WXNET_DEL(self);
}

WXNET_EXPORT(void)
  wxArrayIntPtr_Set(void** self, int pos, void* value)
{
   WXNET_LOG_DEREF(self);
   WXNET_LOG_DEREF(value);
   if (self && value)
      self[pos]=value;
}

WXNET_EXPORT(void*)
  wxArrayIntPtr_Get(void** self, int pos)
{
   WXNET_LOG_DEREF(self);
   if (self)
      return self[pos];
   return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxArrayString*)
  wxArrayString_ctor()
{
	return WXNET_NEW( wxArrayString, ());
}

WXNET_EXPORT(void)
  wxArrayString_dtor(wxArrayString* self)
{
	WXNET_DEL( self );
}

WXNET_EXPORT(void)
  wxArrayString_Add(wxArrayString* self, const wxString* toadd)
{
   if (self && toadd)
   {
      WXNET_LOG_DEREF(self)
      WXNET_LOG_DEREFSTR(toadd)
	   self->Add(*toadd);
   }
}

WXNET_EXPORT(int)
  wxArrayString_Index(wxArrayString* self, const wxString* sz, char bCase, char bFromEnd)
{
   if (self && sz)
   {
      WXNET_LOG_DEREF(self)
      WXNET_LOG_DEREFSTR(sz)
      return self->Index(*sz, bCase!=0, bFromEnd!=0);
   }
   else
      return -1;
}

WXNET_EXPORT(void)
  wxArrayString_Remove(wxArrayString* self, const wxString* sz)
{
   if (self && sz)
   {
      WXNET_LOG_DEREF(self)
      WXNET_LOG_DEREFSTR(sz)
      self->Remove(*sz);
   }
}

WXNET_EXPORT(void)
  wxArrayString_RemoveAt(wxArrayString* self, int pos)
{
   if (self)
   {
      WXNET_LOG_DEREF(self)
      self->RemoveAt(pos);
   }
}

WXNET_EXPORT(void)
  wxArrayString_Clear(wxArrayString* self)
{
   if (self)
   {
      WXNET_LOG_DEREF(self)
	   self->Clear();
   }
}

WXNET_EXPORT(void)
  wxArrayString_Sort(wxArrayString* self, char inReversedOrder)
{
   if (self)
   {
      WXNET_LOG_DEREF(self)
	   self->Sort(inReversedOrder != 0);
   }
}

WXNET_EXPORT(wxString*)
  wxArrayString_Item(wxArrayString* self, int num)
{
   if (self)
   {
      WXNET_LOG_DEREF(self)
	   return WXNET_NEW( wxString, (self->Item(num)));
   }
   else
      return NULL;
}

WXNET_EXPORT(int)
  wxArrayString_GetCount(wxArrayString* self)
{
   if (self)
   {
      WXNET_LOG_DEREF(self)
	   return self->GetCount();
   }
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxSleep_func(int num)
{
	wxSleep(num);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxYield_func()
{
    return wxYield()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxBeginBusyCursor_func()
{
	// currently only the standard wxHOURGLASS_CURSOR
	wxBeginBusyCursor();
}

WXNET_EXPORT(void)
  wxEndBusyCursor_func()
{
	wxEndBusyCursor();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxWindowDisabler*)
  wxWindowDisabler_ctor(wxWindow* winToSkip)
{
	return WXNET_NEW( wxWindowDisabler, (winToSkip));
}

WXNET_EXPORT(void)
  wxWindowDisabler_dtor(wxWindowDisabler* self)
{
	WXNET_DEL( self );
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxBusyInfo*)
  wxBusyInfo_ctor(const wxString* message, wxWindow* parent)
{
   if (message)
	   return WXNET_NEW( wxBusyInfo, (*message, parent));
   else
      return 0;
}

WXNET_EXPORT(void)
  wxBusyInfo_dtor(wxBusyInfo* self)
{
	WXNET_DEL( self );
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxMutexGuiEnter_func()
{
		wxMutexGuiEnter();
}

WXNET_EXPORT(void)
  wxMutexGuiLeave_func()
{
	wxMutexGuiLeave();
}

//-----------------------------------------------------------------------------
// wxSize

WXNET_EXPORT(wxSize*)
  wxSize_ctor(int x, int y)
{
	return WXNET_NEW( wxSize, (x, y));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxSize_dtor(wxSize* self)
{
	WXNET_DEL( self );
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxSize_SetWidth(wxSize* self, int w)
{
   if (self)
   {
      WXNET_LOG_DEREF(self)
	   self->SetWidth(w);
   }
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxSize_SetHeight(wxSize* self, int h)
{
   if (self)
   {
      WXNET_LOG_DEREF(self)
   	self->SetHeight(h);
   }
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxSize_GetWidth(wxSize* self)
{
   if (self)
   {
      WXNET_LOG_DEREF(self)
	   return self->GetWidth();
   }
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxSize_GetHeight(wxSize* self)
{
   if (self)
   {
      WXNET_LOG_DEREF(self)
	   return self->GetHeight();
   }
   else
      return 0;
}

//-----------------------------------------------------------------------------
// wxRect

class _Rect : public wxRect
{
public:
	DECLARE_DISPOSABLE(_Rect)
	_Rect(int x, int y, int w, int h)
		: wxRect(x, y, w, h)
   {
      m_onDispose=0;
   }
};

WXNET_EXPORT(_Rect*)
  wxRect_ctor(int x, int y, int w, int h)
{
	return WXNET_NEW( _Rect, (x, y, w, h));
}

WXNET_EXPORT(void)
  wxRect_dtor(wxRect* self)
{
	WXNET_DEL( self );
}

WXNET_EXPORT(void)
  wxRect_RegisterDisposable(_Rect* self, Virtual_Dispose onDispose)
{
   if (self)
   {
      WXNET_LOG_DEREF(self)
	   self->RegisterDispose(onDispose);
   }
}

WXNET_EXPORT(int)
  wxRect_GetX(wxRect* self)
{
   if (self)
   {
      WXNET_LOG_DEREF(self)
	   return self->GetX();
   }
   else
      return 0;
}

WXNET_EXPORT(void)
  wxRect_SetX(wxRect* self, int x)
{
   if (self)
   {
      WXNET_LOG_DEREF(self)
   	self->SetX(x);
   }
}

WXNET_EXPORT(int)
  wxRect_GetY(wxRect* self)
{
   if (self)
   {
      WXNET_LOG_DEREF(self)
	   return self->GetY();
   }
   else
      return 0;
}

WXNET_EXPORT(void)
  wxRect_SetY(wxRect* self, int y)
{
   if (self)
   {
      WXNET_LOG_DEREF(self)
	   self->SetY(y);
   }
}

WXNET_EXPORT(int)
  wxRect_GetWidth(wxRect* self)
{
   if (self)
   {
      WXNET_LOG_DEREF(self)
	   return self->GetWidth();
   }
   else
      return 0;
}

WXNET_EXPORT(void)
  wxRect_SetWidth(wxRect* self, int w)
{
   if (self)
   {
      WXNET_LOG_DEREF(self)
   	self->SetWidth(w);
   }
}

WXNET_EXPORT(int)
  wxRect_GetHeight(wxRect* self)
{
   if (self)
   {
      WXNET_LOG_DEREF(self)
	   return self->GetHeight();
   }
   else
      return 0;
}

WXNET_EXPORT(void)
  wxRect_SetHeight(wxRect* self, int h)
{
   if (self)
   {
      WXNET_LOG_DEREF(self)
	   self->SetHeight(h);
   }
}

//-----------------------------------------------------------------------------
// wxPoint

WXNET_EXPORT(wxPoint*)
  wxPoint_ctor(int x, int y)
{
   return WXNET_NEW( wxPoint, (x, y));
}

WXNET_EXPORT(int)
  wxPoint_GetX(const wxPoint* self)
{
   if (self)
   {
      WXNET_LOG_DEREF(self)
      return self->x;
   }
   else
      return -1;
}

WXNET_EXPORT(void)
  wxPoint_SetX(wxPoint* self, int x)
{
   if (self)
   {
      WXNET_LOG_DEREF(self)
      self->x=x;
   }
}

WXNET_EXPORT(int)
  wxPoint_GetY(const wxPoint* self)
{
   if (self)
   {
      WXNET_LOG_DEREF(self)
      return self->y;
   }
   else
      return -1;
}

WXNET_EXPORT(void)
  wxPoint_SetY(wxPoint* self, int y)
{
   if (self)
   {
      WXNET_LOG_DEREF(self)
      self->y=y;
   }
}

