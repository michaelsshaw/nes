//-----------------------------------------------------------------------------
// wx.NET - updateuievent.cxx
//
// The wxUpdateUIEvent proxy interface.
//
// Written by Jason Perkins (jason@379.com)
// (C) 2003 by 379, Inc.
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: updateuievent.cxx,v 1.6 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include "wxnet_globals.h"

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxUpdateUIEvent*)
  wxUpdateUIEvent_ctor(wxWindowID commandId)
{
	return new wxUpdateUIEvent(commandId);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxUpdateUIEvent_CanUpdate(wxWindow* window)
{
	return wxUpdateUIEvent::CanUpdate(window)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxUpdUIEvt_Enable(wxUpdateUIEvent* self, bool enable)
{
	self->Enable(enable);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxUpdUIEvt_Check(wxUpdateUIEvent* self, bool check)
{
	self->Check(check);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxUpdateUIEvent_GetChecked(wxUpdateUIEvent* self)
{
	return self->GetChecked()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxUpdateUIEvent_GetEnabled(wxUpdateUIEvent* self)
{
	return self->GetEnabled()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxUpdateUIEvent_GetSetChecked(wxUpdateUIEvent* self)
{
	return self->GetSetChecked()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxUpdateUIEvent_GetSetEnabled(wxUpdateUIEvent* self)
{
	return self->GetSetEnabled()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxUpdateUIEvent_GetSetText(wxUpdateUIEvent* self)
{
	return self->GetSetText()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxUpdateUIEvent_GetText(wxUpdateUIEvent* self)
{
	return new wxString(self->GetText());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxUpdateUIMode)
  wxUpdateUIEvent_GetMode()
{
	return wxUpdateUIEvent::GetMode();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxUpdateUIEvent_GetUpdateInterval()
{
	return wxUpdateUIEvent::GetUpdateInterval();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxUpdateUIEvent_ResetUpdateTime()
{
	wxUpdateUIEvent::ResetUpdateTime();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxUpdateUIEvent_SetMode(wxUpdateUIMode mode)
{
	wxUpdateUIEvent::SetMode(mode);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxUpdateUIEvent_SetText(wxUpdateUIEvent* self, const wxString* text)
{
   if (self && text)
	   self->SetText(*text);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxUpdateUIEvent_SetUpdateInterval(int updateInterval)
{
	wxUpdateUIEvent::SetUpdateInterval(updateInterval);
}


