//-----------------------------------------------------------------------------
// wx.NET - togglebutton.cxx
//
// The wxToggleButton proxy interface.
//
// Written by Florian Fankhauser (f.fankhauser@gmx.at)
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: togglebutton.cxx,v 1.7 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/tglbtn.h>
#include "local_events.h"

//-----------------------------------------------------------------------------

class _ToggleButton : public wxToggleButton
{
public:
    DECLARE_OBJECTDELETED(_ToggleButton)
};

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxToggleButton*)
  wxToggleButton_ctor()
{
	return new _ToggleButton();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxToggleButton_Create(wxToggleButton *self, wxWindow* parent, wxWindowID id, const wxString* labelArg, int x, int y, int width, int height, unsigned int style, const wxValidator* validator, const wxString* nameArg)
{
	if (validator == NULL)
		validator = &wxDefaultValidator;

   wxString name;
	if (nameArg == NULL)
		name = wxT("check");
   else
      name=*nameArg;
   wxString label;
   if (labelArg)
      label=*labelArg;

	return self->Create(parent, id, label, wxPoint(x, y), wxSize(width, height), style, *validator, name);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxToggleButton_GetValue(wxToggleButton* self)
{
	return self->GetValue()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxToggleButton_SetValue(wxToggleButton* self, const bool state)
{
	self->SetValue(state);
}

