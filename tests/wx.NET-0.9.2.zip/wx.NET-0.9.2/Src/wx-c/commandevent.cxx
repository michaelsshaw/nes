//-----------------------------------------------------------------------------
// wx.NET - commandevent.cxx
//
// The wxCommandEvent proxy interface.
//
// Written by Jason Perkins (jason@379.com)
// (C) 2003 by 379, Inc.
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: commandevent.cxx,v 1.11 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#ifndef WXNET_GLOBAL_H
#include "wxnet_globals.h"
#endif

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxCommandEvent*)
  wxCommandEvent_CTor(int evtType, int id)
{
   return new wxCommandEvent(evtType, id);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxCommandEvent_GetSelection(wxCommandEvent* self)
{
	return self->GetSelection();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(const wxString*)
  wxCommandEvent_GetString(wxCommandEvent* self)
{
	return new wxString(self->GetString());
}

WXNET_EXPORT(void)
  wxCommandEvent_SetString(wxCommandEvent* self, const wxString* s)
{
   if (self && s)
	   self->SetString(*s);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxCommandEvent_IsChecked(wxCommandEvent* self)
{
	return self->IsChecked()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxCommandEvent_IsSelection(wxCommandEvent* self)
{
	return self->IsSelection()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxCommandEvent_GetInt(wxCommandEvent* self)
{
	return self->GetInt();
}

WXNET_EXPORT(void)
  wxCommandEvent_SetInt(wxCommandEvent* self, int i)
{
	self->SetInt(i);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxClientData*)
  wxCommandEvent_GetClientObject(wxCommandEvent* self)
{
   if (self)
    return (wxClientData*)self->GetClientObject();
   else
      return 0;
}

WXNET_EXPORT(void)
  wxCommandEvent_SetClientObject(wxCommandEvent* self, wxClientData* data)
{
   if (self)
    self->SetClientObject(data);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxCommandEvent_SetExtraLong(wxCommandEvent* self, int extralong)
{
	self->SetExtraLong(extralong);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxCommandEvent_GetExtraLong(wxCommandEvent* self)
{
	return self->GetExtraLong();
}

