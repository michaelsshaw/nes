//-----------------------------------------------------------------------------
// wx.NET - reflect.cxx
//
// This file provides functions exposing the configuration of the
// used wxWidgets configuration.
//
// (C) 2007 by Harald Meyer auf'm Hofe
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: reflectconfig.cxx,v 1.5 2010/06/16 18:10:12 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include "wxnet_globals.h"

WXNET_EXPORT(char)
  ReflectConfig_CheckWxMSW(void)
{
#ifdef __WXMSW__
    return true;
#else
    return false;
#endif
}

WXNET_EXPORT(char)
  ReflectConfig_CheckWxMAC(void)
{
#ifdef __WXMAC__
    return true;
#else
    return false;
#endif
}

WXNET_EXPORT(char)
  ReflectConfig_CheckWxGTK(void)
{
#ifdef __WXGTK__
    return true;
#else
    return false;
#endif
}

WXNET_EXPORT(char)
  ReflectConfig_CheckUseUnicode(void)
{
#if wxUSE_UNICODE
# ifdef _MSC_VER
# pragma message ("Using Unicode encoding")
#elif __GNUC__
#warning Using Unicode encoding
# endif
    return true;
#else
# ifdef _MSC_VER
# pragma message ("Using ANSI encoding")
# elif __GNUC__
# warning Using ANSI encoding.
# endif
    return false;
#endif
}

WXNET_EXPORT(char)
  ReflectConfig_CheckWxWinCompatibility26(void)
{
#if WXWIN_COMPATIBILITY_2_6
# ifdef _MSC_VER
# pragma message ("Compiling in compatibility mode with wxWidgets Version 2.6.X")
# elif __GNUC__
# warning Compiling in compatibility mode with wxWidgets Version 2.6.X.
# endif
    return true;
#else
    return false;
#endif
}

WXNET_EXPORT(char)
  ReflectConfig_CheckWxWinCompatibility24(void)
{
#if WXWIN_COMPATIBILITY_2_4
# ifdef _MSC_VER
# pragma message ("Compiling in compatibility mode with wxWidgets Version 2.4.X")
# elif __GNUC__
# warning Compiling in compatibility mode with wxWidgets Version 2.4.X.
# endif
    return true;
#else
    return false;
#endif
}

WXNET_EXPORT(char)
  ReflectConfig_CheckWxWinVersion28(void)
{
#if wxCHECK_VERSION(2, 8, 0)
# ifdef _MSC_VER
# pragma message ("Compiling with wxWidgets Version 2.8.X")
# elif __GNUC__
# warning Compiling with wxWidgets Version 2.8.X.
# endif
    return true;
#else
    return false;
#endif
}

WXNET_EXPORT(char)
  ReflectConfig_CheckWxWinVersion26(void)
{
#if wxCHECK_VERSION(2, 6, 0)
# ifdef _MSC_VER
# pragma message ("Compiling with wxWidgets Version 2.6.X")
# elif __GNUC__
# warning Compiling with wxWidgets Version 2.6.X.
# endif
    return true;
#else
    return false;
#endif
}

WXNET_EXPORT(char)
  ReflectConfig_CheckUseTabDialog(void)
{
#ifdef __WXMSW__
# if wxUSE_TAB_DIALOG
#  ifdef _MSC_VER
#  pragma message ("Using tab dialog: wxUSE_TAB_DIALOG")
#  elif __GNUC__
#  warning Using tab dialog: wxUSE_TAB_DIALOG
#  endif
    return true;
# else
    return false;
# endif
#else
    return false;
#endif
}


