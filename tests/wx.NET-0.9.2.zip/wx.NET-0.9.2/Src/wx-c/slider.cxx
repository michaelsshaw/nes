//-----------------------------------------------------------------------------
// wx.NET - slider.cxx
//
// The wxSlider proxy interface
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 by Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: slider.cxx,v 1.10 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/slider.h>
#include "local_events.h"

//-----------------------------------------------------------------------------

class _Slider : public wxSlider
{
public:
    DECLARE_OBJECTDELETED(_Slider)
};

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxSlider*)
  wxSlider_ctor()
{
	return new _Slider();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxSlider_Create(wxSlider* self, wxWindow *parent, wxWindowID id, int value, int minValue, int maxValue, int posX, int posY, int width, int height, unsigned int style, const wxValidator* validator, const wxString* nameArg)
{
   wxString name;		
	if (nameArg == NULL)
		name = wxT("slider");
   else
      name=*nameArg;

	if (validator == NULL)
	{
		return self->Create(parent, id, value, minValue, maxValue, wxPoint(posX, posY), wxSize(width, height), style, wxDefaultValidator, name);
	}

	return self->Create(parent, id, value, minValue, maxValue, wxPoint(posX, posY), wxSize(width, height), style, *validator, name);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxSlider_GetValue(wxSlider* self)
{
	return self->GetValue();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxSlider_SetValue(wxSlider* self, int value)
{
	self->SetValue(value);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxSlider_SetRange(wxSlider* self, int minValue, int maxValue)
{
	self->SetRange(minValue, maxValue);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxSlider_GetMin(wxSlider* self)
{
	return self->GetMin();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxSlider_GetMax(wxSlider* self)
{
	return self->GetMax();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxSlider_SetLineSize(wxSlider* self, int lineSize)
{
	self->SetLineSize(lineSize);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxSlider_SetPageSize(wxSlider* self, int pageSize)
{
	self->SetPageSize(pageSize);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxSlider_GetLineSize(wxSlider* self)
{
	return self->GetLineSize();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxSlider_GetPageSize(wxSlider* self)
{
	return self->GetPageSize();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxSlider_SetThumbLength(wxSlider* self, int lenPixels)
{
	self->SetThumbLength(lenPixels);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxSlider_GetThumbLength(wxSlider* self)
{
	return self->GetThumbLength();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxSlider_SetTickFreq(wxSlider* self, int n, int pos)
{
	self->SetTickFreq(n, pos);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxSlider_GetTickFreq(wxSlider* self)
{
	return self->GetTickFreq();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxSlider_ClearTicks(wxSlider* self)
{
	self->ClearTicks();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxSlider_SetTick(wxSlider* self, int tickPos)
{
	self->SetTick(tickPos);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxSlider_ClearSel(wxSlider* self)
{
	self->ClearSel();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxSlider_GetSelEnd(wxSlider* self)
{
	return self->GetSelEnd();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxSlider_GetSelStart(wxSlider* self)
{
	return self->GetSelStart();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxSlider_SetSelection(wxSlider* self, int min, int max)
{
	self->SetSelection(min, max);
}

