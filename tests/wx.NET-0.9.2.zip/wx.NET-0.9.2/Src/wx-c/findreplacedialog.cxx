//-----------------------------------------------------------------------------
// wx.NET - findreplacedialog.cxx
//
// The wxFindReplaceDialog proxy interface.
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 by Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: findreplacedialog.cxx,v 1.8 2009/02/13 21:48:49 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/fdrepdlg.h>
#include "local_events.h"

//-----------------------------------------------------------------------------

class _FindReplaceDialog : public wxFindReplaceDialog
{
public:
    DECLARE_OBJECTDELETED(_FindReplaceDialog)
};

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxFindReplaceDialog*)
  wxFindReplaceDialog_ctor()
{
    return new _FindReplaceDialog();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxFindReplaceDialog_Create(wxFindReplaceDialog* self, wxWindow* parent, wxFindReplaceData* data, const wxString* titleArg, unsigned int style)
{
   wxString title;
   if (titleArg)
      title=*titleArg;
    return self->Create(parent, data, title, style);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxFindReplaceData*)
  wxFindReplaceDialog_GetData(wxFindReplaceDialog* self)
{
    return (wxFindReplaceData*)self->GetData();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxFindReplaceDialog_SetData(wxFindReplaceDialog* self, wxFindReplaceData* data)
{
    self->SetData(data);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxFindDialogEvent*)
  wxFindDialogEvent_ctor(wxEventType commandType, int id)
{
    return new wxFindDialogEvent(commandType, id);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxFindDialogEvent_GetFlags(wxFindDialogEvent* self)
{
    return self->GetFlags();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxFindDialogEvent_GetFindString(wxFindDialogEvent* self)
{
    return new wxString(self->GetFindString());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxFindDialogEvent_GetReplaceString(wxFindDialogEvent* self)
{
    return new wxString(self->GetReplaceString());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxFindReplaceDialog*)
  wxFindDialogEvent_GetDialog(wxFindDialogEvent* self)
{
    return self->GetDialog();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxFindDialogEvent_SetFlags(wxFindDialogEvent* self, int flags)
{
    self->SetFlags(flags);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxFindDialogEvent_SetFindString(wxFindDialogEvent* self, const wxString* str)
{
   if (self && str)
    self->SetFindString(*str);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxFindDialogEvent_SetReplaceString(wxFindDialogEvent* self, const wxString* str)
{
   if (self && str)
    self->SetReplaceString(*str);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxFindReplaceData*)
  wxFindReplaceData_ctor(wxUint32 flags)
{
    return new wxFindReplaceData(flags);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxFindReplaceData_GetFindString(wxFindReplaceData* self)
{
    return new wxString(self->GetFindString());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxFindReplaceData_GetReplaceString(wxFindReplaceData* self)
{
    return new wxString(self->GetReplaceString());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxFindReplaceData_GetFlags(wxFindReplaceData* self)
{
    return self->GetFlags();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxFindReplaceData_SetFlags(wxFindReplaceData* self, wxUint32 flags)
{
    self->SetFlags(flags);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxFindReplaceData_SetFindString(wxFindReplaceData* self, const wxString* str)
{
   if (self && str)
    self->SetFindString(*str);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxFindReplaceData_SetReplaceString(wxFindReplaceData* self, const wxString* str)
{
   if (self && str)
    self->SetReplaceString(*str);
}

//-----------------------------------------------------------------------------

