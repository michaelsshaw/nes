//-----------------------------------------------------------------------------
// wx.NET - wizard.cxx
//
// The wxWizard proxy interface.
//
// Written by Jason Perkins (jason@379.com)
// (C) 2003 by 379, Inc.
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: wizard.cxx,v 1.8 2009/01/06 18:24:22 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/wizard.h>
#include "local_events.h"

//-----------------------------------------------------------------------------

class _Wizard : public wxWizard
{
public:
	_Wizard(wxWindow* parent, wxWindowID id, const wxString& title,
			const wxBitmap& bitmap, const wxPoint& pos)
		: wxWizard(parent, id, title, bitmap, pos) { }

    DECLARE_OBJECTDELETED(_Wizard)
};

//-----------------------------------------------------------------------------
// C stubs for class methods

WXNET_EXPORT(wxWizard*)
  wxWizard_ctor(wxWindow* parent, int id, const wxString* titleArg, const wxBitmap* bitmap, int posX, int posY)
{
	if (bitmap == NULL)
		bitmap = &wxNullBitmap;
   wxString title(wxT("Wizard"));
   if (titleArg)
      title=*titleArg;

	return new _Wizard(parent, id, title, *bitmap, wxPoint(posX, posY));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxWizard_RunWizard(wxWizard* self, wxWizardPage* firstPage)
{
   if (self)
	   return self->RunWizard(firstPage);
   else
      return false;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWizard_SetPageSize(wxWizard* self, const wxSize* size)
{
   if (self && size)
	   self->SetPageSize(*size);
}

//-----------------------------------------------------------------------------
// the wizard event


WXNET_EXPORT(char) wxWizardEvent_GetDirection(const wxWizardEvent* self)
{
   if (self)
      return self->GetDirection();
   else
      return false;
}

WXNET_EXPORT(wxWizardPage*) wxWizardEvent_GetPage(const wxWizardEvent* self)
{
   if (self)
      return self->GetPage();
   else
      return NULL;
}
