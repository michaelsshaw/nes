//-----------------------------------------------------------------------------
// wx.NET - image.cxx
//
// The wxImage proxy interface.
//
// Written by Jason Perkins (jason@379.com)
// (C) 2003 by 379, Inc.
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: image.cxx,v 1.18 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/image.h>
#include <wx/mstream.h>
#include "local_events.h"

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxImage*)
  wxImage_ctor()
{
	return new wxImage();
}

WXNET_EXPORT(wxImage*)
  wxImage_ctorByName(const wxString* name, int type)
{
   if (name)
	   return new wxImage(*name, type);
   else
      return NULL;
}

WXNET_EXPORT(wxImage*)
  wxImage_ctorByByteArray(const char* data /* this is in fact an array of bytes*/, int length, int type)
{
	wxMemoryInputStream* image_stream;
	
	image_stream = new wxMemoryInputStream(data, length);

	return new wxImage(*image_stream, type);
}

WXNET_EXPORT(wxImage*)
  wxImage_ctorintintbool(int width, int height, bool clear)
{
	return new wxImage(width, height, clear);
}

WXNET_EXPORT(wxImage*) wxImage_ctorByImage(wxImage* image)
{
#if wxCHECK_VERSION(2, 8, 0)
   if (image)
	   return new wxImage(*image);
   else
      return NULL;
#else
   if (image)
	   return new wxImage(*image);
   else
      return NULL;
#endif
}

WXNET_EXPORT(void)
  wxImage_dtor(wxImage* self)
{
	WXNET_DEL( self );
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxImage_Destroy(wxImage* self)
{
	self->Destroy();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxImage_GetHeight(wxImage* self)
{
	return self->GetHeight();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxImage_GetWidth(wxImage* self)
{
	return self->GetWidth();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxImage_InitAllHandlers()
{
	wxInitAllImageHandlers();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxImage_LoadFileByTypeId(wxImage* self, const wxString* name, int type, int index)
{
   if (self && name)
	   return self->LoadFile(*name, type, index);
   else
      return 0;
}

WXNET_EXPORT(char)
  wxImage_LoadFileByMimeTypeId(wxImage* self, const wxString* name, const wxString* mimetype, int index)
{
   if (self && name && mimetype)
	   return self->LoadFile(*name, *mimetype, index);
   else
      return 0;
}


WXNET_EXPORT(char)
  wxImage_SaveFileByType(wxImage* self, const wxString* name, int type)
{
   if (self && name)
    return self->SaveFile(*name, type);
   else
      return 0;
}

WXNET_EXPORT(char)
  wxImage_SaveFileByMimeType(wxImage* self, const wxString* name, const wxString* mimetype)
{
   if (self && name && mimetype)
    return self->SaveFile(*name, *mimetype);
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxImage*)
  wxImage_Rescale(wxImage* self, int width, int height)
{
	return new wxImage(self->Rescale(width, height));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxImage*)
  wxImage_Scale(wxImage* self, int width, int height)
{
	return new wxImage(self->Scale(width, height));

}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxImage_SetMaskColour(wxImage* self, unsigned char r, unsigned char g, unsigned char b)
{
    self->SetMaskColour(r, g, b);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxImage_SetMask(wxImage* self, bool mask)
{
    self->SetMask(mask);
}

WXNET_EXPORT(char)
  wxImage_HasMask(wxImage* self)
{
    return self->HasMask()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxImage*)
  wxImage_Copy(wxImage* self)
{
	return new wxImage(self->Copy());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxImage*)
  wxImage_GetSubImage(wxImage* self, int x, int y, int w, int h)
{
	return new wxImage(self->GetSubImage(wxRect(x, y, w, h)));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxImage_Paste(wxImage* self, wxImage* image, int x, int y)
{
	self->Paste(*image, x, y);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxImage*)
  wxImage_ShrinkBy(wxImage* self, int xFactor, int yFactor)
{
	return new wxImage(self->ShrinkBy(xFactor, yFactor));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxImage*)
  wxImage_Rotate(wxImage* self, double angle, wxPoint* centre_of_rotation, bool interpolating, wxPoint* offset_after_rotation)
{
	return new wxImage(self->Rotate(angle, *centre_of_rotation, interpolating, offset_after_rotation));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxImage*)
  wxImage_Rotate90(wxImage* self, bool clockwise)
{
	return new wxImage(self->Rotate90(clockwise));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxImage*)
  wxImage_Mirror(wxImage* self, bool horizontally)
{
	return new wxImage(self->Mirror(horizontally));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxImage_Replace(wxImage* self, unsigned char r1, unsigned char g1, unsigned char b1, unsigned char r2, unsigned char g2, unsigned char b2)
{
	self->Replace(r1, g1, b1, r2, g2, b2);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxImage*)
  wxImage_ConvertToMono(wxImage* self, unsigned char r, unsigned char g, unsigned char b)
{
	return new wxImage(self->ConvertToMono(r, g, b));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxImage_SetRGB(wxImage* self, int x, int y, unsigned char r, unsigned char g, unsigned char b)
{
	self->SetRGB(x, y, r, g, b);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(unsigned char)
  wxImage_GetRed(wxImage* self, int x, int y)
{
	return self->GetRed(x, y);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(unsigned char)
  wxImage_GetGreen(wxImage* self, int x, int y)
{
	return self->GetGreen(x, y);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(unsigned char)
  wxImage_GetBlue(wxImage* self, int x, int y)
{
	return self->GetBlue(x, y);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxImage_SetAlpha(wxImage* self, int x, int y, unsigned char alpha)
{
	self->SetAlpha(x, y, alpha);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(unsigned char)
  wxImage_GetAlpha(wxImage* self, int x, int y)
{
	return self->GetAlpha(x, y);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxImage_FindFirstUnusedColour(wxImage* self, unsigned char* r, unsigned char* g, unsigned char* b, unsigned char startR, unsigned char startG, unsigned char startB)
{
	return self->FindFirstUnusedColour(r, g, b, startR, startG, startB)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxImage_SetMaskFromImage(wxImage* self, wxImage* mask, unsigned char mr, unsigned char mg, unsigned char mb)
{
	return self->SetMaskFromImage(*mask, mr, mg, mb)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxImage_ConvertAlphaToMask(wxImage* self, unsigned char threshold)
{
	return self->ConvertAlphaToMask(threshold)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxImage_CanRead(const wxString* name)
{
   if (name)
	   return wxImage::CanRead(*name)?1:0;
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxImage_GetImageCount(const wxString* name, int type)
{
   if (name)
	   return wxImage::GetImageCount(*name, type);
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxImage_Ok(wxImage* self)
{
	return self->Ok()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(unsigned char)
  wxImage_GetMaskRed(wxImage* self)
{
	return self->GetMaskRed();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(unsigned char)
  wxImage_GetMaskGreen(wxImage* self)
{
	return self->GetMaskGreen();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(unsigned char)
  wxImage_GetMaskBlue(wxImage* self)
{
	return self->GetMaskBlue();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxImage_HasPalette(wxImage* self)
{
	return self->HasPalette()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxPalette*)
  wxImage_GetPalette(wxImage* self)
{
	return new wxPalette(self->GetPalette());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxImage_SetPalette(wxImage* self, wxPalette* palette)
{
	self->SetPalette(*palette);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxImage_SetOption(wxImage* self, const wxString* name, const wxString* value)
{
   if (self && name && value)
	   self->SetOption(*name, *value);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxImage_SetOption2(wxImage* self, const wxString* name, int value)
{
   if (self && name)
	   self->SetOption(*name, value);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxImage_GetOption(wxImage* self, const wxString* name)
{
   if (self && name)
	   return new wxString(self->GetOption(*name));
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxImage_GetOptionInt(wxImage* self, const wxString* name)
{
   if (self && name)
	   return self->GetOptionInt(*name);
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxImage_HasOption(wxImage* self, const wxString* name)
{
	return self->HasOption(*name);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(unsigned long)
  wxImage_CountColours(wxImage* self, unsigned long stopafter)
{
	return self->CountColours(stopafter);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(unsigned long)
  wxImage_ComputeHistogram(wxImage* self, wxImageHistogram* h)
{
	return self->ComputeHistogram(*h);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(const wxNode*)
  wxImage_GetFirstHandlerNode(void)
{
	return wxImage::GetHandlers().GetFirst();
}

WXNET_EXPORT(wxObject*)
  wxNode_GetData(const wxNode* node)
{
   if (node)
      return dynamic_cast< wxObject* >(node->GetData());
   else
      return NULL;
}

WXNET_EXPORT(const wxNode*)
  wxNode_GetNext(const wxNode* node)
{
   if (node)
      return node->GetNext();
   else
      return NULL;
}

WXNET_EXPORT(const wxNode*)
  wxNode_GetPrevious(const wxNode* node)
{
   if (node)
      return node->GetPrevious();
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxImage_AddHandler(wxImageHandler* handler)
{
	wxImage::AddHandler(handler);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxImage_InsertHandler(wxImageHandler* handler)
{
	wxImage::InsertHandler(handler);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxImage_RemoveHandler(const wxString* name)
{
   if (name)
	   return wxImage::RemoveHandler(*name);
   return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxImageHandler*)
  wxImage_FindHandler(const wxString* name)
{
   if (name)
	   return wxImage::FindHandler(*name);
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxImageHandler*)
  wxImage_FindHandler2(const wxString* name, int imageType)
{
   if (name)
	   return wxImage::FindHandler(*name, imageType);
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxImageHandler*)
  wxImage_FindHandler3(int imageType)
{
	return wxImage::FindHandler(imageType);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxImageHandler*)
  wxImage_FindHandlerMime(const wxString* mimetype)
{
	return wxImage::FindHandlerMime(*mimetype);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxImage_GetImageExtWildcard()
{
	return new wxString(wxImage::GetImageExtWildcard());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxImage_CleanUpHandlers()
{
	wxImage::CleanUpHandlers();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxImage_InitStandardHandlers()
{
	wxImage::InitStandardHandlers();
}

//-----------------------------------------------------------------------------
// wxImageHandler


WXNET_EXPORT(void)
  wxImageHandler_SetName(wxImageHandler* self, const wxString* name)
{
   if (self && name)
   	self->SetName(*name);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxImageHandler_SetExtension(wxImageHandler* self, const wxString* ext)
{
   if (self && ext)
	   self->SetExtension(*ext);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxImageHandler_SetType(wxImageHandler* self, int type)
{
	self->SetType(type);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxImageHandler_SetMimeType(wxImageHandler* self, const wxString* type)
{
   if (self && type)
	   self->SetMimeType(*type);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxImageHandler_GetName(wxImageHandler* self)
{
	return new wxString(self->GetName());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxImageHandler_GetExtension(wxImageHandler* self)
{
	return new wxString(self->GetExtension());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxImageHandler_GetType(wxImageHandler* self)
{
	return self->GetType();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxImageHandler_GetMimeType(wxImageHandler* self)
{
	return new wxString(self->GetMimeType());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxImageHandler_CanReadFilename(wxImageHandler* self, const wxString* filename)
{
   if (self && filename)
      return self->CanRead(*filename);
   return false;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxImageHandler_CanReadBuffer(wxImageHandler* self, const unsigned char* bytestring, size_t size)
{
   if (self && bytestring && size)
   {
      wxMemoryInputStream stream(bytestring, size);
      return self->CanRead(stream);
   }
   return false;
}


//-----------------------------------------------------------------------------
// wxImageHistogramEntry

WXNET_EXPORT(wxImageHistogramEntry*)
  wxImageHistogramEntry_ctor()
{
	return new wxImageHistogramEntry();
}

WXNET_EXPORT(void)
  wxImageHistogramEntry_dtor(wxImageHistogramEntry* self)
{
	WXNET_DEL( self );
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(unsigned long)
  wxImageHistogramEntry_index(wxImageHistogramEntry* self)
{
	return self->index;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxImageHistogramEntry_Setindex(wxImageHistogramEntry* self, unsigned long v)
{
	self->index=v;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(unsigned long)
  wxImageHistogramEntry_value(wxImageHistogramEntry* self)
{
	return self->value;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxImageHistogramEntry_Setvalue(wxImageHistogramEntry* self, unsigned long v)
{
	self->value=v;
}

//-----------------------------------------------------------------------------
// wxImageHistogram

WXNET_EXPORT(wxImageHistogram*)
  wxImageHistogram_ctor()
{
	return new wxImageHistogram();
}

WXNET_EXPORT(void)
  wxImageHistogram_dtor(wxImageHistogram* self)
{
	WXNET_DEL( self );
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(unsigned long)
  wxImageHistogram_MakeKey(unsigned char r, unsigned char g, unsigned char b)
{
		return wxImageHistogram::MakeKey(r, g, b);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxImageHistogram_FindFirstUnusedColour(wxImageHistogram* self, unsigned char* r, unsigned char* g, unsigned char*b, unsigned char startR, unsigned char startG, unsigned char startB)
{
	return self->FindFirstUnusedColour(r, g, b, startR, startG, startB)?1:0;
}
