//-----------------------------------------------------------------------------
// wx.NET - Object.cs
//
// The wxObject wrapper class.
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: object.cxx,v 1.16 2008/12/25 17:01:35 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>

// this has to be used because of reimplemented dynamic type info
#include <wx/grid.h>
#include <wx/generic/gridctrl.h>

#include "local_events.h"

#define CLASSNAME(name) \
	(new wxString(CLASSINFO(name)->GetClassName()))

#define OBJECTNAME(obj) \
	(new wxString(obj->GetClassInfo()->GetClassName()))

//-----------------------------------------------------------------------------

// Utility function to grab the C++ typename of a given pointer to a class.
WXNET_EXPORT(const wxString*)
  wxObject_GetTypeName(wxObject* obj)
{
   if (obj)
	   return OBJECTNAME(obj);
   else
      return NULL;
}

//-----------------------------------------------------------------------------

extern wxClassInfo wxGridCellNumberEditor_ms_classInfo; 
extern wxClassInfo wxGridCellFloatEditor_ms_classInfo; 
extern wxClassInfo wxGridCellTextEditor_ms_classInfo; 
extern wxClassInfo wxGridCellEnumEditor_ms_classInfo; 
extern wxClassInfo wxGridCellChoiceEditor_ms_classInfo; 
extern wxClassInfo wxGridCellEditor_ms_classInfo;

WXNET_EXPORT(wxClassInfo*)
  wxObject_GetClassInfo(wxObject* obj)
{
   // Exceptional implementation.
   return obj->GetClassInfo();
}

WXNET_EXPORT(wxString*)
  wxClassInfo_GetName(wxClassInfo* self)
{
   if (self)
      return new wxString(self->GetClassName());
   else
      return NULL;
}

WXNET_EXPORT(wxString*)
  wxClassInfo_GetBaseClassName1(wxClassInfo* self)
{
   if (self)
   {
      const wxChar* result=self->GetBaseClassName1();
      if (result)
         return new wxString(result);
      else
         return NULL;
   }
   else
      return NULL;
}

WXNET_EXPORT(wxString*)
  wxClassInfo_GetBaseClassName2(wxClassInfo* self)
{
   if (self)
   {
      const wxChar* result=self->GetBaseClassName2();
      if (result)
         return new wxString(result);
      else
         return NULL;
   }
   else
      return NULL;
}

WXNET_EXPORT(int)
  wxClassInfo_GetSize(wxClassInfo* self)
{
   if (self)
      return self->GetSize();
   else
      return 0;
}


//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxObject_dtor(wxObject* self)
{
    WXNET_DEL( self );
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxGetTranslation_func(const wxString* str)
{
  if (str)
    return new wxString(wxGetTranslation(*str));
  else
    return 0;
}

