//-----------------------------------------------------------------------------
// wx.NET - xmlresource.cxx
//
// The wxXmlResource proxy interface.
//
// Written by Achim Breunig (achim.breunig@web.de)
// (C) 2003 Achim Breunig
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: xmlresource.cxx,v 1.12 2010/06/06 08:54:49 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/xrc/xmlres.h>
#include <wx/fontenum.h>
#include <wx/fs_mem.h>
#include "local_events.h"

//-----------------------------------------------------------------------------
// C stubs for class methods

typedef wxObject* (CALLBACK* XmlSubclassCreate) (wxString*);

class XmlSubclassFactoryCS : public wxXmlSubclassFactory
{
public:
    XmlSubclassFactoryCS() { }

    wxObject *Create(const wxString& className)
        { return m_create(new wxString(className)); }

    void RegisterVirtual(XmlSubclassCreate create)
        { m_create = create; }

private:
    XmlSubclassCreate m_create;
};

WXNET_EXPORT(void)
  wxXmlSubclassFactory_ctor(XmlSubclassCreate create)
{
    XmlSubclassFactoryCS *s_factory = new XmlSubclassFactoryCS();
    s_factory->RegisterVirtual(create);
    wxXmlResource::AddSubclassFactory(s_factory);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxXmlResource*)
  wxXmlResource_ctorByFilemask(const wxString* filemask, int flags = wxXRC_USE_LOCALE)
{
   if (filemask)
	   return new wxXmlResource(*filemask,flags);
   else
      return NULL;
}

WXNET_EXPORT(wxXmlResource*)
  wxXmlResource_ctor(int flags)
{
	return new wxXmlResource(flags);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxXmlResource_InitAllHandlers(wxXmlResource* self)
{
	self->InitAllHandlers();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxXmlResource_Load(wxXmlResource* self, const wxString* filemask)
{
   if (self && filemask)
	   return self->Load(*filemask);
   else
      return false;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxXmlResource_LoadFromByteArray(wxXmlResource* self, const wxString* filemask, char* data, size_t length)
{
   if (filemask)
   {
	   wxFileSystem::AddHandler(new wxMemoryFSHandler());
	   wxMemoryFSHandler::AddFile(*filemask, data, length);

	   wxString mem_name = wxString(wxT("memory:")) + *filemask;

	   return self->Load(mem_name);
   }
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxDialog*)
  wxXmlResource_LoadDialog(wxXmlResource* self, wxWindow* parent, const wxString* name)
{
   if (self && name)
	   return self->LoadDialog(parent, *name);
   else
      return NULL;
}

WXNET_EXPORT(char)
  wxXmlResource_LoadDialogDlg(wxXmlResource* self, wxDialog* dlg, wxWindow* parent, const wxString* name)
{
   if (self && name)
	   return self->LoadDialog(dlg, parent, *name);
   else
      return false;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxXmlResource_GetXRCID(const wxString* str_id)
{
   if (str_id)
	   return wxXmlResource::GetXRCID(*str_id);
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxXmlResource_GetVersion(wxXmlResource* self)
{
	return self->GetVersion();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxXmlResource_LoadFrameWithFrame(wxXmlResource* self, wxFrame* frame, wxWindow* parent, const wxString* name)
{
   if (self && name)
	   return self->LoadFrame(frame, parent, *name);
   else 
      return 0;
}

WXNET_EXPORT(wxFrame*)
  wxXmlResource_LoadFrame(wxXmlResource* self, wxWindow* parent, const wxString* name)
{
   if (self && name)
	   return self->LoadFrame(parent, *name);
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxBitmap*)
  wxXmlResource_LoadBitmap(wxXmlResource* self, const wxString* name)
{
   if (self && name)
	   return new wxBitmap(self->LoadBitmap(*name));
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxIcon*)
  wxXmlResource_LoadIcon(wxXmlResource* self, const wxString* name)
{
   if (self && name)
	   return new wxIcon(self->LoadIcon(*name));
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxMenu*)
  wxXmlResource_LoadMenu(wxXmlResource* self, const wxString* name)
{
   if (self && name)
	   return self->LoadMenu(*name);
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxMenuBar*)
  wxXmlResource_LoadMenuBarWithParent(wxXmlResource* self, wxWindow* parent, const wxString* name)
{
   if (self && name)
	   return self->LoadMenuBar(parent, *name);
   else
      return NULL;
}

WXNET_EXPORT(wxMenuBar*)
  wxXmlResource_LoadMenuBar(wxXmlResource* self, const wxString* name)
{
   if (self && name)
	   return self->LoadMenuBar(*name);
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxXmlResource_LoadPanelWithPanel(wxXmlResource* self, wxPanel* panel, wxWindow* parent, const wxString* name)
{
   if (self && name)
	   return self->LoadPanel(panel, parent, *name);
   else
      return 0;
}

WXNET_EXPORT(wxPanel*)
  wxXmlResource_LoadPanel(wxXmlResource* self, wxWindow* parent, const wxString* name)
{
   if (self && name)
	   return self->LoadPanel(parent, *name);
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxToolBar*)
  wxXmlResource_LoadToolBar(wxXmlResource* self, wxWindow* parent, const wxString* name)
{
   if (self && name)
	   return self->LoadToolBar(parent, *name);
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxXmlResource_SetFlags(wxXmlResource* self, int flags)
{
	self->SetFlags(flags);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxXmlResource_GetFlags(wxXmlResource* self)
{
	return self->GetFlags();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxXmlResource_CompareVersion(wxXmlResource* self, int major, int minor, int release, int revision)
{
	return self->CompareVersion(major, minor, release, revision);
}

//-----------------------------------------------------------------------------

/*
WXNET_EXPORT(void)
  wxXmlResource_UpdateResources(wxXmlResource* self)
{
	self->UpdateResources();
}
*/

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxXmlResource_AttachUnknownControl(wxXmlResource* self, const wxString* name, wxWindow* control, wxWindow* parent)
{
   if (self && name)
	   return self->AttachUnknownControl(*name, control, parent);
   else
      return 0;
}

