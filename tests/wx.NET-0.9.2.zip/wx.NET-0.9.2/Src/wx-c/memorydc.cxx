//-----------------------------------------------------------------------------
// wx.NET - memorydc.cxx
// 
// The wxBufferedDC and wxMemoryDC proxy interface.
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 by Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: memorydc.cxx,v 1.5 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/dcbuffer.h>
#include <wx/dcmemory.h>
#ifndef WXNET_GLOBAL_H
#include "wxnet_globals.h"
#endif

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxMemoryDC*)
  wxMemoryDC_ctor()
{
	return new wxMemoryDC();
}

WXNET_EXPORT(wxMemoryDC*)
  wxMemoryDC_ctorByDC(wxDC *dc)
{
	return new wxMemoryDC(dc);
}

//-----------------------------------------------------------------------------

#if wxCHECK_VERSION(2, 8, 0)
WXNET_EXPORT(void)
  wxMemoryDC_SelectObject(wxMemoryDC* self, wxBitmap& bitmap)
{
	self->SelectObject(bitmap);
}
#else
WXNET_EXPORT(void)
  wxMemoryDC_SelectObject(wxMemoryDC* self, const wxBitmap* bitmap)
{
	self->SelectObject(*bitmap);
}
#endif

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxBufferedDC*)
  wxBufferedDC_ctor()
{
	return new wxBufferedDC();
}

#if wxCHECK_VERSION(2, 8, 0)
WXNET_EXPORT(wxBufferedDC*)
  wxBufferedDC_ctorByBitmap(wxDC *dc, wxBitmap &buffer)
{
	return new wxBufferedDC(dc, buffer);
}
#else
WXNET_EXPORT(wxBufferedDC*)
  wxBufferedDC_ctorByBitmap(wxDC *dc, const wxBitmap *buffer)
{
	return new wxBufferedDC(dc, *buffer);
}
#endif

WXNET_EXPORT(wxBufferedDC*)
  wxBufferedDC_ctorBySize(wxDC *dc, const wxSize *area)
{
	return new wxBufferedDC(dc, *area);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxBufferedDC_InitByBitmap(wxBufferedDC* self, wxDC *dc, wxBitmap *bitmap)
{
	self->Init(dc, *bitmap);
}

WXNET_EXPORT(void)
  wxBufferedDC_InitBySize(wxBufferedDC* self, wxDC *dc, wxSize *area)
{
	self->Init(dc, *area);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxBufferedDC_UnMask(wxBufferedDC* self)
{
	self->UnMask();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxBufferedPaintDC*)
  wxBufferedPaintDC_ctor(wxWindow *window, wxBitmap *buffer)
{
	if (buffer == NULL)
		buffer = &wxNullBitmap;

	return new wxBufferedPaintDC(window, *buffer);
}

//-----------------------------------------------------------------------------

