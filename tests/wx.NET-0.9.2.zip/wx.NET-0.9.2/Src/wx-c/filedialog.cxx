//-----------------------------------------------------------------------------
// wx.NET - filedialog.cxx
//
// The wxFileDialog proxy interface.
//
// Written by Achim Breunig (Achim.Breunig@web.de)
// (C) 2003 by Achim Breunig
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: filedialog.cxx,v 1.12 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/filedlg.h>
#include "local_events.h"

//-----------------------------------------------------------------------------

class _FileDialog : public wxFileDialog
{
public:
        _FileDialog(wxWindow* parent, const wxString message, 
            const wxString& defaultDir, const wxString& defaultFile, 
            const wxString& wildcard, unsigned int style, const wxPoint& pos)
        : wxFileDialog(parent, message, defaultDir, defaultFile, wildcard, style, pos)
    {
    }

    DECLARE_OBJECTDELETED(_FileDialog)
};

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxFileDialog*)
  wxFileDialog_ctor(wxWindow* parent, const wxString* messageArg, 
            const wxString* defaultDirArg, const wxString* defaultFileArg, 
            const wxString* wildcardArg, unsigned int style, int posX, int posY)
{
   wxString message;
   if (messageArg==0)
      message=wxT("Choose a file.");
   else
      message=*messageArg;
   wxString defaultDir;
   if (defaultDirArg!=NULL)
      defaultDir=*defaultDirArg;
   wxString defaultFile;
   if (defaultFileArg!=NULL)
      defaultFile=*defaultFileArg;
   wxString wildcard;
   if (wildcardArg==NULL)
      wildcard=wxT("*.*");
   else
      wildcard=*wildcardArg;
    return new _FileDialog(parent, message, defaultDir, defaultFile, wildcard, style, wxPoint(posX, posY));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxFileDialog_dtor(wxFileDialog* self)
{
    WXNET_DEL(self);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxFileDialog_ShowModal(wxFileDialog* self)
{
    return self->ShowModal();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxFileDialog_GetDirectory(wxFileDialog* self)
{
    return new wxString(self->GetDirectory());
}

WXNET_EXPORT(void)
  wxFileDialog_SetDirectory(wxFileDialog* self, const wxString* dir)
{
   if (self && dir)
    self->SetDirectory(*dir);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxFileDialog_GetFilename(wxFileDialog* self)
{
    return new wxString(self->GetFilename());
}

WXNET_EXPORT(void)
  wxFileDialog_SetFilename(wxFileDialog* self, const wxString* filename)
{
   if (self && filename)
    self->SetFilename(*filename);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxFileDialog_GetPath(wxFileDialog* self)
{
    return new wxString(self->GetPath());
}

WXNET_EXPORT(void)
  wxFileDialog_SetPath(wxFileDialog* self, const wxString* path)
{
   if (self && path)
    self->SetPath(*path);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxFileDialog_SetFilterIndex(wxFileDialog *self, int filterindex)
{
    self->SetFilterIndex(filterindex);
}

WXNET_EXPORT(int)
  wxFileDialog_GetFilterIndex(wxFileDialog *self)
{
    return self->GetFilterIndex();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxFileDialog_SetMessage(wxFileDialog *self, const wxString* message)
{
   if (self && message)
    self->SetMessage(*message);
}

WXNET_EXPORT(wxString*)
  wxFileDialog_GetMessage(wxFileDialog *self)
{
    return new wxString(self->GetMessage());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxFileDialog_GetWildcard(wxFileDialog* self)
{
    return new wxString(self->GetWildcard());
}

WXNET_EXPORT(void)
  wxFileDialog_SetWildcard(wxFileDialog* self, const wxString* wildcard)
{
   if (self && wildcard)
    self->SetWildcard(*wildcard);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxFileDialog_SetStyle(wxFileDialog *self, unsigned int style)
{
#if wxCHECK_VERSION(2, 8, 0)
    self->SetWindowStyle(style);
#else
    self->SetStyle(style);
#endif
}

WXNET_EXPORT(int)
  wxFileDialog_GetStyle(wxFileDialog *self)
{
#if wxCHECK_VERSION(2, 8, 0)
    return self->wxWindow::GetWindowStyle();
#else    
    return self->GetStyle();
#endif
}

//-----------------------------------------------------------------------------
WXNET_EXPORT(wxArrayString*)
  wxFileDialog_GetPaths(wxFileDialog* self)
{
	wxArrayString* wai = new wxArrayString();
	self->GetPaths(*wai);
	return wai;
}

//-----------------------------------------------------------------------------
WXNET_EXPORT(wxArrayString*)
  wxFileDialog_GetFilenames(wxFileDialog* self)
{
    wxArrayString* wai = new wxArrayString();
    self->GetFilenames(*wai);
    return wai;
}

//-----------------------------------------------------------------------------


