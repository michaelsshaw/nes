//-----------------------------------------------------------------------------
// wx.NET - listctrl.cxx
//
// The wxListCtrl proxy interface
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 by Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/imaglist.h>
#include <wx/listctrl.h>
#include "local_events.h"

//-----------------------------------------------------------------------------

class _ListItemAttr : public wxListItemAttr
{
public:
	_ListItemAttr()
		: wxListItemAttr() {}
		
   _ListItemAttr(const wxListItemAttr& src)
      : wxListItemAttr(src)
   {
   }

	_ListItemAttr(const wxColour& colText,
                   const wxColour& colBack,
                   const wxFont& font)
		: wxListItemAttr(colText, colBack, font), m_onDispose(NULL) {}
		
	DECLARE_DISPOSABLE(_ListItemAttr)
};


typedef _DisposableStringBox* (CALLBACK* Callback_OnGetItemText)(int item, int col);
typedef int (CALLBACK* Callback_OnGetItemImage)(int item);
typedef int (CALLBACK* Callback_OnGetItemColumnImage)(int item, int column);
typedef _ListItemAttr* (CALLBACK* Callback_OnGetItemAttr)(int item);

class _ListCtrl : public wxListCtrl
{
   Callback_OnGetItemText m_OnGetItemText;
   Callback_OnGetItemImage m_OnGetItemImage;
   Callback_OnGetItemColumnImage m_OnGetItemColumnImage;
   Callback_OnGetItemAttr m_OnGetItemAttr;
public:
    DECLARE_OBJECTDELETED(_ListCtrl)

    _ListCtrl()
       : m_OnGetItemText(0), m_OnGetItemImage(0), m_OnGetItemColumnImage(0), m_OnGetItemAttr(0)
    {
    }

    void RegisterVirtual(Callback_OnGetItemText OnGetItemText, Callback_OnGetItemImage OnGetItemImage, Callback_OnGetItemColumnImage OnGetItemColumnImage, Callback_OnGetItemAttr OnGetItemAttr)
    {
      m_OnGetItemText=OnGetItemText;
      m_OnGetItemImage=OnGetItemImage;
      m_OnGetItemColumnImage=OnGetItemColumnImage;
      m_OnGetItemAttr=OnGetItemAttr;
    }

    virtual wxString OnGetItemText(long item, long column) const
    {
       if (m_OnGetItemText)
       {
          _DisposableStringBox* result=m_OnGetItemText((int)item, (int)column);
          return _DisposableStringBox::GetValAndDelete(result);
       }
       else
          return _DisposableStringBox::empty;
    }

    virtual int OnGetItemImage(long item) const
    {
       if (m_OnGetItemImage)
          return m_OnGetItemImage((int) item);
       else
          return -1;
    }

    virtual int OnGetItemColumnImage(long item, long column) const
    {
       if (m_OnGetItemColumnImage)
          return m_OnGetItemColumnImage((int) item, (int)column);
       else
          return -1;
    }

    virtual wxListItemAttr * OnGetItemAttr(long item) const
    {
       if (m_OnGetItemAttr)
       {
          return m_OnGetItemAttr((int) item);
       }
       else
          return NULL;
    }
};

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxListCtrl*)
  wxListCtrl_ctor()
{
    return new _ListCtrl();
}

WXNET_EXPORT(void)
  wxListCtrl_RegisterVirtual(_ListCtrl *self, Callback_OnGetItemText OnGetItemText, Callback_OnGetItemImage OnGetItemImage, Callback_OnGetItemColumnImage OnGetItemColumnImage, Callback_OnGetItemAttr OnGetItemAttr)
{
   if (self)
      self->RegisterVirtual(OnGetItemText, OnGetItemImage, OnGetItemColumnImage, OnGetItemAttr);
}

WXNET_EXPORT(char)
  wxListCtrl_Create(wxListCtrl *self, wxWindow *parent, wxWindowID id, int posX, int posY, int width, unsigned int height, int style, const wxValidator* validator, const wxString* nameArg)
{
    if (validator == NULL)
        validator = &wxDefaultValidator;

    wxString name;
    if (nameArg == NULL)
        name = wxT("listctrl");
    else
       name = *nameArg;

    return self->Create(parent, id, wxPoint(posX, posY), wxSize(width, height), style, *validator, name)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxListCtrl_dtor(wxListCtrl* self)
{
    WXNET_DEL( self );
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxListCtrl_GetColumn(wxListCtrl* self, int col, wxListItem* item)
{
    return self->GetColumn(col, *item)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxListCtrl_SetColumn(wxListCtrl* self, int col, wxListItem* item)
{
    return self->SetColumn(col, *item)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxListCtrl_GetColumnWidth(wxListCtrl* self, int col)
{
    return self->GetColumnWidth(col);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxListCtrl_SetColumnWidth(wxListCtrl* self, int col, int width)
{
    return self->SetColumnWidth(col, width)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxListCtrl_GetCountPerPage(wxListCtrl* self)
{
    return self->GetCountPerPage();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxListCtrl_GetItem(wxListCtrl* self, wxListItem* info)
{
   if (self && info)
    return self->GetItem(*info);
   else
      return false;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxListCtrl_SetItem(wxListCtrl* self, wxListItem* info)
{
    return self->SetItem(*info)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxListCtrl_SetItem_By_Row_Col(wxListCtrl* self, int index, int col, const wxString* label, int imageId)
{
   if (self && label)
    return self->SetItem(index, col, *label, imageId);
   else
      return 0;
}


//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxListCtrl_SetTextImageItem(wxListCtrl* self, int index, int col, const wxString* label, int imageId)
{
   if (self && label)
    return self->SetItem(index, col, *label, imageId);
   else
    return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxListCtrl_GetItemState(wxListCtrl* self, int item, int stateMask)
{
    return self->GetItemState(item, stateMask);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxListCtrl_SetItemState(wxListCtrl* self, int item, int state, int stateMask)
{
    return self->SetItemState(item, state, stateMask)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxListCtrl_SetItemImage(wxListCtrl* self, int item, int image, int selImage)
{
    return self->SetItemImage(item, image, selImage)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxListCtrl_GetItemText(wxListCtrl* self, int item)
{
    return new wxString(self->GetItemText(item));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxListCtrl_SetItemText(wxListCtrl* self, int item, const wxString* str)
{
   if (self && str)
    self->SetItemText(item, *str);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void*)
  wxListCtrl_GetItemData(wxListCtrl* self, int item) 	
{
    return (void*)self->GetItemData(item);
}

//-----------------------------------------------------------------------------
 
WXNET_EXPORT(char)
  wxListCtrl_SetItemData(wxListCtrl* self, int item, wxClientData* data)
{
    return self->SetItemData(item, (long)data)?1:0;
}

//-----------------------------------------------------------------------------
 
WXNET_EXPORT(char)
  wxListCtrl_SetItemData2(wxListCtrl* self, int item, int data)
{
    return self->SetItemData(item, data);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxListCtrl_GetItemRect(wxListCtrl* self, int item, wxRect* rect, int code)
{
    return self->GetItemRect(item, *rect, code)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxListCtrl_GetItemPosition(wxListCtrl* self, int item, wxPoint* pos)
{
    return self->GetItemPosition(item, *pos)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxListCtrl_SetItemPosition(wxListCtrl* self, int item, const wxPoint* pos)
{
    return self->SetItemPosition(item, *pos)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxListCtrl_GetItemCount(wxListCtrl* self)
{
    return self->GetItemCount();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxListCtrl_GetColumnCount(wxListCtrl* self)
{
    return self->GetColumnCount();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxListCtrl_SetItemTextColour(wxListCtrl* self, int item, const wxColour* col)
{
    self->SetItemTextColour(item, *col);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxColour*)
  wxListCtrl_GetItemTextColour(wxListCtrl* self, int item)
{
    return new wxColour(self->GetItemTextColour(item));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxListCtrl_SetItemBackgroundColour(wxListCtrl* self, int item, const wxColour *col)
{
    self->SetItemBackgroundColour(item, *col);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxColour*)
  wxListCtrl_GetItemBackgroundColour(wxListCtrl* self, int item)
{
    return new wxColour(self->GetItemBackgroundColour(item));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxListCtrl_GetSelectedItemCount(wxListCtrl* self)
{
    return self->GetSelectedItemCount();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxColour*)
  wxListCtrl_GetTextColour(wxListCtrl* self)
{
    return new wxColour(self->GetTextColour());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxListCtrl_SetTextColour(wxListCtrl* self, const wxColour* col)
{
    self->SetTextColour(*col);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxListCtrl_GetTopItem(wxListCtrl* self)
{
    return self->GetTopItem();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxListCtrl_SetSingleStyle(wxListCtrl* self, unsigned int style, bool add)
{
    self->SetSingleStyle(style, add);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxListCtrl_SetWindowStyleFlag(wxListCtrl* self, unsigned int style)
{
   if (self)
    self->SetWindowStyleFlag(style);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxListCtrl_GetNextItem(wxListCtrl* self, int item, int geometry, int state)
{
   if (self)
    return self->GetNextItem(item, geometry, state);
   else
      return -1;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxImageList*)
  wxListCtrl_GetImageList(wxListCtrl* self, int which)
{
    return self->GetImageList(which);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxListCtrl_SetImageList(wxListCtrl* self, wxImageList* imageList, int which)
{
    self->SetImageList(imageList, which);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxListCtrl_AssignImageList(wxListCtrl* self, wxImageList* imageList, int which)
{
    self->AssignImageList(imageList, which);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxListCtrl_Arrange(wxListCtrl* self, int flag)
{
    return self->Arrange(flag)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxListCtrl_ClearAll(wxListCtrl* self)
{
    self->ClearAll();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxListCtrl_DeleteItem(wxListCtrl* self, int item)
{
    return self->DeleteItem(item)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxListCtrl_DeleteAllItems(wxListCtrl* self)
{
    return self->DeleteAllItems()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxListCtrl_DeleteAllColumns(wxListCtrl* self)
{
    return self->DeleteAllColumns()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxListCtrl_DeleteColumn(wxListCtrl* self, int col)
{
    return self->DeleteColumn(col)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxListCtrl_SetItemCount(wxListCtrl* self, int count)
{
    self->SetItemCount(count);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxListCtrl_EditLabel(wxListCtrl* self, int item)
{
    self->EditLabel(item);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxListCtrl_EnsureVisible(wxListCtrl* self, int item)
{
    return self->EnsureVisible(item)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxListCtrl_FindItem(wxListCtrl* self, int start, const wxString* str, bool partial)
{
   if (self && str)
    return self->FindItem(start, *str, partial)?1:0;
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxListCtrl_FindItemData(wxListCtrl* self, int start, int data)
{
    return self->FindItem(start, data);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxListCtrl_FindItemPoint(wxListCtrl* self, int start, const wxPoint* pt, int direction)
{
    return self->FindItem(start, *pt, direction);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxListCtrl_HitTest(wxListCtrl* self, const wxPoint* point, int flags)
{
    return self->HitTest(*point, flags);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxListCtrl_InsertItem(wxListCtrl* self, wxListItem* info)
{
    return self->InsertItem(*info);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxListCtrl_InsertTextItem(wxListCtrl* self, int index, const wxString* label)
{
   if (self && label)
    return self->InsertItem(index, *label);
   return -1;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxListCtrl_InsertImageItem(wxListCtrl* self, int index, int imageIndex)
{
    return self->InsertItem(index, imageIndex);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxListCtrl_InsertTextImageItem(wxListCtrl* self, int index, const wxString* label, int imageIndex)
{
   if (self && label)
    return self->InsertItem(index, *label, imageIndex);
   else
      return -1;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxListCtrl_InsertColumn(wxListCtrl* self, int col, wxListItem* info)
{
    return self->InsertColumn(col, *info);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxListCtrl_InsertTextColumn(wxListCtrl* self, int col, const wxString* heading, int format, int width)
{
   if (self && heading)
    return self->InsertColumn(col, *heading, format, width);
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxListCtrl_ScrollList(wxListCtrl* self, int dx, int dy)
{
    return self->ScrollList(dx, dy)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxListCtrl_SortItems(wxListCtrl* self, wxListCtrlCompare fn, int data)
{
    return self->SortItems(fn, data)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxListCtrl_GetViewRect(wxListCtrl* self, wxRect* rect)
{
	*rect=self->GetViewRect();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxListCtrl_RefreshItem(wxListCtrl* self, int item)
{
	self->RefreshItem(item);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxListCtrl_RefreshItems(wxListCtrl* self, int itemFrom, int itemTo)
{
	self->RefreshItems(itemFrom, itemTo);
}

//-----------------------------------------------------------------------------
// wxListItem

WXNET_EXPORT(wxListItem*)
  wxListItem_ctor()
{
    return new wxListItem();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxListItem_Clear(wxListItem* self)
{
    self->Clear();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxListItem_ClearAttributes(wxListItem* self)
{
	self->ClearAttributes();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxListItem_GetAlign(wxListItem* self)
{
    return self->GetAlign();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxColour*)
  wxListItem_GetBackgroundColour(wxListItem* self)
{
    return new wxColour(self->GetBackgroundColour());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxListItem_GetColumn(wxListItem* self)
{
    return self->GetColumn();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void*)
  wxListItem_GetData(wxListItem* self)
{
    return (void*)self->GetData();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxFont*)
  wxListItem_GetFont(wxListItem* self)
{
    return new wxFont(self->GetFont());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxListItem_GetId(wxListItem* self)
{
    return self->GetId();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxListItem_GetImage(wxListItem* self)
{
    return self->GetImage();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxListItem_GetMask(wxListItem* self)
{
    return self->GetMask();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxListItem_GetState(wxListItem* self)
{
    return self->GetState();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxListItem_GetText(wxListItem* self)
{
    return new wxString(self->GetText());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxColour*)
  wxListItem_GetTextColour(wxListItem* self)
{
    return new wxColour(self->GetTextColour());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxListItem_GetWidth(wxListItem* self)
{
    return self->GetWidth();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxListItem_SetAlign(wxListItem* self, int align)
{
    self->SetAlign((wxListColumnFormat)align);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxListItem_SetBackgroundColour(wxListItem* self, wxColour* col)
{
    self->SetBackgroundColour(*col);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxListItem_SetColumn(wxListItem* self, int col)
{
    self->SetColumn(col);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxListItem_SetData(wxListItem* self, wxClientData* data)
{
	self->SetData((long)data);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxListItem_SetFont(wxListItem* self, wxFont* font)
{
    self->SetFont(*font);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxListItem_SetId(wxListItem* self, int id)
{
    self->SetId(id);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxListItem_SetImage(wxListItem* self, int image)
{
    self->SetImage(image);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxListItem_SetMask(wxListItem* self, int mask)
{
    self->SetMask(mask);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxListItem_SetState(wxListItem* self, int state)
{
    self->SetState(state);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxListItem_SetStateMask(wxListItem* self, int stateMask)
{
    self->SetStateMask(stateMask);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxListItem_SetText(wxListItem* self, const wxString* text)
{
   if (self && text)
    self->SetText(*text);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxListItem_SetTextColour(wxListItem* self, wxColour* col)
{
    self->SetTextColour(*col);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxListItem_SetWidth(wxListItem* self, int width)
{
    self->SetWidth(width);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(_ListItemAttr*)
  wxListItem_GetAttributes(wxListItem* self)
{
   if (self && self->GetAttributes())
	   return new _ListItemAttr(*self->GetAttributes());
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxListItem_HasAttributes(wxListItem* self)
{
	return self->HasAttributes()?1:0;
}

//----------------------------------------------------------------------------
// wxListEvent

WXNET_EXPORT(wxListEvent*)
  wxListEvent_ctor(wxEventType commandType, int id)
{
    return new wxListEvent(commandType, id);
}

//----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxListEvent_GetCacheFrom(wxListEvent* self)
{
    return self->GetCacheFrom();
}
//----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxListEvent_GetCacheTo(wxListEvent* self)
{
    return self->GetCacheTo();
}
//----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxListEvent_GetKeyCode(wxListEvent* self)
{
    return self->GetKeyCode();
}
//----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxListEvent_GetIndex(wxListEvent* self)
{
    return self->GetIndex();
}
//----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxListEvent_GetColumn(wxListEvent* self)
{
    return self->GetColumn();
}
//----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxListEvent_IsEditCancelled(wxListEvent* self)
{
    return self->IsEditCancelled()?1:0;
}

//----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxListEvent_SetEditCanceled(wxListEvent* self, bool editCancelled)
{
    self->SetEditCanceled(editCancelled);
}

//----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxListEvent_GetLabel(wxListEvent* self)
{
    return new wxString(self->GetLabel());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxListEvent_GetPoint(wxListEvent* self, wxPoint* pt)
{
    *pt = self->GetPoint();
}

//-----------------------------------------------------------------------------
WXNET_EXPORT(int)
  wxListEvent_GetImage(wxListEvent* self)
{
    return self->GetImage();
}

//-----------------------------------------------------------------------------


WXNET_EXPORT(wxString*)
  wxListEvent_GetText(wxListEvent* self)
{
    return new wxString(self->GetText());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxListEvent_GetMask(wxListEvent* self)
{
    return self->GetMask();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxListItem*)
  wxListEvent_GetItem(wxListEvent* self)
{
    return new wxListItem(self->GetItem());
}

WXNET_EXPORT(void*)
  wxListEvent_GetData(wxListEvent* self)
{
	return (void*)self->GetData();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxListEvent_Veto(wxListEvent* self)
{
    self->Veto();
}

WXNET_EXPORT(void)
  wxListEvent_Allow(wxListEvent* self)
{
    self->Allow();
}

WXNET_EXPORT(char)
  wxListEvent_IsAllowed(wxListEvent* self)
{
    return self->IsAllowed()?1:0;
}

//-----------------------------------------------------------------------------
// wxListView

class _ListView : public wxListView
{
public:
    DECLARE_OBJECTDELETED(_ListView)
};

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxListView*)
  wxListView_ctor()
{
    return new _ListView();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxListView_Create(wxListCtrl *self, wxWindow *parent, wxWindowID id, int posX, int posY, int width , int height, unsigned int style, const wxValidator* validator, const wxString* nameArg)
{
    if (validator == NULL)
        validator = &wxDefaultValidator;

    wxString name;
    if (nameArg == NULL)
        name = wxT("listview");
    else
       name = *nameArg;

    return self->Create(parent, id, wxPoint(posX, posY), wxSize(width, height), style, *validator, name)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxListView_Select(wxListView* self, int n, bool on)
{
	self->Select(n, on);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxListView_Focus(wxListView* self, int index)
{
	self->Focus(index);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxListView_GetFocusedItem(wxListView* self)
{
	return self->GetFocusedItem();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxListView_GetNextSelected(wxListView* self, int item)
{
	return self->GetNextSelected(item);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxListView_GetFirstSelected(wxListView* self)
{
	return self->GetFirstSelected();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxListView_IsSelected(wxListView* self, int index)
{
	return self->IsSelected(index);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxListView_SetColumnImage(wxListView* self, int col, int image)
{
	self->SetColumnImage(col, image);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxListView_ClearColumnImage(wxListView* self, int col)
{
	self->ClearColumnImage(col);
}

//-----------------------------------------------------------------------------
// wxListItemAttr

//-----------------------------------------------------------------------------

WXNET_EXPORT(_ListItemAttr*)
  wxListItemAttr_ctor()
{
	return new _ListItemAttr();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(_ListItemAttr*)
  wxListItemAttr_ctor2(wxColour* colText, wxColour* colBack, wxFont* font)
{
	return new _ListItemAttr(*colText, *colBack, *font);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxListItemAttr_dtor(_ListItemAttr* self)
{
	WXNET_DEL( self );
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxListItemAttr_RegisterDisposable(_ListItemAttr* self, Virtual_Dispose onDispose)
{
   if (self)
	   self->RegisterDispose(onDispose);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxListItemAttr_SetTextColour(_ListItemAttr* self, wxColour* colText)
{
	self->SetTextColour(*colText);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxListItemAttr_SetBackgroundColour(_ListItemAttr* self, wxColour* colBack)
{
	self->SetBackgroundColour(*colBack);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxListItemAttr_SetFont(_ListItemAttr* self, wxFont* font)
{
   if (self && font)
	self->SetFont(*font);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxListItemAttr_HasTextColour(_ListItemAttr* self)
{
	return self->HasTextColour()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxListItemAttr_HasBackgroundColour(_ListItemAttr* self)
{
	return self->HasBackgroundColour()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxListItemAttr_HasFont(_ListItemAttr* self)
{
	return self->HasFont()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxColour*)
  wxListItemAttr_GetTextColour(_ListItemAttr* self)
{
	return new wxColour(self->GetTextColour());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxColour*)
  wxListItemAttr_GetBackgroundColour(_ListItemAttr* self)
{
	return new wxColour(self->GetBackgroundColour());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxFont*)
  wxListItemAttr_GetFont(_ListItemAttr* self)
{
	return new wxFont(self->GetFont());
}

