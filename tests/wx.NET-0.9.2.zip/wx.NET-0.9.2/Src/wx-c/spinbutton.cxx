//-----------------------------------------------------------------------------
// wx.NET - spinbutton.cxx
//
// The wxSpinButton proxy interface
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 by Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: spinbutton.cxx,v 1.10 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/spinbutt.h>
#include "local_events.h"

//-----------------------------------------------------------------------------

class _SpinButton : public wxSpinButton
{
public:
    DECLARE_OBJECTDELETED(_SpinButton)
};

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxSpinButton*)
  wxSpinButton_ctor()
{
	return new _SpinButton();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxSpinButton_Create(wxSpinButton* self, wxWindow *parent, wxWindowID id, int posX, int posY, int width, int height, unsigned int style, const wxString* nameArg)
{
   wxString name;
	if (nameArg == NULL)
		name = wxT("spinbutton");
   else
      name=*nameArg;

	return self->Create(parent, id, wxPoint(posX, posY), wxSize(width, height), style, name);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxSpinButton_GetValue(wxSpinButton* self)
{
	return self->GetValue();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxSpinButton_GetMin(wxSpinButton* self)
{
	return self->GetMin();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxSpinButton_GetMax(wxSpinButton* self)
{
	return self->GetMax();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxSpinButton_SetValue(wxSpinButton* self, int val)
{
	self->SetValue(val);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxSpinButton_SetRange(wxSpinButton* self, int minVal, int maxVal)
{
	self->SetRange(minVal, maxVal);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxSpinEvent*)
  wxSpinEvent_ctor(wxEventType commandType, int id)
{
    return new wxSpinEvent(commandType, id);
}

WXNET_EXPORT(int)
  wxSpinEvent_GetPosition(wxSpinEvent* self)
{
    return self->GetPosition();
}

WXNET_EXPORT(void)
  wxSpinEvent_SetPosition(wxSpinEvent* self, int pos)
{
    self->SetPosition(pos);
}

WXNET_EXPORT(void)
  wxSpinEvent_Veto(wxSpinEvent* self)
{
    self->Veto();
}

WXNET_EXPORT(void)
  wxSpinEvent_Allow(wxSpinEvent* self)
{
    self->Allow();
}

WXNET_EXPORT(bool)
  wxSpinEvent_IsAllowed(wxSpinEvent* self)
{
    return self->IsAllowed()?1:0;
}
