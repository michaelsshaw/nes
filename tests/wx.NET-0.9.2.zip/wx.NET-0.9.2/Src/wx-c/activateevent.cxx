//-----------------------------------------------------------------------------
// wx.NET - activateevent.cxx
// 
// The wxActivateEvent proxy interface.
//
// Written by Alexander Olk (xenomorph2@onlinehome.de)
// (C) 2004 by Alexander Olk
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// activateevent.cxx,v 1.5 2008/12/25 17:01:35 harald_meyer Exp
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#ifndef WXNET_GLOBAL_H
#include "wxnet_globals.h"
#endif

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxActivateEvent*)
  wxActivateEvent_ctor(wxEventType type)
{
    return new wxActivateEvent(type);
}

WXNET_EXPORT(bool)
  wxActivateEvent_GetActive(wxActivateEvent* self)
{
	return self->GetActive()?1:0;
}
