//-----------------------------------------------------------------------------
// wx.NET - html.cxx
//
// The wxHTML proxy interface.
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 by Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// Fixes to wxHtmlWidgetCell by Harald Meyer auf'm Hofe (P) 2007
//
// $Id: html.cxx,v 1.38 2010/02/21 17:38:34 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/html/htmlwin.h>
#include <wx/html/htmlproc.h>
#include <wx/html/htmprint.h>
#include "local_events.h"

// CALLBACK MAY BE ALREADY DEFINED
#ifndef CALLBACK 
# if defined(_WINDOWS)
#  define CALLBACK __stdcall
# else
#  define CALLBACK
# endif
#endif

//-----------------------------------------------------------------------------

typedef void (CALLBACK* Virtual_OnLinkClicked) (wxHtmlLinkInfo* );
typedef void (CALLBACK* Virtual_OnSetTitle) (wxString* );
typedef void (CALLBACK* Virtual_OnCellMouseHover) (wxHtmlCell*, wxCoord, wxCoord);
typedef bool (CALLBACK* Virtual_OnCellClicked) (wxHtmlCell*, wxCoord, wxCoord, wxMouseEvent*);
typedef wxHtmlOpeningStatus (CALLBACK* Virtual_OnOpeningURL) (wxHtmlURLType, wxString*, wxString*);
typedef int (CALLBACK* Virtual_LoadFile) (const wxString* filename);
typedef int (CALLBACK* Virtual_LoadPage) (const wxString* location);

class _HtmlWindow : public wxHtmlWindow
{
public:
	_HtmlWindow()
		: wxHtmlWindow(),
      m_OnLinkClicked(NULL),
		m_OnSetTitle(NULL),
		m_OnCellMouseHover(NULL),
		m_OnCellClicked(NULL),
		m_OnOpeningURL(NULL),
      m_LoadFile(NULL),
      m_LoadPage(NULL)
   {}

	_HtmlWindow(wxWindow *parent, wxWindowID id, const wxPoint& pos, const wxSize& size, unsigned int style, const wxString& name)
		: wxHtmlWindow(parent, id, pos, size, style, name),
      m_OnLinkClicked(NULL),
		m_OnSetTitle(NULL),
		m_OnCellMouseHover(NULL),
		m_OnCellClicked(NULL),
		m_OnOpeningURL(NULL),
      m_LoadFile(NULL),
      m_LoadPage(NULL)
    {}

   /** Additional method to select cells.
   * \c fromCell and \c lastCell may be the same cell. Otherwise,
   * leafs of \c fromCell must be before those of \c lastCell when traversing
   * the HTML document.
   */
   void SelectCells(wxHtmlCell* fromCell, wxHtmlCell* lastCell);

	void OnLinkClicked(const wxHtmlLinkInfo& link)
	{ if (m_OnLinkClicked)
         m_OnLinkClicked(WXNET_NEW( wxHtmlLinkInfo, (link)) );
     else
        wxHtmlWindow::OnLinkClicked(link);
   }
	
	void OnSetTitle(const wxString& title)
	{
      if (m_OnSetTitle)
         m_OnSetTitle(WXNET_NEW( wxString, (title)));
      else
         wxHtmlWindow::OnSetTitle(title);
   }
	
	void OnCellMouseHover(wxHtmlCell* cell, wxCoord x, wxCoord y)
	{ 
      if (m_OnCellMouseHover)
         m_OnCellMouseHover(cell, x, y);
      else
         wxHtmlWindow::OnCellMouseHover(cell, x, y);
   }

#if wxCHECK_VERSION(2, 8, 0)
	bool OnCellClicked(wxHtmlCell* cell, wxCoord x, wxCoord y, const wxMouseEvent& evt)
	{
      return m_OnCellClicked(cell, x, y, WXNET_NEW( wxMouseEvent, (evt))); 
   }
   /** Work around protected scope.
   */
   bool OnCellClickedOrig(wxHtmlCell* cell, wxCoord x, wxCoord y, const wxMouseEvent& evt)
   {
      return wxHtmlWindow::OnCellClicked(cell, x, y, evt);
   }
#else
	void OnCellClicked(wxHtmlCell* cell, wxCoord x, wxCoord y, const wxMouseEvent& evt)
	{
      m_OnCellClicked(cell, x, y, WXNET_NEW( wxMouseEvent, (event)));
   }
   /** Work around protected scope.
   */
   void OnCellClickedOrig(wxHtmlCell* cell, wxCoord x, wxCoord y, const wxMouseEvent& evt)
   {
      wxHtmlWindow::OnCellClicked(cell, x, y, evt);
   }
#endif
	

	wxHtmlOpeningStatus OnOpeningURL(wxHtmlURLType type, const wxString& url, wxString * redirect) const
	{
      if (m_OnOpeningURL)
         return m_OnOpeningURL(type, WXNET_NEW( wxString, (url)), redirect);
      else
         return wxHtmlWindow::OnOpeningURL(type, url, redirect);
   }

   virtual bool LoadFile(const wxFileName& filename)
   {
      if (m_LoadFile)
         return m_LoadFile(WXNET_NEW( wxString, (filename.GetFullPath())))>0;
      else
         return wxHtmlWindow::LoadFile(filename);
   }

   virtual bool LoadPage(const wxString& location)
   {
      if (m_LoadPage)
         return m_LoadPage(WXNET_NEW( wxString, (location)) )>0;
      else
         return wxHtmlWindow::LoadPage(location);
   }

	void RegisterVirtual(Virtual_OnLinkClicked onLinkClicked, 
		Virtual_OnSetTitle onSetTitle,
		Virtual_OnCellMouseHover onCellMouseHover,
		Virtual_OnCellClicked onCellClicked,
		Virtual_OnOpeningURL onOpeningURL,
      Virtual_LoadFile loadFile,
      Virtual_LoadPage loadPage)
	{
		m_OnLinkClicked = onLinkClicked;
		m_OnSetTitle = onSetTitle;
		m_OnCellMouseHover = onCellMouseHover;
		m_OnCellClicked = onCellClicked;
		m_OnOpeningURL = onOpeningURL;
      m_LoadFile = loadFile;
      m_LoadPage = loadPage;
	}

    bool HasSelection() const
    {
       return m_selection && m_selection->GetFromPos() != m_selection->GetToPos();
    }
    wxHtmlCell* GetSelectionFromCell() const
    {
       if (m_selection)
          return (wxHtmlCell*) m_selection->GetFromCell();
       return NULL;
    }

    wxHtmlCell* GetSelectionToCell() const
    {
       if (m_selection)
          return (wxHtmlCell*) m_selection->GetToCell();
       return NULL;
    }

    // these values are in absolute coordinates:
    void ReadSelectionFromPos(int* posX, int* posY) const
    {
       if (m_selection)
       {
          if (posX)
             *posX=m_selection->GetFromPos().x;
          if (posY)
             *posY=m_selection->GetFromPos().y;
       }
    }
    void ReadSelectionToPos(int* posX, int* posY) const
    {
       if (m_selection)
       {
          if (posX)
             *posX=m_selection->GetToPos().x;
          if (posY)
             *posY=m_selection->GetToPos().y;
       }
    }

private:
	Virtual_OnLinkClicked m_OnLinkClicked;
	Virtual_OnSetTitle m_OnSetTitle;
	Virtual_OnCellMouseHover m_OnCellMouseHover;
	Virtual_OnCellClicked m_OnCellClicked;
	Virtual_OnOpeningURL m_OnOpeningURL;
   Virtual_LoadFile m_LoadFile;
   Virtual_LoadPage m_LoadPage;
	
public:
	DECLARE_OBJECTDELETED(_HtmlWindow)
};

void _HtmlWindow::SelectCells(wxHtmlCell* fromCell, wxHtmlCell* lastCell)
{
    if ( m_Cell )
    {
        if ( fromCell && lastCell )
        {
            bool wasSelected=false;
            if (m_selection)
            {
               delete m_selection;
               wasSelected=true;
            }
            m_selection = new wxHtmlSelection();
            wxHtmlCell* start=fromCell;
            wxHtmlCell* end=lastCell;
            wxHtmlCell* firstLeaf=fromCell->GetFirstTerminal();
            if (firstLeaf)
               start=firstLeaf;
            wxHtmlCell* lastLeaf=lastCell->GetLastTerminal();
            if (lastLeaf)
               end=lastLeaf;
            m_selection->Set(start, end);
            Refresh();
        }
    }
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxHtmlWindow*)
  wxHtmlWindow_ctor()
{
    return WXNET_NEW( _HtmlWindow, ());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxHtmlWindow*)
  wxHtmlWindow_ctor2(wxWindow* parent, wxWindowID id, wxPoint* pos, wxSize* size, unsigned int style, wxString* name)
{
   if (name && pos && size)
	   return WXNET_NEW( _HtmlWindow, (parent, id, *pos, *size, style, *name));
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlWindow_RegisterVirtual(_HtmlWindow* self, 
	Virtual_OnLinkClicked onLinkClicked,
	Virtual_OnSetTitle onSetTitle,
	Virtual_OnCellMouseHover onCellMouseHover,
	Virtual_OnCellClicked onCellClicked,
	Virtual_OnOpeningURL onOpeningURL,
   Virtual_LoadFile loadFile,
   Virtual_LoadPage loadPage)
{
	self->RegisterVirtual(onLinkClicked, onSetTitle, onCellMouseHover, onCellClicked, onOpeningURL, loadFile, loadPage);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxHtmlWindow_Create(_HtmlWindow* self, wxWindow* parent, wxWindowID id, wxPoint* pos, wxSize* size, unsigned int style, const wxString* name)
{
   wxString nameStr;
   if (name) nameStr=*name;
   if (self)
    return self->Create(parent, id, *pos, *size, style, nameStr)?1:0;
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxHtmlWindow_SetPage(_HtmlWindow* self, const wxString* source)
{
   if (self && source)
   {
      WXNET_LOG_DEREF(self) 
      WXNET_LOG_DEREFSTR(source) 
      return self->SetPage(*source)?1:0;
   }
   return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxHtmlWindow_AppendToPage(_HtmlWindow* self, const wxString* source)
{
   if (self && source)
   {
      WXNET_LOG_DEREF(self) 
      WXNET_LOG_DEREFSTR(source) 
      return self->AppendToPage(*source)?1:0;
   }
   return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxHtmlWindow_LoadPage(_HtmlWindow* self, const wxString* location)
{
   if (self && location)
   {
      WXNET_LOG_DEREF(self) 
      WXNET_LOG_DEREFSTR(location) 
      return (char) self->wxHtmlWindow::LoadPage(*location);
   }
   else
      return 0;
}

//-----------------------------------------------------------------------------

//! This calls the original implementation, not the callback.
WXNET_EXPORT(char)
  wxHtmlWindow_LoadFile(_HtmlWindow* self, const wxString* filename)
{
   if (self && filename)
   {
      WXNET_LOG_DEREF(self) 
      WXNET_LOG_DEREFSTR(filename) 
      return (char) self->wxHtmlWindow::LoadFile(wxFileName(*filename));
   }
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxHtmlWindow_GetOpenedPage(_HtmlWindow* self)
{
   if (self)
   {
      WXNET_LOG_DEREF(self) 
      return WXNET_NEW( wxString, (self->GetOpenedPage()));
   }
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxHtmlWindow_GetOpenedAnchor(_HtmlWindow* self)
{
   if (self)
   {
      WXNET_LOG_DEREF(self) 
      return WXNET_NEW( wxString, (self->GetOpenedAnchor()));
   }
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxHtmlWindow_GetOpenedPageTitle(_HtmlWindow* self)
{
   if (self)
   {
      WXNET_LOG_DEREF(self) 
      return WXNET_NEW( wxString, (self->GetOpenedPageTitle()));
   }
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlWindow_SetRelatedFrame(_HtmlWindow* self, wxFrame* frame, const wxString* format)
{
   if (self && frame && format)
    self->SetRelatedFrame(frame, *format);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxFrame*)
  wxHtmlWindow_GetRelatedFrame(_HtmlWindow* self)
{
   if (self)
    return self->GetRelatedFrame();
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlWindow_SetRelatedStatusBar(_HtmlWindow* self, int bar)
{
   if (self)
    self->SetRelatedStatusBar(bar);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlWindow_SetFonts(_HtmlWindow* self, const wxString* normal_face, const wxString* fixed_face, int* sizes)
{
   if (self && normal_face && fixed_face && sizes)
    self->SetFonts(*normal_face, *fixed_face, sizes);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlWindow_SetBorders(_HtmlWindow* self, int b)
{
   if (self)
    self->SetBorders(b);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlWindow_ReadCustomization(_HtmlWindow* self, wxConfigBase* cfg, const wxString* path)
{
   if (self && cfg)
   {
      if (path)
         self->ReadCustomization(cfg, *path);
      else
         self->ReadCustomization(cfg);
   }
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlWindow_WriteCustomization(_HtmlWindow* self, wxConfigBase* cfg, const wxString* path)
{
   if (self && cfg)
   {
      if (path)
         self->WriteCustomization(cfg, *path);
      else
         self->WriteCustomization(cfg);
   }
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxHtmlWindow_HistoryBack(_HtmlWindow* self)
{
   if (self)
    return self->HistoryBack();
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxHtmlWindow_HistoryForward(_HtmlWindow* self)
{
   if (self)
    return self->HistoryForward();
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxHtmlWindow_HistoryCanBack(_HtmlWindow* self)
{
   if (self)
    return self->HistoryCanBack();
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxHtmlWindow_HistoryCanForward(_HtmlWindow* self)
{
   if (self)
    return self->HistoryCanForward();
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlWindow_HistoryClear(_HtmlWindow* self)
{
   if (self)
    self->HistoryClear();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxHtmlContainerCell*)
  wxHtmlWindow_GetInternalRepresentation(_HtmlWindow* self)
{
   if (self)
    return self->GetInternalRepresentation();
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlWindow_AddFilter(wxHtmlFilter* filter)
{
    wxHtmlWindow::AddFilter(filter);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxHtmlWinParser*)
  wxHtmlWindow_GetParser(_HtmlWindow* self)
{
   if (self)
    return self->GetParser();
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlWindow_AddProcessor(_HtmlWindow* self, wxHtmlProcessor* processor)
{
   if (self)
    self->AddProcessor(processor);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlWindow_AddGlobalProcessor(wxHtmlProcessor* processor)
{
    wxHtmlWindow::AddGlobalProcessor(processor);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxHtmlWindow_AcceptsFocusFromKeyboard(_HtmlWindow* self)
{
   if (self)
    return self->AcceptsFocusFromKeyboard();
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlWindow_OnSetTitle(_HtmlWindow* self, const wxString* title)
{
   if (self && title)
    self->wxHtmlWindow::OnSetTitle(*title);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxHtmlWindow_OnCellClicked(_HtmlWindow* self, wxHtmlCell* cell, wxCoord x, wxCoord y, wxMouseEvent* event)
{
#if wxCHECK_VERSION(2, 8, 0)
    return self->_HtmlWindow::OnCellClickedOrig(cell, x, y, *event);
#else
    self->_HtmlWindow::OnCellClickedOrig(cell, x, y, *event);
    return false;
#endif
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlWindow_OnLinkClicked(_HtmlWindow* self, wxHtmlLinkInfo* link)
{
   if (self && link)
	   self->wxHtmlWindow::OnLinkClicked(*link);
} 

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxHtmlOpeningStatus)
  wxHtmlWindow_OnOpeningURL(_HtmlWindow* self, wxHtmlURLType type, const wxString* url, wxString* redirect)
{
   if (self && url && redirect)
	   return self->wxHtmlWindow::OnOpeningURL(type, *url, redirect);
   else
      return wxHTML_BLOCK;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlWindow_SelectAll(_HtmlWindow* self)
{
   if (self)
	self->SelectAll();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlWindow_SelectCells(_HtmlWindow* self, wxHtmlCell* firstCell, wxHtmlCell* lastCell)
{
   if (self && firstCell && lastCell)
	   self->SelectCells(firstCell, lastCell);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlWindow_SelectWord(_HtmlWindow* self, wxPoint* pos)
{
   if (self && pos)
	self->SelectWord(*pos);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlWindow_SelectLine(_HtmlWindow* self, wxPoint* pos)
{
   if (self && pos)
	self->SelectLine(*pos);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxHtmlWindow_HasSelection(const _HtmlWindow* self)
{
   if (self)
      return self->HasSelection();
   return false;
}

WXNET_EXPORT(wxHtmlCell*)
  wxHtmlWindow_SelectionFromCell(const _HtmlWindow* self)
{
   if (self)
      return self->GetSelectionFromCell();
   return NULL;
}

WXNET_EXPORT(wxHtmlCell*)
  wxHtmlWindow_SelectionToCell(const _HtmlWindow* self)
{
   if (self)
      return self->GetSelectionToCell();
   return NULL;
}

WXNET_EXPORT(char)
  wxHtmlWindow_SelectionPosition(const _HtmlWindow* self, int* fromX, int* fromY, int* toX, int* toY)
{
   if (self && self->HasSelection())
   {
      self->ReadSelectionFromPos(fromX, fromY);
      self->ReadSelectionToPos(toX, toY);
      return true;
   }
   return false;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxHtmlWindow_ToText(_HtmlWindow* self)
{
	return WXNET_NEW( wxString, (self->ToText()));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxHtmlWindow_SelectionToText(_HtmlWindow* self)
{
	return WXNET_NEW( wxString, (self->SelectionToText()));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxClassInfo*)
  HtmlFontCell_GetWxClassInfo(void)
{
   return CLASSINFO(wxHtmlFontCell);
}

WXNET_EXPORT(wxHtmlFontCell*)
  wxHtmlFontCell_ctor(wxFont* font)
{
    return WXNET_NEW( wxHtmlFontCell, (font));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlFontCell_Draw(wxHtmlFontCell* self, wxDC* dc, int x, int y, int view_y1, int view_y2, wxHtmlRenderingInfo* info)
{
   if (self && dc && info)
    self->Draw(*dc, x, y, view_y1, view_y2, *info);
   else if (self && dc)
   {
       wxHtmlRenderingInfo defaultInfo;
       self->Draw(*dc, x, y, view_y1, view_y2, defaultInfo);
   }
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlFontCell_DrawInvisible(wxHtmlFontCell* self, wxDC* dc, int x, int y, wxHtmlRenderingInfo* info)
{
   if (self && dc && info)
    self->DrawInvisible(*dc, x, y, *info);
   else if (self && dc)
   {
       wxHtmlRenderingInfo defaultInfo;
       self -> DrawInvisible(*dc, x, y, defaultInfo);
   }
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxClassInfo*)
  HtmlColourCell_GetWxClassInfo(void)
{
   return CLASSINFO(wxHtmlColourCell);
}


WXNET_EXPORT(wxHtmlColourCell*)
  wxHtmlColourCell_ctor(wxColour* clr, int flags)
{
   if (clr)
    return WXNET_NEW( wxHtmlColourCell, (*clr, flags));
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlColourCell_Draw(wxHtmlColourCell* self, wxDC* dc, int x, int y, int view_y1, int view_y2, wxHtmlRenderingInfo* info)
{
   if (self && dc && info)
    self->Draw(*dc, x, y, view_y1, view_y2, *info);
   else if (self && dc)
   {
      wxHtmlRenderingInfo defaultRendering;
      self->Draw(*dc, x, y, view_y1, view_y2, defaultRendering);
   }
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlColourCell_DrawInvisible(wxHtmlColourCell* self, wxDC* dc, int x, int y, wxHtmlRenderingInfo* info)
{
   if (self && dc && info)
    self->DrawInvisible(*dc, x, y, *info);
   else if (self && dc)
   {
      wxHtmlRenderingInfo defaultRendering;
      self->DrawInvisible(*dc, x, y, defaultRendering);
   }
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxHtmlLinkInfo*)
  wxHtmlLinkInfo_ctor()
{
    return WXNET_NEW( wxHtmlLinkInfo, ());
}

//-----------------------------------------------------------------------------

/*extern "C" WXEXPORT
wxHtmlLinkInfo* wxHtmlLinkInfo_ctor(const wxString* href, const wxString* target)
{
    if (target == NULL)
        target = &wxEmptyString;

    if (href && target)
      return WXNET_NEW( wxHtmlLinkInfo, (*href, *target));
    else return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxHtmlLinkInfo*)
  wxHtmlLinkInfo_ctor(wxHtmlLinkInfo* l)
{
    return WXNET_NEW( wxHtmlLinkInfo, (*l));
}*/

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlLinkInfo_SetEvent(wxHtmlLinkInfo* self, wxMouseEvent* e)
{
   if (self)
    self->SetEvent(e);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlLinkInfo_SetHtmlCell(wxHtmlLinkInfo* self, wxHtmlCell* e)
{
   if (self)
    self->SetHtmlCell(e);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxHtmlLinkInfo_GetHref(wxHtmlLinkInfo* self)
{
    return WXNET_NEW( wxString, (self->GetHref()));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxHtmlLinkInfo_GetTarget(wxHtmlLinkInfo* self)
{
    return WXNET_NEW( wxString, (self->GetTarget()));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(const wxMouseEvent*)
  wxHtmlLinkInfo_GetEvent(wxHtmlLinkInfo* self)
{
   if (self)
    return self->GetEvent();
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(const wxHtmlCell*)
  wxHtmlLinkInfo_GetHtmlCell(wxHtmlLinkInfo* self)
{
   if (self)
    return self->GetHtmlCell();
   else
      return NULL;
}

//-----------------------------------------------------------------------------

// This is a work around a problem of the original widget cell:
// This will defer visibility of the client window up to the point when its layout
// is valid.
class _HtmlWidgetCell : public wxHtmlWidgetCell
{
   bool m_hasBeenMadeVisible;
   DECLARE_DISPOSABLE(_HtmlWidgetCell)
public:
   _HtmlWidgetCell(wxWindow *wnd, int w = 0) : wxHtmlWidgetCell(wnd, w), m_hasBeenMadeVisible(false), m_onDispose(NULL)
   {
      wnd->Show(false);
   }

   virtual void DrawInvisible(wxDC& dc, int x, int y, wxHtmlRenderingInfo& info)
   {
       if (!m_Wnd)
           return;
       int absx = 0, absy = 0, stx, sty;
       wxHtmlCell *c = this;

       while (c)
       {
           absx += c->GetPosX();
           absy += c->GetPosY();
           c = c->GetParent();
       }

       ((wxScrolledWindow*)(m_Wnd->GetParent()))->GetViewStart(&stx, &sty);
       int xComputed=absx - wxHTML_SCROLL_STEP * stx;
       int yComputed=absy - wxHTML_SCROLL_STEP * sty;
       int xCurrent, yCurrent;
       m_Wnd->GetPosition(&xCurrent, &yCurrent);
       //std::cout << "Draw invisible widget cell " << x << "x" << y << " computed " << xComputed << "x" << yComputed << " current " << xCurrent << "x" << yCurrent << " size " << m_Width << "x" << m_Height << std::endl;
       if (xComputed != xCurrent || yComputed != yCurrent)
       {
         m_Wnd->SetSize(xComputed, yComputed, m_Width, m_Height);
         if (m_hasBeenMadeVisible)
            m_Wnd->Refresh();
         else
            m_Wnd->Show(true);
       }
   }

   virtual void Draw(wxDC& dc,
                     int x, int y,
                     int view_y1, int view_y2,
                     wxHtmlRenderingInfo& info)
   {
       if (!m_Wnd)
           return;
      // pasted from base implementation
      int absx = 0, absy = 0, stx, sty;
      wxHtmlCell *c = this;

      while (c)
      {
        absx += c->GetPosX();
        absy += c->GetPosY();
        c = c->GetParent();
      }

      ((wxScrolledWindow*)(m_Wnd->GetParent()))->GetViewStart(&stx, &sty);
      int xComputed=absx - wxHTML_SCROLL_STEP * stx;
      int yComputed=absy - wxHTML_SCROLL_STEP * sty;
      int xCurrent, yCurrent;
      m_Wnd->GetPosition(&xCurrent, &yCurrent);
      //std::cout << "Draw widget cell " << x << "x" << y << "+" << view_y1 << "+" << view_y2 << " computed " << xComputed << "x" << yComputed << " current " << xCurrent << "x" << yCurrent << " size " << m_Width << "x" << m_Height << std::endl;
      if (xComputed != xCurrent || yComputed != yCurrent)
      {
         m_Wnd->SetSize(xComputed, yComputed, m_Width, m_Height);
         if (m_hasBeenMadeVisible)
            m_Wnd->Refresh();
         else
            m_Wnd->Show(true);
      }
   }

   virtual void Layout(int w)
   {
       if (!m_Wnd)
           return;
      //std::cout << "Layout widget cell " << w << " size " << m_Width << "x" << m_Height << std::endl;
      wxHtmlWidgetCell::Layout(w);
      m_Wnd->Refresh();
   }

   wxWindow* GetWindow() const { return m_Wnd; }

   bool Destroy()
   {
       if (m_Wnd)
       {
           wxWindow* parent=m_Wnd->GetParent();
           bool result = m_Wnd->Destroy();
           m_Wnd=new wxPanel(parent);
           return result;
       }
       return false;
   }
};

WXNET_EXPORT(wxClassInfo*)
  HtmlWidgetCell_GetWxClassInfo(void)
{
   return CLASSINFO(wxHtmlWidgetCell);
}

WXNET_EXPORT(wxHtmlWidgetCell*)
  wxHtmlWidgetCell_ctor(wxWindow* wnd, int w)
{
    return WXNET_NEW( _HtmlWidgetCell, (wnd, w));
}

WXNET_EXPORT(void)
  wxHtmlWidgetCell_RegisterDispose(wxHtmlWidgetCell* self, Virtual_Dispose onDispose)
{
   _HtmlWidgetCell* selfCasted=NULL;
   selfCasted=dynamic_cast< _HtmlWidgetCell* >(self);
   if (selfCasted)
      selfCasted->RegisterDispose(onDispose);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlWidgetCell_Draw(wxHtmlWidgetCell* self, wxDC* dc, int x, int y, int view_y1, int view_y2, wxHtmlRenderingInfo* info)
{
   if (self && dc && info)
    self->Draw(*dc, x, y, view_y1, view_y2, *info);
   else if (self && dc)
   {
     wxHtmlRenderingInfo defaultRendering;
     self->Draw(*dc, x, y, view_y1, view_y2, defaultRendering);
   }
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlWidgetCell_DrawInvisible(wxHtmlWidgetCell* self, wxDC* dc, int x, int y, wxHtmlRenderingInfo* info)
{
   if (self && dc && info)
    self->DrawInvisible(*dc, x, y, *info);
   else if (self && dc)
   {
     wxHtmlRenderingInfo defaultRendering;
     self->DrawInvisible(*dc, x, y, defaultRendering);
   }
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlWidgetCell_Layout(wxHtmlWidgetCell* self, int w)
{
   if (self)
    self->Layout(w);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxWindow*)
  wxHtmlWidgetCell_GetWindow(const _HtmlWidgetCell* self)
{
    if (self)
       return self->GetWindow();
    else
       return 0;
}

WXNET_EXPORT(char) wxHtmlWidgetCell_Destroy(_HtmlWidgetCell* self)
{
    if (self)
        return self->Destroy()?1:0;
    else
        return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxClassInfo*)
  HtmlCell_GetWxClassInfo(void)
{
   return CLASSINFO(wxHtmlCell);
}

WXNET_EXPORT(wxHtmlCell*)
  wxHtmlCell_ctor()
{
    return WXNET_NEW( wxHtmlCell, () );
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlCell_SetParent(wxHtmlCell* self, wxHtmlContainerCell* p)
{
   if (self)
    self->SetParent(p);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxHtmlContainerCell*)
  wxHtmlCell_GetParent(wxHtmlCell* self)
{
   if (self)
    return self->GetParent();
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxHtmlCell_GetPosX(wxHtmlCell* self)
{
   if (self)
    return self->GetPosX();
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxHtmlCell_GetPosY(wxHtmlCell* self)
{
   if (self)
    return self->GetPosY();
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlCell_GetAbsPos(wxHtmlCell* self, wxHtmlCell* rootCell, int* x, int* y)
{
   if (self)
   {
      wxPoint result=self->GetAbsPos(rootCell);
      if (x)
         *x=result.x;
      if (y)
         *y=result.y;
   }
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxHtmlCell_GetWidth(wxHtmlCell* self)
{
   if (self)
    return self->GetWidth();
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxHtmlCell_GetHeight(wxHtmlCell* self)
{
   if (self)
    return self->GetHeight();
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxHtmlCell_GetDescent(wxHtmlCell* self)
{
   if (self)
    return self->GetDescent();
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxHtmlCell_GetId(wxHtmlCell* self)
{
   if (self)
    return WXNET_NEW( wxString, (self->GetId()) );
   return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlCell_SetId(wxHtmlCell* self, const wxString* id)
{
   if (self && id)
      self->SetId(*id);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxHtmlCell*)
  wxHtmlCell_GetNext(wxHtmlCell* self)
{
   if (self)
    return self->GetNext();
   return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlCell_SetPos(wxHtmlCell* self, int x, int y)
{
   if (self)
    self->SetPos(x, y);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxHtmlLinkInfo*)
  wxHtmlCell_GetLink(wxHtmlCell* self)
{
   if (self)
   {
      const wxHtmlLinkInfo* result=self->GetLink();
      if (result)
         return new wxHtmlLinkInfo(*result);
   }
   return NULL;
}

WXNET_EXPORT(void)
  wxHtmlCell_SetLink(wxHtmlCell* self, wxHtmlLinkInfo* link)
{
   if (self)
    self->SetLink(*link);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlCell_SetNext(wxHtmlCell* self, wxHtmlCell* cell)
{
   if (self)
    self->SetNext(cell);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlCell_Layout(wxHtmlCell* self, int w)
{
   if (self)
    self->Layout(w);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlCell_Draw(wxHtmlCell* self, wxDC* dc, int x, int y, int view_y1, int view_y2, wxHtmlRenderingInfo* info)
{
   if (self && dc && info)
    self->Draw(*dc, x, y, view_y1, view_y2, *info);
   else if (self && dc)
   {
     wxHtmlRenderingInfo defaultRendering;
     self->Draw(*dc, x, y, view_y1, view_y2, defaultRendering);
   }
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlCell_DrawInvisible(wxHtmlCell* self, wxDC* dc, int x, int y, wxHtmlRenderingInfo* info)
{
   if (self && dc && info)
    self->DrawInvisible(*dc, x, y, *info);
   else if (self && dc)
   {
     wxHtmlRenderingInfo defaultRendering;
     self->DrawInvisible(*dc, x, y, defaultRendering);
   }
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(const wxHtmlCell*)
  wxHtmlCell_Find(wxHtmlCell* self, int condition, void* param)
{
   if (self)
    return self->Find(condition, param);
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlCell_OnMouseClick(wxHtmlCell* self, wxWindow* parent, int x, int y, wxMouseEvent* event)
{
   if (self)
    self->OnMouseClick(parent, x, y, *event);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxHtmlCell_AdjustPagebreak(wxHtmlCell* self, int* pagebreak)
{
   wxArrayInt known_pagebreaks;
   if (self)
      return self->AdjustPagebreak(pagebreak, known_pagebreaks);
   else
      return 0;
}


//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlCell_SetCanLiveOnPagebreak(wxHtmlCell* self, bool can)
{
   if (self)
    self->SetCanLiveOnPagebreak(can);
}

//-----------------------------------------------------------------------------
/*
WXNET_EXPORT(void)
  wxHtmlCell_GetHorizontalConstraints(wxHtmlCell* self, int* left, int* right)
{
    self->GetHorizontalConstraints(left, right);
}
*/
//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxHtmlCell_IsTerminalCell(wxHtmlCell* self)
{
   if (self)
    return self->IsTerminalCell();
   return false;
}
WXNET_EXPORT(char)
  wxHtmlCell_IsFormattingCell(wxHtmlCell* self)
{
   if (self)
    return self->IsFormattingCell();
   return false;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxHtmlCell*)
  wxHtmlCell_FindCellByPos(wxHtmlCell* self, wxCoord x, wxCoord y, int mode)
{
   if (self)
    return self->FindCellByPos(x, y, mode);
   return NULL;
}


WXNET_EXPORT(wxHtmlCell*)
  wxHtmlCell_GetFirstChild(const wxHtmlCell* self)
{
   if (self)
    return self->GetFirstChild();
   return NULL;
}

WXNET_EXPORT(wxHtmlCell*)
  wxHtmlCell_GetFirstTerminal(const wxHtmlCell* self)
{
   if (self)
      return self->GetFirstTerminal();
   return NULL;
}

WXNET_EXPORT(wxHtmlCell*)
  wxHtmlCell_GetLastTerminal(const wxHtmlCell* self)
{
   if (self)
      return self->GetLastTerminal();
   return NULL;
}

WXNET_EXPORT(wxHtmlCell*)
  wxHtmlCell_GetRootCell(const wxHtmlCell* self)
{
   if (self)
      return self->GetRootCell();
   return NULL;
}

WXNET_EXPORT(char)
  wxHtmlCell_IsBefore(const wxHtmlCell* self, wxHtmlCell* other)
{
   if (self && other)
   {
      return self->IsBefore(other);
   }
   else
      return false;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxHtmlWindow_ConvertToText(const wxHtmlCell* self)
{
   if (self)
      return WXNET_NEW(wxString, (self->ConvertToText(NULL)));
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxClassInfo*)
  HtmlWordCell_GetWxClassInfo(void)
{
   return CLASSINFO(wxHtmlWordCell);
}

WXNET_EXPORT(wxHtmlWordCell*)
  wxHtmlWordCell_ctor(const wxString* word, wxDC* dc)
{
   if (word && dc)
    return WXNET_NEW( wxHtmlWordCell, (*word, *dc));
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlWordCell_Draw(wxHtmlWordCell* self, wxDC* dc, int x, int y, int view_y1, int view_y2, wxHtmlRenderingInfo* info)
{
   if (self && dc && info)
    self->Draw(*dc, x, y, view_y1, view_y2, *info);
   else if (self && dc)
   {
     wxHtmlRenderingInfo defaultRendering;
     self->Draw(*dc, x, y, view_y1, view_y2, defaultRendering);
   }
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxClassInfo*)
  HtmlContainerCell_GetWxClassInfo(void)
{
   return CLASSINFO(wxHtmlContainerCell);
}


WXNET_EXPORT(wxHtmlContainerCell*)
  wxHtmlContainerCell_ctor(wxHtmlContainerCell* parent)
{
    return WXNET_NEW( wxHtmlContainerCell, (parent));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlContainerCell_Layout(wxHtmlContainerCell* self, int w)
{
   if (self)
    self->Layout(w);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlContainerCell_Draw(wxHtmlContainerCell* self, wxDC* dc, int x, int y, int view_y1, int view_y2, wxHtmlRenderingInfo* info)
{
   if (self && info && dc)
    self->Draw(*dc, x, y, view_y1, view_y2, *info);
   else if (self && dc)
   {
     wxHtmlRenderingInfo defaultRendering;
     self->Draw(*dc, x, y, view_y1, view_y2, defaultRendering);
   }
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlContainerCell_DrawInvisible(wxHtmlContainerCell* self, wxDC* dc, int x, int y, wxHtmlRenderingInfo* info)
{
   if (self && dc && info)
    self->DrawInvisible(*dc, x, y, *info);
   else if (self && dc)
   {
     wxHtmlRenderingInfo defaultRendering;
     self->DrawInvisible(*dc, x, y, defaultRendering);
   }
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxHtmlContainerCell_AdjustPagebreak(wxHtmlContainerCell* self, int* pagebreak)
{
   wxArrayInt known_pagebreaks;
   if (self)
      return self->AdjustPagebreak(pagebreak, known_pagebreaks);
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlContainerCell_InsertCell(wxHtmlContainerCell* self, wxHtmlCell* cell)
{
   if (self)
    self->InsertCell(cell);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlContainerCell_SetAlignHor(wxHtmlContainerCell* self, int al)
{
   if (self)
    self->SetAlignHor(al);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxHtmlContainerCell_GetAlignHor(wxHtmlContainerCell* self)
{
   if (self)
    return self->GetAlignHor();
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlContainerCell_SetAlignVer(wxHtmlContainerCell* self, int al)
{
   if (self)
    self->SetAlignVer(al);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxHtmlContainerCell_GetAlignVer(wxHtmlContainerCell* self)
{
   if (self)
    return self->GetAlignVer();
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlContainerCell_SetIndent(wxHtmlContainerCell* self, int i, int what, int units)
{
   if (self)
    self->SetIndent(i, what, units);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxHtmlContainerCell_GetIndent(wxHtmlContainerCell* self, int ind)
{
   if (self)
    return self->GetIndent(ind);
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxHtmlContainerCell_GetIndentUnits(wxHtmlContainerCell* self, int ind)
{
   if (self)
    return self->GetIndentUnits(ind);
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlContainerCell_SetAlign(wxHtmlContainerCell* self, wxHtmlTag* tag)
{
   if (self)
    self->SetAlign(*tag);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlContainerCell_SetWidthFloat(wxHtmlContainerCell* self, int w, int units)
{
   if (self)
    self->SetWidthFloat(w, units);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlContainerCell_SetWidthFloatTag(wxHtmlContainerCell* self, wxHtmlTag* tag, double pixel_scale)
{
   if (self)
    self->SetWidthFloat(*tag, pixel_scale);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlContainerCell_SetMinHeight(wxHtmlContainerCell* self, int h, int align)
{
   if (self)
    self->SetMinHeight(h, align);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlContainerCell_SetBackgroundColour(wxHtmlContainerCell* self, wxColour* clr)
{
   if (self)
    self->SetBackgroundColour(*clr);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxColour*)
  wxHtmlContainerCell_GetBackgroundColour(wxHtmlContainerCell* self)
{
    return WXNET_NEW( wxColour, (self->GetBackgroundColour()));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlContainerCell_SetBorder(wxHtmlContainerCell* self, wxColour* clr1, wxColour* clr2)
{
   if (self)
    self->SetBorder(*clr1, *clr2);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxHtmlLinkInfo*)
  wxHtmlContainerCell_GetLink(wxHtmlContainerCell* self, int x, int y)
{
   if (self)
    return self->GetLink(x, y);
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(const wxHtmlCell*)
  wxHtmlContainerCell_Find(wxHtmlContainerCell* self, int condition, void* param)
{
    return self->Find(condition, param);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlContainerCell_OnMouseClick(wxHtmlContainerCell* self, wxWindow* parent, int x, int y, wxMouseEvent* event)
{
   if (self)
    self->OnMouseClick(parent, x, y, *event);
}

//-----------------------------------------------------------------------------
/*
WXNET_EXPORT(void)
  wxHtmlContainerCell_GetHorizontalConstraints(wxHtmlContainerCell* self, int* left, int* right)
{
    self->GetHorizontalConstraints(left, right);
}
*/
//-----------------------------------------------------------------------------


WXNET_EXPORT(void)
  wxHtmlTag_dtor(wxHtmlTag* self)
{
   WXNET_DEL(self);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxHtmlTag*)
  wxHtmlTag_GetParent(wxHtmlTag* self)
{
   if (self)
    return self->GetParent();
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxHtmlTag*)
  wxHtmlTag_GetFirstSibling(wxHtmlTag* self)
{
   if (self)
    return self->GetFirstSibling();
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxHtmlTag*)
  wxHtmlTag_GetLastSibling(wxHtmlTag* self)
{
   if (self)
    return self->GetLastSibling();
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxHtmlTag*)
  wxHtmlTag_GetChildren(wxHtmlTag* self)
{
   if (self)
    return self->GetChildren();
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxHtmlTag*)
  wxHtmlTag_GetPreviousSibling(wxHtmlTag* self)
{
   if (self)
    return self->GetPreviousSibling();
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxHtmlTag*)
  wxHtmlTag_GetNextSibling(wxHtmlTag* self)
{
   if (self)
    return self->GetNextSibling();
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxHtmlTag*)
  wxHtmlTag_GetNextTag(wxHtmlTag* self)
{
   if (self)
    return self->GetNextTag();
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxHtmlTag_GetName(wxHtmlTag* self)
{
   if (self)
    return WXNET_NEW( wxString, (self->GetName()));
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxHtmlTag_HasParam(wxHtmlTag* self, const wxString* par)
{
   if (self && par)
    return self->HasParam(*par)?1:0;
   else return false;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxHtmlTag_GetParam(wxHtmlTag* self, const wxString* par, bool with_commas)
{
   if (self && par)
    return WXNET_NEW( wxString, (self->GetParam(*par, with_commas)));
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxHtmlTag_GetParamAsColour(wxHtmlTag* self, const wxString* par, wxColour* clr)
{
   if (self && par)
    return self->GetParamAsColour(*par, clr)?1:0;
   else
      return false;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxHtmlTag_GetParamAsInt(wxHtmlTag* self, const wxString* par, int* clr)
{
   if (self && par)
    return self->GetParamAsInt(*par, clr)?1:0;
   else
      return false;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxHtmlTag_GetAllParams(wxHtmlTag* self)
{
    return WXNET_NEW( wxString, (self->GetAllParams()));
}

//-----------------------------------------------------------------------------
/*
WXNET_EXPORT(char)
  wxHtmlTag_IsEnding(wxHtmlTag* self)
{
    return self->IsEnding();
}
*/
//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxHtmlTag_HasEnding(wxHtmlTag* self)
{
    return self->HasEnding()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxHtmlTag_GetBeginPos(wxHtmlTag* self)
{
   if (self)
    return self->GetBeginPos();
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxHtmlTag_GetEndPos1(wxHtmlTag* self)
{
   if (self)
    return self->GetEndPos1();
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxHtmlTag_GetEndPos2(wxHtmlTag* self)
{
   if (self)
    return self->GetEndPos2();
   else
      return 0;
}

//-----------------------------------------------------------------------------
// wxHtmlFilter

WXNET_EXPORT(char)
  wxHtmlFilter_CanRead(wxHtmlFilter* self, wxFSFile* file)
{
   if (self && file)
    return self->CanRead(*file);
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxHtmlFilter_ReadFile(wxHtmlFilter* self, wxFSFile* file)
{
   if (self && file)
   {
	   wxString str = self->ReadFile(*file);
	   return WXNET_NEW( wxString, (str));
   }
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxHtmlFilterPlainText_CanRead(wxHtmlFilterPlainText* self, wxFSFile* file)
{
   if (self && file)
    return self->CanRead(*file);
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxHtmlFilterPlainText_ReadFile(wxHtmlFilterPlainText* self, wxFSFile* file)
{
   if (self && file)
   {
	   wxString str = self->ReadFile(*file);
      return WXNET_NEW( wxString, (str));
   }
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxHtmlFilterHTML_CanRead(wxHtmlFilterHTML* self, wxFSFile* file)
{
   if (self)
    return self->CanRead(*file);
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxHtmlFilterHTML_ReadFile(wxHtmlFilterHTML* self, wxFSFile* file)
{
   if (self && file)
   {
	   wxString str = self->ReadFile(*file);
      return WXNET_NEW( wxString, (str));
   } else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxHtmlTagsModule*)
  wxHtmlTagsModule_ctor()
{
    return WXNET_NEW( wxHtmlTagsModule, ());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxHtmlTagsModule_OnInit(wxHtmlTagsModule* self)
{
   if (self)
    return self->OnInit();
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlTagsModule_OnExit(wxHtmlTagsModule* self)
{
   if (self)
      self->OnExit();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlTagsModule_FillHandlersTable(wxHtmlTagsModule* self, wxHtmlWinParser * parser)
{
   if (self && parser)
    self->FillHandlersTable(parser);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxHtmlWinParser*)
  wxHtmlWinParser_ctor(wxHtmlWindow* wnd)
{
    return WXNET_NEW( wxHtmlWinParser, (wnd));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlWinParser_InitParser(wxHtmlWinParser* self, const wxString* source)
{
   if (self && source)
    self->InitParser(*source);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlWinParser_DoneParser(wxHtmlWinParser* self)
{
   if (self)
    self->DoneParser();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxObject*)
  wxHtmlWinParser_GetProduct(wxHtmlWinParser* self)
{
   if (self)
    return self->GetProduct();
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxFSFile*)
  wxHtmlWinParser_OpenURL(wxHtmlWinParser* self, wxHtmlURLType type, const wxString* url)
{
   if (self && url)
    return self->OpenURL(type, *url);
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlWinParser_SetDC(wxHtmlWinParser* self, wxDC* dc, double pixel_scale)
{
   if (self && dc)
    self->SetDC(dc, pixel_scale);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxDC*)
  wxHtmlWinParser_GetDC(wxHtmlWinParser* self)
{
   if (self)
    return self->GetDC();
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(double)
  wxHtmlWinParser_GetPixelScale(wxHtmlWinParser* self)
{
   if (self)
    return self->GetPixelScale();
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxHtmlWinParser_GetCharHeight(wxHtmlWinParser* self)
{
   if (self)
    return self->GetCharHeight();
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxHtmlWinParser_GetCharWidth(wxHtmlWinParser* self)
{
   if (self)
    return self->GetCharWidth();
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxHtmlWindow*)
  wxHtmlWinParser_GetWindow(wxHtmlWinParser* self)
{
   if (self)
    return dynamic_cast<wxHtmlWindow*>(self->GetWindowInterface()->GetHTMLWindow());
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlWinParser_SetFonts(wxHtmlWinParser* self, const wxString* normal_face, const wxString* fixed_face, int* sizes)
{
   if (self && normal_face && fixed_face)
    self->SetFonts(*normal_face, *fixed_face, sizes);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlWinParser_AddModule(wxHtmlWinParser* self, wxHtmlTagsModule* module)
{
   if (self && module)
    self->AddModule(module);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlWinParser_RemoveModule(wxHtmlWinParser* self, wxHtmlTagsModule* module)
{
   if (self && module)
    self->RemoveModule(module);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxHtmlContainerCell*)
  wxHtmlWinParser_GetContainer(wxHtmlWinParser* self)
{
   if (self)
    return self->GetContainer();
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxHtmlContainerCell*)
  wxHtmlWinParser_OpenContainer(wxHtmlWinParser* self)
{
   if (self)
    return self->OpenContainer();
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxHtmlContainerCell*)
  wxHtmlWinParser_SetContainer(wxHtmlWinParser* self, wxHtmlContainerCell* c)
{
   if (self && c)
    return self->SetContainer(c);
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxHtmlContainerCell*)
  wxHtmlWinParser_CloseContainer(wxHtmlWinParser* self)
{
   if (self)
    return self->CloseContainer();
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxHtmlWinParser_GetFontSize(wxHtmlWinParser* self)
{
   if (self)
    return self->GetFontSize();
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlWinParser_SetFontSize(wxHtmlWinParser* self, int s)
{
   if (self)
    self->SetFontSize(s);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxHtmlWinParser_GetFontBold(wxHtmlWinParser* self)
{
   if (self)
    return self->GetFontBold();
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlWinParser_SetFontBold(wxHtmlWinParser* self, int x)
{
    self->SetFontBold(x);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxHtmlWinParser_GetFontItalic(wxHtmlWinParser* self)
{
    return self->GetFontItalic();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlWinParser_SetFontItalic(wxHtmlWinParser* self, int x)
{
    self->SetFontItalic(x);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxHtmlWinParser_GetFontUnderlined(wxHtmlWinParser* self)
{
    return self->GetFontUnderlined();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlWinParser_SetFontUnderlined(wxHtmlWinParser* self, int x)
{
    self->SetFontUnderlined(x);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxHtmlWinParser_GetFontFixed(wxHtmlWinParser* self)
{
    return self->GetFontFixed();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlWinParser_SetFontFixed(wxHtmlWinParser* self, int x)
{
    self->SetFontFixed(x);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxHtmlWinParser_GetFontFace(wxHtmlWinParser* self)
{
    return WXNET_NEW( wxString, (self->GetFontFace()) );
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlWinParser_SetFontFace(wxHtmlWinParser* self, const wxString* face)
{
   if (self && face)
    self->SetFontFace(*face);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxHtmlWinParser_GetAlign(wxHtmlWinParser* self)
{
    return self->GetAlign();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlWinParser_SetAlign(wxHtmlWinParser* self, int a)
{
    self->SetAlign(a);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxColour*)
  wxHtmlWinParser_GetLinkColor(wxHtmlWinParser* self)
{
    return WXNET_NEW( wxColour, (self->GetLinkColor()));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlWinParser_SetLinkColor(wxHtmlWinParser* self, wxColour* clr)
{
    self->SetLinkColor(*clr);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxColour*)
  wxHtmlWinParser_GetActualColor(wxHtmlWinParser* self)
{
    return WXNET_NEW( wxColour, (self->GetActualColor()));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlWinParser_SetActualColor(wxHtmlWinParser* self, wxColour* clr)
{
    self->SetActualColor(*clr);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(const wxHtmlLinkInfo*)
  wxHtmlWinParser_GetLink(wxHtmlWinParser* self)
{
    return &(self->GetLink());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlWinParser_SetLink(wxHtmlWinParser* self, wxHtmlLinkInfo* link)
{
    self->SetLink(*link);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxFont*)
  wxHtmlWinParser_CreateCurrentFont(wxHtmlWinParser* self)
{
    return self->CreateCurrentFont();
}

//-----------------------------------------------------------------------------

struct _DisposableHtmlTagBox
{
public:
   Virtual_Dispose m_onDispose;
   void RegisterDispose(Virtual_Dispose onDispose) { m_onDispose = onDispose; }
   const wxHtmlTag& m_tag;
   _DisposableHtmlTagBox(const wxHtmlTag& tag) : m_onDispose(0), m_tag(tag)
   {
   }
   virtual ~_DisposableHtmlTagBox()
   {
      if (m_onDispose) m_onDispose();
   }
   const wxHtmlTag* GetTag() const { return &m_tag; }
};

//-----------------------------------------------------------------------------

void DisposableHtmlTagBox_RegisterDispose(_DisposableHtmlTagBox* self, Virtual_Dispose onDispose)
{
   if (self) self->RegisterDispose(onDispose);
}

//-----------------------------------------------------------------------------

// Please keep in mind that that all references to the result have to be removed if
// this box will be disposed.
const wxHtmlTag* DisposableHtmlTagBox_GetTag(const _DisposableHtmlTagBox* self)
{
   if (self)
      return self->GetTag();
   else
      return NULL;
}

//-----------------------------------------------------------------------------

class _DisposableStringBox;
typedef _DisposableStringBox* (CALLBACK* Virtual_GetSupportedTags)();
typedef int (CALLBACK* Virtual_GetHandleTag)(const wxHtmlTag* varib);

class _HtmlTagHandler : public wxHtmlWinTagHandler
{
public:
   Virtual_GetSupportedTags m_getSupportedTagsCall;
   Virtual_GetHandleTag     m_getHandleTagCall;

   public:
    Virtual_Dispose m_onDispose;
    void RegisterDispose(Virtual_Dispose onDispose) { m_onDispose = onDispose; }
    virtual ~_HtmlTagHandler()
    {
       if (m_onDispose) m_onDispose();
    }

   _HtmlTagHandler() : wxHtmlWinTagHandler(), m_onDispose(0), m_getSupportedTagsCall(0), m_getHandleTagCall(0)
   {
   }

   void RegisterVirtual(Virtual_Dispose onDispose, Virtual_GetSupportedTags getSupportedTagsCall, Virtual_GetHandleTag getHandleTagCall)
   {
      m_onDispose=onDispose;
      m_getSupportedTagsCall=getSupportedTagsCall;
      m_getHandleTagCall=getHandleTagCall;
      //std::cerr << "_HtmlTagHandler::RegisterVirtual" << std::endl;
   }

   wxString GetSupportedTags()
   {
      if (m_getSupportedTagsCall)
      {
         wxString tags=_DisposableStringBox::GetValAndDelete(m_getSupportedTagsCall());
         //std::cerr << "_HtmlTagHandler::GetSupportedTags=" << tags.mb_str(*wxConvCurrent) << std::endl;
         return tags;
      }
      else
         return _DisposableStringBox::empty;
   }

   bool HandleTag(const wxHtmlTag& varib)
   {
      if (m_getHandleTagCall)
      {
         //std::cerr << "_HtmlTagHandler::HandleTag(" << varib.GetName().mb_str(*wxConvCurrent) << ")" << std::endl;
         int result=m_getHandleTagCall(&varib);
         //std::cerr << "_HtmlTagHandler::HandleTag(" << varib.GetName().mb_str(*wxConvCurrent) << ")=" << result << std::endl;
         return result != 0;
      }
      else 
         return false;
   }

   wxHtmlParser* GetParser() const { return m_Parser; }

   wxHtmlWinParser* GetWParser() const
   {
      return dynamic_cast< wxHtmlWinParser* >(this->m_Parser);
   }

   void PublicParseInner(const wxHtmlTag& tag) { this->ParseInner(tag); }
};

#include <ostream>
std::ostream& operator << (std::ostream& dest, wxHtmlTagHandler& handler)
{
   dest << wxString(handler.GetClassInfo()->GetClassName()).mb_str(*wxConvCurrent) << "(" << handler.GetSupportedTags().mb_str(*wxConvCurrent) << ")";
   return dest;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(_HtmlTagHandler*)
  wxHtmlTagHandler_CTor()
{
   return WXNET_NEW( _HtmlTagHandler, ());
}
//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlTagHandler_RegisterVirtual(_HtmlTagHandler* self, Virtual_Dispose onDispose, Virtual_GetSupportedTags getSupportedTagsCall, Virtual_GetHandleTag getHandleTagCall)
{
   if (self)
      self->RegisterVirtual(onDispose, getSupportedTagsCall, getHandleTagCall);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxHtmlParser*)
  wxHtmlTagHandler_GetParser(_HtmlTagHandler* self)
{
   if (self)
    return self->GetParser();
   else
      return NULL;
}

WXNET_EXPORT(wxHtmlWinParser*)
  wxHtmlTagHandler_GetWParser(_HtmlTagHandler* self)
{
   if (self)
    return self->GetWParser();
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlTagHandler_ParseInner(_HtmlTagHandler* self, const wxHtmlTag* tag)
{
   if (self && tag)
      self->PublicParseInner(*tag);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlTagHandler_SetParser(wxHtmlTagHandler* self, wxHtmlParser* parser)
{
    self->SetParser(parser);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxHtmlEntitiesParser*)
  wxHtmlEntitiesParser_ctor()
{
    return WXNET_NEW( wxHtmlEntitiesParser, ());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlEntitiesParser_dtor(wxHtmlEntitiesParser* self)
{
    WXNET_DEL(self);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlEntitiesParser_SetEncoding(wxHtmlEntitiesParser* self, wxFontEncoding encoding)
{
    self->SetEncoding(encoding);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxHtmlEntitiesParser_Parse(wxHtmlEntitiesParser* self, const wxString* input)
{
   if (self && input)
      return WXNET_NEW( wxString, (self->Parse(*input)));
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxHtmlEntitiesParser_GetEntityChar(wxHtmlEntitiesParser* self, const wxString* entity)
{
   if (self && entity)
    return (char)self->GetEntityChar(*entity);
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxHtmlEntitiesParser_GetCharForCode(wxHtmlEntitiesParser* self, unsigned code)
{
    return self->GetCharForCode(code);
}

//-----------------------------------------------------------------------------

/** This will find out whether \c self is an instance of wxHtmlWinParser or not.
* This will use the wxWidgets RTTI.
*/
WXNET_EXPORT(char)
  wxHtmlParser_IsWinParser(wxHtmlParser* self)
{
   if (self && self->IsKindOf(CLASSINFO(wxHtmlWinParser)))
      return 1;
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlParser_SetFS(wxHtmlParser* self, wxFileSystem* fs)
{
    self->SetFS(fs);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxFileSystem*)
  wxHtmlParser_GetFS(wxHtmlParser* self)
{
    return self->GetFS();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxFSFile*)
  wxHtmlParser_OpenURL(wxHtmlParser* self, wxHtmlURLType type, const wxString* url)
{
   if (self && url)
    return self->OpenURL(type, *url);
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxObject*)
  wxHtmlParser_Parse(wxHtmlParser* self, const wxString* source)
{
   if (self && source)
    return self->Parse(*source);
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlParser_InitParser(wxHtmlParser* self, const wxString* source)
{
   if (self && source)
    self->InitParser(*source);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlParser_DoneParser(wxHtmlParser* self)
{
    self->DoneParser();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlParser_StopParsing(wxHtmlParser* self)
{
    self->StopParsing();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlParser_DoParsing(wxHtmlParser* self, int begin_pos, int end_pos)
{
    self->DoParsing(begin_pos, end_pos);
}

WXNET_EXPORT(void)
  wxHtmlParser_DoParsingAll(wxHtmlParser* self)
{
    self->DoParsing();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxHtmlTag*)
  wxHtmlParser_GetCurrentTag(wxHtmlParser* self)
{
    return self->GetCurrentTag();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxObject*)
  wxHtmlParser_GetProduct(wxHtmlParser* self)
{
    return self->GetProduct();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlParser_AddTagHandler(wxHtmlParser* self, wxHtmlTagHandler* handler)
{
    self->AddTagHandler(handler);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlParser_PushTagHandler(wxHtmlParser* self, wxHtmlTagHandler* handler, const wxString* tags)
{
   if (self && tags && handler)
      self->PushTagHandler(handler, *tags );
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlParser_PopTagHandler(wxHtmlParser* self)
{
   if (self)
      self->PopTagHandler();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxHtmlParser_GetSource(wxHtmlParser* self)
{
    return self->GetSource();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlParser_SetSource(wxHtmlParser* self, const wxString* src)
{
   if (self && src)
    self->SetSource(*src);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlParser_SetSourceAndSaveState(wxHtmlParser* self, const wxString* src)
{
   if (self && src)
    self->SetSourceAndSaveState(*src);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxHtmlParser_RestoreState(wxHtmlParser* self)
{
    return self->RestoreState()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxHtmlParser_ExtractCharsetInformation(wxHtmlParser* self, const wxString* markup)
{
   if (self && markup)
    return WXNET_NEW( wxString, (self->ExtractCharsetInformation(*markup)));
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxHtmlProcessor_GetPriority(wxHtmlProcessor* self)
{
    return self->GetPriority();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlProcessor_Enable(wxHtmlProcessor* self, bool enable)
{
    self->Enable(enable);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxHtmlProcessor_IsEnabled(wxHtmlProcessor* self)
{
    return self->IsEnabled()?1:0;
}

//-----------------------------------------------------------------------------
// wxHtmlRenderingInfo > 2.5.1

WXNET_EXPORT(wxHtmlRenderingInfo*)
  wxHtmlRenderingInfo_ctor()
{
	return WXNET_NEW( wxHtmlRenderingInfo, ());
}

WXNET_EXPORT(void)
  wxHtmlRenderingInfo_dtor(wxHtmlRenderingInfo* self)
{
	WXNET_DEL(self);
}

WXNET_EXPORT(void)
  wxHtmlRenderingInfo_SetSelection(wxHtmlRenderingInfo* self, wxHtmlSelection* s)
{
	self->SetSelection(s);
}

WXNET_EXPORT(wxHtmlSelection*)
  wxHtmlRenderingInfo_GetSelection(wxHtmlRenderingInfo* self)
{
	return self->GetSelection();
}

//-----------------------------------------------------------------------------
// wxHtmlSelection > 2.5.1

WXNET_EXPORT(wxHtmlSelection*)
  wxHtmlSelection_ctor()
{
	return WXNET_NEW( wxHtmlSelection, ());
}

WXNET_EXPORT(void)
  wxHtmlSelection_dtor(wxHtmlSelection* self)
{
	WXNET_DEL(self);
}

WXNET_EXPORT(void)
  wxHtmlSelection_Set(wxHtmlSelection* self, wxPoint* fromPos, wxHtmlCell* fromCell, wxPoint* toPos, wxHtmlCell* toCell)
{
	self->Set(*fromPos, fromCell, *toPos, toCell);
}

WXNET_EXPORT(void)
  wxHtmlSelection_Set2(wxHtmlSelection* self, wxHtmlCell* fromCell, wxHtmlCell* toCell)
{
	self->Set(fromCell, toCell);
}

WXNET_EXPORT(const wxHtmlCell*)
  wxHtmlSelection_GetFromCell(wxHtmlSelection* self)
{
	return self->GetFromCell();
}

WXNET_EXPORT(const wxHtmlCell*)
  wxHtmlSelection_GetToCell(wxHtmlSelection* self)
{
	return self->GetToCell();
}

WXNET_EXPORT(void)
  wxHtmlSelection_GetFromPos(wxHtmlSelection* self, wxPoint* fromPos)
{
	fromPos = WXNET_NEW(wxPoint, (self->GetFromPos()));
}

WXNET_EXPORT(void)
  wxHtmlSelection_GetToPos(wxHtmlSelection* self, wxPoint* toPos)
{
	toPos = WXNET_NEW(wxPoint, (self->GetToPos()));
}

WXNET_EXPORT(void)
  wxHtmlSelection_GetFromPrivPos(wxHtmlSelection* self, wxPoint* fromPrivPos)
{
	fromPrivPos = WXNET_NEW( wxPoint, (self->GetFromPrivPos()));
}

WXNET_EXPORT(void)
  wxHtmlSelection_GetToPrivPos(wxHtmlSelection* self, wxPoint* toPrivPos)
{
	toPrivPos = WXNET_NEW( wxPoint, (self->GetToPrivPos()));
}

WXNET_EXPORT(void)
  wxHtmlSelection_SetFromPrivPos(wxHtmlSelection* self, wxPoint* pos)
{
	self->SetFromPrivPos(*pos);
}

WXNET_EXPORT(void)
  wxHtmlSelection_SetToPrivPos(wxHtmlSelection* self, wxPoint* pos)
{
	self->SetToPrivPos(*pos);
}

WXNET_EXPORT(void)
  wxHtmlSelection_ClearPrivPos(wxHtmlSelection* self)
{
	self->ClearPrivPos();
}

WXNET_EXPORT(char)
  wxHtmlSelection_IsEmpty(wxHtmlSelection* self)
{
	return self->IsEmpty()?1:0;
}

//-----------------------------------------------------------------------------
// wxHtmlEasyPrinting

WXNET_EXPORT(wxHtmlEasyPrinting*)
  wxHtmlEasyPrinting_ctor(const wxString* name, wxWindow* parent)
{
   if (name)
	   return WXNET_NEW( wxHtmlEasyPrinting, (*name, parent));
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxHtmlEasyPrinting_PreviewFile(wxHtmlEasyPrinting* self, const wxString* htmlfile)
{
   if (self && htmlfile)
	   return self->PreviewFile(*htmlfile)?1:0;
   else
      return false;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxHtmlEasyPrinting_PreviewText(wxHtmlEasyPrinting* self, const wxString* htmltext, const wxString* basepath)
{
   if (self && htmltext && basepath)
	   return self->PreviewText(*htmltext, *basepath)?1:0;
   else
      return false;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxHtmlEasyPrinting_PrintFile(wxHtmlEasyPrinting* self, const wxString* htmlfile)
{
   if (self && htmlfile)
	   return self->PrintFile(*htmlfile)?1:0;
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxHtmlEasyPrinting_PrintText(wxHtmlEasyPrinting* self, const wxString* htmltext, const wxString* basepath)
{
   if (self && htmltext && basepath)
	   return self->PrintText(*htmltext, *basepath)?1:0;
   else
      return false;
}

//-----------------------------------------------------------------------------

/*extern "C" WXEXPORT
void wxHtmlEasyPrinting_PrinterSetup(wxHtmlEasyPrinting* self)
{
	self->PrinterSetup();
}*/

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlEasyPrinting_PageSetup(wxHtmlEasyPrinting* self)
{
	self->PageSetup();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlEasyPrinting_SetHeader(wxHtmlEasyPrinting* self, const wxString* header, int pg)
{
   if (self && header)
	   self->SetHeader(*header, pg);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlEasyPrinting_SetFooter(wxHtmlEasyPrinting* self, const wxString* footer, int pg)
{
   if (self && footer)
	   self->SetFooter(*footer, pg);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlEasyPrinting_SetFonts(wxHtmlEasyPrinting* self, const wxString* normal_face, const wxString* fixed_face, int* sizes)
{
   if (self && normal_face && fixed_face)
	   self->SetFonts(*normal_face, *fixed_face, sizes);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHtmlEasyPrinting_SetStandardFonts(wxHtmlEasyPrinting* self, int size, const wxString* normal_face, const wxString* fixed_face)
{
   if (self && normal_face && fixed_face)
   	self->SetStandardFonts(size, *normal_face, *fixed_face);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxPrintData*)
  wxHtmlEasyPrinting_GetPrintData(wxHtmlEasyPrinting* self)
{
	return self->GetPrintData();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxPageSetupDialogData*)
  wxHtmlEasyPrinting_GetPageSetupData(wxHtmlEasyPrinting* self)
{
	return self->GetPageSetupData();
}

