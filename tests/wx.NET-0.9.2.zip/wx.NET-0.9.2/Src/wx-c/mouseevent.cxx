//-----------------------------------------------------------------------------
// wx.NET - mouseevent.cxx
//
// The wxMouseEvent proxy interface
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 by Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: mouseevent.cxx,v 1.8 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#ifndef WXNET_GLOBAL_H
#include "wxnet_globals.h"
#endif

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxMouseEvent*)
  wxMouseEvent_ctor(wxEventType mouseType)
{
    return new wxMouseEvent(mouseType);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxMouseEvent_IsButton(wxMouseEvent* self)
{
   if (self)
    return self->IsButton()?1:0;
   return 0;
}

WXNET_EXPORT(char)
  wxMouseEvent_ButtonDown(wxMouseEvent* self)
{
   if (self)
    return self->ButtonDown()?1:0;
   return 0;
}

WXNET_EXPORT(char)
  wxMouseEvent_ButtonDown2(wxMouseEvent* self, int button)
{
   if (self)
    return self->ButtonDown(button)?1:0;
   return 0;
}

WXNET_EXPORT(char)
  wxMouseEvent_ButtonDClick(wxMouseEvent* self, int but)
{
   if (self)
    return self->ButtonDClick(but)?1:0;
   return 0;
}

WXNET_EXPORT(char)
  wxMouseEvent_ButtonUp(wxMouseEvent* self, int but)
{
   if (self)
    return self->ButtonUp(but)?1:0;
   return 0;
}

WXNET_EXPORT(char)
  wxMouseEvent_Button(wxMouseEvent* self, int but)
{
   if (self)
    return self->Button(but)?1:0;
   return 0;
}

WXNET_EXPORT(char)
  wxMouseEvent_ButtonIsDown(wxMouseEvent* self, int but)
{
   if (self)
    return self->ButtonIsDown(but)?1:0;
   return 0;
}

WXNET_EXPORT(int)
  wxMouseEvent_GetButton(wxMouseEvent* self)
{
   if (self)
    return self->GetButton();
   return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxMouseEvent_ControlDown(wxMouseEvent* self)
{
   if (self)
    return self->ControlDown()?1:0;
   return 0;
}

WXNET_EXPORT(char)
  wxMouseEvent_MetaDown(wxMouseEvent* self)
{
   if (self)
    return self->MetaDown()?1:0;
   return 0;
}

WXNET_EXPORT(char)
  wxMouseEvent_AltDown(wxMouseEvent* self)
{
   if (self)
    return self->AltDown()?1:0;
   return 0;
}

WXNET_EXPORT(char)
  wxMouseEvent_ShiftDown(wxMouseEvent* self)
{
   if (self)
    return self->ShiftDown()?1:0;
   return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxMouseEvent_LeftDown(wxMouseEvent* self)
{
   if (self)
    return self->LeftDown()?1:0;
   return 0;
}

WXNET_EXPORT(char)
  wxMouseEvent_MiddleDown(wxMouseEvent* self)
{
   if (self)
    return self->MiddleDown()?1:0;
   return 0;
}

WXNET_EXPORT(char)
  wxMouseEvent_RightDown(wxMouseEvent* self)
{
   if (self)
    return self->RightDown()?1:0;
   return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxMouseEvent_LeftUp(wxMouseEvent* self)
{
   if (self)
    return self->LeftUp()?1:0;
   return 0;
}

WXNET_EXPORT(char)
  wxMouseEvent_MiddleUp(wxMouseEvent* self)
{
   if (self)
    return self->MiddleUp()?1:0;
   return 0;
}

WXNET_EXPORT(char)
  wxMouseEvent_RightUp(wxMouseEvent* self)
{
   if (self)
    return self->RightUp()?1:0;
   return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxMouseEvent_LeftDClick(wxMouseEvent* self)
{
   if (self)
    return self->LeftDClick()?1:0;
   return 0;
}

WXNET_EXPORT(char)
  wxMouseEvent_MiddleDClick(wxMouseEvent* self)
{
   if (self)
    return self->MiddleDClick()?1:0;
   return 0;
}

WXNET_EXPORT(char)
  wxMouseEvent_RightDClick(wxMouseEvent* self)
{
   if (self)
    return self->RightDClick()?1:0;
   return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxMouseEvent_LeftIsDown(wxMouseEvent* self)
{
   if (self)
    return self->LeftIsDown()?1:0;
   return 0;
}

WXNET_EXPORT(char)
  wxMouseEvent_MiddleIsDown(wxMouseEvent* self)
{
   if (self)
    return self->MiddleIsDown()?1:0;
   return 0;
}

WXNET_EXPORT(char)
  wxMouseEvent_RightIsDown(wxMouseEvent* self)
{
   if (self)
    return self->RightIsDown()?1:0;
   return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxMouseEvent_Dragging(wxMouseEvent* self)
{
   if (self)
    return self->Dragging()?1:0;
   return 0;
}

WXNET_EXPORT(char)
  wxMouseEvent_Moving(wxMouseEvent* self)
{
   if (self)
    return self->Moving()?1:0;
   return 0;
}

WXNET_EXPORT(char)
  wxMouseEvent_Entering(wxMouseEvent* self)
{
   if (self)
    return self->Entering()?1:0;
   return 0;
}

WXNET_EXPORT(char)
  wxMouseEvent_Leaving(wxMouseEvent* self)
{
   if (self)
    return self->Leaving()?1:0;
   return 0;
}

//-----------------------------------------------------------------------------


WXNET_EXPORT(void)
  wxMouseEvent_GetPosition(wxMouseEvent* self, wxPoint* pos)
{
   if (self && pos)
    *pos = self->GetPosition();
}

WXNET_EXPORT(void)
  wxMouseEvent_LogicalPosition(wxMouseEvent* self, wxDC* dc, wxPoint* pos)
{
   if (self && pos)
    *pos = self->GetLogicalPosition(*dc);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxMouseEvent_GetWheelRotation(wxMouseEvent* self)
{
   if (self)
    return self->GetWheelRotation();
   return 0;
}

WXNET_EXPORT(int)
  wxMouseEvent_GetWheelDelta(wxMouseEvent* self)
{
   if (self)
    return self->GetWheelDelta();
   return 0;
}

WXNET_EXPORT(int)
  wxMouseEvent_GetLinesPerAction(wxMouseEvent* self)
{
   if (self)
    return self->GetLinesPerAction();
   return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxMouseEvent_IsPageScroll(wxMouseEvent* self)
{
   if (self)
    return self->IsPageScroll()?1:0;
   return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxMouseEvent_GetX(const wxMouseEvent* self)
{
   if (self)
      return self->GetX();
   else
      return 0;
}

WXNET_EXPORT(int)
  wxMouseEvent_GetY(const wxMouseEvent* self)
{
   if (self)
      return self->GetY();
   else
      return 0;
}


