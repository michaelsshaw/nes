//-----------------------------------------------------------------------------
// wx.NET - vscroll.cxx
//
// The wxVScrolledWindow proxy interface.
//
// Written by Alexander Olk (xenomorph2@onlinehome.de)
// (C) 2004 by Alexander Olk
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: vscroll.cxx,v 1.8 2009/12/12 10:32:01 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/vscroll.h>
#include "local_events.h"

#ifndef CALLBACK
# if defined(_WINDOWS)
#  define CALLBACK __stdcall
# else
#  define CALLBACK
# endif
#endif

//-----------------------------------------------------------------------------

typedef int (CALLBACK* Virtual_IntInt) (int);

class _VScrolledWindow : public wxVScrolledWindow
{
public:
	_VScrolledWindow(wxWindow* parent, wxWindowID id, const wxPoint& pos,
					const wxSize& size, long style, const wxString& name)
		: wxVScrolledWindow(parent, id, pos, size, style, name) { }
		
	void RegisterVirtual(Virtual_IntInt onGetLineHeight)
		{
			m_OnGetLineHeight = onGetLineHeight;
		}
		
protected:
	wxCoord OnGetLineHeight( size_t n) const
		{ return m_OnGetLineHeight(n); }	
		
private:
	Virtual_IntInt m_OnGetLineHeight;
	
public:
	DECLARE_OBJECTDELETED(_VScrolledWindow)
};

//-----------------------------------------------------------------------------
// C stubs for class methods

WXNET_EXPORT(wxVScrolledWindow*)
  wxVScrolledWindow_ctor(wxWindow *parent, wxWindowID id, int posX, int posY,
					                           int width, int height, unsigned int style, const wxString* nameArg)
{
   wxString name;
	if (nameArg == NULL)
		name = wxT("vscrolled");
   else
      name=*nameArg;

	return new _VScrolledWindow(parent, id, wxPoint(posX, posY), wxSize(width, height), style, name);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxVScrolledWindow_RegisterVirtual(_VScrolledWindow* self, Virtual_IntInt onGetLineHeight)
{
	self->RegisterVirtual(onGetLineHeight);
}

WXNET_EXPORT(char)
  wxVScrolledWindow_Create(_VScrolledWindow* self, wxWindow *parent, wxWindowID id, int posX, int posY,
					               int width, int height, unsigned int style, const wxString* nameArg)
{
   wxString name;
	if (nameArg == NULL)
		name = wxT("vscrolled");
   else
      name=*nameArg;
		
	return self->Create(parent, id, wxPoint(posX, posY), wxSize(width, height), style, name);
}

WXNET_EXPORT(void)
  wxVScrolledWindow_SetLineCount(_VScrolledWindow* self, int count)
{
	self->SetLineCount(count);
}

WXNET_EXPORT(bool)
  wxVScrolledWindow_ScrollToLine(_VScrolledWindow* self, int line)
{
	return self->ScrollToLine(line)?1:0;
}

WXNET_EXPORT(bool)
  wxVScrolledWindow_ScrollLines(_VScrolledWindow* self, int lines)
{
	return self->ScrollLines(lines)?1:0;
}

WXNET_EXPORT(bool)
  wxVScrolledWindow_ScrollPages(_VScrolledWindow* self, int pages)
{
	return self->ScrollPages(pages)?1:0;
}

WXNET_EXPORT(void)
  wxVScrolledWindow_RefreshLine(_VScrolledWindow* self, int line)
{
	self->RefreshLine(line);
}

WXNET_EXPORT(void)
  wxVScrolledWindow_RefreshLines(_VScrolledWindow* self, int from, int to)
{
	self->RefreshLines(from, to);
}

WXNET_EXPORT(int)
  wxVScrolledWindow_HitTest(_VScrolledWindow* self, wxCoord x, wxCoord y)
{
	return self->HitTest(x, y);	
}

WXNET_EXPORT(int)
  wxVScrolledWindow_HitTest2(_VScrolledWindow* self, const wxPoint* pt)
{
	return self->HitTest(*pt);
}

WXNET_EXPORT(void)
  wxVScrolledWindow_RefreshAll(_VScrolledWindow* self)
{
	self->RefreshAll();
}

WXNET_EXPORT(int)
  wxVScrolledWindow_GetLineCount(_VScrolledWindow* self)
{
	return self->GetLineCount();
}

WXNET_EXPORT(int)
  wxVScrolledWindow_GetFirstVisisbleLine(_VScrolledWindow* self)
{
	return self->GetFirstVisibleLine();
}

WXNET_EXPORT(int)
  wxVScrolledWindow_GetLastVisibleLine(_VScrolledWindow* self)
{
	return self->GetLastVisibleLine();
}

WXNET_EXPORT(bool)
  wxVScrolledWindow_IsVisible(_VScrolledWindow* self, int line)
{
	return self->IsVisible(line)?1:0;
}

