//-----------------------------------------------------------------------------
// wx.NET - toolbar.cxx
// 
// The wxToolBar proxy interface
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 by Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: toolbar.cxx,v 1.12 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/toolbar.h>
#include "local_events.h"

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxToolBarToolBase*)
  wxToolBarToolBase_ctor(wxToolBar *tbar, int toolid, const wxString* labelArg, const wxBitmap* bmpNormal, const wxBitmap* bmpDisabled, wxItemKind kind, wxObject *clientData, const wxString* shortHelpStringArg, const wxString* longHelpStringArg)
{
	if (bmpNormal == NULL)
		bmpNormal = &wxNullBitmap;

	if (bmpDisabled == NULL)
		bmpDisabled = &wxNullBitmap;

   wxString longHelpString;
	if (longHelpStringArg)
		longHelpString = *longHelpStringArg;
   wxString shortHelpString;
   if (shortHelpStringArg)
      shortHelpString=*shortHelpStringArg;
   wxString label;
   if (labelArg)
      label=*labelArg;

	return new wxToolBarToolBase(tbar, toolid, label, *bmpNormal, *bmpDisabled, kind, clientData, shortHelpString, longHelpString);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxToolBarToolBase*)
  wxToolBarToolBase_ctorCtrl(wxToolBar *tbar, wxControl *control)
{
	return new wxToolBarToolBase(tbar, control);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxToolBarToolBase_GetId(wxToolBarToolBase* self)
{
	return self->GetId();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxControl*)
  wxToolBarToolBase_GetControl(wxToolBarToolBase* self)
{
	return self->GetControl();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxToolBar*)
  wxToolBarToolBase_GetToolBar(wxToolBarToolBase* self)
{
	return (wxToolBar*)self->GetToolBar();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxToolBarToolBase_IsButton(wxToolBarToolBase* self)
{
	return self->IsButton()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxToolBarToolBase_IsControl(wxToolBarToolBase* self)
{
	return self->IsControl()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxToolBarToolBase_IsSeparator(wxToolBarToolBase* self)
{
	return self->IsSeparator()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxToolBarToolBase_GetStyle(wxToolBarToolBase* self)
{
	return self->GetStyle();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxItemKind)
  wxToolBarToolBase_GetKind(wxToolBarToolBase* self)
{
	return self->GetKind();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxToolBarToolBase_IsEnabled(wxToolBarToolBase* self)
{
	return self->IsEnabled()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxToolBarToolBase_IsToggled(wxToolBarToolBase* self)
{
	return self->IsToggled()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxToolBarToolBase_CanBeToggled(wxToolBarToolBase* self)
{
	return self->CanBeToggled()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxToolBarToolBase_GetLabel(wxToolBarToolBase* self)
{
	return new wxString(self->GetLabel());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxToolBarToolBase_GetShortHelp(wxToolBarToolBase* self)
{
	return new wxString(self->GetShortHelp());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxToolBarToolBase_GetLongHelp(wxToolBarToolBase* self)
{
	return new wxString(self->GetLongHelp());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxObject*)
  wxToolBarToolBase_GetClientData(wxToolBarToolBase* self)
{
	return self->GetClientData();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxToolBarToolBase_Enable(wxToolBarToolBase* self, bool enable)
{
	return self->Enable(enable)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxToolBarToolBase_Toggle(wxToolBarToolBase* self, bool toggle)
{
	return self->Toggle(toggle)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxToolBarToolBase_SetToggle(wxToolBarToolBase* self, bool toggle)
{
	return self->SetToggle(toggle)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxToolBarToolBase_SetShortHelp(wxToolBarToolBase* self, const wxString* help)
{
   if (help)
	   return self->SetShortHelp(*help);
   else
      return false;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxToolBarToolBase_SetLongHelp(wxToolBarToolBase* self, const wxString* help)
{
   if (help)
	   return self->SetLongHelp(*help);
   else
      return false;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxToolBarToolBase_SetNormalBitmap(wxToolBarToolBase* self, const wxBitmap* bmp)
{
	self->SetNormalBitmap(*bmp);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxToolBarToolBase_SetDisabledBitmap(wxToolBarToolBase* self, const wxBitmap* bmp)
{
	self->SetDisabledBitmap(*bmp);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxToolBarToolBase_SetLabel(wxToolBarToolBase* self, const wxString* label)
{
   if (self && label)
	self->SetLabel(*label);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxToolBarToolBase_SetClientData(wxToolBarToolBase* self, wxObject *clientData)
{
	self->SetClientData(clientData);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxToolBarToolBase_Detach(wxToolBarToolBase* self)
{
	self->Detach();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxToolBarToolBase_Attach(wxToolBarToolBase* self, wxToolBar *tbar)
{
	self->Attach(tbar);
}

//-----------------------------------------------------------------------------

class _ToolBar : public wxToolBar
{
public:
    _ToolBar(wxWindow* parent, wxWindowID id, const wxPoint& pos, const wxSize& size, unsigned int style)
        : wxToolBar(parent, id, pos, size, style) { }

    DECLARE_OBJECTDELETED(_ToolBar)
};

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxToolBar*)
  wxToolBar_ctor(wxWindow* parent, wxWindowID id, const wxPoint* pos, const wxSize* size, unsigned int style)
{
    if (pos == NULL)
        pos = &wxDefaultPosition;

    if (size == NULL)
        size = &wxDefaultSize;

	return new _ToolBar(parent, id, *pos, *size, style);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxToolBarToolBase*)
  wxToolBar_AddTool1(wxToolBar* self, int toolid, const wxString* labelArg, const wxBitmap* bitmap, const wxBitmap* bmpDisabled, wxItemKind kind, const wxString* shortHelpArg, const wxString* longHelpArg, wxObject *data)
{
   wxString shortHelp;
	if (shortHelpArg)
		shortHelp = *shortHelpArg;
   wxString longHelp;
	if (longHelpArg)
		longHelp = *longHelpArg;
   wxString label;
   if (labelArg)
      label=*labelArg;
	if (bmpDisabled == NULL)
		bmpDisabled = &wxNullBitmap;
	if (bitmap == NULL)
		bitmap = &wxNullBitmap;

	return self->AddTool(toolid, label, *bitmap, *bmpDisabled, kind, shortHelp, longHelp, data);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxToolBarToolBase*)
  wxToolBar_AddTool2(wxToolBar* self, int toolid, const wxString* labelArg, const wxBitmap* bitmap, const wxString* shortHelpArg, wxItemKind kind)
{
   wxString shortHelp;
	if (shortHelpArg)
		shortHelp = *shortHelpArg;
   wxString label;
   if (labelArg)
      label=*labelArg;
	if (bitmap == NULL)
		bitmap = &wxNullBitmap;

	return self->AddTool(toolid, label, *bitmap, shortHelp, kind);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxToolBarToolBase*)
  wxToolBar_AddCheckTool(wxToolBar* self, int toolid, const wxString* labelArg, const wxBitmap* bitmap, const wxBitmap* bmpDisabled, const wxString* shortHelpArg, const wxString* longHelpArg, wxObject *data)
{
	if (bmpDisabled == NULL)
		bmpDisabled = &wxNullBitmap;
	if (bitmap == NULL)
		bitmap = &wxNullBitmap;

   wxString shortHelp;
	if (shortHelpArg)
		shortHelp = *shortHelpArg;
   wxString longHelp;
	if (longHelpArg)
		longHelp = *longHelpArg;
   wxString label;
   if (labelArg)
      label=*labelArg;

	return self->AddCheckTool(toolid, label, *bitmap, *bmpDisabled, shortHelp, longHelp, data);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxToolBarToolBase*)
  wxToolBar_AddRadioTool(wxToolBar* self, int toolid, const wxString* labelArg, const wxBitmap* bitmap, const wxBitmap* bmpDisabled, const wxString* shortHelpArg, const wxString* longHelpArg, wxObject *data)
{
	if (bmpDisabled == NULL)
		bmpDisabled = &wxNullBitmap;
	if (bitmap == NULL)
		bitmap = &wxNullBitmap;

   wxString shortHelp;
	if (shortHelpArg)
		shortHelp = *shortHelpArg;
   wxString longHelp;
	if (longHelpArg)
		longHelp = *longHelpArg;
   wxString label;
   if (labelArg)
      label=*labelArg;

	return self->AddRadioTool(toolid, label, *bitmap, *bmpDisabled, shortHelp, longHelp, data);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxToolBarToolBase*)
  wxToolBar_AddControl(wxToolBar* self, wxControl *control)
{
	return self->AddControl(control);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxToolBarToolBase*)
  wxToolBar_InsertControl(wxToolBar* self, size_t pos, wxControl *control)
{
	return self->InsertControl(pos, control);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxControl*)
  wxToolBar_FindControl(wxToolBar* self, int toolid)
{
	return self->FindControl(toolid);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxToolBarToolBase*)
  wxToolBar_AddSeparator(wxToolBar* self)
{
	return self->AddSeparator();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxToolBarToolBase*)
  wxToolBar_InsertSeparator(wxToolBar* self, size_t pos)
{
	return self->InsertSeparator(pos);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxToolBarToolBase*)
  wxToolBar_RemoveTool(wxToolBar* self, int toolid)
{
	return self->RemoveTool(toolid);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxToolBar_DeleteToolByPos(wxToolBar* self, size_t pos)
{
	return self->DeleteToolByPos(pos)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxToolBar_DeleteTool(wxToolBar* self, int toolid)
{
	return self->DeleteTool(toolid)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxToolBar_ClearTools(wxToolBar* self)
{
	self->ClearTools();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxToolBar_Realize(wxToolBar* self)
{
	return self->Realize()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxToolBar_EnableTool(wxToolBar* self, int toolid, bool enable)
{
	self->EnableTool(toolid, enable);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxToolBar_ToggleTool(wxToolBar* self, int toolid, bool toggle)
{
	self->ToggleTool(toolid, toggle);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxObject*)
  wxToolBar_GetToolClientData(wxToolBar* self, int toolid)
{
	return self->GetToolClientData(toolid);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxToolBar_SetToolClientData(wxToolBar* self, int toolid, wxObject *clientData)
{
	self->SetToolClientData(toolid, clientData);
}

//-----------------------------------------------------------------------------

#if 0
WXNET_EXPORT(int)
  wxToolBar_GetToolPos(wxToolBar* self, int id)
{
	return self->GetToolPos(id);
}
#endif

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxToolBar_GetToolState(wxToolBar* self, int toolid)
{
	return self->GetToolState(toolid)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxToolBar_GetToolEnabled(wxToolBar* self, int toolid)
{
	return self->GetToolEnabled(toolid)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxToolBar_SetToolShortHelp(wxToolBar* self, int toolid, const wxString* helpString)
{
   if (self && helpString)
	self->SetToolShortHelp(toolid, *helpString);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxToolBar_GetToolShortHelp(wxToolBar* self, int toolid)
{
	return new wxString(self->GetToolShortHelp(toolid));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxToolBar_SetToolLongHelp(wxToolBar* self, int toolid, const wxString* helpString)
{
   if (self && helpString)
	self->SetToolLongHelp(toolid, *helpString);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxToolBar_GetToolLongHelp(wxToolBar* self, int toolid)
{
	return new wxString(self->GetToolLongHelp(toolid));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxToolBar_SetMargins(wxToolBar* self, int x, int y)
{
	self->SetMargins(x, y);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxToolBar_SetToolPacking(wxToolBar* self, int packing)
{
	self->SetToolPacking(packing);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxToolBar_SetToolSeparation(wxToolBar* self, int separation)
{
	self->SetToolSeparation(separation);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxToolBar_GetToolMargins(wxToolBar* self, int* width, int* height)
{
	wxSize size = self->GetToolMargins();
   if (width)
      *width=size.GetWidth();
   if (height)
      *height=size.GetHeight();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxToolBar_GetToolPacking(wxToolBar* self)
{
	return self->GetToolPacking();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxToolBar_GetToolSeparation(wxToolBar* self)
{
	return self->GetToolSeparation();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxToolBar_SetRows(wxToolBar* self, int nRows)
{
	self->SetRows(nRows);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxToolBar_SetMaxRowsCols(wxToolBar* self, int rows, int cols)
{
	self->SetMaxRowsCols(rows, cols);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxToolBar_GetMaxRows(wxToolBar* self)
{
	return self->GetMaxRows();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxToolBar_GetMaxCols(wxToolBar* self)
{
	return self->GetMaxCols();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxToolBar_SetToolBitmapSize(wxToolBar* self, int x, int y)
{
	self->SetToolBitmapSize(wxSize(x, y));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxToolBar_GetToolBitmapSize(wxToolBar* self, int* width, int* height)
{
	wxSize size = self->GetToolBitmapSize();
   if (width)
      *width=size.GetWidth();
   if (height)
      *height=size.GetHeight();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxToolBar_GetToolSize(wxToolBar* self, int* width, int* height)
{
	wxSize size = self->GetToolSize();
   if (width)
      *width=size.GetWidth();
   if (height)
      *height=size.GetHeight();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxToolBarToolBase*)
  wxToolBar_FindToolForPosition(wxToolBar* self, wxCoord x, wxCoord y)
{
	return self->FindToolForPosition(x, y);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxToolBar_IsVertical(wxToolBar* self)
{
	return self->IsVertical()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxToolBarToolBase*)
  wxToolBar_AddTool3(wxToolBar* self, int toolid, const wxBitmap* bitmap, const wxBitmap* bmpDisabled, bool toggle, wxObject *clientData, const wxString* shortHelpArg, const wxString* longHelpArg)
{
   wxString shortHelp;
	if (shortHelpArg)
		shortHelp = *shortHelpArg;
   wxString longHelp;
	if (longHelpArg)
		longHelp = *longHelpArg;
	if (bitmap == NULL)
		bitmap = &wxNullBitmap;

	return self->AddTool(toolid, *bitmap, *bmpDisabled, toggle, clientData, shortHelp, longHelp);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxToolBarToolBase*)
  wxToolBar_AddTool4(wxToolBar* self, int toolid, const wxBitmap* bitmap, const wxString* shortHelpArg, const wxString* longHelpArg)
{
   wxString shortHelp;
	if (shortHelpArg)
		shortHelp = *shortHelpArg;
   wxString longHelp;
	if (longHelpArg)
		longHelp = *longHelpArg;
	if (bitmap == NULL)
		bitmap = &wxNullBitmap;

	return self->AddTool(toolid, *bitmap, shortHelp, longHelp);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxToolBarToolBase*)
  wxToolBar_AddTool5(wxToolBar* self, int toolid, const wxBitmap* bitmap, const wxBitmap* bmpDisabled, bool toggle, wxCoord xPos, wxCoord yPos, wxObject *clientData, const wxString* shortHelpArg, const wxString* longHelpArg)
{
   wxString shortHelp;
	if (shortHelpArg)
		shortHelp = *shortHelpArg;
   wxString longHelp;
	if (longHelpArg)
		longHelp = *longHelpArg;
	if (bmpDisabled == NULL)
		bmpDisabled = &wxNullBitmap;
	if (bitmap == NULL)
		bitmap = &wxNullBitmap;

	return self->AddTool(toolid, *bitmap, *bmpDisabled, toggle, xPos, yPos, clientData, shortHelp, longHelp);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxToolBarToolBase*)
  wxToolBar_InsertTool(wxToolBar* self, size_t pos, int toolid, const wxBitmap* bitmap, const wxBitmap* bmpDisabled, bool toggle, wxObject *clientData, const wxString* shortHelpArg, const wxString* longHelpArg)
{
	if (bmpDisabled == NULL)
		bmpDisabled = &wxNullBitmap;
	if (bitmap == NULL)
		bitmap = &wxNullBitmap;

   wxString shortHelp;
	if (shortHelpArg)
		shortHelp = *shortHelpArg;
   wxString longHelp;
	if (longHelpArg)
		longHelp = *longHelpArg;

	return self->InsertTool(pos, toolid, *bitmap, *bmpDisabled, toggle, clientData, shortHelp, longHelp);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxToolBar_GetMargins(wxToolBar* self, wxSize* size)
{
	*size = self->GetMargins();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(size_t)
  wxToolBar_GetToolsCount(wxToolBar* self)
{
	return self->GetToolsCount();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxToolBar_AcceptsFocus(wxToolBar* self)
{
	return self->AcceptsFocus()?1:0;
}

