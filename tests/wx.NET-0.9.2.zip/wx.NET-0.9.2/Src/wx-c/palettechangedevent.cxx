//-----------------------------------------------------------------------------
// wx.NET - palettechangedevent.cxx
// 
// The wxPaletteChangedEvent proxy interface.
//
// Written by Alexander Olk (xenomorph2@onlinehome.de)
// (C) 2004 by Alexander Olk
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: palettechangedevent.cxx,v 1.3 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#ifndef WXNET_GLOBAL_H
#include "wxnet_globals.h"
#endif

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxPaletteChangedEvent*)
  wxPaletteChangedEvent_ctor(wxEventType type)
{
    return new wxPaletteChangedEvent(type);
}

WXNET_EXPORT(void)
  wxPaletteChangedEvent_SetChangedWindow(wxPaletteChangedEvent* self, wxWindow* win)
{
	self->SetChangedWindow(win);
}

WXNET_EXPORT(wxWindow*)
  wxPaletteChangedEvent_GetChangedWindow(wxPaletteChangedEvent* self)
{
	return self->GetChangedWindow();
}
