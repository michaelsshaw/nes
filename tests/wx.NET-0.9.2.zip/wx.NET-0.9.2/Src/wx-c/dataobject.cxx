//-----------------------------------------------------------------------------
// wx.NET - dataobj.cxx
//
// The wxDataObject proxy interface.
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 by Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: dataobject.cxx,v 1.14 2009/07/12 07:56:06 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/dataobj.h>
#include "local_events.h"

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxDataObject_dtor(wxDataObject* self)
{
	WXNET_DEL( self );
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxDataObject_GetPreferredFormat(wxDataObject* self, wxDataObject::Direction dir, wxDataFormat* dataFormat)
{
	*dataFormat = self->GetPreferredFormat(dir);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(size_t)
  wxDataObject_GetFormatCount(wxDataObject* self, wxDataObject::Direction dir)
{
	return self->GetFormatCount(dir);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxDataObject_GetAllFormats(wxDataObject* self, wxDataFormat *formats, wxDataObject::Direction dir)
{
	self->GetAllFormats(formats, dir);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(size_t)
  wxDataObject_GetDataSize(wxDataObject* self, const wxDataFormat* format)
{
	return self->GetDataSize(*format);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxDataObject_GetDataHere(wxDataObject* self, const wxDataFormat* format, void *buf)
{
	return self->GetDataHere(*format, buf)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxDataObject_SetData(wxDataObject* self, const wxDataFormat* format, size_t len, const void * buf)
{
	return self->SetData(*format, len, buf)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxDataObject_IsSupported(wxDataObject* self, const wxDataFormat* format, wxDataObject::Direction dir)
{
	return self->IsSupported(*format, dir)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxDataObjectSimple*)
  wxDataObjectSimple_ctor(const wxDataFormat* format)
{
	if (format == NULL)
		format = &wxFormatInvalid;

	return new wxDataObjectSimple(*format);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxDataObjectSimple_dtor(wxDataObjectSimple* self)
{
	WXNET_DEL( self );
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxDataObjectSimple_SetFormat(wxDataObjectSimple* self, const wxDataFormat* format)
{
	self->SetFormat(*format);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(size_t)
  wxDataObjectSimple_GetDataSize(wxDataObjectSimple* self)
{
	return self->GetDataSize();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxDataObjectSimple_GetDataHere(wxDataObjectSimple* self, void *buf)
{
	return self->GetDataHere(buf)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxDataObjectSimple_SetData(wxDataObjectSimple* self, size_t len, const void *buf)
{
	return self->SetData(len, buf)?1:0;
}

//-----------------------------------------------------------------------------
// wxTextDataObject

class _TextDataObject : public wxTextDataObject
{
public:
	_TextDataObject(const wxString& text)
		: wxTextDataObject(text) {}

	DECLARE_DISPOSABLE(_TextDataObject)
};

WXNET_EXPORT(wxTextDataObject*)
  wxTextDataObject_ctor(const wxString* text)
{
   if (text)
	   return new _TextDataObject(*text);
   else
      return NULL;
}

WXNET_EXPORT(void)
  wxTextDataObject_dtor(wxTextDataObject* self)
{
	WXNET_DEL(self);
}

WXNET_EXPORT(void)
  wxTextDataObject_RegisterDisposable(_TextDataObject* self, Virtual_Dispose onDispose)
{
	self->RegisterDispose(onDispose);
}

WXNET_EXPORT(size_t)
  wxTextDataObject_GetTextLength(wxTextDataObject* self)
{
	return self->GetTextLength();
}

WXNET_EXPORT(wxString*)
  wxTextDataObject_GetText(wxTextDataObject* self)
{
	return new wxString(self->GetText());
}

WXNET_EXPORT(void)
  wxTextDataObject_SetText(wxTextDataObject* self, const wxString* text)
{
   if (text)
	   self->SetText(*text);
}

//-----------------------------------------------------------------------------

class _FileDataObject : public wxFileDataObject
{
public:
	_FileDataObject()
		: wxFileDataObject() {}

	DECLARE_DISPOSABLE(_FileDataObject)
};

WXNET_EXPORT(wxFileDataObject*)
  wxFileDataObject_ctor()
{
	return new _FileDataObject();
}

WXNET_EXPORT(void)
  wxFileDataObject_dtor(wxFileDataObject* self)
{
	WXNET_DEL(self);
}

WXNET_EXPORT(void)
  wxFileDataObject_RegisterDisposable(_FileDataObject* self, Virtual_Dispose onDispose)
{
	self->RegisterDispose(onDispose);
}

WXNET_EXPORT(void)
  wxFileDataObject_AddFile(wxFileDataObject* self, const wxString* filename)
{
   if (self && filename)
	   self->AddFile(*filename);
}

WXNET_EXPORT(wxArrayString*)
  wxFileDataObject_GetFilenames(wxFileDataObject* self)
{
	wxArrayString* was = new wxArrayString();
	*was = self->GetFilenames();
	return was;
}

// __________________________________________________

class _DataObjectComposite : public wxDataObjectComposite
{
public:
	_DataObjectComposite()
		: wxDataObjectComposite() {}

	DECLARE_DISPOSABLE(_DataObjectComposite)
};

WXNET_EXPORT(wxDataObjectComposite*)
  wxDataObjectComposite_ctor()
{
	return new _DataObjectComposite();
}

WXNET_EXPORT(void)
  wxDataObjectComposite_RegisterDisposable(wxDataObjectComposite* self, Virtual_Dispose onDispose)
{
    if (self)
    {
        _DataObjectComposite* selfCast=dynamic_cast<_DataObjectComposite*>(self);
        if (selfCast)
	        selfCast->RegisterDispose(onDispose);
    }
}

WXNET_EXPORT(void)
  wxDataObjectComposite_Add(wxDataObjectComposite* self, wxDataObjectSimple *object, bool preferred)
{
    if (self && object)
    {
        self->Add(object, preferred);
    }
}

WXNET_EXPORT(wxDataFormat*)
  wxDataObjectComposite_GetReceivedFormat(wxDataObjectComposite* self)
{
    if (self)
        return new wxDataFormat(self->GetReceivedFormat());
    else
        return NULL;
}

// __________________________________________________

class _BitmapDataObject : public wxBitmapDataObject
{
public:
	_BitmapDataObject(const wxBitmap& bitmap)
        : wxBitmapDataObject(bitmap), m_onDispose(NULL) {}

	DECLARE_DISPOSABLE(_BitmapDataObject)
};

WXNET_EXPORT(wxBitmapDataObject*)
  wxBitmapDataObject_ctor(const wxBitmap* bitmap)
{
    return new _BitmapDataObject(bitmap ? *bitmap : wxNullBitmap);
}

WXNET_EXPORT(void)
  wxBitmapDataObject_RegisterDisposable(wxBitmapDataObject* self, Virtual_Dispose onDispose)
{
    if (self)
    {
        _BitmapDataObject* selfCast=dynamic_cast<_BitmapDataObject*>(self);
        if (selfCast)
	        selfCast->RegisterDispose(onDispose);
    }
}

WXNET_EXPORT(wxBitmap*) wxBitmapDataObject_GetBitmap(const wxBitmapDataObject* self)
{
    if (self)
        return new wxBitmap(self->GetBitmap());
    else
        return NULL;
}

WXNET_EXPORT(void) wxBitmapDataObject_SetBitmap(wxBitmapDataObject* self, const wxBitmap* bitmap)
{
    if (self && bitmap)
    {
        self->SetBitmap(*bitmap);
    }
}
