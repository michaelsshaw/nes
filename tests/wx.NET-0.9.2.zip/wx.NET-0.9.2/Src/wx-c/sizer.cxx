//-----------------------------------------------------------------------------
// wx.NET - sizer.cxx
//
// The wxSizer proxy interface.
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: sizer.cxx,v 1.12 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include "wxnet_globals.h"


WXNET_EXPORT(void)
  wxSizer_AddWindow(wxSizer* self, wxWindow* window, int proportion, int flag,
		int border, wxObject* userData)
{
	self->Add(window, proportion, flag, border, userData);
}

WXNET_EXPORT(void)
  wxSizer_AddSizer(wxSizer* self, wxSizer* sizer, int proportion, int flag,
					int border,	wxObject* userData)
{
	self->Add(sizer, proportion, flag, border, userData);
}

WXNET_EXPORT(void)
  wxSizer_Add(wxSizer* self, int width, int height, int proportion,
				int flag, int border, wxObject* userData)
{
	self->Add(width, height, proportion, flag, border, userData);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxSizer_Fit(wxSizer* self, wxWindow *window, wxSize* size)
{
	*size = self->Fit(window);
}

WXNET_EXPORT(void)
  wxSizer_FitInside(wxSizer* self, wxWindow *window)
{
	self->FitInside(window);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxSizer_InsertWindow(wxSizer* self, int before, wxWindow *window,
						  int option, int flag, int border, wxObject* userData)
{
	self->Insert(before, window, option, flag, border, userData);
}

WXNET_EXPORT(void)
  wxSizer_InsertSizer(wxSizer* self, int before, wxSizer *sizer,
						 int option, int flag, int border, wxObject* userData)
{
	self->Insert(before, sizer, option, flag, border, userData);
}

WXNET_EXPORT(void)
  wxSizer_Insert(wxSizer* self, int before, int width, int height,
					int option, int flag, int border, wxObject* userData)
{
	self->Insert(before, width, height, option, flag, border, userData);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxSizer_PrependWindow(wxSizer* self, wxWindow *window, int option,
						   int flag, int border, wxObject* userData)
{
	self->Prepend(window, option, flag, border, userData);
}

WXNET_EXPORT(void)
  wxSizer_PrependSizer(wxSizer* self, wxSizer *sizer, int option, int flag,
						  int border, wxObject* userData)
{
	self->Prepend(sizer, option, flag, border, userData);
}

WXNET_EXPORT(void)
  wxSizer_Prepend(wxSizer* self, int width, int height, int option,
					 int flag, int border, wxObject* userData)
{
	self->Prepend(width, height, option, flag, border, userData);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxSizer_RemoveWindow(wxSizer* self, wxWindow *window)
{
	return self->Detach(window)?1:0;
}

WXNET_EXPORT(bool)
  wxSizer_RemoveSizer(wxSizer* self, wxSizer *sizer)
{
	return self->Remove(sizer)?1:0;
}

WXNET_EXPORT(bool)
  wxSizer_Remove(wxSizer* self, int pos)
{
	return self->Remove(pos)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxSizer_Clear(wxSizer* self, bool delete_windows)
{
	self->Clear(delete_windows);
}

WXNET_EXPORT(void)
  wxSizer_DeleteWindows(wxSizer* self)
{
	self->DeleteWindows();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxSizer_SetMinSize(wxSizer* self, wxSize* size)
{
	self->SetMinSize(*size);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxSizer_SetItemMinSizeWindow(wxSizer* self, wxWindow *window, wxSize* size)
{
	return self->SetItemMinSize(window, *size)?1:0;
}

WXNET_EXPORT(bool)
  wxSizer_SetItemMinSizeSizer(wxSizer* self, wxSizer *sizer, wxSize* size)
{
	return self->SetItemMinSize(sizer, *size)?1:0;
}

WXNET_EXPORT(bool)
  wxSizer_SetItemMinSize(wxSizer* self, int pos, wxSize* size)
{
	return self->SetItemMinSize(pos, *size)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxSizer_GetSize(wxSizer* self, wxSize* size)
{
	*size = self->GetSize();
}

WXNET_EXPORT(void)
  wxSizer_GetPosition(wxSizer* self, wxPoint *pt)
{
	*pt = self->GetPosition();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxSizer_GetMinSize(wxSizer* self, wxSize* size)
{
	*size = self->GetMinSize();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxSizer_RecalcSizes(wxSizer* self)
{
	self->RecalcSizes();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxSizer_CalcMin(wxSizer* self, wxSize* size)
{
	*size = self->CalcMin();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxSizer_Layout(wxSizer* self)
{
	self->Layout();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxSizer_SetSizeHints(wxSizer* self, wxWindow *window)
{
	self->SetSizeHints(window);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxSizer_SetVirtualSizeHints(wxSizer* self, wxWindow *window)
{
	self->SetVirtualSizeHints(window);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxSizer_SetDimension(wxSizer* self, int x, int y, int width, int height)
{
	self->SetDimension(x, y, width, height);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxSizer_ShowWindow(wxSizer* self, wxWindow *window, bool show)
{
	self->Show(window, show);
}

WXNET_EXPORT(void)
  wxSizer_HideWindow(wxSizer* self, wxWindow *window)
{
	self->Hide(window);
}

WXNET_EXPORT(void)
  wxSizer_ShowSizer(wxSizer* self, wxSizer *sizer, bool show)
{
	self->Show(sizer, show);
}

WXNET_EXPORT(void)
  wxSizer_HideSizer(wxSizer* self, wxSizer *sizer)
{
	self->Hide(sizer);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxSizer_IsShownWindow(wxSizer* self, wxWindow *window)
{
	return self->IsShown(window)?1:0;
}

WXNET_EXPORT(bool)
  wxSizer_IsShownSizer(wxSizer* self, wxSizer *sizer)
{
	return self->IsShown(sizer)?1:0;
}


WXNET_EXPORT(bool)
  wxSizer_Detach(wxSizer* self, wxWindow* window)
{
	return self->Detach(window)?1:0;
}

WXNET_EXPORT(bool)
  wxSizer_Detach2(wxSizer* self, wxSizer* sizer)
{
	return self->Detach(sizer)?1:0;
}

WXNET_EXPORT(bool)
  wxSizer_Detach3(wxSizer* self, int index)
{
	return self->Detach(index)?1:0;
}

