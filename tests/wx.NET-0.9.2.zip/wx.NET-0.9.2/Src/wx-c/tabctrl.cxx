//-----------------------------------------------------------------------------
// wx.NET - tabctrl.cxx
// 
// The wxTabCtrl proxy interface.
//
// Written by Alexander Olk (xenomorph2@onlinehome.de)
// (C) 2004 by Alexander Olk
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: tabctrl.cxx,v 1.7 2010/06/06 08:53:52 harald_meyer Exp $
//-----------------------------------------------------------------------------

#ifdef __WXMSW__  

#include <wx/wx.h>
#include <wx/tabctrl.h>
#include "local_events.h"

//-----------------------------------------------------------------------------

class _TabCtrl : public wxTabCtrl
{
public:
	_TabCtrl()
		: wxTabCtrl() {}
		
	_TabCtrl(wxWindow* parent, wxWindowID id, const wxPoint& pos, const wxSize& size, long style, const wxString& name)
		: wxTabCtrl(parent, id, pos, size, style, name) {}

	DECLARE_OBJECTDELETED(_TabCtrl)
};

WXNET_EXPORT(wxTabCtrl*)
  wxTabCtrl_ctor()
{
	return new _TabCtrl();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxTabCtrl*)
  wxTabCtrl_ctor2(wxWindow *parent, wxWindowID id, int posX, int posY, int width, int height,
            int style, const wxString* nameArg)
{
   wxString name;
	if (nameArg == NULL)
		name = wxT("tabctrl");
   else
      name=*nameArg;

	return new _TabCtrl(parent, id, wxPoint(posX, posY), wxSize(width, height), style, name);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxTabCtrl_Create(wxTabCtrl* self, wxWindow *parent, wxWindowID id, int posX, int posY, int width, int height,
            int style, const wxString* nameArg)
{
   wxString name;
	if (nameArg == NULL)
		name = wxT("tabctrl");
   else
      name=*nameArg;

	return self->Create(parent, id, wxPoint(posX, posY), wxSize(width, height), style, name);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxTabCtrl_GetSelection(wxTabCtrl* self)
{
	return self->GetSelection();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxTabCtrl_GetCurFocus(wxTabCtrl* self)
{
	return self->GetCurFocus();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxImageList*)
  wxTabCtrl_GetImageList(wxTabCtrl* self)
{
	return self->GetImageList();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxTabCtrl_GetItemCount(wxTabCtrl* self)
{
	return self->GetItemCount();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxTabCtrl_GetItemRect(wxTabCtrl* self, int item, wxRect* rect)
{
	return self->GetItemRect(item, *rect)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxTabCtrl_GetRowCount(wxTabCtrl* self)
{
	return self->GetRowCount();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxTabCtrl_GetItemText(wxTabCtrl* self, int item)
{
	return new wxString(self->GetItemText(item));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxTabCtrl_GetItemImage(wxTabCtrl* self, int item)
{
	return self->GetItemImage(item);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void*)
  wxTabCtrl_GetItemData(wxTabCtrl* self, int item)
{
	return self->GetItemData(item);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxTabCtrl_SetSelection(wxTabCtrl* self, int item)
{
	return self->SetSelection(item);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTabCtrl_SetImageList(wxTabCtrl* self, wxImageList* imageList)
{
	self->SetImageList(imageList);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxTabCtrl_SetItemText(wxTabCtrl* self, int item, const wxString* text)
{
   if (self && text)
	return self->SetItemText(item, *text);
   else
      return false;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxTabCtrl_SetItemImage(wxTabCtrl* self, int item, int image)
{
	return self->SetItemImage(item, image)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxTabCtrl_SetItemData(wxTabCtrl* self, int item, void* data)
{
	return self->SetItemData(item, data)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTabCtrl_SetItemSize(wxTabCtrl* self, const wxSize* size)
{
	self->SetItemSize(*size);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTabCtrl_SetPadding(wxTabCtrl* self, const wxSize* padding)
{
	self->SetPadding(*padding);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxTabCtrl_DeleteAllItems(wxTabCtrl* self)
{
	return self->DeleteAllItems()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxTabCtrl_DeleteItem(wxTabCtrl* self, int item)
{
	return self->DeleteItem(item)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxTabCtrl_HitTest(wxTabCtrl* self, const wxPoint* pt, int* flags)
{
   long lflags=flags;
	int result = self->HitTest(*pt, &lflags);
   flags=lflags;
   return result;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxTabCtrl_InsertItem(wxTabCtrl* self, int item, const wxString* text, int imageId, void* data)
{
   if (self && text)
	return self->InsertItem(item, *text, imageId, data);
   else
      return false;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxTabEvent*)
  wxTabEvent_ctor(wxEventType commandType, int id, int nSel, int nOldSel)
{
    return new wxTabEvent(commandType, id, nSel, nOldSel);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxTabEvent_GetSelection(wxTabEvent* self)
{
    return self->GetSelection();
}

WXNET_EXPORT(void)
  wxTabEvent_SetSelection(wxTabEvent* self, int nSel)
{
    self->SetSelection(nSel);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxTabEvent_GetOldSelection(wxTabEvent* self)
{
    return self->GetOldSelection();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTabEvent_SetOldSelection(wxTabEvent* self, int nOldSel)
{
    self->SetOldSelection(nOldSel);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTabEvent_Veto(wxTabEvent* self)
{
    self->Veto();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTabEvent_Allow(wxTabEvent* self)
{
    self->Allow();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxTabEvent_IsAllowed(wxTabEvent* self)
{
    return self->IsAllowed()?1:0;
}

#endif
 
