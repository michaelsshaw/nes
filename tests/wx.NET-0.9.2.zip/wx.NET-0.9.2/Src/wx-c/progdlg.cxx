//-----------------------------------------------------------------------------
// wx.NET - progdlg.cxx
//
// The wxProgressDialog proxy interface.
//
// Written by Alexander Olk (xenomorph2@onlinehome.de)
// (C) 2003 by Alexander Olk
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: progdlg.cxx,v 1.7 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/progdlg.h>
#include "local_events.h"

class _ProgressDialog : public wxProgressDialog
{
    public:
        _ProgressDialog(const wxString title, const wxString& message,
			int maximum, wxWindow* parent, unsigned int style)
            : wxProgressDialog(title, message, maximum, parent, style)
        {
        }

        DECLARE_OBJECTDELETED(_ProgressDialog)
};


//-----------------------------------------------------------------------------

WXNET_EXPORT(wxProgressDialog*)
  wxProgressDialog_ctor(const wxString* titleArg, const wxString* messageArg,
        int maximum, wxWindow* parent, unsigned int style)
{
   wxString title;
   if (titleArg)
      title=*titleArg;
   wxString message;
   if (messageArg)
      message=*messageArg;
    return new _ProgressDialog(title, message, maximum, parent, style);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxProgressDialog_dtor(wxProgressDialog* self)
{
    WXNET_DEL( self );
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxProgressDialog_Update(wxProgressDialog* self, int value, const wxString* newmsg)
{
   if (self && newmsg)
    return self->Update(value, *newmsg);
   return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxProgressDialog_Resume(wxProgressDialog* self)
{
    self->Resume();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxProgressDialog_Show(wxProgressDialog* self, bool show)
{
	return self->Show(show)?1:0;
}



