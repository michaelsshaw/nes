//-----------------------------------------------------------------------------
// wx.NET - window.cxx
//
// The wxWindow proxy interface.
//
// Written by Jason Perkins (jason@379.com)
// (C) 2003 by 379, Inc.
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: window.cxx,v 1.41 2010/06/06 08:53:52 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/tooltip.h>
#include "local_events.h"

//-----------------------------------------------------------------------------
// The proxy class

class _Window : public wxWindow, public ValidatorStub
{
public:
	_Window(wxWindow* parent, wxWindowID id, const wxPoint& pos, const wxSize& size, long style, const wxString& name)
		: wxWindow(parent, id, pos, size, style, name)
	{
	}

    DECLARE_OBJECTDELETED(_Window)

#include "window.inc"
};

//-----------------------------------------------------------------------------
// C stubs for class methods

WXNET_EXPORT(wxWindow*)
  wxWindow_ctor(wxWindow *parent, wxWindowID id, int posX, int posY,
					         int width, int height, unsigned int style, const wxString* nameArg)
{
   wxString name;
	if (nameArg == NULL)
		name = wxPanelNameStr;
   else
      name=*nameArg;

	return new _Window(parent, id, wxPoint(posX, posY), wxSize(width, height), style, name);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void) wxWindow_RegisterValidator(wxWindow* selfArg, ValidatorFct validator)
{
   ValidatorStub* self=dynamic_cast<ValidatorStub*>(selfArg);
   if (self)
   {
      self->Set(validator);
   }
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxWindow_Close(wxWindow* self, bool force)
{
    if (self)
	return self->Close(force);
    else
        return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_GetClientSize(wxWindow* self, wxSize* size)
{
    if (self && size)
	self->GetClientSize(&size->x, &size->y);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_SetSize(wxWindow* self, int x, int y, int width, int height, int flags)
{
    if (self)
	self->SetSize(x, y, width, height, flags);
}

WXNET_EXPORT(void)
  wxWindow_SetSize2(wxWindow* self, int width, int height)
{
    if (self)
	self->SetSize(width, height);
}

WXNET_EXPORT(void)
  wxWindow_SetSize3(wxWindow* self, wxSize* size)
{
    if (self)
	self->SetSize(*size);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_Move(wxWindow* self, int x, int y, int flags)
{
    if (self)
	self->Move(x, y, flags);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxWindow_Show(wxWindow* self, bool show)
{
    if (self)
	return self->Show(show);
    else
        return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_GetBestSize(wxWindow* self, wxSize* size)
{
    if (self && size)
	*size = self->GetBestSize();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxWindow_GetId(wxWindow *self)
{
    if (self)
	return self->GetId();
    else
        return -1;
}

WXNET_EXPORT(void)
  wxWindow_SetId(wxWindow *self, int id)
{
    if (self)
	self->SetId(id);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxWindow_GetWindowStyleFlag(wxWindow* self)
{
    if (self)
	return self->GetWindowStyleFlag();
    else
        return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_Layout(wxWindow* self)
{
    if (self)
	self->Layout();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_SetAutoLayout(wxWindow* self, bool autoLayout)
{
	self->SetAutoLayout(autoLayout);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_SetBackgroundColour(wxWindow* self, wxColour* colour)
{
	self->SetBackgroundColour(*colour);
}

WXNET_EXPORT(void)
  wxWindow_SetForegroundColour(wxWindow* self, wxColour* colour)
{
	self->SetForegroundColour(*colour);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_SetCursor(wxWindow* self, wxCursor* cursor)
{
    if (self && cursor)
	self->SetCursor(*cursor);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxCursor*) wxWindow_GetCursor(wxWindow* self)
{
    if (self)
        return new wxCursor(self->GetCursor());
    else
        return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_SetSizer(wxWindow *self, wxSizer *sizer, bool deleteOld)
{
	self->SetSizer(sizer, deleteOld);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_SetWindowStyleFlag(wxWindow* self, unsigned int style)
{
	self->SetWindowStyleFlag(style);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxWindow_SetFont(wxWindow* self, wxFont* font)
{
	return self->SetFont(*font);
}

WXNET_EXPORT(wxFont*)
  wxWindow_GetFont(wxWindow* self)
{
	return new wxFont(self->GetFont());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_SetToolTip(wxWindow* self, const wxString* tip)
{
   if (self && tip)
	   self->SetToolTip(*tip);
}

WXNET_EXPORT(wxString*)
  wxWindow_GetToolTip(const wxWindow* self)
{
   wxString* result=new wxString();
   if (!self)
      return result;
   wxToolTip* tooltip=self->GetToolTip();
   if (!tooltip)
      return result;
   *result=tooltip->GetTip();
   return result;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxWindow_Enable(wxWindow* self, bool enable)
{
	return self->Enable(enable);
}

WXNET_EXPORT(char)
  wxWindow_IsEnabled(wxWindow* self)
{
	return self->IsEnabled();
}

//-----------------------------------------------------------------------------

#if 0
WXNET_EXPORT(char)
  wxWindow_LoadFromResource(wxWindow* self, wxWindow *parent, const wxString* resourceName, const wxResourceTable *table)
{
   if (self && resourceName)
	   return self->LoadFromResource(parent, *resourceName, table);
   else
      return 0;
}
#endif

//-----------------------------------------------------------------------------

#if 0
WXNET_EXPORT(wxControl*)
  wxWindow_CreateItem(wxWindow* self, const wxItemResource* childResource, const wxItemResource* parentResource, const wxResourceTable *table)
{
	return self->CreateItem(childResource, parentResource, table);
}
#endif

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxWindow_Destroy(wxWindow* self)
{
    if (self)
	    return self->Destroy();
    else
        return false;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
   wxWindow_DestroyChildren(wxWindow* self)
{
    if (self)
	    return self->DestroyChildren();
    else
        return false;
}

//-----------------------------------------------------------------------------

// Use wxWindow_SetLabel instead
// HMaH: it does not make sense to enforce the wx.NET dll to
// address the title by SetLabel/GetLabel. It is better to
// do this transparently in this method.
WXNET_EXPORT(void)
  wxWindow_SetTitle(wxWindow* self, const wxString* title)
{
   if (!self || !title)
      return;
#if wxCHECK_VERSION(2, 8, 0)
    self->SetLabel(*title);
#else    
	self->SetTitle(*title);
#endif	
}

WXNET_EXPORT(void)
  wxWindow_SetLabel(wxWindow* self, const wxString* title)
{
   if (self && title)
	   self->SetLabel(*title);
}

//-----------------------------------------------------------------------------

// Use wxWindow_GetLabel instead
WXNET_EXPORT(wxString*)
  wxWindow_GetTitle(wxWindow* self)
{
#if wxCHECK_VERSION(2, 8, 0)
    return new wxString(self->GetLabel());
#else    
	return new wxString(self->GetTitle());
#endif	
}

WXNET_EXPORT(wxString*)
  wxWindow_GetLabel(wxWindow* self)
{
	return new wxString(self->GetLabel());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_SetName(wxWindow* self, const wxString* name)
{
   if (self && name)
	   self->SetName(*name);
}

WXNET_EXPORT(wxString*)
  wxWindow_GetName(wxWindow* self)
{
	return new wxString(self->GetName());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxWindow_NewControlId()
{
	return wxWindow::NewControlId();
}

WXNET_EXPORT(int)
  wxWindow_NextControlId(int id)
{
	return wxWindow::NextControlId(id);
}

WXNET_EXPORT(int)
  wxWindow_PrevControlId(int id)
{
	return wxWindow::PrevControlId(id);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_Raise(wxWindow* self)
{
	self->Raise();
}

WXNET_EXPORT(void)
  wxWindow_Lower(wxWindow* self)
{
	self->Lower();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_SetClientSize(wxWindow* self, int width, int height)
{
	self->SetClientSize(width, height);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_GetPosition(wxWindow* self, wxPoint *point)
{
	*point = self->GetPosition();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_GetSize(wxWindow* self, wxSize* size)
{
	*size = self->GetSize();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_GetRect(wxWindow* self, wxRect* rect)
{
	*rect = self->GetRect();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_GetClientAreaOrigin(wxWindow* self, wxPoint* point)
{
	*point = self->GetClientAreaOrigin();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_GetClientRect(wxWindow* self, wxRect* rect)
{
	*rect = self->GetClientRect();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_GetAdjustedBestSize(wxWindow* self, wxSize* size)
{
#if wxCHECK_VERSION(2, 8, 0)
	*size = self->GetEffectiveMinSize();
#else
	*size = self->GetAdjustedBestSize();
#endif
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_Center(wxWindow* self, int direction)
{
	self->Center(direction);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_CenterOnScreen(wxWindow* self, int dir)
{
#if wxCHECK_VERSION(2, 8, 0)
	self->Centre(wxCENTRE_ON_SCREEN);
#else
	self->CenterOnScreen(dir);
#endif
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_CenterOnParent(wxWindow* self, int dir)
{
	self->CenterOnParent(dir);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_Fit(wxWindow* self)
{
	self->Fit();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_FitInside(wxWindow* self)
{
	self->FitInside();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_SetSizeHints(wxWindow* self, int minW, int minH, int maxW, int maxH, int incW, int incH)
{
	self->SetSizeHints(minW, minH, maxW, maxH, incW, incH);
}

WXNET_EXPORT(void)
  wxWindow_SetVirtualSizeHints(wxWindow* self, int minW, int minH, int maxW, int maxH)
{
	self->SetVirtualSizeHints(minW, minH, maxW, maxH);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxWindow_GetMinWidth(const wxWindow* self)
{
	return self->GetMinWidth();
}

WXNET_EXPORT(int)
  wxWindow_GetMinHeight(const wxWindow* self)
{
	return self->GetMinHeight();
}

WXNET_EXPORT(void)
  wxWindow_SetMinSize(wxWindow* self, int w, int h)
{
   if (self) self->SetMinSize(wxSize(w, h));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxWindow_GetMaxWidth(wxWindow* self)
{
	return self->GetMaxWidth();
}

WXNET_EXPORT(int)
  wxWindow_GetMaxHeight(wxWindow* self)
{
	return self->GetMaxHeight();
}

WXNET_EXPORT(void)
  wxWindow_SetMaxSize(wxWindow* self, int w, int h)
{
   if (self) self->SetMaxSize(wxSize(w, h));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_GetMaxSize(wxWindow* self, wxSize* size)
{
	*size = self->GetMaxSize();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_SetVirtualSize(wxWindow* self, int w, int h)
{
	if (self) self->SetVirtualSize(wxSize(w, h));
}

WXNET_EXPORT(void)
  wxWindow_GetVirtualSize(wxWindow* self, wxSize* size)
{
	*size = self->GetVirtualSize();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_GetBestVirtualSize(wxWindow* self, wxSize* size)
{
	*size = self->GetBestVirtualSize();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxWindow_Hide(wxWindow* self)
{
	return self->Hide();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxWindow_Disable(wxWindow* self)
{
	return self->Disable();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxWindow_IsShown(wxWindow* self)
{
	return self->IsShown();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_SetWindowStyle(wxWindow* self, int style)
{
	self->SetWindowStyle(style);
}

WXNET_EXPORT(int)
  wxWindow_GetWindowStyle(wxWindow* self)
{
	return (int)self->GetWindowStyle();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxWindow_HasFlag(wxWindow* self, int flag)
{
	return self->HasFlag(flag);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxWindow_IsRetained(wxWindow* self)
{
	return self->IsRetained();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_SetExtraStyle(wxWindow* self, int exStyle)
{
	self->SetExtraStyle(exStyle);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxWindow_GetExtraStyle(wxWindow* self)
{
	return (int)self->GetExtraStyle();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_MakeModal(wxWindow* self, bool modal)
{
	self->MakeModal(modal);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_SetThemeEnabled(wxWindow* self, bool enableTheme)
{
	self->SetThemeEnabled(enableTheme);
}

WXNET_EXPORT(char)
  wxWindow_GetThemeEnabled(wxWindow* self)
{
	return self->GetThemeEnabled();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_SetFocus(wxWindow* self)
{
   self->wxWindow::SetFocus();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_SetFocusFromKbd(wxWindow* self)
{
	self->SetFocusFromKbd();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxWindow*)
  wxWindow_FindFocus()
{
	return wxWindow::FindFocus();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxWindow_AcceptsFocus(wxWindow* self)
{
	return self->AcceptsFocus();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxWindow_AcceptsFocusFromKeyboard(wxWindow* self)
{
	return self->AcceptsFocusFromKeyboard();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxWindow*)
  wxWindow_GetDefaultItem(wxWindow* self)
{
#if wxCHECK_VERSION(2, 8, 0)
	return wxDynamicCast(
			wxGetTopLevelParent(self),
			wxTopLevelWindow
		)->GetDefaultItem();
#else
	return self->GetDefaultItem();
#endif
}

WXNET_EXPORT(wxWindow*)
  wxWindow_SetDefaultItem(wxWindow* self, wxWindow *child)
{
#if wxCHECK_VERSION(2, 8, 0)
	return wxDynamicCast(
			wxGetTopLevelParent(self),
			wxTopLevelWindow
		)->SetDefaultItem(child);
#else
	return self->SetDefaultItem(child);
#endif
}

//-----------------------------------------------------------------------------

#if (!wxCHECK_VERSION(2, 8, 0))
WXNET_EXPORT(void)
  wxWindow_SetTmpDefaultItem(wxWindow* self, wxWindow *win)
{
	self->SetTmpDefaultItem(win);
}
#endif

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxWindow*)
  wxWindow_GetParent(wxWindow* self)
{
	return self->GetParent();
}

WXNET_EXPORT(wxWindow*)
  wxWindow_GetGrandParent(wxWindow* self)
{
	return self->GetGrandParent();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxWindow_IsTopLevel(wxWindow* self)
{
	return self->IsTopLevel();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_SetParent(wxWindow* self, wxWindow *parent)
{
	self->SetParent(parent);
}

WXNET_EXPORT(char)
  wxWindow_Reparent(wxWindow* self, wxWindow *newParent)
{
	return self->Reparent(newParent);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_AddChild(wxWindow* self, wxWindow *child)
{
	self->AddChild(child);
}

WXNET_EXPORT(void)
  wxWindow_RemoveChild(wxWindow* self, wxWindow *child)
{
	self->RemoveChild(child);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxWindow*)
  wxWindow_FindWindowId(wxWindow* self, int id)
{
	return self->FindWindow(id);
}

WXNET_EXPORT(wxWindow*)
  wxWindow_FindWindowName(wxWindow* self, const wxString* name)
{
   if (self && name)
	   return self->FindWindow(*name);
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxWindow*)
  wxWindow_FindWindowById(int id, const wxWindow *parent)
{
	return wxWindow::FindWindowById(id, parent);
}

WXNET_EXPORT(wxWindow*)
  wxWindow_FindWindowByName(const wxString* name, const wxWindow *parent)
{
   if (name)
	   return wxWindow::FindWindowByName(*name, parent);
   else
      return NULL;
}

WXNET_EXPORT(wxWindow*)
  wxWindow_FindWindowByLabel(const wxString* label, const wxWindow *parent)
{
   if (label)
	   return wxWindow::FindWindowByLabel(*label, parent);
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxEvtHandler*)
  wxWindow_GetEventHandler(wxWindow* self)
{
	return self->GetEventHandler();
}

WXNET_EXPORT(void)
  wxWindow_SetEventHandler(wxWindow* self, wxEvtHandler *handler)
{
	self->SetEventHandler(handler);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_PushEventHandler(wxWindow* self, wxEvtHandler *handler)
{
	self->PushEventHandler(handler);
}

WXNET_EXPORT(wxEvtHandler*)
  wxWindow_PopEventHandler(wxWindow* self, bool deleteHandler)
{
	return self->PopEventHandler(deleteHandler);
}

WXNET_EXPORT(char)
  wxWindow_RemoveEventHandler(wxWindow* self, wxEvtHandler *handler)
{
	return self->RemoveEventHandler(handler)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_SetValidator(wxWindow* self, const wxValidator *validator)
{
	self->SetValidator(*validator);
}

WXNET_EXPORT(wxValidator*)
  wxWindow_GetValidator(wxWindow* self)
{
	return self->GetValidator();
}

WXNET_EXPORT(char)
  wxWindow_Validate(wxWindow* self)
{
	return self->Validate()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxWindow_TransferDataToWindow(wxWindow* self)
{
	return self->TransferDataToWindow();
}

WXNET_EXPORT(char)
  wxWindow_TransferDataFromWindow(wxWindow* self)
{
	return self->TransferDataFromWindow();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_InitDialog(wxWindow* self)
{
    if (self)
	self->InitDialog();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_SetAcceleratorTable(wxWindow* self, const wxAcceleratorTable* accel)
{
    if (self && accel)
	self->SetAcceleratorTable(*accel);
}

WXNET_EXPORT(wxAcceleratorTable*)
  wxWindow_GetAcceleratorTable(wxWindow* self)
{
  if (self)
	return self->GetAcceleratorTable();
  else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_ConvertPixelsToDialogPoint(wxWindow* self, const wxPoint* pt, wxPoint *point)
{
    if (point && self && pt)
	*point = self->ConvertPixelsToDialog(*pt);
}

WXNET_EXPORT(void)
  wxWindow_ConvertDialogToPixelsPoint(wxWindow* self, const wxPoint* pt, wxPoint* point)
{
    if (point && self && pt)
	*point = self->ConvertDialogToPixels(*pt);
}

WXNET_EXPORT(void)
  wxWindow_ConvertPixelsToDialogSize(wxWindow* self, const wxSize* sz, wxSize* size)
{
    if (size && self && sz)
	*size = self->ConvertPixelsToDialog(*sz);
}

WXNET_EXPORT(void)
  wxWindow_ConvertDialogToPixelsSize(wxWindow* self, const wxSize* sz, wxSize* size)
{
    if (self && size && sz)
	*size = self->ConvertDialogToPixels(*sz);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_WarpPointer(wxWindow* self, int x, int y)
{
    if (self)
	self->WarpPointer(x, y);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_CaptureMouse(wxWindow* self)
{
	self->CaptureMouse();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_ReleaseMouse(wxWindow* self)
{
	self->ReleaseMouse();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxWindow*)
  wxWindow_GetCapture()
{
	return wxWindow::GetCapture();
}

WXNET_EXPORT(char)
  wxWindow_HasCapture(wxWindow* self)
{
	return self->HasCapture();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_Refresh(wxWindow* self, bool eraseBackground, const wxRect *rect)
{
	self->Refresh(eraseBackground, rect);
}

WXNET_EXPORT(void)
  wxWindow_RefreshRect(wxWindow* self, const wxRect* rect)
{
	self->RefreshRect(*rect);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_Update(wxWindow* self)
{
	self->Update();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_ClearBackground(wxWindow* self)
{
	self->ClearBackground();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_Freeze(wxWindow* self)
{
	self->Freeze();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_Thaw(wxWindow* self)
{
	self->Thaw();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_PrepareDC(wxWindow* self, wxDC *dc)
{
	self->PrepareDC(*dc);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxWindow_IsExposed(wxWindow* self, int x, int y, int w, int h)
{
	return self->IsExposed(x, y, w, h);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxColour*)
  wxWindow_GetBackgroundColour(wxWindow* self)
{
	return new wxColour(self->GetBackgroundColour());
}

WXNET_EXPORT(wxColour*)
  wxWindow_GetForegroundColour(wxWindow* self)
{
	return new wxColour(self->GetForegroundColour());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_SetCaret(wxWindow* self, wxCaret *caret)
{
	self->SetCaret(caret);
}

WXNET_EXPORT(wxCaret*)
  wxWindow_GetCaret(wxWindow* self)
{
	return self->GetCaret();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxWindow_GetCharHeight(wxWindow* self)
{
	return self->GetCharHeight();
}

WXNET_EXPORT(int)
  wxWindow_GetCharWidth(wxWindow* self)
{
	return self->GetCharWidth();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_GetTextExtent(wxWindow* self, const wxString* string, int *x, int *y, int *descent, int *externalLeading, const wxFont *theFont)
{
   if (string)
	   self->GetTextExtent(*string, x, y, descent, externalLeading, theFont);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_ClientToScreen(wxWindow* self, const wxPoint* pt, wxPoint *point)
{
	*point = self->ClientToScreen(*pt);
}

WXNET_EXPORT(void)
  wxWindow_ScreenToClient(wxWindow* self, const wxPoint* pt, wxPoint* point)
{
	*point = self->ScreenToClient(*pt);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_HitTest(wxWindow* self, const wxPoint* pt, wxHitTest* hittest)
{
	*hittest = self->HitTest(*pt);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxBorder)
  wxWindow_GetBorder(wxWindow* self)
{
	return self->GetBorder();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxBorder)
  wxWindow_GetBorderByFlags(wxWindow* self, int flags)
{
	return self->GetBorder(flags);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_UpdateWindowUI(wxWindow* self)
{
	self->UpdateWindowUI();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxWindow_PopupMenu(wxWindow* self, wxMenu *menu, const wxPoint* pos)
{
	return self->PopupMenu(menu, *pos);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxWindow_HasScrollbar(wxWindow* self, int orient)
{
	return self->HasScrollbar(orient);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_SetScrollbar(wxWindow* self, int orient, int pos, int thumbvisible, int range, bool refresh)
{
	self->SetScrollbar(orient, pos, thumbvisible, range, refresh);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_SetScrollPos(wxWindow* self, int orient, int pos, bool refresh)
{
	self->SetScrollPos(orient, pos, refresh);
}

WXNET_EXPORT(int)
  wxWindow_GetScrollPos(wxWindow* self, int orient)
{
	return self->GetScrollPos(orient);
}

WXNET_EXPORT(int)
  wxWindow_GetScrollThumb(wxWindow* self, int orient)
{
	return self->GetScrollThumb(orient);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxWindow_GetScrollRange(wxWindow* self, int orient)
{
	return self->GetScrollRange(orient);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_ScrollWindow(wxWindow* self, int dx, int dy, const wxRect* rect)
{
	self->ScrollWindow(dx, dy, rect);
}

WXNET_EXPORT(char)
  wxWindow_ScrollLines(wxWindow* self, int lines)
{
	return self->ScrollLines(lines);
}

WXNET_EXPORT(char)
  wxWindow_ScrollPages(wxWindow* self, int pages)
{
	return self->ScrollPages(pages);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxWindow_LineUp(wxWindow* self)
{
	return self->LineUp();
}

WXNET_EXPORT(char)
  wxWindow_LineDown(wxWindow* self)
{
	return self->LineDown();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxWindow_PageUp(wxWindow* self)
{
	return self->PageUp();
}

WXNET_EXPORT(char)
  wxWindow_PageDown(wxWindow* self)
{
	return self->PageDown();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_SetHelpText(wxWindow* self, const wxString* text)
{
   if (self && text)
	   self->SetHelpText(*text);
}

WXNET_EXPORT(void)
  wxWindow_SetHelpTextForId(wxWindow* self, const wxString* text)
{
   if (self && text)
	   self->SetHelpTextForId(*text);
}

WXNET_EXPORT(wxString*)
  wxWindow_GetHelpText(wxWindow* self)
{
	return new wxString(self->GetHelpText());
}

//-----------------------------------------------------------------------------

// TODO Not available in OS X
#if 0
WXNET_EXPORT(wxString*)
  wxWindow_GetToolTipText(wxWindow* self)
{
	return new wxString(self->GetToolTipText());
}
#endif

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxWindow*)
  wxWindow_GetAncestorWithCustomPalette(wxWindow* self)
{
	return self->GetAncestorWithCustomPalette();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_SetDropTarget(wxWindow* self, wxDropTarget *dropTarget)
{
	self->SetDropTarget(dropTarget);
}

WXNET_EXPORT(wxDropTarget*)
  wxWindow_GetDropTarget(wxWindow* self)
{
	return self->GetDropTarget();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_SetConstraints(wxWindow* self, wxLayoutConstraints *constraints)
{
	self->SetConstraints(constraints);
}

WXNET_EXPORT(wxLayoutConstraints*)
  wxWindow_GetConstraints(wxWindow* self)
{
	return self->GetConstraints();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxWindow_GetAutoLayout(wxWindow* self)
{
	return self->GetAutoLayout();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_SetSizerAndFit(wxWindow* self, wxSizer *sizer, bool deleteOld)
{
	self->SetSizerAndFit(sizer, deleteOld);
}

WXNET_EXPORT(wxSizer*)
  wxWindow_GetSizer(wxWindow* self)
{
	return self->GetSizer();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_SetContainingSizer(wxWindow* self, wxSizer* sizer)
{
	self->SetContainingSizer(sizer);
}

WXNET_EXPORT(wxSizer*)
  wxWindow_GetContainingSizer(wxWindow* self)
{
	return self->GetContainingSizer();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxPalette*)
  wxWindow_GetPalette(wxWindow* self)
{
	return new wxPalette(self->GetPalette());
}

WXNET_EXPORT(void)
  wxWindow_SetPalette(wxWindow* self, const wxPalette* pal)
{
	self->SetPalette(*pal);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxWindow_HasCustomPalette(wxWindow* self)
{
	return self->HasCustomPalette();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxRegion*)
  wxWindow_GetUpdateRegion(wxWindow* self)
{
    return new wxRegion(self->GetUpdateRegion());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_SetWindowVariant(wxWindow* self, wxWindowVariant variant)
{
	self->SetWindowVariant(variant);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxWindowVariant)
  wxWindow_GetWindowVariant(wxWindow* self)
{
	return self->GetWindowVariant();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxWindow_IsBeingDeleted(wxWindow* self)
{
	return self->IsBeingDeleted()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_InvalidateBestSize(wxWindow* self)
{
	self->InvalidateBestSize();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_CacheBestSize(wxWindow* self, wxSize* size)
{
	self->CacheBestSize(*size);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_GetEffectiveMinSize(wxWindow* self, wxSize* size)
{
	*size = self->GetEffectiveMinSize();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_SetInitialSize(wxWindow* self, wxSize* size)
{
   self->SetInitialSize(*size);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxWindow*)
  wxWindow_GetChildren(wxWindow* self, int num)
{
	if (num >= (int)self->GetChildren().GetCount())
		return NULL;

	wxWindowListNode* node = self->GetChildren().Item(num);
	return node->GetData();
}

WXNET_EXPORT(int)
  wxWindow_GetChildrenCount(wxWindow* self)
{
	return self->GetChildren().GetCount();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxVisualAttributes*)
  wxWindow_GetDefaultAttributes(wxWindow* self)
{
	return new wxVisualAttributes(self->GetDefaultAttributes());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxVisualAttributes*)
  wxWindow_GetClassDefaultAttributes(wxWindowVariant variant)
{
	return new wxVisualAttributes(wxWindow::GetClassDefaultAttributes(variant));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_SetBackgroundStyle(wxWindow* self, wxBackgroundStyle style)
{
	self->SetBackgroundStyle(style);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxBackgroundStyle)
  wxWindow_GetBackgroundStyle(wxWindow* self)
{
	return self->GetBackgroundStyle();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxWindow_InheritAttributes(wxWindow* self)
{
	self->InheritAttributes();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxWindow_ShouldInheritColours(wxWindow* self)
{
	return self->ShouldInheritColours();
}

//-----------------------------------------------------------------------------
// wxVisualAttributes

struct _VisualAttributes : public wxVisualAttributes
{
public:
	_VisualAttributes()
		: wxVisualAttributes() {}

	DECLARE_DISPOSABLE(_VisualAttributes)
};

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxVisualAttributes*)
  wxVisualAttributes_ctor()
{
	return new _VisualAttributes();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxVisualAttributes_dtor(wxVisualAttributes* self)
{
	if (self != NULL)
		delete self;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxVisualAttributes_RegisterDisposable(_VisualAttributes* self, Virtual_Dispose onDispose)
{
	self->RegisterDispose(onDispose);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxVisualAttributes_SetFont(wxVisualAttributes* self, wxFont* font)
{
	self->font = *font;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxFont*)
  wxVisualAttributes_GetFont(wxVisualAttributes* self)
{
	return new wxFont(self->font);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxVisualAttributes_SetColourFg(wxVisualAttributes* self, wxColour* colour)
{
	self->colFg = *colour;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxColour*)
  wxVisualAttributes_GetColourFg(wxVisualAttributes* self)
{
	return new wxColour(self->colFg);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxVisualAttributes_SetColourBg(wxVisualAttributes* self, wxColour* colour)
{
	self->colBg = *colour;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxColour*)
  wxVisualAttributes_GetColourBg(wxVisualAttributes* self)
{
	return new wxColour(self->colBg);
}




