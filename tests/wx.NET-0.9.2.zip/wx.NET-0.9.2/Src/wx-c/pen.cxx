//-----------------------------------------------------------------------------
// wx.NET - pen.cxx
//
// The wxPen proxy interface.
//
// Written by Jason Perkins (jason@379.com)
// (C) 2003 by 379, Inc.
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: pen.cxx,v 1.10 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#ifndef WXNET_GLOBAL_H
#include "wxnet_globals.h"
#endif

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxPen*)
  wxPen_ctorByName(const wxString* name, int width, int style)
{
   if (name)
	   return new wxPen(*name, width, style);
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxPen*)
  wxPen_ctor(const wxColour* col, int width, int style)
{
	return new wxPen(*col, width, style);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxPen*)
  wxPen_clone(const wxPen* src)
{
    if (src)
	    return new wxPen(*src);
    else
        return new wxPen();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPen_SetWidth(wxPen *self, int width) 
{
    self->SetWidth(width);
}

WXNET_EXPORT(int)
  wxPen_GetWidth(wxPen *self)
{
	return self->GetWidth();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxColour*)
  wxPen_GetColour(wxPen* self)
{
    return new wxColour(self->GetColour());
}

WXNET_EXPORT(void)
  wxPen_SetColour(wxPen* self, wxColour* col)
{
    self->SetColour(*col);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxPen_GetCap(wxPen* self)
{
	return self->GetCap();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxPen_GetJoin(wxPen* self)
{
	return self->GetJoin();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxPen_GetStyle(wxPen* self)
{
	return self->GetStyle();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxPen_Ok(wxPen* self)
{
	return self->Ok()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPen_SetCap(wxPen* self, int capStyle)
{
	self->SetCap(capStyle);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPen_SetJoin(wxPen* self, int join_style)
{
	self->SetJoin(join_style);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPen_SetStyle(wxPen* self, int style)
{
	self->SetStyle(style);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPen_Set(wxPen* self, const wxPen* src)
{
    if (self && src) (*self)=(*src);
}

