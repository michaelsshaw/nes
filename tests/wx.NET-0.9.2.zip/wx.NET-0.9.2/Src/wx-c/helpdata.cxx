//-----------------------------------------------------------------------------
// wx.NET - filesys.cxx
// 
// The wx streams and file system proxy interface.
//
// Written by Harald Meyer auf'm Hofe
// (C) 2006 by Harald Meyer auf'm Hofe (harald_meyer@sf.net)
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: helpdata.cxx,v 1.7 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/html/helpdata.h>
#include <wx/hashmap.h>
#include "local_events.h"

class _wxHtmlHelpDataItem : public wxHtmlHelpDataItem
{
public:
   Virtual_Dispose virtual_OnDispose;
    _wxHtmlHelpDataItem() : wxHtmlHelpDataItem(),
                      virtual_OnDispose(NULL)
    {
    }

    _wxHtmlHelpDataItem(const wxHtmlHelpDataItem& src)
       : wxHtmlHelpDataItem(src)
       , virtual_OnDispose(NULL)
    {
    }

    virtual ~_wxHtmlHelpDataItem()
    {
       if (this->virtual_OnDispose) virtual_OnDispose();
    }

    void SetVirtualOnDispose(Virtual_Dispose virtual_OnDispose)
    {
       this->virtual_OnDispose=virtual_OnDispose;
    }

    _wxHtmlHelpDataItem* GetParent() const { return (_wxHtmlHelpDataItem*) this->parent; }

    wxHtmlBookRecord* GetBook() const { return this->book; }
};

class _wxHtmlHelpData
{
public:
   wxHtmlHelpData m_data;
   Virtual_Dispose virtual_OnDispose;
    _wxHtmlHelpData() : m_data(),
                        virtual_OnDispose(NULL)
    {
    }

    virtual ~_wxHtmlHelpData()
    {
       if (this->virtual_OnDispose) virtual_OnDispose();
    }

    void SetVirtualOnDispose(Virtual_Dispose virtual_OnDispose)
    {
       this->virtual_OnDispose=virtual_OnDispose;
    }

    int BooksCount() const
    {
       return this->m_data.GetBookRecArray().Count();
    }

    int ContentsCount() const
    {
       return this->m_data.GetContentsArray().Count();
    }
};


WXNET_EXPORT(wxString*)
  wxHtmlBookrecord_GetBookFile(const wxHtmlBookRecord* self){
   if (self)
   {
      WXNET_LOG_DEREF(self) 
      return WXNET_NEW( wxString, (self->GetBookFile()));
   }
   else
      return NULL;
}


WXNET_EXPORT(wxString*)
  wxHtmlBookrecord_GetTitle(const wxHtmlBookRecord* self){
   if (self)
   {
      WXNET_LOG_DEREF(self) 
      return WXNET_NEW( wxString, (self->GetTitle()));
   }
   else
      return NULL;
}


WXNET_EXPORT(wxString*)
  wxHtmlBookrecord_GetStart(const wxHtmlBookRecord* self){
   if (self)
   {
      WXNET_LOG_DEREF(self) 
      return WXNET_NEW( wxString, (self->GetStart()));
   }
   else
      return NULL;
}


WXNET_EXPORT(wxString*)
  wxHtmlBookrecord_GetBasePath(const wxHtmlBookRecord* self){
   if (self)
   {
      WXNET_LOG_DEREF(self) 
      return WXNET_NEW( wxString, ( self->GetBasePath() ));
   }
   else
      return 0;
}


WXNET_EXPORT(wxString*)
  wxHtmlBookrecord_GetFullPath(const wxHtmlBookRecord* self, const wxString* page){
   if (self && page)
   {
      WXNET_LOG_DEREF(self) 
      WXNET_LOG_DEREFSTR(page) 
      return WXNET_NEW( wxString, ( self->GetFullPath(*page) ));
   }
   else
      return 0;
}


WXNET_EXPORT(int)
  wxHtmlBookrecord_GetContentsStart(const wxHtmlBookRecord* self){
   if (self)
   {
      WXNET_LOG_DEREF(self) 
      return self->GetContentsStart();
   }
   else
      return -1;
}


WXNET_EXPORT(int)
  wxHtmlBookrecord_GetContentsEnd(const wxHtmlBookRecord* self){
   if (self)
   {
      WXNET_LOG_DEREF(self) 
      return self->GetContentsEnd();
   }
   else
      return -1;
}



WXNET_EXPORT(int)
  wxHtmlBookRecords_GetCount(const wxHtmlBookRecArray* self){
   if (self)
   {
      WXNET_LOG_DEREF(self) 
      return self->Count();
   }
   return 0;
}


WXNET_EXPORT(const wxHtmlBookRecord*)
  wxHtmlBookRecords_GetItem(const wxHtmlBookRecArray* self, int index){
   if (self && index >= 0)
   {
      WXNET_LOG_DEREF(self) 
      return &(*self)[index];
   }
   else
      return NULL;
}







WXNET_EXPORT(_wxHtmlHelpDataItem*)
  wxHtmlHelpDataItem_ctor(void){
   return WXNET_NEW( _wxHtmlHelpDataItem, ());
}


WXNET_EXPORT(void)
  wxHtmlHelpDataItem_SetVirtualDispose(_wxHtmlHelpDataItem* self, Virtual_Dispose virtualDispose)
{
   if (self)
   {
      WXNET_LOG_DEREF(self) 
      self->SetVirtualOnDispose(virtualDispose);
   }
}


WXNET_EXPORT(int)
  wxHtmlHelpDataItem_GetLevel(const _wxHtmlHelpDataItem* self){
   if (self)
   {
      WXNET_LOG_DEREF(self) 
      return self->level;
   }
   else
      return -1;
}


WXNET_EXPORT(_wxHtmlHelpDataItem*)
  wxHtmlHelpDataItem_GetParent(const _wxHtmlHelpDataItem* self){
   if (self)
   {
      WXNET_LOG_DEREF(self) 
      return self->GetParent();
   }
   return NULL;
}


WXNET_EXPORT(int)
  wxHtmlHelpDataItem_GetId(const _wxHtmlHelpDataItem* self){
   if (self)
   {
      WXNET_LOG_DEREF(self) 
      return self->id;
   }
   else
      return -1;
}


WXNET_EXPORT(wxString*)
  wxHtmlHelpDataItem_GetName(const _wxHtmlHelpDataItem* self){
   if (self)
   {
      WXNET_LOG_DEREF(self) 
      return WXNET_NEW( wxString, (self->name));
   }
   return NULL;
}


WXNET_EXPORT(wxString*)
  wxHtmlHelpDataItem_GetPage(const _wxHtmlHelpDataItem* self){
   if (self)
   {
      WXNET_LOG_DEREF(self) 
      return WXNET_NEW( wxString, (self->page));
   }
   return NULL;
}


WXNET_EXPORT(wxHtmlBookRecord*)
  wxHtmlHelpDataItem_GetBook(const _wxHtmlHelpDataItem* self){
   if (self)
   {
      WXNET_LOG_DEREF(self) 
      return self->GetBook();
   }
   else
      return NULL;
}


WXNET_EXPORT(wxString*)
  wxHtmlHelpDataItem_GetFullPath(const _wxHtmlHelpDataItem* self){
   if (self)
   {
      WXNET_LOG_DEREF(self) 
      return WXNET_NEW( wxString, (self->GetFullPath()));
   }
   else
      return NULL;
}



WXNET_EXPORT(wxString*)
  wxHtmlHelpDataItem_GetIndentedName(const _wxHtmlHelpDataItem* self){
   if (self)
   {
      WXNET_LOG_DEREF(self) 
      return WXNET_NEW( wxString, (self->GetIndentedName()));
   }
   else
      return NULL;
}

class _wxHtmlHelpDataItems;

WX_DECLARE_HASH_MAP( wxHtmlHelpDataItem*, _wxHtmlHelpDataItem*, wxPointerHash, wxPointerEqual, HashHtmlBookRecords); 

WX_DECLARE_OBJARRAY(_wxHtmlHelpDataItem, _wxHtmlHelpDataItemArray);

#include "wx/arrimpl.cpp"
WX_DEFINE_OBJARRAY(_wxHtmlHelpDataItemArray)

class _wxHtmlHelpDataItems
{
   _wxHtmlHelpDataItemArray _data;
public:
   Virtual_Dispose virtual_OnDispose;
    _wxHtmlHelpDataItems(const wxHtmlHelpDataItems& data)
                      : virtual_OnDispose(NULL)
    {
       if (data.Count() > 0)
       {
          HashHtmlBookRecords conversions;
          this->_data.Alloc(data.Count());

          // in a first step, create new instances
          for(size_t i=0; i < data.Count(); ++i)
          {
             wxHtmlHelpDataItem& item=data.Item(i);
             _wxHtmlHelpDataItem* newInstance=WXNET_NEW( _wxHtmlHelpDataItem, (item));
             this->_data.Add(newInstance);
             conversions.insert(HashHtmlBookRecords::value_type(&item, newInstance));
          }
          // in a second step, replace allpernts with their new counterpart
          for(size_t i=0; i < this->_data.Count(); ++i)
          {
             _wxHtmlHelpDataItem* newInstance=this->GetItem(i);
             if (newInstance->parent)
             {
                HashHtmlBookRecords::iterator pos=conversions.find(newInstance->parent);
                if (pos==conversions.end())
                   newInstance->parent=NULL;
                else
                   newInstance->parent=(*pos).second;
             }
          }
       }
    }

    virtual ~_wxHtmlHelpDataItems()
    {
       if (this->virtual_OnDispose) (*this->virtual_OnDispose)();
    }

    void SetVirtualOnDispose(Virtual_Dispose virtual_OnDispose)
    {
       this->virtual_OnDispose=virtual_OnDispose;
    }

    size_t Count() const { return this->_data.Count(); }
    _wxHtmlHelpDataItem* GetItem(size_t index) const
    {
       if (index >= this->Count())
          return NULL;
       return (_wxHtmlHelpDataItem*) &(this->_data.Item(index));
    }
};


WXNET_EXPORT(int)
  wxHtmlHelpDataItems_GetCount(const _wxHtmlHelpDataItems* self){
   if (self)
   {
      WXNET_LOG_DEREF(self) 
      return self->Count();
   }
   else
      return 0;
}


WXNET_EXPORT(_wxHtmlHelpDataItem*)
  wxHtmlHelpDataItems_GetItem(const _wxHtmlHelpDataItems* self, int index){
   if (self && index >= 0)
   {
      WXNET_LOG_DEREF(self) 
      _wxHtmlHelpDataItem* result=self->GetItem(index);
      return result;
   }
   else
      return NULL;
}


WXNET_EXPORT(void)
  wxHtmlHelpDataItems_SetVirtualDispose(_wxHtmlHelpDataItems* self,  Virtual_Dispose virtualDispose){
   if (self)
   {
      WXNET_LOG_DEREF(self) 
      self->SetVirtualOnDispose(virtualDispose);
   }
}


class _HtmlSearchStatus:public wxHtmlSearchStatus
{
   DECLARE_DISPOSABLE(_HtmlSearchStatus)
public:
   _HtmlSearchStatus(wxHtmlHelpData* data, const wxString& keyword, bool searchCaseSensitive, bool searchWholeWords, const wxString& book)
      : wxHtmlSearchStatus(data, keyword, searchCaseSensitive, searchWholeWords, book), m_onDispose(NULL)
   {
   }
};


WXNET_EXPORT(wxHtmlSearchStatus*)
  wxHtmlSearchStatus_CTor(_wxHtmlHelpData* data, const wxString* keyword, char searchCaseSensitive, char searchWholeWords, const wxString* book){
   if (data && keyword)
   {
      WXNET_LOG_DEREF(data) 
      WXNET_LOG_DEREFSTR(keyword) 
      wxString bookSelection;
      if (book) bookSelection=*book;
      return WXNET_NEW( wxHtmlSearchStatus, (&data->m_data, *keyword, searchCaseSensitive != 0, searchWholeWords != 0, bookSelection));
   }
   return NULL;
}

/*

WXNET_EXPORT(void)
  wxHtmlSearchStatus_RegisterDispose(_HtmlSearchStatus* self, Virtual_Dispose onDispose){
   if (self)
   {
      WXNET_LOG_DEREF(self) 
      self->RegisterDispose(onDispose);
   }
}
*/


WXNET_EXPORT(char)
  wxHtmlSearchStatus_Search(wxHtmlSearchStatus* self){
   if (self)
   {
      WXNET_LOG_DEREF(self) 
      return self->Search();
   }
   return false;
}


WXNET_EXPORT(char)
  wxHtmlSearchStatus_IsActive(wxHtmlSearchStatus* self){
   if (self)
   {
      WXNET_LOG_DEREF(self) 
      return self->IsActive();
   }
   return false;
}


WXNET_EXPORT(int)
  wxHtmlSearchStatus_GetCurIndex(wxHtmlSearchStatus* self){
   if (self)
   {
      WXNET_LOG_DEREF(self) 
      return self->GetCurIndex();
   }
   return 0;
}


WXNET_EXPORT(int)
  wxHtmlSearchStatus_GetMaxIndex(wxHtmlSearchStatus* self){
   if (self)
   {
      WXNET_LOG_DEREF(self) 
      return self->GetMaxIndex();
   }
   return 0;
}


WXNET_EXPORT(wxString*)
  wxHtmlSearchStatus_GetName(wxHtmlSearchStatus* self){
   if (self)
   {
      return WXNET_NEW( wxString, (self->GetName()));
   }
   return NULL;
}


WXNET_EXPORT(_wxHtmlHelpDataItem*)
  wxHtmlSearchStatus_GetCurItem(wxHtmlSearchStatus* self){
   if (self && self->GetCurItem())
   {
      WXNET_LOG_DEREF(self) 
      WXNET_LOG_DEREF(self->GetCurItem()) 
      return WXNET_NEW( _wxHtmlHelpDataItem, (*self->GetCurItem()));
   }
   return 0;
}



WXNET_EXPORT(_wxHtmlHelpData*)
  wxHtmlHelpData_ctor(void){
   return WXNET_NEW( _wxHtmlHelpData, ());
}


WXNET_EXPORT(void)
  wxHtmlHelpData_SetVirtualDispose(_wxHtmlHelpData* self, Virtual_Dispose virtualDispose){
   if (self)
   {
      WXNET_LOG_DEREF(self) 
      self->SetVirtualOnDispose(virtualDispose);
   }
}


WXNET_EXPORT(void)
  wxHtmlHelpData_SetTempDir(_wxHtmlHelpData* self, const wxString* path){
   if (self && path)
   {
      WXNET_LOG_DEREF(self) 
      WXNET_LOG_DEREFSTR(path) 
      self->m_data.SetTempDir(*path);
   }
}


WXNET_EXPORT(char)
  wxHtmlHelpData_AddBook(_wxHtmlHelpData* self, const wxString* book){
   if (self && book)
   {
      WXNET_LOG_DEREF(self) 
      WXNET_LOG_DEREFSTR(book) 
      return self->m_data.AddBook(*book);
   }
   else
      return false;
}


WXNET_EXPORT(wxString*)
  wxHtmlHelpData_FindPageByName(_wxHtmlHelpData* self, const wxString* page){
   if (self && page)
   {
      WXNET_LOG_DEREF(self) 
      WXNET_LOG_DEREFSTR(page) 
      return WXNET_NEW( wxString, (self->m_data.FindPageByName(*page)));
   }
   else
      return NULL;
}


WXNET_EXPORT(wxString*)
  wxHtmlHelpData_FindPageById(_wxHtmlHelpData* self, int id){
   if (self)
   {
      WXNET_LOG_DEREF(self) 
      return WXNET_NEW( wxString, (self->m_data.FindPageById(id)));
   }
   else
      return NULL;
}

// please note, that this does not return a copy but the value itself.

WXNET_EXPORT(const wxHtmlBookRecArray*)
  wxHtmlHelpData_GetBookRecArray(const _wxHtmlHelpData* self){
   if (self)
   {
      WXNET_LOG_DEREF(self) 
      return &self->m_data.GetBookRecArray();
   }
   else
      return NULL;
}


WXNET_EXPORT(int)
  wxHtmlHelpData_BooksCount(const _wxHtmlHelpData* self){
   if (self)
   {
      WXNET_LOG_DEREF(self) 
      return self->BooksCount();
   }
   else
      return 0;
}


WXNET_EXPORT(_wxHtmlHelpDataItems*)
  wxHtmlHelpData_GetContentsArray(const _wxHtmlHelpData* self){
   if (self)
   {
      WXNET_LOG_DEREF(self) 
      return WXNET_NEW( _wxHtmlHelpDataItems, (self->m_data.GetContentsArray()));
   }
   else
      return NULL;
}


WXNET_EXPORT(int)
  wxHtmlHelpData_ContentsCount(const _wxHtmlHelpData* self){
   if (self)
   {
      WXNET_LOG_DEREF(self) 
      return self->ContentsCount();
   }
   else
      return 0;
}


WXNET_EXPORT(_wxHtmlHelpDataItems*)
  wxHtmlHelpData_GetIndexArray(const _wxHtmlHelpData* self){
   if (self)
   {
      WXNET_LOG_DEREF(self) 
      return WXNET_NEW( _wxHtmlHelpDataItems, (self->m_data.GetIndexArray()));
   }
   else
      return NULL;
}
