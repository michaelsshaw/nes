//-----------------------------------------------------------------------------
// wx.NET - idleevent.cxx
// 
// The wxIdleEvent proxy interface.
//
// Written by Alexander Olk (xenomorph2@onlinehome.de)
// (C) 2004 by Alexander Olk
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: idleevent.cxx,v 1.3 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#ifndef WXNET_GLOBAL_H
#include "wxnet_globals.h"
#endif

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxIdleEvent*)
  wxIdleEvent_ctor()
{
    return new wxIdleEvent();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxIdleEvent_RequestMore(wxIdleEvent* self, bool needMore)
{
	self->RequestMore(needMore);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxIdleEvent_MoreRequested(wxIdleEvent* self)
{
	return self->MoreRequested()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxIdleEvent_SetMode(wxIdleMode mode)
{
	wxIdleEvent::SetMode(mode);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxIdleMode)
  wxIdleEvent_GetMode()
{
	return wxIdleEvent::GetMode();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxIdleEvent_CanSend(wxWindow* win)
{
	return wxIdleEvent::CanSend(win)?1:0;
}


