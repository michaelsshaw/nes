//-----------------------------------------------------------------------------
// wx.NET - fontmisc.cxx
//
// Misc font proxy interfaces
//
// Written by Alexander Olk (xenomorph2@onlinehome.de)
// (C) 2003 by Alexander Olk
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// fontmisc.cxx,v 1.4 2004/11/25 20:50:10 olkalex Exp
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/fontmap.h>
#include <wx/encconv.h>
#include <wx/fontenum.h>

#include "local_events.h"

WXNET_EXPORT(wxFontMapper*)
  wxFontMapper_ctor()
{
	return new wxFontMapper();
}

WXNET_EXPORT(void)
  wxFontMapper_dtor(wxFontMapper* self)
{
	WXNET_DEL( self );
}

WXNET_EXPORT(wxFontMapper*)
  wxFontMapper_Get()
{
	return wxFontMapper::Get();
}

WXNET_EXPORT(wxFontMapper*)
  wxFontMapper_Set(wxFontMapper* mapper)
{
	return wxFontMapper::Set(mapper);
}

WXNET_EXPORT(size_t)
  wxFontMapper_GetSupportedEncodingsCount()
{
	return wxFontMapper::GetSupportedEncodingsCount();
}

WXNET_EXPORT(wxFontEncoding)
  wxFontMapper_GetEncoding(size_t n)
{
	return wxFontMapper::GetEncoding(n);
}

WXNET_EXPORT(wxString*)
  wxFontMapper_GetEncodingName(wxFontEncoding encoding)
{
	return new wxString(wxFontMapper::GetEncodingName(encoding));
}

WXNET_EXPORT(wxFontEncoding)
  wxFontMapper_GetEncodingFromName(const wxString* nameArg)
{
   wxString name;
   if (nameArg)
      name=*nameArg;
   return wxFontMapper::GetEncodingFromName(*name);
}

WXNET_EXPORT(wxFontEncoding)
  wxFontMapper_CharsetToEncoding(wxFontMapper* self, const wxString* charset, bool interactive)
{
   if (charset)
	   return self->CharsetToEncoding(*charset, interactive);
   else
      return wxFONTENCODING_DEFAULT;
}

WXNET_EXPORT(char)
  wxFontMapper_IsEncodingAvailable(wxFontMapper* self, wxFontEncoding encoding, const wxString* facename)
{
   if (self && facename)
	   return self->IsEncodingAvailable(encoding, *facename);
   return false;
}

WXNET_EXPORT(char)
  wxFontMapper_GetAltForEncoding(wxFontMapper* self, wxFontEncoding encoding, wxFontEncoding *alt_encoding, const wxString* facename, bool interactive)
{
   if (self && facename)
	   return self->GetAltForEncoding(encoding, alt_encoding, *facename, interactive);
   else
      return false;
}

WXNET_EXPORT(wxString*)
  wxFontMapper_GetEncodingDescription(wxFontEncoding encoding)
{
	return new wxString(wxFontMapper::GetEncodingDescription(encoding));
}

WXNET_EXPORT(void)
  wxFontMapper_SetDialogParent(wxFontMapper* self, wxWindow* parent)
{
	self->SetDialogParent(parent);
}

WXNET_EXPORT(void)
  wxFontMapper_SetDialogTitle(wxFontMapper* self, const wxString* title)
{
   if (self && title)
	   self->SetDialogTitle(*title);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxEncodingConverter*)
  wxEncodingConverter_ctor()
{
	return new wxEncodingConverter();
}

WXNET_EXPORT(char)
  wxEncodingConverter_Init(wxEncodingConverter* self, wxFontEncoding input_enc, wxFontEncoding output_enc, int method)
{
	return self->Init(input_enc, output_enc, method);
}

WXNET_EXPORT(wxString*)
  wxEncodingConverter_Convert(wxEncodingConverter* self, const wxString* input)
{
   if (input && self)
	   return new wxString(self->Convert(*input));
   else
      return NULL;
}

//-----------------------------------------------------------------------------

typedef bool (CALLBACK* Virtual_EnumerateFacenames) (wxFontEncoding, bool);
typedef bool (CALLBACK* Virtual_EnumerateEncodings)(wxString*);
typedef bool (CALLBACK* Virtual_OnFacename) (wxString*);
typedef bool (CALLBACK* Virtual_OnFontEncoding) (wxString*, wxString*);

class _FontEnumerator : public wxFontEnumerator
{
   Virtual_Dispose m_onDispose;
public:
   _FontEnumerator()
		: wxFontEnumerator(), m_onDispose(NULL) {}

   virtual ~_FontEnumerator()
   {
      if (m_onDispose) m_onDispose();
   }
		
	bool EnumerateFacenames(wxFontEncoding encoding, bool fixedWidthOnly)
		{ return m_EnumerateFacenames(encoding, fixedWidthOnly); }
		
	bool EnumerateEncodings(const wxString& facename)
		{ return m_EnumerateEncodings(new wxString(facename)); }
		
	bool OnFacename(const wxString& facename)
		{ return m_OnFacename(new wxString(facename)); }
		
	bool OnFontEncoding(const wxString& facename, const wxString& encoding)
		{ return m_OnFontEncoding(new wxString(facename), new wxString(encoding)); }

	void RegisterVirtual(Virtual_Dispose onDispose,
      Virtual_EnumerateFacenames enumerateFacenames, 
		Virtual_EnumerateEncodings enumerateEncodings,
		Virtual_OnFacename onFacename,
		Virtual_OnFontEncoding onFontEncoding)
	{
      m_onDispose=onDispose;
		m_EnumerateFacenames = enumerateFacenames;
		m_EnumerateEncodings = enumerateEncodings;
		m_OnFacename = onFacename;
		m_OnFontEncoding = onFontEncoding;
	}

private:
	Virtual_EnumerateFacenames m_EnumerateFacenames;
	Virtual_EnumerateEncodings m_EnumerateEncodings;
	Virtual_OnFacename m_OnFacename;
	Virtual_OnFontEncoding m_OnFontEncoding;
};

WXNET_EXPORT(wxFontEnumerator*)
  wxFontEnumerator_ctor()
{
	return new _FontEnumerator();
}

WXNET_EXPORT(void)
  wxFontEnumerator_dtor(_FontEnumerator* self)
{
	WXNET_DEL( self );
}

WXNET_EXPORT(void)
  wxFontEnumerator_RegisterVirtual(_FontEnumerator *self,
         Virtual_Dispose onDispose,
			Virtual_EnumerateFacenames enumerateFacenames,
			Virtual_EnumerateEncodings enumerateEncodings,
			Virtual_OnFacename onFacename,
			Virtual_OnFontEncoding onFontEncoding)
{
   if (self)
	   self->RegisterVirtual(onDispose, enumerateFacenames, enumerateEncodings, onFacename, onFontEncoding);
}

WXNET_EXPORT(wxArrayString*)
  wxFontEnumerator_GetFacenames(_FontEnumerator* self)
{
	wxArrayString* was = new wxArrayString();
#if wxCHECK_VERSION(2, 8, 0)
   *was=self->GetFacenames();
#else
   if (self->GetFacenames())
	   (*was) = (*self->GetFacenames());
#endif
	return was;
}

WXNET_EXPORT(wxArrayString*)
  wxFontEnumerator_GetEncodings(_FontEnumerator* self)
{
	wxArrayString* was = new wxArrayString();
#if wxCHECK_VERSION(2, 8, 0)
   *was=self->GetEncodings();
#else
   if (self->GetEncodings())
   {
	   *was = (*self->GetEncodings());
   }
#endif
	return was;
}

WXNET_EXPORT(bool)
  wxFontEnumerator_OnFacename(_FontEnumerator* self, const wxString* facename )
{
   if (facename && self)
	   return self->wxFontEnumerator::OnFacename(*facename);
   return false;
}

WXNET_EXPORT(bool)
  wxFontEnumerator_OnFontEncoding(_FontEnumerator* self, const wxString* facename, const wxString* encoding)
{
   if (facename && self && encoding)
	   return self->wxFontEnumerator::OnFontEncoding(*facename, *encoding);
   return false;
}

WXNET_EXPORT(bool)
  wxFontEnumerator_EnumerateFacenames(_FontEnumerator* self, wxFontEncoding encoding, bool fixedWidthOnly)
{
	return self->wxFontEnumerator::EnumerateFacenames(encoding, fixedWidthOnly);
}

WXNET_EXPORT(bool)
  wxFontEnumerator_EnumerateEncodings(_FontEnumerator* self, const wxString* facenameArg)
{
   wxString facename;
   if (facenameArg)
      facename=*facenameArg;
   if (self)
   	return self->wxFontEnumerator::EnumerateEncodings(facename);
   return false;
}

