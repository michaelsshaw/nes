//-----------------------------------------------------------------------------
// wx.NET - gauge.cxx
//
// The wxGauge proxy interface
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 by Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: gauge.cxx,v 1.10 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/gauge.h>
#include "local_events.h"

//-----------------------------------------------------------------------------

class _Gauge : public wxGauge
{
public:
    DECLARE_OBJECTDELETED(_Gauge)
};

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxGauge*)
  wxGauge_ctor()
{
	return new _Gauge();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGauge_dtor(wxGauge* self)
{
	WXNET_DEL( self );
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxGauge_Create(wxGauge* self, wxWindow *parent, wxWindowID id, int range, int posX, int posY, int width, int height, int style, const wxValidator* validator, const wxString* nameArg)
{
	if (validator == NULL)
		validator = &wxDefaultValidator;

   wxString name;
	if (nameArg == NULL)
		name = wxT("gauge");
   else
      name=*nameArg;

	return self->Create(parent, id, range, wxPoint(posX, posY), wxSize(width, height), style, *validator, name)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGauge_SetRange(wxGauge* self, int range)
{
	self->SetRange(range);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxGauge_GetRange(wxGauge* self)
{
	return self->GetRange();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGauge_SetValue(wxGauge* self, int pos)
{
	self->SetValue(pos);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxGauge_GetValue(wxGauge* self)
{
	return self->GetValue();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGauge_SetShadowWidth(wxGauge* self, int w)
{
	self->SetShadowWidth(w);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxGauge_GetShadowWidth(wxGauge* self)
{
	return self->GetShadowWidth();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGauge_SetBezelFace(wxGauge* self, int w)
{
	self->SetBezelFace(w);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxGauge_GetBezelFace(wxGauge* self)
{
	return self->GetBezelFace();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxGauge_AcceptsFocus(wxGauge* self)
{
	return self->AcceptsFocus()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxGauge_IsVertical(wxGauge* self)
{
	return self->IsVertical()?1:0;
}
