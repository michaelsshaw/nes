//-----------------------------------------------------------------------------
// wx.NET - panel.cxx
//
// The wxPanel proxy interface.
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: panel.cxx,v 1.16 2009/01/06 18:24:22 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/panel.h>
#include "local_events.h"

//-----------------------------------------------------------------------------

class _Panel : public wxPanel, public ValidatorStub
{
public:
	_Panel()
		: wxPanel() {}
		
	_Panel(wxWindow *parent,
            wxWindowID winid,
            const wxPoint& pos,
            const wxSize& size,
            long style,
            const wxString& name)
	    	: wxPanel(parent, winid, pos, size, style, name),
           _cbSetFocus(0),
           _cbSetFocusFromKbd(0)
    {}

    DECLARE_OBJECTDELETED(_Panel)

    DECLARE_SETFOCUS_OVERRIDING(wxPanel)
    
#include "panel.inc"
};

//-----------------------------------------------------------------------------
// C stubs for class methods

WXNET_EXPORT(wxPanel*)
  wxPanel_ctor()
{
	return new _Panel();
}

WXNET_EXPORT(wxPanel*)
  wxPanel_ctor2(wxWindow *parent, wxWindowID id, int posX, int posY,
                       int width, int height, unsigned int style, const wxString* nameArg)
{
   wxString name;
	if (nameArg == NULL)
		name = wxT("panel");
   else
      name=*nameArg;

	return new _Panel(parent, id, wxPoint(posX, posY), wxSize(width, height), style, name);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxPanel_Create(wxPanel* self, wxWindow *parent, wxWindowID id, int posX, int posY,
                    int width, int height, unsigned int style, const wxString* nameArg)
{
   wxString name;
	if (nameArg == NULL)
		name = wxT("panel");
   else
      name=*nameArg;

	return self->Create(parent, id, wxPoint(posX, posY), wxSize(width, height), style, name);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPanel_InitDialog(wxPanel* self)
{
	self->InitDialog();
}

//-----------------------------------------------------------------------------

IMPLEMENT_SETFOCUS_OVERRIDING(_Panel, wxPanel)

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTopLevelWindow_SetDefaultItem(wxTopLevelWindow* self, wxWindow* btn)
{
   if (self)
   	self->SetDefaultItem(btn);
}

WXNET_EXPORT(wxWindow*)
  wxTopLevelWindow_GetDefaultItem(wxTopLevelWindow* self)
{
   if (self)
	   return self->GetDefaultItem();
   else
      return NULL;
}
