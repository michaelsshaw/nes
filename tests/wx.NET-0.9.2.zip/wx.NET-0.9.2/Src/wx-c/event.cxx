//-----------------------------------------------------------------------------
// wx.NET - event.cxx
//
// The wxEvent proxy interface.
//
// Written by Jason Perkins (jason@379.com)
// (C) 2003 by 379, Inc.
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: event.cxx,v 1.30 2009/12/20 14:21:12 harald_meyer Exp $
//-----------------------------------------------------------------------------
//
// WARNING THIS FILE IS REALLY PICKY ABOUT Conditional Compilation directives
//   (#if, #ifdef, #ifndef, #else, #elif, #endif, and defined) Blocks.
//
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/tglbtn.h>
#include <wx/calctrl.h>
#include <wx/fdrepdlg.h>
#include <wx/treectrl.h>
#include <wx/listctrl.h>
#include <wx/notebook.h>
#include <wx/listbook.h>
#include <wx/grid.h>
#include <wx/sashwin.h>
#include <wx/laywin.h>
#include <wx/taskbar.h> 
#ifndef __WXGTK__
#include <wx/tabctrl.h>
#endif
#include <wx/clrpicker.h>
#include <wx/fontpicker.h>
#include <wx/wizard.h>
#include "local_events.h"

//-----------------------------------------------------------------------------
// Event type for virtual destructors

DEFINE_EVENT_TYPE(wxEVT_OBJECTDELETED)    

//-----------------------------------------------------------------------------


WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_BUTTON_CLICKED()        { return wxEVT_COMMAND_BUTTON_CLICKED; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_CHECKBOX_CLICKED()      { return wxEVT_COMMAND_CHECKBOX_CLICKED; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_CHOICE_SELECTED()       { return wxEVT_COMMAND_CHOICE_SELECTED; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_LISTBOX_SELECTED()      { return wxEVT_COMMAND_LISTBOX_SELECTED; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_LISTBOX_DOUBLECLICKED() { return wxEVT_COMMAND_LISTBOX_DOUBLECLICKED; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_CHECKLISTBOX_TOGGLED()  { return wxEVT_COMMAND_CHECKLISTBOX_TOGGLED; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_TEXT_UPDATED()          { return wxEVT_COMMAND_TEXT_UPDATED; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_TEXT_ENTER()            { return wxEVT_COMMAND_TEXT_ENTER; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_TEXT_URL()              { return wxEVT_COMMAND_TEXT_URL; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_TEXT_MAXLEN()           { return wxEVT_COMMAND_TEXT_MAXLEN; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_MENU_SELECTED()         { return wxEVT_COMMAND_MENU_SELECTED; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_SLIDER_UPDATED()        { return wxEVT_COMMAND_SLIDER_UPDATED; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_RADIOBOX_SELECTED()     { return wxEVT_COMMAND_RADIOBOX_SELECTED; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_RADIOBUTTON_SELECTED()  { return wxEVT_COMMAND_RADIOBUTTON_SELECTED; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_SCROLLBAR_UPDATED()     { return wxEVT_COMMAND_SCROLLBAR_UPDATED; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_VLBOX_SELECTED()        { return wxEVT_COMMAND_VLBOX_SELECTED; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_COMBOBOX_SELECTED()     { return wxEVT_COMMAND_COMBOBOX_SELECTED; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_TOOL_RCLICKED()         { return wxEVT_COMMAND_TOOL_RCLICKED; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_TOOL_ENTER()            { return wxEVT_COMMAND_TOOL_ENTER; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_SPINCTRL_UPDATED()      { return wxEVT_COMMAND_SPINCTRL_UPDATED; }
WXNET_EXPORT(int)
  wxEvent_EVT_SOCKET()                        { return wxEVT_SOCKET; }
WXNET_EXPORT(int)
  wxEvent_EVT_TIMER()                         { return wxEVT_TIMER ; }
WXNET_EXPORT(int)
  wxEvent_EVT_LEFT_DOWN()                     { return wxEVT_LEFT_DOWN; }
WXNET_EXPORT(int)
  wxEvent_EVT_LEFT_UP()                       { return wxEVT_LEFT_UP; }
WXNET_EXPORT(int)
  wxEvent_EVT_MIDDLE_DOWN()                   { return wxEVT_MIDDLE_DOWN; }
WXNET_EXPORT(int)
  wxEvent_EVT_MIDDLE_UP()                     { return wxEVT_MIDDLE_UP; }
WXNET_EXPORT(int)
  wxEvent_EVT_RIGHT_DOWN()                    { return wxEVT_RIGHT_DOWN; }
WXNET_EXPORT(int)
  wxEvent_EVT_RIGHT_UP()                      { return wxEVT_RIGHT_UP; }
WXNET_EXPORT(int)
  wxEvent_EVT_MOTION()                        { return wxEVT_MOTION; }
WXNET_EXPORT(int)
  wxEvent_EVT_ENTER_WINDOW()                  { return wxEVT_ENTER_WINDOW; }
WXNET_EXPORT(int)
  wxEvent_EVT_LEAVE_WINDOW()                  { return wxEVT_LEAVE_WINDOW; }
WXNET_EXPORT(int)
  wxEvent_EVT_LEFT_DCLICK()                   { return wxEVT_LEFT_DCLICK; }
WXNET_EXPORT(int)
  wxEvent_EVT_MIDDLE_DCLICK()                 { return wxEVT_MIDDLE_DCLICK; }
WXNET_EXPORT(int)
  wxEvent_EVT_RIGHT_DCLICK()                  { return wxEVT_RIGHT_DCLICK; }
WXNET_EXPORT(int)
  wxEvent_EVT_SET_FOCUS()                     { return wxEVT_SET_FOCUS; }
WXNET_EXPORT(int)
  wxEvent_EVT_KILL_FOCUS()                    { return wxEVT_KILL_FOCUS; }
WXNET_EXPORT(int)
  wxEvent_EVT_CHILD_FOCUS()                   { return wxEVT_CHILD_FOCUS; }
WXNET_EXPORT(int)
  wxEvent_EVT_MOUSEWHEEL()                    { return wxEVT_MOUSEWHEEL; }
WXNET_EXPORT(int)
  wxEvent_EVT_NC_LEFT_DOWN()                  { return wxEVT_NC_LEFT_DOWN; }
WXNET_EXPORT(int)
  wxEvent_EVT_NC_LEFT_UP()                    { return wxEVT_NC_LEFT_UP; }
WXNET_EXPORT(int)
  wxEvent_EVT_NC_MIDDLE_DOWN()                { return wxEVT_NC_MIDDLE_DOWN; }
WXNET_EXPORT(int)
  wxEvent_EVT_NC_MIDDLE_UP()                  { return wxEVT_NC_MIDDLE_UP; }
WXNET_EXPORT(int)
  wxEvent_EVT_NC_RIGHT_DOWN()                 { return wxEVT_NC_RIGHT_DOWN; }
WXNET_EXPORT(int)
  wxEvent_EVT_NC_RIGHT_UP()                   { return wxEVT_NC_RIGHT_UP; }
WXNET_EXPORT(int)
  wxEvent_EVT_NC_MOTION()                     { return wxEVT_NC_MOTION; }
WXNET_EXPORT(int)
  wxEvent_EVT_NC_ENTER_WINDOW()               { return wxEVT_NC_ENTER_WINDOW; }
WXNET_EXPORT(int)
  wxEvent_EVT_NC_LEAVE_WINDOW()               { return wxEVT_NC_LEAVE_WINDOW; }
WXNET_EXPORT(int)
  wxEvent_EVT_NC_LEFT_DCLICK()                { return wxEVT_NC_LEFT_DCLICK; }
WXNET_EXPORT(int)
  wxEvent_EVT_NC_MIDDLE_DCLICK()              { return wxEVT_NC_MIDDLE_DCLICK; }
WXNET_EXPORT(int)
  wxEvent_EVT_NC_RIGHT_DCLICK()               { return wxEVT_NC_RIGHT_DCLICK; }
WXNET_EXPORT(int)
  wxEvent_EVT_CHAR()                          { return wxEVT_CHAR; }
WXNET_EXPORT(int)
  wxEvent_EVT_CHAR_HOOK()                     { return wxEVT_CHAR_HOOK; }
WXNET_EXPORT(int)
  wxEvent_EVT_NAVIGATION_KEY()                { return wxEVT_NAVIGATION_KEY; }
WXNET_EXPORT(int)
  wxEvent_EVT_KEY_DOWN()                      { return wxEVT_KEY_DOWN; }
WXNET_EXPORT(int)
  wxEvent_EVT_KEY_UP()                        { return wxEVT_KEY_UP; }
WXNET_EXPORT(int)
  wxEvent_EVT_SET_CURSOR()                    { return wxEVT_SET_CURSOR; }
WXNET_EXPORT(int)
  wxEvent_EVT_SCROLL_TOP()                    { return wxEVT_SCROLL_TOP; }
WXNET_EXPORT(int)
  wxEvent_EVT_SCROLL_BOTTOM()                 { return wxEVT_SCROLL_BOTTOM; }
WXNET_EXPORT(int)
  wxEvent_EVT_SCROLL_LINEUP()                 { return wxEVT_SCROLL_LINEUP; }
WXNET_EXPORT(int)
  wxEvent_EVT_SCROLL_LINEDOWN()               { return wxEVT_SCROLL_LINEDOWN; }
WXNET_EXPORT(int)
  wxEvent_EVT_SCROLL_PAGEUP()                 { return wxEVT_SCROLL_PAGEUP; }
WXNET_EXPORT(int)
  wxEvent_EVT_SCROLL_PAGEDOWN()               { return wxEVT_SCROLL_PAGEDOWN; }
WXNET_EXPORT(int)
  wxEvent_EVT_SCROLL_THUMBTRACK()             { return wxEVT_SCROLL_THUMBTRACK; }
WXNET_EXPORT(int)
  wxEvent_EVT_SCROLL_THUMBRELEASE()           { return wxEVT_SCROLL_THUMBRELEASE; }
WXNET_EXPORT(int)
  wxEvent_EVT_SCROLL_ENDSCROLL()              { return wxEVT_SCROLL_ENDSCROLL; }
WXNET_EXPORT(int)
  wxEvent_EVT_SCROLLWIN_TOP()                 { return wxEVT_SCROLLWIN_TOP; }
WXNET_EXPORT(int)
  wxEvent_EVT_SCROLLWIN_BOTTOM()              { return wxEVT_SCROLLWIN_BOTTOM; }
WXNET_EXPORT(int)
  wxEvent_EVT_SCROLLWIN_LINEUP()              { return wxEVT_SCROLLWIN_LINEUP; }
WXNET_EXPORT(int)
  wxEvent_EVT_SCROLLWIN_LINEDOWN()            { return wxEVT_SCROLLWIN_LINEDOWN; }
WXNET_EXPORT(int)
  wxEvent_EVT_SCROLLWIN_PAGEUP()              { return wxEVT_SCROLLWIN_PAGEUP; }
WXNET_EXPORT(int)
  wxEvent_EVT_SCROLLWIN_PAGEDOWN()            { return wxEVT_SCROLLWIN_PAGEDOWN; }
WXNET_EXPORT(int)
  wxEvent_EVT_SCROLLWIN_THUMBTRACK()          { return wxEVT_SCROLLWIN_THUMBTRACK; }
WXNET_EXPORT(int)
  wxEvent_EVT_SCROLLWIN_THUMBRELEASE()        { return wxEVT_SCROLLWIN_THUMBRELEASE; }
WXNET_EXPORT(int)
  wxEvent_EVT_SIZE()                          { return wxEVT_SIZE; }
WXNET_EXPORT(int)
  wxEvent_EVT_MOVE()                          { return wxEVT_MOVE; }
WXNET_EXPORT(int)
  wxEvent_EVT_CLOSE_WINDOW()                  { return wxEVT_CLOSE_WINDOW; }
WXNET_EXPORT(int)
  wxEvent_EVT_END_SESSION()                   { return wxEVT_END_SESSION; }
WXNET_EXPORT(int)
  wxEvent_EVT_QUERY_END_SESSION()             { return wxEVT_QUERY_END_SESSION; }
WXNET_EXPORT(int)
  wxEvent_EVT_ACTIVATE_APP()                  { return wxEVT_ACTIVATE_APP; }
#if (wxCHECK_VERSION(2, 8, 0))
WXNET_EXPORT(int)
  wxEvent_EVT_POWER()                         { return -1; }
#else
WXNET_EXPORT(int)
  wxEvent_EVT_POWER()                         { return wxEVT_POWER; }
#endif

WXNET_EXPORT(int)
  wxEvent_EVT_ACTIVATE()                      { return wxEVT_ACTIVATE; }
WXNET_EXPORT(int)
  wxEvent_EVT_CREATE()                        { return wxEVT_CREATE; }
WXNET_EXPORT(int)
  wxEvent_EVT_DESTROY()                       { return wxEVT_DESTROY; }
WXNET_EXPORT(int)
  wxEvent_EVT_SHOW()                          { return wxEVT_SHOW; }
WXNET_EXPORT(int)
  wxEvent_EVT_ICONIZE()                       { return wxEVT_ICONIZE; }
WXNET_EXPORT(int)
  wxEvent_EVT_MAXIMIZE()                      { return wxEVT_MAXIMIZE; }
WXNET_EXPORT(int)
  wxEvent_EVT_MOUSE_CAPTURE_CHANGED()         { return wxEVT_MOUSE_CAPTURE_CHANGED; }
WXNET_EXPORT(int)
  wxEvent_EVT_PAINT()                         { return wxEVT_PAINT; }
WXNET_EXPORT(int)
  wxEvent_EVT_ERASE_BACKGROUND()              { return wxEVT_ERASE_BACKGROUND; }
WXNET_EXPORT(int)
  wxEvent_EVT_NC_PAINT()                      { return wxEVT_NC_PAINT; }
WXNET_EXPORT(int)
  wxEvent_EVT_PAINT_ICON()                    { return wxEVT_PAINT_ICON; }
WXNET_EXPORT(int)
  wxEvent_EVT_MENU_OPEN()                     { return wxEVT_MENU_OPEN; }
WXNET_EXPORT(int)
  wxEvent_EVT_MENU_CLOSE()                    { return wxEVT_MENU_CLOSE; }
WXNET_EXPORT(int)
  wxEvent_EVT_MENU_HIGHLIGHT()                { return wxEVT_MENU_HIGHLIGHT; }
WXNET_EXPORT(int)
  wxEvent_EVT_CONTEXT_MENU()                  { return wxEVT_CONTEXT_MENU; }
WXNET_EXPORT(int)
  wxEvent_EVT_SYS_COLOUR_CHANGED()            { return wxEVT_SYS_COLOUR_CHANGED; }
WXNET_EXPORT(int)
  wxEvent_EVT_DISPLAY_CHANGED()               { return wxEVT_DISPLAY_CHANGED; }
WXNET_EXPORT(int)
  wxEvent_EVT_SETTING_CHANGED()               { return wxEVT_SETTING_CHANGED; }
WXNET_EXPORT(int)
  wxEvent_EVT_QUERY_NEW_PALETTE()             { return wxEVT_QUERY_NEW_PALETTE; }
WXNET_EXPORT(int)
  wxEvent_EVT_PALETTE_CHANGED()               { return wxEVT_PALETTE_CHANGED; }
WXNET_EXPORT(int)
  wxEvent_EVT_JOY_BUTTON_DOWN()               { return wxEVT_JOY_BUTTON_DOWN; }
WXNET_EXPORT(int)
  wxEvent_EVT_JOY_BUTTON_UP()                 { return wxEVT_JOY_BUTTON_UP; }
WXNET_EXPORT(int)
  wxEvent_EVT_JOY_MOVE()                      { return wxEVT_JOY_MOVE; }
WXNET_EXPORT(int)
  wxEvent_EVT_JOY_ZMOVE()                     { return wxEVT_JOY_ZMOVE; }
WXNET_EXPORT(int)
  wxEvent_EVT_DROP_FILES()                    { return wxEVT_DROP_FILES; }
WXNET_EXPORT(int)
  wxEvent_EVT_DRAW_ITEM()                     { return wxEVT_DRAW_ITEM; }
WXNET_EXPORT(int)
  wxEvent_EVT_MEASURE_ITEM()                  { return wxEVT_MEASURE_ITEM; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMPARE_ITEM()                  { return wxEVT_COMPARE_ITEM; }
WXNET_EXPORT(int)
  wxEvent_EVT_INIT_DIALOG()                   { return wxEVT_INIT_DIALOG; }
WXNET_EXPORT(int)
  wxEvent_EVT_IDLE()                          { return wxEVT_IDLE; }
WXNET_EXPORT(int)
  wxEvent_EVT_UPDATE_UI()                     { return wxEVT_UPDATE_UI; }
WXNET_EXPORT(int)
  wxEvent_EVT_SIZING()                        { return wxEVT_SIZING; }
WXNET_EXPORT(int)
  wxEvent_EVT_MOVING()                        { return wxEVT_MOVING; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_LEFT_CLICK()            { return wxEVT_COMMAND_LEFT_CLICK; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_LEFT_DCLICK()           { return wxEVT_COMMAND_LEFT_DCLICK; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_RIGHT_CLICK()           { return wxEVT_COMMAND_RIGHT_CLICK; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_RIGHT_DCLICK()          { return wxEVT_COMMAND_RIGHT_DCLICK; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_SET_FOCUS()             { return wxEVT_COMMAND_SET_FOCUS; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_KILL_FOCUS()            { return wxEVT_COMMAND_KILL_FOCUS; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_ENTER()                 { return wxEVT_COMMAND_ENTER; }
WXNET_EXPORT(int)
  wxEvent_EVT_HELP()                          { return wxEVT_HELP; }
WXNET_EXPORT(int)
  wxEvent_EVT_DETAILED_HELP()                 { return wxEVT_DETAILED_HELP; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_TOGGLEBUTTON_CLICKED()  { return wxEVT_COMMAND_TOGGLEBUTTON_CLICKED; }
WXNET_EXPORT(int)
  wxEvent_EVT_OBJECTDELETED()                 { return wxEVT_OBJECTDELETED; }

WXNET_EXPORT(int)
  wxEvent_EVT_CALENDAR_SEL_CHANGED()          { return wxEVT_CALENDAR_SEL_CHANGED; }
WXNET_EXPORT(int)
  wxEvent_EVT_CALENDAR_DAY_CHANGED()          { return wxEVT_CALENDAR_DAY_CHANGED; }
WXNET_EXPORT(int)
  wxEvent_EVT_CALENDAR_MONTH_CHANGED()        { return wxEVT_CALENDAR_MONTH_CHANGED; }
WXNET_EXPORT(int)
  wxEvent_EVT_CALENDAR_YEAR_CHANGED()         { return wxEVT_CALENDAR_YEAR_CHANGED; }
WXNET_EXPORT(int)
  wxEvent_EVT_CALENDAR_DOUBLECLICKED()        { return wxEVT_CALENDAR_DOUBLECLICKED; }
WXNET_EXPORT(int)
  wxEvent_EVT_CALENDAR_WEEKDAY_CLICKED()      { return wxEVT_CALENDAR_WEEKDAY_CLICKED; }

WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_FIND()                  { return wxEVT_COMMAND_FIND; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_FIND_NEXT()             { return wxEVT_COMMAND_FIND_NEXT; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_FIND_REPLACE()          { return wxEVT_COMMAND_FIND_REPLACE; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_FIND_REPLACE_ALL()      { return wxEVT_COMMAND_FIND_REPLACE_ALL; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_FIND_CLOSE()            { return wxEVT_COMMAND_FIND_CLOSE; }

WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_TREE_BEGIN_DRAG()             { return wxEVT_COMMAND_TREE_BEGIN_DRAG; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_TREE_BEGIN_RDRAG()            { return wxEVT_COMMAND_TREE_BEGIN_RDRAG; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_TREE_BEGIN_LABEL_EDIT()       { return wxEVT_COMMAND_TREE_BEGIN_LABEL_EDIT; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_TREE_END_LABEL_EDIT()         { return wxEVT_COMMAND_TREE_END_LABEL_EDIT; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_TREE_DELETE_ITEM()            { return wxEVT_COMMAND_TREE_DELETE_ITEM; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_TREE_GET_INFO()               { return wxEVT_COMMAND_TREE_GET_INFO; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_TREE_SET_INFO()               { return wxEVT_COMMAND_TREE_SET_INFO; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_TREE_ITEM_EXPANDED()          { return wxEVT_COMMAND_TREE_ITEM_EXPANDED; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_TREE_ITEM_EXPANDING()         { return wxEVT_COMMAND_TREE_ITEM_EXPANDING; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_TREE_ITEM_COLLAPSED()         { return wxEVT_COMMAND_TREE_ITEM_COLLAPSED; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_TREE_ITEM_COLLAPSING()        { return wxEVT_COMMAND_TREE_ITEM_COLLAPSING; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_TREE_SEL_CHANGED()            { return wxEVT_COMMAND_TREE_SEL_CHANGED; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_TREE_SEL_CHANGING()           { return wxEVT_COMMAND_TREE_SEL_CHANGING; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_TREE_KEY_DOWN()               { return wxEVT_COMMAND_TREE_KEY_DOWN; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_TREE_ITEM_ACTIVATED()         { return wxEVT_COMMAND_TREE_ITEM_ACTIVATED; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_TREE_ITEM_RIGHT_CLICK()       { return wxEVT_COMMAND_TREE_ITEM_RIGHT_CLICK; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_TREE_ITEM_MIDDLE_CLICK()      { return wxEVT_COMMAND_TREE_ITEM_MIDDLE_CLICK; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_TREE_END_DRAG()               { return wxEVT_COMMAND_TREE_END_DRAG; }

WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_LIST_BEGIN_DRAG()             { return wxEVT_COMMAND_LIST_BEGIN_DRAG; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_LIST_BEGIN_RDRAG()            { return wxEVT_COMMAND_LIST_BEGIN_RDRAG; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_LIST_BEGIN_LABEL_EDIT()       { return wxEVT_COMMAND_LIST_BEGIN_LABEL_EDIT; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_LIST_END_LABEL_EDIT()         { return wxEVT_COMMAND_LIST_END_LABEL_EDIT; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_LIST_DELETE_ITEM()            { return wxEVT_COMMAND_LIST_DELETE_ITEM; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_LIST_DELETE_ALL_ITEMS()       { return wxEVT_COMMAND_LIST_DELETE_ALL_ITEMS; }
#if WXWIN_COMPATIBILITY_2_4
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_LIST_GET_INFO()			{ return wxEVT_COMMAND_LIST_GET_INFO; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_LIST_SET_INFO()			{ return wxEVT_COMMAND_LIST_SET_INFO; }
#else
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_LIST_GET_INFO()			{ return -1; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_LIST_SET_INFO()			{ return -1; }
#endif

WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_LIST_ITEM_SELECTED()          { return wxEVT_COMMAND_LIST_ITEM_SELECTED; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_LIST_ITEM_DESELECTED()        { return wxEVT_COMMAND_LIST_ITEM_DESELECTED; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_LIST_ITEM_ACTIVATED()         { return wxEVT_COMMAND_LIST_ITEM_ACTIVATED; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_LIST_ITEM_FOCUSED()           { return wxEVT_COMMAND_LIST_ITEM_FOCUSED; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_LIST_ITEM_MIDDLE_CLICK()      { return wxEVT_COMMAND_LIST_ITEM_MIDDLE_CLICK; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_LIST_ITEM_RIGHT_CLICK()       { return wxEVT_COMMAND_LIST_ITEM_RIGHT_CLICK; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_LIST_KEY_DOWN()               { return wxEVT_COMMAND_LIST_KEY_DOWN; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_LIST_INSERT_ITEM()            { return wxEVT_COMMAND_LIST_INSERT_ITEM; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_LIST_COL_CLICK()              { return wxEVT_COMMAND_LIST_COL_CLICK; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_LIST_COL_RIGHT_CLICK()        { return wxEVT_COMMAND_LIST_COL_RIGHT_CLICK; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_LIST_COL_BEGIN_DRAG()         { return wxEVT_COMMAND_LIST_COL_BEGIN_DRAG; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_LIST_COL_DRAGGING()           { return wxEVT_COMMAND_LIST_COL_DRAGGING; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_LIST_COL_END_DRAG()           { return wxEVT_COMMAND_LIST_COL_END_DRAG; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_LIST_CACHE_HINT()             { return wxEVT_COMMAND_LIST_CACHE_HINT; }

WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_NOTEBOOK_PAGE_CHANGED()       { return wxEVT_COMMAND_NOTEBOOK_PAGE_CHANGED; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_NOTEBOOK_PAGE_CHANGING()      { return wxEVT_COMMAND_NOTEBOOK_PAGE_CHANGING; }

WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_LISTBOOK_PAGE_CHANGED()       { return wxEVT_COMMAND_LISTBOOK_PAGE_CHANGED; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_LISTBOOK_PAGE_CHANGING()      { return wxEVT_COMMAND_LISTBOOK_PAGE_CHANGING; }
#ifdef __WXMSW__
#if (wxUSE_TAB_DIALOG)
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_TAB_SEL_CHANGED()             { return wxEVT_COMMAND_TAB_SEL_CHANGED; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_TAB_SEL_CHANGING()            { return wxEVT_COMMAND_TAB_SEL_CHANGING; }
#else 
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_TAB_SEL_CHANGED()             { return -1; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_TAB_SEL_CHANGING()            { return -1; }
#endif
#endif // __WXMSW__


WXNET_EXPORT(int)
  wxEvent_EVT_GRID_CELL_LEFT_CLICK() 		{ return wxEVT_GRID_CELL_LEFT_CLICK; }
WXNET_EXPORT(int)
  wxEvent_EVT_GRID_CELL_RIGHT_CLICK() 		{ return wxEVT_GRID_CELL_RIGHT_CLICK; }
WXNET_EXPORT(int)
  wxEvent_EVT_GRID_CELL_LEFT_DCLICK() 		{ return wxEVT_GRID_CELL_LEFT_DCLICK; }
WXNET_EXPORT(int)
  wxEvent_EVT_GRID_CELL_RIGHT_DCLICK() 		{ return wxEVT_GRID_CELL_RIGHT_DCLICK; }
WXNET_EXPORT(int)
  wxEvent_EVT_GRID_LABEL_LEFT_CLICK()		{ return wxEVT_GRID_LABEL_LEFT_CLICK; }
WXNET_EXPORT(int)
  wxEvent_EVT_GRID_LABEL_RIGHT_CLICK()		{ return wxEVT_GRID_LABEL_RIGHT_CLICK; }
WXNET_EXPORT(int)
  wxEvent_EVT_GRID_LABEL_LEFT_DCLICK()		{ return wxEVT_GRID_LABEL_LEFT_DCLICK; }
WXNET_EXPORT(int)
  wxEvent_EVT_GRID_LABEL_RIGHT_DCLICK()		{ return wxEVT_GRID_LABEL_RIGHT_DCLICK; }
WXNET_EXPORT(int)
  wxEvent_EVT_GRID_ROW_SIZE()			{ return wxEVT_GRID_ROW_SIZE; }
WXNET_EXPORT(int)
  wxEvent_EVT_GRID_COL_SIZE()			{ return wxEVT_GRID_COL_SIZE; }
WXNET_EXPORT(int)
  wxEvent_EVT_GRID_RANGE_SELECT()			{ return wxEVT_GRID_RANGE_SELECT; }
WXNET_EXPORT(int)
  wxEvent_EVT_GRID_CELL_CHANGE()			{ return wxEVT_GRID_CELL_CHANGE; }
WXNET_EXPORT(int)
  wxEvent_EVT_GRID_SELECT_CELL()			{ return wxEVT_GRID_SELECT_CELL; }
WXNET_EXPORT(int)
  wxEvent_EVT_GRID_EDITOR_SHOWN()			{ return wxEVT_GRID_EDITOR_SHOWN; }
WXNET_EXPORT(int)
  wxEvent_EVT_GRID_EDITOR_HIDDEN()		{ return wxEVT_GRID_EDITOR_HIDDEN; }
WXNET_EXPORT(int)
  wxEvent_EVT_GRID_EDITOR_CREATED()		{ return wxEVT_GRID_EDITOR_CREATED; }

WXNET_EXPORT(int)
  wxEvent_EVT_SASH_DRAGGED()			{ return wxEVT_SASH_DRAGGED; }

WXNET_EXPORT(int)
  wxEvent_EVT_QUERY_LAYOUT_INFO()			{ return wxEVT_QUERY_LAYOUT_INFO; }
WXNET_EXPORT(int)
  wxEvent_EVT_CALCULATE_LAYOUT()			{ return wxEVT_CALCULATE_LAYOUT; }
BEGIN_DECLARE_EVENT_TYPES()
DECLARE_EVENT_TYPE(wxEVT_LOAD_HTML_PAGE, -1)
END_DECLARE_EVENT_TYPES()

DEFINE_EVENT_TYPE(wxEVT_LOAD_HTML_PAGE)


WXNET_EXPORT(int)
  wxEvent_EVT_LOAD_HTML_PAGE()			{ return wxEVT_LOAD_HTML_PAGE; }
//-----------------------------------------------------------------------------

/* wxTaskBarIcon events impementation */

WXNET_EXPORT(int)
  wxEvent_EVT_TASKBAR_MOVE() 			{ return wxEVT_TASKBAR_MOVE; }
WXNET_EXPORT(int)
  wxEvent_EVT_TASKBAR_LEFT_DOWN() 		{ return wxEVT_TASKBAR_LEFT_DOWN; }
WXNET_EXPORT(int)
  wxEvent_EVT_TASKBAR_LEFT_UP() 			{ return wxEVT_TASKBAR_LEFT_UP; }
WXNET_EXPORT(int)
  wxEvent_EVT_TASKBAR_RIGHT_DOWN() 		{ return wxEVT_TASKBAR_RIGHT_DOWN; }
WXNET_EXPORT(int)
  wxEvent_EVT_TASKBAR_RIGHT_UP() 		{ return wxEVT_TASKBAR_RIGHT_UP; }
WXNET_EXPORT(int)
  wxEvent_EVT_TASKBAR_LEFT_DCLICK() 		{ return wxEVT_TASKBAR_LEFT_DCLICK; }
WXNET_EXPORT(int)
  wxEvent_EVT_TASKBAR_RIGHT_DCLICK() 		{ return wxEVT_TASKBAR_RIGHT_DCLICK; }
WXNET_EXPORT(int)
  wxEvent_EVT_TASKBAR_CLICK() 			{ return wxEVT_TASKBAR_CLICK; }

WXNET_EXPORT(int) wxEvent_CreateNewEventType(void)
{
    return wxNewEventType();
}
//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxEvent_GetEventType(wxEvent* self)
{
    return self->GetEventType();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxEvent_GetId(wxEvent* self)
{
    return self->GetId();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxEvent_GetSkipped(wxEvent* self)
{
    return self->GetSkipped();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxEvent_GetTimestamp(wxEvent* self)
{
    return self->GetTimestamp();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxEvent_Skip(wxEvent* self, bool skip)
{
    self->Skip(skip);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxObject*)
  wxEvent_GetEventObject(wxEvent* self)
{
    return self->GetEventObject();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxEvent_EVT_DATE_CHANGED()			{ return wxEVT_DATE_CHANGED; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_COLOURPICKER_CHANGED()			{ return wxEVT_COMMAND_COLOURPICKER_CHANGED; }
WXNET_EXPORT(int)
  wxEvent_EVT_COMMAND_FONTPICKER_CHANGED()			{ return wxEVT_COMMAND_FONTPICKER_CHANGED; }

//-----------------------------------------------------------------------------
// wxWizard events

WXNET_EXPORT(int) wxEvent_EVT_WIZARD_PAGE_CHANGED() { return wxEVT_WIZARD_PAGE_CHANGED; }
WXNET_EXPORT(int) wxEvent_EVT_WIZARD_PAGE_CHANGING() { return wxEVT_WIZARD_PAGE_CHANGING; }
WXNET_EXPORT(int) wxEvent_EVT_WIZARD_CANCEL() { return wxEVT_WIZARD_CANCEL; }
WXNET_EXPORT(int) wxEvent_EVT_WIZARD_HELP() { return wxEVT_WIZARD_HELP; }
WXNET_EXPORT(int) wxEvent_EVT_WIZARD_FINISHED() { return wxEVT_WIZARD_FINISHED; }

WXNET_EXPORT(void) wxNotifyEvent_Allow(wxNotifyEvent* self)
{
   if (self)
      self->Allow();
}

WXNET_EXPORT(char) wxNotifyEvent_IsAllowed(const wxNotifyEvent* self)
{
   if (self)
      return self->IsAllowed();
   else
      return false;
}

WXNET_EXPORT(void) wxNotifyEvent_Veto(wxNotifyEvent* self)
{
   if (self)
      self->Veto();
}


