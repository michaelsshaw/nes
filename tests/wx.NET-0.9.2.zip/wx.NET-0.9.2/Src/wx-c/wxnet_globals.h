//-----------------------------------------------------------------------------
// wx.NET 
//
// Global declarations for all files.
//
// Written by Dr. Harald Meyer auf'm Hofe
// (C) 2009
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: wxnet_globals.h,v 1.5 2010/06/16 18:09:03 harald_meyer Exp $
//-----------------------------------------------------------------------------

#ifndef WXNET_GLOBAL_H
#define WXNET_GLOBAL_H

#if !defined(__GNUC__) && (defined(__WXMSW__) || defined(__WXMAC__) || defined(__WXCOCOA__))
// please note, that stdcall used with GCC will produce libraries with symbol names that
// do not follow MS naming conventions. MS tools introduce stdcall C symbols with an underscore.
// The GNU compiler won't do that. As a consequence, PINVOKE will not find stdcall functions
// compiled by the GNU compiler.
#define WXNET_EXPORT(return_type) extern "C" __declspec(dllexport) return_type __stdcall
#else
#define WXNET_EXPORT(return_type) extern "C" return_type
#endif

// MingW already defines CALLBACK
#ifndef CALLBACK
# if defined(_WINDOWS)
#  define CALLBACK __stdcall
# else
#  define CALLBACK
# endif
#endif

#if (!defined(__WXMSW__) || defined(_DEBUG)) && defined(WXNET_LOG_MEM)
#if defined(__WXMSW__) && defined(_MSC_VER)
#pragma message("Log memory allocations in wx_c_mem.csv.")
#ifndef _CRTDBG_MAP_ALLOC
# define _CRTDBG_MAP_ALLOC
#endif
#include <crtdbg.h>
#include <stdlib.h>
#include <typeinfo.h>
#endif
extern void* wxnetLogNew(void* blockStart, const char* filename, int lineno);
extern void wxnetLogLocal(void* blockStart, const char* filename, int lineno);
extern void wxnetLogDel(void* blockStart, const char* filename, int lineno);
extern void wxnetLogDeref(const void* usedData, const char* typeinfo, const char* filename, int lineno);
extern void wxnetLogDerefString(const wxString* usedData, const char* filename, int lineno);
extern void wxnetLogDerefPrintable(const void* usedData, const wxString& printOut, const char* filename, int lineno);

#define WXNET_NEW(className, args) (className*) wxnetLogNew(new className args, __FILE__, __LINE__)
#define WXNET_DEL(ptr) wxnetLogDel(ptr, __FILE__, __LINE__); if (ptr) delete ptr
#define WXNET_LOG_DEREF(ptr) wxnetLogDeref(ptr, typeid(ptr).name(),__FILE__, __LINE__);
#define WXNET_LOG_DEREFSTR(ptr) wxnetLogDerefString(ptr, __FILE__, __LINE__);
#define WXNET_LOG_DEREFDATETIME(ptr) wxnetLogDerefPrintable(ptr, ptr?ptr->Format():wxString(), __FILE__, __LINE__);
#else
#define WXNET_NEW(className, args) new className args
#define WXNET_DEL(ptr) if (ptr) delete ptr
#define WXNET_LOG_DEREF(ptr) 
#define WXNET_LOG_DEREFSTR(ptr) 
#define WXNET_LOG_DEREFDATETIME(ptr) 
#endif


struct ByteBuffer
{
   unsigned char*               _buffer;
   size_t                       _sizeReserved;
   size_t                       _sizeFilled;
   ByteBuffer()
      : _buffer(NULL), _sizeReserved(0), _sizeFilled(0)
   {
   }
   ByteBuffer(size_t sizeReserved)
      : _buffer(NULL), _sizeReserved(sizeReserved), _sizeFilled(0)
   {
      _buffer=new unsigned char[_sizeReserved];
   }
   virtual ~ByteBuffer()
   {
      if (_buffer) delete _buffer;
   }
};

extern std::ostream& operator<<(std::ostream& dest, const ByteBuffer& src);

#endif
