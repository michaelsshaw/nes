//-----------------------------------------------------------------------------
// wx.NET - mdi.cxx
// 
// The wxMDI* proxy interface.
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 by Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: mdi.cxx,v 1.13 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/mdi.h>
#include "local_events.h"

//-----------------------------------------------------------------------------

typedef wxMDIClientWindow* (CALLBACK* Virtual_OnCreateClient) ();

class _MDIParentFrame : public wxMDIParentFrame 
{
public:
	_MDIParentFrame()
		: wxMDIParentFrame() {}
	
	wxMDIClientWindow *OnCreateClient()
	{ return m_OnCreateClient(); }
	
	void Register_Virtual(Virtual_OnCreateClient onCreateClient)
	{
		m_OnCreateClient = onCreateClient;
	}
	
private:
	Virtual_OnCreateClient m_OnCreateClient;
};

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxMDIParentFrame*)
  wxMDIParentFrame_ctor()
{
	return new _MDIParentFrame();
}

WXNET_EXPORT(void)
  wxMDIParentFrame_RegisterVirtual(_MDIParentFrame* self, Virtual_OnCreateClient onCreateClient)
{
	self->Register_Virtual(onCreateClient);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxMDIClientWindow*)
  wxMDIParentFrame_OnCreateClient(_MDIParentFrame* self)
{
	return self->wxMDIParentFrame::OnCreateClient();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxMDIParentFrame_Create(_MDIParentFrame* self, wxWindow* parent, wxWindowID id, const wxString* titleArg, int posX, int posY, int width, int height, unsigned int style, const wxString* nameArg)
{
   wxString name;
   if (nameArg == NULL)
        name = wxT("mdiParentFrame");
   else
      name=*nameArg;
   wxString title;
   if (titleArg != NULL)
      title=*titleArg;

   return self->Create(parent, id, title, wxPoint(posX, posY), wxSize(width, height), style, name);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxMDIChildFrame*)
  wxMDIParentFrame_GetActiveChild(_MDIParentFrame* self)
{
    return self->GetActiveChild();
}

//-----------------------------------------------------------------------------

#if 0
WXNET_EXPORT(void)
  wxMDIParentFrame_SetActiveChild(wxMDIParentFrame* self, wxMDIChildFrame* pChildFrame)
{
    self->SetActiveChild(pChildFrame);
}
#endif

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxMDIClientWindow*)
  wxMDIParentFrame_GetClientWindow(_MDIParentFrame* self)
{
    return self->GetClientWindow();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxMDIParentFrame_Cascade(_MDIParentFrame* self)
{
    self->Cascade();
}

WXNET_EXPORT(void)
  wxMDIParentFrame_Tile(_MDIParentFrame* self)
{
    self->Tile();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxMDIParentFrame_ArrangeIcons(_MDIParentFrame* self)
{
    self->ArrangeIcons();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxMDIParentFrame_ActivateNext(_MDIParentFrame* self)
{
    self->ActivateNext();
}

WXNET_EXPORT(void)
  wxMDIParentFrame_ActivatePrevious(_MDIParentFrame* self)
{
    self->ActivatePrevious();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxMDIParentFrame_GetClientSize(_MDIParentFrame* self, int* width, int* height)
{
	self->GetClientSize(width, height);
}

//-----------------------------------------------------------------------------
// wxMDIChildFrame

class _MDIChildFrame : public wxMDIChildFrame 
{
public:
	DECLARE_OBJECTDELETED(_MDIChildFrame)
};

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxMDIChildFrame*)
  wxMDIChildFrame_ctor()
{
    return new _MDIChildFrame();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxMDIChildFrame_Activate(wxMDIChildFrame* self)
{
	self->Activate();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxMDIChildFrame_Create(wxMDIChildFrame* self, wxMDIParentFrame* parent, wxWindowID id, const wxString* titleArg, int posX, int posY, int width, int height, unsigned int style, const wxString* nameArg)
{
   wxString name;
   if (nameArg == NULL)
        name = wxT("mdiChildFrame");
   else
      name=*nameArg;
   wxString title;
   if (titleArg!=NULL)
      title=*titleArg;

    return self->Create(parent, id, title, wxPoint(posX, posY), wxSize(width, height), style, name);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxMDIChildFrame_Restore(wxMDIChildFrame* self)
{
    self->Restore();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxMDIChildFrame_Maximize(wxMDIChildFrame* self, bool maximize)
{
    self->Maximize(maximize);
}

//-----------------------------------------------------------------------------
// wxMDIClientWindow

class _MDIClientWindow : public wxMDIClientWindow
{
public:
    DECLARE_OBJECTDELETED(_MDIClientWindow)
};

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxMDIClientWindow*)
  wxMDIClientWindow_ctor()
{
    return new _MDIClientWindow();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxMDIClientWindow_CreateClient(wxMDIClientWindow* self, wxMDIParentFrame* parent, unsigned int style)
{
    return self->CreateClient(parent, style)?1:0;
}

//-----------------------------------------------------------------------------

