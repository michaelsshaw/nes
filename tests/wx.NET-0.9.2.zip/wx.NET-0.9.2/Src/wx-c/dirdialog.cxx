//-----------------------------------------------------------------------------
// wx.NET - dirdialog.cxx
// 
// The wxDirDialog proxy interface
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 by Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: dirdialog.cxx,v 1.7 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/dirdlg.h>
#include "local_events.h"

//-----------------------------------------------------------------------------

class _DirDialog : public wxDirDialog
{
public:
    _DirDialog(wxWindow* parent, const wxString& message, 
            const wxString& defaultPath, unsigned int style, const wxPoint& pos,
            const wxSize& size, const wxString& name)
        : wxDirDialog(parent, message, defaultPath, style, pos, size, name)
    {
    }

    DECLARE_OBJECTDELETED(_DirDialog)
};

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxDirDialog*)
  wxDirDialog_ctor(wxWindow* parent,  const wxString* messageArg, 
                              const wxString* defaultPathArg, unsigned int style, int posX, int posY, 
                              int sizeX, int sizeY, const wxString* nameArg)
{
   wxString message;
   if (messageArg==NULL)
      message=wxT("Choose a directory.");
   else
      message=*messageArg;
   wxString defaultPath;
   if (defaultPathArg != NULL)
      defaultPath=*defaultPathArg;
   wxString name;
   if (nameArg != NULL)
      name=*nameArg;
   return new _DirDialog(parent, message, defaultPath, style, wxPoint(posX, posY),
                         wxSize(sizeX, sizeY), name);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxDirDialog_GetStyle(wxDirDialog* self)
{
#if wxCHECK_VERSION(2, 8, 0)
    return self->wxWindow::GetWindowStyle();
#else    
    return self->GetStyle();
#endif    
}


WXNET_EXPORT(void)
  wxDirDialog_SetStyle(wxDirDialog* self, unsigned int style)
{
#if wxCHECK_VERSION(2, 8, 0)
    self->SetWindowStyle(style);
#else
    self->SetStyle(style);
#endif    
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxDirDialog_SetMessage(wxDirDialog* self, const wxString* message)
{
   if (self && message)
    self->SetMessage(*message);
}

WXNET_EXPORT(wxString*)
  wxDirDialog_GetMessage(wxDirDialog* self)
{
    return new wxString(self->GetMessage());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxDirDialog_ShowModal(wxDirDialog* self)
{
    return self->ShowModal();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxDirDialog_SetPath(wxDirDialog* self, const wxString* path)
{
   if (self && path)
    self->SetPath(*path);
}

WXNET_EXPORT(wxString*)
  wxDirDialog_GetPath(wxDirDialog* self)
{
    return new wxString(self->GetPath());
}

