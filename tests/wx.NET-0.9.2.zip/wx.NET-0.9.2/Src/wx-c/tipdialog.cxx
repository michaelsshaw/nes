//-----------------------------------------------------------------------------
// wx.NET - tipdialog.cxx
//
// The wxTipProvider proxy interface.
//
// Written by Alexander Olk (xenomorph2@onlinehome.de)
// (C) 2003 by Alexander Olk
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: tipdialog.cxx,v 1.7 2010/06/05 11:52:02 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/tipdlg.h>
#include "local_events.h"

static wxTipProvider* mpTipProvider = NULL;

//-----------------------------------------------------------------------------

WXNET_EXPORT(size_t)
  wxTipProvider_GetCurrentTip()
{
    if ( mpTipProvider == NULL ) return 0;
    return mpTipProvider->GetCurrentTip();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxTipProvider*)
  wxCreateFileTipProvider_func(const wxString* filename, size_t currentTip)
{
	if ( mpTipProvider != NULL)
	{
		delete mpTipProvider;
	}
   mpTipProvider=NULL;
   if (filename)
	   mpTipProvider=wxCreateFileTipProvider(*filename, currentTip);
   return mpTipProvider;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxShowTip_func(wxWindow* parent, bool showAtStartup)
{
	if (mpTipProvider)
		return wxShowTip(parent, mpTipProvider, showAtStartup)?1:0;
	else
		return 0;
}

//-----------------------------------------------------------------------------







