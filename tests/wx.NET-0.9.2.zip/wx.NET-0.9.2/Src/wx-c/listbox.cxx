//-----------------------------------------------------------------------------
// wx.NET - listbox.cxx
//
// wxListBox proxy inteface.
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: listbox.cxx,v 1.25 2010/02/22 22:13:41 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/listbox.h>
#include <wx/checklst.h>
#include "local_events.h"

//-----------------------------------------------------------------------------

class _ListBox : public wxListBox
{
public:
    DECLARE_OBJECTDELETED(_ListBox)
};

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxListBox*)
  wxListBox_ctor()
{
	return new _ListBox();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxListBox_dtor(wxListBox* self)
{
	WXNET_DEL(self);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxListBox_Create(wxListBox* self, wxWindow *parent, wxWindowID id,
					  const wxPoint* pos, const wxSize* size, 
                 const wxArrayString* items, unsigned int style,
					  const wxValidator* validator, const wxString* nameArg)
{
	if (pos == NULL)
		pos = &wxDefaultPosition;

	if (size == NULL)
		size = &wxDefaultSize;

	if (validator == NULL)
		validator = &wxDefaultValidator;

   wxString name;
	if (nameArg == NULL)
		name = wxT("listbox");
   else
      name=*nameArg;

    if (self && validator)
    {
       if (items)
	      return self->Create(parent, id, *pos, *size, *items, style, *validator, name)?1:0;
       else
          return self->Create(parent, id, *pos, *size, 0, NULL, style, *validator, name)?1:0;
    }
    return false;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxListBox_GetSingleString(wxListBox* self, int n)
{
	return new wxString(self->GetString(n));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxListBox_SetSingleString(wxListBox* self, int n, const wxString* s)
{
   if (self && s)
	   self->SetString(n, *s);
}

//-----------------------------------------------------------------------------


WXNET_EXPORT(void)
  wxListBox_SetSelection(wxListBox* self, int n, bool select)
{
	self->SetSelection(n, select);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxListBox_GetSelection(wxListBox* self)
{
	return self->GetSelection();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxArrayInt*)
  wxListBox_GetSelections(wxListBox* self)
{
    wxArrayInt *ari = new wxArrayInt();
	self->GetSelections(*ari);
    return ari;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxListBox_InsertItems(wxListBox* self, const wxArrayString* items, int pos)
{
    if (self)
    {
      if (items)
      {
         self->InsertItems(*items, pos);
      }
      else
      {
         self->InsertItems(0, NULL, pos);
      }
    }
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxListBox_Set(wxListBox* self, const wxArrayString* items, wxClientData* clientData[])
{
    if (self && items)
	   self->Set(*items, (void**) clientData);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxListBox_Select(wxListBox* self, int n)
{
	self->Select(n);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxListBox_Deselect(wxListBox* self, int n)
{
	self->Deselect(n);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxListBox_DeselectAll(wxListBox* self, int itemToLeaveSelected)
{
	self->DeselectAll(itemToLeaveSelected);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxListBox_SetFirstItem(wxListBox* self, int n)
{
	self->SetFirstItem(n);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxListBox_SetFirstItemText(wxListBox* self, const wxString* s)
{
   if (self && s)
	   self->SetFirstItem(*s);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxListBox_HasMultipleSelection(wxListBox* self)
{
	return self->HasMultipleSelection()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxListBox_IsSorted(wxListBox* self)
{
	return self->IsSorted()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxListBox_Command(wxListBox* self, wxCommandEvent* event)
{
	self->Command(*event);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(const wxString*)
  wxListBox_GetStringSelection(wxListBox* self)
{
	return new wxString(self->GetStringSelection());
}

//-----------------------------------------------------------------------------
// wxCheckListBox

class _CheckListBox : public wxCheckListBox
{
public:
	_CheckListBox()
		: wxCheckListBox() {}
		
	_CheckListBox(wxWindow *parent, wxWindowID id,
            const wxPoint& pos,
            const wxSize& size,
            const wxArrayString& choices,
            int style,
            const wxValidator& validator,
            const wxString& name)
	    : wxCheckListBox(parent, id, pos, size, choices, style, validator, name) {}
	    
	_CheckListBox(wxWindow *parent, wxWindowID id,
            const wxPoint& pos,
            const wxSize& size,
            size_t n,
            const wxString choices[],
            int style,
            const wxValidator& validator,
            const wxString& name)
	    : wxCheckListBox(parent, id, pos, size, n, choices, style, validator, name) {}
	    
	DECLARE_OBJECTDELETED(_CheckListBox)
};

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxCheckListBox*)
  wxCheckListBox_ctor1()
{
	return new _CheckListBox();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxCheckListBox*)
  wxCheckListBox_ctor2(wxWindow* parent, wxWindowID id, const wxPoint* pos, const wxSize* size, 
	const wxArrayString* choices, unsigned int style, const wxValidator* validator, const wxString* nameArg)
{
	if (pos == NULL)
		pos = &wxDefaultPosition;

	if (size == NULL)
		size = &wxDefaultSize;

	if (validator == NULL)
		validator = &wxDefaultValidator;

   wxString name;
	if (nameArg == NULL)
		name = wxT("checklistbox");
   else
      name=*nameArg;

   if (choices)
	   return new _CheckListBox(parent, id, *pos, *size, *choices, style, *validator, name);
   else
	   return new _CheckListBox(parent, id, *pos, *size, 0, NULL, style, *validator, name);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxCheckListBox_IsChecked(wxCheckListBox* self, int index)
{
	return self->IsChecked(index)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxCheckListBox_Check(wxCheckListBox* self, int index, bool check)
{
	return self->Check(index, check);
}

//-----------------------------------------------------------------------------

#ifndef __WXMAC__
WXNET_EXPORT(int)
  wxCheckListBox_GetItemHeight(wxCheckListBox* self)
{
	return self->GetItemHeight();
}
#endif
