//-----------------------------------------------------------------------------
// wx.NET - bmpbuttn.cxx
// 
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: bitmapbutton.cxx,v 1.19 2009/12/12 10:29:53 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/bmpbuttn.h>
#include "local_events.h"

// CALLBACK MAY BE ALREADY DEFINED
#ifndef CALLBACK 
# if defined(_WINDOWS)
#  define CALLBACK __stdcall
# else
#  define CALLBACK
# endif
#endif

//-----------------------------------------------------------------------------

typedef void (CALLBACK* Virtual_OnSetBitmap) ();

class _BitmapButton : public wxBitmapButton
{
public:
	_BitmapButton()
   : wxBitmapButton(), m_OnSetBitmap(NULL) {}
		
	void POnSetBitmap()
		{ wxBitmapButton::OnSetBitmap(); }

	void RegisterVirtual(Virtual_OnSetBitmap onSetBitmap)
	{
		m_OnSetBitmap = onSetBitmap;
	}
	
protected:
	void OnSetBitmap()
    { if (m_OnSetBitmap) m_OnSetBitmap(); }
		
private:
	Virtual_OnSetBitmap m_OnSetBitmap;
	
public:
	DECLARE_OBJECTDELETED(_BitmapButton)
	
	//DECLARE_DISPOSABLE_AND_OBJECTDELETED(_BitmapButton)
};

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxBitmapButton*)
  wxBitmapButton_ctor()
{
	return new _BitmapButton();
}

WXNET_EXPORT(void)
  wxBitmapButton_RegisterVirtual(_BitmapButton* self, Virtual_OnSetBitmap onSetBitmap)
{
	self->RegisterVirtual(onSetBitmap);
}

/*extern "C" WXEXPORT
void wxBitmapButton_RegisterDisposable(_BitmapButton* self, Virtual_Dispose onDispose)
{
	self->RegisterDispose(onDispose);
}*/

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxBitmapButton_Create(_BitmapButton* self, wxWindow *parent, wxWindowID id, const wxBitmap *bitmap, int x, int y, int w, int h, unsigned int style, const wxValidator* validator, const wxString* nameArg)
{
	if (validator == NULL)
		validator = &wxDefaultValidator;

   wxString name;
	if (nameArg == NULL)
		name = wxT("bitmapbutton");
   else
      name=*nameArg;

	return self->Create(parent, id, *bitmap, wxPoint(x,y), wxSize(w, h), style, *validator, *name)?1:0;
}

WXNET_EXPORT(void)
  wxBitmapButton_OnSetBitmap(_BitmapButton* self)
{
	self->POnSetBitmap();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxBitmapButton_SetLabel(_BitmapButton* self, const wxString* label)
{
   if (self && label)
	   self->SetLabel(*label);
}

WXNET_EXPORT(wxString*)
  wxBitmapButton_GetLabel(_BitmapButton* self)
{
	return new wxString(self->GetLabel());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxBitmapButton_Enable(_BitmapButton* self, bool enable)
{
	return self->Enable(enable)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxBitmapButton_SetBitmapLabel(_BitmapButton* self, const wxBitmap* bitmap)
{
	self->SetBitmapLabel(*bitmap);
}

WXNET_EXPORT(wxBitmap*)
  wxBitmapButton_GetBitmapLabel(_BitmapButton* self)
{
    return &(self->GetBitmapLabel());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxBitmapButton_SetBitmapSelected(_BitmapButton* self, const wxBitmap* sel)
{
	self->SetBitmapSelected(*sel);
}

WXNET_EXPORT(wxBitmap*)
  wxBitmapButton_GetBitmapSelected(_BitmapButton* self)
{
    return &(self->GetBitmapSelected());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxBitmapButton_SetBitmapDisabled(_BitmapButton* self, const wxBitmap* disabled)
{
    self->SetBitmapDisabled(*disabled);
}

WXNET_EXPORT(wxBitmap*)
  wxBitmapButton_GetBitmapDisabled(_BitmapButton* self)
{
    return &(self->GetBitmapDisabled());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxBitmapButton_SetBitmapFocus(_BitmapButton* self, const wxBitmap* focus)
{
	self->SetBitmapFocus(*focus);
}

WXNET_EXPORT(wxBitmap*)
  wxBitmapButton_GetBitmapFocus(_BitmapButton* self)
{
    return &(self->GetBitmapFocus());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxBitmapButton_SetDefault(_BitmapButton* self)
{
	self->SetDefault();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxBitmapButton_SetMargins(_BitmapButton* self, int x, int y)
{
	self->SetMargins(x, y);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxBitmapButton_GetMarginX(_BitmapButton* self)
{
	return self->GetMarginX();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxBitmapButton_GetMarginY(_BitmapButton* self)
{
	return self->GetMarginY();
}

//-----------------------------------------------------------------------------

/*extern "C" WXEXPORT
void wxBitmapButton_ApplyParentThemeBackground(_BitmapButton* self, wxColour* colour)
{
	self->ApplyParentThemeBackground(*colour);
}*/
