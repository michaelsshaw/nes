
//-----------------------------------------------------------------------------
// wx.NET - treectrl.cxx
//
// The wxTreeCtrl proxy interface.
//
// Written by Jason Perkins (jason@379.com)
// (C) 2003 by 379, Inc.
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: treectrl.cxx,v 1.31 2009/01/06 18:24:22 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/treectrl.h>
#include "local_events.h"

//-----------------------------------------------------------------------------
// wxTreeCtrl

typedef int (CALLBACK* Virtual_OnCompareItems) (wxTreeItemId*, wxTreeItemId*);

class _TreeCtrl : public wxTreeCtrl, ValidatorStub
{
   DECLARE_DYNAMIC_CLASS(_TreeCtrl)
public:
	_TreeCtrl()
		: wxTreeCtrl() {}
		
	void RegisterVirtual(Virtual_OnCompareItems onCompareItems)
	{
		m_OnCompareItems = onCompareItems;
	}
	
	virtual int OnCompareItems(const wxTreeItemId& item1, const wxTreeItemId& item2)
	{ 
		return m_OnCompareItems(WXNET_NEW( wxTreeItemId, (item1)), WXNET_NEW( wxTreeItemId, (item2))); 
	}

public:
    void* my_cookie;
    
private:
	Virtual_OnCompareItems m_OnCompareItems;

public:
    DECLARE_OBJECTDELETED(_TreeCtrl)

#include "control.inc"
};

IMPLEMENT_DYNAMIC_CLASS(_TreeCtrl, wxTreeCtrl)

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxTreeCtrl*)
  wxTreeCtrl_ctor()
{
	return WXNET_NEW(_TreeCtrl, ());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTreeCtrl_RegisterVirtual(_TreeCtrl* self, Virtual_OnCompareItems onCompareItems)
{
	self->RegisterVirtual(onCompareItems);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxTreeCtrl_OnCompareItems(_TreeCtrl* self, wxTreeItemId* item1, wxTreeItemId* item2)
{
	return self->wxTreeCtrl::OnCompareItems(*item1, *item2);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTreeCtrl_SortChildren(wxTreeCtrl* self, wxTreeItemId* item)
{
	self->SortChildren(*item);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxTreeItemId*)
  wxTreeCtrl_AddRoot(wxTreeCtrl* self, const wxString* text, int image, int selImage, wxTreeItemData* data)
{
   if (self && text)
	   return WXNET_NEW( wxTreeItemId, (self->AddRoot(*text, image, selImage, data)) );
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxTreeItemId*)
  wxTreeCtrl_AppendItem(wxTreeCtrl* self, wxTreeItemId* parent, const wxString* text, int image, int selImage, wxTreeItemData* data)
{
   if (self && parent && text)
	   return WXNET_NEW( wxTreeItemId, (self->AppendItem(*parent, *text, image, selImage, data)));
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTreeCtrl_AssignImageList(wxTreeCtrl* self, wxImageList* imageList)
{
    self->AssignImageList(imageList);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTreeCtrl_AssignStateImageList(wxTreeCtrl* self, wxImageList* imageList)
{
    self->AssignStateImageList(imageList);
}

//-----------------------------------------------------------------------------

/*extern "C" WXEXPORT
void wxTreeCtrl_AssignButtonsImageList(wxTreeCtrl* self, wxImageList* imageList)
{
    self->AssignButtonsImageList(imageList);
}*/

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxTreeCtrl_Create(wxTreeCtrl* self, wxWindow* parent, int id, const wxPoint* pos,
                       const wxSize* size, unsigned int style, const wxValidator* val,
                       const wxString* nameArg)
{
	if (pos == NULL)
		pos = &wxDefaultPosition;

	if (size == NULL)
		size = &wxDefaultSize;

   wxString name;
	if (nameArg == NULL)
		name = wxT("treectrl");
   else
      name=*nameArg;

    if (val == NULL)
        val = &wxDefaultValidator;

    if (self)
      return self->Create(parent, id, *pos, *size, style, *val, name)?1:0;
    else
       return false;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxTreeCtrl_GetDefaultStyle()
{
    // This value depends on the current platform. Rather than expose the
    // platform dependencies in wx.NET, I'll just hide it in here.

    return wxTR_DEFAULT_STYLE;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(unsigned int)
   wxTreeCtrl_GetIndent(wxTreeCtrl* self)
{
	return self->GetIndent();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTreeCtrl_SetIndent(wxTreeCtrl* self, unsigned int indent)
{
	self->SetIndent(indent);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(unsigned int)
   wxTreeCtrl_GetSpacing(wxTreeCtrl* self)
{
	return self->GetSpacing();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTreeCtrl_SetSpacing(wxTreeCtrl* self, unsigned int indent)
{
	self->SetSpacing(indent);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxImageList*)
  wxTreeCtrl_GetStateImageList(wxTreeCtrl* self)
{
    return self->GetStateImageList();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTreeCtrl_SetStateImageList(wxTreeCtrl* self, wxImageList* imageList)
{
    self->SetStateImageList(imageList);
}

//-----------------------------------------------------------------------------

/*extern "C" WXEXPORT
wxImageList* wxTreeCtrl_GetButtonsImageList(wxTreeCtrl* self)
{
    return self->GetButtonsImageList();
}*/

//-----------------------------------------------------------------------------

/*extern "C" WXEXPORT
void wxTreeCtrl_SetButtonsImageList(wxTreeCtrl* self, wxImageList* imageList)
{
    self->SetButtonsImageList(imageList);
}*/

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxImageList*)
  wxTreeCtrl_GetImageList(wxTreeCtrl* self)
{
    return self->GetImageList();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTreeCtrl_SetImageList(wxTreeCtrl* self, wxImageList* imageList)
{
    self->SetImageList(imageList);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTreeCtrl_SetItemImage(wxTreeCtrl* self, wxTreeItemId* item, int image, wxTreeItemIcon which)
{
    self->SetItemImage(*item, image, which);
}
//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxTreeCtrl_GetItemImage(wxTreeCtrl* self, wxTreeItemId* item, wxTreeItemIcon which)
{
    return self->GetItemImage(*item, which);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTreeCtrl_DeleteAllItems(wxTreeCtrl* self)
{
    self->DeleteAllItems();
}

WXNET_EXPORT(void)
  wxTreeCtrl_DeleteChildren(wxTreeCtrl* self, wxTreeItemId* item)
{
    self->DeleteChildren(*item);
}

WXNET_EXPORT(void)
  wxTreeCtrl_Delete(wxTreeCtrl* self, wxTreeItemId* item)
{
    self->Delete(*item);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTreeCtrl_Unselect(wxTreeCtrl* self)
{
    self->Unselect();
}

WXNET_EXPORT(void)
  wxTreeCtrl_UnselectAll(wxTreeCtrl* self)
{
    self->UnselectAll();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTreeCtrl_SelectItem(wxTreeCtrl* self, wxTreeItemId* item)
{
    self->SelectItem(*item);
}

WXNET_EXPORT(wxTreeItemId*)
  wxTreeCtrl_GetSelection(wxTreeCtrl* self)
{
      return WXNET_NEW( wxTreeItemId, (self->GetSelection()));
}

WXNET_EXPORT(bool)
  wxTreeCtrl_IsSelected(wxTreeCtrl* self, wxTreeItemId* item)
{
    return self->IsSelected(*item)?1:0;
}

WXNET_EXPORT(wxArrayTreeItemIds*)
  wxTreeCtrl_GetSelections(wxTreeCtrl* self)
{
      wxArrayTreeItemIds *array = WXNET_NEW( wxArrayTreeItemIds, ());
      self->GetSelections(*array);
      return array;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTreeCtrl_SetItemText(wxTreeCtrl* self, wxTreeItemId* item, const wxString* text)
{
   if (self && text)
    self->SetItemText(*item, *text);
}

WXNET_EXPORT(wxString*)
  wxTreeCtrl_GetItemText(wxTreeCtrl* self, wxTreeItemId* item)
{
  if (item && self)
      return WXNET_NEW( wxString, (self->GetItemText(*item)));
  return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTreeCtrl_SetItemData(wxTreeCtrl* self, wxTreeItemId* item, wxTreeItemData* data)
{
  if (self && item)
    self->SetItemData(*item, data);
}

WXNET_EXPORT(wxTreeItemData*)
  wxTreeCtrl_GetItemData(wxTreeCtrl* self, wxTreeItemId* item)
{
  if (self && item)
    return self->GetItemData(*item);
  return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTreeCtrl_SetItemHasChildren(wxTreeCtrl* self, wxTreeItemId* item, bool has)
{
  if (self && item)
    self->SetItemHasChildren(*item, has);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxTreeItemId*)
  wxTreeCtrl_HitTest(wxTreeCtrl* self, wxPoint* pt, int* flags)
{
      return WXNET_NEW( wxTreeItemId, (self->HitTest(*pt, *flags)));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxTreeItemId*)
  wxTreeCtrl_GetItemParent(wxTreeCtrl* self, wxTreeItemId* item)
{
      return WXNET_NEW( wxTreeItemId, (self->GetItemParent(*item)));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void*)
  wxTreeCtrl_GetMyCookie(_TreeCtrl* self)
{
      return self->my_cookie;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTreeCtrl_SetMyCookie(_TreeCtrl* self, void* newval)
{
      self->my_cookie = newval;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxTreeItemId*)
  wxTreeCtrl_GetFirstChild(_TreeCtrl* self, wxTreeItemId* item)
{
      self->my_cookie = 0;
      return WXNET_NEW( wxTreeItemId, (self->GetFirstChild(*item, self->my_cookie)));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxTreeItemId*)
  wxTreeCtrl_GetNextChild(_TreeCtrl* self, wxTreeItemId* item)
{
      return WXNET_NEW( wxTreeItemId, (self->GetNextChild(*item, self->my_cookie)));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxTreeItemId*)
  wxTreeCtrl_GetLastChild(wxTreeCtrl* self, wxTreeItemId* item)
{
      return WXNET_NEW( wxTreeItemId, (self->GetLastChild(*item)));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxTreeItemId*)
  wxTreeCtrl_GetNextSibling(wxTreeCtrl* self, wxTreeItemId* item)
{
      return WXNET_NEW( wxTreeItemId, (self->GetNextSibling(*item)));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxTreeItemId*)
  wxTreeCtrl_GetPrevSibling(wxTreeCtrl* self, wxTreeItemId* item)
{
      return WXNET_NEW( wxTreeItemId, (self->GetPrevSibling(*item)));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxTreeItemId*)
  wxTreeCtrl_GetFirstVisibleItem(wxTreeCtrl* self)
{
      return WXNET_NEW( wxTreeItemId, (self->GetFirstVisibleItem()));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxTreeItemId*)
  wxTreeCtrl_GetNextVisible(wxTreeCtrl* self, wxTreeItemId* item)
{
      return WXNET_NEW( wxTreeItemId, (self->GetNextVisible(*item)));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxTreeItemId*)
  wxTreeCtrl_GetPrevVisible(wxTreeCtrl* self, wxTreeItemId* item)
{
      return WXNET_NEW( wxTreeItemId, (self->GetPrevVisible(*item)));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxTreeItemId*)
  wxTreeCtrl_PrependItem(wxTreeCtrl* self, wxTreeItemId* parent, const wxString* text, int image, int selectedImage, wxTreeItemData* data)
{
   if (self && text)
         return WXNET_NEW( wxTreeItemId, (self->PrependItem(*parent, *text, image, selectedImage, data)));
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxTreeItemId*)
  wxTreeCtrl_InsertItem(wxTreeCtrl* self, wxTreeItemId* parent, wxTreeItemId* idPrevious, const wxString* text, int image, int selectedImage, wxTreeItemData* data)
{
   if (self && text && parent)
         return WXNET_NEW( wxTreeItemId, (self->InsertItem(*parent, *idPrevious, *text, image, selectedImage, data)));
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxTreeItemId*)
  wxTreeCtrl_InsertItem2(wxTreeCtrl* self, wxTreeItemId* parent, size_t before, const wxString* text, int image, int selectedImage, wxTreeItemData* data)
{
   if (self && text && parent)
         return WXNET_NEW( wxTreeItemId, (self->InsertItem(*parent, before, *text, image, selectedImage, data)));
   else 
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTreeCtrl_Expand(wxTreeCtrl* self, wxTreeItemId* item)
{
    self->Expand(*item);
}

WXNET_EXPORT(void)
  wxTreeCtrl_Collapse(wxTreeCtrl* self, wxTreeItemId* item)
{
    self->Collapse(*item);
}

WXNET_EXPORT(void)
  wxTreeCtrl_CollapseAndReset(wxTreeCtrl* self, wxTreeItemId* item)
{
    self->CollapseAndReset(*item);
}

WXNET_EXPORT(void)
  wxTreeCtrl_Toggle(wxTreeCtrl* self, wxTreeItemId* item)
{
    self->Toggle(*item);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTreeCtrl_EnsureVisible(wxTreeCtrl* self, wxTreeItemId* item)
{
    self->EnsureVisible(*item);
}

WXNET_EXPORT(void)
  wxTreeCtrl_ScrollTo(wxTreeCtrl* self, wxTreeItemId* item)
{
    self->ScrollTo(*item);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxTreeCtrl_GetChildrenCount(wxTreeCtrl* self, wxTreeItemId* item, bool recursively)
{
    return self->GetChildrenCount(*item, recursively);
}

WXNET_EXPORT(int)
  wxTreeCtrl_GetCount(wxTreeCtrl* self)
{
    return self->GetCount();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxTreeCtrl_IsVisible(wxTreeCtrl* self, wxTreeItemId* item)
{
    return self->IsVisible(*item)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxTreeCtrl_ItemHasChildren(wxTreeCtrl* self, wxTreeItemId* item)
{
    return self->ItemHasChildren(*item)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxTreeCtrl_IsExpanded(wxTreeCtrl* self, wxTreeItemId* item)
{
    return self->IsExpanded(*item)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxTreeItemId*)
  wxTreeCtrl_GetRootItem(wxTreeCtrl* self)
{
   return WXNET_NEW( wxTreeItemId, (self->GetRootItem()));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxColour*)
  wxTreeCtrl_GetItemTextColour(wxTreeCtrl* self, wxTreeItemId* item)
{
   return WXNET_NEW( wxColour, (self->GetItemTextColour(*item)));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxColour*)
  wxTreeCtrl_GetItemBackgroundColour(wxTreeCtrl* self, wxTreeItemId* item)
{
   return WXNET_NEW( wxColour, (self->GetItemBackgroundColour(*item)));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxFont*)
  wxTreeCtrl_GetItemFont(wxTreeCtrl* self, wxTreeItemId* item)
{
   return WXNET_NEW( wxFont, (self->GetItemFont(*item)));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTreeCtrl_SetItemBold(wxTreeCtrl* self, wxTreeItemId* item, bool bold)
{
	self->SetItemBold(*item, bold);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTreeCtrl_SetItemTextColour(wxTreeCtrl* self, wxTreeItemId* item, wxColour* col)
{
	self->SetItemTextColour(*item, *col);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTreeCtrl_SetItemBackgroundColour(wxTreeCtrl* self, wxTreeItemId* item, wxColour* col)
{
	self->SetItemBackgroundColour(*item, *col);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTreeCtrl_SetItemFont(wxTreeCtrl* self, wxTreeItemId* item, wxFont* font)
{
	self->SetItemFont(*item, *font);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTreeCtrl_EditLabel(wxTreeCtrl* self, wxTreeItemId* item)
{
	self->EditLabel(*item);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxTreeCtrl_GetBoundingRect(wxTreeCtrl* self, wxTreeItemId* item, wxRect* rect, bool textOnly)
{
	return self->GetBoundingRect(*item, *rect, textOnly);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxTreeCtrl_IsBold(wxTreeCtrl* self, wxTreeItemId* item)
{
	return self->IsBold(*item)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTreeCtrl_SetItemSelectedImage(wxTreeCtrl* self, wxTreeItemId* item, int selImage)
{
    self->SetItemImage(*item, wxTreeItemIcon_Selected);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTreeCtrl_ToggleItemSelection(wxTreeCtrl* self, wxTreeItemId* item)
{
	self->ToggleItemSelection(*item);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTreeCtrl_UnselectItem(wxTreeCtrl* self, wxTreeItemId* item)
{
	self->UnselectItem(*item);
}

//-----------------------------------------------------------------------------
// wxTreeItemId

class _TreeItemId : public wxTreeItemId
{
public:
	_TreeItemId()
		: wxTreeItemId() {}
		
	_TreeItemId(void* pItem)
		: wxTreeItemId(pItem) {}

	DECLARE_DISPOSABLE(_TreeItemId)
};

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxTreeItemId*)
  wxTreeItemId_ctor()
{
   return WXNET_NEW( _TreeItemId, ());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxTreeItemId*)
  wxTreeItemId_ctor2(void* pItem)
{
   return WXNET_NEW( _TreeItemId, (pItem));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTreeItemId_dtor(wxTreeItemId* self)
{
   WXNET_DEL(self);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTreeItemId_RegisterDisposable(_TreeItemId* self, Virtual_Dispose onDispose)
{
   self->RegisterDispose(onDispose);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxTreeItemId_Equal(wxTreeItemId* item1, wxTreeItemId* item2)
{
   if (item1==item2)
      return true;
   else if (!item1 || !item2)
      return false;
   return *item1 == *item2;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxTreeItemId_IsOk(wxTreeItemId* self)
{
   return self->IsOk();
}

WXNET_EXPORT(size_t)
  wxTreeItemId_AsLong(wxTreeItemId* self)
{
   if (self)
      return (size_t) self->m_pItem;
   else
      return 0;
}

//-----------------------------------------------------------------------------
// wxTreeEvent

WXNET_EXPORT(wxTreeEvent*)
  wxTreeEvent_ctor(wxEventType commandType, int id)
{
   return WXNET_NEW( wxTreeEvent, (commandType, id));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxTreeItemId*)
  wxTreeEvent_GetItem(wxTreeEvent* self)
{
   return WXNET_NEW( wxTreeItemId, (self->GetItem()));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTreeEvent_SetItem(wxTreeEvent* self, wxTreeItemId* item)
{
    self->SetItem(*item);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxTreeItemId*)
  wxTreeEvent_GetOldItem(wxTreeEvent* self)
{
   return WXNET_NEW( wxTreeItemId, (self->GetOldItem()));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTreeEvent_SetOldItem(wxTreeEvent* self, wxTreeItemId* item)
{
    self->SetOldItem(*item);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTreeEvent_GetPoint(wxTreeEvent* self, wxPoint* pt)
{
    *pt = self->GetPoint();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTreeEvent_SetPoint(wxTreeEvent* self, wxPoint* pt)
{
    self->SetPoint(*pt);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(const wxKeyEvent*)
   wxTreeEvent_GetKeyEvent(wxTreeEvent* self)
{
    return &(self->GetKeyEvent());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxTreeEvent_GetKeyCode(wxTreeEvent* self)
{
    return self->GetKeyCode();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTreeEvent_SetKeyEvent(wxTreeEvent* self, wxKeyEvent* evt)
{
    self->SetKeyEvent(*evt);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxTreeEvent_GetLabel(wxTreeEvent* self)
{
   return WXNET_NEW( wxString, (self->GetLabel()));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTreeEvent_SetLabel(wxTreeEvent* self, const wxString* label)
{
   if (self && label)
    self->SetLabel(*label);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxTreeEvent_IsEditCancelled(wxTreeEvent* self)
{
    return self->IsEditCancelled()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTreeEvent_SetEditCanceled(wxTreeEvent* self, bool editCancelled)
{
    self->SetEditCanceled(editCancelled);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
   wxTreeEvent_Veto( wxTreeEvent* self)
{
    self->Veto();
}

WXNET_EXPORT(void)
   wxTreeEvent_Allow( wxTreeEvent* self)
{
    self->Allow();
}

WXNET_EXPORT(bool)
   wxTreeEvent_IsAllowed( wxTreeEvent* self)
{
    return self->IsAllowed()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTreeEvent_SetToolTip(wxTreeEvent* self, const wxString* toolTip)
{
   if (self && toolTip)
	   self->SetToolTip(*toolTip);
}

//-----------------------------------------------------------------------------
// wxTreeItemData

class _TreeItemData : public wxTreeItemData
{
public:
	_TreeItemData()
		: wxTreeItemData() {}

	DECLARE_DISPOSABLE(_TreeItemData)
};

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxTreeItemData*)
  wxTreeItemData_ctor()
{
   return WXNET_NEW( _TreeItemData, ());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTreeItemData_dtor(wxTreeItemData* self)
{
   WXNET_DEL(self);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTreeItemData_RegisterDisposable(_TreeItemData* self, Virtual_Dispose onDispose)
{
	self->RegisterDispose(onDispose);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxTreeItemId*)
  wxTreeItemData_GetId(wxTreeItemData* self)
{
   return WXNET_NEW( wxTreeItemId, (self->GetId()));
}

WXNET_EXPORT(void)
  wxTreeItemData_SetId(wxTreeItemData* self, wxTreeItemId* param)
{
    self->SetId(*param);
}

//-----------------------------------------------------------------------------
// wxTreeItemAttr

class _TreeItemAttr : public wxTreeItemAttr
{
public:
	_TreeItemAttr()
		: wxTreeItemAttr() {}
		
	_TreeItemAttr(const wxColour& colText, const wxColour& colBack, const wxFont& font)
		: wxTreeItemAttr(colText, colBack, font) {}

	DECLARE_DISPOSABLE(_TreeItemAttr)
};

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxTreeItemAttr*)
  wxTreeItemAttr_ctor()
{
   return WXNET_NEW( _TreeItemAttr, ());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxTreeItemAttr*)
  wxTreeItemAttr_ctor2(wxColour* colText, wxColour* colBack, wxFont* font)
{
	return WXNET_NEW(_TreeItemAttr, (*colText, *colBack, *font));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTreeItemAttr_dtor(wxTreeItemAttr* self)
{
	WXNET_DEL(self);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTreeItemAttr_RegisterDisposable(_TreeItemAttr* self, Virtual_Dispose onDispose)
{
	self->RegisterDispose(onDispose);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTreeItemAttr_SetTextColour(wxTreeItemAttr* self, wxColour* colText)
{
	self->SetTextColour(*colText);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTreeItemAttr_SetBackgroundColour(wxTreeItemAttr* self, wxColour* colBack)
{
	self->SetBackgroundColour(*colBack);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTreeItemAttr_SetFont(wxTreeItemAttr* self, wxFont* font)
{
	self->SetFont(*font);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxTreeItemAttr_HasTextColour(wxTreeItemAttr* self)
{
	return self->HasTextColour()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxTreeItemAttr_HasBackgroundColour(wxTreeItemAttr* self)
{
	return self->HasBackgroundColour()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxTreeItemAttr_HasFont(wxTreeItemAttr* self)
{
	return self->HasFont()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxColour*)
  wxTreeItemAttr_GetTextColour(wxTreeItemAttr* self)
{
   return WXNET_NEW( wxColour, (self->GetTextColour()));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxColour*)
  wxTreeItemAttr_GetBackgroundColour(wxTreeItemAttr* self)
{
   return WXNET_NEW( wxColour, (self->GetBackgroundColour()));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxFont*)
  wxTreeItemAttr_GetFont(wxTreeItemAttr* self)
{
   return WXNET_NEW( wxFont, (self->GetFont()));
}

//-----------------------------------------------------------------------------
// wxArrayTreeItemIds

class _ArrayTreeItemIds : public wxArrayTreeItemIds
{
public:
	_ArrayTreeItemIds()
		: wxArrayTreeItemIds() {}
		
	DECLARE_DISPOSABLE(_ArrayTreeItemIds)
};

WXNET_EXPORT(wxArrayTreeItemIds*)
  wxArrayTreeItemIds_ctor()
{
	return WXNET_NEW(_ArrayTreeItemIds, ());
}

WXNET_EXPORT(void)
  wxArrayTreeItemIds_dtor(wxArrayTreeItemIds* self)
{
	WXNET_DEL(self);
}

WXNET_EXPORT(void)
  wxArrayTreeItemIds_RegisterDisposable(_ArrayTreeItemIds* self, Virtual_Dispose onDispose)
{
	self->RegisterDispose(onDispose);
}

WXNET_EXPORT(void)
  wxArrayTreeItemIds_Add(wxArrayTreeItemIds* self, wxTreeItemId* toadd)
{
	self->Add(toadd);
}

WXNET_EXPORT(wxTreeItemId*)
  wxArrayTreeItemIds_Item(wxArrayTreeItemIds* self, size_t num)
{
	return WXNET_NEW( wxTreeItemId, (self->Item(num)));
}

WXNET_EXPORT(int)
  wxArrayTreeItemIds_GetCount(wxArrayTreeItemIds* self)
{
	return self->GetCount();
}

