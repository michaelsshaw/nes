//-----------------------------------------------------------------------------
// wx.NET - filesys.cxx
// 
// The wx streams and file system proxy interface.
//
// Written by Harald Meyer auf'm Hofe
// (C) 2006 by Harald Meyer auf'm Hofe (harald_meyer@sf.net)
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: filesys.cxx,v 1.12 2010/06/06 08:53:52 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/stream.h>
#include <wx/filesys.h>
#include <wx/fs_zip.h>
#include <wx/fs_mem.h>
#include <wx/fs_inet.h>

#include "local_events.h"

/*****************************************************************
  class wxInputStream
 *****************************************************************/

/* Callbacks for wxInputStream */
typedef void (CALLBACK* Virtual_InputStream_OnDispose) (void);
typedef int (CALLBACK* Virtual_InputStream_CanRead) (void);
typedef size_t (CALLBACK* Virtual_InputStream_LastRead) ();
typedef size_t (CALLBACK* Virtual_InputStream_Read) (ByteBuffer* buffer);
typedef int (CALLBACK* Virtual_InputStream_CanRead) (void);
typedef int (CALLBACK* Virtual_InputStream_CanSeek) (void);
typedef long (CALLBACK* Virtual_InputStream_Seek) (long, int);
typedef long (CALLBACK* Virtual_InputStream_Tell) (void);
typedef long (CALLBACK* Virtual_InputStream_GetLength) (void);

//#include <iostream>

class wxInputStreamWrapper : public wxInputStream
{
private:
    Virtual_InputStream_OnDispose onDispose;
    Virtual_InputStream_LastRead lastRead;
    Virtual_InputStream_Read     sysRead;
    Virtual_InputStream_CanRead  canRead;
    Virtual_InputStream_CanSeek  canSeek;
    Virtual_InputStream_Seek     seek;
    // assumes -1 to be the invalid offset.
    Virtual_InputStream_Tell     tell;
    Virtual_InputStream_GetLength getLength;

public:
    wxInputStreamWrapper()
        : onDispose(0),
          lastRead(0),
          sysRead(0),
          canRead(0),
          canSeek(0),
          seek(0),
          tell(0),
          getLength(0)
    {
    }
    virtual ~wxInputStreamWrapper()
    {
       if (onDispose) onDispose();
    }

    void RegisterVirtual(Virtual_InputStream_OnDispose onDispose,
                         Virtual_InputStream_LastRead  lastRead,
                         Virtual_InputStream_Read      sysRead,
                         Virtual_InputStream_CanRead   canRead,
                         Virtual_InputStream_CanSeek   canSeek,
                         Virtual_InputStream_Seek      seek,
                         Virtual_InputStream_Tell      tell,
                         Virtual_InputStream_GetLength getLength)
    {
        this->onDispose=onDispose;
        this->lastRead=lastRead;
        this->sysRead=sysRead;
        this->canRead=canRead;
        this->canSeek=canSeek;
        this->seek=seek;
        this->tell=tell;
        this->getLength=getLength;
    }

    void UnregisterVirtual()
    {
        this->onDispose=0;
        this->lastRead=0;
        this->sysRead=0;
        this->canRead=0;
        this->canSeek=0;
        this->seek=0;
        this->tell=0;
        this->getLength=0;
    }

    virtual bool CanRead() const
    {
       if (this->canRead != 0)
          return this->canRead()!=0;
       else
          return false;
    }

    virtual wxFileOffset SeekI(wxFileOffset pos, wxSeekMode mode = wxFromStart)
    {
        if (this->canSeek && this->seek && this->canSeek())
            // in the hope that System.IO.SeekOrigin remains to b ethe same as wxSeekMode
            return this->seek(pos, mode);
        else
            return wxInvalidOffset;
    }
    virtual wxFileOffset TellI() const
    {
        if (this->tell)
            return this->tell();
        else
            return wxInvalidOffset;
    }

    virtual wxFileOffset GetLength() const
    {
       if (this->getLength)
          return this->getLength();
       else
          return wxInvalidOffset;
    }

protected:
    // do read up to size bytes of data into the provided buffer
    //
    // this method should return 0 if EOF has been reached or an error occurred
    // (m_lasterror should be set accordingly as well) or the number of bytes
    // read
    virtual size_t OnSysRead(void* buffer, size_t size)
    {
       //std::cout << "OnSysRead(" << size << ")" << std::endl;
       size_t result= ReadBuffer((unsigned char*) buffer, size);
       //std::cout << " read " << result << " bytes";
       //if (size==result) //std::cout << " OK!!" <<std::endl;
       //else //std::cout << " Failure!!!" << std::endl;
       return result;
    }

    size_t ReadBuffer(unsigned char* buffer, size_t size)
    {
        if (this->sysRead)
        {
           //std::cout << "Want to read buffer size " << size << " into " << (size_t)buffer << std::endl;
           ByteBuffer byteBuffer;
           #if defined(__WXMSW__) && defined(_DEBUG) && defined(WXNET_LOG_MEM)
           wxnetLogLocal(&byteBuffer, __FILE__, __LINE__);
           #endif
           byteBuffer._buffer=buffer;
           byteBuffer._sizeReserved=size;
           //std::cout << "Generated " << byteBuffer << ", trying to call " << (size_t) this->sysRead << std::endl;
           byteBuffer._sizeFilled=this->sysRead(&byteBuffer);
           byteBuffer._buffer=NULL;
           //std::cout << " Received " << byteBuffer._sizeFilled << std::endl;
           return byteBuffer._sizeFilled;
        }
        else
            return 0;
    }
};


WXNET_EXPORT(wxInputStreamWrapper*)
  wxInputStreamWrapper_ctor(void){
    return WXNET_NEW( wxInputStreamWrapper, () );
}


WXNET_EXPORT(void)
  wxInputStreamWrapper_dtor(wxInputStream* self){
    WXNET_DEL(self);
}


WXNET_EXPORT(void)
  wxInputStreamWrapper_RegisterVirtual                        (wxInputStream* self,
                         Virtual_InputStream_OnDispose onDispose,
                         Virtual_InputStream_LastRead lastRead,
                         Virtual_InputStream_Read     sysRead,
                         Virtual_InputStream_CanRead  canRead,
                         Virtual_InputStream_CanSeek  canSeek,
                         Virtual_InputStream_Seek     seek,
                         Virtual_InputStream_Tell     tell,
                         Virtual_InputStream_GetLength getLength)
{
    if (self)
    {
        WXNET_LOG_DEREF(self)
        dynamic_cast< wxInputStreamWrapper* >(self)->
            RegisterVirtual(onDispose, lastRead, sysRead, canRead, canSeek, seek, tell, getLength);
    }
}


WXNET_EXPORT(void)
  wxInputStreamWrapper_UnregisterVirtual                        (wxInputStream* self)
{
    if (self)
    {
      WXNET_LOG_DEREF(self)
      dynamic_cast< wxInputStreamWrapper* >(self)->UnregisterVirtual();
    }
}


WXNET_EXPORT(char)
  wxInputStreamWrapper_Peek(wxInputStream* self){
    if (self)
    {
      WXNET_LOG_DEREF(self)
      return self->Peek();
    }
    else
        return 0;
}


WXNET_EXPORT(char)
  wxInputStreamWrapper_GetC(wxInputStream* self){
    if (self)
    {
      WXNET_LOG_DEREF(self)
      return self->GetC();
    }
    else
        return 0;
}


WXNET_EXPORT(void)
  wxInputStreamWrapper_ReadIntoBuffer(wxInputStream* self, ByteBuffer* buffer){
    if (self && buffer)
    {
       WXNET_LOG_DEREF(self)
       WXNET_LOG_DEREF(buffer)
       self->Read(buffer->_buffer, buffer->_sizeReserved);
       buffer->_sizeFilled=self->LastRead();
    }
}


WXNET_EXPORT(void)
  wxInputStreamWrapper_ReadIntoStream(wxInputStream* self, wxOutputStream* streamOut){
    if (self && streamOut)
    {
        WXNET_LOG_DEREF(self)
        WXNET_LOG_DEREF(streamOut)
        self->Read(*streamOut);
    }
}


WXNET_EXPORT(size_t)
  wxInputStreamWrapper_LastRead(const wxInputStream* self){
    if (self)
    {
        WXNET_LOG_DEREF(self)
        return self->LastRead();
    }
    else
        return 0;
}


WXNET_EXPORT(char)
  wxInputStreamWrapper_CanRead(const wxInputStream* self){
    if (self)
    {
        WXNET_LOG_DEREF(self)
        return self->CanRead();
    }
    else
        return false;
}


WXNET_EXPORT(char)
  wxInputStreamWrapper_Eof(const wxInputStream* self){
    if (self)
    {
        WXNET_LOG_DEREF(self)
        return self->Eof();
    }
    else
        return true;
}


WXNET_EXPORT(size_t)
  wxInputStreamWrapper_UngetBuffer(wxInputStream* self, const void *buffer, size_t size){
    if (self)
    {
        WXNET_LOG_DEREF(self)
        return self->Ungetch(buffer, size);
    }
    else
        return 0;
}


WXNET_EXPORT(char)
  wxInputStreamWrapper_Ungetch(wxInputStream* self, char c){
    if (self)
    {
        WXNET_LOG_DEREF(self)
        return self->Ungetch(c);
    }
    else
        return false;
}


WXNET_EXPORT(wxFileOffset)
  wxInputStreamWrapper_SeekI(wxInputStream* self, wxFileOffset pos, wxSeekMode mode){
    if (self)
    {
        WXNET_LOG_DEREF(self)
        return self->SeekI(pos, mode);
    }
    else
        return wxInvalidOffset;
}


WXNET_EXPORT(wxFileOffset)
  wxInputStreamWrapper_TellI(const wxInputStream* self){
    if (self)
    {
        WXNET_LOG_DEREF(self)
        return self->TellI();
    }
    else
        return wxInvalidOffset;
}


/*****************************************************************
  class wxFSFile
 *****************************************************************/

class _wxFSFile : public wxFSFile
{
public:
   typedef void (CALLBACK* OnDisposeCallback)();
   OnDisposeCallback onDisposeCallback;
   _wxFSFile(wxInputStream* aWxInputStream,
             const wxString& location, const wxString& mimetype,
             const wxString& anchor,
             const wxDateTime& modificationTime)
             : wxFSFile(aWxInputStream, location, mimetype, anchor, modificationTime),
               onDisposeCallback(NULL)
   {
   }

   virtual ~_wxFSFile()
   {
      if (onDisposeCallback)
         onDisposeCallback();
   }
};



WXNET_EXPORT(wxFSFile*)
  wxFSFile_ctor(wxInputStream* aWxInputStream,                                            const wxString* location, const wxString* mimetype,
                                            const wxString* anchor,
                                            const wxDateTime* modificationTime)
{
   if (aWxInputStream && location && mimetype && anchor && modificationTime)
   {
      WXNET_LOG_DEREF(aWxInputStream) 
      WXNET_LOG_DEREFSTR(location) 
      WXNET_LOG_DEREFSTR(mimetype) 
      WXNET_LOG_DEREFSTR(anchor) 
      WXNET_LOG_DEREFDATETIME(modificationTime) 
      return WXNET_NEW( _wxFSFile, (aWxInputStream, *location, *mimetype, *anchor, *modificationTime) );
   }
   else
      return 0;
}


WXNET_EXPORT(void)
  wxFSFile_SetDisposeCallback(wxFSFile* self, _wxFSFile::OnDisposeCallback onDisposeCallback){
   if (self)
   {
      WXNET_LOG_DEREF(self) 
      _wxFSFile* selfCasted=dynamic_cast< _wxFSFile* >(self);
      if (selfCasted)
      {
         selfCasted->onDisposeCallback=onDisposeCallback;
      }
   }
}


WXNET_EXPORT(void)
  wxFSFile_UnsetDisposeCallback(wxFSFile* self){
   if (self)
   {
      WXNET_LOG_DEREF(self) 
      _wxFSFile* selfCasted=dynamic_cast< _wxFSFile* >(self);
      if (selfCasted)
      {
         selfCasted->onDisposeCallback=NULL;
      }
   }
}
                                            


WXNET_EXPORT(void)
  wxFSFile_dtor(wxFSFile* self){
   WXNET_DEL(self);
}


WXNET_EXPORT(wxString*)
  wxFSFile_GetAnchor(const wxFSFile* self){
    if (self)
    {
       WXNET_LOG_DEREF(self) 
       return WXNET_NEW( wxString, (self->GetAnchor()) );
    }
    else
        return 0;
}


WXNET_EXPORT(wxString*)
  wxFSFile_GetLocation(const wxFSFile* self){
    if (self)
    {
        WXNET_LOG_DEREF(self) 
        return WXNET_NEW( wxString, (self->GetLocation()) );
    }
    else
        return 0;
}


WXNET_EXPORT(wxString*)
  wxFSFile_GetMimeType(const wxFSFile* self){
    if (self)
    {
        WXNET_LOG_DEREF(self) 
        return WXNET_NEW( wxString, (self->GetMimeType()) );
    }
    else
        return 0;
}


WXNET_EXPORT(wxDateTime*)
  wxFSFile_GetModificationTime(const wxFSFile* self){
    if (self)
    {
        WXNET_LOG_DEREF(self) 
        return WXNET_NEW( wxDateTime, (self->GetModificationTime()) );
    }
    else
        return 0;
}


WXNET_EXPORT(wxInputStream*)
  wxFSFile_GetStream(const wxFSFile* self){
    if (self)
    {
        WXNET_LOG_DEREF(self) 
        return self->GetStream();
    }
    else
        return 0;
}

/*****************************************************************
  class wxFileSystemHandler
 *****************************************************************/

// This is simply a hack to make some functions publically available.
class wxFileSystemHandlerWrapper : public wxFileSystemHandler
{
public:
    wxFileSystemHandlerWrapper() {}
    wxString GetAnchor(const wxString& location) const
    { return wxFileSystemHandler::GetAnchor(location); }
    wxString GetProtocol(const wxString& location) const
    { return wxFileSystemHandler::GetProtocol(location); }
    wxString GetLeftLocation(const wxString& location) const
    { return wxFileSystemHandler::GetLeftLocation(location); }
    wxString GetRightLocation(const wxString& location) const
    { return wxFileSystemHandler::GetRightLocation(location); }
    wxString GetMimeTypeFromExt(const wxString& location)
    { return wxFileSystemHandler::GetMimeTypeFromExt(location); }
    
};


WXNET_EXPORT(char)
  wxFileSystemHandler_CanOpen(wxFileSystemHandler* self, const wxString* location){
   if (self && location)
   {
      WXNET_LOG_DEREF(self) 
      WXNET_LOG_DEREFSTR(location) 
      return self->CanOpen(*location);
   }
   else
      return false;
}


WXNET_EXPORT(wxString*)
  wxFileSystemHandler_FindFirst(wxFileSystemHandler* self, const wxString* wildcard, int kindOfFile){
   if (self && wildcard)
   {
      WXNET_LOG_DEREF(self) 
      WXNET_LOG_DEREFSTR(wildcard) 
      return WXNET_NEW( wxString, (self->FindFirst(*wildcard, kindOfFile)) );
   }
   else
      return NULL;
}


WXNET_EXPORT(wxString*)
  wxFileSystemHandler_FindNext(wxFileSystemHandler* self){
   if (self)
   {
      WXNET_LOG_DEREF(self) 
      return WXNET_NEW( wxString, (self->FindNext()) );
   }
   else
      return NULL;
}


WXNET_EXPORT(wxString*)
  wxFileSystemHandler_GetAnchor(const wxFileSystemHandler* self, const wxString* location){
   if (self && location)
   {
      WXNET_LOG_DEREF(self) 
      WXNET_LOG_DEREFSTR(location) 
      const wxFileSystemHandlerWrapper* fsw=dynamic_cast<const wxFileSystemHandlerWrapper*>(self);
      if (fsw)
         return WXNET_NEW( wxString, (fsw->GetAnchor(*location)) );
      else
         return NULL;
   }
   else
      return NULL;
}


WXNET_EXPORT(wxString*)
  wxFileSystemHandler_GetProtocol(const wxFileSystemHandler* self, const wxString* location){
   if (self && location)
   {
      WXNET_LOG_DEREF(self) 
      WXNET_LOG_DEREFSTR(location) 
      const wxFileSystemHandlerWrapper* fsw=dynamic_cast<const wxFileSystemHandlerWrapper*>(self);
      if (fsw)
         return WXNET_NEW( wxString, (fsw->GetProtocol(*location)) );
      else
         return NULL;
   }
   else
      return NULL;
}


WXNET_EXPORT(wxString*)
  wxFileSystemHandler_GetLeftLocation(const wxFileSystemHandler* self, const wxString* location){
   if (self && location)
   {
      WXNET_LOG_DEREF(self) 
      WXNET_LOG_DEREFSTR(location) 
      const wxFileSystemHandlerWrapper* fsw=dynamic_cast<const wxFileSystemHandlerWrapper*>(self);
      if (fsw)
         return WXNET_NEW( wxString, (fsw->GetLeftLocation(*location)) );
      else
         return NULL;
   }
   else
      return NULL;
}

WXNET_EXPORT(wxString*)
  wxFileSystemHandler_GetRightLocation(const wxFileSystemHandler* self, const wxString* location){
   if (self && location)
   {
      WXNET_LOG_DEREF(self) 
      WXNET_LOG_DEREFSTR(location) 
      const wxFileSystemHandlerWrapper* fsw=dynamic_cast<const wxFileSystemHandlerWrapper*>(self);
      if (fsw)
         return WXNET_NEW( wxString, (fsw->GetRightLocation(*location)) );
      else
         return NULL;
   }
   else
       return NULL;
}

WXNET_EXPORT(wxString*)
  wxFileSystemHandler_GetMimeTypeFromExt(wxFileSystemHandler* self, const wxString* location){
   if (self && location)
   {
      WXNET_LOG_DEREF(self) 
      WXNET_LOG_DEREFSTR(location) 
      wxFileSystemHandlerWrapper* fsw=dynamic_cast<wxFileSystemHandlerWrapper*>(self);
      if (fsw)
         return WXNET_NEW( wxString, (fsw->GetMimeTypeFromExt(*location)) );
      else
         return NULL;
   }
   else
      return NULL;
}


/*****************************************************************
  class wxFileSystem
 *****************************************************************/


WXNET_EXPORT(wxFileSystem*)
  wxFileSystem_ctor(void){
   return WXNET_NEW( wxFileSystem, () );
}


WXNET_EXPORT(void)
  wxFileSystem_AddHandler(wxFileSystemHandler* fileSystemHandler){
   WXNET_LOG_DEREF(fileSystemHandler) 
   wxFileSystem::AddHandler(fileSystemHandler);
}


WXNET_EXPORT(void)
  wxFileSystem_CleanUpHandlers(void){
   wxFileSystem::CleanUpHandlers();
}


WXNET_EXPORT(void)
  wxFileSystem_ChangePathTo(wxFileSystem* self, const wxString* location, char is_dir){
   if (self && location)
   {
      WXNET_LOG_DEREF(self) 
      WXNET_LOG_DEREFSTR(location) 
      self->ChangePathTo(*location, is_dir!=0);
   }
}


WXNET_EXPORT(wxString*)
  wxFileSystem_GetPath(const wxFileSystem* self){
    if (self)
    {
        WXNET_LOG_DEREF(self) 
        return WXNET_NEW( wxString, (self->GetPath()) );
    }
    else
        return 0;
}


WXNET_EXPORT(wxString*)
  wxFileSystem_FindFirst(wxFileSystem* self, const wxString* wildcard, int kindOfFile){
   if (self && wildcard)
   {
      WXNET_LOG_DEREF(self) 
      WXNET_LOG_DEREFSTR(wildcard) 
      return WXNET_NEW( wxString, (self->FindFirst(*wildcard, kindOfFile)) );
   }
   else
      return NULL;
}


WXNET_EXPORT(wxString*)
  wxFileSystem_FindNext(wxFileSystem* self){
   if (self)
   {
      WXNET_LOG_DEREF(self) 
      return WXNET_NEW( wxString, (self->FindNext()) );
   }
   else
      return NULL;
}


WXNET_EXPORT(wxFSFile*)
  wxFileSystem_OpenFile(wxFileSystem* self, const wxString* location){
   if (self && location)
   {
      WXNET_LOG_DEREF(self) 
      WXNET_LOG_DEREFSTR(location) 
      return self->OpenFile(*location);
   }
   else
      return NULL;
}

/*****************************************************************
  class wxZipFSHandler
 *****************************************************************/


WXNET_EXPORT(wxZipFSHandler*)
  wxZipFSHandler_ctor(void){
   return WXNET_NEW( wxZipFSHandler, () );
}


WXNET_EXPORT(wxFSFile*)
  wxZipFSHandler_OpenFile(wxZipFSHandler* self, wxFileSystem* fs, const wxString* location){
   if (self && fs && location)
   {
      WXNET_LOG_DEREF(self) 
      WXNET_LOG_DEREF(fs) 
      WXNET_LOG_DEREFSTR(location) 
      return self->OpenFile(*fs, *location);
   }
   else
      return NULL;
}

/*****************************************************************
  class wxInternetFSHandler
 *****************************************************************/


WXNET_EXPORT(wxInternetFSHandler*)
  wxInternetFSHandler_ctor(void){
   return WXNET_NEW( wxInternetFSHandler, () );
}


WXNET_EXPORT(wxFSFile*)
  wxInternetFSHandler_OpenFile(wxInternetFSHandler* self, wxFileSystem* fs, const wxString* location){
   if (self && fs && location)
   {
      WXNET_LOG_DEREF(self) 
      WXNET_LOG_DEREF(fs) 
      WXNET_LOG_DEREFSTR(location) 
      return self->OpenFile(*fs, *location);
   }
   else
      return NULL;
}

/*****************************************************************
  class wxMemoryFSHandler
 *****************************************************************/


WXNET_EXPORT(wxMemoryFSHandler*)
  wxMemoryFSHandler_ctor(void){
   return WXNET_NEW( wxMemoryFSHandler, () );
}


WXNET_EXPORT(wxFSFile*)
  wxMemoryFSHandler_OpenFile(wxMemoryFSHandler* self, wxFileSystem* fs, const wxString* location){
   if (self && fs && location)
   {
      WXNET_LOG_DEREF(self) 
      WXNET_LOG_DEREF(fs) 
      WXNET_LOG_DEREFSTR(location) 
      return self->OpenFile(*fs, *location);
   }
   else
      return NULL;
}


WXNET_EXPORT(void)
  wxMemoryFSHandler_AddImage(const wxString* filename, const wxImage* image, int type){
   if (image && filename)
   {
      WXNET_LOG_DEREFSTR(filename) 
      WXNET_LOG_DEREF(image) 
      wxMemoryFSHandler::AddFile(*filename, *image, type);
   }
}

WXNET_EXPORT(void)
  wxMemoryFSHandler_AddBitmap(const wxString* filename, const wxBitmap* image, int type){
   if (image && filename)
   {
      WXNET_LOG_DEREF(image) 
      WXNET_LOG_DEREFSTR(filename) 
      wxMemoryFSHandler::AddFile(*filename, *image, type);
   }
}

WXNET_EXPORT(void)
  wxMemoryFSHandler_AddText(const wxString* filename, const wxString* text){
   if (text && filename)
   {
      WXNET_LOG_DEREFSTR(text) 
      WXNET_LOG_DEREFSTR(filename) 
      wxMemoryFSHandler::AddFile(*filename, *text);
   }
}

WXNET_EXPORT(void)
  wxMemoryFSHandler_AddBinaryData(const wxString* filename, const void* data, size_t size){
   if (data && filename)
   {
      WXNET_LOG_DEREF(data) 
      WXNET_LOG_DEREFSTR(filename) 
      wxMemoryFSHandler::AddFile(*filename, data, size);
   }
}

WXNET_EXPORT(void)
  wxMemoryFSHandler_RemoveFile(const wxString* filename){
   if (filename)
   {
      WXNET_LOG_DEREFSTR(filename) 
      wxMemoryFSHandler::RemoveFile(*filename);
   }
}

/*****************************************************************
  class DotNetFileSystemHandler
 *****************************************************************/

/* Callbacks for wxInputStream */
typedef char (CALLBACK* Virtual_FileSystemHandler_CanOpen) (const wxString*);
typedef wxFSFile* (CALLBACK* Virtual_FileSystemHandler_OpenFile) (wxFileSystem*, const wxString*);
typedef wxString* (CALLBACK* Virtual_FileSystemHandler_FindFirst) (const wxString*, int);
typedef wxString* (CALLBACK* Virtual_FileSystemHandler_FindNext) ();

class DotNetFileSystemHandler : public wxFileSystemHandlerWrapper
{
    public:
    Virtual_FileSystemHandler_CanOpen fnCanOpen;
    Virtual_FileSystemHandler_OpenFile fnOpenFile;
    Virtual_FileSystemHandler_FindFirst fnFindFirst;
    Virtual_FileSystemHandler_FindNext fnFindNext;
    Virtual_Dispose fnVirtualDispose;
    DotNetFileSystemHandler()
      : fnCanOpen(0), fnOpenFile(0), fnFindFirst(0), fnFindNext(0), fnVirtualDispose(0)
    {
    }

    virtual ~DotNetFileSystemHandler()
    {
       if (this->fnVirtualDispose) this->fnVirtualDispose();
    }

    virtual bool CanOpen(const wxString& location)
    {
        if (fnCanOpen)
            return fnCanOpen(&location)!=0;
        else
            return false;
    }
    
    virtual wxFSFile* OpenFile(wxFileSystem& fs, const wxString& location)
    {
        if (fnOpenFile)
        {
            wxFSFile* result = fnOpenFile(&fs, &location);
            return result;
        }
        else
            return NULL;
    }
    
    virtual wxString FindFirst(const wxString& wildcard, int flags = 0)
    {
        if (fnFindFirst)
            return *fnFindFirst(&wildcard, flags);
        else
            return wxT("");
    }

    virtual wxString FindNext()
    {
        if (fnFindNext)
            return *fnFindNext();
        else
            return wxT("");
    }
};



WXNET_EXPORT(DotNetFileSystemHandler*)
  dotNetFileSystemHandler_ctor(void){
   return WXNET_NEW(DotNetFileSystemHandler, ());
}


WXNET_EXPORT(void)
  dotNetFileSystemHandler_RegisterVirtual(DotNetFileSystemHandler* self,                                                                 Virtual_Dispose fnVirtualDispose,
                                                                 Virtual_FileSystemHandler_CanOpen fnCanOpen,
                                                                 Virtual_FileSystemHandler_OpenFile fnOpenFile,
                                                                 Virtual_FileSystemHandler_FindFirst fnFindFirst,
                                                                 Virtual_FileSystemHandler_FindNext fnFindNext)
{
   if (self)
   {
      WXNET_LOG_DEREF(self) 
      self->fnVirtualDispose=fnVirtualDispose;
      self->fnCanOpen=fnCanOpen;
      self->fnOpenFile=fnOpenFile;
      self->fnFindNext=fnFindNext;
      self->fnFindFirst=fnFindFirst;
   }
}


WXNET_EXPORT(void)
  dotNetFileSystemHandler_UnregisterVirtual(DotNetFileSystemHandler* self){
   if (self)
   {
      WXNET_LOG_DEREF(self) 
      self->fnVirtualDispose=NULL;
      self->fnCanOpen=NULL;
      self->fnOpenFile=NULL;
      self->fnFindNext=NULL;
      self->fnFindFirst=NULL;
   }
}
