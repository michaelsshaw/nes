//-----------------------------------------------------------------------------
// wx.NET - archive.cxx
// 
// The wxArchive proxy interface.
//
// Written by Harald Meyer auf'm Hofe
// (C) 2006 by Harald Meyer auf'm Hofe (harald_meyer@sf.net)
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: archive.cxx,v 1.7 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/archive.h>
#include <wx/zipstrm.h>
#include <wx/wfstream.h>
#include "local_events.h"

WXNET_EXPORT(void)
  wxArchiveEntry_SetDatetime(wxArchiveEntry* self, const wxDateTime* dateTime)
{
    if (self && dateTime)
        self->SetDateTime(*dateTime);
}

WXNET_EXPORT(wxDateTime*)
  wxArchiveEntry_GetDatetime(const wxArchiveEntry* self)
{
    if (self)
    {
       WXNET_LOG_DEREF(self)
       return WXNET_NEW( wxDateTime, (self->GetDateTime()) );
    }
    else
        return 0;
}

WXNET_EXPORT(wxString*)
  wxArchiveEntry_GetInternalName(const wxArchiveEntry* self)
{
    if (self)
    {
       WXNET_LOG_DEREF(self)
       return WXNET_NEW( wxString, (self->GetInternalName()) );
    }
    else
        return 0;
}

WXNET_EXPORT(wxString*)
  wxArchiveEntry_GetName(const wxArchiveEntry* self)
{
    if (self)
    {
       WXNET_LOG_DEREF(self)
       return WXNET_NEW( wxString, (self->GetName()) );
    }
    else
        return 0;
}

WXNET_EXPORT(void)
  wxArchiveEntry_SetName(wxArchiveEntry* self, const wxString* name)
{
    if (self && name)
    {
       WXNET_LOG_DEREF(self)
       self->SetName(*name);
    }
}

WXNET_EXPORT(char)
  wxArchiveEntry_IsDir(const wxArchiveEntry* self)
{
    if (self)
    {
        WXNET_LOG_DEREF(self)
        return self->IsDir();
    }
    else
        return 0;
}

WXNET_EXPORT(void)
  wxArchiveEntry_SetIsDir(wxArchiveEntry* self, char value)
{
    if (self)
    {
       WXNET_LOG_DEREF(self)
       self->SetIsDir(value!=0);
    }
}

WXNET_EXPORT(char)
  wxArchiveEntry_IsReadOnly(const wxArchiveEntry* self)
{
    if (self)
    {
       WXNET_LOG_DEREF(self)
       return self->IsReadOnly();
    }
    else
        return 0;
}

WXNET_EXPORT(void)
  wxArchiveEntry_SetIsReadOnly(wxArchiveEntry* self, char value)
{
    if (self)
    {
       WXNET_LOG_DEREF(self)
       self->SetIsReadOnly(value!=0);
    }
}

WXNET_EXPORT(int)
  wxArchiveEntry_Offset(const wxArchiveEntry* self)
{
    if (self)
    {
       WXNET_LOG_DEREF(self)
       return self->GetOffset();
    }
    else
        return 0;
}

WXNET_EXPORT(int)
  wxArchiveEntry_GetSize(const wxArchiveEntry* self)
{
    if (self)
    {
       WXNET_LOG_DEREF(self)
       return self->GetSize();
    }
    else
        return 0;
}

WXNET_EXPORT(void)
  wxArchiveEntry_SetSize(wxArchiveEntry* self, int size)
{
    if (self)
    {
       WXNET_LOG_DEREF(self)
       self->SetSize(size);
    }
}

struct wxArchiveOutputStreamPair
{
    wxOutputStream*        m_outputStream;
    wxArchiveOutputStream* m_archiveStream;
    int                    m_type;
    wxArchiveOutputStreamPair(int type);
    ~wxArchiveOutputStreamPair();
};

wxArchiveOutputStreamPair::wxArchiveOutputStreamPair(int type)
  : m_outputStream(0), m_archiveStream(0), m_type(type)
{
}

wxArchiveOutputStreamPair::~wxArchiveOutputStreamPair()
{
    WXNET_DEL(m_outputStream);
    WXNET_DEL(m_archiveStream);
}



WXNET_EXPORT(size_t)
  wxArchiveOutputStream_Write(wxArchiveOutputStreamPair* self, const char* buffer, size_t offset, size_t count)
{
    if (self && self->m_archiveStream && buffer)
    {
        WXNET_LOG_DEREF(self)
        WXNET_LOG_DEREF(self->m_archiveStream)
        buffer+=offset;
        self->m_archiveStream->Write(buffer, count);
        return self->m_archiveStream->LastWrite();
    }
    return 0;
}

WXNET_EXPORT(void)
  wxArchiveOutputStream_WriteByte(wxArchiveOutputStreamPair* self, char value)
{
    if (self && self->m_archiveStream)
    {
        WXNET_LOG_DEREF(self)
        WXNET_LOG_DEREF(self->m_archiveStream)
        self->m_archiveStream->PutC(value);
    }
}

WXNET_EXPORT(void)
  wxArchiveOutputStream_CloseEntry(wxArchiveOutputStreamPair* self)
{
    if (self && self->m_archiveStream)
    {
        WXNET_LOG_DEREF(self)
        WXNET_LOG_DEREF(self->m_archiveStream)
        self->m_archiveStream->CloseEntry();
    }
}

WXNET_EXPORT(wxArchiveOutputStreamPair*)
  wxArchiveOutputStream_CTor(const wxString* filename, int type)
{
    wxArchiveOutputStreamPair* result=WXNET_NEW( wxArchiveOutputStreamPair, (type) );
    result->m_outputStream=WXNET_NEW( wxFFileOutputStream, (*filename) );
    result->m_archiveStream=WXNET_NEW( wxZipOutputStream, (*result->m_outputStream) );
    return result;
}

WXNET_EXPORT(char)
  wxArchiveOutputStream_PutNextEntryNow(wxArchiveOutputStreamPair* self, const wxString* name)
{
    if (self && self->m_archiveStream)
    {
        WXNET_LOG_DEREF(self)
        WXNET_LOG_DEREF(self->m_archiveStream)
        return self->m_archiveStream->PutNextEntry(*name);
    }
    else return 0;
}

WXNET_EXPORT(char)
  wxArchiveOutputStream_PutNextEntry(wxArchiveOutputStreamPair* self, const wxString* name, const wxDateTime* dateTime)
{
    if (self && self->m_archiveStream && name)
    {
        WXNET_LOG_DEREF(self)
        WXNET_LOG_DEREF(self->m_archiveStream)
        WXNET_LOG_DEREFSTR(name)
        WXNET_LOG_DEREFDATETIME(dateTime)
        if (dateTime)
            return self->m_archiveStream->PutNextEntry(*name, *dateTime);
        else
            return self->m_archiveStream->PutNextEntry(*name);
    }
    else return 0;
}

WXNET_EXPORT(char)
  wxArchiveOutputStream_PutNextDirEntryNow(wxArchiveOutputStreamPair* self, const wxString* name)
{
    if (self && self->m_archiveStream && name)
    {
        WXNET_LOG_DEREF(self)
        WXNET_LOG_DEREF(self->m_archiveStream)
        WXNET_LOG_DEREF(name)
        return self->m_archiveStream->PutNextDirEntry(*name);
    }
    else return 0;
}

WXNET_EXPORT(char)
  wxArchiveOutputStream_PutNextDirEntry(wxArchiveOutputStreamPair* self, const wxString* name, const wxDateTime* dateTime)
{
    if (self && self->m_archiveStream)
    {
        WXNET_LOG_DEREF(self)
        WXNET_LOG_DEREF(self->m_archiveStream)
        WXNET_LOG_DEREFSTR(name)
        WXNET_LOG_DEREFDATETIME(dateTime)
        if (dateTime)
            return self->m_archiveStream->PutNextDirEntry(*name, *dateTime);
        else
            return self->m_archiveStream->PutNextDirEntry(*name);
    }
    else return 0;
}


WXNET_EXPORT(char)
  wxArchiveOutputStream_Close(wxArchiveOutputStreamPair* self)
{
    if (self) 
    {
        WXNET_LOG_DEREF(self)
        WXNET_LOG_DEREF(self->m_archiveStream)
        char result1=0;
        if (self->m_archiveStream)
            result1= self->m_archiveStream->Close();
        char result2=0;
        if (self->m_outputStream)
            result2= self->m_outputStream->Close();
        return result1&&result2;
    }
    else return 0;
}

WXNET_EXPORT(int)
  wxArchiveOutputStream_GetType(wxArchiveOutputStreamPair* self)
{
    if (self) 
    {
        WXNET_LOG_DEREF(self)
        WXNET_LOG_DEREF(self->m_archiveStream)
        return self->m_type;
    }
    else return -1;
}

WXNET_EXPORT(char)
  wxArchiveOutputStream_IsOk(wxArchiveOutputStreamPair* self)
{
    if (self) 
    {
        WXNET_LOG_DEREF(self)
        WXNET_LOG_DEREF(self->m_archiveStream)
        return self->m_archiveStream->IsOk() && self->m_outputStream->IsOk();;
    }
    else return 0;
}


WXNET_EXPORT(char)
  wxArchiveOutput_CopyEntry(wxArchiveOutputStreamPair* self, const wxArchiveEntry* entry, wxArchiveInputStream* input)
{
    if (self && self->m_archiveStream && entry && input)
    {
        WXNET_LOG_DEREF(self)
        WXNET_LOG_DEREF(self->m_archiveStream)
        WXNET_LOG_DEREF(entry)
        WXNET_LOG_DEREF(input)
        return self->m_archiveStream->CopyEntry(entry->Clone(), *input);
    }
    else return 0;
}

WXNET_EXPORT(char)
  wxArchiveOutput_CopyArchiveMetaData(wxArchiveOutputStreamPair* self, wxArchiveInputStream* input)
{
    if (self && self->m_archiveStream && input)
    {
        WXNET_LOG_DEREF(self)
        WXNET_LOG_DEREF(self->m_archiveStream)
        WXNET_LOG_DEREF(input)
        return self->m_archiveStream->CopyArchiveMetaData(*input);
    }
    else return 0;
}

struct wxArchiveInputStreamPair
{
    wxInputStream*        m_inputStream;
    wxArchiveInputStream* m_archiveStream;
    int                   m_type;
    wxArchiveInputStreamPair(int type);
    ~wxArchiveInputStreamPair();
};

wxArchiveInputStreamPair::wxArchiveInputStreamPair(int type)
  : m_inputStream(0), m_archiveStream(0), m_type(type)
{
}

wxArchiveInputStreamPair::~wxArchiveInputStreamPair()
{
    WXNET_DEL(m_inputStream);
    WXNET_DEL(m_archiveStream);
}

WXNET_EXPORT(wxArchiveInputStreamPair*)
  wxArchiveInputStream_CTor(const wxString* filename, int type)
{
    wxArchiveInputStreamPair* result=WXNET_NEW( wxArchiveInputStreamPair, (type) );
    result->m_inputStream=WXNET_NEW( wxFFileInputStream, (*filename) );
    result->m_archiveStream=WXNET_NEW( wxZipInputStream, (*result->m_inputStream) );
    return result;
}

// be careful. this will take ownership of the provided input stream. it will be
// deallocated with the instance resulting from this call.
WXNET_EXPORT(wxArchiveInputStreamPair*)
  wxArchiveInputStream_CTorFromStream(wxInputStream* inputStream, int type)
{
    wxArchiveInputStreamPair* result=WXNET_NEW( wxArchiveInputStreamPair, (type) );
    result->m_inputStream=inputStream;
    result->m_archiveStream=WXNET_NEW( wxZipInputStream, (*result->m_inputStream) );
    return result;
}

WXNET_EXPORT(void)
  wxArchiveInputStream_CloseEntry(wxArchiveInputStreamPair* self)
{
    if (self && self->m_archiveStream)
    {
        WXNET_LOG_DEREF(self)
        WXNET_LOG_DEREF(self->m_archiveStream)
        self->m_archiveStream->CloseEntry();
    }
}

WXNET_EXPORT(char)
  wxArchiveInputStream_OpenEntry(wxArchiveInputStreamPair* self, wxArchiveEntry* entry)
{
    if (self && self->m_archiveStream)
    {
        WXNET_LOG_DEREF(self)
        WXNET_LOG_DEREF(self->m_archiveStream)
        WXNET_LOG_DEREF(entry)
        return self->m_archiveStream->OpenEntry(*entry);
    }
    return 0;
}

WXNET_EXPORT(wxArchiveEntry*)
  wxArchiveInputStream_GetNextEntry(wxArchiveInputStreamPair* self)
{
    if (self && self->m_archiveStream)
    {
        WXNET_LOG_DEREF(self)
        WXNET_LOG_DEREF(self->m_archiveStream)
        return self->m_archiveStream->GetNextEntry();
    }
    return 0;
}

WXNET_EXPORT(size_t)
  wxArchiveInputStream_GetSize(const wxArchiveInputStreamPair* self)
{
   if (self && self->m_archiveStream)
   {
        WXNET_LOG_DEREF(self)
        WXNET_LOG_DEREF(self->m_archiveStream)
      return self->m_archiveStream->GetSize();
   }
   return 0;
}

WXNET_EXPORT(char)
  wxArchiveInputStream_IsSeekable(const wxArchiveInputStreamPair* self)
{
   if (self && self->m_archiveStream)
   {
        WXNET_LOG_DEREF(self)
        WXNET_LOG_DEREF(self->m_archiveStream)
      return self->m_archiveStream->IsSeekable();
   }
   return 0;
}

WXNET_EXPORT(char)
  wxArchiveInputStream_Seek(const wxArchiveInputStreamPair* self, int pos, wxSeekMode mode)
{
   if (self && self->m_archiveStream)
   {
        WXNET_LOG_DEREF(self)
        WXNET_LOG_DEREF(self->m_archiveStream)
      return self->m_archiveStream->SeekI(pos, mode);
   }
   return -1;
}

WXNET_EXPORT(size_t)
  wxArchiveInputStream_Tell(const wxArchiveInputStreamPair* self)
{
   if (self && self->m_archiveStream)
   {
        WXNET_LOG_DEREF(self)
        WXNET_LOG_DEREF(self->m_archiveStream)
      return self->m_archiveStream->TellI();
   }
   return 0;
}

WXNET_EXPORT(size_t)
  wxArchiveInputStream_Read(wxArchiveInputStreamPair* self, char* buffer, size_t offset, size_t count)
{
    if (self && self->m_archiveStream && buffer)
    {
        WXNET_LOG_DEREF(self)
        WXNET_LOG_DEREF(self->m_archiveStream)
        self->m_archiveStream->Read(buffer+offset, count);
        return self->m_archiveStream->LastRead();
    }
    return 0;
}

WXNET_EXPORT(int)
  wxArchiveInputStream_ReadChar(wxArchiveInputStreamPair* self)
{
    if (self && self->m_archiveStream)
    {
        WXNET_LOG_DEREF(self)
        WXNET_LOG_DEREF(self->m_archiveStream)
        return self->m_archiveStream->GetC();
    }
    else
        return -1;
}

WXNET_EXPORT(int)
  wxArchiveInputStream_GetType(wxArchiveInputStreamPair* self)
{
    if (self) 
    {
        WXNET_LOG_DEREF(self)
        return self->m_type;
    }
    else return -1;
}

WXNET_EXPORT(char)
  wxArchiveInputStream_IsOk(wxArchiveInputStreamPair* self)
{
    if (self) 
    {
        WXNET_LOG_DEREF(self)
        WXNET_LOG_DEREF(self->m_archiveStream)
        return self->m_archiveStream->IsOk() && self->m_inputStream->IsOk();;
    }
    else return 0;
}

WXNET_EXPORT(wxString*)
  wxArchiveEntry_ConvertIntoInternalName(wxArchiveInputStreamPair* self, const wxString* localFilename)
{
    if (self && localFilename)
    {
        WXNET_LOG_DEREF(self)
        WXNET_LOG_DEREFSTR(localFilename)
        // on extending with more archive types: switch by self->m_type
        return WXNET_NEW( wxString, (wxZipEntry::GetInternalName(*localFilename)) );
    }
    else
        return 0;
}

