//-----------------------------------------------------------------------------
// wx.NET - closeevent.cxx
// 
// The wxCloseEvent proxy interface.
//
// Written by Alexander Olk (xenomorph2@onlinehome.de)
// (C) 2004 by Alexander Olk
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// closeevent.cxx,v 1.5 2008/12/25 17:01:35 harald_meyer Exp
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#ifndef WXNET_GLOBAL_H
#include "wxnet_globals.h"
#endif

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxCloseEvent*)
  wxCloseEvent_ctor(wxEventType type)
{
    return new wxCloseEvent(type);
}

WXNET_EXPORT(void)
  wxCloseEvent_SetLoggingOff(wxCloseEvent* self, bool logOff)
{
	self->SetLoggingOff(logOff);
}

WXNET_EXPORT(char)
  wxCloseEvent_GetLoggingOff(wxCloseEvent* self)
{
	return self->GetLoggingOff()?1:0;
}

WXNET_EXPORT(void)
  wxCloseEvent_Veto(wxCloseEvent* self, bool veto)
{
	self->Veto(veto);
}

WXNET_EXPORT(void)
  wxCloseEvent_SetCanVeto(wxCloseEvent* self, bool canVeto)
{
	self->SetCanVeto(canVeto);
}

WXNET_EXPORT(char)
  wxCloseEvent_CanVeto(wxCloseEvent* self)
{
	return self->CanVeto()?1:0;
}

WXNET_EXPORT(char)
  wxCloseEvent_GetVeto(wxCloseEvent* self)
{
	return self->GetVeto()?1:0;
}


