//-----------------------------------------------------------------------------
// wx.NET - events.h
//
// Defines custom events required by wx.NET.
//
// Written by Jason Perkins (jason@379.com)
// (C) 2003 by 379, Inc.
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: local_events.h,v 1.15 2010/06/05 11:52:17 harald_meyer Exp $
//-----------------------------------------------------------------------------

#ifndef WX_C_LOCAL_EVENTS_H
#define WX_C_LOCAL_EVENTS_H

#ifndef WXNET_GLOBAL_H
#include "wxnet_globals.h"
#endif

// I use this class to route virtual functions originating from within
// wxWidgets to the .NET framework. The framework will catch the event,
// and then trigger the appropriate function on that side of the wall.

class FunctionEvent : public wxEvent
{
public:
	FunctionEvent(wxEventType type)
		: wxEvent(0, type)
	{ }

	virtual wxEvent* Clone() const
	{
		return new FunctionEvent(this->GetEventType());
	}
};


// Custom event types for all mapped virtual functions

DECLARE_EVENT_TYPE(wxEVT_APPINIT, 0)
DECLARE_EVENT_TYPE(wxEVT_TRANSFERDATAFROMWINDOW, 0)
DECLARE_EVENT_TYPE(wxEVT_TRANSFERDATATOWINDOW, 0)
DECLARE_EVENT_TYPE(wxEVT_OBJECTDELETED, 0)

// Short-cut for virtual destructors

// Creates sends an event when an object is deleted, so that it 
// can be handled elsewhere.

#define DECLARE_OBJECTDELETED(name) \
    virtual ~name() \
    { \
        FunctionEvent e(wxEVT_OBJECTDELETED); \
        ProcessEvent(e); \
    }

// Calls a delegate when an object is deleted internally.

typedef void (CALLBACK* OverloadedAction)(void);

// overload focus
#define DECLARE_SETFOCUS_OVERRIDING(wxWidgetsClass) \
   OverloadedAction _cbSetFocus;\
   OverloadedAction _cbSetFocusFromKbd;\
   void SetFocusVirtuals(OverloadedAction cbSetFocus, OverloadedAction cbSetFocusFromKbd)\
   {\
      _cbSetFocus=cbSetFocus;\
      _cbSetFocusFromKbd=cbSetFocusFromKbd;\
   }\
   virtual void SetFocus()\
   {\
       if (_cbSetFocus)\
          _cbSetFocus();\
       else\
          wxWidgetsClass ::SetFocus();\
   }\
   virtual void SetFocusFromKbd()\
   {\
       if (_cbSetFocusFromKbd)\
          _cbSetFocusFromKbd();\
       else\
          this->SetFocus();\
   }

#define IMPLEMENT_SETFOCUS_OVERRIDING(wrapperClass, wxWidgetsClass) \
 extern "C" WXNET_EXPORT(void)\
  wxWidgetsClass##_SetFocus(wxWidgetsClass* self)\
 { if (self)\
   self-> wxWidgetsClass ::SetFocus();\
 }\
 extern "C" WXNET_EXPORT(void)\
  wxWidgetsClass##_SetFocusFromKbd(wxWidgetsClass* self)\
 { if (self)\
   self-> wxWidgetsClass ::SetFocus();\
 }\
 extern "C" WXNET_EXPORT(void)\
  wxWidgetsClass##_SetFocusVirtuals(wxWidgetsClass* self, OverloadedAction cbSetFocus, OverloadedAction cbSetFocusFromKbd)\
 {\
    wrapperClass* dialog=dynamic_cast<wrapperClass*>(self);\
    if (dialog)\
    {\
       dialog->SetFocusVirtuals(cbSetFocus, cbSetFocusFromKbd);\
    }\
 }

typedef void (CALLBACK* Virtual_Dispose)();

// This will be used as callback for functions validating in wxWindow::TransferDataFromWindow.
typedef char (CALLBACK* ValidatorFct)(void);

// This will be used to encapsulate a ValidatorFct to ensure that is's FALSE.
class ValidatorStub
{
   ValidatorFct _fct;
public:
   ValidatorStub(ValidatorFct fct) : _fct(fct) {}
   ValidatorStub() : _fct(NULL) {}
   virtual ~ValidatorStub(){}

   void Set(ValidatorFct fct) { _fct=fct; }

   bool RunValidatorFct()
   {
      if (_fct)
         return _fct()!=0;
      else
         return true;
   }
};


// HMaH: Added public modifier. This will call <m_onDispose> only if this is not NULL.
// Please do not forget to set <m_onDispose> to NULL in the constructors. Otherwise,
// destruction of the instances will cause access violations on destruction of the
// wx.NET implementation does not register callbacks.
#define DECLARE_DISPOSABLE(name) \
   public:\
    Virtual_Dispose m_onDispose;\
    void RegisterDispose(Virtual_Dispose onDispose) { m_onDispose = onDispose; } \
    virtual ~name() { if (m_onDispose) m_onDispose(); }


// HMaH: Use this class for returning string from virtual functions in C#
// Unfortunately, wxString cannot be made disposable directly since one cannot subclass
// it. So, we have to box a string instance which have to be disposable that means that
// wrappers will loose their wxObject if this is destroyed. It is safe to use this
// class for all strings which are passed to the wx-c.dll but very inconvenient.
// The implementation is in <wxstring.cxx>.
class _DisposableStringBox
{
    wxString* m_val;
public:
    static const wxString empty;
    Virtual_Dispose m_onDispose;
    _DisposableStringBox(wxString* val) : m_val(val), m_onDispose(0) {}
    void RegisterDispose(Virtual_Dispose onDispose) { m_onDispose = onDispose; }
    virtual ~_DisposableStringBox() { if (m_onDispose) m_onDispose(); WXNET_DEL(m_val); }
    const wxString& Val() const 
    {
       if (m_val)
          return *m_val;
       else
          return empty;
    }
    wxString* Ptr() const { return m_val; }

    //! This is a helper to be used when receiving strings from callbacks.
    /*! This extracts the result from the box and kills the box (and thus the embedded string)
      * safely.
    */
    static wxString GetValAndDelete(_DisposableStringBox* box)
    {
       if (box)
       {
          wxString result=box->Val();
          WXNET_DEL(box);
          return result;
       }
       else
          return empty;
    }
};
#endif

