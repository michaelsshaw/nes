//-----------------------------------------------------------------------------
// wx.NET - keyevent.cxx
// 
// The wxKeyEvent proxy interface.
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 by Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: keyevent.cxx,v 1.9 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#ifndef WXNET_GLOBAL_H
#include "wxnet_globals.h"
#endif

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxKeyEvent*)
  wxKeyEvent_ctor(wxEventType type)
{
    return new wxKeyEvent(type);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxKeyEvent_ControlDown(wxKeyEvent* self)
{
    return self->ControlDown()?1:0;
}

WXNET_EXPORT(char)
  wxKeyEvent_ShiftDown(wxKeyEvent* self)
{
    return self->ShiftDown()?1:0;
}

WXNET_EXPORT(char)
  wxKeyEvent_AltDown(wxKeyEvent* self)
{
    return self->AltDown()?1:0;
}

WXNET_EXPORT(char)
  wxKeyEvent_MetaDown(wxKeyEvent* self)
{
    return self->MetaDown()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxKeyEvent_GetRawKeyCode(wxKeyEvent* self)
{
    return self->GetRawKeyCode();
}

WXNET_EXPORT(int)
  wxKeyEvent_GetKeyCode(wxKeyEvent* self)
{
    return self->GetKeyCode();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxKeyEvent_GetRawKeyFlags(wxKeyEvent* self)
{
    return self->GetRawKeyFlags();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxKeyEvent_HasModifiers(wxKeyEvent* self)
{
    return self->HasModifiers()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxKeyEvent_GetPosition(wxKeyEvent* self, wxPoint* pt)
{
    *pt = self->GetPosition();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxKeyEvent_GetX(wxKeyEvent* self)
{
    return self->GetX();
}

WXNET_EXPORT(int)
  wxKeyEvent_GetY(wxKeyEvent* self)
{
    return self->GetY();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxKeyEvent_CmdDown(wxKeyEvent* self)
{
	return self->CmdDown()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxKeyEvent_GetUnicodeChar(wxKeyEvent* self)
{
#if wxUSE_UNICODE 
   if (self)
      return self->GetUnicodeKey();
   else
      return 0;
#else
   if (self && self->GetKeyCode() < 128)
      return self->GetKeyCode();
   else
      return 0;
#endif
}