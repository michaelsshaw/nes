//-----------------------------------------------------------------------------
// wx.NET - caret.cxx
//
// The wxCaret proxy interface.
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 by Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: caret.cxx,v 1.8 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/caret.h>
#include "local_events.h"

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxCaret*)
  wxCaret_ctor()
{
	return new wxCaret();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxCaret_dtor(wxCaret* self)
{
	WXNET_DEL(self);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxCaret_Create(wxCaret* self, wxWindow *window, int width, int height)
{
	return self->Create(window, width, height)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxCaret_IsOk(wxCaret* self)
{
	return self->IsOk()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxCaret_IsVisible(wxCaret* self)
{
	return self->IsVisible()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxCaret_GetPosition(wxCaret* self, int *x, int *y)
{
	self->GetPosition(x, y);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxCaret_GetSize(wxCaret* self, int *width, int *height)
{
	self->GetSize(width, height);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxWindow*)
  wxCaret_GetWindow(wxCaret* self)
{
	return self->GetWindow();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxCaret_SetSize(wxCaret* self, int width, int height)
{
	self->SetSize(width, height);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxCaret_Move(wxCaret* self, int x, int y)
{
	self->Move(x, y);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxCaret_Show(wxCaret* self, bool show)
{
	self->Show(show);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxCaret_Hide(wxCaret* self)
{
	self->Hide();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxCaret_GetBlinkTime()
{
	return wxCaret::GetBlinkTime();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxCaret_SetBlinkTime(int milliseconds)
{
	wxCaret::SetBlinkTime(milliseconds);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxCaretSuspend*)
  wxCaretSuspend_ctor(wxWindow *win)
{
	return new wxCaretSuspend(win);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxCaretSuspend_dtor(wxCaretSuspend* self)
{
	WXNET_DEL(self);
}
