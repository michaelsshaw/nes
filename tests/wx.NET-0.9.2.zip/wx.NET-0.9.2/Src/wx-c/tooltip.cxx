//-----------------------------------------------------------------------------
// wx.NET - tooltip.cxx
//
// The wxToolTip proxy interface
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 by Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: tooltip.cxx,v 1.7 2010/06/06 08:53:52 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/tooltip.h>
#include "wxnet_globals.h"

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxToolTip_Enable(bool flag)
{
	wxToolTip::Enable(flag);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxToolTip_SetDelay(unsigned int msecs)
{
	wxToolTip::SetDelay(msecs);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxToolTip*)
  wxToolTip_ctor(const wxString* tip)
{
   if (tip)
	   return new wxToolTip(*tip);
   else
      return new wxToolTip(wxString());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxToolTip_SetTip(wxToolTip* self, const wxString* tip)
{
   if (self && tip)
	   self->SetTip(*tip);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxToolTip_GetTip(wxToolTip* self)
{
	return new wxString(self->GetTip());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxWindow*)
  wxToolTip_GetWindow(wxToolTip* self)
{
	return self->GetWindow();
}

//-----------------------------------------------------------------------------
