//-----------------------------------------------------------------------------
// wx.NET - focusevent.cxx
// 
// The wxFocusEvent proxy interface.
//
// Written by Alexander Olk (xenomorph2@onlinehome.de)
// (C) 2004 by Alexander Olk
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: focusevent.cxx,v 1.3 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#ifndef WXNET_GLOBAL_H
#include "wxnet_globals.h"
#endif

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxFocusEvent*)
  wxFocusEvent_ctor(wxEventType type)
{
    return new wxFocusEvent(type);
}

WXNET_EXPORT(wxWindow*)
  wxFocusEvent_GetWindow(wxFocusEvent* self)
{
	return self->GetWindow();
}

WXNET_EXPORT(void)
  wxFocusEvent_SetWindow(wxFocusEvent* self, wxWindow* win)
{
	self->SetWindow(win);
}
