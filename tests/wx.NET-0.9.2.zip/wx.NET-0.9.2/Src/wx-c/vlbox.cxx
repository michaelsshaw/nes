//-----------------------------------------------------------------------------
// wx.NET - vlbox.cxx
//
// The wxVListBox proxy interface.
//
// Written by Alexander Olk (xenomorph2@onlinehome.de)
// (C) 2004 by Alexander Olk
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: vlbox.cxx,v 1.8 2009/12/12 10:32:01 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/vlbox.h>
#include "local_events.h"

#ifndef CALLBACK
# if defined(_WINDOWS)
#  define CALLBACK __stdcall
# else
#  define CALLBACK
# endif
#endif

//-----------------------------------------------------------------------------

typedef void (CALLBACK* Virtual_voidDcRectSizeT) (wxDC*, wxRect*, size_t);
typedef int (CALLBACK* Virtual_IntInt) (int);

class _VListBox : public wxVListBox
{
public:
	_VListBox(wxWindow* parent, wxWindowID id, const wxPoint& pos,
					const wxSize& size, long style, const wxString& name)
		: wxVListBox(parent, id, pos, size, style, name) { }
		
	void RegisterVirtual(Virtual_voidDcRectSizeT onDrawItem,
		Virtual_IntInt onMeasureItem,
		Virtual_voidDcRectSizeT onDrawSeparator,
		Virtual_voidDcRectSizeT onDrawBackground,
		Virtual_IntInt onGetLineHeight)
		{
			m_OnDrawItem = onDrawItem;
			m_OnMeasureItem = onMeasureItem;
			m_OnDrawSeparator = onDrawSeparator;
			m_OnDrawBackground = onDrawBackground;
			m_OnGetLineHeight = onGetLineHeight;
		}
		
	void POnDrawSeparator(wxDC& dc, wxRect& rect, size_t n)
		{
			wxVListBox::OnDrawSeparator(dc, rect, n);
		}
		
	void POnDrawBackground(wxDC& dc, wxRect& rect, size_t n)
		{
			wxVListBox::OnDrawBackground(dc, rect, n);
		}
		
	wxCoord POnGetLineHeight(int n)
		{
			return wxVListBox::OnGetLineHeight(n); 
		}
		
protected:
	void OnDrawItem( wxDC& dc, const wxRect& rect, size_t n) const
		{ m_OnDrawItem( &dc, new wxRect(rect), n); }	
		
	wxCoord OnMeasureItem( size_t n) const
		{ return m_OnMeasureItem( n); }		
		
	void OnDrawSeparator(wxDC& dc, wxRect& rect, size_t n) const
		{ return m_OnDrawSeparator(&dc, new wxRect(rect), n); }
		
	void OnDrawBackground(wxDC& dc, const wxRect& rect, size_t n) const
		{ return m_OnDrawBackground(&dc, new wxRect(rect), n); }
		
	wxCoord OnGetLineHeight( size_t n) const
		{ return m_OnGetLineHeight(n); }	
				
private:
	Virtual_voidDcRectSizeT m_OnDrawItem;
	Virtual_IntInt m_OnMeasureItem;
	Virtual_voidDcRectSizeT m_OnDrawSeparator;
	Virtual_voidDcRectSizeT m_OnDrawBackground;
	Virtual_IntInt m_OnGetLineHeight;
	
public: 
	DECLARE_OBJECTDELETED(_VListBox)
};

//-----------------------------------------------------------------------------
// C stubs for class methods

WXNET_EXPORT(wxVListBox*)
  wxVListBox_ctor(wxWindow *parent, wxWindowID id, int posX, int posY,
					             int width, int height, unsigned int style, const wxString* nameArg)
{
   wxString name;
	if (nameArg == NULL)
		name = wxT("vlistbox");
   else
      name=*nameArg;

	return new _VListBox(parent, id, wxPoint(posX, posY), wxSize(width, height), style, name);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxVListBox_RegisterVirtual(_VListBox* self, Virtual_voidDcRectSizeT onDrawItem,
		Virtual_IntInt onMeasureItem,
		Virtual_voidDcRectSizeT onDrawSeparator,
		Virtual_voidDcRectSizeT onDrawBackground,
		Virtual_IntInt onGetLineHeight)
{
	self->RegisterVirtual(onDrawItem, onMeasureItem, onDrawSeparator, onDrawBackground, onGetLineHeight);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxVListBox_Create(_VListBox* self, wxWindow *parent, wxWindowID id, int posX, int posY,
					        int width, int height, unsigned int style, const wxString* nameArg)
{
   wxString name;
	if (nameArg == NULL)
		name = wxT("vlistbox");
   else
      name=*nameArg;
			
	return self->Create(parent, id, wxPoint(posX, posY), wxSize(width, height), style, name);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxVListBox_OnDrawSeparator(_VListBox* self, wxDC* dc, wxRect* rect, int n)
{
	self->POnDrawSeparator(*dc, *rect, n);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxVListBox_OnDrawBackground(_VListBox* self, wxDC* dc, wxRect* rect, int n)
{
	self->POnDrawBackground(*dc, *rect, n);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxCoord)
  wxVListBox_OnGetLineHeight(_VListBox* self, int line)
{
	return self->POnGetLineHeight(line);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxVListBox_GetItemCount(_VListBox* self)
{
	return self->GetItemCount();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxVListBox_HasMultipleSelection(_VListBox* self)
{
	return self->HasMultipleSelection()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxVListBox_GetSelection(_VListBox* self)
{
	return self->GetSelection();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxVListBox_IsCurrent(_VListBox* self, int item)
{
	return self->IsCurrent(item)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxVListBox_IsSelected(_VListBox* self, int item)
{
	return self->IsSelected(item)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxVListBox_GetSelectedCount(_VListBox* self)
{
	return self->GetSelectedCount();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxVListBox_GetFirstSelected(_VListBox* self, unsigned long *cookie)
{
	return self->GetFirstSelected(*cookie);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxVListBox_GetNextSelected(_VListBox* self, unsigned long *cookie)
{
	return self->GetNextSelected(*cookie);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxVListBox_GetMargins(_VListBox* self, wxPoint* pt)
{
	*pt = self->GetMargins();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxColour*)
  wxVListBox_GetSelectionBackground(_VListBox* self)
{
	return new wxColour(self->GetSelectionBackground());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxVListBox_SetItemCount(_VListBox* self, int count)
{
	self->SetItemCount(count);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxVListBox_Clear(_VListBox* self)
{
	self->Clear();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxVListBox_SetSelection(_VListBox* self, int selection)
{
	self->SetSelection(selection);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxVListBox_Select(_VListBox* self, int item, bool select)
{
	return self->Select(item, select)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxVListBox_SelectRange(_VListBox* self, int from, int to)
{
	return self->SelectRange(from, to)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxVListBox_Toggle(_VListBox* self, int item)
{
	self->Toggle(item);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxVListBox_SelectAll(_VListBox* self)
{
	return self->SelectAll()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxVListBox_DeselectAll(_VListBox* self)
{
	return self->DeselectAll()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxVListBox_SetMargins(_VListBox* self, const wxPoint* pt)
{
	self->SetMargins(*pt);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxVListBox_SetMargins2(_VListBox* self, int x, int y)
{
	self->SetMargins(x, y);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxVListBox_SetSelectionBackground(_VListBox* self, wxColour* col)
{
	self->SetSelectionBackground(*col);
}
