------------------------------------------------------------------------
-- $Id: premake-funcs.lua,v 1.9 2004/12/13 00:43:21 malenfant Exp $
------------------------------------------------------------------------

--
-- Linker support functions
--

-- Add a wxWidgets contributed library to the necessary build parameters.
function add_contrib_link(contrib_name)
   if (win) then
      add_win_lib("Debug", "wxmsw" .. wx_concat_ver() .. 
         wx_debug_flag .. "_" ..  contrib_name)
      add_win_lib("Release", "wxmsw" .. wx_concat_ver() .. 
         wx_release_flag .. "_" ..  contrib_name)
   else
      add_unix_lib("Debug", wx_debug, contrib_name)
      add_unix_lib("Release", wx_release, contrib_name)
   end
end

-- Add a UN*X library by using the wx-config-helper Perl script
-- to do the grunt work of figuring out whether to use
-- Unicode, Debug|Release, Static|Shared.
function add_unix_lib(build_type, wx_buid, contrib_name)
   command = "../../Build/Common/wx-config-helper " .. 
      wx_buid .. " " .. wxconfig .. " get-link-arg "..
      wx_link_mode() .. " " .. contrib_name;
   tinsert(package.config[build_type].linkoptions, { "$(shell " .. command .. ")" })
end

-- Add a Windows library
function add_win_lib(build_type, full_lib_name)
   tinsert(package.config[build_type].links, { full_lib_name })
end

-- Returns something like 25 for ver 2.5
function wx_concat_ver( )
   return(gsub(WX_VERSION, "%.", ""))
end

-- Returns shared or static depending on how wxWidgets should be
-- linked in
function wx_link_mode()
   if (options["with-shared"]) then
      return "shared"
   else
      return "static"
   end
end

