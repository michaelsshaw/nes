//-----------------------------------------------------------------------------
// wx.NET - boxsizer.cxx
//
// The wxBoxSizer proxy interface.
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: boxsizer.cxx,v 1.9 2009/12/12 10:30:22 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include "local_events.h"

// CALLBACK MAY BE ALREADY DEFINED
#ifndef CALLBACK 
# if defined(_WINDOWS)
#  define CALLBACK __stdcall
# else
#  define CALLBACK
# endif
#endif

typedef void (CALLBACK* Virtual_voidvoid) ();
typedef wxSize* (CALLBACK* Virtual_sizevoid) ();

class _BoxSizer : public wxBoxSizer
{
public:
	_BoxSizer(int orient)
		: wxBoxSizer(orient) {}
		
	void RegisterVirtual(Virtual_voidvoid recalcSizes)
	{
		m_RecalcSizes = recalcSizes;
	}
	
	void RecalcSizes()
	{ m_RecalcSizes(); }
	
   /*
	wxSize CalcMin()
	{ return wxSize(*m_CalcMin()); }
   */
	
private:
	Virtual_voidvoid m_RecalcSizes;
	//Virtual_sizevoid m_CalcMin;
	
public:
	DECLARE_DISPOSABLE(_BoxSizer)
};

WXNET_EXPORT(void)
  wxBoxSizer_RegisterVirtual(_BoxSizer* self, Virtual_voidvoid recalcSizes)
{
	self->RegisterVirtual(recalcSizes);
}

WXNET_EXPORT(wxBoxSizer*)
  wxBoxSizer_ctor(int orient)
{
	return new _BoxSizer(orient);
}

WXNET_EXPORT(void)
  wxBoxSizer_RegisterDisposable(_BoxSizer* self, Virtual_Dispose onDispose)
{
	self->RegisterDispose(onDispose);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxBoxSizer_RecalcSizes(_BoxSizer* self)
{
	self->wxBoxSizer::RecalcSizes();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxBoxSizer_GetOrientation(_BoxSizer* self)
{
	return self->GetOrientation();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxBoxSizer_SetOrientation(_BoxSizer* self, int orient)
{
	self->SetOrientation(orient);
}
