//-----------------------------------------------------------------------------
// wx.NET - checkbox.cxx
//
// The wxCheckBox proxy interface.
//
// Written by Jason Perkins (jason@379.com)
// (C) 2003 by 379, Inc.
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: checkbox.cxx,v 1.14 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include "local_events.h"

//-----------------------------------------------------------------------------

class _CheckBox : public wxCheckBox 
{
public:
    DECLARE_OBJECTDELETED(_CheckBox)
};

//-----------------------------------------------------------------------------
// C stubs for class methods

WXNET_EXPORT(wxCheckBox*)
  wxCheckBox_ctor()
{
    return new _CheckBox();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxCheckBox_Create(wxCheckBox* self, wxWindow* parent, int id,
                       const wxString* labelArg, int posX, int posY,
                       int width, int height, unsigned int style, const wxValidator* val,
                       const wxString* nameArg)
{
    if (val == NULL)
        val = &wxDefaultValidator;
	
    wxString name;
    if (nameArg==NULL)
       name = wxT("checkbox");
    else
       name=*nameArg;
    wxString label;
    if (labelArg != NULL)
       label=*labelArg;
    if (val)
       return self->Create(parent, id, label, wxPoint(posX, posY), wxSize(width, height), style,
                           *val, name)?1:0;
    else
       return false;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxCheckBox_GetValue(wxCheckBox* self)
{
    return self->GetValue()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxCheckBox_SetValue(wxCheckBox* self, bool state)
{
    self->SetValue(state);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxCheckBox_IsChecked(wxCheckBox* self)
{
    return self->IsChecked()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxCheckBoxState)
  wxCheckBox_Get3StateValue(wxCheckBox* self)
{
	return self->Get3StateValue();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxCheckBox_Set3StateValue(wxCheckBox* self, wxCheckBoxState state)
{
	self->Set3StateValue(state);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxCheckBox_Is3State(wxCheckBox* self)
{
	return self->Is3State()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxCheckBox_Is3rdStateAllowedForUser(wxCheckBox* self)
{
	return self->Is3rdStateAllowedForUser()?1:0;
}

