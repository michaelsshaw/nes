//-----------------------------------------------------------------------------
// wx.NET - navigationkeyevent.cxx
// 
// The wxNavigationKeyEvent proxy interface.
//
// Written by Alexander Olk (xenomorph2@onlinehome.de)
// (C) 2004 by Alexander Olk
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: navigationkeyevent.cxx,v 1.4 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#ifndef WXNET_GLOBAL_H
#include "wxnet_globals.h"
#endif

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxNavigationKeyEvent*)
  wxNavigationKeyEvent_ctor()
{
    return new wxNavigationKeyEvent();
}

WXNET_EXPORT(bool)
  wxNavigationKeyEvent_GetDirection(wxNavigationKeyEvent* self)
{
	return self->GetDirection()?1:0;
}

WXNET_EXPORT(void)
  wxNavigationKeyEvent_SetDirection(wxNavigationKeyEvent* self, bool bForward)
{
	self->SetDirection(bForward);
}

WXNET_EXPORT(bool)
  wxNavigationKeyEvent_IsWindowChange(wxNavigationKeyEvent* self)
{
	return self->IsWindowChange()?1:0;
}

WXNET_EXPORT(void)
  wxNavigationKeyEvent_SetWindowChange(wxNavigationKeyEvent* self, bool bIs)
{
	self->SetWindowChange(bIs);
}

WXNET_EXPORT(wxWindow*)
  wxNavigationKeyEvent_GetCurrentFocus(wxNavigationKeyEvent* self)
{
	return self->GetCurrentFocus();
}

WXNET_EXPORT(void)
  wxNavigationKeyEvent_SetCurrentFocus(wxNavigationKeyEvent* self, wxWindow* win)
{
	self->SetCurrentFocus(win);
}

WXNET_EXPORT(void)
  wxNavigationKeyEvent_SetFlags(wxNavigationKeyEvent* self, int flags)
{
	self->SetFlags(flags);
}

