//-----------------------------------------------------------------------------
// wx.NET - button.cxx
//
// The wxButton proxy interface.
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 by Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: button.cxx,v 1.20 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/button.h>
#include "local_events.h"

//-----------------------------------------------------------------------------

class _Button : public wxButton
{
public:
    DECLARE_OBJECTDELETED(_Button)
};

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxButton*)
  wxButton_ctor()
{
	return new _Button();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxButton_Create(wxButton *self, wxWindow* parent, wxWindowID id, const wxString* labelArg, int x, int y, int w, int h, int style, const wxValidator* validator, const wxString* nameArg)
{
	if (validator == NULL)
		validator = &wxDefaultValidator;

   wxString name(wxT("button"));
	if (nameArg) name = *nameArg;

   wxString label;
   if (labelArg) label=*labelArg;

	return self->Create(parent, id, label, wxPoint(x,y), wxSize(w,h), style, *validator, name)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxButton_SetDefault(wxButton* self)
{
	self->SetDefault();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxButton_GetDefaultSize(wxSize* size)
{
	*size = wxButton::GetDefaultSize();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxButton_SetImageLabel(wxButton* self, wxBitmap* bitmap)
{
	self->SetImageLabel(*bitmap);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxButton_SetImageMargins(wxButton* self, wxCoord x, wxCoord y)
{
	self->SetImageMargins(x, y);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxButton_SetLabel(wxButton* self, const wxString* label)
{
   if (self && label)
	   self->SetLabel(*label);
}

WXNET_EXPORT(wxString*)
  wxButton_GetLabel(const wxButton* self)
{
   if (self)
      return new wxString(self->GetLabel());
   else
      return 0;
}

