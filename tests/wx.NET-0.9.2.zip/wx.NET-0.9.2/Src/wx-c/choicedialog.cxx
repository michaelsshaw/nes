//-----------------------------------------------------------------------------
// wx.NET - choicedialog.h
//
// The wxXChoiceDialog proxy interfaces.
//
// Written by Alexander Olk (xenomorph2@onlinehome.de)
// (C) 2003 by Alexander Olk
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: choicedialog.cxx,v 1.9 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/choicdlg.h>
#include "local_events.h"

class _SingleChoiceDialog : public wxSingleChoiceDialog
{
public:
        _SingleChoiceDialog(wxWindow* parent, const wxString message,
                const wxString& caption,
                const wxArrayString& choices,
                char **clientData,
                int style,
                const wxPoint& pos)
        : wxSingleChoiceDialog(parent, message, caption, choices, clientData, style, pos)
    {}
        _SingleChoiceDialog(wxWindow* parent, const wxString message,
                const wxString& caption,
                int style,
                const wxPoint& pos)
        : wxSingleChoiceDialog(parent, message, caption, 0, NULL, NULL, style, pos)
    {}
    DECLARE_OBJECTDELETED(_SingleChoiceDialog)
};

WXNET_EXPORT(wxSingleChoiceDialog*)
  wxSingleChoiceDialog_ctor(wxWindow* parent, const wxString* messageArg,
        const wxString* captionArg, const wxArrayString* choices, void** clientData,
        int style, int posX, int posY)
{
    wxString message;
    if (messageArg != NULL)
       message = *messageArg;
    wxString caption;
    if (captionArg != NULL)
       caption = *captionArg;
    if (choices==NULL)
       return WXNET_NEW( _SingleChoiceDialog, (parent, message, caption, style, wxPoint(posX, posY)));
    else
       return WXNET_NEW( _SingleChoiceDialog, (parent, message, caption,
                   *choices, (char**)clientData, style, wxPoint(posX, posY)));
}

WXNET_EXPORT(void)
  wxSingleChoiceDialog_dtor(wxSingleChoiceDialog* self)
{
    WXNET_DEL( self );
}

WXNET_EXPORT(void)
  wxSingleChoiceDialog_SetSelection(wxSingleChoiceDialog* self, int sel)
{
    self->SetSelection(sel);
}

WXNET_EXPORT(int)
  wxSingleChoiceDialog_GetSelection(wxSingleChoiceDialog* self)
{
    return self->GetSelection();
}

WXNET_EXPORT(wxString*)
  wxSingleChoiceDialog_GetStringSelection(wxSingleChoiceDialog* self)
{
    return new wxString(self->GetStringSelection());
}

WXNET_EXPORT(void*)
  wxSingleChoiceDialog_GetSelectionClientData(wxSingleChoiceDialog* self)
{
    return self->GetSelectionClientData();
}

//-----------------------------------------------------------------------------

class _MultiChoiceDialog : public wxMultiChoiceDialog
{
public:
        _MultiChoiceDialog(wxWindow* parent, const wxString message,
                const wxString& caption,
                const wxArrayString& choices,
                int style,
                const wxPoint& pos)
        : wxMultiChoiceDialog(parent, message, caption, choices, style, pos)
    {}
        _MultiChoiceDialog(wxWindow* parent, const wxString message,
                const wxString& caption,
                int style,
                const wxPoint& pos)
        : wxMultiChoiceDialog(parent, message, caption, 0, NULL, style, pos)
    {}
    DECLARE_OBJECTDELETED(_MultiChoiceDialog)
};

WXNET_EXPORT(wxMultiChoiceDialog*)
  wxMultiChoiceDialog_ctor(wxWindow* parent, const wxString* messageArg,
        const wxString* captionArg, const wxArrayString* choices,
        int style, int posX, int posY)
{
   wxString message;
   if (messageArg)
      message=*messageArg;
   wxString caption;
   if (captionArg)
      caption=*captionArg;
   if (choices)
      return WXNET_NEW(_MultiChoiceDialog, (parent, message, caption, *choices, style, wxPoint(posX, posY)));
   else
      return WXNET_NEW(_MultiChoiceDialog, (parent, message, caption, style, wxPoint(posX, posY)));
}

WXNET_EXPORT(void)
  wxMultiChoiceDialog_dtor(wxMultiChoiceDialog* self)
{
    WXNET_DEL( self );
}

WXNET_EXPORT(void)
  wxMultiChoiceDialog_SetSelections(wxMultiChoiceDialog* self, int *sel[], int numsel)
{
    wxArrayInt wai;
    for (int i = 0; i < numsel; ++i)
        wai.Add(*sel[i]);
    self->SetSelections(wai);
}

WXNET_EXPORT(wxArrayInt*)
  wxMultiChoiceDialog_GetSelections(wxMultiChoiceDialog* self)
{
    return new wxArrayInt(self->GetSelections());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxGetSingleChoice_func(const wxString* messageArg, const wxString* captionArg, const wxArrayString* choices,
                wxWindow *parent, int x, int y, bool centre,
                int width, int height)
{
   wxString message;
   if (messageArg)
      message=*messageArg;
   wxString caption;
   if (captionArg)
      caption=*captionArg;
   if (choices)
      return WXNET_NEW(wxString, (wxGetSingleChoice(message, caption, *choices, parent, x, y, centre, width, height)));
   else
      return WXNET_NEW(wxString, (wxGetSingleChoice(message, caption, 0, NULL, parent, x, y, centre, width, height)));
}

WXNET_EXPORT(int)
  wxGetSingleChoiceIndex_func(const wxString* messageArg, const wxString* captionArg, const wxArrayString* choices,
                wxWindow *parent, int x, int y, bool centre,
                int width, int height)
{
   wxString message;
   if (messageArg)
      message=*messageArg;
   wxString caption;
   if (captionArg)
      caption=*captionArg;
   if (choices)
      return wxGetSingleChoiceIndex(message, caption, *choices, parent, x, y, centre, width, height);
   else
      return wxGetSingleChoiceIndex(message, caption, 0, NULL, parent, x, y, centre, width, height);
}



