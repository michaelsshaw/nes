//-----------------------------------------------------------------------------
// wx.NET - config.cxx
// 
// The wxConfig proxy interface.
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 by Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: config.cxx,v 1.14 2010/02/13 17:24:57 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/config.h>
#ifdef __WXMSW__
#include <wx/msw/iniconf.h>
#endif
#include <wx/fileconf.h>
#include "local_events.h"

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxConfigBase*)
  wxConfigBase_CTor1(const wxString* appNameArg,
                                 const wxString* vendorNameArg,
                                 const wxString* localFilenameArg,
                                 const wxString* globalFilenameArg,
                                 int style)
{
   wxString appName;
   if (appNameArg)
      appName=*appNameArg;
   wxString vendorName;
   if (vendorNameArg)
      vendorName=*vendorNameArg;
   wxString localFilename;
   if (localFilenameArg)
      localFilename=*localFilenameArg;
   wxString globalFilename;
   if (globalFilenameArg)
      globalFilename=*globalFilenameArg;
#if defined(__WXMSW__) && wxUSE_CONFIG_NATIVE
   return new wxRegConfig(appName, vendorName, wxT(""), wxT(""), style);
#elif defined(__WXPALMOS__) && wxUSE_CONFIG_NATIVE
   return new wxPrefConfig(appName);
#else // either we're under Unix or wish to use files even under Windows
   return new wxFileConfig(appName, vendorName, localFilename, globalFilename, style);
#endif
}

WXNET_EXPORT(wxConfigBase*)
  wxConfigBase_Set(wxConfigBase* pConfig)
{
   if (!pConfig) return NULL;
   return wxConfigBase::Set(pConfig);
}

WXNET_EXPORT(wxConfigBase*)
  wxConfigBase_Get(bool createOnDemand)
{
    return wxConfigBase::Get(createOnDemand);
}

WXNET_EXPORT(wxConfigBase*)
  wxConfigBase_Create()
{
    return wxConfigBase::Create();
}

WXNET_EXPORT(void)
  wxConfigBase_DontCreateOnDemand()
{
    wxConfigBase::DontCreateOnDemand();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxConfigBase_Delete(wxConfigBase* self)
{
    WXNET_DEL( self );
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxConfigBase_SetPath(wxConfigBase* self, const wxString* strPath)
{
   if (self)
    self->SetPath(*strPath);
}

WXNET_EXPORT(wxString*)
  wxConfigBase_GetPath(wxConfigBase* self)
{
   if (self)
    return new wxString(self->GetPath());
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxConfigBase_GetFirstGroup(wxConfigBase* self, wxString* str, int *iIndex)
{
   if (self && str && iIndex)
   {
       long lIndex=*iIndex;
       bool result = self->GetFirstGroup(*str, lIndex);
       *iIndex=lIndex;
       return result;
   }
   else
      return false;
}

WXNET_EXPORT(char)
  wxConfigBase_GetNextGroup(wxConfigBase* self, wxString* str, int* iIndex)
{
   if (self && str && iIndex)
   {
       long lIndex=*iIndex;
       bool result = self->GetNextGroup(*str, lIndex);
       *iIndex=lIndex;
       return result;
   }
   else
      return false;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxConfigBase_GetFirstEntry(wxConfigBase* self, wxString* str, int* iIndex)
{
   if (self && str && iIndex)
   {
        long lIndex=*iIndex;
        bool result = self->GetFirstEntry(*str, lIndex);
        *iIndex=lIndex;
        return result;
   }
   else
      return false;
}

WXNET_EXPORT(char)
  wxConfigBase_GetNextEntry(wxConfigBase* self, wxString* str, int* iIndex)
{
   if (self && str && iIndex)
   {
       long lIndex=*iIndex;
       bool result=self->GetNextEntry(*str, lIndex);
       *iIndex=lIndex;
       return result;
   }
   else
      return false;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxConfigBase_GetNumberOfEntries(wxConfigBase* self, bool bRecursive)
{
   if (self)
    return self->GetNumberOfEntries(bRecursive);
   else
      return 0;
}

WXNET_EXPORT(int)
  wxConfigBase_GetNumberOfGroups(wxConfigBase* self, bool bRecursive)
{
   if (self)
    return self->GetNumberOfGroups(bRecursive);
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxConfigBase_HasGroup(wxConfigBase* self, const wxString* strName)
{
   if (self)
    return self->HasGroup(*strName)?1:0;
   else
      return false;
}

WXNET_EXPORT(char)
  wxConfigBase_HasEntry(wxConfigBase* self, const wxString* strName)
{
   if (self && strName)
    return self->HasEntry(*strName)?1:0;
   else
      return false;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxConfigBase_Exists(wxConfigBase* self, const wxString* strName)
{
   if (self && strName)
    return self->Exists(*strName)?1:0;
   else
      return false;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxConfigBase_GetEntryType(wxConfigBase* self, const wxString* name)
{
   if (self && name)
    return self->GetEntryType(*name);
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxConfigBase_ReadStr(wxConfigBase* self, const wxString* key, wxString* pStr)
{
   if (self && key && pStr)
    return self->Read(*key, pStr)?1:0;
   else
      return false;
}

WXNET_EXPORT(char)
  wxConfigBase_ReadStrDef(wxConfigBase* self, const wxString* key, wxString* pStr, const wxString* defVal)
{
   if (self && key && pStr && defVal)
    return self->Read(*key, pStr, *defVal)?1:0;
   else
      return false;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxConfigBase_ReadInt(wxConfigBase* self, const wxString* key, int* pl)
{
   if (self && key && pl)
    return self->Read(*key, pl)?1:0;
   else
      return false;
}

WXNET_EXPORT(char)
  wxConfigBase_ReadIntDef(wxConfigBase* self, const wxString* key, int* pl, int defVal)
{
   if (self && key && pl && defVal)
    return self->Read(*key, pl, defVal)?1:0;
   else
      return false;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxConfigBase_ReadDbl(wxConfigBase* self, const wxString* key, double* val)
{
   if (self && key && val)
    return self->Read(*key, val)?1:0;
   else
      return false;
}

WXNET_EXPORT(char)
  wxConfigBase_ReadDblDef(wxConfigBase* self, const wxString* key, double* val, double defVal)
{
   if (self && key && val)
    return self->Read(*key, val, defVal)?1:0;
   else
      return false;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxConfigBase_ReadBool(wxConfigBase* self, const wxString* key, bool* val)
{
   if (self && key && val)
    return self->Read(*key, val)?1:0;
   else
      return false;
}

WXNET_EXPORT(char)
  wxConfigBase_ReadBoolDef(wxConfigBase* self, const wxString* key, bool* val, bool defVal)
{
   if (self && key && val)
    return self->Read(*key, val, defVal)?1:0;
   else
      return false;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxConfigBase_ReadStrRet(wxConfigBase* self, const wxString* key, const wxString* defVal)
{
   if (self && key && defVal)
    return new wxString(self->Read(*key, *defVal));
   else
      return NULL;
}

WXNET_EXPORT(int)
  wxConfigBase_ReadIntRet(wxConfigBase* self, const wxString* key, int defVal)
{
   if (self && key)
    return self->Read(*key, defVal);
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxConfigBase_WriteStr(wxConfigBase* self, const wxString* key, const wxString* value)
{
   if (self && key && value)
    return self->Write(*key, *value)?1:0;
   else
      return false;
}

WXNET_EXPORT(char)
  wxConfigBase_WriteInt(wxConfigBase* self, const wxString* key, int value)
{
   if (self && key)
    return self->Write(*key, value)?1:0;
   else
      return false;
}

WXNET_EXPORT(char)
  wxConfigBase_WriteDbl(wxConfigBase* self, const wxString* key, double value)
{
   if (self && key)
    return self->Write(*key, value)?1:0;
   else
      return false;
}

WXNET_EXPORT(char)
  wxConfigBase_WriteBool(wxConfigBase* self, const wxString* key, bool value)
{
   if (self && key)
    return self->Write(*key, value)?1:0;
   else
      return false;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxConfigBase_Flush(wxConfigBase* self, bool bCurrentOnly)
{
   if (self)
    return self->Flush(bCurrentOnly)?1:0;
   else
      return false;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxConfigBase_RenameEntry(wxConfigBase* self, const wxString* oldName, const wxString* newName)
{
   if (self && oldName && newName)
    return self->RenameEntry(*oldName, *newName)?1:0;
   else
      return false;
}

WXNET_EXPORT(char)
  wxConfigBase_RenameGroup(wxConfigBase* self, const wxString* oldName, const wxString* newName)
{
   if (self && oldName && newName)
    return self->RenameGroup(*oldName, *newName)?1:0;
   else
      return false;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxConfigBase_DeleteEntry(wxConfigBase* self, const wxString* key, bool bDeleteGroupIfEmpty)
{
   if (self && key)
    return self->DeleteEntry(*key, bDeleteGroupIfEmpty)?1:0;
   else
      return false;
}

WXNET_EXPORT(char)
  wxConfigBase_DeleteGroup(wxConfigBase* self, const wxString* key)
{
   if (self && key)
    return self->DeleteGroup(*key)?1:0;
   else 
      return false;
}

WXNET_EXPORT(char)
  wxConfigBase_DeleteAll(wxConfigBase* self)
{
   if (self)
    return self->DeleteAll()?1:0;
   else
      return false;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxConfigBase_IsExpandingEnvVars(wxConfigBase* self)
{
   if (self)
    return self->IsExpandingEnvVars()?1:0;
   else
      return false;
}

WXNET_EXPORT(void)
  wxConfigBase_SetExpandEnvVars(wxConfigBase* self, bool bDoIt)
{
   if (self)
    self->SetExpandEnvVars(bDoIt);
}

WXNET_EXPORT(wxString*)
  wxConfigBase_ExpandEnvVars(wxConfigBase* self, const wxString* str)
{
   if (self && str)
    return new wxString(self->ExpandEnvVars(*str));
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxConfigBase_SetRecordDefaults(wxConfigBase* self, bool bDoIt)
{
   if (self)
    self->SetRecordDefaults(bDoIt);
}

WXNET_EXPORT(char)
  wxConfigBase_IsRecordingDefaults(wxConfigBase* self)
{
   if (self)
    return self->IsRecordingDefaults()?1:0;
   else
      return false;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxConfigBase_GetAppName(wxConfigBase* self)
{
    return new wxString(self->GetAppName());
}

WXNET_EXPORT(void)
  wxConfigBase_SetAppName(wxConfigBase* self, const wxString* appName)
{
   if (self && appName)
    self->SetAppName(*appName);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxConfigBase_GetVendorName(wxConfigBase* self)
{
   if (self)
    return new wxString(self->GetVendorName());
   else
      return NULL;
}

WXNET_EXPORT(void)
  wxConfigBase_SetVendorName(wxConfigBase* self, const wxString* vendorName)
{
   if (self && vendorName)
    self->SetVendorName(*vendorName);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxConfigBase_SetStyle(wxConfigBase* self, unsigned int style)
{
   if (self)
    self->SetStyle(style);
}

WXNET_EXPORT(int)
  wxConfigBase_GetStyle(wxConfigBase* self)
{
   if (self)
    return self->GetStyle();
   else
      return 0;
}

//-----------------------------------------------------------------------------

