//-----------------------------------------------------------------------------
// wx.NET - validator.cxx
//
// The wxValidator proxy interface
//
// Written by Alexander Olk (xenomorph2@onlinehome.de)
// (C) 2004 by Alexander Olk
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: validator.cxx,v 1.2 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/validate.h>
#include "wxnet_globals.h"


WXNET_EXPORT(wxValidator*)
  wxValidator_ctor()
{
	return new wxValidator();
}
