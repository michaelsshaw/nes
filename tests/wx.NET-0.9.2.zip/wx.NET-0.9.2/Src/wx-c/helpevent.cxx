//-----------------------------------------------------------------------------
// wx.NET - helpevent.cxx
// 
// The wxHelpEvent proxy interface.
//
// Written by Alexander Olk (xenomorph2@onlinehome.de)
// (C) 2004 by Alexander Olk
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: helpevent.cxx,v 1.4 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#ifndef WXNET_GLOBAL_H
#include "wxnet_globals.h"
#endif

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxHelpEvent*)
  wxHelpEvent_ctor(wxEventType type)
{
    return new wxHelpEvent(type);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHelpEvent_GetPosition(wxHelpEvent* self, wxPoint* inp)
{
	*inp = self->GetPosition();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHelpEvent_SetPosition(wxHelpEvent* self, wxPoint* pos)
{
	self->SetPosition(*pos);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxHelpEvent_GetLink(wxHelpEvent* self)
{
	return new wxString(self->GetLink());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHelpEvent_SetLink(wxHelpEvent* self, const wxString* link)
{
   if (link && self)
	self->SetLink(*link);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxHelpEvent_GetTarget(wxHelpEvent* self)
{
	return new wxString(self->GetTarget());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxHelpEvent_SetTarget(wxHelpEvent* self, const wxString* target)
{
   if (self && target)
	   self->SetTarget(*target);
}

