//-----------------------------------------------------------------------------
// wx.NET - notebook.cxx
//
// The wxNotebook proxy interface.
//
// Written by Jason Perkins (jason@379.com)
// (C) 2003 by 379, Inc.
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: notebook.cxx,v 1.18 2009/01/06 18:24:22 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/notebook.h>
#include "local_events.h"

//-----------------------------------------------------------------------------
// The proxy class

class _Notebook : public wxNotebook, ValidatorStub
{
public:
	DECLARE_OBJECTDELETED(_Notebook)

#include "control.inc"
};

//-----------------------------------------------------------------------------
// C stubs for class methods

WXNET_EXPORT(wxNotebook*)
  wxNotebook_ctor()
{
	return new _Notebook();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxNotebook_AddPage(wxNotebook* self, wxNotebookPage* page, const wxString* text, bool select, int imageId)
{
   if (self && text)
	   return self->AddPage(page, *text, select, imageId);
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxNotebook_Create(wxNotebook* self, wxWindow* parent, int id, int posX, int posY,
                       int width, int height, unsigned int style, const wxString* nameArg)
{
   wxString name;
	if (nameArg == NULL)
		name = wxT("notebook");
   else
      name=*nameArg;

	return self->Create(parent, id, wxPoint(posX, posY), wxSize(width, height), style, name);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxNotebook_SetImageList(wxNotebookBase* self, wxImageList* imageList)
{
	self->SetImageList(imageList);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxNotebook_GetPageCount(wxNotebook* self)
{
	return self->GetPageCount();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxNotebookPage*)
  wxNotebook_GetPage(wxNotebook* self, int nPage)
{
	return self->GetPage(nPage);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxNotebook_GetSelection(wxNotebook* self)
{
	return self->GetSelection();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxNotebook_SetPageText(wxNotebook* self, int nPage, const wxString* strText)
{
   if (strText && self)
	   return self->SetPageText(nPage, *strText);
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxNotebook_GetPageText(wxNotebook* self, int nPage)
{
	return new wxString(self->GetPageText(nPage));;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxNotebook_AssignImageList(wxNotebook* self, wxImageList* imageList)
{
	self->AssignImageList(imageList);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxImageList*)
  wxNotebook_GetImageList(wxNotebook* self)
{
	return self->GetImageList();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxNotebook_GetPageImage(wxNotebook* self, int nPage)
{
	return self->GetPageImage(nPage);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxNotebook_SetPageImage(wxNotebook* self, int nPage, int nImage)
{
	return self->SetPageImage(nPage, nImage)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxNotebook_GetRowCount(wxNotebook* self)
{
	return self->GetRowCount();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxNotebook_SetPageSize(wxNotebook* self, const wxSize* size)
{
	self->SetPageSize(*size);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxNotebook_SetPadding(wxNotebook* self, const wxSize* padding)
{
	self->SetPadding(*padding);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxNotebook_SetTabSize(wxNotebook* self, const wxSize* sz)
{
	self->SetTabSize(*sz);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxNotebook_DeletePage(wxNotebook* self, int nPage)
{
	return self->DeletePage(nPage)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxNotebook_RemovePage(wxNotebook* self, int nPage)
{
	return self->RemovePage(nPage)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxNotebook_DeleteAllPages(wxNotebook* self)
{
	return self->DeleteAllPages()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxNotebook_InsertPage(wxNotebook* self, int nPage, wxNotebookPage *pPage, const wxString* strText, bool bSelect, int imageId)
{
   if (strText && self)
	   return self->InsertPage(nPage, pPage, *strText, bSelect, imageId);
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxNotebook_SetSelection(wxNotebook* self, int nPage)
{
	return self->SetSelection(nPage);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxNotebook_AdvanceSelection(wxNotebook* self, bool forward)
{
	self->AdvanceSelection(forward);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxNotebookEvent*)
  wxNotebookEvent_ctor(wxEventType commandType, int id, int nSel, int nOldSel)
{
    return new wxNotebookEvent(commandType, id, nSel, nOldSel);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxNotebookEvent_GetSelection(wxNotebookEvent* self)
{
    return self->GetSelection();
}

WXNET_EXPORT(void)
  wxNotebookEvent_SetSelection(wxNotebookEvent* self, int nSel)
{
    self->SetSelection(nSel);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxNotebookEvent_GetOldSelection(wxNotebookEvent* self)
{
   if (self)
    return self->GetOldSelection();
   else
      return 0;
}

WXNET_EXPORT(void)
  wxNotebookEvent_SetOldSelection(wxNotebookEvent* self, int nOldSel)
{
   if (self)
    self->SetOldSelection(nOldSel);
}
