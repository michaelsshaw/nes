//-----------------------------------------------------------------------------
// wx.NET - sashwindow.cxx
// 
// The wxSashWindow proxy interface.
//
// Written by Alexander Olk (xenomorph2@onlinehome.de)
// (C) 2004 by Alexander Olk
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: sashwindow.cxx,v 1.9 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/sashwin.h>
#include "local_events.h"

//-----------------------------------------------------------------------------
// wxSashEdge

WXNET_EXPORT(wxSashEdge*)
  wxSashEdge_ctor()
{
	return new wxSashEdge();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxSashEdge_dtor(wxSashEdge* self)
{
	WXNET_DEL( self );
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxSashEdge_m_show(wxSashEdge* self)
{
	return self->m_show;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxSashEdge_m_border(wxSashEdge* self)
{
	return self->m_border?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxSashEdge_m_margin(wxSashEdge* self)
{
	return self->m_margin;
}

//-----------------------------------------------------------------------------
// wxSashWindow

class _SashWindow : public wxSashWindow
{
public:
    DECLARE_OBJECTDELETED(_SashWindow)
};

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxSashWindow*)
  wxSashWindow_ctor()
{
	return new _SashWindow();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxSashWindow_Create(wxSashWindow* self, wxWindow* parent, wxWindowID id, int posX, int posY, int width, int height, unsigned int style, const wxString* nameArg)
{
   wxString name;		
	if (nameArg == NULL)
		name = wxT("sashwindow");
   else
      name=*nameArg;
		
	return self->Create(parent, id, wxPoint(posX, posY), wxSize(width, height), style, name);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxSashWindow_SetSashVisible(wxSashWindow* self, wxSashEdgePosition edge, bool sash)
{
	self->SetSashVisible(edge, sash);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxSashWindow_GetSashVisible(wxSashWindow* self, wxSashEdgePosition edge)
{
	return self->GetSashVisible(edge)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxSashWindow_SetSashBorder(wxSashWindow* self, wxSashEdgePosition edge, bool border)
{
	self->SetSashBorder(edge, border);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxSashWindow_HasBorder(wxSashWindow* self, wxSashEdgePosition edge)
{
	return self->HasBorder(edge)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxSashWindow_GetEdgeMargin(wxSashWindow* self, wxSashEdgePosition edge)
{
	return self->GetEdgeMargin(edge);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxSashWindow_SetDefaultBorderSize(wxSashWindow* self, int with)
{
	self->SetDefaultBorderSize(with);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxSashWindow_GetDefaultBorderSize(wxSashWindow* self)
{
	return self->GetDefaultBorderSize();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxSashWindow_SetExtraBorderSize(wxSashWindow* self, int width)
{
	self->SetExtraBorderSize(width);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxSashWindow_GetExtraBorderSize(wxSashWindow* self)
{
	return self->GetExtraBorderSize();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxSashWindow_SetMinimumSizeX(wxSashWindow* self, int min)
{
	self->SetMinimumSizeX(min);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxSashWindow_SetMinimumSizeY(wxSashWindow* self, int min)
{
	self->SetMinimumSizeY(min);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxSashWindow_GetMinimumSizeX(wxSashWindow* self)
{
	return self->GetMinimumSizeX();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxSashWindow_GetMinimumSizeY(wxSashWindow* self)
{
	return self->GetMinimumSizeY();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxSashWindow_SetMaximumSizeX(wxSashWindow* self, int max)
{
	self->SetMaximumSizeX(max);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxSashWindow_SetMaximumSizeY(wxSashWindow* self, int max)
{
	self->SetMaximumSizeY(max);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxSashWindow_GetMaximumSizeX(wxSashWindow* self)
{
	return self->GetMaximumSizeX();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxSashWindow_GetMaximumSizeY(wxSashWindow* self)
{
	return self->GetMaximumSizeY();
}

//-----------------------------------------------------------------------------
// wxSashEvent

WXNET_EXPORT(wxSashEvent*)
  wxSashEvent_ctor(int id, wxSashEdgePosition edge)
{
	return new wxSashEvent(id, edge);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxSashEvent_SetEdge(wxSashEvent* self, wxSashEdgePosition edge)
{
	self->SetEdge(edge);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxSashEdgePosition*)
  wxSashEvent_GetEdge(wxSashEvent* self)
{
	return new wxSashEdgePosition(self->GetEdge());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxSashEvent_SetDragRect(wxSashEvent* self, wxRect* rect)
{
	self->SetDragRect(*rect);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxSashEvent_GetDragRect(wxSashEvent* self, wxRect* rect)
{
	*rect = self->GetDragRect();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxSashEvent_SetDragStatus(wxSashEvent* self, wxSashDragStatus status)
{
	self->SetDragStatus(status);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxSashDragStatus)
  wxSashEvent_GetDragStatus(wxSashEvent* self)
{
	return self->GetDragStatus();
}



