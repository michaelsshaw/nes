//-----------------------------------------------------------------------------
// wx.NET - palette.cxx
//
// The wxPalette proxy interface.
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: palette.cxx,v 1.7 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/palette.h>
#include "local_events.h"

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxPalette*)
  wxPalette_ctor()
{
	return new wxPalette();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPalette_dtor(wxPalette* self)
{
	WXNET_DEL( self );
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxPalette_Ok(wxPalette* self)
{
	return self->Ok()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxPalette_Create(wxPalette* self, int n, const unsigned char *red,
					  const unsigned char *green, const unsigned char *blue)
{
	return self->Create(n, red, green, blue)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxPalette_GetPixel(wxPalette* self, const unsigned char red,
					   const unsigned char green, const unsigned char blue)
{
	return self->GetPixel(red, green, blue);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxPalette_GetRGB(wxPalette* self, int pixel, unsigned char *red,
					  unsigned char *green, unsigned char *blue)
{
	return self->GetRGB(pixel, red, green, blue)?1:0;
}
