//-----------------------------------------------------------------------------
// wx.NET - document.cxx
//
// The wxDocument proxy interface.
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 by Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: document.cxx,v 1.8 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/docview.h>
#ifndef WXNET_GLOBAL_H
#include "wxnet_globals.h"
#endif

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxDocument*)
  wxDocument_ctor(wxDocument* parent)
{
    return new wxDocument(parent);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxDocument_SetFilename(wxDocument* self, const wxString* filename, bool notifyViews)
{
   if (self && filename)
    self->SetFilename(*filename, notifyViews);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxDocument_GetFilename(wxDocument* self)
{
    return new wxString(self->GetFilename());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxDocument_SetTitle(wxDocument* self, const wxString* title)
{
   if (self && title)
    self->SetTitle(*title);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxDocument_GetTitle(wxDocument* self)
{
    return new wxString(self->GetTitle());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxDocument_SetDocumentName(wxDocument* self, const wxString* name)
{
   if (self && name)
    self->SetDocumentName(*name);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxDocument_GetDocumentName(wxDocument* self)
{
    return new wxString(self->GetDocumentName());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxDocument_GetDocumentSaved(wxDocument* self)
{
    return self->GetDocumentSaved();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxDocument_SetDocumentSaved(wxDocument* self, bool saved)
{
    self->SetDocumentSaved(saved);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxDocument_Close(wxDocument* self)
{
    return self->Close();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxDocument_Save(wxDocument* self)
{
    return self->Save();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxDocument_SaveAs(wxDocument* self)
{
    return self->SaveAs();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxDocument_Revert(wxDocument* self)
{
    return self->Revert();
}

//-----------------------------------------------------------------------------

/*extern "C" WXEXPORT
wxOutputStream* wxDocument_SaveObject(wxDocument* self, wxOutputStream* stream)
{
    return &(self->SaveObject(*stream));
}

WXNET_EXPORT(wxInputStream*)
  wxDocument_LoadObject(wxDocument* self, wxInputStream* stream)
{
    return &(self->LoadObject(*stream));
}*/

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxCommandProcessor*)
  wxDocument_GetCommandProcessor(wxDocument* self)
{
    return self->GetCommandProcessor();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxDocument_SetCommandProcessor(wxDocument* self, wxCommandProcessor* proc)
{
    self->SetCommandProcessor(proc);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxDocument_DeleteContents(wxDocument* self)
{
    return self->DeleteContents();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxDocument_Draw(wxDocument* self, wxDC* dc)
{
    return self->Draw(*dc);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxDocument_IsModified(wxDocument* self)
{
    return self->IsModified();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxDocument_Modify(wxDocument* self, bool mod)
{
    self->Modify(mod);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxDocument_AddView(wxDocument* self, wxView* view)
{
    return self->AddView(view);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxDocument_RemoveView(wxDocument* self, wxView* view)
{
    return self->RemoveView(view);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxList*)
  wxDocument_GetViews(wxDocument* self)
{
    return &(self->GetViews());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxView*)
  wxDocument_GetFirstView(wxDocument* self)
{
    return self->GetFirstView();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxDocument_UpdateAllViews(wxDocument* self, wxView* sender, wxObject* hint)
{
    self->UpdateAllViews(sender, hint);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxDocument_NotifyClosing(wxDocument* self)
{
    self->NotifyClosing();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxDocument_DeleteAllViews(wxDocument* self)
{
    return self->DeleteAllViews();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxDocManager*)
  wxDocument_GetDocumentManager(wxDocument* self)
{
    return self->GetDocumentManager();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxDocTemplate*)
  wxDocument_GetDocumentTemplate(wxDocument* self)
{
    return self->GetDocumentTemplate();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxDocument_SetDocumentTemplate(wxDocument* self, wxDocTemplate* temp)
{
    self->SetDocumentTemplate(temp);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxDocument_GetPrintableName(wxDocument* self, wxString* name)
{
    return self->GetPrintableName(*name);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxWindow*)
  wxDocument_GetDocumentWindow(wxDocument* self)
{
    return self->GetDocumentWindow();
}

//-----------------------------------------------------------------------------
