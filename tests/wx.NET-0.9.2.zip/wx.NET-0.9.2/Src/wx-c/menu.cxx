//-----------------------------------------------------------------------------
// wx.NET - menu.cxx
//
// The wxMenu proxy interface.
//
// Written by Jason Perkins (jason@379.com)
// (C) 2003 by 379, Inc.
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: menu.cxx,v 1.16 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include "local_events.h"

//-----------------------------------------------------------------------------
// wxMenuBase

class _MenuBase : public wxMenuBase
{
public:
	_MenuBase(const wxString& title, long style)
		: wxMenuBase(title, style) {}
		
	_MenuBase(long style)
		: wxMenuBase(style) {}
		
	DECLARE_OBJECTDELETED(_MenuBase)
};

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxMenuBase*)
  wxMenuBase_ctor1(const wxString* title, unsigned int style)
{
   if (title)
	   return new _MenuBase(*title, style);
   else return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxMenuBase*)
  wxMenuBase_ctor2(int style)
{
	return new _MenuBase(style);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxMenuItem*)
  wxMenuBase_Append(wxMenuBase* self, int id, const wxString* item, const wxString* helpString, wxItemKind kind)
{
   if (self && item && helpString)
	   return self->Append(id, *item, *helpString, kind);
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxMenuItem*)
  wxMenuBase_AppendSeparator(wxMenuBase* self)
{
	return self->AppendSeparator();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxMenuItem*)
  wxMenuBase_AppendCheckItem(wxMenuBase* self, int itemid, const wxString* text, const wxString* help)
{
   if (self && text && help)
	   return self->AppendCheckItem(itemid, *text, *help);
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxMenuItem*)
  wxMenuBase_AppendRadioItem(wxMenuBase* self, int itemid, const wxString* text, const wxString* help)
{
   if (self && text && help)
	   return self->AppendRadioItem(itemid, *text, *help);
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxMenuItem*)
  wxMenuBase_AppendSubMenu(wxMenuBase* self, int id, const wxString* item, wxMenu* subMenu, const wxString* helpString)
{
   if (self && item && helpString)
	   return self->Append(id, *item, subMenu, *helpString);
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxMenuItem*)
  wxMenuBase_AppendItem(wxMenuBase* self, wxMenuItem* item)
{
	return self->Append(item);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxMenuBase_Break(wxMenuBase* self)
{
	self->Break();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxMenuItem*)
  wxMenuBase_Insert(wxMenuBase* self, size_t pos, wxMenuItem* item)
{
	return self->Insert(pos, item);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxMenuItem*)
  wxMenuBase_Insert2(wxMenuBase* self, size_t pos, int itemid, const wxString* text, const wxString* help, wxItemKind kind)
{
   if (self && text && help)
	   return self->Insert(pos, itemid, *text, *help, kind);
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxMenuItem*)
  wxMenuBase_InsertSeparator(wxMenuBase* self, size_t pos)
{
	return self->InsertSeparator(pos);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxMenuItem*)
  wxMenuBase_InsertCheckItem(wxMenuBase* self, size_t pos, int itemid, const wxString* text, const wxString* help)
{
   if (self && text && help)
	   return self->InsertCheckItem(pos, itemid, *text, *help);
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxMenuItem*)
  wxMenuBase_InsertRadioItem(wxMenuBase* self, size_t pos, int itemid, const wxString* text, const wxString* help)
{
   if (self && text && help)
	   return self->InsertRadioItem(pos, itemid, *text, *help);
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxMenuItem*)
  wxMenuBase_InsertSubMenu(wxMenuBase* self, size_t pos, int itemid, const wxString* text, wxMenu* submenu, const wxString* help)
{
   if (self && text && help)
	   return self->Insert(pos, itemid,  *text, submenu, *help);
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxMenuItem*)
  wxMenuBase_Prepend(wxMenuBase* self, wxMenuItem* item)
{
	return self->Prepend(item);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxMenuItem*)
  wxMenuBase_Prepend2(wxMenuBase* self, int itemid, const wxString* text, const wxString* help, wxItemKind kind)
{
   if (self && text && help)
	   return self->Prepend(itemid, *text, *help, kind);
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxMenuItem*)
  wxMenuBase_PrependSeparator(wxMenuBase* self)
{
	return self->PrependSeparator();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxMenuItem*)
  wxMenuBase_PrependCheckItem(wxMenuBase* self, int itemid, const wxString* text, const wxString* help)
{
   if (self && text && help)
	   return self->PrependCheckItem(itemid, *text, *help);
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxMenuItem*)
  wxMenuBase_PrependRadioItem(wxMenuBase* self, int itemid, const wxString* text, const wxString* help)
{
   if (self && text && help)
	   return self->PrependRadioItem(itemid, *text, *help);
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxMenuItem*)
  wxMenuBase_PrependSubMenu(wxMenuBase* self, int itemid, const wxString* text, wxMenu* submenu, const wxString* help)
{
   if (self && text && help)
	   return self->Prepend(itemid, *text, submenu, *help);
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxMenuItem*)
  wxMenuBase_Remove(wxMenuBase* self, int itemid)
{
	return self->Remove(itemid);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxMenuItem*)
  wxMenuBase_Remove2(wxMenuBase* self, wxMenuItem* item)
{
	return self->Remove(item);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxMenuBase_Delete(wxMenuBase* self, int itemid)
{
	return self->Delete(itemid)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxMenuBase_Delete2(wxMenuBase* self, wxMenuItem* item)
{
	return self->Delete(item)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxMenuBase_Destroy(wxMenuBase* self, int itemid)
{
	return self->Destroy(itemid)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxMenuBase_Destroy2(wxMenuBase* self, wxMenuItem* item)
{
	return self->Destroy(item)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxMenuBase_GetMenuItemCount(wxMenuBase* self)
{
    return self->GetMenuItemCount();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxMenuBase_FindItem(wxMenuBase* self, const wxString* item)
{
   if (self && item)
	   return self->FindItem(*item);
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxMenuItem*)
  wxMenuBase_FindItem2(wxMenuBase* self, int itemid, wxMenu** menu)
{
	return self->FindItem(itemid, menu);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxMenuItem*)
  wxMenuBase_FindItemByPosition(wxMenuBase* self, size_t position)
{
	return self->FindItemByPosition(position);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxMenuBase_Enable(wxMenuBase* self, int itemid, bool enable)
{
	self->Enable(itemid, enable);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxMenuBase_IsEnabled(wxMenuBase* self, int itemid)
{
	return self->IsEnabled(itemid)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxMenuBase_Check(wxMenuBase* self, int itemid, bool check)
{
    self->Check(itemid, check);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxMenuBase_IsChecked(wxMenuBase* self, int itemid)
{
	return self->IsChecked(itemid)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxMenuBase_SetLabel(wxMenuBase* self, int itemid, const wxString* label)
{
   if (self && label)
	   self->SetLabel(itemid, *label);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxMenuBase_GetLabel(wxMenuBase* self, int itemid)
{
	return new wxString(self->GetLabel(itemid));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxMenuBase_SetHelpString(wxMenuBase* self, int itemid, const wxString* helpString)
{
   if (self && helpString)
	   self->SetHelpString(itemid, *helpString);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxMenuBase_GetHelpString(wxMenuBase* self, int itemid)
{
	return new wxString(self->GetHelpString(itemid));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxMenuBase_SetTitle(wxMenuBase* self, const wxString* title)
{
	self->SetTitle(*title);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxMenuBase_GetTitle(wxMenuBase* self)
{
	return new wxString(self->GetTitle());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxMenuBase_SetEventHandler(wxMenuBase* self, wxEvtHandler* handler)
{
	self->SetEventHandler(handler);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxEvtHandler*)
  wxMenuBase_GetEventHandler(wxMenuBase* self)
{
	return self->GetEventHandler();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxMenuBase_SetInvokingWindow(wxMenuBase* self, wxWindow* win)
{
	self->SetInvokingWindow(win);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxWindow*)
  wxMenuBase_GetInvokingWindow(wxMenuBase* self)
{
	return self->GetInvokingWindow();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxMenuBase_GetStyle(wxMenuBase* self)
{
	return self->GetStyle();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxMenuBase_UpdateUI(wxMenuBase* self, wxEvtHandler* source)
{
	self->UpdateUI(source);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxMenuBar*)
  wxMenuBase_GetMenuBar(wxMenuBase* self)
{
	return self->GetMenuBar();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxMenuBase_IsAttached(wxMenuBase* self)
{
	return self->IsAttached()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxMenuBase_SetParent(wxMenuBase* self, wxMenu* parent)
{
	self->SetParent(parent);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxMenu*)
  wxMenuBase_GetParent(wxMenuBase* self)
{
	return self->GetParent();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxMenuItem*)
  wxMenuBase_FindChildItem(wxMenuBase* self, int itemid, size_t *pos)
{
	return self->FindChildItem(itemid, pos);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxMenuItem*)
  wxMenuBase_FindChildItem2(wxMenuBase* self, int itemid)
{
	return self->FindChildItem(itemid);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxMenuBase_SendEvent(wxMenuBase* self, int itemid, int checked)
{
	return self->SendEvent(itemid, checked)?1:0;
}

//-----------------------------------------------------------------------------
// wxMenu

class _Menu : public wxMenu
{
public:
	_Menu(const wxString message, unsigned int style)
		: wxMenu(message, style) {}
		
	_Menu(int style)
		: wxMenu(style) {}
		
    DECLARE_OBJECTDELETED(_Menu)
};

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxMenu*)
  wxMenu_ctor(const wxString* title, unsigned int style)
{
   if (title)
	   return new _Menu(*title, style);
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxMenu*)
  wxMenu_ctor2(int style)
{
	return new _Menu(style);
}



