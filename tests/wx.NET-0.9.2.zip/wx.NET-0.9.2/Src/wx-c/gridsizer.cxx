//-----------------------------------------------------------------------------
// wx.NET - gridsizer.cxx
//
// The wxGridSizer proxy interface
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 by Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: gridsizer.cxx,v 1.4 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/sizer.h>
#ifndef WXNET_GLOBAL_H
#include "wxnet_globals.h"
#endif

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxGridSizer*)
  wxGridSizer_ctor(int rows, int cols, int vgap, int hgap)
{
	return new wxGridSizer(rows, cols, vgap, hgap);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGridSizer_RecalcSizes(wxGridSizer* self)
{
	self->RecalcSizes();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGridSizer_CalcMin(wxGridSizer* self, wxSize* size)
{
	*size = self->CalcMin();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGridSizer_SetCols(wxGridSizer* self, int cols)
{
	self->SetCols(cols);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGridSizer_SetRows(wxGridSizer* self, int rows)
{
	self->SetRows(rows);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGridSizer_SetVGap(wxGridSizer* self, int gap)
{
	self->SetVGap(gap);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGridSizer_SetHGap(wxGridSizer* self, int gap)
{
	self->SetHGap(gap);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxGridSizer_GetCols(wxGridSizer* self)
{
	return self->GetCols();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxGridSizer_GetRows(wxGridSizer* self)
{
	return self->GetRows();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxGridSizer_GetVGap(wxGridSizer* self)
{
	return self->GetVGap();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxGridSizer_GetHGap(wxGridSizer* self)
{
	return self->GetHGap();
}

//-----------------------------------------------------------------------------
