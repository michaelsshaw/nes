//-----------------------------------------------------------------------------
// wx.NET - imghandler.cxx
//
// The wxImageHandlers proxy interfaces.
//
// Written by Alexander Olk (xenomorph2@onlinehome.de)
// (C) 2004 by Alexander Olk
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: imghandler.cxx,v 1.5 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/image.h>
#ifndef WXNET_GLOBAL_H
#include "wxnet_globals.h"
#endif

WXNET_EXPORT(wxBMPHandler*)
  wxBMPHandler_ctor() 
{
    return new wxBMPHandler();
}

WXNET_EXPORT(wxICOHandler*)
  wxICOHandler_ctor() 
{
    return new wxICOHandler();
}

WXNET_EXPORT(wxCURHandler*)
  wxCURHandler_ctor() 
{
    return new wxCURHandler();
}

WXNET_EXPORT(wxANIHandler*)
  wxANIHandler_ctor() 
{
   return new wxANIHandler();
}



WXNET_EXPORT(wxPNGHandler*)
  wxPNGHandler_ctor() 
{
   return new wxPNGHandler();
}

WXNET_EXPORT(wxGIFHandler*)
  wxGIFHandler_ctor() 
{
    return new wxGIFHandler();
}

WXNET_EXPORT(wxPCXHandler*)
  wxPCXHandler_ctor() 
{
    return new wxPCXHandler();
}

WXNET_EXPORT(wxJPEGHandler*)
  wxJPEGHandler_ctor() 
{
    return new wxJPEGHandler();
}

WXNET_EXPORT(wxPNMHandler*)
  wxPNMHandler_ctor() 
{
    return new wxPNMHandler();
}

WXNET_EXPORT(wxXPMHandler*)
  wxXPMHandler_ctor() 
{
    return new wxXPMHandler();
}

WXNET_EXPORT(wxTIFFHandler*)
  wxTIFFHandler_ctor() 
{
    return new wxTIFFHandler();
}

