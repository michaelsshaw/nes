//-----------------------------------------------------------------------------
// wx.NET - notebooksizer.cxx
//
// The wxNotebookSizer proxy interface
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 by Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: notebooksizer.cxx,v 1.5 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>

#if (!wxCHECK_VERSION(2, 8, 0))

#include <wx/sizer.h>

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxNotebookSizer*)
  wxNotebookSizer_ctor(wxNotebook *nb)
{
	return new wxNotebookSizer(nb);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxNotebookSizer_RecalcSizes(wxNotebookSizer* self)
{
	self->RecalcSizes();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxNotebookSizer_CalcMin(wxNotebookSizer* self, wxSize* size)
{
	*size = self->CalcMin();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxNotebook*)
  wxNotebookSizer_GetNotebook(wxNotebookSizer* self)
{
	return self->GetNotebook();
}

//-----------------------------------------------------------------------------
#endif
