//-----------------------------------------------------------------------------
// wx.NET - styledtextctrl.h
// 
// The wxStyledTextCtrl proxy interface.
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 by Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: styledtextctrl.cxx,v 1.19 2010/06/06 08:53:52 harald_meyer Exp $
//-----------------------------------------------------------------------------

#ifdef WXNET_STYLEDTEXTCTRL

#include <wx/wx.h>
#include <wx/stc/stc.h>
#include "local_events.h"

//-----------------------------------------------------------------------------

// Event types


WXNET_EXPORT(int)
  wxStyledTextCtrl_EVT_STC_CHANGE()             { return wxEVT_STC_CHANGE; }
WXNET_EXPORT(int)
  wxStyledTextCtrl_EVT_STC_STYLENEEDED()        { return wxEVT_STC_STYLENEEDED; }
WXNET_EXPORT(int)
  wxStyledTextCtrl_EVT_STC_CHARADDED()          { return wxEVT_STC_CHARADDED; }
WXNET_EXPORT(int)
  wxStyledTextCtrl_EVT_STC_SAVEPOINTREACHED()   { return wxEVT_STC_SAVEPOINTREACHED; }
WXNET_EXPORT(int)
  wxStyledTextCtrl_EVT_STC_SAVEPOINTLEFT()      { return wxEVT_STC_SAVEPOINTLEFT; }
WXNET_EXPORT(int)
  wxStyledTextCtrl_EVT_STC_ROMODIFYATTEMPT()    { return wxEVT_STC_ROMODIFYATTEMPT; }
WXNET_EXPORT(int)
  wxStyledTextCtrl_EVT_STC_KEY()                { return wxEVT_STC_KEY; }
WXNET_EXPORT(int)
  wxStyledTextCtrl_EVT_STC_DOUBLECLICK()        { return wxEVT_STC_DOUBLECLICK; }
WXNET_EXPORT(int)
  wxStyledTextCtrl_EVT_STC_UPDATEUI()           { return wxEVT_STC_UPDATEUI; }
WXNET_EXPORT(int)
  wxStyledTextCtrl_EVT_STC_MODIFIED()           { return wxEVT_STC_MODIFIED; }
WXNET_EXPORT(int)
  wxStyledTextCtrl_EVT_STC_MACRORECORD()        { return wxEVT_STC_MACRORECORD; }
WXNET_EXPORT(int)
  wxStyledTextCtrl_EVT_STC_MARGINCLICK()        { return wxEVT_STC_MARGINCLICK; }
WXNET_EXPORT(int)
  wxStyledTextCtrl_EVT_STC_NEEDSHOWN()          { return wxEVT_STC_NEEDSHOWN; }
//extern "C" WXEXPORT int wxStyledTextCtrl_EVT_STC_POSCHANGED()         { return wxEVT_STC_POSCHANGED; }

WXNET_EXPORT(int)
  wxStyledTextCtrl_EVT_STC_PAINTED()            { return wxEVT_STC_PAINTED; }
WXNET_EXPORT(int)
  wxStyledTextCtrl_EVT_STC_USERLISTSELECTION()  { return wxEVT_STC_USERLISTSELECTION; }
WXNET_EXPORT(int)
  wxStyledTextCtrl_EVT_STC_URIDROPPED()         { return wxEVT_STC_URIDROPPED; }
WXNET_EXPORT(int)
  wxStyledTextCtrl_EVT_STC_DWELLSTART()         { return wxEVT_STC_DWELLSTART; }
WXNET_EXPORT(int)
  wxStyledTextCtrl_EVT_STC_DWELLEND()           { return wxEVT_STC_DWELLEND; }
WXNET_EXPORT(int)
  wxStyledTextCtrl_EVT_STC_START_DRAG()         { return wxEVT_STC_START_DRAG; }
WXNET_EXPORT(int)
  wxStyledTextCtrl_EVT_STC_DRAG_OVER()          { return wxEVT_STC_DRAG_OVER; }
WXNET_EXPORT(int)
  wxStyledTextCtrl_EVT_STC_DO_DROP()            { return wxEVT_STC_DO_DROP; }
WXNET_EXPORT(int)
  wxStyledTextCtrl_EVT_STC_ZOOM()               { return wxEVT_STC_ZOOM; }
WXNET_EXPORT(int)
  wxStyledTextCtrl_EVT_STC_HOTSPOT_CLICK()      { return wxEVT_STC_HOTSPOT_CLICK; }
WXNET_EXPORT(int)
  wxStyledTextCtrl_EVT_STC_HOTSPOT_DCLICK()     { return wxEVT_STC_HOTSPOT_DCLICK; }
WXNET_EXPORT(int)
  wxStyledTextCtrl_EVT_STC_CALLTIP_CLICK()      { return wxEVT_STC_CALLTIP_CLICK; }
//-----------------------------------------------------------------------------

class _StyledTextCtrl : public wxStyledTextCtrl
{
public:
    _StyledTextCtrl(wxWindow* parent, wxWindowID id, const wxPoint& pos, const wxSize& size, unsigned int style, const wxString& name)
        : wxStyledTextCtrl(parent, id, pos, size, style, name)
    {
    }

    ~_StyledTextCtrl()
    {
        FunctionEvent e(wxEVT_OBJECTDELETED);
        ProcessEvent(e);
    }
};

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxStyledTextCtrl*)
  wxStyledTextCtrl_ctor(wxWindow* parent, wxWindowID id, int posX, int posY, int width, int height, unsigned int style, const wxString* nameArg)
{
   wxString name;
   if (nameArg == NULL)
        name = wxT("styledtextctrl");
   else
      name=*nameArg;

    return new _StyledTextCtrl(parent, id, wxPoint(posX, posY), wxSize(width, height), style, name);
}

WXNET_EXPORT(void) wxStyledtextCtrl_dtor(wxStyledTextCtrl* obj)
{
    if (obj)
        delete obj;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_AddText(wxStyledTextCtrl* self, const wxString* text)
{if (self && text)
    self->AddText(*text);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_AddStyledText(wxStyledTextCtrl* self, wxMemoryBuffer* data)
{
    self->AddStyledText(*data);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_InsertText(wxStyledTextCtrl* self, int pos, const wxString* text)
{
   if (self && text)
    self->InsertText(pos, *text);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_ClearAll(wxStyledTextCtrl* self)
{
    self->ClearAll();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_ClearDocumentStyle(wxStyledTextCtrl* self)
{
    self->ClearDocumentStyle();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_GetLength(wxStyledTextCtrl* self)
{
    return self->GetLength();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_GetCharAt(wxStyledTextCtrl* self, int pos)
{
    return self->GetCharAt(pos);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_GetCurrentPos(wxStyledTextCtrl* self)
{
    return self->GetCurrentPos();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_GetAnchor(wxStyledTextCtrl* self)
{
    return self->GetAnchor();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_GetStyleAt(wxStyledTextCtrl* self, int pos)
{
    return self->GetStyleAt(pos);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_Redo(wxStyledTextCtrl* self)
{
    self->Redo();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetUndoCollection(wxStyledTextCtrl* self, bool collectUndo)
{
    self->SetUndoCollection(collectUndo);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SelectAll(wxStyledTextCtrl* self)
{
    self->SelectAll();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetSavePoint(wxStyledTextCtrl* self)
{
    self->SetSavePoint();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxMemoryBuffer*)
  wxStyledTextCtrl_GetStyledText(wxStyledTextCtrl* self, int startPos, int endPos)
{
    return new wxMemoryBuffer(self->GetStyledText(startPos, endPos));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxStyledTextCtrl_CanRedo(wxStyledTextCtrl* self)
{
    return self->CanRedo()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_MarkerLineFromHandle(wxStyledTextCtrl* self, int handle)
{
    return self->MarkerLineFromHandle(handle);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_MarkerDeleteHandle(wxStyledTextCtrl* self, int handle)
{
    self->MarkerDeleteHandle(handle);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxStyledTextCtrl_GetUndoCollection(wxStyledTextCtrl* self)
{
    return self->GetUndoCollection();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_GetViewWhiteSpace(wxStyledTextCtrl* self)
{
    return self->GetViewWhiteSpace();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetViewWhiteSpace(wxStyledTextCtrl* self, int viewWS)
{
    self->SetViewWhiteSpace(viewWS);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_PositionFromPoint(wxStyledTextCtrl* self, wxPoint pt)
{
    return self->PositionFromPoint(pt);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_PositionFromPointClose(wxStyledTextCtrl* self, int x, int y)
{
    return self->PositionFromPointClose(x, y);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_GotoLine(wxStyledTextCtrl* self, int line)
{
    self->GotoLine(line);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_GotoPos(wxStyledTextCtrl* self, int pos)
{
    self->GotoPos(pos);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetAnchor(wxStyledTextCtrl* self, int posAnchor)
{
    self->SetAnchor(posAnchor);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxStyledTextCtrl_GetCurLine(wxStyledTextCtrl* self, int* linePos)
{
    return new wxString(self->GetCurLine(linePos));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_GetEndStyled(wxStyledTextCtrl* self)
{
    return self->GetEndStyled();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_ConvertEOLs(wxStyledTextCtrl* self, int eolMode)
{
    self->ConvertEOLs(eolMode);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_GetEOLMode(wxStyledTextCtrl* self)
{
    return self->GetEOLMode();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetEOLMode(wxStyledTextCtrl* self, int eolMode)
{
    self->SetEOLMode(eolMode);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_StartStyling(wxStyledTextCtrl* self, int pos, int mask)
{
    self->StartStyling(pos, mask);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetStyling(wxStyledTextCtrl* self, int length, int style)
{
    self->SetStyling(length, style);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxStyledTextCtrl_GetBufferedDraw(wxStyledTextCtrl* self)
{
    return self->GetBufferedDraw();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetBufferedDraw(wxStyledTextCtrl* self, bool buffered)
{
    self->SetBufferedDraw(buffered);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetTabWidth(wxStyledTextCtrl* self, int tabWidth)
{
    self->SetTabWidth(tabWidth);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_GetTabWidth(wxStyledTextCtrl* self)
{
    return self->GetTabWidth();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetCodePage(wxStyledTextCtrl* self, int codePage)
{
    self->SetCodePage(codePage);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_MarkerDefine(wxStyledTextCtrl* self, int markerNumber, int markerSymbol, wxColour* foregroundArg, wxColour* backgroundArg)
{
    wxColour foreground;
    wxColour background;
    if (backgroundArg)
       background = *backgroundArg;
    if (foregroundArg)
       foreground = *foregroundArg;

    self->MarkerDefine(markerNumber, markerSymbol, foreground, background);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_MarkerSetForeground(wxStyledTextCtrl* self, int markerNumber, wxColour* fore)
{
    self->MarkerSetForeground(markerNumber, *fore);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_MarkerSetBackground(wxStyledTextCtrl* self, int markerNumber, wxColour* back)
{
    self->MarkerSetBackground(markerNumber, *back);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_MarkerAdd(wxStyledTextCtrl* self, int line, int markerNumber)
{
    return self->MarkerAdd(line, markerNumber);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_MarkerDelete(wxStyledTextCtrl* self, int line, int markerNumber)
{
    self->MarkerDelete(line, markerNumber);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_MarkerDeleteAll(wxStyledTextCtrl* self, int markerNumber)
{
    self->MarkerDeleteAll(markerNumber);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_MarkerGet(wxStyledTextCtrl* self, int line)
{
    return self->MarkerGet(line);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_MarkerNext(wxStyledTextCtrl* self, int lineStart, int markerMask)
{
    return self->MarkerNext(lineStart, markerMask);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_MarkerPrevious(wxStyledTextCtrl* self, int lineStart, int markerMask)
{
    return self->MarkerPrevious(lineStart, markerMask);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_MarkerDefineBitmap(wxStyledTextCtrl* self, int markerNumber, wxBitmap* bmp)
{
    self->MarkerDefineBitmap(markerNumber, *bmp);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetMarginType(wxStyledTextCtrl* self, int margin, int marginType)
{
    self->SetMarginType(margin, marginType);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_GetMarginType(wxStyledTextCtrl* self, int margin)
{
    return self->GetMarginType(margin);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetMarginWidth(wxStyledTextCtrl* self, int margin, int pixelWidth)
{
    self->SetMarginWidth(margin, pixelWidth);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_GetMarginWidth(wxStyledTextCtrl* self, int margin)
{
    return self->GetMarginWidth(margin);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetMarginMask(wxStyledTextCtrl* self, int margin, int mask)
{
    self->SetMarginMask(margin, mask);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_GetMarginMask(wxStyledTextCtrl* self, int margin)
{
    return self->GetMarginMask(margin);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetMarginSensitive(wxStyledTextCtrl* self, int margin, bool sensitive)
{
    self->SetMarginSensitive(margin, sensitive);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxStyledTextCtrl_GetMarginSensitive(wxStyledTextCtrl* self, int margin)
{
    return self->GetMarginSensitive(margin);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_StyleClearAll(wxStyledTextCtrl* self)
{
    self->StyleClearAll();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_StyleSetForeground(wxStyledTextCtrl* self, int style, wxColour* fore)
{
    self->StyleSetForeground(style, *fore);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_StyleSetBackground(wxStyledTextCtrl* self, int style, wxColour* back)
{
    self->StyleSetBackground(style, *back);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_StyleSetBold(wxStyledTextCtrl* self, int style, bool bold)
{
    self->StyleSetBold(style, bold);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_StyleSetItalic(wxStyledTextCtrl* self, int style, bool italic)
{
    self->StyleSetItalic(style, italic);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_StyleSetSize(wxStyledTextCtrl* self, int style, int sizePoints)
{
    self->StyleSetSize(style, sizePoints);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_StyleSetFaceName(wxStyledTextCtrl* self, int style, const wxString* fontName)
{
   if (self && fontName)
    self->StyleSetFaceName(style, *fontName);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_StyleSetEOLFilled(wxStyledTextCtrl* self, int style, bool filled)
{
    self->StyleSetEOLFilled(style, filled);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_StyleResetDefault(wxStyledTextCtrl* self)
{
    self->StyleResetDefault();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_StyleSetUnderline(wxStyledTextCtrl* self, int style, bool underline)
{
    self->StyleSetUnderline(style, underline);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_StyleSetCase(wxStyledTextCtrl* self, int style, int caseForce)
{
    self->StyleSetCase(style, caseForce);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_StyleSetCharacterSet(wxStyledTextCtrl* self, int style, int characterSet)
{
    self->StyleSetCharacterSet(style, characterSet);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_StyleSetHotSpot(wxStyledTextCtrl* self, int style, bool hotspot)
{
    self->StyleSetHotSpot(style, hotspot);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetSelForeground(wxStyledTextCtrl* self, bool useSetting, wxColour* fore)
{
    self->SetSelForeground(useSetting, *fore);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetSelBackground(wxStyledTextCtrl* self, bool useSetting, wxColour* back)
{
    self->SetSelBackground(useSetting, *back);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetCaretForeground(wxStyledTextCtrl* self, wxColour* fore)
{
    self->SetCaretForeground(*fore);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_CmdKeyAssign(wxStyledTextCtrl* self, int key, int modifiers, int cmd)
{
    self->CmdKeyAssign(key, modifiers, cmd);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_CmdKeyClear(wxStyledTextCtrl* self, int key, int modifiers)
{
    self->CmdKeyClear(key, modifiers);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_CmdKeyClearAll(wxStyledTextCtrl* self)
{
    self->CmdKeyClearAll();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetStyleBytes(wxStyledTextCtrl* self, int length, char* styleBytes)
{
    self->SetStyleBytes(length, styleBytes);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_StyleSetVisible(wxStyledTextCtrl* self, int style, bool visible)
{
    self->StyleSetVisible(style, visible);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_GetCaretPeriod(wxStyledTextCtrl* self)
{
    return self->GetCaretPeriod();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetCaretPeriod(wxStyledTextCtrl* self, int periodMilliseconds)
{
    self->SetCaretPeriod(periodMilliseconds);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetWordChars(wxStyledTextCtrl* self, const wxString* characters)
{
   if (self && characters)
    self->SetWordChars(*characters);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_BeginUndoAction(wxStyledTextCtrl* self)
{
    self->BeginUndoAction();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_EndUndoAction(wxStyledTextCtrl* self)
{
    self->EndUndoAction();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_IndicatorSetStyle(wxStyledTextCtrl* self, int indic, int style)
{
    self->IndicatorSetStyle(indic, style);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_IndicatorGetStyle(wxStyledTextCtrl* self, int indic)
{
    return self->IndicatorGetStyle(indic);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_IndicatorSetForeground(wxStyledTextCtrl* self, int indic, wxColour* fore)
{
    self->IndicatorSetForeground(indic, *fore);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxColour*)
  wxStyledTextCtrl_IndicatorGetForeground(wxStyledTextCtrl* self, int indic)
{
    return new wxColour(self->IndicatorGetForeground(indic));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetWhitespaceForeground(wxStyledTextCtrl* self, bool useSetting, wxColour* fore)
{
    self->SetWhitespaceForeground(useSetting, *fore);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetWhitespaceBackground(wxStyledTextCtrl* self, bool useSetting, wxColour* back)
{
    self->SetWhitespaceBackground(useSetting, *back);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetStyleBits(wxStyledTextCtrl* self, int bits)
{
    self->SetStyleBits(bits);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_GetStyleBits(wxStyledTextCtrl* self)
{
    return self->GetStyleBits();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetLineState(wxStyledTextCtrl* self, int line, int state)
{
    self->SetLineState(line, state);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_GetLineState(wxStyledTextCtrl* self, int line)
{
    return self->GetLineState(line);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_GetMaxLineState(wxStyledTextCtrl* self)
{
    return self->GetMaxLineState();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxStyledTextCtrl_GetCaretLineVisible(wxStyledTextCtrl* self)
{
    return self->GetCaretLineVisible();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetCaretLineVisible(wxStyledTextCtrl* self, bool show)
{
    self->SetCaretLineVisible(show);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxColour*)
  wxStyledTextCtrl_GetCaretLineBack(wxStyledTextCtrl* self)
{
#if wxCHECK_VERSION(2, 8, 0)
	return new wxColour(self->GetCaretLineBackground());
#else
	return new wxColour(self->GetCaretLineBack());
#endif    
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetCaretLineBack(wxStyledTextCtrl* self, wxColour* back)
{
#if wxCHECK_VERSION(2, 8, 0)
	self->SetCaretLineBackground(*back);
#else
    self->SetCaretLineBack(*back);
#endif 
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_StyleSetChangeable(wxStyledTextCtrl* self, int style, bool changeable)
{
    self->StyleSetChangeable(style, changeable);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_AutoCompShow(wxStyledTextCtrl* self, int lenEntered, const wxString* itemList)
{
   if (self && itemList)
    self->AutoCompShow(lenEntered, *itemList);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_AutoCompCancel(wxStyledTextCtrl* self)
{
    self->AutoCompCancel();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxStyledTextCtrl_AutoCompActive(wxStyledTextCtrl* self)
{
    return self->AutoCompActive();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_AutoCompPosStart(wxStyledTextCtrl* self)
{
    return self->AutoCompPosStart();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_AutoCompComplete(wxStyledTextCtrl* self)
{
    self->AutoCompComplete();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_AutoCompStops(wxStyledTextCtrl* self, const wxString* characterSet)
{
   if (self && characterSet)
    self->AutoCompStops(*characterSet);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_AutoCompSetSeparator(wxStyledTextCtrl* self, int separatorCharacter)
{
    self->AutoCompSetSeparator(separatorCharacter);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_AutoCompGetSeparator(wxStyledTextCtrl* self)
{
    return self->AutoCompGetSeparator();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_AutoCompSelect(wxStyledTextCtrl* self, const wxString* text)
{
   if (self && text)
    self->AutoCompSelect(*text);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_AutoCompSetCancelAtStart(wxStyledTextCtrl* self, bool cancel)
{
    self->AutoCompSetCancelAtStart(cancel);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxStyledTextCtrl_AutoCompGetCancelAtStart(wxStyledTextCtrl* self)
{
    return self->AutoCompGetCancelAtStart();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_AutoCompSetFillUps(wxStyledTextCtrl* self, const wxString* characterSet)
{
   if (self && characterSet)
    self->AutoCompSetFillUps(*characterSet);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_AutoCompSetChooseSingle(wxStyledTextCtrl* self, bool chooseSingle)
{
    self->AutoCompSetChooseSingle(chooseSingle);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxStyledTextCtrl_AutoCompGetChooseSingle(wxStyledTextCtrl* self)
{
    return self->AutoCompGetChooseSingle()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_AutoCompSetIgnoreCase(wxStyledTextCtrl* self, bool ignoreCase)
{
    self->AutoCompSetIgnoreCase(ignoreCase);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxStyledTextCtrl_AutoCompGetIgnoreCase(wxStyledTextCtrl* self)
{
    return self->AutoCompGetIgnoreCase()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_UserListShow(wxStyledTextCtrl* self, int listType, const wxString* itemList)
{
   if (self && itemList)
    self->UserListShow(listType, *itemList);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_AutoCompSetAutoHide(wxStyledTextCtrl* self, bool autoHide)
{
    self->AutoCompSetAutoHide(autoHide);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxStyledTextCtrl_AutoCompGetAutoHide(wxStyledTextCtrl* self)
{
    return self->AutoCompGetAutoHide()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_AutoCompSetDropRestOfWord(wxStyledTextCtrl* self, bool dropRestOfWord)
{
    self->AutoCompSetDropRestOfWord(dropRestOfWord);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxStyledTextCtrl_AutoCompGetDropRestOfWord(wxStyledTextCtrl* self)
{
    return self->AutoCompGetDropRestOfWord()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_RegisterImage(wxStyledTextCtrl* self, int type, wxBitmap* bmp)
{
    self->RegisterImage(type, *bmp);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_ClearRegisteredImages(wxStyledTextCtrl* self)
{
    self->ClearRegisteredImages();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_AutoCompGetTypeSeparator(wxStyledTextCtrl* self)
{
    return self->AutoCompGetTypeSeparator();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_AutoCompSetTypeSeparator(wxStyledTextCtrl* self, int separatorCharacter)
{
    self->AutoCompSetTypeSeparator(separatorCharacter);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetIndent(wxStyledTextCtrl* self, int indentSize)
{
    self->SetIndent(indentSize);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_GetIndent(wxStyledTextCtrl* self)
{
    return self->GetIndent();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetUseTabs(wxStyledTextCtrl* self, bool useTabs)
{
    self->SetUseTabs(useTabs);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxStyledTextCtrl_GetUseTabs(wxStyledTextCtrl* self)
{
    return self->GetUseTabs();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetLineIndentation(wxStyledTextCtrl* self, int line, int indentSize)
{
    self->SetLineIndentation(line, indentSize);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_GetLineIndentation(wxStyledTextCtrl* self, int line)
{
    return self->GetLineIndentation(line);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_GetLineIndentPosition(wxStyledTextCtrl* self, int line)
{
    return self->GetLineIndentPosition(line);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_GetColumn(wxStyledTextCtrl* self, int pos)
{
    return self->GetColumn(pos);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetUseHorizontalScrollBar(wxStyledTextCtrl* self, bool show)
{
    self->SetUseHorizontalScrollBar(show);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxStyledTextCtrl_GetUseHorizontalScrollBar(wxStyledTextCtrl* self)
{
    return self->GetUseHorizontalScrollBar()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetIndentationGuides(wxStyledTextCtrl* self, bool show)
{
    self->SetIndentationGuides(show);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxStyledTextCtrl_GetIndentationGuides(wxStyledTextCtrl* self)
{
    return self->GetIndentationGuides()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetHighlightGuide(wxStyledTextCtrl* self, int column)
{
    self->SetHighlightGuide(column);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_GetHighlightGuide(wxStyledTextCtrl* self)
{
    return self->GetHighlightGuide();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_GetLineEndPosition(wxStyledTextCtrl* self, int line)
{
    return self->GetLineEndPosition(line);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_GetCodePage(wxStyledTextCtrl* self)
{
    return self->GetCodePage();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxColour*)
  wxStyledTextCtrl_GetCaretForeground(wxStyledTextCtrl* self)
{
    return new wxColour(self->GetCaretForeground());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxStyledTextCtrl_GetReadOnly(wxStyledTextCtrl* self)
{
    return self->GetReadOnly()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetCurrentPos(wxStyledTextCtrl* self, int pos)
{
    self->SetCurrentPos(pos);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetSelectionStart(wxStyledTextCtrl* self, int pos)
{
    self->SetSelectionStart(pos);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_GetSelectionStart(wxStyledTextCtrl* self)
{
    return self->GetSelectionStart();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetSelectionEnd(wxStyledTextCtrl* self, int pos)
{
    self->SetSelectionEnd(pos);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_GetSelectionEnd(wxStyledTextCtrl* self)
{
    return self->GetSelectionEnd();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetPrintMagnification(wxStyledTextCtrl* self, int magnification)
{
    self->SetPrintMagnification(magnification);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_GetPrintMagnification(wxStyledTextCtrl* self)
{
    return self->GetPrintMagnification();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetPrintColourMode(wxStyledTextCtrl* self, int mode)
{
    self->SetPrintColourMode(mode);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_GetPrintColourMode(wxStyledTextCtrl* self)
{
    return self->GetPrintColourMode();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_FindText(wxStyledTextCtrl* self, int minPos, int maxPos, const wxString* text, int flags)
{
   if (self && text)
    return self->FindText(minPos, maxPos, *text, flags);
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_FormatRange(wxStyledTextCtrl* self, bool doDraw, int startPos, int endPos, wxDC* draw, wxDC* target, wxRect renderRect, wxRect pageRect)
{
    return self->FormatRange(doDraw, startPos, endPos, draw, target, renderRect, pageRect);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_GetFirstVisibleLine(wxStyledTextCtrl* self)
{
    return self->GetFirstVisibleLine();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxStyledTextCtrl_GetLine(wxStyledTextCtrl* self, int line)
{
    return new wxString(self->GetLine(line));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_GetLineCount(wxStyledTextCtrl* self)
{
    return self->GetLineCount();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetMarginLeft(wxStyledTextCtrl* self, int pixelWidth)
{
    self->SetMarginLeft(pixelWidth);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_GetMarginLeft(wxStyledTextCtrl* self)
{
    return self->GetMarginLeft();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetMarginRight(wxStyledTextCtrl* self, int pixelWidth)
{
    self->SetMarginRight(pixelWidth);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_GetMarginRight(wxStyledTextCtrl* self)
{
    return self->GetMarginRight();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxStyledTextCtrl_GetModify(wxStyledTextCtrl* self)
{
    return self->GetModify();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetSelection(wxStyledTextCtrl* self, int start, int end)
{
    self->SetSelection(start, end);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxStyledTextCtrl_GetSelectedText(wxStyledTextCtrl* self)
{
    return new wxString(self->GetSelectedText());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxStyledTextCtrl_GetTextRange(wxStyledTextCtrl* self, int startPos, int endPos)
{
    return new wxString(self->GetTextRange(startPos, endPos));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_HideSelection(wxStyledTextCtrl* self, bool normal)
{
    self->HideSelection(normal);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_LineFromPosition(wxStyledTextCtrl* self, int pos)
{
    return self->LineFromPosition(pos);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_PositionFromLine(wxStyledTextCtrl* self, int line)
{
    return self->PositionFromLine(line);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_LineScroll(wxStyledTextCtrl* self, int columns, int lines)
{
    self->LineScroll(columns, lines);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_EnsureCaretVisible(wxStyledTextCtrl* self)
{
    self->EnsureCaretVisible();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_ReplaceSelection(wxStyledTextCtrl* self, const wxString* text)
{
   if (self && text)
    self->ReplaceSelection(*text);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetReadOnly(wxStyledTextCtrl* self, bool readOnly)
{
    self->SetReadOnly(readOnly);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxStyledTextCtrl_CanPaste(wxStyledTextCtrl* self)
{
    return self->CanPaste()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxStyledTextCtrl_CanUndo(wxStyledTextCtrl* self)
{
    return self->CanUndo()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_EmptyUndoBuffer(wxStyledTextCtrl* self)
{
    self->EmptyUndoBuffer();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_Undo(wxStyledTextCtrl* self)
{
    self->Undo();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_Cut(wxStyledTextCtrl* self)
{
    self->Cut();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_Copy(wxStyledTextCtrl* self)
{
    self->Copy();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_Paste(wxStyledTextCtrl* self)
{
    self->Paste();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_Clear(wxStyledTextCtrl* self)
{
    self->Clear();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetText(wxStyledTextCtrl* self, const wxString* text)
{
   if (self && text)
    self->SetText(*text);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxStyledTextCtrl_GetText(wxStyledTextCtrl* self)
{
    return new wxString(self->GetText());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_GetTextLength(wxStyledTextCtrl* self)
{
    return self->GetTextLength();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetOvertype(wxStyledTextCtrl* self, bool overtype)
{
    self->SetOvertype(overtype);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxStyledTextCtrl_GetOvertype(wxStyledTextCtrl* self)
{
    return self->GetOvertype();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetCaretWidth(wxStyledTextCtrl* self, int pixelWidth)
{
    self->SetCaretWidth(pixelWidth);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_GetCaretWidth(wxStyledTextCtrl* self)
{
    return self->GetCaretWidth();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetTargetStart(wxStyledTextCtrl* self, int pos)
{
    self->SetTargetStart(pos);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_GetTargetStart(wxStyledTextCtrl* self)
{
    return self->GetTargetStart();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetTargetEnd(wxStyledTextCtrl* self, int pos)
{
    self->SetTargetEnd(pos);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_GetTargetEnd(wxStyledTextCtrl* self)
{
    return self->GetTargetEnd();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_ReplaceTarget(wxStyledTextCtrl* self, const wxString* text)
{
   if (self && text)
    return self->ReplaceTarget(*text);
   else
    return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_ReplaceTargetRE(wxStyledTextCtrl* self, const wxString* text)
{
   if (self && text)
    return self->ReplaceTargetRE(*text);
   else
    return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_SearchInTarget(wxStyledTextCtrl* self, const wxString* text)
{
   if (self && text)
    return self->SearchInTarget(*text);
   else
    return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetSearchFlags(wxStyledTextCtrl* self, int flags)
{
    self->SetSearchFlags(flags);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_GetSearchFlags(wxStyledTextCtrl* self)
{
    return self->GetSearchFlags();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_CallTipShow(wxStyledTextCtrl* self, int pos, const wxString* definition)
{
   if (self && definition)
    self->CallTipShow(pos, *definition);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_CallTipCancel(wxStyledTextCtrl* self)
{
    self->CallTipCancel();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxStyledTextCtrl_CallTipActive(wxStyledTextCtrl* self)
{
    return self->CallTipActive()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_CallTipPosAtStart(wxStyledTextCtrl* self)
{
    return self->CallTipPosAtStart();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_CallTipSetHighlight(wxStyledTextCtrl* self, int start, int end)
{
    self->CallTipSetHighlight(start, end);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_CallTipSetBackground(wxStyledTextCtrl* self, wxColour* back)
{
    self->CallTipSetBackground(*back);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_CallTipSetForeground(wxStyledTextCtrl* self, wxColour* fore)
{
    self->CallTipSetForeground(*fore);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_CallTipSetForegroundHighlight(wxStyledTextCtrl* self, wxColour* fore)
{
    self->CallTipSetForegroundHighlight(*fore);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_CallTipUseStyle(wxStyledTextCtrl* self, int tabsize)
{
   if (self)
      self->CallTipUseStyle(tabsize);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_VisibleFromDocLine(wxStyledTextCtrl* self, int line)
{
    return self->VisibleFromDocLine(line);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_DocLineFromVisible(wxStyledTextCtrl* self, int lineDisplay)
{
    return self->DocLineFromVisible(lineDisplay);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetFoldLevel(wxStyledTextCtrl* self, int line, int level)
{
    self->SetFoldLevel(line, level);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_GetFoldLevel(wxStyledTextCtrl* self, int line)
{
    return self->GetFoldLevel(line);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_GetLastChild(wxStyledTextCtrl* self, int line, int level)
{
    return self->GetLastChild(line, level);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_GetFoldParent(wxStyledTextCtrl* self, int line)
{
    return self->GetFoldParent(line);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_ShowLines(wxStyledTextCtrl* self, int lineStart, int lineEnd)
{
    self->ShowLines(lineStart, lineEnd);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_HideLines(wxStyledTextCtrl* self, int lineStart, int lineEnd)
{
    self->HideLines(lineStart, lineEnd);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxStyledTextCtrl_GetLineVisible(wxStyledTextCtrl* self, int line)
{
	if (self)
    return self->GetLineVisible(line)?1:0;
	else
	return false;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetFoldExpanded(wxStyledTextCtrl* self, int line, bool expanded)
{
	if (self)
    self->SetFoldExpanded(line, expanded);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxStyledTextCtrl_GetFoldExpanded(wxStyledTextCtrl* self, int line)
{
	if (self)
    return self->GetFoldExpanded(line)?1:0;
	else
	return false;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_ToggleFold(wxStyledTextCtrl* self, int line)
{
    self->ToggleFold(line);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_EnsureVisible(wxStyledTextCtrl* self, int line)
{
    self->EnsureVisible(line);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetFoldFlags(wxStyledTextCtrl* self, int flags)
{
    self->SetFoldFlags(flags);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_EnsureVisibleEnforcePolicy(wxStyledTextCtrl* self, int line)
{
    self->EnsureVisibleEnforcePolicy(line);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetTabIndents(wxStyledTextCtrl* self, bool tabIndents)
{
    self->SetTabIndents(tabIndents);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxStyledTextCtrl_GetTabIndents(wxStyledTextCtrl* self)
{
    return self->GetTabIndents();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetBackSpaceUnIndents(wxStyledTextCtrl* self, bool bsUnIndents)
{
    self->SetBackSpaceUnIndents(bsUnIndents);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxStyledTextCtrl_GetBackSpaceUnIndents(wxStyledTextCtrl* self)
{
    return self->GetBackSpaceUnIndents();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetMouseDwellTime(wxStyledTextCtrl* self, int periodMilliseconds)
{
    self->SetMouseDwellTime(periodMilliseconds);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_GetMouseDwellTime(wxStyledTextCtrl* self)
{
    return self->GetMouseDwellTime();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_WordStartPosition(wxStyledTextCtrl* self, int pos, bool onlyWordCharacters)
{
    return self->WordStartPosition(pos, onlyWordCharacters);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_WordEndPosition(wxStyledTextCtrl* self, int pos, bool onlyWordCharacters)
{
    return self->WordEndPosition(pos, onlyWordCharacters);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetWrapMode(wxStyledTextCtrl* self, int mode)
{
    self->SetWrapMode(mode);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_GetWrapMode(wxStyledTextCtrl* self)
{
    return self->GetWrapMode();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetLayoutCache(wxStyledTextCtrl* self, int mode)
{
    self->SetLayoutCache(mode);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_GetLayoutCache(wxStyledTextCtrl* self)
{
    return self->GetLayoutCache();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetScrollWidth(wxStyledTextCtrl* self, int pixelWidth)
{
    self->SetScrollWidth(pixelWidth);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_GetScrollWidth(wxStyledTextCtrl* self)
{
    return self->GetScrollWidth();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_TextWidth(wxStyledTextCtrl* self, int style, const wxString* text)
{
   if (self && text)
    return self->TextWidth(style, *text);
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetEndAtLastLine(wxStyledTextCtrl* self, bool endAtLastLine)
{
    self->SetEndAtLastLine(endAtLastLine);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxStyledTextCtrl_GetEndAtLastLine(wxStyledTextCtrl* self)
{
    return self->GetEndAtLastLine();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_TextHeight(wxStyledTextCtrl* self, int line)
{
    return self->TextHeight(line);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetUseVerticalScrollBar(wxStyledTextCtrl* self, bool show)
{
    self->SetUseVerticalScrollBar(show);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxStyledTextCtrl_GetUseVerticalScrollBar(wxStyledTextCtrl* self)
{
    return self->GetUseVerticalScrollBar()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_AppendText(wxStyledTextCtrl* self, const wxString* text)
{
   if (self && text)
    self->AppendText(*text);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxStyledTextCtrl_GetTwoPhaseDraw(wxStyledTextCtrl* self)
{
    return self->GetTwoPhaseDraw();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetTwoPhaseDraw(wxStyledTextCtrl* self, bool twoPhase)
{
    self->SetTwoPhaseDraw(twoPhase);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_TargetFromSelection(wxStyledTextCtrl* self)
{
    self->TargetFromSelection();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_LinesJoin(wxStyledTextCtrl* self)
{
    self->LinesJoin();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_LinesSplit(wxStyledTextCtrl* self, int pixelWidth)
{
    self->LinesSplit(pixelWidth);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetFoldMarginColour(wxStyledTextCtrl* self, bool useSetting, wxColour* back)
{
    self->SetFoldMarginColour(useSetting, *back);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetFoldMarginHiColour(wxStyledTextCtrl* self, bool useSetting, wxColour* fore)
{
    self->SetFoldMarginHiColour(useSetting, *fore);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_LineDuplicate(wxStyledTextCtrl* self)
{
    self->LineDuplicate();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_HomeDisplay(wxStyledTextCtrl* self)
{
    self->HomeDisplay();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_HomeDisplayExtend(wxStyledTextCtrl* self)
{
    self->HomeDisplayExtend();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_LineEndDisplay(wxStyledTextCtrl* self)
{
    self->LineEndDisplay();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_LineEndDisplayExtend(wxStyledTextCtrl* self)
{
    self->LineEndDisplayExtend();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_MoveCaretInsideView(wxStyledTextCtrl* self)
{
    self->MoveCaretInsideView();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_LineLength(wxStyledTextCtrl* self, int line)
{
    return self->LineLength(line);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_BraceHighlight(wxStyledTextCtrl* self, int pos1, int pos2)
{
    self->BraceHighlight(pos1, pos2);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_BraceBadLight(wxStyledTextCtrl* self, int pos)
{
    self->BraceBadLight(pos);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_BraceMatch(wxStyledTextCtrl* self, int pos)
{
    return self->BraceMatch(pos);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxStyledTextCtrl_GetViewEOL(wxStyledTextCtrl* self)
{
    return self->GetViewEOL()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetViewEOL(wxStyledTextCtrl* self, bool visible)
{
    self->SetViewEOL(visible);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_GetDocPointer(wxStyledTextCtrl* self)
{
    self->GetDocPointer();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetDocPointer(wxStyledTextCtrl* self, void* docPointer)
{
    self->SetDocPointer(docPointer);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetModEventMask(wxStyledTextCtrl* self, int mask)
{
    self->SetModEventMask(mask);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_GetEdgeColumn(wxStyledTextCtrl* self)
{
    return self->GetEdgeColumn();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetEdgeColumn(wxStyledTextCtrl* self, int column)
{
    self->SetEdgeColumn(column);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_GetEdgeMode(wxStyledTextCtrl* self)
{
    return self->GetEdgeMode();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetEdgeMode(wxStyledTextCtrl* self, int mode)
{
    self->SetEdgeMode(mode);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxColour*)
  wxStyledTextCtrl_GetEdgeColour(wxStyledTextCtrl* self)
{
    return new wxColour(self->GetEdgeColour());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetEdgeColour(wxStyledTextCtrl* self, wxColour* edgeColour)
{
    self->SetEdgeColour(*edgeColour);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SearchAnchor(wxStyledTextCtrl* self)
{
    self->SearchAnchor();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_SearchNext(wxStyledTextCtrl* self, int flags, const wxString* text)
{
   if (self && text)
    return self->SearchNext(flags, *text);
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_SearchPrev(wxStyledTextCtrl* self, int flags, const wxString* text)
{
   if (text)
    return self->SearchPrev(flags, *text);
   else 
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_LinesOnScreen(wxStyledTextCtrl* self)
{
    return self->LinesOnScreen();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_UsePopUp(wxStyledTextCtrl* self, bool allowPopUp)
{
    self->UsePopUp(allowPopUp);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxStyledTextCtrl_SelectionIsRectangle(wxStyledTextCtrl* self)
{
    return self->SelectionIsRectangle()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetZoom(wxStyledTextCtrl* self, int zoom)
{
    self->SetZoom(zoom);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_GetZoom(wxStyledTextCtrl* self)
{
    return self->GetZoom();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_CreateDocument(wxStyledTextCtrl* self)
{
    self->CreateDocument();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_AddRefDocument(wxStyledTextCtrl* self, void* docPointer)
{
    self->AddRefDocument(docPointer);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_ReleaseDocument(wxStyledTextCtrl* self, void* docPointer)
{
    self->ReleaseDocument(docPointer);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_GetModEventMask(wxStyledTextCtrl* self)
{
    return self->GetModEventMask();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetSTCFocus(wxStyledTextCtrl* self, bool focus)
{
    self->SetSTCFocus(focus);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxStyledTextCtrl_GetSTCFocus(wxStyledTextCtrl* self)
{
    return self->GetSTCFocus()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetStatus(wxStyledTextCtrl* self, int statusCode)
{
    self->SetStatus(statusCode);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_GetStatus(wxStyledTextCtrl* self)
{
    return self->GetStatus();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetMouseDownCaptures(wxStyledTextCtrl* self, bool captures)
{
    self->SetMouseDownCaptures(captures);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxStyledTextCtrl_GetMouseDownCaptures(wxStyledTextCtrl* self)
{
    return self->GetMouseDownCaptures()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetSTCCursor(wxStyledTextCtrl* self, int cursorType)
{
    self->SetSTCCursor(cursorType);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_GetSTCCursor(wxStyledTextCtrl* self)
{
    return self->GetSTCCursor();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetControlCharSymbol(wxStyledTextCtrl* self, int symbol)
{
    self->SetControlCharSymbol(symbol);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_GetControlCharSymbol(wxStyledTextCtrl* self)
{
    return self->GetControlCharSymbol();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_WordPartLeft(wxStyledTextCtrl* self)
{
    self->WordPartLeft();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_WordPartLeftExtend(wxStyledTextCtrl* self)
{
    self->WordPartLeftExtend();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_WordPartRight(wxStyledTextCtrl* self)
{
    self->WordPartRight();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_WordPartRightExtend(wxStyledTextCtrl* self)
{
    self->WordPartRightExtend();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetVisiblePolicy(wxStyledTextCtrl* self, int visiblePolicy, int visibleSlop)
{
    self->SetVisiblePolicy(visiblePolicy, visibleSlop);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_DelLineLeft(wxStyledTextCtrl* self)
{
    self->DelLineLeft();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_DelLineRight(wxStyledTextCtrl* self)
{
    self->DelLineRight();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetXOffset(wxStyledTextCtrl* self, int newOffset)
{
    self->SetXOffset(newOffset);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_GetXOffset(wxStyledTextCtrl* self)
{
    return self->GetXOffset();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_ChooseCaretX(wxStyledTextCtrl* self)
{
    self->ChooseCaretX();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetXCaretPolicy(wxStyledTextCtrl* self, int caretPolicy, int caretSlop)
{
    self->SetXCaretPolicy(caretPolicy, caretSlop);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetYCaretPolicy(wxStyledTextCtrl* self, int caretPolicy, int caretSlop)
{
    self->SetYCaretPolicy(caretPolicy, caretSlop);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetPrintWrapMode(wxStyledTextCtrl* self, int mode)
{
    self->SetPrintWrapMode(mode);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_GetPrintWrapMode(wxStyledTextCtrl* self)
{
    return self->GetPrintWrapMode();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetHotspotActiveForeground(wxStyledTextCtrl* self, bool useSetting, wxColour* fore)
{
    self->SetHotspotActiveForeground(useSetting, *fore);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetHotspotActiveBackground(wxStyledTextCtrl* self, bool useSetting, wxColour* back)
{
    self->SetHotspotActiveBackground(useSetting, *back);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetHotspotActiveUnderline(wxStyledTextCtrl* self, bool underline)
{
    self->SetHotspotActiveUnderline(underline);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_StartRecord(wxStyledTextCtrl* self)
{
    self->StartRecord();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_StopRecord(wxStyledTextCtrl* self)
{
    self->StopRecord();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetLexer(wxStyledTextCtrl* self, int lexer)
{
    self->SetLexer(lexer);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_GetLexer(wxStyledTextCtrl* self)
{
    return self->GetLexer();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_Colourise(wxStyledTextCtrl* self, int start, int end)
{
    self->Colourise(start, end);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetProperty(wxStyledTextCtrl* self, const wxString* key, const wxString* value)
{
   if (self && key && value)
    self->SetProperty(*key, *value);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetKeyWords(wxStyledTextCtrl* self, int keywordSet, const wxString* keyWords)
{
   if (self && keyWords)
    self->SetKeyWords(keywordSet, *keyWords);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetLexerLanguage(wxStyledTextCtrl* self, const wxString* language)
{
   if (self && language)
    self->SetLexerLanguage(*language);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_GetCurrentLine(wxStyledTextCtrl* self)
{
    return self->GetCurrentLine();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_StyleSetSpec(wxStyledTextCtrl* self, int styleNum, const wxString* spec)
{
   if (self && spec)
    self->StyleSetSpec(styleNum, *spec);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_StyleSetFont(wxStyledTextCtrl* self, int styleNum, wxFont* font)
{
    self->StyleSetFont(styleNum, *font);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_StyleSetFontAttr(wxStyledTextCtrl* self, int styleNum, int size, const wxString* faceName, bool bold, bool italic, bool underline)
{
   if (self && faceName)
    self->StyleSetFontAttr(styleNum, size, *faceName, bold, italic, underline);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_CmdKeyExecute(wxStyledTextCtrl* self, int cmd)
{
    self->CmdKeyExecute(cmd);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetMargins(wxStyledTextCtrl* self, int left, int right)
{
    self->SetMargins(left, right);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_GetSelection(wxStyledTextCtrl* self, int* startPos, int* endPos)
{
    self->GetSelection(startPos, endPos);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_PointFromPosition(wxStyledTextCtrl* self, int pos, wxPoint* pt)
{
    *pt = self->PointFromPosition(pos);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_ScrollToLine(wxStyledTextCtrl* self, int line)
{
    self->ScrollToLine(line);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_ScrollToColumn(wxStyledTextCtrl* self, int column)
{
    self->ScrollToColumn(column);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextCtrl_SendMsg(wxStyledTextCtrl* self, int msg, int wp, int lp)
{
    return self->SendMsg(msg, wp, lp);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetVScrollBar(wxStyledTextCtrl* self, wxScrollBar* bar)
{
    self->SetVScrollBar(bar);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetHScrollBar(wxStyledTextCtrl* self, wxScrollBar* bar)
{
    self->SetHScrollBar(bar);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxStyledTextCtrl_GetLastKeydownProcessed(wxStyledTextCtrl* self)
{
    return self->GetLastKeydownProcessed()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextCtrl_SetLastKeydownProcessed(wxStyledTextCtrl* self, bool val)
{
    self->SetLastKeydownProcessed(val);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxStyledTextCtrl_SaveFile(wxStyledTextCtrl* self, const wxString* filename)
{
   if (self && filename)
    return self->SaveFile(*filename);
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxStyledTextCtrl_LoadFile(wxStyledTextCtrl* self, const wxString* filename)
{
   if (self && filename)
    return self->LoadFile(*filename);
   else
      return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxStyledTextEvent*)
  wxStyledTextEvent_ctor(wxEventType commandType, int id)
{
    return new wxStyledTextEvent(commandType, id);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextEvent_SetPosition(wxStyledTextEvent* self, int pos)
{
    self->SetPosition(pos);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextEvent_SetKey(wxStyledTextEvent* self, int k)
{
    self->SetKey(k);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextEvent_SetModifiers(wxStyledTextEvent* self, int m)
{
    self->SetModifiers(m);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextEvent_SetModificationType(wxStyledTextEvent* self, int t)
{
    self->SetModificationType(t);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextEvent_SetText(wxStyledTextEvent* self, const wxString* t)
{
   if (self && t)
    self->SetText(*t);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextEvent_SetLength(wxStyledTextEvent* self, int len)
{
    self->SetLength(len);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextEvent_SetLinesAdded(wxStyledTextEvent* self, int num)
{
    self->SetLinesAdded(num);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextEvent_SetLine(wxStyledTextEvent* self, int val)
{
    self->SetLine(val);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextEvent_SetFoldLevelNow(wxStyledTextEvent* self, int val)
{
    self->SetFoldLevelNow(val);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextEvent_SetFoldLevelPrev(wxStyledTextEvent* self, int val)
{
    self->SetFoldLevelPrev(val);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextEvent_SetMargin(wxStyledTextEvent* self, int val)
{
    self->SetMargin(val);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextEvent_SetMessage(wxStyledTextEvent* self, int val)
{
    self->SetMessage(val);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextEvent_SetWParam(wxStyledTextEvent* self, int val)
{
    self->SetWParam(val);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextEvent_SetLParam(wxStyledTextEvent* self, int val)
{
    self->SetLParam(val);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextEvent_SetListType(wxStyledTextEvent* self, int val)
{
    self->SetListType(val);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextEvent_SetX(wxStyledTextEvent* self, int val)
{
    self->SetX(val);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextEvent_SetY(wxStyledTextEvent* self, int val)
{
    self->SetY(val);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextEvent_SetDragText(wxStyledTextEvent* self, const wxString* val)
{
   if (self && val)
    self->SetDragText(*val);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextEvent_SetDragAllowMove(wxStyledTextEvent* self, bool val)
{
    self->SetDragAllowMove(val);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStyledTextEvent_SetDragResult(wxStyledTextEvent* self, wxDragResult val)
{
    self->SetDragResult(val);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextEvent_GetPosition(wxStyledTextEvent* self)
{
    return self->GetPosition();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextEvent_GetKey(wxStyledTextEvent* self)
{
    return self->GetKey();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextEvent_GetModifiers(wxStyledTextEvent* self)
{
    return self->GetModifiers();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextEvent_GetModificationType(wxStyledTextEvent* self)
{
    return self->GetModificationType();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxStyledTextEvent_GetText(wxStyledTextEvent* self)
{
    return new wxString(self->GetText());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextEvent_GetLength(wxStyledTextEvent* self)
{
    return self->GetLength();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextEvent_GetLinesAdded(wxStyledTextEvent* self)
{
    return self->GetLinesAdded();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextEvent_GetLine(wxStyledTextEvent* self)
{
    return self->GetLine();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextEvent_GetFoldLevelNow(wxStyledTextEvent* self)
{
    return self->GetFoldLevelNow();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextEvent_GetFoldLevelPrev(wxStyledTextEvent* self)
{
    return self->GetFoldLevelPrev();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextEvent_GetMargin(wxStyledTextEvent* self)
{
    return self->GetMargin();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextEvent_GetMessage(wxStyledTextEvent* self)
{
    return self->GetMessage();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextEvent_GetWParam(wxStyledTextEvent* self)
{
    return self->GetWParam();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextEvent_GetLParam(wxStyledTextEvent* self)
{
    return self->GetLParam();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextEvent_GetListType(wxStyledTextEvent* self)
{
    return self->GetListType();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextEvent_GetX(wxStyledTextEvent* self)
{
    return self->GetX();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStyledTextEvent_GetY(wxStyledTextEvent* self)
{
    return self->GetY();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxStyledTextEvent_GetDragText(wxStyledTextEvent* self)
{
    return new wxString(self->GetDragText());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxStyledTextEvent_GetDragAllowMove(wxStyledTextEvent* self)
{
    return self->GetDragAllowMove()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxDragResult*)
  wxStyledTextEvent_GetDragResult(wxStyledTextEvent* self)
{
    return new wxDragResult(self->GetDragResult());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxStyledTextEvent_GetShift(wxStyledTextEvent* self)
{
    return self->GetShift()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxStyledTextEvent_GetControl(wxStyledTextEvent* self)
{
    return self->GetControl()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxStyledTextEvent_GetAlt(wxStyledTextEvent* self)
{
    return self->GetAlt()?1:0;
}

#endif

