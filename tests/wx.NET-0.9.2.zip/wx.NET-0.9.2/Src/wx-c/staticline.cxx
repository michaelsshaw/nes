//-----------------------------------------------------------------------------
// wx.NET - staticline.cxx
//
// The wxStaticLine proxy interface.
//
// Written by Robert Roebling
// (C) 2003 by Robert Roebling
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: staticline.cxx,v 1.8 2010/06/06 08:53:52 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/statline.h>
#include "local_events.h"

//-----------------------------------------------------------------------------

class _StaticLine : public wxStaticLine
{
public:
    DECLARE_OBJECTDELETED(_StaticLine)
};

//-----------------------------------------------------------------------------
// C stubs for class methods
//-----------------------------------------------------------------------------

WXNET_EXPORT(wxStaticLine*)
  wxStaticLine_ctor()
{
	return new _StaticLine();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxStaticLine_Create(wxStaticLine *self, wxWindow* parent, wxWindowID id, int posX, int posY, int width, int height, unsigned int style, const wxString* nameArg)
{
   wxString name;
	if (nameArg == NULL)
		name = wxT("staticLine");
   else
      name=*nameArg;

	return self->Create(parent, id, wxPoint(posX, posY), wxSize(width, height), style, name);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxStaticLine_IsVertical(wxStaticLine* self)
{
	return self->IsVertical()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxStaticLine_GetDefaultSize(wxStaticLine* self)
{
	return self->GetDefaultSize();
}


