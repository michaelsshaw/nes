//-----------------------------------------------------------------------------
// wx.NET - accel.cxx
//
// The wxAccelerator* proxy interfaces
//
// Written by Alexander Olk (xenomorph2@onlinehome.de)
// (C) 2004 by Alexander Olk
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: accel.cxx,v 1.12 2010/07/12 21:43:57 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include "local_events.h"

WXNET_EXPORT(wxAcceleratorEntry*)
 wxAcceleratorEntry_ctor(int flags, int keyCode, int cmd, wxMenuItem* item)
{
	return new wxAcceleratorEntry(flags, keyCode, cmd, item);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
 wxAcceleratorEntry_dtor(wxAcceleratorEntry* self)
{
	WXNET_DEL(self);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
 wxAcceleratorEntry_Set(wxAcceleratorEntry* self, int flags, int keyCode, int cmd, wxMenuItem* item)
{
	self->Set(flags, keyCode, cmd, item);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
 wxAcceleratorEntry_SetMenuItem(wxAcceleratorEntry* self, wxMenuItem* item)
{
	self->SetMenuItem(item);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
 wxAcceleratorEntry_GetFlags(wxAcceleratorEntry* self)
{
	return self->GetFlags();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
 wxAcceleratorEntry_GetKeyCode(wxAcceleratorEntry* self)
{
	return self->GetKeyCode();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
 wxAcceleratorEntry_GetCommand(wxAcceleratorEntry* self)
{
	return self->GetCommand();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxMenuItem*)
 wxAcceleratorEntry_GetMenuItem(wxAcceleratorEntry* self)
{
	return self->GetMenuItem();
}

//-----------------------------------------------------------------------------
// wxAcceleratorTable

WXNET_EXPORT(wxAcceleratorTable*)
 wxAcceleratorTable_ctor()
{
	return new wxAcceleratorTable();
}

//-----------------------------------------------------------------------------

class wxAcceleratorArrayNet
{
   wxAcceleratorEntry* m_entries;
   int                 m_size;

public:
   wxAcceleratorArrayNet(int size) : m_size(size)
   {
      m_entries=new wxAcceleratorEntry[size];
   }
   ~wxAcceleratorArrayNet()
   {
      if (m_entries)
         delete [] m_entries;
      m_size=0;
   }

   void Set(int i, const wxAcceleratorEntry& entry)
   {
      if (i >= 0 && i < m_size)
         m_entries[i]=entry;
   }

   const wxAcceleratorEntry* Data() const { return this->m_entries; }
   int Size() const { return this->m_size; }
};

WXNET_EXPORT(wxAcceleratorArrayNet*)
 wxAcceleratorArrayNet_ctor(int size)
{
   return new wxAcceleratorArrayNet(size);
}

WXNET_EXPORT(void)
 wxAcceleratorArrayNet_Set(wxAcceleratorArrayNet* self, int pos, const wxAcceleratorEntry* entry)
{
   if (self && entry)
      self->Set(pos, *entry);
}

WXNET_EXPORT(void)
 wxAcceleratorArrayNet_dtor(wxAcceleratorArrayNet* self)
{
   if (self)
      delete self;
}

WXNET_EXPORT(wxAcceleratorTable*)
 wxAcceleratorTable_ctorWithEntries(const wxAcceleratorArrayNet* entries)
{
   if (entries)
	   return new wxAcceleratorTable(entries->Size(), entries->Data());
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
 wxAcceleratorTable_Ok(wxAcceleratorTable* self)
{
	return self->Ok()?1:0;
}
