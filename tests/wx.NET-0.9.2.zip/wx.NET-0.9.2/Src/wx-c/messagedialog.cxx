//-----------------------------------------------------------------------------
// wx.NET - messagedialog.cxx
//
// The wxMessageDialog proxy interface.
//
// Written by Jason Perkins (jason@379.com)
// (C) 2003 by 379, Inc.
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: messagedialog.cxx,v 1.7 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include "local_events.h"

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxMsgBox(wxWindow* parent, const wxString* msg, const wxString* cap, unsigned int style, int posX, int posY)
{
   if (cap && msg)
	   return wxMessageBox(*msg, *cap, style, parent, posX, posY);
   else
      return 0;
}

//-----------------------------------------------------------------------------

class _MessageDialog : public wxMessageDialog
{
public:
    _MessageDialog(wxWindow* parent, const wxString& message, const wxString& caption, unsigned int style, const wxPoint& pos)
        : wxMessageDialog(parent, message, caption, style, pos)
    {
    }

    DECLARE_OBJECTDELETED(_MessageDialog)
};

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxMessageDialog*)
  wxMessageDialog_ctor(wxWindow *parent, const wxString* message, const wxString* caption, unsigned int style, int posX, int posY)
{
   wxString cptn;
	if (caption == NULL)
        cptn = wxMessageBoxCaptionStr;
    else 
        cptn = *caption;

   if (message)
	   return new _MessageDialog(parent, *message, cptn, style, wxPoint(posX, posY));
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxMessageDialog_ShowModal(wxMessageDialog* self)
{
	return self->ShowModal();
}

//-----------------------------------------------------------------------------

