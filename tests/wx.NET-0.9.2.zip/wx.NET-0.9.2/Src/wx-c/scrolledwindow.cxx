//-----------------------------------------------------------------------------
// wx.NET - scrolledwindow.cxx
//
// The wxScrolledWindow proxy interface.
//
// Written by Jason Perkins (jason@379.com)
// (C) 2003 by 379, Inc.
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: scrolledwindow.cxx,v 1.17 2009/01/06 18:24:22 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/scrolwin.h>
#include "local_events.h"

//-----------------------------------------------------------------------------

class _ScrolledWindow : public wxScrolledWindow, public ValidatorStub
{
public:
	_ScrolledWindow(wxWindow* parent, wxWindowID id, const wxPoint& pos,
					const wxSize& size, long style, const wxString& name)
		: wxScrolledWindow(parent, id, pos, size, style, name) { }

    DECLARE_OBJECTDELETED(_ScrolledWindow)
    
#include "panel.inc"
};

//-----------------------------------------------------------------------------
// C stubs for class methods

WXNET_EXPORT(wxScrolledWindow*)
  wxScrollWnd_ctor(wxWindow *parent, wxWindowID id, int posX, int posY,
					               int width, int height, unsigned int style, const wxString* nameArg)
{
   wxString name;
   if (nameArg == NULL)
		name = wxT("scrolled");
   else
      name=*nameArg;

	return new _ScrolledWindow(parent, id, wxPoint(posX, posY), wxSize(width, height), style, name);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxScrollWnd_PrepareDC(wxScrolledWindow* self, wxDC* dc)
{
	self->PrepareDC(*dc);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxScrollWnd_SetScrollbars(wxScrolledWindow* self, int pixelsPerUnitX, int pixelsPerUnitY,
							   int noUnitsX, int noUnitsY, int xPos, int yPos, bool noRefresh)
{
	self->SetScrollbars(pixelsPerUnitX, pixelsPerUnitY, noUnitsX, noUnitsY, xPos, yPos, noRefresh);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxScrollWnd_GetViewStart(wxScrolledWindow* self, int* x, int* y)
{
    self->GetViewStart(x, y);
}

WXNET_EXPORT(void)
  wxScrollWnd_GetScrollPixelsPerUnit(wxScrolledWindow* self, int* xUnit, int* yUnit)
{
    self->GetScrollPixelsPerUnit(xUnit, yUnit);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxScrollWnd_CalcScrolledPosition(wxScrolledWindow* self, int x, int y, int* xx, int* yy)
{
	self->CalcScrolledPosition(x, y, xx, yy);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxScrollWnd_CalcUnscrolledPosition(wxScrolledWindow* self, int x, int y, int* xx, int* yy)
{
	self->CalcUnscrolledPosition(x, y, xx, yy);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxScrollWnd_GetVirtualSize(wxScrolledWindow* self, int* x, int* y)
{
	self->GetVirtualSize(x, y);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxScrollWnd_Scroll(wxScrolledWindow* self, int x, int y)
{
	self->Scroll(x, y);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxScrollWnd_SetScrollRate(wxScrolledWindow* self, int xstep, int ystep)
{
	self->SetScrollRate(xstep, ystep);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxScrollWnd_SetTargetWindow(wxScrolledWindow* self, wxWindow* window)
{
	self->SetTargetWindow(window);
}
