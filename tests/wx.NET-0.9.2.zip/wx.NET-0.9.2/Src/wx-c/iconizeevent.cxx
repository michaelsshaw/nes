//-----------------------------------------------------------------------------
// wx.NET - iconizeevent.cxx
// 
// The wxIconizeEvent proxy interface.
//
// Written by Alexander Olk (xenomorph2@onlinehome.de)
// (C) 2004 by Alexander Olk
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: iconizeevent.cxx,v 1.3 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#ifndef WXNET_GLOBAL_H
#include "wxnet_globals.h"
#endif

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxIconizeEvent*)
  wxIconizeEvent_ctor(wxEventType type)
{
    return new wxIconizeEvent(type);
}

WXNET_EXPORT(bool)
  wxIconizeEvent_Iconized(wxIconizeEvent* self)
{
	return self->Iconized()?1:0;
}
