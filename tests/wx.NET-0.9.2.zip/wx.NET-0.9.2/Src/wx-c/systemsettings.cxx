//-----------------------------------------------------------------------------
// wx.NET - systemsettings.cxx
//
// The wxSystemSettings proxy interface.
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 by Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: systemsettings.cxx,v 1.5 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/settings.h>
#ifndef WXNET_GLOBAL_H
#include "wxnet_globals.h"
#endif

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxColour*)
  wxSystemSettings_GetColour(wxSystemColour index)
{
    return new wxColour(wxSystemSettings::GetColour(index));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxFont*)
  wxSystemSettings_GetFont(wxSystemFont index)
{
    return new wxFont(wxSystemSettings::GetFont(index));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxSystemSettings_GetMetric(wxSystemMetric index)
{
    return wxSystemSettings::GetMetric(index);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxSystemSettings_HasFeature(wxSystemFeature index)
{
    return wxSystemSettings::HasFeature(index)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxSystemScreenType)
  wxSystemSettings_GetScreenType()
{
    return wxSystemSettings::GetScreenType();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxSystemSettings_SetScreenType(wxSystemScreenType screen)
{
    wxSystemSettings::SetScreenType(screen);
}

