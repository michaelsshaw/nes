//-----------------------------------------------------------------------------
// wx.NET - tipwindow.cxx
//
// The wxTipWindow proxy interface.
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 by Bryan Bulten 
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: tipwindow.cxx,v 1.5 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/tipwin.h>
#include "local_events.h"

//-----------------------------------------------------------------------------

class _TipWindow : public wxTipWindow
{
public:
    _TipWindow(wxWindow *parent, const wxString& text, wxCoord maxLength, 
               wxTipWindow** windowPtr, wxRect* rectBound)
        : wxTipWindow(parent, text, maxLength, windowPtr, rectBound) { }

    DECLARE_OBJECTDELETED(_TipWindow)
};

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxTipWindow*)
  wxTipWindow_ctor(wxWindow* parent, const wxString* text, wxCoord maxLength, int x, int y, int width, int height)
{
   if (text)
   {
      wxRect rect(x, y, width, height);
      return new _TipWindow(parent, *text, maxLength, NULL, &rect);
   }
   else
      return NULL;
}

WXNET_EXPORT(wxTipWindow*)
  wxTipWindow_ctorNoRect(wxWindow* parent, const wxString* text, wxCoord maxLength)
{
   if (text)
    return new _TipWindow(parent, *text, maxLength, NULL, NULL);
   else
      return NULL;
}

//-----------------------------------------------------------------------------

/*extern "C" WXEXPORT
void wxTipWindow_SetTipWindowPtr(wxTipWindow* self, * wxTipWindow* windowPtr)
{
    self->SetTipWindowPtr(wxTipWindow* windowPtr);
}*/

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTipWindow_SetBoundingRect(wxTipWindow* self, wxRect* rectBound)
{
    self->SetBoundingRect(*rectBound);
}

