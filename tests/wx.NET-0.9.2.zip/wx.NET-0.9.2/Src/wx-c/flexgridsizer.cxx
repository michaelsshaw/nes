//-----------------------------------------------------------------------------
// wx.NET - flexgridsizer.cxx
//
// The wxFlexGridSizer proxy interface
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 by Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: flexgridsizer.cxx,v 1.5 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/sizer.h>
#include "local_events.h"

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxFlexGridSizer*)
  wxFlexGridSizer_ctor(int rows, int cols, int vgap, int hgap)
{
	return new wxFlexGridSizer(rows, cols, vgap, hgap);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxFlexGridSizer_dtor(wxFlexGridSizer* self)
{
	WXNET_DEL(self);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxFlexGridSizer_RecalcSizes(wxFlexGridSizer* self)
{
	self->RecalcSizes();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxFlexGridSizer_CalcMin(wxFlexGridSizer* self, wxSize* size)
{
	*size = self->CalcMin();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxFlexGridSizer_AddGrowableRow(wxFlexGridSizer* self, size_t idx)
{
	self->AddGrowableRow(idx);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxFlexGridSizer_RemoveGrowableRow(wxFlexGridSizer* self, size_t idx)
{
	self->RemoveGrowableRow(idx);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxFlexGridSizer_AddGrowableCol(wxFlexGridSizer* self, size_t idx)
{
	self->AddGrowableCol(idx);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxFlexGridSizer_RemoveGrowableCol(wxFlexGridSizer* self, size_t idx)
{
	self->RemoveGrowableCol(idx);
}

//-----------------------------------------------------------------------------
