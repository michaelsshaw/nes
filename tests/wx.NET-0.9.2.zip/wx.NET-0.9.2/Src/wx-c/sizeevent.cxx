//-----------------------------------------------------------------------------
// wx.NET - sizeevent.cxx
// 
// The wxSizeEvent proxy interface.
//
// Written by Alexander Olk (xenomorph2@onlinehome.de)
// (C) 2004 by Alexander Olk
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// sizeevent.cxx,v 1.5 2008/12/25 17:01:35 harald_meyer Exp
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#ifndef WXNET_GLOBAL_H
#include "wxnet_globals.h"
#endif

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxSizeEvent*)
  wxSizeEvent_ctor()
{
    return new wxSizeEvent();
}

WXNET_EXPORT(wxSizeEvent*)
  wxSizeEvent_ctor2(int width, int height, int id)
{
    return new wxSizeEvent(wxSize(width, height), id);
}

WXNET_EXPORT(void)
  wxSizeEvent_GetSize(wxSizeEvent* self, wxSize* size)
{
    *size=self->GetSize();
}

