//-----------------------------------------------------------------------------
// wx.NET - fontdialog.cxx
//
// The wxFontDialog proxy interface.
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 by Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: fontdialog.cxx,v 1.7 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/fontdlg.h>
#include "local_events.h"

//-----------------------------------------------------------------------------

class _FontDialog : public wxFontDialog
{
public:
    DECLARE_OBJECTDELETED(_FontDialog)
};

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxFontDialog*)
  wxFontDialog_ctor()
{
    return new _FontDialog();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxFontDialog_Create(wxFontDialog* self, wxWindow *parent, const wxFontData* data)
{
    return self->Create(parent, *data)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxFontDialog_dtor(wxFontDialog* self)
{
    WXNET_DEL( self );
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxFontDialog_ShowModal(wxFontDialog* self)
{
    return self->ShowModal();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxFontData*)
  wxFontDialog_GetFontData(wxFontDialog* self)
{
    return &(self->GetFontData());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxFontData*)
  wxFontData_ctor()
{
	return new wxFontData();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxFontData_dtor(wxFontData* self)
{
	WXNET_DEL( self );
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxFontData_SetAllowSymbols(wxFontData* self, bool flag)
{
	self->SetAllowSymbols(flag);
}

WXNET_EXPORT(bool)
  wxFontData_GetAllowSymbols(wxFontData* self)
{
	return self->GetAllowSymbols()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxFontData_SetColour(wxFontData* self, const wxColour* colour)
{
	self->SetColour(*colour);
}

WXNET_EXPORT(wxColour*)
  wxFontData_GetColour(wxFontData* self)
{
    return new wxColour(self->GetColour());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxFontData_SetShowHelp(wxFontData* self, bool flag)
{
	self->SetShowHelp(flag);
}

WXNET_EXPORT(bool)
  wxFontData_GetShowHelp(wxFontData* self)
{
	return self->GetShowHelp()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxFontData_EnableEffects(wxFontData* self, bool flag)
{
	self->EnableEffects(flag);
}

WXNET_EXPORT(bool)
  wxFontData_GetEnableEffects(wxFontData* self)
{
	return self->GetEnableEffects()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxFontData_SetInitialFont(wxFontData* self, const wxFont* font)
{
	self->SetInitialFont(*font);
}

WXNET_EXPORT(wxFont*)
  wxFontData_GetInitialFont(wxFontData* self)
{
	return new wxFont(self->GetInitialFont());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxFontData_SetChosenFont(wxFontData* self, const wxFont* font)
{
	self->SetChosenFont(*font);
}

WXNET_EXPORT(wxFont*)
  wxFontData_GetChosenFont(wxFontData* self)
{
	return new wxFont(self->GetChosenFont());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxFontData_SetRange(wxFontData* self, int minRange, int maxRange)
{
	self->SetRange(minRange, maxRange);
}

//-----------------------------------------------------------------------------

