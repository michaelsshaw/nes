//-----------------------------------------------------------------------------
// wx.NET - printdata.cxx
//
// The wxPrint data classes proxy interface.
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 by Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: printdata.cxx,v 1.7 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/cmndata.h>
#include "wxnet_globals.h"

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxPageSetupDialogData*)
  wxPageSetupDialogData_ctor()
{
    return new wxPageSetupDialogData();
}

WXNET_EXPORT(wxPageSetupDialogData*)
  wxPageSetupDialogData_ctorPrintSetup(wxPageSetupDialogData* dialogData)
{
    return new wxPageSetupDialogData(*dialogData);
}

WXNET_EXPORT(wxPageSetupDialogData*)
  wxPageSetupDialogData_ctorPrintData(wxPrintData* printData)
{
    return new wxPageSetupDialogData(*printData);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPageSetupDialogData_GetPaperSize(wxPageSetupDialogData* self, wxSize* size)
{
    *size = self->GetPaperSize();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxPaperSize)
  wxPageSetupDialogData_GetPaperId(wxPageSetupDialogData* self)
{
    return self->GetPaperId();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPageSetupDialogData_GetMinMarginTopLeft(wxPageSetupDialogData* self, wxPoint* pt)
{
    *pt = self->GetMinMarginTopLeft();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPageSetupDialogData_GetMinMarginBottomRight(wxPageSetupDialogData* self, wxPoint* pt)
{
    *pt = self->GetMinMarginBottomRight();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPageSetupDialogData_GetMarginTopLeft(wxPageSetupDialogData* self, wxPoint* pt)
{
    *pt = self->GetMarginTopLeft();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPageSetupDialogData_GetMarginBottomRight(wxPageSetupDialogData* self, wxPoint* pt)
{
    *pt = self->GetMarginBottomRight();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxPageSetupDialogData_GetDefaultMinMargins(wxPageSetupDialogData* self)
{
    return self->GetDefaultMinMargins()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxPageSetupDialogData_GetEnableMargins(wxPageSetupDialogData* self)
{
    return self->GetEnableMargins()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxPageSetupDialogData_GetEnableOrientation(wxPageSetupDialogData* self)
{
    return self->GetEnableOrientation()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxPageSetupDialogData_GetEnablePaper(wxPageSetupDialogData* self)
{
    return self->GetEnablePaper()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxPageSetupDialogData_GetEnablePrinter(wxPageSetupDialogData* self)
{
    return self->GetEnablePrinter()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxPageSetupDialogData_GetDefaultInfo(wxPageSetupDialogData* self)
{
    return self->GetDefaultInfo()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxPageSetupDialogData_GetEnableHelp(wxPageSetupDialogData* self)
{
    return self->GetEnableHelp()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxPageSetupDialogData_Ok(wxPageSetupDialogData* self)
{
    return self->Ok()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPageSetupDialogData_SetPaperSizeSize(wxPageSetupDialogData* self, wxSize* sz)
{
    self->SetPaperSize(*sz);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPageSetupDialogData_SetPaperId(wxPageSetupDialogData* self, wxPaperSize id)
{
    self->SetPaperId(id);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPageSetupDialogData_SetPaperSize(wxPageSetupDialogData* self, wxPaperSize id)
{
    self->SetPaperSize(id);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPageSetupDialogData_SetMinMarginTopLeft(wxPageSetupDialogData* self, wxPoint* pt)
{
    self->SetMinMarginTopLeft(*pt);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPageSetupDialogData_SetMinMarginBottomRight(wxPageSetupDialogData* self, wxPoint* pt)
{
    self->SetMinMarginBottomRight(*pt);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPageSetupDialogData_SetMarginTopLeft(wxPageSetupDialogData* self, wxPoint* pt)
{
    self->SetMarginTopLeft(*pt);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPageSetupDialogData_SetMarginBottomRight(wxPageSetupDialogData* self, wxPoint* pt)
{
    self->SetMarginBottomRight(*pt);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPageSetupDialogData_SetDefaultMinMargins(wxPageSetupDialogData* self, bool flag)
{
    self->SetDefaultMinMargins(flag);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPageSetupDialogData_SetDefaultInfo(wxPageSetupDialogData* self, bool flag)
{
    self->SetDefaultInfo(flag);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPageSetupDialogData_EnableMargins(wxPageSetupDialogData* self, bool flag)
{
    self->EnableMargins(flag);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPageSetupDialogData_EnableOrientation(wxPageSetupDialogData* self, bool flag)
{
    self->EnableOrientation(flag);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPageSetupDialogData_EnablePaper(wxPageSetupDialogData* self, bool flag)
{
    self->EnablePaper(flag);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPageSetupDialogData_EnablePrinter(wxPageSetupDialogData* self, bool flag)
{
    self->EnablePrinter(flag);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPageSetupDialogData_EnableHelp(wxPageSetupDialogData* self, bool flag)
{
    self->EnableHelp(flag);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPageSetupDialogData_CalculateIdFromPaperSize(wxPageSetupDialogData* self)
{
    self->CalculateIdFromPaperSize();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPageSetupDialogData_CalculatePaperSizeFromId(wxPageSetupDialogData* self)
{
    self->CalculatePaperSizeFromId();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxPrintData*)
  wxPageSetupDialogData_GetPrintData(wxPageSetupDialogData* self)
{
    return &(self->GetPrintData());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPageSetupDialogData_SetPrintData(wxPageSetupDialogData* self, wxPrintData* printData)
{
    self->SetPrintData(*printData);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxPrintDialogData*)
  wxPrintDialogData_ctor()
{
    return new wxPrintDialogData();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxPrintDialogData*)
  wxPrintDialogData_ctorDialogData(wxPrintDialogData* dialogData)
{
    return new wxPrintDialogData(*dialogData);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxPrintDialogData*)
  wxPrintDialogData_ctorPrintData(wxPrintData* printData)
{
    return new wxPrintDialogData(*printData);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxPrintDialogData_GetFromPage(wxPrintDialogData* self)
{
    return self->GetFromPage();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxPrintDialogData_GetToPage(wxPrintDialogData* self)
{
    return self->GetToPage();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxPrintDialogData_GetMinPage(wxPrintDialogData* self)
{
    return self->GetMinPage();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxPrintDialogData_GetMaxPage(wxPrintDialogData* self)
{
    return self->GetMaxPage();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxPrintDialogData_GetNoCopies(wxPrintDialogData* self)
{
    return self->GetNoCopies();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxPrintDialogData_GetAllPages(wxPrintDialogData* self)
{
    return self->GetAllPages()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxPrintDialogData_GetSelection(wxPrintDialogData* self)
{
    return self->GetSelection()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxPrintDialogData_GetCollate(wxPrintDialogData* self)
{
    return self->GetCollate()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxPrintDialogData_GetPrintToFile(wxPrintDialogData* self)
{
    return self->GetPrintToFile()?1:0;
}

//-----------------------------------------------------------------------------

#if WXWIN_COMPATIBILITY_2_4
WXNET_EXPORT(bool)
  wxPrintDialogData_GetSetupDialog(wxPrintDialogData* self)
{
    return self->GetSetupDialog()?1:0;
}
#endif

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPrintDialogData_SetFromPage(wxPrintDialogData* self, int v)
{
    self->SetFromPage(v);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPrintDialogData_SetToPage(wxPrintDialogData* self, int v)
{
    self->SetToPage(v);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPrintDialogData_SetMinPage(wxPrintDialogData* self, int v)
{
    self->SetMinPage(v);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPrintDialogData_SetMaxPage(wxPrintDialogData* self, int v)
{
    self->SetMaxPage(v);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPrintDialogData_SetNoCopies(wxPrintDialogData* self, int v)
{
    self->SetNoCopies(v);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPrintDialogData_SetAllPages(wxPrintDialogData* self, bool flag)
{
    self->SetAllPages(flag);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPrintDialogData_SetSelection(wxPrintDialogData* self, bool flag)
{
    self->SetSelection(flag);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPrintDialogData_SetCollate(wxPrintDialogData* self, bool flag)
{
    self->SetCollate(flag);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPrintDialogData_SetPrintToFile(wxPrintDialogData* self, bool flag)
{
    self->SetPrintToFile(flag);
}

//-----------------------------------------------------------------------------

#if WXWIN_COMPATIBILITY_2_4
WXNET_EXPORT(void)
  wxPrintDialogData_SetSetupDialog(wxPrintDialogData* self, bool flag)
{
    self->SetSetupDialog(flag);
}
#endif

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPrintDialogData_EnablePrintToFile(wxPrintDialogData* self, bool flag)
{
    self->EnablePrintToFile(flag);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPrintDialogData_EnableSelection(wxPrintDialogData* self, bool flag)
{
    self->EnableSelection(flag);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPrintDialogData_EnablePageNumbers(wxPrintDialogData* self, bool flag)
{
    self->EnablePageNumbers(flag);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPrintDialogData_EnableHelp(wxPrintDialogData* self, bool flag)
{
    self->EnableHelp(flag);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxPrintDialogData_GetEnablePrintToFile(wxPrintDialogData* self)
{
    return self->GetEnablePrintToFile()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxPrintDialogData_GetEnableSelection(wxPrintDialogData* self)
{
    return self->GetEnableSelection()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxPrintDialogData_GetEnablePageNumbers(wxPrintDialogData* self)
{
    return self->GetEnablePageNumbers()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxPrintDialogData_GetEnableHelp(wxPrintDialogData* self)
{
    return self->GetEnableHelp()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxPrintDialogData_Ok(wxPrintDialogData* self)
{
    return self->Ok()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxPrintData*)
  wxPrintDialogData_GetPrintData(wxPrintDialogData* self)
{
    return &(self->GetPrintData());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPrintDialogData_SetPrintData(wxPrintDialogData* self, wxPrintData* printData)
{
    self->SetPrintData(*printData);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxPrintData*)
  wxPrintData_ctor()
{
    return new wxPrintData();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxPrintData*)
  wxPrintData_ctorPrintData(wxPrintData* printData)
{
    return new wxPrintData(*printData);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxPrintData_GetNoCopies(wxPrintData* self)
{
    return self->GetNoCopies();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxPrintData_GetCollate(wxPrintData* self)
{
    return self->GetCollate()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxPrintData_GetOrientation(wxPrintData* self)
{
    return self->GetOrientation();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxPrintData_Ok(wxPrintData* self)
{
    return self->Ok()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxPrintData_GetPrinterName(wxPrintData* self)
{
    return new wxString(self->GetPrinterName());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxPrintData_GetColour(wxPrintData* self)
{
    return self->GetColour()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxDuplexMode)
  wxPrintData_GetDuplex(wxPrintData* self)
{
    return self->GetDuplex();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxPaperSize)
  wxPrintData_GetPaperId(wxPrintData* self)
{
    return self->GetPaperId();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPrintData_GetPaperSize(wxPrintData* self, wxSize* size)
{
    *size = self->GetPaperSize();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxPrintQuality)
  wxPrintData_GetQuality(wxPrintData* self)
{
    return self->GetQuality();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPrintData_SetNoCopies(wxPrintData* self, int v)
{
    self->SetNoCopies(v);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPrintData_SetCollate(wxPrintData* self, bool flag)
{
    self->SetCollate(flag);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPrintData_SetOrientation(wxPrintData* self, int orient)
{
    self->SetOrientation(orient);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPrintData_SetPrinterName(wxPrintData* self, const wxString* name)
{
   if (self && name)
    self->SetPrinterName(*name);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPrintData_SetColour(wxPrintData* self, bool colour)
{
    self->SetColour(colour);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPrintData_SetDuplex(wxPrintData* self, wxDuplexMode duplex)
{
    self->SetDuplex(duplex);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPrintData_SetPaperId(wxPrintData* self, wxPaperSize sizeId)
{
    self->SetPaperId(sizeId);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPrintData_SetPaperSize(wxPrintData* self, wxSize* sz)
{
    self->SetPaperSize(*sz);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPrintData_SetQuality(wxPrintData* self, wxPrintQuality quality)
{
    self->SetQuality(quality);
}

//-----------------------------------------------------------------------------

#if WXWIN_COMPATIBILITY_2_4
WXNET_EXPORT(wxString*)
  wxPrintData_GetPrinterCommand(wxPrintData* self)
{
    return new wxString(self->GetPrinterCommand());
}
#endif

//-----------------------------------------------------------------------------

#if WXWIN_COMPATIBILITY_2_4
WXNET_EXPORT(wxString*)
  wxPrintData_GetPrinterOptions(wxPrintData* self)
{
    return new wxString(self->GetPrinterOptions());
}
#endif

//-----------------------------------------------------------------------------

#if WXWIN_COMPATIBILITY_2_4
WXNET_EXPORT(wxString*)
  wxPrintData_GetPreviewCommand(wxPrintData* self)
{
    return new wxString(self->GetPreviewCommand());
}
#endif

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxPrintData_GetFilename(wxPrintData* self)
{
    return new wxString(self->GetFilename());
}

//-----------------------------------------------------------------------------

#if WXWIN_COMPATIBILITY_2_4
WXNET_EXPORT(wxString*)
  wxPrintData_GetFontMetricPath(wxPrintData* self)
{
    return new wxString(self->GetFontMetricPath());
}
#endif

//-----------------------------------------------------------------------------

#if WXWIN_COMPATIBILITY_2_4
WXNET_EXPORT(double)
  wxPrintData_GetPrinterScaleX(wxPrintData* self)
{
    return self->GetPrinterScaleX();
}
#endif

//-----------------------------------------------------------------------------

#if WXWIN_COMPATIBILITY_2_4
WXNET_EXPORT(double)
  wxPrintData_GetPrinterScaleY(wxPrintData* self)
{
    return self->GetPrinterScaleY();
}
#endif

//-----------------------------------------------------------------------------

#if WXWIN_COMPATIBILITY_2_4
WXNET_EXPORT(int)
  wxPrintData_GetPrinterTranslateX(wxPrintData* self)
{
    return self->GetPrinterTranslateX();
}
#endif

//-----------------------------------------------------------------------------

#if WXWIN_COMPATIBILITY_2_4
WXNET_EXPORT(int)
  wxPrintData_GetPrinterTranslateY(wxPrintData* self)
{
    return self->GetPrinterTranslateY();
}
#endif

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxPrintMode)
  wxPrintData_GetPrintMode(wxPrintData* self)
{
    return self->GetPrintMode();
}

//-----------------------------------------------------------------------------

#if WXWIN_COMPATIBILITY_2_4
WXNET_EXPORT(void)
  wxPrintData_SetPrinterCommand(wxPrintData* self, const wxString* command)
{
   if (self && command)
    self->SetPrinterCommand(*command);
}
#endif

//-----------------------------------------------------------------------------

#if WXWIN_COMPATIBILITY_2_4
WXNET_EXPORT(void)
  wxPrintData_SetPrinterOptions(wxPrintData* self, const wxString* options)
{
   if (self && options)
    self->SetPrinterOptions(*options);
}
#endif

//-----------------------------------------------------------------------------

#if WXWIN_COMPATIBILITY_2_4
WXNET_EXPORT(void)
  wxPrintData_SetPreviewCommand(wxPrintData* self, const wxString* command)
{
   if (self && command)
    self->SetPreviewCommand(*command);
}
#endif

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPrintData_SetFilename(wxPrintData* self, const wxString* filename)
{
   if (self && filename)
    self->SetFilename(*filename);
}

//-----------------------------------------------------------------------------

#if WXWIN_COMPATIBILITY_2_4
WXNET_EXPORT(void)
  wxPrintData_SetFontMetricPath(wxPrintData* self, const wxString* path)
{
   if (self && path)
    self->SetFontMetricPath(*path);
}
#endif

//-----------------------------------------------------------------------------

#if WXWIN_COMPATIBILITY_2_4
WXNET_EXPORT(void)
  wxPrintData_SetPrinterScaleX(wxPrintData* self, double x)
{
    self->SetPrinterScaleX(x);
}
#endif

//-----------------------------------------------------------------------------

#if WXWIN_COMPATIBILITY_2_4
WXNET_EXPORT(void)
  wxPrintData_SetPrinterScaleY(wxPrintData* self, double y)
{
    self->SetPrinterScaleY(y);
}
#endif

//-----------------------------------------------------------------------------

#if WXWIN_COMPATIBILITY_2_4
WXNET_EXPORT(void)
  wxPrintData_SetPrinterScaling(wxPrintData* self, double x, double y)
{
    self->SetPrinterScaling(x, y);
}
#endif

//-----------------------------------------------------------------------------

#if WXWIN_COMPATIBILITY_2_4
WXNET_EXPORT(void)
  wxPrintData_SetPrinterTranslateX(wxPrintData* self, int x)
{
    self->SetPrinterTranslateX(x);
}
#endif

//-----------------------------------------------------------------------------

#if WXWIN_COMPATIBILITY_2_4
WXNET_EXPORT(void)
  wxPrintData_SetPrinterTranslateY(wxPrintData* self, int y)
{
    self->SetPrinterTranslateY(y);
}
#endif

//-----------------------------------------------------------------------------

#if WXWIN_COMPATIBILITY_2_4
WXNET_EXPORT(void)
  wxPrintData_SetPrinterTranslation(wxPrintData* self, int x, int y)
{
    self->SetPrinterTranslation(x, y);
}
#endif

//-----------------------------------------------------------------------------

#if WXWIN_COMPATIBILITY_2_4
WXNET_EXPORT(void)
  wxPrintData_SetPrintMode(wxPrintData* self, wxPrintMode printMode)
{
    self->SetPrintMode(printMode);
}
#endif

