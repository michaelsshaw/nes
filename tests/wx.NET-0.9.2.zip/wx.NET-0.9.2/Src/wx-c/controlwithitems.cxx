//-----------------------------------------------------------------------------
// wx.NET - controlwithitems.cxx
//
// The wxControlWithItems wrapper class.
//
// Written by Harald Meyer auf'm Hofe (harald_meyer@sf.net)
// (C) 2007 Harald Meyer auf'm Hofe
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: controlwithitems.cxx,v 1.5 2008/12/25 17:01:35 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/ctrlsub.h>
#ifndef WXNET_GLOBAL_H
#include "wxnet_globals.h"
#endif

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxControlWithItems_SetString(wxControlWithItems* self, int n, const wxString* text)
{
   if (self && text)
    self->SetString(n, *text);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxControlWithItems_GetStringSelection(wxControlWithItems* self)
{
    return new wxString(self->GetStringSelection());
}

WXNET_EXPORT(char)
  wxComboBox_SetStringSelection(wxComboBox* self, const wxString* str)
{
   if (self && str)
    return self->SetStringSelection(*str);
   return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxControlWithItems_GetString(wxControlWithItems* self, int n)
{
    return new wxString(self->GetString(n));
}

WXNET_EXPORT(int)
  wxControlWithItems_GetSelection(wxControlWithItems* self)
{
    return self->GetSelection();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxControlWithItems_GetCount(wxControlWithItems* self)
{
    return self->GetCount();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void*)
  wxControlWithItems_GetClientData(const wxControlWithItems* self, int n)
{
   if (self)
    return self->GetClientData(n);
   
   return NULL;
}

WXNET_EXPORT(void)
  wxControlWithItems_SetClientData(wxControlWithItems* self, int n, void* data)
{
   if (self)
    self->SetClientData(n, data);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxControlWithItems_FindString(wxControlWithItems* self, const wxString* string)
{
   if (self && string)
    return self->FindString(*string);
   return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxControlWithItems_Delete(wxControlWithItems* self, int n)
{
    self->Delete(n);
}

WXNET_EXPORT(void)
  wxControlWithItems_Clear(wxControlWithItems* self)
{
   if (self && !self->IsEmpty())
    self->Clear();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxControlWithItems_Append(wxControlWithItems* self, const wxString* item)
{
   if (self && item)
    return self->Append(*item);
   return 0;
}

WXNET_EXPORT(int)
  wxControlWithItems_AppendWithData(wxControlWithItems* self, const wxString* item, wxClientData* clientData)
{
   if (self && item)
    return self->Append(*item, clientData);
   return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxControlWithItems_Insert(wxControlWithItems* self, const wxString* item, int pos)
{
   if (self && item)
	   return self->Insert(*item, pos);
   return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxControlWithItems_InsertWithData(wxControlWithItems* self, const wxString* item, int pos, wxClientData* clientData)
{
   if (self && item)
	   return self->Insert(*item, pos, clientData);
   return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxArrayString*)
  wxControlWithItems_GetStrings(wxControlWithItems* self)
{
	wxArrayString* wai = new wxArrayString();
	*wai = self->GetStrings();
	return wai;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxControlWithItems_SetClientObject(wxControlWithItems* self, int n, wxClientData* clientData)
{
	self->SetClientObject(n, clientData);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxClientData*)
  wxControlWithItems_GetClientObject(wxControlWithItems* self, int n)
{
	return self->GetClientObject(n);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxControlWithItems_HasClientObjectData(wxControlWithItems* self)
{
	return self->HasClientObjectData()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxControlWithItems_HasClientUntypedData(wxControlWithItems* self)
{
	return self->HasClientUntypedData()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxControlWithItems_SetSelection(wxControlWithItems* self, int n)
{
    self->SetSelection(n);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxControlWithItems_SetStringSelection(wxControlWithItems* self, const wxString* s)
{
   if (self && s)
    return self->SetStringSelection(*s)?1:0;
   return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxControlWithItems_Command(wxControlWithItems* self, wxCommandEvent* event)
{
    self->Command(*event);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxControlWithItems_Select(wxControlWithItems* self, int n)
{
	self->Select(n);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxControlWithItems_ShouldInheritColours(wxControlWithItems* self)
{
	return self->ShouldInheritColours(); 
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxControlWithItems_IsEmpty(wxControlWithItems* self)
{
	return self->IsEmpty()?1:0;
}
