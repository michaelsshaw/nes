//-----------------------------------------------------------------------------
// wx.NET - miniframe.cxx
// 
// The wxMiniFrame proxy interface.
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 by Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: miniframe.cxx,v 1.8 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/minifram.h>
#include "local_events.h"

//-----------------------------------------------------------------------------

class _MiniFrame : public wxMiniFrame
{
public:
    DECLARE_OBJECTDELETED(_MiniFrame)
};

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxMiniFrame*)
  wxMiniFrame_ctor()
{
    return new _MiniFrame();
}

//-----------------------------------------------------------------------------


WXNET_EXPORT(char)
  wxMiniFrame_Create(wxMiniFrame* self, wxWindow* parent, wxWindowID id, const wxString* titleArg, int posX, int posY, int width, unsigned int height, int style, const wxString* nameArg)
{
   wxString name;
   if (nameArg == NULL)
        name = wxT("miniFrame");
   else
      name=*nameArg;
   wxString title;
   if (titleArg)
      title=*titleArg;

    return self->Create(parent, id, title, wxPoint(posX, posY), wxSize(width, height), style, name);
}

//-----------------------------------------------------------------------------

