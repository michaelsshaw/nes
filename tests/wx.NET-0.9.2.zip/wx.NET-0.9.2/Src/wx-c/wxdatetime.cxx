//-----------------------------------------------------------------------------
// wx.NET - wxdatetime.cxx
//
// The wxDateTime proxy interface
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 by Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: wxdatetime.cxx,v 1.5 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/datetime.h>
#include "wxnet_globals.h"

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxDateTime*)
  wxDateTime_ctor()
{
    return new wxDateTime();
}

WXNET_EXPORT(void)
  wxDateTime_dtor(wxDateTime* self)
{
	if (self != NULL)
		delete self;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxDateTime_Set(wxDateTime* self, unsigned short day, 
                    int month, int year, 
                    unsigned short hour, unsigned short minute, 
                    unsigned short second, unsigned short millisec)
{
    self->Set(day, (wxDateTime::Month)month, year, hour, minute, second, millisec);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(unsigned short)
   wxDateTime_GetYear(wxDateTime* self)
{
    return self->GetYear();
}

WXNET_EXPORT(int)
  wxDateTime_GetMonth(wxDateTime* self)
{
    return (int)self->GetMonth();
}

WXNET_EXPORT(unsigned short)
  wxDateTime_GetDay(wxDateTime* self)
{
    return self->GetDay();
}

WXNET_EXPORT(unsigned short)
  wxDateTime_GetHour(wxDateTime* self)
{
    return self->GetHour();
}

WXNET_EXPORT(unsigned short)
  wxDateTime_GetMinute(wxDateTime* self)
{
    return self->GetMinute();
}

WXNET_EXPORT(unsigned short)
  wxDateTime_GetSecond(wxDateTime* self)
{
    return self->GetSecond();
}

WXNET_EXPORT(unsigned short)
  wxDateTime_GetMillisecond(wxDateTime* self)
{
    return self->GetMillisecond();
}

//-----------------------------------------------------------------------------

