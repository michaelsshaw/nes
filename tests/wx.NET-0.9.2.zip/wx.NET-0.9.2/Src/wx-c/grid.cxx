//-----------------------------------------------------------------------------
// wx.NET - grid.cxx
// 
// The wxGrid proxy interface.
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 by Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: grid.cxx,v 1.25 2009/10/11 16:23:29 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/grid.h>
#include <wx/generic/gridctrl.h>
#include "local_events.h"

//-----------------------------------------------------------------------------
// wxGridEvent

WXNET_EXPORT(wxGridEvent*)
  wxGridEvent_ctor(int id, wxEventType type, wxObject* obj, int row, int col, int x, int y, bool sel, bool control, bool shift, bool alt, bool meta)
{
    return new wxGridEvent(id, type, obj, row, col, x, y, sel, control, shift, alt, meta);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxGridEvent_GetRow(wxGridEvent* self)
{
    return self->GetRow();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxGridEvent_GetCol(wxGridEvent* self)
{
    return self->GetCol();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGridEvent_GetPosition(wxGridEvent* self, wxPoint* pt)
{
    *pt = self->GetPosition();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGridEvent_Selecting(wxGridEvent* self)
{
    return self->Selecting()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGridEvent_ControlDown(wxGridEvent* self)
{
    return self->ControlDown()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGridEvent_MetaDown(wxGridEvent* self)
{
    return self->MetaDown()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGridEvent_ShiftDown(wxGridEvent* self)
{
    return self->ShiftDown()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGridEvent_AltDown(wxGridEvent* self)
{
    return self->AltDown()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGridEvent_Veto(wxGridEvent* self)
{
    self->Veto();
}

WXNET_EXPORT(void)
  wxGridEvent_Allow(wxGridEvent* self)
{
    self->Allow();
}

WXNET_EXPORT(char)
  wxGridEvent_IsAllowed(wxGridEvent* self)
{
    return self->IsAllowed()?1:0;
}

//-----------------------------------------------------------------------------
// wxGridRangeSelectEvent

WXNET_EXPORT(wxGridRangeSelectEvent*)
  wxGridRangeSelectEvent_ctor(int id, wxEventType type, wxObject* obj, wxGridCellCoords* topLeft, wxGridCellCoords* bottomRight, bool sel, bool control, bool shift, bool alt, bool meta)
{
    return new wxGridRangeSelectEvent(id, type, obj, *topLeft, *bottomRight, sel, control, shift, alt, meta);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxGridCellCoords*)
  wxGridRangeSelectEvent_GetTopLeftCoords(wxGridRangeSelectEvent* self)
{
    return new wxGridCellCoords(self->GetTopLeftCoords());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxGridCellCoords*)
  wxGridRangeSelectEvent_GetBottomRightCoords(wxGridRangeSelectEvent* self)
{
    return new wxGridCellCoords(self->GetBottomRightCoords());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxGridRangeSelectEvent_GetTopRow(wxGridRangeSelectEvent* self)
{
    return self->GetTopRow();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxGridRangeSelectEvent_GetBottomRow(wxGridRangeSelectEvent* self)
{
    return self->GetBottomRow();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxGridRangeSelectEvent_GetLeftCol(wxGridRangeSelectEvent* self)
{
    return self->GetLeftCol();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxGridRangeSelectEvent_GetRightCol(wxGridRangeSelectEvent* self)
{
    return self->GetRightCol();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGridRangeSelectEvent_Selecting(wxGridRangeSelectEvent* self)
{
    return self->Selecting()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGridRangeSelectEvent_ControlDown(wxGridRangeSelectEvent* self)
{
    return self->ControlDown()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGridRangeSelectEvent_MetaDown(wxGridRangeSelectEvent* self)
{
    return self->MetaDown()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGridRangeSelectEvent_ShiftDown(wxGridRangeSelectEvent* self)
{
    return self->ShiftDown()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGridRangeSelectEvent_AltDown(wxGridRangeSelectEvent* self)
{
    return self->AltDown()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGridRangeSelectEvent_Veto(wxGridRangeSelectEvent* self)
{
    self->Veto();
}

WXNET_EXPORT(void)
  wxGridRangeSelectEvent_Allow(wxGridRangeSelectEvent* self)
{
    self->Allow();
}

WXNET_EXPORT(char)
  wxGridRangeSelectEvent_IsAllowed(wxGridRangeSelectEvent* self)
{
    return self->IsAllowed()?1:0;
}

//-----------------------------------------------------------------------------
// wxGridCellWorker

typedef void (CALLBACK* Virtual_SetParameters) (wxString*);

class _GridCellWorker : public wxGridCellWorker
{
public:
    _GridCellWorker()
        : wxGridCellWorker() {}

    void SetParameters(const wxString& params)
        {
            return m_SetParameters(new wxString(params));
        }

    void RegisterVirtual(Virtual_SetParameters setParameters)
        {
            m_SetParameters = setParameters;
        }

private:
    Virtual_SetParameters m_SetParameters;
};

WXNET_EXPORT(wxGridCellWorker*)
  wxGridCellWorker_ctor()
{
    return new _GridCellWorker();
}

WXNET_EXPORT(void)
  wxGridCellWorker_RegisterVirtual(_GridCellWorker* self, Virtual_SetParameters setParameters)
{
    self->RegisterVirtual(setParameters);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGridCellWorker_IncRef(_GridCellWorker* self)
{
    self->IncRef();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGridCellWorker_DecRef(_GridCellWorker* self)
{
    self->DecRef();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGridCellWorker_SetParameters(_GridCellWorker* self, const wxString* params)
{
   if (self && params)
    self->wxGridCellWorker::SetParameters(*params);
}

//-----------------------------------------------------------------------------
// wxGridEditorCreatedEvent

WXNET_EXPORT(wxGridEditorCreatedEvent*)
  wxGridEditorCreatedEvent_ctor(int id, wxEventType type, wxObject* obj, int row, int col, wxControl* ctrl)
{
    return new wxGridEditorCreatedEvent(id, type, obj, row, col, ctrl);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxGridEditorCreatedEvent_GetRow(wxGridEditorCreatedEvent* self)
{
    return self->GetRow();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxGridEditorCreatedEvent_GetCol(wxGridEditorCreatedEvent* self)
{
    return self->GetCol();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxControl*)
  wxGridEditorCreatedEvent_GetControl(wxGridEditorCreatedEvent* self)
{
    return self->GetControl();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGridEditorCreatedEvent_SetRow(wxGridEditorCreatedEvent* self, int row)
{
    self->SetRow(row);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGridEditorCreatedEvent_SetCol(wxGridEditorCreatedEvent* self, int col)
{
    self->SetCol(col);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGridEditorCreatedEvent_SetControl(wxGridEditorCreatedEvent* self, wxControl* ctrl)
{
    self->SetControl(ctrl);
}

//-----------------------------------------------------------------------------
// wxGrid

class _Grid : public wxGrid
{
public:
	_Grid()
		: wxGrid() {}
		
	_Grid(wxWindow* parent, wxWindowID id, const wxPoint& pos, const wxSize& size, unsigned int style, const wxString& name)
		: wxGrid(parent, id, pos, size, style, name) {}

	DECLARE_OBJECTDELETED(_Grid)
};

WXNET_EXPORT(wxGrid*)
  wxGrid_ctor()
{
    return new _Grid();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxGrid*)
  wxGrid_ctorFull(wxWindow* parent, wxWindowID id, int posX, int posY, unsigned int width, int height, int style, const wxString* nameArg)
{
   wxString name;
   if (nameArg)
      name=*nameArg;
   else
      name=wxT("Grid");
    return new _Grid(parent, id, wxPoint(posX, posY), wxSize(width, height), style, name);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_dtor(wxGrid* self)   
{
    WXNET_DEL( self );
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGrid_CreateGrid(wxGrid* self, int numRows, int numCols, wxGrid::wxGridSelectionModes selmode)
{
    return self->CreateGrid(numRows, numCols, selmode)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SetSelectionMode(wxGrid* self, wxGrid::wxGridSelectionModes selmode)
{
    self->SetSelectionMode(selmode);
}

WXNET_EXPORT(wxGrid::wxGridSelectionModes)
  wxGrid_GetSelectionMode(wxGrid* self)
{
    return self->GetSelectionMode();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxGrid_GetNumberRows(wxGrid* self)
{
    return self->GetNumberRows();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxGrid_GetNumberCols(wxGrid* self)
{
    return self->GetNumberCols();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_ProcessRowLabelMouseEvent(wxGrid* self, wxMouseEvent* event)
{
    self->ProcessRowLabelMouseEvent(*event);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_ProcessColLabelMouseEvent(wxGrid* self, wxMouseEvent* event)
{
    self->ProcessColLabelMouseEvent(*event);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_ProcessCornerLabelMouseEvent(wxGrid* self, wxMouseEvent* event)
{
    self->ProcessCornerLabelMouseEvent(*event);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_ProcessGridCellMouseEvent(wxGrid* self, wxMouseEvent* event)
{
    self->ProcessGridCellMouseEvent(*event);
}

WXNET_EXPORT(char)
  wxGrid_ProcessTableMessage(wxGrid* self, wxGridTableMessage* msg )
{
   if (self && msg)
      return self->ProcessTableMessage(*msg);
   else
      return false;
}


WXNET_EXPORT(wxGridTableMessage*)
  wxGridTableMessage_ctor1()
{
   return new wxGridTableMessage();
}

WXNET_EXPORT(wxGridTableMessage*)
  wxGridTableMessage_ctor2(wxGridTableBase* table,
                                             int id,
                                             int comInt1, int comInt2)
{
   return new wxGridTableMessage(table, id, comInt1, comInt2);
}

WXNET_EXPORT(void)
    wxGridTableMessage_SetTableObject(wxGridTableMessage* self, wxGridTableBase* table)
{
   if (self)
      self->SetTableObject(table);
}

WXNET_EXPORT(wxGridTableBase*)
  wxGridTableMessage_GetTableObject(wxGridTableMessage* self)
{
   if (self) return self->GetTableObject();
   else return NULL;
}

WXNET_EXPORT(void)
    wxGridTableMessage_SetId(wxGridTableMessage* self, int id)
{
   if (self) self->SetId(id);
}

WXNET_EXPORT(int)
  wxGridTableMessage_GetId(wxGridTableMessage* self)
{
   if (self) return self->GetId();
   else return 0;
}

WXNET_EXPORT(void)
    wxGridTableMessage_SetCommandInt(wxGridTableMessage* self, int comInt)
{
   if (self) return self->SetCommandInt(comInt);
}

WXNET_EXPORT(int)
     wxGridTableMessage_GetCommandInt(wxGridTableMessage* self)
{
   if (self) return self->GetCommandInt();
   else return -1;
}

WXNET_EXPORT(void)
    wxGridTableMessage_SetCommandInt2(wxGridTableMessage* self, int comInt)
{
   if (self) return self->SetCommandInt2(comInt);
}

WXNET_EXPORT(int)
     wxGridTableMessage_GetCommandInt2(wxGridTableMessage* self)
{
   if (self) return self->GetCommandInt2();
   else return -1;
}


//-----------------------------------------------------------------------------

WXNET_EXPORT(wxGridTableBase*)
  wxGrid_GetTable(wxGrid* self)
{
    return self->GetTable();
}

WXNET_EXPORT(char)
  wxGrid_SetTable(wxGrid* self, wxGridTableBase* table, bool takeOwnership, wxGrid::wxGridSelectionModes selmode)
{
    return self->SetTable(table, takeOwnership, selmode)?1:0;
}

WXNET_EXPORT(int) wxGridStringTable_GetNumberRows(wxGridStringTable* self)
{
    if (self)
        return self->GetNumberRows();
    else
        return 0;
}

WXNET_EXPORT(int) wxGridStringTable_GetNumberCols(wxGridStringTable* self)
{
    if (self)
        return self->GetNumberCols();
    else
        return 0;
}

WXNET_EXPORT(char) wxGridStringTable_IsEmptyCell(wxGridStringTable* self, int row, int col)
{
   if (self)
      return self->IsEmptyCell(row, col);
   else
      return true;
}

WXNET_EXPORT(wxString*) wxGridStringTable_GetValue(wxGridStringTable* self, int row, int col)
{
   if (self)
      return new wxString(self->GetValue(row, col));
   else
      return NULL;
}

WXNET_EXPORT(void) wxGridStringTable_SetValue(wxGridStringTable* self, int row, int col, const wxString* val)
{
   if (self && val)
   {
      self->SetValue(row, col, *val);
   }
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_ClearGrid(wxGrid* self)
{
    self->ClearGrid();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGrid_InsertRows(wxGrid* self, int pos, int numRows, bool updateLabels)
{
    return self->InsertRows(pos, numRows, updateLabels)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGrid_AppendRows(wxGrid* self, int numRows, bool updateLabels)
{
    return self->AppendRows(numRows, updateLabels)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGrid_DeleteRows(wxGrid* self, int pos, int numRows, bool updateLabels)
{
    return self->DeleteRows(pos, numRows, updateLabels)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGrid_InsertCols(wxGrid* self, int pos, int numCols, bool updateLabels)
{
    return self->InsertCols(pos, numCols, updateLabels)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGrid_AppendCols(wxGrid* self, int numCols, bool updateLabels)
{
    return self->AppendCols(numCols, updateLabels)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGrid_DeleteCols(wxGrid* self, int pos, int numCols, bool updateLabels)
{
    return self->DeleteCols(pos, numCols, updateLabels)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_DrawGridCellArea(wxGrid* self, wxDC* dc, wxGridCellCoordsArray* cells)
{
    self->DrawGridCellArea(*dc, *cells);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_DrawGridSpace(wxGrid* self, wxDC* dc)
{
    self->DrawGridSpace(*dc);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_BeginBatch(wxGrid* self)
{
    self->BeginBatch();
}

WXNET_EXPORT(void)
  wxGrid_EndBatch(wxGrid* self)
{
    self->EndBatch();
}

WXNET_EXPORT(int)
  wxGrid_GetBatchCount(wxGrid* self)
{
    return self->GetBatchCount();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_ForceRefresh(wxGrid* self)
{
    self->ForceRefresh();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGrid_IsEditable(wxGrid* self)
{
    return self->IsEditable()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_EnableEditing(wxGrid* self, bool edit)
{
    self->EnableEditing(edit);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_EnableCellEditControl(wxGrid* self, bool enable)
{
    self->EnableCellEditControl(enable);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_DisableCellEditControl(wxGrid* self)
{
    self->DisableCellEditControl();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGrid_CanEnableCellControl(wxGrid* self)
{
    return self->CanEnableCellControl()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGrid_IsCellEditControlEnabled(wxGrid* self)
{
    return self->IsCellEditControlEnabled()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGrid_IsCellEditControlShown(wxGrid* self)
{
    return self->IsCellEditControlShown()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGrid_IsCurrentCellReadOnly(wxGrid* self)
{
    return self->IsCurrentCellReadOnly()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_ShowCellEditControl(wxGrid* self)
{
    self->ShowCellEditControl();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_HideCellEditControl(wxGrid* self)
{
    self->HideCellEditControl();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SaveEditControlValue(wxGrid* self)
{
    self->SaveEditControlValue();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxGrid_YToRow(wxGrid* self, int y)
{
    return self->YToRow(y);
}

WXNET_EXPORT(int)
  wxGrid_XToCol(wxGrid* self, int x)
{
    return self->XToCol(x);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxGrid_YToEdgeOfRow(wxGrid* self, int y)
{
    return self->YToEdgeOfRow(y);
}

WXNET_EXPORT(int)
  wxGrid_XToEdgeOfCol(wxGrid* self, int x)
{
    return self->XToEdgeOfCol(x);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_CellToRect(wxGrid* self, int row, int col, wxRect* rc)
{
    *rc = self->CellToRect(row, col);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxGrid_GetGridCursorRow(wxGrid* self)
{
    return self->GetGridCursorRow();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxGrid_GetGridCursorCol(wxGrid* self)
{
    return self->GetGridCursorCol();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGrid_IsVisible(wxGrid* self, int row, int col, bool wholeCellVisible)
{
    return self->IsVisible(row, col, wholeCellVisible)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_MakeCellVisible(wxGrid* self, int row, int col)
{
    self->MakeCellVisible(row, col);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SetGridCursor(wxGrid* self, int row, int col)
{
    self->SetGridCursor(row, col);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGrid_MoveCursorUp(wxGrid* self, bool expandSelection)
{
    return self->MoveCursorUp(expandSelection)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGrid_MoveCursorDown(wxGrid* self, bool expandSelection)
{
    return self->MoveCursorDown(expandSelection)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGrid_MoveCursorLeft(wxGrid* self, bool expandSelection)
{
    return self->MoveCursorLeft(expandSelection)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGrid_MoveCursorRight(wxGrid* self, bool expandSelection)
{
    return self->MoveCursorRight(expandSelection)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGrid_MovePageDown(wxGrid* self)
{
    return self->MovePageDown()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGrid_MovePageUp(wxGrid* self)
{
    return self->MovePageUp()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGrid_MoveCursorUpBlock(wxGrid* self, bool expandSelection)
{
    return self->MoveCursorUpBlock(expandSelection)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGrid_MoveCursorDownBlock(wxGrid* self, bool expandSelection)
{
    return self->MoveCursorDownBlock(expandSelection)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGrid_MoveCursorLeftBlock(wxGrid* self, bool expandSelection)
{
    return self->MoveCursorLeftBlock(expandSelection)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGrid_MoveCursorRightBlock(wxGrid* self, bool expandSelection)
{
    return self->MoveCursorRightBlock(expandSelection)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxGrid_GetDefaultRowLabelSize(wxGrid* self)
{
    return self->GetDefaultRowLabelSize();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxGrid_GetRowLabelSize(wxGrid* self)
{
    return self->GetRowLabelSize();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxGrid_GetDefaultColLabelSize(wxGrid* self)
{
    return self->GetDefaultColLabelSize();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxGrid_GetColLabelSize(wxGrid* self)
{
    return self->GetColLabelSize();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxColour*)
  wxGrid_GetLabelBackgroundColour(wxGrid* self)
{
    return new wxColour(self->GetLabelBackgroundColour());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxColour*)
  wxGrid_GetLabelTextColour(wxGrid* self)
{
    return new wxColour(self->GetLabelTextColour());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxFont*)
  wxGrid_GetLabelFont(wxGrid* self)
{
    return new wxFont(self->GetLabelFont());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_GetRowLabelAlignment(wxGrid* self, int* horiz, int* vert)
{
    self->GetRowLabelAlignment(horiz, vert);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_GetColLabelAlignment(wxGrid* self, int* horiz, int* vert)
{
    self->GetColLabelAlignment(horiz, vert);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxGrid_GetRowLabelValue(wxGrid* self, int row)
{
    return new wxString(self->GetRowLabelValue(row));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxGrid_GetColLabelValue(wxGrid* self, int col)
{
    return new wxString(self->GetColLabelValue(col));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxColour*)
  wxGrid_GetGridLineColour(wxGrid* self)
{
    return new wxColour(self->GetGridLineColour());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxColour*)
  wxGrid_GetCellHighlightColour(wxGrid* self)
{
    return new wxColour(self->GetCellHighlightColour());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxGrid_GetCellHighlightPenWidth(wxGrid* self)
{
    return self->GetCellHighlightPenWidth();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxGrid_GetCellHighlightROPenWidth(wxGrid* self)
{
    return self->GetCellHighlightROPenWidth();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SetRowLabelSize(wxGrid* self, int width)
{
    self->SetRowLabelSize(width);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SetColLabelSize(wxGrid* self, int height)
{
    self->SetColLabelSize(height);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SetLabelBackgroundColour(wxGrid* self, wxColour* col)
{
    self->SetLabelBackgroundColour(*col);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SetLabelTextColour(wxGrid* self, wxColour* col)
{
    self->SetLabelTextColour(*col);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SetLabelFont(wxGrid* self, wxFont* font)
{
    self->SetLabelFont(*font);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SetRowLabelAlignment(wxGrid* self, int horiz, int vert)
{
    self->SetRowLabelAlignment(horiz, vert);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SetColLabelAlignment(wxGrid* self, int horiz, int vert)
{
    self->SetColLabelAlignment(horiz, vert);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SetRowLabelValue(wxGrid* self, int row, const wxString* val)
{
   if (self && val)
    self->SetRowLabelValue(row, *val);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SetColLabelValue(wxGrid* self, int col, const wxString* val)
{
   if (self && val)
    self->SetColLabelValue(col, *val);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SetGridLineColour(wxGrid* self, wxColour* col)
{
    self->SetGridLineColour(*col);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SetCellHighlightColour(wxGrid* self, wxColour* col)
{
    self->SetCellHighlightColour(*col);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SetCellHighlightPenWidth(wxGrid* self, int width)
{
    self->SetCellHighlightPenWidth(width);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SetCellHighlightROPenWidth(wxGrid* self, int width)
{
    self->SetCellHighlightROPenWidth(width);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_EnableDragRowSize(wxGrid* self, bool enable)
{
    self->EnableDragRowSize(enable);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_DisableDragRowSize(wxGrid* self)
{
    self->DisableDragRowSize();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGrid_CanDragRowSize(wxGrid* self)
{
    return self->CanDragRowSize()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_EnableDragColSize(wxGrid* self, bool enable)
{
    self->EnableDragColSize(enable);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_DisableDragColSize(wxGrid* self)
{
    self->DisableDragColSize();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGrid_CanDragColSize(wxGrid* self)
{
    return self->CanDragColSize()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_EnableDragGridSize(wxGrid* self, bool enable)
{
    self->EnableDragGridSize(enable);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_DisableDragGridSize(wxGrid* self)
{
    self->DisableDragGridSize();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGrid_CanDragGridSize(wxGrid* self)
{
    return self->CanDragGridSize()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SetAttr(wxGrid* self, int row, int col, wxGridCellAttr* attr)
{
    self->SetAttr(row, col, attr);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SetRowAttr(wxGrid* self, int row, wxGridCellAttr* attr)
{
    self->SetRowAttr(row, attr);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SetColAttr(wxGrid* self, int col, wxGridCellAttr* attr)
{
    self->SetColAttr(col, attr);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SetColFormatBool(wxGrid* self, int col)
{
    self->SetColFormatBool(col);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SetColFormatNumber(wxGrid* self, int col)
{
    self->SetColFormatNumber(col);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SetColFormatFloat(wxGrid* self, int col, int width, int precision)
{
    self->SetColFormatFloat(col, width, precision);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SetColFormatCustom(wxGrid* self, int col, const wxString* typeName)
{
   if (self && typeName)
    self->SetColFormatCustom(col, *typeName);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_EnableGridLines(wxGrid* self, bool enable)
{
    self->EnableGridLines(enable);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGrid_GridLinesEnabled(wxGrid* self)
{
    return self->GridLinesEnabled()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxGrid_GetDefaultRowSize(wxGrid* self)
{
    return self->GetDefaultRowSize();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxGrid_GetRowSize(wxGrid* self, int row)
{
    return self->GetRowSize(row);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxGrid_GetDefaultColSize(wxGrid* self)
{
    return self->GetDefaultColSize();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxGrid_GetColSize(wxGrid* self, int col)
{
    return self->GetColSize(col);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxColour*)
  wxGrid_GetDefaultCellBackgroundColour(wxGrid* self)
{
    return new wxColour(self->GetDefaultCellBackgroundColour());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxColour*)
  wxGrid_GetCellBackgroundColour(wxGrid* self, int row, int col)
{
    return new wxColour(self->GetCellBackgroundColour(row, col));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxColour*)
  wxGrid_GetDefaultCellTextColour(wxGrid* self)
{
    return new wxColour(self->GetDefaultCellTextColour());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxColour*)
  wxGrid_GetCellTextColour(wxGrid* self, int row, int col)
{
    return new wxColour(self->GetCellTextColour(row, col));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxFont*)
  wxGrid_GetDefaultCellFont(wxGrid* self)
{
    return new wxFont(self->GetDefaultCellFont());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxFont*)
  wxGrid_GetCellFont(wxGrid* self, int row, int col)
{
    return new wxFont(self->GetCellFont(row, col));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_GetDefaultCellAlignment(wxGrid* self, int* horiz, int* vert)
{
    self->GetDefaultCellAlignment(horiz, vert);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_GetCellAlignment(wxGrid* self, int row, int col, int* horiz, int* vert)
{
    self->GetCellAlignment(row, col, horiz, vert);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGrid_GetDefaultCellOverflow(wxGrid* self)
{
    return self->GetDefaultCellOverflow()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGrid_GetCellOverflow(wxGrid* self, int row, int col)
{
    return self->GetCellOverflow(row, col)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_GetCellSize(wxGrid* self, int row, int col, int* num_rows, int* num_cols)
{
    self->GetCellSize(row, col, num_rows, num_cols);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SetDefaultRowSize(wxGrid* self, int height, bool resizeExistingRows)
{
    self->SetDefaultRowSize(height, resizeExistingRows);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SetRowSize(wxGrid* self, int row, int height)
{
    self->SetRowSize(row, height);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SetDefaultColSize(wxGrid* self, int width, bool resizeExistingCols)
{
    self->SetDefaultColSize(width, resizeExistingCols);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SetColSize(wxGrid* self, int col, int width)
{
    self->SetColSize(col, width);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_AutoSizeColumn(wxGrid* self, int col, bool setAsMin)
{
    self->AutoSizeColumn(col, setAsMin);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_AutoSizeRow(wxGrid* self, int row, bool setAsMin)
{
    self->AutoSizeRow(row, setAsMin);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_AutoSizeColumns(wxGrid* self, bool setAsMin)
{
    self->AutoSizeColumns(setAsMin);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_AutoSizeRows(wxGrid* self, bool setAsMin)
{
    self->AutoSizeRows(setAsMin);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_AutoSize(wxGrid* self)
{
    self->AutoSize();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SetColMinimalWidth(wxGrid* self, int col, int width)
{
    self->SetColMinimalWidth(col, width);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SetRowMinimalHeight(wxGrid* self, int row, int width)
{
    self->SetRowMinimalHeight(row, width);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SetColMinimalAcceptableWidth(wxGrid* self, int width)
{
    self->SetColMinimalAcceptableWidth(width);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SetRowMinimalAcceptableHeight(wxGrid* self, int width)
{
    self->SetRowMinimalAcceptableHeight(width);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxGrid_GetColMinimalAcceptableWidth(wxGrid* self)
{
    return self->GetColMinimalAcceptableWidth();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxGrid_GetRowMinimalAcceptableHeight(wxGrid* self)
{
    return self->GetRowMinimalAcceptableHeight();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SetDefaultCellBackgroundColour(wxGrid* self, wxColour* col)
{
    self->SetDefaultCellBackgroundColour(*col);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SetDefaultCellTextColour(wxGrid* self, wxColour* col)
{
    self->SetDefaultCellTextColour(*col);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SetDefaultCellFont(wxGrid* self, wxFont* font)
{
    self->SetDefaultCellFont(*font);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SetCellFont(wxGrid* self, int row, int col, wxFont* font)
{
    self->SetCellFont(row, col, *font);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SetDefaultCellAlignment(wxGrid* self, int horiz, int vert)
{
    self->SetDefaultCellAlignment(horiz, vert);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SetCellAlignmentHV(wxGrid* self, int row, int col, int horiz, int vert)
{
    self->SetCellAlignment(row, col, horiz, vert);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SetDefaultCellOverflow(wxGrid* self, bool allow)
{
    self->SetDefaultCellOverflow(allow);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SetCellOverflow(wxGrid* self, int row, int col, bool allow)
{
    self->SetCellOverflow(row, col, allow);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SetCellSize(wxGrid* self, int row, int col, int num_rows, int num_cols)
{
    self->SetCellSize(row, col, num_rows, num_cols);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SetDefaultRenderer(wxGrid* self, wxGridCellRenderer* renderer)
{
    self->SetDefaultRenderer(renderer);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SetCellRenderer(wxGrid* self, int row, int col, wxGridCellRenderer* renderer)
{
    self->SetCellRenderer(row, col, renderer);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxGridCellRenderer*)
  wxGrid_GetDefaultRenderer(wxGrid* self)
{
    return self->GetDefaultRenderer();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxGridCellRenderer*)
  wxGrid_GetCellRenderer(wxGrid* self, int row, int col)
{
    return self->GetCellRenderer(row, col);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SetDefaultEditor(wxGrid* self, wxGridCellEditor* editor)
{
    self->SetDefaultEditor(editor);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SetCellEditor(wxGrid* self, int row, int col, wxGridCellEditor* editor)
{
    self->SetCellEditor(row, col, editor);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxGridCellEditor*)
  wxGrid_GetDefaultEditor(wxGrid* self)
{
    return self->GetDefaultEditor();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxGridCellEditor*)
  wxGrid_GetCellEditor(wxGrid* self, int row, int col)
{
    return self->GetCellEditor(row, col);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxGrid_GetCellValue(wxGrid* self, int row, int col)
{
    return new wxString(self->GetCellValue(row, col));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SetCellValue(wxGrid* self, int row, int col, const wxString* s)
{
   if (self && s)
    self->SetCellValue(row, col, *s);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGrid_IsReadOnly(wxGrid* self, int row, int col)
{
    return self->IsReadOnly(row, col)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SetReadOnly(wxGrid* self, int row, int col, bool isReadOnly)
{
    self->SetReadOnly(row, col, isReadOnly);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SelectRow(wxGrid* self, int row, bool addToSelected)
{
    self->SelectRow(row, addToSelected);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SelectCol(wxGrid* self, int col, bool addToSelected)
{
    self->SelectCol(col, addToSelected);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SelectBlock(wxGrid* self, int topRow, int leftCol, int bottomRow, int rightCol, bool addToSelected)
{
    self->SelectBlock(topRow, leftCol, bottomRow, rightCol, addToSelected);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SelectAll(wxGrid* self)
{
    self->SelectAll();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGrid_IsSelection(wxGrid* self)
{
    return self->IsSelection()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_DeselectRow(wxGrid* self, int row)
{
    self->DeselectRow(row);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_DeselectCol(wxGrid* self, int col)
{
    self->DeselectCol(col);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_DeselectCell(wxGrid* self, int row, int col)
{
    self->DeselectCell(row, col);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_ClearSelection(wxGrid* self)
{
    self->ClearSelection();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGrid_IsInSelection(wxGrid* self, int row, int col)
{
    return self->IsInSelection(row, col)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxGridCellCoordsArray*)
  wxGrid_GetSelectedCells(wxGrid* self)
{
    return new wxGridCellCoordsArray(self->GetSelectedCells());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxGridCellCoordsArray*)
  wxGrid_GetSelectionBlockTopLeft(wxGrid* self)
{
    return new wxGridCellCoordsArray(self->GetSelectionBlockTopLeft());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxGridCellCoordsArray*)
  wxGrid_GetSelectionBlockBottomRight(wxGrid* self)
{
    return new wxGridCellCoordsArray(self->GetSelectionBlockBottomRight());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxArrayInt*)
  wxGrid_GetSelectedRows(wxGrid* self)
{
    return new wxArrayInt(self->GetSelectedRows());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxArrayInt*)
  wxGrid_GetSelectedCols(wxGrid* self)
{
    return new wxArrayInt(self->GetSelectedCols());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_BlockToDeviceRect(wxGrid* self, wxGridCellCoords * topLeft, wxGridCellCoords * bottomRight, wxRect* rc)
{
    *rc = self->BlockToDeviceRect(*topLeft, *bottomRight);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxColour*)
  wxGrid_GetSelectionBackground(wxGrid* self)
{
    return new wxColour(self->GetSelectionBackground());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxColour*)
  wxGrid_GetSelectionForeground(wxGrid* self)
{
    return new wxColour(self->GetSelectionForeground());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SetSelectionBackground(wxGrid* self, wxColour* c)
{
    self->SetSelectionBackground(*c);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SetSelectionForeground(wxGrid* self, wxColour* c)
{
    self->SetSelectionForeground(*c);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_RegisterDataType(wxGrid* self, const wxString* typeName, wxGridCellRenderer* renderer, wxGridCellEditor* editor)
{
   if (self && typeName)
    self->RegisterDataType(*typeName, renderer, editor);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxGridCellEditor*)
  wxGrid_GetDefaultEditorForCell(wxGrid* self, int row, int col)
{
    return self->GetDefaultEditorForCell(row, col);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxGridCellRenderer*)
  wxGrid_GetDefaultRendererForCell(wxGrid* self, int row, int col)
{
    return self->GetDefaultRendererForCell(row, col);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxGridCellEditor*)
  wxGrid_GetDefaultEditorForType(wxGrid* self, const wxString* typeName)
{
   if (self && typeName)
    return self->GetDefaultEditorForType(*typeName);
   return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxGridCellRenderer*)
  wxGrid_GetDefaultRendererForType(wxGrid* self, const wxString* typeName)
{
   if (self && typeName)
    return self->GetDefaultRendererForType(*typeName);
   return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SetMargins(wxGrid* self, int extraWidth, int extraHeight)
{
    self->SetMargins(extraWidth, extraHeight);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxWindow*)
  wxGrid_GetGridWindow(wxGrid* self)
{
    return self->GetGridWindow();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxWindow*)
  wxGrid_GetGridRowLabelWindow(wxGrid* self)
{
    return self->GetGridRowLabelWindow();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxWindow*)
  wxGrid_GetGridColLabelWindow(wxGrid* self)
{
    return self->GetGridColLabelWindow();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxWindow*)
  wxGrid_GetGridCornerLabelWindow(wxGrid* self)
{
    return self->GetGridCornerLabelWindow();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_UpdateDimensions(wxGrid* self)
{
    self->UpdateDimensions();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxGrid_GetRows(wxGrid* self)
{
    return self->GetRows();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxGrid_GetCols(wxGrid* self)
{
    return self->GetCols();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxGrid_GetCursorRow(wxGrid* self)
{
    return self->GetCursorRow();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxGrid_GetCursorColumn(wxGrid* self)
{
    return self->GetCursorColumn();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxGrid_GetScrollPosX(wxGrid* self)
{
    return self->GetScrollPosX();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxGrid_GetScrollPosY(wxGrid* self)
{
    return self->GetScrollPosY();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SetScrollX(wxGrid* self, int x)
{
    self->SetScrollX(x);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SetScrollY(wxGrid* self, int y)
{
    self->SetScrollY(y);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SetColumnWidth(wxGrid* self, int col, int width)
{
    self->SetColumnWidth(col, width);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxGrid_GetColumnWidth(wxGrid* self, int col)
{
    return self->GetColumnWidth(col);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SetRowHeight(wxGrid* self, int row, int height)
{
    self->SetRowHeight(row, height);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxGrid_GetViewHeight(wxGrid* self)
{
    return self->GetViewHeight();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxGrid_GetViewWidth(wxGrid* self)
{
    return self->GetViewWidth();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SetLabelSize(wxGrid* self, int orientation, int sz)
{
    self->SetLabelSize(orientation, sz);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxGrid_GetLabelSize(wxGrid* self, int orientation)
{
    return self->GetLabelSize(orientation);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SetLabelAlignment(wxGrid* self, int orientation, int align)
{
    self->SetLabelAlignment(orientation, align);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxGrid_GetLabelAlignment(wxGrid* self, int orientation, int align)
{
    return self->GetLabelAlignment(orientation, align);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SetLabelValue(wxGrid* self, int orientation, const wxString* val, int pos)
{
   if (self && val)
    self->SetLabelValue(orientation, *val, pos);
}

WXNET_EXPORT(wxString*)
  wxGrid_GetLabelValue(wxGrid* self, int orientation, int pos)
{
    return new wxString(self->GetLabelValue(orientation, pos));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxFont*)
  wxGrid_GetCellTextFontGrid(wxGrid* self)
{
    return new wxFont(self->GetCellTextFont());
}

WXNET_EXPORT(wxFont*)
  wxGrid_GetCellTextFont(wxGrid* self, int row, int col)
{
    return new wxFont(self->GetCellTextFont(row, col));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SetCellTextFontGrid(wxGrid* self, wxFont* fnt)
{
    self->SetCellTextFont(*fnt);
}

WXNET_EXPORT(void)
  wxGrid_SetCellTextFont(wxGrid* self, wxFont* fnt, int row, int col)
{
    self->SetCellTextFont(*fnt, row, col);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SetCellTextColour(wxGrid* self, int row, int col, wxColour* val)
{
    self->SetCellTextColour(row, col, *val);
}

WXNET_EXPORT(void)
  wxGrid_SetCellTextColourGrid(wxGrid* self, wxColour* col)
{
    self->SetCellTextColour(*col);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SetCellBackgroundColourGrid(wxGrid* self, wxColour* col)
{
    self->SetCellBackgroundColour(*col);
}

WXNET_EXPORT(void)
  wxGrid_SetCellBackgroundColour(wxGrid* self, int row, int col, wxColour* colour)
{
    self->SetCellBackgroundColour(row, col, *colour);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGrid_GetEditable(wxGrid* self)
{
    return self->GetEditable()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SetEditable(wxGrid* self, bool edit)
{
    self->SetEditable(edit);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGrid_GetEditInPlace(wxGrid* self)
{
    return self->GetEditInPlace()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SetCellAlignment(wxGrid* self, int align, int row, int col)
{
    self->SetCellAlignment(align, row, col);
}

WXNET_EXPORT(void)
  wxGrid_SetCellAlignmentGrid(wxGrid* self, int align)
{
    self->SetCellAlignment(align);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SetCellBitmap(wxGrid* self, wxBitmap* bitmap, int row, int col)
{
    self->SetCellBitmap(bitmap, row, col);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_SetDividerPen(wxGrid* self, wxPen* pen)
{
    self->SetDividerPen(*pen);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxPen*)
  wxGrid_GetDividerPen(wxGrid* self)
{
    return &(self->GetDividerPen());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGrid_OnActivate(wxGrid* self, bool active)
{
    self->OnActivate(active);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxGrid_GetRowHeight(wxGrid* self, int row)
{
    return self->GetRowHeight(row);
}

//-----------------------------------------------------------------------------
// wxGridCellCoords

WXNET_EXPORT(wxGridCellCoords*)
  wxGridCellCoords_ctor()
{
    return new wxGridCellCoords();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGridCellCoords_dtor(wxGridCellCoords* self)
{
	WXNET_DEL( self );
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxGridCellCoords_GetRow(wxGridCellCoords* self)
{
    return self->GetRow();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGridCellCoords_SetRow(wxGridCellCoords* self, int n)
{
    self->SetRow(n);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxGridCellCoords_GetCol(wxGridCellCoords* self)
{
    return self->GetCol();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGridCellCoords_SetCol(wxGridCellCoords* self, int n)
{
    self->SetCol(n);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGridCellCoords_Set(wxGridCellCoords* self, int row, int col)
{
    self->Set(row, col);
}


WXNET_EXPORT(void) wxGridCellCoordsArray_dtor(wxGridCellCoordsArray* self)
{
   WXNET_DEL(self);
}

WXNET_EXPORT(wxGridCellCoords*) wxGridCellCoordsArray_Item(const wxGridCellCoordsArray* self, int num)
{
   if (self && num >= 0 && num <= (int)self->Count())
      return &self->Item(num);
   else
      return NULL;
}

WXNET_EXPORT(int) wxGridCellCoordsArray_GetCount(const wxGridCellCoordsArray* self)
{
   if (self)
      return self->Count();
   else
      return 0;
}


//-----------------------------------------------------------------------------
// wxGridCellAttr

class _GridCellAttr : public wxGridCellAttr
{
   DECLARE_DISPOSABLE(_GridCellAttr)
public:
   _GridCellAttr(const wxColour& colText, const wxColour& colBack, const wxFont& font, int hAlign, int vAlign)
      : wxGridCellAttr(colText, colBack, font, hAlign, vAlign)
      , m_onDispose(0)
   {
   }

   _GridCellAttr(wxGridCellAttr* attrDefault)
      : wxGridCellAttr(attrDefault)
      , m_onDispose(0)
   {
   }

   _GridCellAttr()
      : m_onDispose(0)
   {
   }
};

WXNET_EXPORT(_GridCellAttr*)
  wxGridCellAttr_ctor(wxColour* colText, wxColour* colBack, wxFont* font, int hAlign, int vAlign)
{
    if (colText && colBack && font)
        return new _GridCellAttr(*colText, *colBack, *font, hAlign, vAlign);
    else
    {
        _GridCellAttr* result=new _GridCellAttr();
        result->SetAlignment(hAlign, vAlign);
        if (colText)
            result->SetTextColour(*colText);
        if (colBack)
            result->SetBackgroundColour(*colBack);
        if (font)
            result->SetFont(*font);
        return result;
    }
}

WXNET_EXPORT(_GridCellAttr*)
  wxGridCellAttr_ctor2()
{
    return new _GridCellAttr();
}

WXNET_EXPORT(_GridCellAttr*)
  wxGridCellAttr_ctor3(wxGridCellAttr* attrDefault)
{
    return new _GridCellAttr(attrDefault);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGridCellAttr_RegisterDispose(_GridCellAttr* self, Virtual_Dispose onDispose)
{
   if (self) self->RegisterDispose(onDispose);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(_GridCellAttr*)
  wxGridCellAttr_Clone(wxGridCellAttr* self)
{
    return new _GridCellAttr(self);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGridCellAttr_MergeWith(wxGridCellAttr* self, wxGridCellAttr* mergefrom)
{
    self->MergeWith(mergefrom);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGridCellAttr_IncRef(wxGridCellAttr* self)
{
    self->IncRef();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGridCellAttr_DecRef(wxGridCellAttr* self)
{
    self->DecRef();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGridCellAttr_SetTextColour(wxGridCellAttr* self, wxColour* colText)
{
    self->SetTextColour(*colText);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGridCellAttr_SetBackgroundColour(wxGridCellAttr* self, wxColour* colBack)
{
    self->SetBackgroundColour(*colBack);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGridCellAttr_SetFont(wxGridCellAttr* self, wxFont* font)
{
    self->SetFont(*font);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGridCellAttr_SetAlignment(wxGridCellAttr* self, int hAlign, int vAlign)
{
    self->SetAlignment(hAlign, vAlign);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGridCellAttr_SetSize(wxGridCellAttr* self, int num_rows, int num_cols)
{
    self->SetSize(num_rows, num_cols);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGridCellAttr_SetOverflow(wxGridCellAttr* self, bool allow)
{
    self->SetOverflow(allow);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGridCellAttr_SetReadOnly(wxGridCellAttr* self, bool isReadOnly)
{
    self->SetReadOnly(isReadOnly);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGridCellAttr_SetRenderer(wxGridCellAttr* self, wxGridCellRenderer* renderer)
{
    self->SetRenderer(renderer);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGridCellAttr_SetEditor(wxGridCellAttr* self, wxGridCellEditor* editor)
{
    self->SetEditor(editor);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGridCellAttr_HasTextColour(wxGridCellAttr* self)
{
    return self->HasTextColour()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGridCellAttr_HasBackgroundColour(wxGridCellAttr* self)
{
    return self->HasBackgroundColour()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGridCellAttr_HasFont(wxGridCellAttr* self)
{
    return self->HasFont()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGridCellAttr_HasAlignment(wxGridCellAttr* self)
{
    return self->HasAlignment()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGridCellAttr_HasRenderer(wxGridCellAttr* self)
{
    return self->HasRenderer()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGridCellAttr_HasEditor(wxGridCellAttr* self)
{
    return self->HasEditor()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGridCellAttr_HasReadWriteMode(wxGridCellAttr* self)
{
    return self->HasReadWriteMode()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxColour*)
  wxGridCellAttr_GetTextColour(wxGridCellAttr* self)
{
    return new wxColour(self->GetTextColour());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxColour*)
  wxGridCellAttr_GetBackgroundColour(wxGridCellAttr* self)
{
    return new wxColour(self->GetBackgroundColour());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxFont*)
  wxGridCellAttr_GetFont(wxGridCellAttr* self)
{
    return new wxFont(self->GetFont());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGridCellAttr_GetAlignment(wxGridCellAttr* self, int* hAlign, int* vAlign)
{
    self->GetAlignment(hAlign, vAlign);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGridCellAttr_GetSize(wxGridCellAttr* self, int* num_rows, int* num_cols)
{
    self->GetSize(num_rows, num_cols);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGridCellAttr_GetOverflow(wxGridCellAttr* self)
{
    return self->GetOverflow()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxGridCellRenderer*)
  wxGridCellAttr_GetRenderer(wxGridCellAttr* self, wxGrid* grid, int row, int col)
{
    return self->GetRenderer(grid, row, col);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxGridCellEditor*)
  wxGridCellAttr_GetEditor(wxGridCellAttr* self, wxGrid* grid, int row, int col)
{
    return self->GetEditor(grid, row, col);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGridCellAttr_IsReadOnly(wxGridCellAttr* self)
{
    return self->IsReadOnly()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGridCellAttr_SetDefAttr(wxGridCellAttr* self, wxGridCellAttr* defAttr)
{
    self->SetDefAttr(defAttr);
}

//-----------------------------------------------------------------------------
// wxGridSizeEvent

WXNET_EXPORT(wxGridSizeEvent*)
  wxGridSizeEvent_ctor()
{
    return new wxGridSizeEvent();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxGridSizeEvent*)
  wxGridSizeEvent_ctorParam(int id, wxEventType type, wxObject* obj, int rowOrCol, int x, int y, bool control, bool shift, bool alt, bool meta)
{
    return new wxGridSizeEvent(id, type, obj, rowOrCol, x, y, control, shift, alt, meta);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxGridSizeEvent_GetRowOrCol(wxGridSizeEvent* self)
{
    return self->GetRowOrCol();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGridSizeEvent_GetPosition(wxGridSizeEvent* self, wxPoint* pt)
{
    *pt = self->GetPosition();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGridSizeEvent_ControlDown(wxGridSizeEvent* self)
{
    return self->ControlDown()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGridSizeEvent_MetaDown(wxGridSizeEvent* self)
{
    return self->MetaDown()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGridSizeEvent_ShiftDown(wxGridSizeEvent* self)
{
    return self->ShiftDown()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGridSizeEvent_AltDown(wxGridSizeEvent* self)
{
    return self->AltDown()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGridSizeEvent_Veto(wxGridSizeEvent* self)
{
    self->Veto();
}

WXNET_EXPORT(void)
  wxGridSizeEvent_Allow(wxGridSizeEvent* self)
{
    self->Allow();
}

WXNET_EXPORT(char)
  wxGridSizeEvent_IsAllowed(wxGridSizeEvent* self)
{
    return self->IsAllowed()?1:0;
}

//-----------------------------------------------------------------------------
// wxGridCellEditor

typedef void (CALLBACK* Virtual_Create) (wxWindow*, wxWindowID id, wxEvtHandler*);
typedef void (CALLBACK* Virtual_BeginEdit) (int, int, wxGrid*);
typedef bool (CALLBACK* Virtual_EndEdit) (int, int, wxGrid*);
typedef void (CALLBACK* Virtual_Reset) ();
typedef wxGridCellEditor* (CALLBACK* Virtual_Clone) ();
typedef void (CALLBACK* Virtual_SetSize) (wxRect*);
typedef void (CALLBACK* Virtual_Show) (int, wxGridCellAttr*);
typedef void (CALLBACK* Virtual_PaintBackground) (wxRect*, wxGridCellAttr*);
typedef bool (CALLBACK* Virtual_IsAcceptedKey) (wxKeyEvent*);
typedef void (CALLBACK* Virtual_StartingKey) (wxKeyEvent*);
typedef void (CALLBACK* Virtual_StartingClick) ();
typedef void (CALLBACK* Virtual_HandleReturn) (wxKeyEvent*);
typedef void (CALLBACK* Virtual_Destroy) ();
typedef _DisposableStringBox* (CALLBACK* Virtual_GetValue) ();


wxClassInfo wxGridCellEditor_ms_classInfo(wxT("wxGridCellEditor"),
            NULL,
            NULL,
            (int) sizeof(wxGridCellEditor),
            NULL);

class _GridCellEditor : public wxGridCellEditor
{
public:
    DECLARE_DISPOSABLE(_GridCellEditor)
    _GridCellEditor()
        : wxGridCellEditor(), m_onDispose(0), m_BeginEdit(0), m_EndEdit(0), m_Reset(0), m_Clone(0), m_SetSize(0), m_Show(0), m_PaintBackground(0), m_IsAcceptedKey(0), m_StartingKey(0), m_StartingClick(0), m_HandleReturn(0), m_Destroy(0), m_GetValue(0)
    {}
        
    void Create(wxWindow* parent, wxWindowID id, wxEvtHandler* evtHandler)
        { if (m_Create) m_Create(parent, id, evtHandler); }

    void BeginEdit(int row, int col, wxGrid* grid)
        { if (m_BeginEdit) return m_BeginEdit(row, col, grid); }
        
    bool EndEdit(int row, int col, wxGrid* grid)
        { if (m_EndEdit) return m_EndEdit(row, col, grid); else return false; }
            
    void Reset()
        { if (m_Reset) m_Reset(); }
        
    wxGridCellEditor* Clone() const
        { if (m_Clone) return m_Clone(); else return NULL; }
    
    void SetSize(const wxRect& rect)
        { if (m_SetSize) m_SetSize(new wxRect(rect)); }
    
    void Show(bool show, wxGridCellAttr* attr)
    { if (m_Show) m_Show((int)show, attr); else wxGridCellEditor::Show(show, attr);}
    
    void PaintBackground(const wxRect& rectCell, wxGridCellAttr* attr)
        { if (m_PaintBackground) m_PaintBackground(new wxRect(rectCell), attr);}
    
    bool IsAcceptedKey(wxKeyEvent& event)
        { if (m_IsAcceptedKey) return m_IsAcceptedKey(new wxKeyEvent(event)); else return false;}
    
    void StartingKey(wxKeyEvent& event)
        { if (m_StartingKey) m_StartingKey(new wxKeyEvent(event));}
    
    void StartingClick()
        { if (m_StartingClick) m_StartingClick();}
    
    void HandleReturn(wxKeyEvent& event)
        { if (m_HandleReturn) m_HandleReturn(new wxKeyEvent(event));}
    
    void Destroy()
        { if (m_Destroy) m_Destroy();}
        
    wxString GetValue() const
    {
       _DisposableStringBox* valbox=m_GetValue();
       return _DisposableStringBox::GetValAndDelete(valbox);
    }

    void RegisterVirtual(Virtual_Dispose onDispose,
                            Virtual_Create create,
                            Virtual_BeginEdit beginEdit,
                            Virtual_EndEdit endEdit,
                            Virtual_Reset reset,
                            Virtual_Clone clone,
                            Virtual_SetSize setSize,
                            Virtual_Show show,
                            Virtual_PaintBackground paintBackground,
                            Virtual_IsAcceptedKey isAcceptedKey,
                            Virtual_StartingKey startingKey,
                            Virtual_StartingClick startingClick,
                            Virtual_HandleReturn handleReturn,
                            Virtual_Destroy destroy,
                            Virtual_GetValue getValue)
    {
        m_onDispose=onDispose;
        m_Create = create;
        m_BeginEdit = beginEdit;
        m_EndEdit = endEdit;
        m_Reset = reset;
        m_Clone = clone;
        m_SetSize = setSize;
        m_Show = show;
        m_PaintBackground = paintBackground;
        m_IsAcceptedKey = isAcceptedKey;
        m_StartingKey = startingKey;
        m_StartingClick = startingClick;
        m_HandleReturn = handleReturn;
        m_Destroy = destroy;
        m_GetValue = getValue;
    }
    
private:
    Virtual_Create m_Create;
    Virtual_BeginEdit m_BeginEdit;
    Virtual_EndEdit m_EndEdit;
    Virtual_Reset m_Reset;
    Virtual_Clone m_Clone;
    Virtual_SetSize m_SetSize;
    Virtual_Show m_Show;
    Virtual_PaintBackground m_PaintBackground;
    Virtual_IsAcceptedKey m_IsAcceptedKey;
    Virtual_StartingKey m_StartingKey;
    Virtual_StartingClick m_StartingClick;
    Virtual_HandleReturn m_HandleReturn;
    Virtual_Destroy m_Destroy;
    Virtual_GetValue m_GetValue;
};

WXNET_EXPORT(void)
  wxGridCellEditor_RegisterVirtual(wxGridCellEditor* self,
                        Virtual_Dispose onDispose,
                        Virtual_Create create,
                        Virtual_BeginEdit beginEdit,
                        Virtual_EndEdit endEdit,
                        Virtual_Reset reset,
                        Virtual_Clone clone,
                        Virtual_SetSize setSize,
                        Virtual_Show show,
                        Virtual_PaintBackground paintBackground,
                        Virtual_IsAcceptedKey isAcceptedKey,
                        Virtual_StartingKey startingKey,
                        Virtual_StartingClick startingClick,
                        Virtual_HandleReturn handleReturn,
                        Virtual_Destroy destroy,
                        Virtual_GetValue getvalue)
{
   _GridCellEditor* castedSelf=dynamic_cast<_GridCellEditor*>(self);
   if (castedSelf)
    castedSelf->RegisterVirtual(onDispose, create, beginEdit, endEdit, reset, clone,
                setSize, show, paintBackground, isAcceptedKey, startingKey,
                startingClick, handleReturn, destroy, getvalue);
}

WXNET_EXPORT(void)
  wxGridCellEditor_DeregisterVirtual(wxGridCellEditor* self)
{
   _GridCellEditor* castedSelf=dynamic_cast<_GridCellEditor*>(self);
   if (castedSelf)
    castedSelf->RegisterVirtual(0, 0, 0, 0, 0, 0,
                0, 0, 0, 0, 0,
                0, 0, 0, 0);
}

WXNET_EXPORT(wxGridCellEditor*)
  wxGridCellEditor_ctor()
{
    return new _GridCellEditor();
}

WXNET_EXPORT(void)
  wxGridCellEditor_dtor(_GridCellEditor* self)
{
    WXNET_DEL( self );
}

WXNET_EXPORT(void)
  wxGridCellEditor_Create(_GridCellEditor* self, wxWindow* parent, wxWindowID id, wxEvtHandler* evtHandler)
{
    return self->wxGridCellEditor::Create(parent, id, evtHandler);
}

WXNET_EXPORT(char)
  wxGridCellEditor_IsCreated(_GridCellEditor* self)
{
    return self->IsCreated()?1:0;
}

// HMaH: Missing methods for read/write access to the control.
WXNET_EXPORT(void)
  wxGridCellEditor_SetControl(_GridCellEditor* self, wxControl* control)
{
    self->SetControl(control);
}

// HMaH: Missing methods for read/write access to the control.
WXNET_EXPORT(wxControl*)
  wxGridCellEditor_GetControl(_GridCellEditor* self)
{
    return self->GetControl();
}

WXNET_EXPORT(char)
  wxGridCellEditor_IsAcceptedKey(_GridCellEditor* self, wxKeyEvent* event)
{
    return self->wxGridCellEditor::IsAcceptedKey(*event)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGridCellEditor_SetSize(_GridCellEditor* self, int x, int y, int width, int height)
{
    self->wxGridCellEditor::SetSize(wxRect(x, y, width, height));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGridCellEditor_Show(_GridCellEditor* self, bool show, wxGridCellAttr* attr)
{
    self->wxGridCellEditor::Show(show, attr);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGridCellEditor_PaintBackground(_GridCellEditor* self, wxRect* rectCell, wxGridCellAttr* attr)
{
    self->wxGridCellEditor::PaintBackground(*rectCell, attr);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGridCellEditor_StartingKey(_GridCellEditor* self, wxKeyEvent* event)
{
    self->wxGridCellEditor::StartingKey(*event);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGridCellEditor_StartingClick(_GridCellEditor* self)
{
    self->wxGridCellEditor::StartingClick();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGridCellEditor_HandleReturn(_GridCellEditor* self, wxKeyEvent* event)
{
    self->wxGridCellEditor::HandleReturn(*event);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGridCellEditor_Destroy(_GridCellEditor* self)
{
    self->wxGridCellEditor::Destroy();
}

//-----------------------------------------------------------------------------
// wxGridTableBase...

typedef int (CALLBACK* Virtual_GetNumberRows) ();
typedef int (CALLBACK* Virtual_GetNumberCols) ();
typedef bool (CALLBACK* Virtual_IsEmptyCell) (int, int);
typedef _DisposableStringBox* (CALLBACK* Virtual_GetValue2) (int, int);
typedef void (CALLBACK* Virtual_SetValue) (int, int, wxString*);
typedef bool (CALLBACK* Virtual_CanGetValueAs) (int, int, wxString*);
typedef long (CALLBACK* Virtual_GetValueAsLong) (int, int);
typedef double (CALLBACK* Virtual_GetValueAsDouble) (int, int);
typedef void (CALLBACK* Virtual_SetValueAsLong) (int, int, long);
typedef void (CALLBACK* Virtual_SetValueAsDouble) (int, int, double);
typedef void (CALLBACK* Virtual_SetValueAsBool) (int, int, bool);
typedef void* (CALLBACK* Virtual_GetValueAsCustom) (int, int, wxString*);
typedef void (CALLBACK* Virtual_SetValueAsCustom) (int, int, wxString*, void*);
typedef _DisposableStringBox* (CALLBACK* Virtual_GetColLabelValue) (int);
typedef void (CALLBACK* Virtual_SetView) (wxGrid*);
typedef wxGrid* (CALLBACK* Virtual_GetView) ();
typedef void (CALLBACK* Virtual_Clear) ();
typedef bool (CALLBACK* Virtual_InsertRows) (int, int);
typedef bool (CALLBACK* Virtual_AppendRows) (int);
typedef void (CALLBACK* Virtual_SetRowLabelValue) (int, wxString*);
typedef void (CALLBACK* Virtual_SetAttrProvider) (wxGridCellAttrProvider*);
typedef wxGridCellAttrProvider* (CALLBACK* Virtual_GetAttrProvider) ();
typedef bool (CALLBACK* Virtual_CanHaveAttributes) ();
typedef wxGridCellAttr* (CALLBACK* Virtual_GetAttr) (int, int, wxGridCellAttr::wxAttrKind);
typedef void (CALLBACK* Virtual_SetAttr) (wxGridCellAttr*, int, int);
typedef void (CALLBACK* Virtual_SetRowAttr) (wxGridCellAttr*, int);

class _GridTableBase : public wxGridTableBase
{
public:
    _GridTableBase()
        : wxGridTableBase() {}

    int GetNumberRows()
        { return m_GetNumberRows();}

    int GetNumberCols()
        { return m_GetNumberCols();}

    bool IsEmptyCell(int row, int col)
        { return m_IsEmptyCell(row, col);}

    wxString GetValue(int row, int col)
        {
           _DisposableStringBox* valuebox=m_GetValue(row, col);
           return _DisposableStringBox::GetValAndDelete(valuebox);
        }
    void SetValue(int row, int col, const wxString& value)
        { m_SetValue(row, col, new wxString(value));}
    
    wxString GetTypeName(int row, int col)
        {
           _DisposableStringBox* strbox=m_GetTypeName(row, col);
           return _DisposableStringBox::GetValAndDelete(strbox);
        }
    
    bool CanGetValueAs(int row, int col, const wxString& typeName)
        { return m_CanGetValueAs(row, col, new wxString(typeName)); }
    
    bool CanSetValueAs(int row, int col, const wxString& typeName)
        { return m_CanSetValueAs(row, col, new wxString(typeName)); }
    
    long GetValueAsLong(int row, int col)
        { return m_GetValueAsLong(row, col);}
    
    double GetValueAsDouble(int row, int col)
        { return m_GetValueAsDouble(row, col); }
    
    bool GetValueAsBool(int row, int col)
        { return m_GetValueAsBool(row, col);}
    
    void SetValueAsLong(int row, int col, long value)
        { return m_SetValueAsLong(row, col, value);}
    
    void SetValueAsDouble(int row, int col, double value)
        { return m_SetValueAsDouble(row, col, value);}
    
    void SetValueAsBool(int row, int col, bool value)
        { return m_SetValueAsBool(row, col, value);}
    
    void* GetValueAsCustom(int row, int col, const wxString& typeName)
        { return m_GetValueAsCustom(row, col, new wxString(typeName));}
    
    void SetValueAsCustom(int row, int col, const wxString& typeName, void* value)
        { return m_SetValueAsCustom(row, col, new wxString(typeName), value);}
    
    void SetView(wxGrid* grid)
        { return m_SetView(grid);}
    
    wxGrid* GetView()
        { return m_GetView();}
    
    void Clear()
        { return m_Clear();}
    
    bool InsertRows(size_t pos, size_t numRows)
        { return m_InsertRows(pos, numRows);}
    
    bool AppendRows(size_t numRows)
        { return m_AppendRows(numRows);}
    
    bool DeleteRows(size_t pos, size_t numRows)
        { return m_DeleteRows(pos, numRows);}
    
    bool InsertCols(size_t pos, size_t numCols)
        { return m_InsertCols(pos, numCols);}
    
    bool AppendCols(size_t numCols)
        { return m_AppendCols(numCols);}
    
    bool DeleteCols(size_t pos, size_t numCols)
        { return m_DeleteCols(pos, numCols);}
    
    wxString GetRowLabelValue(int col)
        {
           _DisposableStringBox* result=m_GetRowLabelValue(col);
           return _DisposableStringBox::GetValAndDelete(result);
        }
    
    wxString GetColLabelValue(int col)
        {
           _DisposableStringBox* result=m_GetColLabelValue(col);
           return _DisposableStringBox::GetValAndDelete(result);
        }
    
    void SetRowLabelValue(int row, const wxString& value)
        { return m_SetRowLabelValue(row, new wxString(value));}
    
    void SetColLabelValue(int row, const wxString& value)
        { return m_SetColLabelValue(row, new wxString(value));}
    
    void SetAttrProvider(wxGridCellAttrProvider* attrProvider)
        { return m_SetAttrProvider(attrProvider);}
    
    wxGridCellAttrProvider* GetAttrProvider()
        { return m_GetAttrProvider(); }
    
    bool CanHaveAttributes()
        { return m_CanHaveAttributes();}
    
    wxGridCellAttr* GetAttr(int row, int col, wxGridCellAttr::wxAttrKind kind)
        { return m_GetAttr(row, col, kind);}
    
    void SetAttr(wxGridCellAttr* attr, int row, int col)
        { return m_SetAttr(attr, row, col); }
    
    void SetRowAttr(wxGridCellAttr* attr, int row)
        { return m_SetRowAttr(attr, row); }
    
    void SetColAttr(wxGridCellAttr* attr, int col)
        { return m_SetColAttr(attr, col); }

    void RegisterVirtual(Virtual_GetNumberRows getNumberRows,
            Virtual_GetNumberCols getNumberCols,
            Virtual_IsEmptyCell isEmptyCell,
            Virtual_GetValue2 getValue,
            Virtual_SetValue setValue,
            Virtual_GetValue2 getTypeName,
            Virtual_CanGetValueAs canGetValueAs,
            Virtual_CanGetValueAs canSetValueAs,
            Virtual_GetValueAsLong getValueAsLong,
            Virtual_GetValueAsDouble getValueAsDouble,
            Virtual_IsEmptyCell getValueAsBool,
            Virtual_SetValueAsLong setValueAsLong,
            Virtual_SetValueAsDouble setValueAsDouble,
            Virtual_SetValueAsBool setValueAsBool,
            Virtual_GetValueAsCustom getValueAsCustom,
            Virtual_SetValueAsCustom setValueAsCustom,
            Virtual_SetView setView,
            Virtual_GetView getView,
            Virtual_Clear clear,
            Virtual_InsertRows insertRows,
            Virtual_AppendRows appendRows,
            Virtual_InsertRows deleteRows,
            Virtual_InsertRows insertCols,
            Virtual_AppendRows appendCols,
            Virtual_InsertRows deleteCols,
            Virtual_GetColLabelValue getRowLabelValue,
            Virtual_GetColLabelValue getColLabelValue,
            Virtual_SetRowLabelValue setRowLabelValue,
            Virtual_SetRowLabelValue setColLabelValue,
            Virtual_SetAttrProvider setAttrProvider,
            Virtual_GetAttrProvider getAttrProvider,
            Virtual_CanHaveAttributes canHaveAttributes,
            Virtual_GetAttr getAttr,
            Virtual_SetAttr setAttr,
            Virtual_SetRowAttr setRowAttr,
            Virtual_SetRowAttr setColAttr)
        {
            m_GetNumberRows = getNumberRows;
            m_GetNumberCols = getNumberCols;
            m_IsEmptyCell = isEmptyCell;
            m_GetValue = getValue;
            m_SetValue = setValue;
            m_GetTypeName = getTypeName;
            m_CanGetValueAs = canGetValueAs;
            m_CanSetValueAs = canSetValueAs;
            m_GetValueAsLong = getValueAsLong;
            m_GetValueAsDouble = getValueAsDouble;
            m_GetValueAsBool = getValueAsBool;
            m_SetValueAsLong = setValueAsLong;
            m_SetValueAsDouble = setValueAsDouble;
            m_SetValueAsBool = setValueAsBool;
            m_GetValueAsCustom = getValueAsCustom;
            m_SetValueAsCustom = setValueAsCustom;
            m_GetColLabelValue = getColLabelValue;
            m_SetView = setView;
            m_GetView = getView;
            m_Clear = clear;
            m_InsertRows = insertRows;
            m_AppendRows = appendRows;
            m_DeleteRows = deleteRows;
            m_InsertCols = insertCols;
            m_AppendCols = appendCols;
            m_DeleteCols = deleteCols;
            m_GetRowLabelValue = getRowLabelValue;
            m_SetRowLabelValue = setRowLabelValue;
            m_SetColLabelValue = setColLabelValue;
            m_SetAttrProvider = setAttrProvider;
            m_GetAttrProvider = getAttrProvider;
            m_CanHaveAttributes = canHaveAttributes;
            m_GetAttr = getAttr;
            m_SetAttr = setAttr;
            m_SetRowAttr = setRowAttr;
            m_SetColAttr = setColAttr;
        }

private:
    Virtual_GetNumberRows m_GetNumberRows;
    Virtual_GetNumberCols m_GetNumberCols;
    Virtual_IsEmptyCell m_IsEmptyCell;
    Virtual_GetValue2 m_GetValue;
    Virtual_SetValue m_SetValue;
    Virtual_GetValue2 m_GetTypeName;
    Virtual_CanGetValueAs m_CanGetValueAs;
    Virtual_CanGetValueAs m_CanSetValueAs;
    Virtual_GetValueAsLong m_GetValueAsLong;
    Virtual_GetValueAsDouble m_GetValueAsDouble;
    Virtual_IsEmptyCell m_GetValueAsBool;
    Virtual_SetValueAsLong m_SetValueAsLong;
    Virtual_SetValueAsDouble m_SetValueAsDouble;
    Virtual_SetValueAsBool m_SetValueAsBool;
    Virtual_GetValueAsCustom m_GetValueAsCustom;
    Virtual_SetValueAsCustom m_SetValueAsCustom;
    Virtual_GetColLabelValue m_GetColLabelValue;
    Virtual_SetView m_SetView;
    Virtual_GetView m_GetView;
    Virtual_Clear m_Clear;
    Virtual_InsertRows m_InsertRows;
    Virtual_AppendRows m_AppendRows;
    Virtual_InsertRows m_DeleteRows;
    Virtual_InsertRows m_InsertCols;
    Virtual_AppendRows m_AppendCols;
    Virtual_InsertRows m_DeleteCols;
    Virtual_GetColLabelValue m_GetRowLabelValue;
    Virtual_SetRowLabelValue m_SetRowLabelValue;
    Virtual_SetRowLabelValue m_SetColLabelValue;
    Virtual_SetAttrProvider m_SetAttrProvider;
    Virtual_GetAttrProvider m_GetAttrProvider;
    Virtual_CanHaveAttributes m_CanHaveAttributes;
    Virtual_GetAttr m_GetAttr;
    Virtual_SetAttr m_SetAttr;
    Virtual_SetRowAttr m_SetRowAttr;
    Virtual_SetRowAttr m_SetColAttr;
};

WXNET_EXPORT(wxGridTableBase*)
  wxGridTableBase_ctor()
{
    return new _GridTableBase();
}

WXNET_EXPORT(void)
  wxGridTableBase_RegisterVirtual(_GridTableBase* self, Virtual_GetNumberRows getNumberRows,
            Virtual_GetNumberCols getNumberCols,
            Virtual_IsEmptyCell isEmptyCell,
            Virtual_GetValue2 getValue,
            Virtual_SetValue setValue,
            Virtual_GetValue2 getTypeName,
            Virtual_CanGetValueAs canGetValueAs,
            Virtual_CanGetValueAs canSetValueAs,
            Virtual_GetValueAsLong getValueAsLong,
            Virtual_GetValueAsDouble getValueAsDouble,
            Virtual_IsEmptyCell getValueAsBool,
            Virtual_SetValueAsLong setValueAsLong,
            Virtual_SetValueAsDouble setValueAsDouble,
            Virtual_SetValueAsBool setValueAsBool,
            Virtual_GetValueAsCustom getValueAsCustom,
            Virtual_SetValueAsCustom setValueAsCustom,
            Virtual_SetView setView,
            Virtual_GetView getView,
            Virtual_Clear clear,
            Virtual_InsertRows insertRows,
            Virtual_AppendRows appendRows,
            Virtual_InsertRows deleteRows,
            Virtual_InsertRows insertCols,
            Virtual_AppendRows appendCols,
            Virtual_InsertRows deleteCols,
            Virtual_GetColLabelValue getRowLabelValue,
            Virtual_GetColLabelValue getColLabelValue,
            Virtual_SetRowLabelValue setRowLabelValue,
            Virtual_SetRowLabelValue setColLabelValue,
            Virtual_SetAttrProvider setAttrProvider,
            Virtual_GetAttrProvider getAttrProvider,
            Virtual_CanHaveAttributes canHaveAttributes,
            Virtual_GetAttr getAttr,
            Virtual_SetAttr setAttr,
            Virtual_SetRowAttr setRowAttr,
            Virtual_SetRowAttr setColAttr)
{
    self->RegisterVirtual(getNumberRows, getNumberCols, isEmptyCell, getValue, setValue, getTypeName,
        canGetValueAs, canSetValueAs, getValueAsLong, getValueAsDouble, getValueAsBool,
        setValueAsLong, setValueAsDouble, setValueAsBool, getValueAsCustom, setValueAsCustom,
        setView, getView, clear, insertRows, appendRows, deleteRows,
        insertCols, appendCols, deleteCols, getRowLabelValue, getColLabelValue, setRowLabelValue,
        setColLabelValue, setAttrProvider, getAttrProvider, canHaveAttributes, getAttr,
        setAttr, setRowAttr, setColAttr);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxGridTableBase_GetTypeName(_GridTableBase* self, int row, int col)
{
    return new wxString(self->wxGridTableBase::GetTypeName(row, col));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGridTableBase_CanGetValueAs(_GridTableBase* self, int row, int col, const wxString* typeName)
{
   if (self && typeName)
    return self->wxGridTableBase::CanGetValueAs(row, col, *typeName)?1:0;
   return false;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGridTableBase_CanSetValueAs(_GridTableBase* self, int row, int col, const wxString* typeName)
{
   if (self && typeName)
    return self->wxGridTableBase::CanSetValueAs(row, col, *typeName)?1:0;
   return false;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(long)
  wxGridTableBase_GetValueAsLong(_GridTableBase* self, int row, int col)
{
    return self->wxGridTableBase::GetValueAsLong(row, col);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(double)
  wxGridTableBase_GetValueAsDouble(_GridTableBase* self, int row, int col)
{
    return self->wxGridTableBase::GetValueAsDouble(row, col);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGridTableBase_GetValueAsBool(_GridTableBase* self, int row, int col)
{
    return self->wxGridTableBase::GetValueAsBool(row, col)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGridTableBase_SetValueAsLong(_GridTableBase* self, int row, int col, long value)
{
    self->wxGridTableBase::SetValueAsLong(row, col, value);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGridTableBase_SetValueAsDouble(_GridTableBase* self, int row, int col, double value)
{
    self->wxGridTableBase::SetValueAsDouble(row, col, value);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGridTableBase_SetValueAsBool(_GridTableBase* self, int row, int col, bool value)
{
    self->wxGridTableBase::SetValueAsBool(row, col, value);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void*)
  wxGridTableBase_GetValueAsCustom(_GridTableBase* self, int row, int col, const wxString* typeName)
{
    if (self && typeName)
     return self->wxGridTableBase::GetValueAsCustom(row, col, *typeName);
   return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGridTableBase_SetValueAsCustom(_GridTableBase* self, int row, int col, const wxString* typeName, void* value)
{
    if (self && typeName)
    self->wxGridTableBase::SetValueAsCustom(row, col, *typeName, value);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGridTableBase_SetView(_GridTableBase* self, wxGrid* grid)
{
    self->wxGridTableBase::SetView(grid);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxGrid*)
  wxGridTableBase_GetView(_GridTableBase* self)
{
    return self->wxGridTableBase::GetView();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGridTableBase_Clear(_GridTableBase* self)
{
    self->wxGridTableBase::Clear();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGridTableBase_InsertRows(_GridTableBase* self, int pos, int numRows)
{
    return self->wxGridTableBase::InsertRows(pos, numRows)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGridTableBase_AppendRows(_GridTableBase* self, int numRows)
{
    return self->wxGridTableBase::AppendRows(numRows)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGridTableBase_DeleteRows(_GridTableBase* self, int pos, int numRows)
{
    return self->wxGridTableBase::DeleteRows(pos, numRows)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGridTableBase_InsertCols(_GridTableBase* self, int pos, int numCols)
{
    return self->wxGridTableBase::InsertCols(pos, numCols)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGridTableBase_AppendCols(_GridTableBase* self, int numCols)
{
    return self->wxGridTableBase::AppendCols(numCols)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGridTableBase_DeleteCols(_GridTableBase* self, int pos, int numCols)
{
    return self->wxGridTableBase::DeleteCols(pos, numCols)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxGridTableBase_GetRowLabelValue(_GridTableBase* self, int row)
{
    return new wxString(self->wxGridTableBase::GetRowLabelValue(row));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxGridTableBase_GetColLabelValue(_GridTableBase* self, int col)
{
    return new wxString(self->wxGridTableBase::GetColLabelValue(col));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGridTableBase_SetRowLabelValue(_GridTableBase* self, int row, const wxString* value)
{
   if (self && value)
      self->wxGridTableBase::SetRowLabelValue(row, *value);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGridTableBase_SetColLabelValue(_GridTableBase* self, int col, const wxString* value)
{
   if (self && value)
    self->wxGridTableBase::SetColLabelValue(col, *value);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGridTableBase_SetAttrProvider(_GridTableBase* self, wxGridCellAttrProvider* attrProvider)
{
    self->wxGridTableBase::SetAttrProvider(attrProvider);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxGridCellAttrProvider*)
  wxGridTableBase_GetAttrProvider(_GridTableBase* self)
{
    return self->wxGridTableBase::GetAttrProvider();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGridTableBase_CanHaveAttributes(_GridTableBase* self)
{
    return self->wxGridTableBase::CanHaveAttributes()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxGridCellAttr*)
  wxGridTableBase_GetAttr(_GridTableBase* self, int row, int col, wxGridCellAttr::wxAttrKind kind)
{
    return self->wxGridTableBase::GetAttr(row, col, kind);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGridTableBase_SetAttr(_GridTableBase* self, wxGridCellAttr* attr, int row, int col)
{
    self->wxGridTableBase::SetAttr(attr, row, col);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGridTableBase_SetRowAttr(_GridTableBase* self, wxGridCellAttr* attr, int row)
{
    self->wxGridTableBase::SetRowAttr(attr, row);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGridTableBase_SetColAttr(_GridTableBase* self, wxGridCellAttr* attr, int col)
{
    self->wxGridTableBase::SetColAttr(attr, col);
}

//-----------------------------------------------------------------------------
// wxGridCellTextEditor

WXNET_EXPORT(wxGridCellTextEditor*)
  wxGridCellTextEditor_ctor()
{
    return new wxGridCellTextEditor();
}

wxClassInfo wxGridCellTextEditor_ms_classInfo(wxT("wxGridCellTextEditor"),
            &wxGridCellEditor_ms_classInfo,
            NULL,
            (int) sizeof(wxGridCellTextEditor),
            NULL);

WXNET_EXPORT(wxClassInfo*)
   GridCellTextEditor_GetWxClassInfo(void)
{
   return &wxGridCellTextEditor_ms_classInfo;
}

WXNET_EXPORT(void)
  wxGridCellTextEditor_dtor(wxGridCellTextEditor* self)
{
	WXNET_DEL( self );
}

WXNET_EXPORT(void)
  wxGridCellTextEditor_Create(wxGridCellTextEditor* self, wxWindow* parent, wxWindowID id, wxEvtHandler* evtHandler)
{
    self->Create(parent, id, evtHandler);
}

WXNET_EXPORT(void)
  wxGridCellTextEditor_SetSize(wxGridCellTextEditor* self, wxRect* rect)
{
    self->SetSize(*rect);
}

WXNET_EXPORT(void)
  wxGridCellTextEditor_PaintBackground(wxGridCellTextEditor* self, wxRect* rectCell, wxGridCellAttr* attr)
{
    self->PaintBackground(*rectCell, attr);
}

WXNET_EXPORT(char)
  wxGridCellTextEditor_IsAcceptedKey(wxGridCellTextEditor* self, wxKeyEvent* event)
{
    return self->IsAcceptedKey(*event)?1:0;
}

WXNET_EXPORT(void)
  wxGridCellTextEditor_BeginEdit(wxGridCellTextEditor* self, int row, int col, wxGrid* grid)
{
    return self->BeginEdit(row, col, grid);
}

WXNET_EXPORT(char)
  wxGridCellTextEditor_EndEdit(wxGridCellTextEditor* self, int row, int col, wxGrid* grid)
{
    return self->EndEdit(row, col, grid)?1:0;
}

WXNET_EXPORT(void)
  wxGridCellTextEditor_Reset(wxGridCellTextEditor* self)
{
    return self->Reset();
}

WXNET_EXPORT(void)
  wxGridCellTextEditor_StartingKey(wxGridCellTextEditor* self, wxKeyEvent* event)
{
    return self->StartingKey(*event);
}

WXNET_EXPORT(void)
  wxGridCellTextEditor_SetParameters(wxGridCellTextEditor* self, const wxString* params)
{
   if (self && params)
    self->SetParameters(*params);
}

WXNET_EXPORT(wxGridCellEditor*)
  wxGridCellTextEditor_Clone(wxGridCellTextEditor* self)
{
    return self->Clone();
}

//-----------------------------------------------------------------------------
// wxGridCellAttrProvider

class _GridCellAttrProvider : public wxGridCellAttrProvider
{
    Virtual_GetAttr m_GetAttr;
    Virtual_SetAttr m_SetAttr;
    Virtual_SetRowAttr m_SetRowAttr;
    Virtual_SetRowAttr m_SetColAttr;

public:
    Virtual_Dispose m_onDispose;

    _GridCellAttrProvider()
        : m_onDispose(0), m_GetAttr(0), m_SetAttr(0), m_SetRowAttr(0), m_SetColAttr(0) {}

    virtual ~_GridCellAttrProvider() { if (m_onDispose) m_onDispose(); }
        
    wxGridCellAttr* GetAttr(int row, int col, wxGridCellAttr::wxAttrKind kind)
        { if (m_GetAttr) return m_GetAttr(row, col, kind); else return NULL;}
    
    void SetAttr(wxGridCellAttr* attr, int row, int col)
        { if (m_SetAttr) m_SetAttr(attr, row, col); }
    
    void SetRowAttr(wxGridCellAttr* attr, int row)
        { if (m_SetRowAttr) m_SetRowAttr(attr, row); }
    
    void SetColAttr(wxGridCellAttr* attr, int col)
        { if (m_SetColAttr) m_SetColAttr(attr, col); } 

    void RegisterVirtual(Virtual_Dispose onDispose,
        Virtual_GetAttr getAttr,
        Virtual_SetAttr setAttr,
        Virtual_SetRowAttr setRowAttr,
        Virtual_SetRowAttr setColAttr)
        {
            m_onDispose = onDispose;
            m_GetAttr = getAttr;
            m_SetAttr = setAttr;
            m_SetRowAttr = setRowAttr;
            m_SetColAttr = setColAttr;
        }
};

WXNET_EXPORT(wxGridCellAttrProvider*)
  wxGridCellAttrProvider_ctor()
{
    return new _GridCellAttrProvider();
}

WXNET_EXPORT(void)
  wxGridCellAttrProvider_dtor(_GridCellAttrProvider* self)
{
	WXNET_DEL(self);
}

WXNET_EXPORT(void)
  wxGridCellAttrProvider_RegisterVirtual(_GridCellAttrProvider* self, 
    Virtual_Dispose onDispose,
    Virtual_GetAttr getAttr,
    Virtual_SetAttr setAttr,
    Virtual_SetRowAttr setRowAttr,
    Virtual_SetRowAttr setColAttr)
{
    self->RegisterVirtual(onDispose, getAttr, setAttr, setRowAttr, setColAttr);
}

WXNET_EXPORT(wxGridCellAttr*)
  wxGridCellAttrProvider_GetAttr(_GridCellAttrProvider* self, int row, int col, wxGridCellAttr::wxAttrKind kind)
{
    return self->wxGridCellAttrProvider::GetAttr(row, col, kind);
}

WXNET_EXPORT(void)
  wxGridCellAttrProvider_SetAttr(_GridCellAttrProvider* self, wxGridCellAttr* attr, int row, int col)
{
    self->wxGridCellAttrProvider::SetAttr(attr, row, col);
}

WXNET_EXPORT(void)
  wxGridCellAttrProvider_SetRowAttr(_GridCellAttrProvider* self, wxGridCellAttr* attr, int row)
{
    self->wxGridCellAttrProvider::SetRowAttr(attr, row);
}

WXNET_EXPORT(void)
  wxGridCellAttrProvider_SetColAttr(_GridCellAttrProvider* self, wxGridCellAttr* attr, int col)
{
    self->wxGridCellAttrProvider::SetColAttr(attr, col);
}

WXNET_EXPORT(void)
  wxGridCellAttrProvider_UpdateAttrRows(_GridCellAttrProvider* self, int pos, int numRows)
{
    self->UpdateAttrRows(pos, numRows);
}

WXNET_EXPORT(void)
  wxGridCellAttrProvider_UpdateAttrCols(_GridCellAttrProvider* self, int pos, int numCols)
{
    self->UpdateAttrCols(pos, numCols);
}

//-----------------------------------------------------------------------------
// wxGridCellNumberEditor

class _GridCellNumberEditor : public wxGridCellNumberEditor
{
public:
	_GridCellNumberEditor(int min, int max)
		: wxGridCellNumberEditor(min, max) {}

	DECLARE_DISPOSABLE(_GridCellNumberEditor)
};

wxClassInfo wxGridCellNumberEditor_ms_classInfo(wxT("wxGridCellNumberEditor"),
            &wxGridCellEditor_ms_classInfo,
            NULL,
            (int) sizeof(wxGridCellNumberEditor),
            NULL);

WXNET_EXPORT(wxClassInfo*)
   GridCellNumberEditor_GetWxClassInfo(void)
{
   return &wxGridCellNumberEditor_ms_classInfo;
}

WXNET_EXPORT(wxGridCellNumberEditor*)
  wxGridCellNumberEditor_ctor(int min, int max)
{
    return new _GridCellNumberEditor(min, max);
}

WXNET_EXPORT(void)
  wxGridCellNumberEditor_dtor(wxGridCellNumberEditor* self)
{
    WXNET_DEL(self);
}

WXNET_EXPORT(void)
  wxGridCellNumberEditor_RegisterDisposable(_GridCellNumberEditor* self, Virtual_Dispose onDispose)
{
	self->RegisterDispose(onDispose);
}

WXNET_EXPORT(void)
  wxGridCellNumberEditor_Create(wxGridCellNumberEditor* self, wxWindow* parent, wxWindowID id, wxEvtHandler* evtHandler)
{
    self->Create(parent, id, evtHandler);
}

WXNET_EXPORT(char)
  wxGridCellNumberEditor_IsAcceptedKey(wxGridCellNumberEditor* self, wxKeyEvent* event)
{
    return self->IsAcceptedKey(*event)?1:0;
}

WXNET_EXPORT(void)
  wxGridCellNumberEditor_BeginEdit(wxGridCellNumberEditor* self, int row, int col, wxGrid* grid)
{
    return self->BeginEdit(row, col, grid);
}

WXNET_EXPORT(char)
  wxGridCellNumberEditor_EndEdit(wxGridCellNumberEditor* self, int row, int col, wxGrid* grid)
{
    return self->EndEdit(row, col, grid)?1:0;
}

WXNET_EXPORT(void)
  wxGridCellNumberEditor_Reset(wxGridCellNumberEditor* self)
{
    return self->Reset();
}

WXNET_EXPORT(void)
  wxGridCellNumberEditor_StartingKey(wxGridCellNumberEditor* self, wxKeyEvent* event)
{
    return self->StartingKey(*event);
}

WXNET_EXPORT(void)
  wxGridCellNumberEditor_SetParameters(wxGridCellNumberEditor* self, const wxString* params)
{
   if (self && params)
    self->SetParameters(*params);
}

WXNET_EXPORT(wxGridCellEditor*)
  wxGridCellNumberEditor_Clone(wxGridCellNumberEditor* self)
{
    return self->Clone();
}

//-----------------------------------------------------------------------------
// wxGridCellFloatEditor


wxClassInfo wxGridCellFloatEditor_ms_classInfo(wxT("wxGridCellFloatEditor"),
            &wxGridCellEditor_ms_classInfo,
            NULL,
            (int) sizeof(wxGridCellFloatEditor),
            NULL);

WXNET_EXPORT(wxClassInfo*)
   GridCellFloatEditor_GetWxClassInfo(void)
{
   return &wxGridCellFloatEditor_ms_classInfo;
}


WXNET_EXPORT(wxGridCellFloatEditor*)
  wxGridCellFloatEditor_ctor(int width, int precision)
{
    return new wxGridCellFloatEditor(width, precision);
}

WXNET_EXPORT(void)
  wxGridCellFloatEditor_dtor(wxGridCellFloatEditor* self)
{
	WXNET_DEL(self);
}

WXNET_EXPORT(void)
  wxGridCellFloatEditor_Create(wxGridCellFloatEditor* self, wxWindow* parent, wxWindowID id, wxEvtHandler* evtHandler)
{
    self->Create(parent, id, evtHandler);
}

WXNET_EXPORT(char)
  wxGridCellFloatEditor_IsAcceptedKey(wxGridCellFloatEditor* self, wxKeyEvent* event)
{
    return self->IsAcceptedKey(*event)?1:0;
}

WXNET_EXPORT(void)
  wxGridCellFloatEditor_BeginEdit(wxGridCellFloatEditor* self, int row, int col, wxGrid* grid)
{
    return self->BeginEdit(row, col, grid);
}

WXNET_EXPORT(char)
  wxGridCellFloatEditor_EndEdit(wxGridCellFloatEditor* self, int row, int col, wxGrid* grid)
{
    return self->EndEdit(row, col, grid)?1:0;
}

WXNET_EXPORT(void)
  wxGridCellFloatEditor_Reset(wxGridCellFloatEditor* self)
{
    return self->Reset();
}

WXNET_EXPORT(void)
  wxGridCellFloatEditor_StartingKey(wxGridCellFloatEditor* self, wxKeyEvent* event)
{
    return self->StartingKey(*event);
}

WXNET_EXPORT(void)
  wxGridCellFloatEditor_SetParameters(wxGridCellFloatEditor* self, const wxString* params)
{
   if (self && params)
      self->SetParameters(*params);
}

WXNET_EXPORT(wxGridCellEditor*)
  wxGridCellFloatEditor_Clone(wxGridCellFloatEditor* self)
{
    return self->Clone();
}

//-----------------------------------------------------------------------------
// wxGridCellBoolEditor

class _GridCellBoolEditor : public wxGridCellBoolEditor
{
public:
	_GridCellBoolEditor()
		: wxGridCellBoolEditor() {}

	DECLARE_DISPOSABLE(_GridCellBoolEditor)
};

wxClassInfo wxGridCellBoolEditor_ms_classInfo(wxT("wxGridCellBoolEditor"),
            &wxGridCellEditor_ms_classInfo,
            NULL,
            (int) sizeof(wxGridCellBoolEditor),
            NULL);

WXNET_EXPORT(wxClassInfo*)
   GridCellBoolEditor_GetWxClassInfo(void)
{
   return &wxGridCellBoolEditor_ms_classInfo;
}


WXNET_EXPORT(void) wxGridCellBoolEditor_UseStringValues(const wxString* valueTrue, const wxString* valueFalse)
{
   if (valueTrue && valueFalse)
      wxGridCellBoolEditor::UseStringValues(*valueTrue, *valueFalse);
}

WXNET_EXPORT(char) wxGridCellBoolEditor_IsTrueValue(const wxString* value)
{
   if (value)
      return wxGridCellBoolEditor::IsTrueValue(*value)?1:0;
   else
      return 0;
}

WXNET_EXPORT(wxGridCellBoolEditor*)
  wxGridCellBoolEditor_ctor()
{
    return new _GridCellBoolEditor();
}

WXNET_EXPORT(void)
  wxGridCellBoolEditor_dtor(wxGridCellBoolEditor* self)
{
    WXNET_DEL(self);
}

WXNET_EXPORT(void)
  wxGridCellBoolEditor_RegisterDisposable(_GridCellBoolEditor* self, Virtual_Dispose onDispose)
{
	self->RegisterDispose(onDispose);
}

WXNET_EXPORT(void)
  wxGridCellBoolEditor_Create(wxGridCellBoolEditor* self, wxWindow* parent, wxWindowID id, wxEvtHandler* evtHandler)
{
    self->Create(parent, id, evtHandler);
}

WXNET_EXPORT(void)
  wxGridCellBoolEditor_SetSize(wxGridCellBoolEditor* self, wxRect* rect)
{
    self->SetSize(*rect);
}

WXNET_EXPORT(char)
  wxGridCellBoolEditor_IsAcceptedKey(wxGridCellBoolEditor* self, wxKeyEvent* event)
{
    return self->IsAcceptedKey(*event)?1:0;
}

WXNET_EXPORT(void)
  wxGridCellBoolEditor_BeginEdit(wxGridCellBoolEditor* self, int row, int col, wxGrid* grid)
{
    self->BeginEdit(row, col, grid);
}

WXNET_EXPORT(char)
  wxGridCellBoolEditor_EndEdit(wxGridCellBoolEditor* self, int row, int col, wxGrid* grid)
{
    return self->EndEdit(row, col, grid)?1:0;
}

WXNET_EXPORT(void)
  wxGridCellBoolEditor_Reset(wxGridCellBoolEditor* self)
{
    return self->Reset();
}

WXNET_EXPORT(void)
  wxGridCellBoolEditor_StartingClick(wxGridCellFloatEditor* self)
{
    return self->StartingClick();
}

WXNET_EXPORT(wxGridCellEditor*)
  wxGridCellBoolEditor_Clone(wxGridCellBoolEditor* self)
{
    return self->Clone();
}

//-----------------------------------------------------------------------------
// wxGridCellChoiceEditor

class _GridCellChoiceEditor : public wxGridCellChoiceEditor
{
public:
	_GridCellChoiceEditor(size_t count, const wxString choices[], bool allowOthers)
		: wxGridCellChoiceEditor(count, choices, allowOthers) {}

	_GridCellChoiceEditor(const wxArrayString& choices, bool allowOthers)
		: wxGridCellChoiceEditor(choices, allowOthers) {}

	DECLARE_DISPOSABLE(_GridCellChoiceEditor)
};

wxClassInfo wxGridCellChoiceEditor_ms_classInfo(wxT("wxGridCellChoiceEditor"),
            &wxGridCellEditor_ms_classInfo,
            NULL,
            (int) sizeof(wxGridCellChoiceEditor),
            NULL);

WXNET_EXPORT(wxClassInfo*)
   GridCellChoiceEditor_GetWxClassInfo(void)
{
   return &wxGridCellChoiceEditor_ms_classInfo;
}


WXNET_EXPORT(wxGridCellChoiceEditor*)
  wxGridCellChoiceEditor_ctor(const wxArrayString* choices, bool allowOthers)
{
   if (choices)
      return new _GridCellChoiceEditor(*choices, allowOthers);
   else
      return new _GridCellChoiceEditor(0, NULL, allowOthers);
}

WXNET_EXPORT(void)
  wxGridCellChoiceEditor_dtor(wxGridCellChoiceEditor* self)
{
	WXNET_DEL(self);
}

WXNET_EXPORT(void)
  wxGridCellChoiceEditor_RegisterDisposable(_GridCellChoiceEditor* self, Virtual_Dispose onDispose)
{
	self->RegisterDispose(onDispose);
}

WXNET_EXPORT(void)
  wxGridCellChoiceEditor_Create(wxGridCellChoiceEditor* self, wxWindow* parent, wxWindowID id, wxEvtHandler* evtHandler)
{
    self->Create(parent, id, evtHandler);
}

WXNET_EXPORT(void)
  wxGridCellChoiceEditor_PaintBackground(wxGridCellChoiceEditor* self, wxRect* rect, wxGridCellAttr* attr)
{
    self->PaintBackground(*rect, attr);
}

WXNET_EXPORT(void)
  wxGridCellChoiceEditor_BeginEdit(wxGridCellChoiceEditor* self, int row, int col, wxGrid* grid)
{
    return self->BeginEdit(row, col, grid);
}

WXNET_EXPORT(char)
  wxGridCellChoiceEditor_EndEdit(wxGridCellChoiceEditor* self, int row, int col, wxGrid* grid)
{
    return self->EndEdit(row, col, grid)?1:0;
}

WXNET_EXPORT(void)
  wxGridCellChoiceEditor_Reset(wxGridCellChoiceEditor* self)
{
    return self->Reset();
}

WXNET_EXPORT(void)
  wxGridCellChoiceEditor_SetParameters(wxGridCellChoiceEditor* self, const wxString* params)
{
   if (self && params)
      self->SetParameters(*params);
}

WXNET_EXPORT(wxGridCellEditor*)
  wxGridCellChoiceEditor_Clone(wxGridCellChoiceEditor* self)
{
    return self->Clone();
}

//-----------------------------------------------------------------------------
// wxGridCellStringRenderer

typedef void (CALLBACK* Virtual_Draw) (wxGrid*, wxGridCellAttr*, wxDC*, wxRect*, int, int, char);
typedef wxSize* (CALLBACK* Virtual_GetBestSize) (wxGrid*, wxGridCellAttr*, wxDC*, int, int);
typedef wxGridCellRenderer* (CALLBACK* Virtual_RendererClone) ();


class _GridCellStringRenderer : public wxGridCellStringRenderer
{
public:
	DECLARE_DISPOSABLE(_GridCellStringRenderer)

    _GridCellStringRenderer()
		: wxGridCellStringRenderer() {}

    void Draw(wxGrid& grid, wxGridCellAttr& attr, wxDC& dc, const wxRect& rect, int row, int col, bool isSelected)
        { 
           if (m_Draw)
           {
              wxRect rectArg(rect);
              m_Draw(&grid, &attr, &dc, &rectArg, row, col, isSelected);
           }
           else wxGridCellStringRenderer::Draw(grid, attr, dc, rect, row, col, isSelected);
        }
    
    wxSize GetBestSize(wxGrid& grid, wxGridCellAttr& attr, wxDC& dc, int row, int col)
        {
           if (m_GetBestSize) return wxSize(*m_GetBestSize(&grid, &attr, &dc, row, col));
           else return wxGridCellStringRenderer::GetBestSize(grid, attr, dc, row, col);
         }
    
    wxGridCellRenderer* Clone() const
        {
           if (m_Clone)
              return m_Clone();
           else
              return wxGridCellStringRenderer::Clone();
         }

    void RegisterVirtual(Virtual_Dispose onDispose,
        Virtual_Draw draw,
        Virtual_GetBestSize getBestSize,
        Virtual_RendererClone clone)
        {
            m_onDispose = onDispose;
            m_Draw = draw;
            m_GetBestSize = getBestSize;
            m_Clone = clone;
        }

private:
    Virtual_Draw m_Draw;
    Virtual_GetBestSize m_GetBestSize;
    Virtual_RendererClone m_Clone;

};

WXNET_EXPORT(wxGridCellStringRenderer*)
  wxGridCellStringRenderer_ctor()
{
    return new _GridCellStringRenderer();
}

WXNET_EXPORT(void)
  wxGridCellStringRenderer_dtor(wxGridCellStringRenderer* self)
{
	WXNET_DEL(self);
}

WXNET_EXPORT(void)
  wxGridCellStringRenderer_RegisterVirtual(wxGridCellStringRenderer* self,
      Virtual_Dispose onDispose, Virtual_Draw draw,
        Virtual_GetBestSize getBestSize,
        Virtual_RendererClone clone)
{
   _GridCellStringRenderer* selfCasted=dynamic_cast<_GridCellStringRenderer*>(self);
   if (selfCasted)
	   selfCasted->RegisterVirtual(onDispose, draw, getBestSize, clone);
}

WXNET_EXPORT(void)
  wxGridCellStringRenderer_Draw(wxGridCellStringRenderer* self, wxGrid* grid, wxGridCellAttr* attr,
                wxDC* dc, wxRect* rect, int row, int col, bool isSelected)
{
   if (grid && attr && dc && rect)
   self->wxGridCellStringRenderer::Draw(*grid, *attr, *dc, *rect, row, col, isSelected);
}

WXNET_EXPORT(void)
  wxGridCellStringRenderer_GetBestSize(wxGridCellStringRenderer* self, wxGrid *grid, wxGridCellAttr *attr,
                wxDC* dc, int row, int col, wxSize* size)
{
   if (grid && attr && dc)
   *size = self->wxGridCellStringRenderer::GetBestSize(*grid, *attr, *dc, row, col);
}

WXNET_EXPORT(wxGridCellRenderer*)
  wxGridCellStringRenderer_Clone(wxGridCellStringRenderer* self)
{
   return self->wxGridCellStringRenderer::Clone();
}

//-----------------------------------------------------------------------------
// wxGridCellNumberRenderer

class _GridCellNumberRenderer : public wxGridCellNumberRenderer
{
public:
	DECLARE_DISPOSABLE(_GridCellNumberRenderer)

    _GridCellNumberRenderer()
		: wxGridCellNumberRenderer() {}

    void Draw(wxGrid& grid, wxGridCellAttr& attr, wxDC& dc, const wxRect& rect, int row, int col, bool isSelected)
        { 
           if (m_Draw)
           {
              wxRect rectArg(rect);
              m_Draw(&grid, &attr, &dc, &rectArg, row, col, isSelected);
           }
           else wxGridCellNumberRenderer::Draw(grid, attr, dc, rect, row, col, isSelected);
        }
    
    wxSize GetBestSize(wxGrid& grid, wxGridCellAttr& attr, wxDC& dc, int row, int col)
        {
           if (m_GetBestSize) return wxSize(*m_GetBestSize(&grid, &attr, &dc, row, col));
           else return wxGridCellNumberRenderer::GetBestSize(grid, attr, dc, row, col);
         }
    
    wxGridCellRenderer* Clone() const
        {
           if (m_Clone)
              return m_Clone();
           else
              return wxGridCellNumberRenderer::Clone();
         }

    void RegisterVirtual(Virtual_Dispose onDispose,
        Virtual_Draw draw,
        Virtual_GetBestSize getBestSize,
        Virtual_RendererClone clone)
        {
            m_onDispose = onDispose;
            m_Draw = draw;
            m_GetBestSize = getBestSize;
            m_Clone = clone;
        }

private:
    Virtual_Draw m_Draw;
    Virtual_GetBestSize m_GetBestSize;
    Virtual_RendererClone m_Clone;

};


WXNET_EXPORT(wxGridCellNumberRenderer*)
  wxGridCellNumberRenderer_ctor()
{
    return new _GridCellNumberRenderer();
}

WXNET_EXPORT(void)
  wxGridCellNumberRenderer_dtor(wxGridCellNumberRenderer* self)
{
	WXNET_DEL(self);
}

WXNET_EXPORT(void)
  wxGridCellNumberRenderer_RegisterVirtual(wxGridCellNumberRenderer* self,
      Virtual_Dispose onDispose, Virtual_Draw draw,
        Virtual_GetBestSize getBestSize,
        Virtual_RendererClone clone)
{
   _GridCellNumberRenderer* selfCasted=dynamic_cast<_GridCellNumberRenderer*>(self);
   if (selfCasted)
	   selfCasted->RegisterVirtual(onDispose, draw, getBestSize, clone);
}

WXNET_EXPORT(void)
  wxGridCellNumberRenderer_Draw(wxGridCellNumberRenderer* self, wxGrid* grid, wxGridCellAttr* attr,
                wxDC* dc, wxRect* rect, int row, int col, bool isSelected)
{
   if (grid && attr && dc && rect)
   self->wxGridCellNumberRenderer::Draw(*grid, *attr, *dc, *rect, row, col, isSelected);
}

WXNET_EXPORT(void)
  wxGridCellNumberRenderer_GetBestSize(wxGridCellNumberRenderer* self, wxGrid *grid, wxGridCellAttr *attr,
                wxDC* dc, int row, int col, wxSize* size)
{
   if (grid && attr && dc)
   *size = self->wxGridCellNumberRenderer::GetBestSize(*grid, *attr, *dc, row, col);
}

WXNET_EXPORT(wxGridCellRenderer*)
  wxGridCellNumberRenderer_Clone(wxGridCellNumberRenderer* self)
{
   return self->wxGridCellNumberRenderer::Clone();
}

//-----------------------------------------------------------------------------
// wxGridCellFloatRenderer

class _GridCellFloatRenderer : public wxGridCellFloatRenderer
{
public:
	DECLARE_DISPOSABLE(_GridCellFloatRenderer)

    _GridCellFloatRenderer(int width, int precision)
       : wxGridCellFloatRenderer(width, precision) {}

    void Draw(wxGrid& grid, wxGridCellAttr& attr, wxDC& dc, const wxRect& rect, int row, int col, bool isSelected)
        { 
           if (m_Draw)
           {
              wxRect rectArg(rect);
              m_Draw(&grid, &attr, &dc, &rectArg, row, col, isSelected);
           }
           else wxGridCellFloatRenderer::Draw(grid, attr, dc, rect, row, col, isSelected);
        }
    
    wxSize GetBestSize(wxGrid& grid, wxGridCellAttr& attr, wxDC& dc, int row, int col)
        {
           if (m_GetBestSize) return wxSize(*m_GetBestSize(&grid, &attr, &dc, row, col));
           else return wxGridCellFloatRenderer::GetBestSize(grid, attr, dc, row, col);
         }
    
    wxGridCellRenderer* Clone() const
        {
           if (m_Clone)
              return m_Clone();
           else
              return wxGridCellFloatRenderer::Clone();
         }

    void RegisterVirtual(Virtual_Dispose onDispose,
        Virtual_Draw draw,
        Virtual_GetBestSize getBestSize,
        Virtual_RendererClone clone)
        {
            m_onDispose = onDispose;
            m_Draw = draw;
            m_GetBestSize = getBestSize;
            m_Clone = clone;
        }

private:
    Virtual_Draw m_Draw;
    Virtual_GetBestSize m_GetBestSize;
    Virtual_RendererClone m_Clone;

};

WXNET_EXPORT(void)
  wxGridCellFloatRenderer_RegisterVirtual(wxGridCellFloatRenderer* self,
      Virtual_Dispose onDispose, Virtual_Draw draw,
        Virtual_GetBestSize getBestSize,
        Virtual_RendererClone clone)
{
   _GridCellFloatRenderer* selfCasted=dynamic_cast<_GridCellFloatRenderer*>(self);
   if (selfCasted)
	   selfCasted->RegisterVirtual(onDispose, draw, getBestSize, clone);
}

WXNET_EXPORT(wxGridCellFloatRenderer*)
  wxGridCellFloatRenderer_ctor(int width, int precision)
{
    return new _GridCellFloatRenderer(width, precision);
}

WXNET_EXPORT(void)
  wxGridCellFloatRenderer_dtor(wxGridCellFloatRenderer* self)
{
	WXNET_DEL(self);
}

WXNET_EXPORT(void)
  wxGridCellFloatRenderer_Draw(wxGridCellFloatRenderer* self, wxGrid* grid, wxGridCellAttr* attr,
                wxDC* dc, wxRect* rect, int row, int col, bool isSelected)
{
   if (grid && attr && dc)
   self->wxGridCellFloatRenderer::Draw(*grid, *attr, *dc, *rect, row, col, isSelected);
}

WXNET_EXPORT(void)
  wxGridCellFloatRenderer_GetBestSize(wxGridCellFloatRenderer* self, wxGrid *grid, wxGridCellAttr *attr,
                wxDC* dc, int row, int col, wxSize* size)
{
   if (grid && attr && dc)
    *size = self->wxGridCellFloatRenderer::GetBestSize(*grid, *attr, *dc, row, col);
}

WXNET_EXPORT(wxGridCellRenderer*)
  wxGridCellFloatRenderer_Clone(wxGridCellFloatRenderer* self)
{
    return self->wxGridCellFloatRenderer::Clone();
}

WXNET_EXPORT(int)
  wxGridCellFloatRenderer_GetWidth(wxGridCellFloatRenderer* self)
{
    return self->wxGridCellFloatRenderer::GetWidth();
}

WXNET_EXPORT(void)
  wxGridCellFloatRenderer_SetWidth(wxGridCellFloatRenderer* self, int width)
{
    self->wxGridCellFloatRenderer::SetWidth(width);
}

WXNET_EXPORT(int)
  wxGridCellFloatRenderer_GetPrecision(wxGridCellFloatRenderer* self)
{
    return self->wxGridCellFloatRenderer::GetPrecision();
}

WXNET_EXPORT(void)
  wxGridCellFloatRenderer_SetPrecision(wxGridCellFloatRenderer* self, int precision)
{
    self->wxGridCellFloatRenderer::SetPrecision(precision);
}

WXNET_EXPORT(void)
  wxGridCellFloatRenderer_SetParameters(wxGridCellFloatRenderer* self, const wxString* params)
{
   if (self && params)
    self->wxGridCellFloatRenderer::SetParameters(*params);
}

//-----------------------------------------------------------------------------
// wxGridCellBoolRenderer

class _GridCellBoolRenderer : public wxGridCellBoolRenderer
{
public:
	_GridCellBoolRenderer()
		: wxGridCellBoolRenderer() {}

	DECLARE_DISPOSABLE(_GridCellBoolRenderer)
};

WXNET_EXPORT(wxGridCellBoolRenderer*)
  wxGridCellBoolRenderer_ctor()
{
    return new _GridCellBoolRenderer();
}

WXNET_EXPORT(void)
  wxGridCellBoolRenderer_dtor(wxGridCellBoolRenderer* self)
{
	WXNET_DEL(self);
}

WXNET_EXPORT(void)
  wxGridCellBoolRenderer_RegisterDisposable(_GridCellBoolRenderer* self, Virtual_Dispose onDispose)
{
	self->RegisterDispose(onDispose);
}

WXNET_EXPORT(void)
  wxGridCellBoolRenderer_Draw(wxGridCellBoolRenderer* self, wxGrid* grid, wxGridCellAttr* attr,
                wxDC* dc, wxRect* rect, int row, int col, bool isSelected)
{
    self->Draw(*grid, *attr, *dc, *rect, row, col, isSelected);
}

WXNET_EXPORT(void)
  wxGridCellBoolRenderer_GetBestSize(wxGridCellBoolRenderer* self, wxGrid *grid, wxGridCellAttr *attr,
                wxDC* dc, int row, int col, wxSize* size)
{
    *size = self->GetBestSize(*grid, *attr, *dc, row, col);
}

WXNET_EXPORT(wxGridCellRenderer*)
  wxGridCellBoolRenderer_Clone(wxGridCellBoolRenderer* self)
{
    return self->Clone();
}

//-----------------------------------------------------------------------------
// wxGridCellRenderer

class _GridCellRenderer : public wxGridCellRenderer
{
public:
    DECLARE_DISPOSABLE(_GridCellRenderer)
    _GridCellRenderer()
        : wxGridCellRenderer(), m_onDispose(0) {}
        
    void Draw(wxGrid& grid, wxGridCellAttr& attr, wxDC& dc, const wxRect& rect, int row, int col, bool isSelected)
        { 
           if (m_Draw) m_Draw(&grid, &attr, &dc, new wxRect(rect), row, col, isSelected?255:0);
        }
    
    wxSize GetBestSize(wxGrid& grid, wxGridCellAttr& attr, wxDC& dc, int row, int col)
        { if (m_GetBestSize) return wxSize(*m_GetBestSize(&grid, &attr, &dc, row, col)); else return wxSize(); }
    
    wxGridCellRenderer* Clone() const
        { if (m_Clone) return m_Clone(); else return NULL; }

    void RegisterVirtual(Virtual_Dispose onDispose,
        Virtual_Draw draw,
        Virtual_GetBestSize getBestSize,
        Virtual_RendererClone clone)
        {
            m_onDispose = onDispose;
            m_Draw = draw;
            m_GetBestSize = getBestSize;
            m_Clone = clone;
        }

private:
    Virtual_Draw m_Draw;
    Virtual_GetBestSize m_GetBestSize;
    Virtual_RendererClone m_Clone;
};

WXNET_EXPORT(wxGridCellRenderer*)
  wxGridCellRenderer_ctor()
{
    return new _GridCellRenderer();
}

WXNET_EXPORT(void)
  wxGridCellRenderer_dtor(_GridCellRenderer* self)
{
	WXNET_DEL(self);
}

WXNET_EXPORT(void)
  wxGridCellRenderer_RegisterVirtual(_GridCellRenderer* self, 
        Virtual_Dispose onDispose,
        Virtual_Draw draw,
        Virtual_GetBestSize getBestSize,
        Virtual_RendererClone clone)
{
    self->RegisterVirtual(onDispose, draw, getBestSize, clone);
}




wxClassInfo wxGridCellEnumEditor_ms_classInfo(wxT("wxGridCellEnumEditor"),
            &wxGridCellEditor_ms_classInfo,
            NULL,
            (int) sizeof(wxGridCellEnumEditor),
            NULL);

WXNET_EXPORT(wxClassInfo*)
   GridCellEnumEditor_GetWxClassInfo(void)
{
   return &wxGridCellEnumEditor_ms_classInfo;
}

wxClassInfo wxGridCellAutoWrapStringEditor_ms_classInfo(wxT("wxGridCellAutoWrapStringEditor"),
            &wxGridCellEditor_ms_classInfo,
            NULL,
            (int) sizeof(wxGridCellAutoWrapStringEditor),
            NULL);

WXNET_EXPORT(wxClassInfo*)
   GridCellAutoWrapStringEditor_GetWxClassInfo(void)
{
   return &wxGridCellAutoWrapStringEditor_ms_classInfo;
}


WXNET_EXPORT(wxClassInfo*)
   wxGridCellEditor_GetClassInfoOnInstance(wxGridCellEditor* obj)
{
   if (dynamic_cast<wxGridCellNumberEditor*>(obj))
      return &wxGridCellNumberEditor_ms_classInfo;
   else if (dynamic_cast<wxGridCellBoolEditor*>(obj))
      return &wxGridCellBoolEditor_ms_classInfo;
   else if (dynamic_cast<wxGridCellFloatEditor*>(obj))
      return &wxGridCellFloatEditor_ms_classInfo;
   else if (dynamic_cast<wxGridCellTextEditor*>(obj))
      return &wxGridCellTextEditor_ms_classInfo;
   else if (dynamic_cast<wxGridCellEnumEditor*>(obj))
      return &wxGridCellEnumEditor_ms_classInfo;
   else if (dynamic_cast<wxGridCellChoiceEditor*>(obj))
      return &wxGridCellChoiceEditor_ms_classInfo;
   else if (dynamic_cast<wxGridCellAutoWrapStringEditor*>(obj))
      return &wxGridCellAutoWrapStringEditor_ms_classInfo;
   return &wxGridCellEditor_ms_classInfo;
}

wxClassInfo wxGridCellRenderer_ms_classInfo(wxT("wxGridCellRenderer"),
                                            NULL, NULL, (int) sizeof(wxGridCellRenderer), NULL);
wxClassInfo wxGridCellDateTimeRenderer_ms_classInfo(wxT("wxGridCellDateTimeRenderer"),
   &wxGridCellRenderer_ms_classInfo, NULL, (int) sizeof(wxGridCellDateTimeRenderer), NULL);
wxClassInfo wxGridCellEnumRenderer_ms_classInfo(wxT("wxGridCellEnumRenderer"),
   &wxGridCellRenderer_ms_classInfo, NULL, (int) sizeof(wxGridCellEnumRenderer), NULL);
wxClassInfo wxGridCellAutoWrapStringRenderer_ms_classInfo(wxT("wxGridCellAutoWrapStringRenderer"),
   &wxGridCellRenderer_ms_classInfo, NULL, (int) sizeof(wxGridCellAutoWrapStringRenderer), NULL);
wxClassInfo wxGridCellNumberRenderer_ms_classInfo(wxT("wxGridCellNumberRenderer"),
   &wxGridCellRenderer_ms_classInfo, NULL, (int) sizeof(wxGridCellNumberRenderer), NULL);
wxClassInfo wxGridCellFloatRenderer_ms_classInfo(wxT("wxGridCellFloatRenderer"),
   &wxGridCellRenderer_ms_classInfo, NULL, (int) sizeof(wxGridCellFloatRenderer), NULL);
wxClassInfo wxGridCellStringRenderer_ms_classInfo(wxT("wxGridCellStringRenderer"),
   &wxGridCellRenderer_ms_classInfo, NULL, (int) sizeof(wxGridCellStringRenderer), NULL);
wxClassInfo wxGridCellBoolRenderer_ms_classInfo(wxT("wxGridCellBoolRenderer"),
   &wxGridCellRenderer_ms_classInfo, NULL, (int) sizeof(wxGridCellBoolRenderer), NULL);

WXNET_EXPORT(wxClassInfo*)
   GridCellRenderer_GetWxClassInfo(void)
{
   return &wxGridCellRenderer_ms_classInfo;
}
WXNET_EXPORT(wxClassInfo*)
   GridCellStringRenderer_GetWxClassInfo(void)
{
   return &wxGridCellStringRenderer_ms_classInfo;
}
WXNET_EXPORT(wxClassInfo*)
   GridCellNumberRenderer_GetWxClassInfo(void)
{
   return &wxGridCellNumberRenderer_ms_classInfo;
}
WXNET_EXPORT(wxClassInfo*)
   GridCellFloatRenderer_GetWxClassInfo(void)
{
   return &wxGridCellFloatRenderer_ms_classInfo;
}
WXNET_EXPORT(wxClassInfo*)
   GridCellBoolRenderer_GetWxClassInfo(void)
{
   return &wxGridCellBoolRenderer_ms_classInfo;
}
WXNET_EXPORT(wxClassInfo*)
   GridCellEnumRenderer_GetWxClassInfo(void)
{
   return &wxGridCellEnumRenderer_ms_classInfo;
}
WXNET_EXPORT(wxClassInfo*)
   GridCellDateTimeRenderer_GetWxClassInfo(void)
{
   return &wxGridCellDateTimeRenderer_ms_classInfo;
}
WXNET_EXPORT(wxClassInfo*)
   GridCellAutoWrapStringRenderer_GetWxClassInfo(void)
{
   return &wxGridCellAutoWrapStringRenderer_ms_classInfo;
}
WXNET_EXPORT(wxClassInfo*)
   wxGridCellRenderer_GetClassInfoOnInstance(wxGridCellRenderer* obj)
{
   if (dynamic_cast<wxGridCellNumberRenderer*>(obj))
      return &wxGridCellNumberRenderer_ms_classInfo;
   else if (dynamic_cast<wxGridCellBoolRenderer*>(obj))
      return &wxGridCellBoolRenderer_ms_classInfo;
   else if (dynamic_cast<wxGridCellFloatRenderer*>(obj))
      return &wxGridCellFloatRenderer_ms_classInfo;
   else if (dynamic_cast<wxGridCellStringRenderer*>(obj))
      return &wxGridCellStringRenderer_ms_classInfo;
   else if (dynamic_cast<wxGridCellEnumRenderer*>(obj))
      return &wxGridCellEnumRenderer_ms_classInfo;
   else if (dynamic_cast<wxGridCellDateTimeRenderer*>(obj))
      return &wxGridCellDateTimeRenderer_ms_classInfo;
   else if (dynamic_cast<wxGridCellAutoWrapStringRenderer*>(obj))
      return &wxGridCellAutoWrapStringRenderer_ms_classInfo;
   return &wxGridCellRenderer_ms_classInfo;
}


