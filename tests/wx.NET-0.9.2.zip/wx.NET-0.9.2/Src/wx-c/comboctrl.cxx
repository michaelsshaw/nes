/**
* wx.NET - combobox.cxx
*
* \file
* The wxComboCtrl proxy interface
*
* Written by Harald Meyer auf'm Hofe
* (C) 2008 by Harald Meyer auf'm Hofe
* Licensed under the wxWidgets license, see LICENSE.txt for details.
*
* $Id: comboctrl.cxx,v 1.2 2008/12/11 23:55:31 harald_meyer Exp $
*
*/

#include <wx/wx.h>
#include <wx/combo.h>
#include <wx/dc.h>
#include <wx/event.h>

#include "local_events.h"

typedef void (CALLBACK* CallInit)(void);
typedef bool (CALLBACK* CallCreate)(wxWindow* parent);
typedef void (CALLBACK* CallOnPopup)(void);
typedef void (CALLBACK* CallOnDismiss)(void);
typedef void (CALLBACK* CallSetStringValue)(const wxString* stringValue);
typedef wxString* (CALLBACK* CallGetStringValue)(void);
typedef void (CALLBACK* CallPaintComboControl)(wxDC* dc, int x, int y, int w, int h);
typedef void (CALLBACK* CallOnComboKeyEvent)( wxKeyEvent* kevt );
typedef void (CALLBACK* CallOnComboDoubleClick)(void);
typedef void (CALLBACK* CallGetAdjustedSize)( int* w, int* h, int minWidth, int prefHeight, int maxHeight );
typedef bool (CALLBACK* CallLazyCreate)(void);
typedef wxWindow* (CALLBACK* CallGetControl)(void);

class _ComboPopup : public wxComboPopup
{
public:
   wxWindow* m_control;

   Virtual_Dispose m_virtualDispose;
   CallInit m_callInit;
   CallCreate m_callCreate;
   CallOnPopup m_callOnPopup;
   CallOnDismiss m_callOnDismiss;
   CallSetStringValue m_setStringValue;
   CallGetStringValue m_getStringValue;
   CallPaintComboControl m_paintCombo;
   CallOnComboKeyEvent m_onKeyEvent;
   CallOnComboDoubleClick m_comboDoubleClick;
   CallGetAdjustedSize m_getAdjustedSize;
   CallLazyCreate m_lazyCreate;
   CallGetControl m_getControl;

   _ComboPopup() : m_control(0), m_virtualDispose(), m_callInit(), m_callCreate(),
      m_callOnPopup(0), m_callOnDismiss(0), m_setStringValue(0), m_getStringValue(0),
      m_paintCombo(0), m_onKeyEvent(0), m_comboDoubleClick(0),
      m_getAdjustedSize(0), m_lazyCreate(0), m_getControl(0) {}

   virtual ~_ComboPopup()
   {
      if (m_virtualDispose)
         m_virtualDispose();
   }
   virtual void Init()
   {
      if (m_callInit)
         m_callInit();
   }

   virtual bool Create(wxWindow* parent)
   {
      if (this->m_callCreate)
         return this->m_callCreate(parent);
      else
         return false;
   }

    virtual void OnPopup()
    {
       if (this->m_callOnPopup)
          this->m_callOnPopup();
    }

    // Called when popup is dismissed
    virtual void OnDismiss()
    {
       if (this->m_callOnDismiss)
          this->m_callOnDismiss();
    }

    virtual void SetStringValue( const wxString& value )
    {
       if (this->m_setStringValue)
          this->m_setStringValue(&value);
    }

    // Gets displayed string representation of the value.
    virtual wxString GetStringValue() const
    {
       if (this->m_getStringValue)
       {
          wxString* result=this->m_getStringValue();
          if (result)
             return *result;
       }
       return wxT("");
    }

    // This is called to custom paint in the combo control itself (ie. not the popup).
    // Default implementation draws value as string.
    virtual void PaintComboControl( wxDC& dc, const wxRect& rect )
    {
       if (this->m_paintCombo)
          this->m_paintCombo(&dc, rect.GetX(), rect.GetY(), rect.GetWidth(), rect.GetHeight());
    }

    // Receives key events from the parent wxComboCtrl.
    // Events not handled should be skipped, as usual.
    virtual void OnComboKeyEvent( wxKeyEvent& evt )
    {
       if (this->m_onKeyEvent)
          this->m_onKeyEvent(&evt);
    }

    // Implement if you need to support special action when user
    // double-clicks on the parent wxComboCtrl.
    virtual void OnComboDoubleClick()
    {
       if (this->m_comboDoubleClick)
          this->m_comboDoubleClick();
    }

    // Return final size of popup. Called on every popup, just prior to OnShow.
    // minWidth = preferred minimum width for window
    // prefHeight = preferred height. Only applies if > 0,
    // maxHeight = max height for window, as limited by screen size
    //   and should only be rounded down, if necessary.
    virtual wxSize GetAdjustedSize( int minWidth, int prefHeight, int maxHeight )
    {
       if (this->m_getAdjustedSize)
       {
          int w, h;
          this->m_getAdjustedSize(&w, &h, minWidth, prefHeight, maxHeight);
          return wxSize(w, h);
       }
       else
          return wxSize();
    }

    // Return true if you want delay call to Create until the popup is shown
    // for the first time. It is more efficient, but note that it is often
    // more convenient to have the control created immediately.
    // Default returns false.
    virtual bool LazyCreate()
    {
       if (this->m_lazyCreate)
          return this->m_lazyCreate();
       else
          return false;
    }

    virtual wxWindow* GetControl()
    {
       if (this->m_getControl)
          return this->m_getControl();
       else
          return NULL;
    }
};

WXNET_EXPORT(_ComboPopup*)
  wxComboPopup_ctor()
{
   return new _ComboPopup();
}

WXNET_EXPORT(void)
  wxComboPopup_dtor(wxComboPopup* self)
{
   if (self) delete self;
}

WXNET_EXPORT(wxWindow*)
  wxComboPopup_ComboControl(wxComboPopup* self)
{
   if (self)
      return self->GetControl();
   else
      return NULL;
}

WXNET_EXPORT(void)
  wxComboPopup_PaintComboControl(wxComboPopup* self, wxDC* dc, int x, int y, int w, int h)
{
   if (self && dc)
      self->wxComboPopup::PaintComboControl(*dc, wxRect(x, y, w, h));
}

WXNET_EXPORT(void)
  wxComboPopup_GetAdjustedSize(wxComboPopup* self, int* w, int* height, int minWidth, int prefHeight, int maxHeight)
{
   if (self)
   {
      wxSize result=self->wxComboPopup::GetAdjustedSize(minWidth, prefHeight, maxHeight);
      if (w)
         (*w)=result.GetWidth();
      if (height)
         (*height)=result.GetHeight();
   }
}

WXNET_EXPORT(void)
  wxComboPopup_Dismiss(wxComboPopup* self)
{
   if (self)
      self->wxComboPopup::Dismiss();
}

WXNET_EXPORT(char)
  wxComboPopup_IsCreated(const wxComboPopup* self)
{
   if (self)
      return self->wxComboPopup::IsCreated()?1:0;
   else
      return 0;
}

WXNET_EXPORT(void)
  wxComboPopup_RegisterVirtual(_ComboPopup* self, Virtual_Dispose virtualDispose,
                                  CallInit callInit,
            CallCreate callCreate, CallOnPopup callOnPopup,
            CallOnDismiss callOnDismiss, CallSetStringValue setStringValue,
            CallGetStringValue getStringValue, CallPaintComboControl paintCombo,
            CallOnComboKeyEvent onKeyEvent,
            CallOnComboDoubleClick comboDoubleClick, CallGetAdjustedSize getAdjustedSize,
            CallLazyCreate lazyCreate)
{
   if (self)
   {
      self->m_virtualDispose=virtualDispose;
      self->m_callInit=callInit;
      self->m_callCreate=callCreate;
      self->m_callOnPopup=callOnPopup;
      self->m_callOnDismiss=callOnDismiss;
      self->m_getStringValue=getStringValue;
      self->m_paintCombo=paintCombo;
      self->m_onKeyEvent=onKeyEvent;
      self->m_comboDoubleClick=comboDoubleClick;
      self->m_getAdjustedSize=getAdjustedSize;
      self->m_lazyCreate=lazyCreate;
   }
}

// _________________________________________________________________

typedef void (CALLBACK* CallOnButtonClick)(void);


class _ComboCtrl : public wxComboBox
{
public:
   CallOnButtonClick m_onButtonClick;

   _ComboCtrl() : m_onButtonClick() {}
   DECLARE_OBJECTDELETED(_ComboCtrl)
};

WXNET_EXPORT(_ComboCtrl*)
  wxComboCtrl_ctor()
{
   return new _ComboCtrl();
}

WXNET_EXPORT(void)
  wxComboCtrl_Create(wxComboCtrl* self, wxWindow* parent, int id, const wxString* valueStr, int x, int y, int w, int h, int styles, const wxString* nameArg)
{
   wxString value;
   if (valueStr)
      value=*valueStr;
   wxString name(wxT("wxComboCtrl"));
   if (nameArg)
      name=*nameArg;
   if (self)
      self->Create(parent, id, value, wxPoint(x, y), wxSize(w, h), styles, wxDefaultValidator, name);
}

WXNET_EXPORT(void)
  wxComboCtrl_ShowPopup(wxComboCtrl* self)
{
   if (self)
      self->ShowPopup();
}

WXNET_EXPORT(void)
  wxComboCtrl_HidePopup(wxComboCtrl* self)
{
   if (self)
      self->HidePopup();
}

WXNET_EXPORT(void)
  wxComboCtrl_OnButtonClick(wxComboCtrl* self)
{
   if (self)
      self->OnButtonClick();
}

WXNET_EXPORT(char)
  wxComboCtrl_IsPopupShown(const wxComboCtrl* self)
{
   if (self)
      return self->IsPopupShown();
   else
      return false;
}

WXNET_EXPORT(wxComboPopup*)
  wxComboCtrl_GetPopupControl(wxComboCtrl* self)
{
   if (self)
      return self->GetPopupControl();
   else
      return NULL;
}

WXNET_EXPORT(wxWindow*)
  wxComboCtrl_GetPopupWindow(const wxComboCtrl* self)
{
   if (self)
      return self->GetPopupWindow();
   else
      return NULL;
}

WXNET_EXPORT(wxTextCtrl*)
  wxComboCtrl_GetTextCtrl(const wxComboCtrl* self)
{
   if (self)
      return self->GetTextCtrl();
   else
      return NULL;
}

WXNET_EXPORT(wxWindow*)
  wxComboCtrl_GetButton(const wxComboCtrl* self)
{
   if (self)
      return self->GetButton();
   else
      return NULL;
}

WXNET_EXPORT(char)
  wxComboCtrl_Enable(wxComboCtrl* self, bool enable)
{
   if (self)
      return self->Enable(enable);
   else
      return false;
}

WXNET_EXPORT(char)
  wxComboCtrl_Show(wxComboCtrl* self, bool enable)
{
   if (self)
      return self->Show(enable);
   else
      return false;
}

WXNET_EXPORT(void)
  wxComboCtrl_SetFont(wxComboCtrl* self, const wxFont* font)
{
   if (self && font)
      self->SetFont(*font);
}

WXNET_EXPORT(void)
  wxComboCtrl_SetPopupControl(wxComboCtrl* self, wxComboPopup* ctrl)
{
   if (self && ctrl)
      self->SetPopupControl(ctrl);
}

WXNET_EXPORT(wxString*)
  wxComboCtrl_GetValue(const wxComboCtrl* self)
{
   if (self)
      return new wxString(self->GetValue());
   else
      return NULL;
}

WXNET_EXPORT(void)
  wxComboCtrl_SetValue(wxComboCtrl* self, const wxString* stringValue)
{
   if (self && stringValue)
      self->SetValue(*stringValue);
}

WXNET_EXPORT(void)
  wxComboCtrl_RegisterVirtual(_ComboCtrl* self, CallOnButtonClick onButtonClick)
{
   if (self)
      self->m_onButtonClick=onButtonClick;
}

WXNET_EXPORT(void)
  wxComboCtrl_Copy(wxComboCtrl* self)
{
   if (self)
      self->Copy();
}

WXNET_EXPORT(void)
  wxComboCtrl_Cut(wxComboCtrl* self)
{
   if (self)
      self->Cut();
}

WXNET_EXPORT(void)
  wxComboCtrl_Paste(wxComboCtrl* self)
{
   if (self)
      self->Paste();
}

WXNET_EXPORT(void)
  wxComboCtrl_SetInsertionPoint(wxComboCtrl* self, int position)
{
   if (self)
      self->SetInsertionPoint(position);
}

WXNET_EXPORT(void)
  wxComboCtrl_SetInsertionPointEnd(wxComboCtrl* self)
{
   if (self)
      self->SetInsertionPointEnd();
}

WXNET_EXPORT(int)
  wxComboCtrl_GetInsertionPoint(const wxComboCtrl* self)
{
   if (self)
      return self->GetInsertionPoint();
   else
      return 0;
}

WXNET_EXPORT(int)
  wxComboCtrl_GetLastPosition(const wxComboCtrl* self)
{
   if (self)
      return self->GetLastPosition();
   else
      return 0;
}

WXNET_EXPORT(void)
  wxComboCtrl_Replace(wxComboCtrl* self, int from, int to, const wxString* value)
{
   if (self && value)
      self->Replace(from, to, *value);
}

WXNET_EXPORT(void)
  wxComboCtrl_Remove(wxComboCtrl* self, int from, int to)
{
   if (self)
      self->Remove(from, to);
}

WXNET_EXPORT(void)
  wxComboCtrl_SetSelection(wxComboCtrl* self, int from, int to)
{
   if (self)
      self->SetSelection(from, to);
}

WXNET_EXPORT(void)
  wxComboCtrl_Undo(wxComboCtrl* self)
{
   if (self)
      self->Undo();
}


