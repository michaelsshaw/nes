//-----------------------------------------------------------------------------
// wx.NET - printpreview.cxx
//
// The wxPrintPreview proxy interface.
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 by Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: printpreview.cxx,v 1.7 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/print.h>
#include "wxnet_globals.h"

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxPrintPreview*)
  wxPrintPreview_ctor(wxPrintout* printout, wxPrintout* printoutForPrinting, wxPrintDialogData* data)
{
    return new wxPrintPreview(printout, printoutForPrinting, data);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxPrintPreview*)
  wxPrintPreview_ctorPrintData(wxPrintout* printout, wxPrintout* printoutForPrinting, wxPrintData* data)
{
    return new wxPrintPreview(printout, printoutForPrinting, data);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxPrintPreview_SetCurrentPage(wxPrintPreview* self, int pageNum)
{
    return self->SetCurrentPage(pageNum)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxPrintPreview_GetCurrentPage(wxPrintPreview* self)
{
    return self->GetCurrentPage();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPrintPreview_SetPrintout(wxPrintPreview* self, wxPrintout* printout)
{
    self->SetPrintout(printout);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxPrintout*)
  wxPrintPreview_GetPrintout(wxPrintPreview* self)
{
    return self->GetPrintout();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxPrintout*)
  wxPrintPreview_GetPrintoutForPrinting(wxPrintPreview* self)
{
    return self->GetPrintoutForPrinting();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPrintPreview_SetFrame(wxPrintPreview* self, wxFrame* frame)
{
    self->SetFrame(frame);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPrintPreview_SetCanvas(wxPrintPreview* self, wxPreviewCanvas* canvas)
{
    self->SetCanvas(canvas);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxFrame*)
  wxPrintPreview_GetFrame(wxPrintPreview* self)
{
    return self->GetFrame();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxWindow*)
  wxPrintPreview_GetCanvas(wxPrintPreview* self)
{
    return self->GetCanvas();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxPrintPreview_PaintPage(wxPrintPreview* self, wxPreviewCanvas* canvas, wxDC* dc)
{
    return self->PaintPage(canvas, *dc)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxPrintPreview_DrawBlankPage(wxPrintPreview* self, wxPreviewCanvas* canvas, wxDC* dc)
{
    return self->DrawBlankPage(canvas, *dc)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxPrintPreview_RenderPage(wxPrintPreview* self, int pageNum)
{
    return self->RenderPage(pageNum)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxPrintDialogData*)
  wxPrintPreview_GetPrintDialogData(wxPrintPreview* self)
{
    return &(self->GetPrintDialogData());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPrintPreview_SetZoom(wxPrintPreview* self, int percent)
{
    self->SetZoom(percent);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxPrintPreview_GetZoom(wxPrintPreview* self)
{
    return self->GetZoom();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxPrintPreview_GetMaxPage(wxPrintPreview* self)
{
    return self->GetMaxPage();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxPrintPreview_GetMinPage(wxPrintPreview* self)
{
    return self->GetMinPage();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxPrintPreview_Ok(wxPrintPreview* self)
{
    return self->Ok()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPrintPreview_SetOk(wxPrintPreview* self, bool ok)
{
    self->SetOk(ok);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxPrintPreview_Print(wxPrintPreview* self, bool interactive)
{
    return self->Print(interactive)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPrintPreview_DetermineScaling(wxPrintPreview* self)
{
    self->DetermineScaling();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxPreviewFrame*)
  wxPreviewFrame_ctor(wxPrintPreviewBase* preview, wxFrame* parent, const wxString* titleArg, int posX, int posY, int width, int height, unsigned int style, const wxString* nameArg)
{
   wxString name;
    if (nameArg == NULL)
        name = wxT("PreviewFrame");
    else
       name=*nameArg;
    wxString title;
    if (titleArg != NULL)
       title=*titleArg;

    return new wxPreviewFrame(preview, parent, title, wxPoint(posX, posY), wxSize(width, height), style, name);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPreviewFrame_Initialize(wxPreviewFrame* self)
{
    self->Initialize();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPreviewFrame_CreateCanvas(wxPreviewFrame* self)
{
    self->CreateCanvas();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPreviewFrame_CreateControlBar(wxPreviewFrame* self)
{
    self->CreateControlBar();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxPreviewCanvas*)
  wxPreviewCanvas_ctor(wxPrintPreviewBase* preview, wxWindow* parent, int posX, int posY, int width, int height, unsigned int style, const wxString* nameArg)
{
   wxString name;
    if (nameArg == NULL)
        name = wxT("PreviewCanvas");
    else
       name=*nameArg;

    return new wxPreviewCanvas(preview, parent, wxPoint(posX, posY), wxSize(width, height), style, name);
}

//-----------------------------------------------------------------------------

