//-----------------------------------------------------------------------------
// wx.NET - app.cxx
//
// The wxApp proxy interface.
//
// Written by Jason Perkins (jason@379.com)
// (C) 2003 by 379, Inc.
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: app.cxx,v 1.29 2010/06/16 18:09:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/utils.h>
#include "local_events.h"


WXNET_EXPORT(int)
 OS_GetLastOSError(void)
{
#if defined(__WXMSW__)
# ifdef _MSC_VER
#  pragma message("OS_GetLastOSError supported by Windows GetLastError().")
# elif __GNUC__
#  warning OS_GetLastOSError supported by Windows GetLastError().
# endif
    return GetLastError();
#else
    return 0;
#endif
}

typedef bool (CALLBACK* Virtual_OnInit) ();
typedef bool (CALLBACK* Virtual_OnExceptionInMainLoop) ();
typedef void (CALLBACK* Virtual_OnFatalException) ();
typedef int (CALLBACK* Virtual_OnExit) ();

WXNET_EXPORT(char)
  wxApp_SetHandleFatalExceptions(bool doIt)
{
    #if wxUSE_ON_FATAL_EXCEPTION
    return ::wxHandleFatalExceptions(doIt)?1:0;
    #endif
    return 0;
}

//-----------------------------------------------------------------------------
// The proxy class

class _App : public wxApp
{
	Virtual_OnInit m_OnInit;
	Virtual_OnExit m_OnExit;
   Virtual_OnExceptionInMainLoop m_OnExceptionInMainLoop;
   Virtual_OnFatalException m_OnFatalException;
public:
   _App() : 	m_OnInit(0), m_OnExit(0), m_OnExceptionInMainLoop(0), m_OnFatalException(0)
   {
   }

	bool OnInit()
	{ if (m_OnInit) return m_OnInit()!=0;  else return false; }
	
	int OnExit()
	{ if (m_OnExit) return m_OnExit()!=0; else return 100; }

   bool OnExceptionInMainLoop()
   { if (m_OnExceptionInMainLoop) return m_OnExceptionInMainLoop()!=0; return false; }

   void OnFatalException()
   { if (m_OnFatalException) m_OnFatalException(); }
	
	void RegisterVirtual(Virtual_OnInit onInit, Virtual_OnExit onExit,
                        Virtual_OnExceptionInMainLoop onExceptionInMainLoop, Virtual_OnFatalException onFatalException)
	{
		m_OnInit = onInit;
		m_OnExit = onExit;
      m_OnExceptionInMainLoop=onExceptionInMainLoop;
      m_OnFatalException=onFatalException;
	}	
};

//-----------------------------------------------------------------------------
// Replacement code for IMPLEMENT_APP_NO_MAIN()

#if wxCHECK_VERSION(2, 8, 0)
DECLARE_APP(_App)
IMPLEMENT_APP(_App)
static _App* _app = NULL;
#else
static _App* _app = NULL;
wxApp* wxCreateApp() { return _app; }
wxAppInitializer wxTheAppInitializer((wxAppInitializerFunction)wxCreateApp);
#endif


//-----------------------------------------------------------------------------
// C stubs for class methods

// this is for finding memory leaks
//#include <crtdbg.h>

WXNET_EXPORT(_App*)
  wxApp_ctor()
{
   // this is for finding memory leaks.
   //_CrtSetBreakAlloc(3653);
	_app = new _App();
	return _app;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxApp_RegisterVirtual(_App* self, Virtual_OnInit onInit, Virtual_OnExit onExit, Virtual_OnExceptionInMainLoop onExceptionInMainLoop, Virtual_OnFatalException onFatalException)
{
	self->RegisterVirtual(onInit, onExit, onExceptionInMainLoop, onFatalException );
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxApp_IsActive(_App* self)
{
   if (self)
      return self->IsActive();
   else
      return 0;
}

WXNET_EXPORT(char)
  wxApp_IsMainLoopRunning(_App* self)
{
   if (self)
      return self->IsMainLoopRunning();
   else
      return 0;
}

WXNET_EXPORT(char)
  wxApp_OnExceptionInMainLoop(_App* self)
{
   if (self)
      return self->OnExceptionInMainLoop();
   else
      return 0;
}

//-----------------------------------------------------------------------------

#if (!defined(__WXMSW__) || defined(_DEBUG)) && defined(WXNET_LOG_MEM)
#if defined(__WXMSW__)
#pragma message("Log memory allocations in wx_c_mem.csv.")
#define _CRTDBG_MAP_ALLOC
#include <crtdbg.h>
#include <stdlib.h>
#include <typeinfo.h>
#else
#include <malloc.h>
#define _msize malloc_usable_size
#endif

#include <fstream>

std::ofstream memalloc_log("wx_c_mem.csv");
size_t memalloc_counter=0;
bool memalloc_lock=false;
int wxnetMemoryAllocHook( int allocType, void *userData, size_t size, int 
                     blockType, long requestNumber, const unsigned char *filename, int 
                     lineNumber)
{
#if defined(__WXMSW__)
   if ( blockType != 1 )
        return( TRUE );
   if (memalloc_lock)
      return TRUE;
   memalloc_lock=true;
   if (!memalloc_counter)
      memalloc_log << "\"n\",\"type\",\"addr\",\"addr\",\"size\",\"bt\",\"no\",\"filename\",\"linno\",\"class\"" << std::endl;
   ++memalloc_counter;
   memalloc_log << memalloc_counter << ",";
   switch (allocType)
   {
      case _HOOK_ALLOC: memalloc_log<<"\"ALLOC\""; break;
      case _HOOK_REALLOC: memalloc_log << "\"REALLOC\""; break;
      case _HOOK_FREE: memalloc_log << "\"FREE\""; break;
   }
   if (size==0 && userData) size=_msize(userData);
   memalloc_log << ",\"" << userData << "\"," << (size_t) userData << "," << size << "," << blockType << "," << requestNumber;
   if (filename)
       memalloc_log << ",\"" << filename << "\"," << lineNumber;
   else
       memalloc_log << ",\"\",0";
   memalloc_log << std::endl;
   memalloc_lock=false;
#endif
   return TRUE;
}

void* wxnetLogNew(void* userData, const char* filename, int lineno)
{
   if (memalloc_lock)
      return userData;
   memalloc_lock=true;
   size_t s=0;
   if (userData) s=_msize(userData);
   memalloc_log << ",\"NEW\"";
   memalloc_log << ",\"" << userData << "\"," << (size_t) userData << "," << s << ",,";
   if (filename)
       memalloc_log << ",\"" << filename << "\"," << lineno;
   else
       memalloc_log << ",\"\",0";
   memalloc_log << std::endl;
   memalloc_lock=false;
   return userData;
}
void wxnetLogLocal(void* userData, const char* filename, int lineno)
{
   if (memalloc_lock)
      return;
   memalloc_lock=true;
   size_t s=0;
   memalloc_log << ",\"LOCAL\"";
   memalloc_log << ",\"" << userData << "\"," << (size_t) userData << "," << s << ",,";
   if (filename)
       memalloc_log << ",\"" << filename << "\"," << lineno;
   else
       memalloc_log << ",\"\",0";
   memalloc_log << std::endl;
   memalloc_lock=false;
}
void wxnetLogDel(void* userData, char const* filename, int lineno)
{
   if (!userData) return;
   if (memalloc_lock)
      return;
   memalloc_lock=true;
   size_t s=0;
   if (userData) s=_msize(userData);
   memalloc_log << ",\"DEL\"";
   memalloc_log << ",\"" << userData << "\"," << (size_t) userData << "," << s << ",,";
   if (filename)
       memalloc_log << ",\"" << filename << "\"," << lineno << std::endl;
   else
       memalloc_log << ",\"\",0" << std::endl;
   memalloc_lock=false;
}
int wxnetReportHook( int reportType, char *message, int *returnValue )
{
   *returnValue=0;
#if defined(__WXMSW__)
   memalloc_log << ",";
   switch (reportType)
   {
   case _CRT_WARN: memalloc_log << "WARNING"; break;
   case _CRT_ERROR: 
                    {
                       memalloc_log << "ERROR";
                       *returnValue=1;
                       break;
                    }
   case _CRT_ASSERT: memalloc_log << "ASSERT"; break;
   }
   memalloc_log << ",,,,,,";
   if (message)
      memalloc_log << message;
   memalloc_log << ",";
#endif
   return *returnValue;
}
/* Called on using methods of userData or if dereferencing.
*/
void wxnetLogDeref(const void* usedData, const char* typeinfo, const char* filename, int lineno)
{
   if (memalloc_lock)
      return;
   memalloc_lock=true;
   if (usedData)
   {
      memalloc_log << ",\"DEREF\"";
      memalloc_log << ",\"" << usedData << "\"," << (size_t) usedData << ",,,";
      if (filename)
          memalloc_log << ",\"" << filename << "\"," << lineno;
      else
          memalloc_log << ",\"\",0";
      memalloc_log << ",\"" << typeinfo << "\"" << std::endl;
   }
   else
   {
      memalloc_log << ",\"DEREFERROR\",0,0,,,";
      if (filename)
          memalloc_log << ",\"" << filename << "\"," << lineno << ",\"" << typeinfo << "\"" << std::endl;
      else
          memalloc_log << ",\"\",0,\"" << typeinfo << "\"" << std::endl;
   }
   memalloc_lock=false;
}
void wxnetLogDerefString(const wxString* usedData, const char* filename, int lineno)
{
   if (memalloc_lock)
      return;
   memalloc_lock=true;
   if (usedData)
   {
      memalloc_log << ",\"DEREF\"";
      memalloc_log << ",\"" << usedData << "\"," << (size_t) usedData << ",,,";
      if (filename)
          memalloc_log << ",\"" << filename << "\"," << lineno;
      else
          memalloc_log << ",\"\",0";
      memalloc_log << ",\"" << usedData->Mid(0, 40).mb_str(*wxConvCurrent) << "\"" <<  std::endl;
   }
   else
   {
      memalloc_log << ",\"DEREFERROR\",0,0,,,";
      if (filename)
          memalloc_log << ",\"" << filename << "\"," << lineno << "," << std::endl;
      else
          memalloc_log << ",\"\",0," << std::endl;
   }
   memalloc_lock=false;
}
void wxnetLogDerefPrintable(const void* usedData, const wxString& printOut, const char* filename, int lineno)
{
   if (usedData)
   {
      memalloc_log << ",\"DEREF\"";
      memalloc_log << ",\"" << usedData << "\"," << (size_t) usedData << ",,,";
      if (filename)
          memalloc_log << ",\"" << filename << "\"," << lineno;
      else
          memalloc_log << ",\"\",0";
   }
   else
   {
      memalloc_log << ",\"DEREFERROR\",0,0,,,";
      if (filename)
          memalloc_log << ",\"" << filename << "\"," << lineno;
      else
          memalloc_log << ",\"\",0";
   }
   memalloc_log << ",\"" << printOut.mb_str(*wxConvCurrent) << "\"" <<  std::endl;
}
#endif

WXNET_EXPORT(bool)
  wxApp_OnInit(_App* self)
{
	return self->wxApp::OnInit()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxApp_OnExit(_App* self)
{
	return self->wxApp::OnExit();
}

//-----------------------------------------------------------------------------

#if defined(_WINDOWS)

#define WIN32_LEAN_AND_MEAN
#include <windows.h>

#include <wx/msw/private.h>
#include <wx/cmdline.h>

WXNET_EXPORT(	int)
  wxNetEntry(HINSTANCE hInstance, HINSTANCE WXUNUSED(hPrevInstance),
			   char * WXUNUSED(pCmdLine), int nCmdShow)
	{
#if (!defined(__WXMSW__) || defined(_DEBUG)) && defined(WXNET_LOG_MEM)
   _CrtSetAllocHook(wxnetMemoryAllocHook);
   _CrtSetReportHook(wxnetReportHook);
#endif

      // remember the parameters Windows gave us
		wxSetInstance(hInstance);
		wxApp::m_nCmdShow = nCmdShow;

		// parse the command line: we can't use pCmdLine in Unicode build so it is
		// simpler to never use it at all (this also results in a more correct
		// argv[0])

		// break the command line in words
		wxArrayString args;
		const wxChar *cmdLine = ::GetCommandLine();
		if ( cmdLine )
		{
			args = wxCmdLineParser::ConvertStringToArgs(cmdLine);
		}

		int argc = args.GetCount();

		// +1 here for the terminating NULL
		wxChar **argv = new wxChar *[argc + 1];
		for ( int i = 0; i < argc; i++ )
		{
			argv[i] = wxStrdup(args[i]);
		}

		// argv[] must be NULL-terminated
		argv[argc] = NULL;

		return wxEntry(argc, argv);
	}

	static HANDLE thisModule;

WXNET_EXPORT(	void)
  wxApp_Run(int argc, char* argv[])
	{
		wxNetEntry((HINSTANCE)thisModule, NULL, (char*)GetCommandLineW(), 0);
	}

	BOOL APIENTRY DllMain(HANDLE hModule, DWORD ulReasonForCall, LPVOID lpReserved)
	{
		if (ulReasonForCall == DLL_PROCESS_ATTACH)
			thisModule = hModule;
		return TRUE;
	}

#else

WXNET_EXPORT(	void)
  wxApp_Run(int argc, char* argv[])
	{
		wxEntry(argc, argv);
	}

#endif

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxApp_GetVendorName(wxApp* self)
{
   if (self)
    return new wxString(self->GetVendorName());
   else
      return NULL;
}

WXNET_EXPORT(void)
  wxApp_SetVendorName(wxApp* self, const wxString* name)
{
   if (self && name)
    self->SetVendorName(*name);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxApp_GetAppName(wxApp* self)
{
   if (self)
    return new wxString(self->GetAppName());
   else
      return NULL;
}

WXNET_EXPORT(void)
  wxApp_SetAppName(wxApp* self, const wxString* name)
{
   if (self && name)
    self->SetAppName(*name);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxApp_SafeYield(wxWindow* win, bool onlyIfNeeded) 
{
    return ::wxSafeYield(win, onlyIfNeeded)?1:0;
}

#ifdef Yield
    #undef Yield
#endif
WXNET_EXPORT(char)
  wxApp_Yield(wxApp* self, bool onlyIfNeeded)
{
    return self->Yield(onlyIfNeeded)?1:0;
}

WXNET_EXPORT(void)
  wxApp_WakeUpIdle()
{
    //::wxWakeUpIdle();
}

//-----------------------------------------------------------------------------
