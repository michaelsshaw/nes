// //-----------------------------------------------------------------------------
// wx.NET - textctrl.cxx
//
// The wxTextCtrl proxy interface.
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 by Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: textctrl.cxx,v 1.22 2010/06/16 18:10:37 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/textctrl.h>
#include "local_events.h"

//-----------------------------------------------------------------------------

/*class _TextAttr : public wxTextAttr
{
public:
	_TextAttr(const wxColour& colText, const wxColour& colBack, const wxFont& font, wxTextAttrAlignment alignment)
		: wxTextAttr(colText, colBack, font, alignment) {}
		
	_TextAttr()
		: wxTextAttr() {}

	DECLARE_DISPOSABLE(_TextAttr)
};*/

WXNET_EXPORT(wxTextAttr*)
  wxTextAttr_ctor(const wxColour* colText, const wxColour* colBack, const wxFont* font, wxTextAttrAlignment alignment)
{
	if (colText == NULL)
		colText = &wxNullColour;
	if (colBack == NULL)
		colBack = &wxNullColour;
	if (font == NULL)
		font = &wxNullFont;

	return new wxTextAttr(*colText, *colBack, *font, alignment);
}

WXNET_EXPORT(wxTextAttr*)
  wxTextAttr_ctor2()
{
	return new wxTextAttr();
}

WXNET_EXPORT(void)
  wxTextAttr_dtor(wxTextAttr* self)
{
	if (self != NULL)
		delete self;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTextAttr_Init(wxTextAttr* self)
{
	self->Init();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTextAttr_SetTextColour(wxTextAttr* self, const wxColour* colText)
{
	self->SetTextColour(*colText);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxColour*)
  wxTextAttr_GetTextColour(wxTextAttr* self)
{
	return new wxColour(self->GetTextColour());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTextAttr_SetBackgroundColour(wxTextAttr* self, wxColour *colBack)
{
	self->SetBackgroundColour(*colBack);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTextAttr_SetFont(wxTextAttr* self, const wxFont* font)
{
	self->SetFont(*font);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxTextAttr_HasTextColour(wxTextAttr* self)
{
	return self->HasTextColour()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxTextAttr_HasBackgroundColour(wxTextAttr* self)
{
	return self->HasBackgroundColour()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxTextAttr_HasFont(wxTextAttr* self)
{
	return self->HasFont()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxTextAttr_HasAlignment(wxTextAttr* self)
{
	return self->HasAlignment()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxTextAttr_HasTabs(wxTextAttr* self)
{
	return self->HasTabs()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxTextAttr_HasLeftIndent(wxTextAttr* self)
{
	return self->HasLeftIndent()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxTextAttr_HasRightIndent(wxTextAttr* self)
{
	return self->HasRightIndent()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxTextAttr_HasFlag(wxTextAttr* self, unsigned int flag)
{
	return self->HasFlag(flag)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxTextAttr_IsDefault(wxTextAttr* self)
{
	return self->IsDefault()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTextAttr_SetAlignment(wxTextAttr* self, wxTextAttrAlignment alignment)
{
	self->SetAlignment(alignment);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxTextAttrAlignment)
  wxTextAttr_GetAlignment(wxTextAttr* self)
{
	return self->GetAlignment();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxColour*)
  wxTextAttr_GetBackgroundColour(wxTextAttr* self)
{
	return new wxColour(self->GetBackgroundColour());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxFont*)
  wxTextAttr_GetFont(wxTextAttr* self)
{
	return new wxFont(self->GetFont());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxTextAttr_GetLeftIndent(wxTextAttr* self)
{
	return self->GetLeftIndent();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxTextAttr_GetLeftSubIndent(wxTextAttr* self)
{
	return self->GetLeftSubIndent();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTextAttr_SetTabs(wxTextAttr* self, wxArrayInt* tabs)
{
	self->SetTabs(*tabs);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxArrayInt*)
  wxTextAttr_GetTabs(wxTextAttr* self)
{
	wxArrayInt *ari = new wxArrayInt();
	*ari = self->GetTabs();
    	return ari;	
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTextAttr_SetLeftIndent(wxTextAttr* self, int indent, int subIndent)
{
	self->SetLeftIndent(indent, subIndent);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTextAttr_SetRightIndent(wxTextAttr* self, int indent)
{
	self->SetRightIndent(indent);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxTextAttr_GetRightIndent(wxTextAttr* self)
{
	return self->GetRightIndent();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTextAttr_SetFlags(wxTextAttr* self, int flags)
{
	self->SetFlags(flags);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxTextAttr_GetFlags(wxTextAttr* self)
{
	return self->GetFlags();
}

//-----------------------------------------------------------------------------
// wxTextCtrl

class _TextCtrl : public wxTextCtrl
{
public:
    DECLARE_OBJECTDELETED(_TextCtrl)
};

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxTextCtrl_GetValue(wxTextCtrl* self)
{
	return new wxString(self->GetValue());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTextCtrl_SetValue(wxTextCtrl* self, const wxString* value)
{
   if (self && value)
	   self->SetValue(*value);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxTextCtrl_GetRange(wxTextCtrl* self, int from, int to)
{
	return new wxString(self->GetRange(from, to));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxTextCtrl_GetLineLength(wxTextCtrl* self, int lineNo)
{
	return self->GetLineLength(lineNo);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxTextCtrl_GetLineText(wxTextCtrl* self, int lineNo)
{
	return new wxString(self->GetLineText(lineNo));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxTextCtrl_GetNumberOfLines(wxTextCtrl* self)
{
	return self->GetNumberOfLines();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxTextCtrl_IsModified(wxTextCtrl* self)
{
	return self->IsModified()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxTextCtrl_IsEditable(wxTextCtrl* self)
{
	return self->IsEditable()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxTextCtrl_IsSingleLine(wxTextCtrl* self)
{
	return self->IsSingleLine()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxTextCtrl_IsMultiLine(wxTextCtrl* self)
{
	return self->IsMultiLine()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTextCtrl_GetSelection(wxTextCtrl* self, int* from, int* to)
{
   if (!from || !to) return;
   long lfrom=*from;
   long lto=*to;
	self->GetSelection(&lfrom, &lto);
   *from=(int)lfrom;
   *to=(int)lto;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxTextCtrl_GetStringSelection(wxTextCtrl* self)
{
	return new wxString(self->GetStringSelection());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTextCtrl_Clear(wxTextCtrl* self)
{
	self->Clear();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTextCtrl_Replace(wxTextCtrl* self, int from, int to, const wxString* value)
{
   if (self && value)
	   self->Replace(from, to, *value);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTextCtrl_Remove(wxTextCtrl* self, int from, int to)
{
	self->Remove(from, to);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxTextCtrl_LoadFile(wxTextCtrl* self, const wxString* file)
{
   if (self && file)
	   return self->LoadFile(*file);
   else
      return false;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxTextCtrl_SaveFile(wxTextCtrl* self, const wxString* file)
{
   if (self && file)
	   return self->SaveFile(*file);
   else
      return false;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTextCtrl_DiscardEdits(wxTextCtrl* self)
{
	self->DiscardEdits();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTextCtrl_SetMaxLength(wxTextCtrl* self, int len)
{
	self->SetMaxLength(len);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTextCtrl_WriteText(wxTextCtrl* self, const wxString* text)
{
   if (self && text)
	   self->WriteText(*text);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTextCtrl_AppendText(wxTextCtrl* self, const wxString* text)
{
   if (self && text)
   	self->AppendText(*text);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxTextCtrl_EmulateKeyPress(wxTextCtrl* self, const wxKeyEvent* event)
{
	return self->EmulateKeyPress(*event)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxTextCtrl_SetStyle(wxTextCtrl* self, int start, int end, const wxTextAttr* style)
{
	return self->SetStyle(start, end, *style)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxTextCtrl_GetStyle(wxTextCtrl* self, int position, wxTextAttr* style)
{
	return self->GetStyle(position, *style)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxTextCtrl_SetDefaultStyle(wxTextCtrl* self, const wxTextAttr* style)
{
	return self->SetDefaultStyle(*style)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxTextAttr*)
  wxTextCtrl_GetDefaultStyle(wxTextCtrl* self)
{
	return new wxTextAttr(self->GetDefaultStyle());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxTextCtrl_XYToPosition(wxTextCtrl* self, int x, int y)
{
	return self->XYToPosition(x, y);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxTextCtrl_PositionToXY(wxTextCtrl* self, int pos, int *x, int *y)
{
   long lx=*x;
   long ly=*y;
	bool result = self->PositionToXY(pos, &lx, &ly);
   *x=(int)lx;
   *y=(int)ly;
   return result?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTextCtrl_ShowPosition(wxTextCtrl* self, int pos)
{
	self->ShowPosition(pos);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTextCtrl_Copy(wxTextCtrl* self)
{
	self->Copy();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTextCtrl_Cut(wxTextCtrl* self)
{
	self->Cut();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTextCtrl_Paste(wxTextCtrl* self)
{
	self->Paste();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxTextCtrl_CanCopy(wxTextCtrl* self)
{
	return self->CanCopy()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxTextCtrl_CanCut(wxTextCtrl* self)
{
	return self->CanCut()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxTextCtrl_CanPaste(wxTextCtrl* self)
{
	return self->CanPaste()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTextCtrl_Undo(wxTextCtrl* self)
{
	self->Undo();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTextCtrl_Redo(wxTextCtrl* self)
{
	self->Redo();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxTextCtrl_CanUndo(wxTextCtrl* self)
{
	return self->CanUndo()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxTextCtrl_CanRedo(wxTextCtrl* self)
{
	return self->CanRedo()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTextCtrl_SetInsertionPoint(wxTextCtrl* self, int pos)
{
	self->SetInsertionPoint(pos);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTextCtrl_SetInsertionPointEnd(wxTextCtrl* self)
{
	self->SetInsertionPointEnd();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxTextCtrl_GetInsertionPoint(wxTextCtrl* self)
{
	return self->GetInsertionPoint();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxTextCtrl_GetLastPosition(wxTextCtrl* self)
{
	return self->GetLastPosition();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTextCtrl_SetSelection(wxTextCtrl* self, int from, int to)
{
	self->SetSelection(from, to);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTextCtrl_SelectAll(wxTextCtrl* self)
{
	self->SelectAll();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTextCtrl_SetEditable(wxTextCtrl* self, bool editable)
{
	self->SetEditable(editable);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxTextUrlEvent*)
  wxTextUrlEvent_ctor(int id, const wxMouseEvent* evtMouse, int start, int end)
{
	return new wxTextUrlEvent(id, *evtMouse, start, end);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxTextUrlEvent_GetURLStart(wxTextUrlEvent* self)
{
	return self->GetURLStart();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxTextUrlEvent_GetURLEnd(wxTextUrlEvent* self)
{
	return self->GetURLEnd();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxTextCtrl*)
  wxTextCtrl_ctor()
{
	return new _TextCtrl();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxTextCtrl_Create(wxTextCtrl* self, wxWindow *parent, wxWindowID id, const wxString* valueArg, int posX, int posY, int width, int height, unsigned int style, const wxValidator* validator, const wxString* nameArg)
{
   wxString value;
	if (valueArg)
		value = *valueArg;

	if (validator == NULL)
		validator = &wxDefaultValidator;

   wxString name;
	if (nameArg)
		name = *nameArg;

	return self->Create(parent, id, value, wxPoint(posX, posY), wxSize(width, height), style, *validator, name);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxTextCtrl_Enable(wxTextCtrl* self, bool enable)
{
	return self->Enable(enable)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTextCtrl_OnDropFiles(wxTextCtrl* self, wxDropFilesEvent *event)
{
	self->OnDropFiles(*event);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxTextCtrl_SetFont(wxTextCtrl* self, const wxFont* font)
{
	return self->SetFont(*font)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxTextCtrl_SetForegroundColour(wxTextCtrl* self, const wxColour* colour)
{
	return self->SetForegroundColour(*colour)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxTextCtrl_SetBackgroundColour(wxTextCtrl* self, const wxColour* colour)
{
	return self->SetBackgroundColour(*colour)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTextCtrl_Freeze(wxTextCtrl* self)
{
	self->Freeze();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTextCtrl_Thaw(wxTextCtrl* self)
{
	self->Thaw();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxTextCtrl_ScrollLines(wxTextCtrl* self, int lines)
{
	return self->ScrollLines(lines)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxTextCtrl_ScrollPages(wxTextCtrl* self, int pages)
{
	return self->ScrollPages(pages)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTextCtrl_MarkDirty(wxTextCtrl* self)
{
	self->MarkDirty();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxTextCtrlHitTestResult)
  wxTextCtrl_HitTest(wxTextCtrl* self, wxPoint* pt, int* pos)
{
   if (!pos || !pt || !self) return (wxTextCtrlHitTestResult) -2;
   long lpos=*pos;
	wxTextCtrlHitTestResult result = self->HitTest(*pt, &lpos);
   *pos=(int)lpos;
   return result;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxTextCtrlHitTestResult)
  wxTextCtrl_HitTest2(wxTextCtrl* self, wxPoint* pt, wxTextCoord *col, wxTextCoord *row)
{
	return self->HitTest(*pt, col, row);
}

