//-----------------------------------------------------------------------------
// wx.NET - menu.cxx
//
// The wxMenu proxy interface.
//
// Written by Achim Breunig(achim.breunig@web.de)
// (C) 2003 by Achim Breunig
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: menuitem.cxx,v 1.10 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#ifndef WXNET_GLOBAL_H
#include "wxnet_globals.h"
#endif

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxMenuItem*)
  wxMenuItem_ctor(wxMenu* parentMenu, int id, const wxString* text, const wxString* help, wxItemKind kind, wxMenu* subMenu)
{
   if (text && help)
      return new wxMenuItem(parentMenu, id, *text, *help, kind, subMenu);
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxMenu*)
  wxMenuItem_GetMenu(wxMenuItem* self)
{
    return self->GetMenu();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxMenuItem_SetMenu(wxMenuItem* self, wxMenu* menu)
{
    self->SetMenu(menu);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxMenuItem_SetId(wxMenuItem* self, int id)
{
    self->SetId(id);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxMenuItem_GetId(wxMenuItem* self)
{
    return self->GetId();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxMenuItem_IsSeparator(wxMenuItem* self)
{
    return self->IsSeparator()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxMenuItem_SetText(wxMenuItem* self, const wxString* str)
{
   if (self && str)
    self->SetText(*str);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxMenuItem_GetLabel(wxMenuItem* self)
{
    return new wxString(self->GetLabel());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxMenuItem_GetText(wxMenuItem* self)
{
    return new wxString(self->GetText());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxMenuItem_GetLabelFromText(wxMenuItem* self, const wxString* text)
{
   if (self && text)
    return new wxString(self->GetLabelFromText(*text));
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxItemKind)
  wxMenuItem_GetKind(wxMenuItem* self)
{
    return self->GetKind();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxMenuItem_SetCheckable(wxMenuItem* self, bool checkable)
{
    self->SetCheckable(checkable);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxMenuItem_IsCheckable(wxMenuItem* self)
{
    return self->IsCheckable()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxMenuItem_IsSubMenu(wxMenuItem* self)
{
    return self->IsSubMenu()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxMenuItem_SetSubMenu(wxMenuItem* self, wxMenu* menu)
{
    self->SetSubMenu(menu);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxMenu*)
  wxMenuItem_GetSubMenu(wxMenuItem* self)
{
    return self->GetSubMenu();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxMenuItem_Enable(wxMenuItem* self, bool enable)
{
    self->Enable(enable);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxMenuItem_IsEnabled(wxMenuItem* self)
{
    return self->IsEnabled()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxMenuItem_Check(wxMenuItem* self, bool check)
{
    self->Check(check);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxMenuItem_IsChecked(wxMenuItem* self)
{
    return self->IsChecked()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxMenuItem_Toggle(wxMenuItem* self)
{
    self->Toggle();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxMenuItem_SetHelp(wxMenuItem* self, const wxString* str)
{
   if (self && str)
    self->SetHelp(*str);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxMenuItem_GetHelp(wxMenuItem* self)
{
    return new wxString(self->GetHelp());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxAcceleratorEntry*)
  wxMenuItem_GetAccel(wxMenuItem* self)
{
    return self->GetAccel();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxMenuItem_SetAccel(wxMenuItem* self, wxAcceleratorEntry* accel)
{
    self->SetAccel(accel);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxMenuItem_SetName(wxMenuItem* self, const wxString* str)
{
   if (self && str)
    self->SetText(*str);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxMenuItem_GetName(wxMenuItem* self)
{
    return new wxString(self->GetText());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxMenuItem*)
  wxMenuItem_NewCheck(wxMenu* parentMenu, int id, const wxString* text, const wxString* help, bool isCheckable, wxMenu* subMenu)
{
   if (text && help)
    return wxMenuItem::New(parentMenu, id, *text, *help, isCheckable, subMenu);
   else
      return NULL;
}

WXNET_EXPORT(wxMenuItem*)
  wxMenuItem_New(wxMenu* parentMenu, int id, const wxString* text, const wxString* help, wxItemKind kind, wxMenu* subMenu)
{
   if (text && help)
    return wxMenuItem::New(parentMenu, id, *text, *help, kind, subMenu);
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxMenuItem_SetBitmap(wxMenuItem* self, wxBitmap* bitmap)
{
    self->SetBitmap(*bitmap);
}

WXNET_EXPORT(const wxBitmap*)
  wxMenuItem_GetBitmap(wxMenuItem* self)
{
    return &(self->GetBitmap());
}

//-----------------------------------------------------------------------------
