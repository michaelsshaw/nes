//-----------------------------------------------------------------------------
// wx.NET - displaychangedevent.cxx
// 
// The wxDisplayChangedEvent proxy interface.
//
// Written by Alexander Olk (xenomorph2@onlinehome.de)
// (C) 2004 by Alexander Olk
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: displaychangedevent.cxx,v 1.3 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#ifndef WXNET_GLOBAL_H
#include "wxnet_globals.h"
#endif

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxDisplayChangedEvent*)
  wxDisplayChangedEvent_ctor()
{
    return new wxDisplayChangedEvent();
}
