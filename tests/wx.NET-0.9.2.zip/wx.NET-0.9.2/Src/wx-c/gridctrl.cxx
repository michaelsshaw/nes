//-----------------------------------------------------------------------------
// wx.NET - gridctrl.cxx
// 
// The wxGrid controls proxy interface.
//
// Written by Alexander Olk (xenomorph2@onlinehome.de)
// (C) 2004 by Alexander Olk
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: gridctrl.cxx,v 1.6 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/grid.h>
#include <wx/generic/gridctrl.h>
#include "local_events.h"

//-----------------------------------------------------------------------------
// wxGridCellDateTimeRenderer

WXNET_EXPORT(wxGridCellDateTimeRenderer*)
  wxGridCellDateTimeRenderer_ctor(const wxString* outformat, const wxString* informat)
{
   if (outformat && informat)
	   return new wxGridCellDateTimeRenderer(*outformat, *informat);
   return NULL;
}

WXNET_EXPORT(void)
  wxGridCellDateTimeRenderer_dtor(wxGridCellDateTimeRenderer* self)
{
	WXNET_DEL(self);
}

WXNET_EXPORT(void)
  wxGridCellDateTimeRenderer_Draw(wxGridCellDateTimeRenderer* self, wxGrid* grid, wxGridCellAttr* attr,
				wxDC* dc, wxRect* rect, int row, int col, bool isSelected)
{
	self->Draw(*grid, *attr, *dc, *rect, row, col, isSelected);
}

WXNET_EXPORT(void)
  wxGridCellDateTimeRenderer_GetBestSize(wxGridCellDateTimeRenderer* self, wxGrid *grid, wxGridCellAttr *attr,
				wxDC* dc, int row, int col, wxSize* size)
{
	*size = self->GetBestSize(*grid, *attr, *dc, row, col);
}

WXNET_EXPORT(wxGridCellRenderer*)
  wxGridCellDateTimeRenderer_Clone(wxGridCellDateTimeRenderer* self)
{
	return self->Clone();
}

WXNET_EXPORT(void)
  wxGridCellDateTimeRenderer_SetParameters(wxGridCellDateTimeRenderer* self, const wxString* params)
{
   if (self && params)
	   self->SetParameters(*params);
}

//-----------------------------------------------------------------------------
// wxGridCellEnumRenderer

WXNET_EXPORT(wxGridCellEnumRenderer*)
  wxGridCellEnumRenderer_ctor(const wxString* choices)
{
   if (choices)
	   return new wxGridCellEnumRenderer(*choices);
   else
      return NULL;
}

WXNET_EXPORT(void)
  wxGridCellEnumRenderer_dtor(wxGridCellEnumRenderer* self)
{
	WXNET_DEL(self);
}

WXNET_EXPORT(void)
  wxGridCellEnumRenderer_Draw(wxGridCellEnumRenderer* self, wxGrid* grid, wxGridCellAttr* attr,
				wxDC* dc, wxRect* rect, int row, int col, bool isSelected)
{
	self->Draw(*grid, *attr, *dc, *rect, row, col, isSelected);
}

WXNET_EXPORT(void)
  wxGridCellEnumRenderer_GetBestSize(wxGridCellEnumRenderer* self, wxGrid *grid, wxGridCellAttr *attr,
				wxDC* dc, int row, int col, wxSize* size)
{
	*size = self->GetBestSize(*grid, *attr, *dc, row, col);
}

WXNET_EXPORT(wxGridCellRenderer*)
  wxGridCellEnumRenderer_Clone(wxGridCellEnumRenderer* self)
{
	return self->Clone();
}

WXNET_EXPORT(void)
  wxGridCellEnumRenderer_SetParameters(wxGridCellEnumRenderer* self, const wxString* params)
{
   if (self && params)
	   self->SetParameters(*params);
}

//-----------------------------------------------------------------------------
// wxGridCellAutoWrapStringRenderer

class _GridCellAutoWrapStringRenderer : public wxGridCellAutoWrapStringRenderer
{
public:
	_GridCellAutoWrapStringRenderer()
		: wxGridCellAutoWrapStringRenderer() {}

	DECLARE_DISPOSABLE(_GridCellAutoWrapStringRenderer)
};

WXNET_EXPORT(wxGridCellAutoWrapStringRenderer*)
  wxGridCellAutoWrapStringRenderer_ctor()
{
	return new _GridCellAutoWrapStringRenderer();
}

WXNET_EXPORT(void)
  wxGridCellAutoWrapStringRenderer_dtor(wxGridCellAutoWrapStringRenderer* self)
{
	WXNET_DEL(self);
}

WXNET_EXPORT(void)
  wxGridCellAutoWrapStringRenderer_RegisterDisposable(_GridCellAutoWrapStringRenderer* self, Virtual_Dispose onDispose)
{
	self->RegisterDispose(onDispose);
}

WXNET_EXPORT(void)
  wxGridCellAutoWrapStringRenderer_Draw(wxGridCellAutoWrapStringRenderer* self, wxGrid* grid, wxGridCellAttr* attr,
				wxDC* dc, wxRect* rect, int row, int col, bool isSelected)
{
	self->Draw(*grid, *attr, *dc, *rect, row, col, isSelected);
}

WXNET_EXPORT(void)
  wxGridCellAutoWrapStringRenderer_GetBestSize(wxGridCellAutoWrapStringRenderer* self, wxGrid *grid, wxGridCellAttr *attr,
				wxDC* dc, int row, int col, wxSize* size)
{
	*size = self->GetBestSize(*grid, *attr, *dc, row, col);
}

WXNET_EXPORT(wxGridCellRenderer*)
  wxGridCellAutoWrapStringRenderer_Clone(wxGridCellAutoWrapStringRenderer* self)
{
	return self->Clone();
}

//-----------------------------------------------------------------------------
// wxGridCellEnumEditor

WXNET_EXPORT(wxGridCellEnumEditor*)
  wxGridCellEnumEditor_ctor(const wxString* choices)
{
   if (choices)
	   return new wxGridCellEnumEditor(*choices);
   return NULL;
}

WXNET_EXPORT(void)
  wxGridCellEnumEditor_dtor(wxGridCellEnumEditor* self)
{
	WXNET_DEL(self);
}

WXNET_EXPORT(void)
  wxGridCellEnumEditor_BeginEdit(wxGridCellEnumEditor* self, int row, int col, wxGrid* grid)
{
	return self->BeginEdit(row, col, grid);
}

WXNET_EXPORT(bool)
  wxGridCellEnumEditor_EndEdit(wxGridCellEnumEditor* self, int row, int col, wxGrid* grid)
{
	return self->EndEdit(row, col, grid)?1:0;
}

WXNET_EXPORT(wxGridCellEditor*)
  wxGridCellEnumEditor_Clone(wxGridCellEnumEditor* self)
{
	return self->Clone();
}

//-----------------------------------------------------------------------------
// wxGridCellAutoWrapStringEditor

class _GridCellAutoWrapStringEditor : public wxGridCellAutoWrapStringEditor
{
public:
	_GridCellAutoWrapStringEditor()
		: wxGridCellAutoWrapStringEditor() {}

	DECLARE_DISPOSABLE(_GridCellAutoWrapStringEditor)
};

WXNET_EXPORT(wxGridCellAutoWrapStringEditor*)
  wxGridCellAutoWrapStringEditor_ctor()
{
	return new _GridCellAutoWrapStringEditor();
}

WXNET_EXPORT(void)
  wxGridCellAutoWrapStringEditor_dtor(wxGridCellAutoWrapStringEditor* self)
{
	WXNET_DEL(self);
}

WXNET_EXPORT(void)
  wxGridCellAutoWrapStringEditor_RegisterDisposable(_GridCellAutoWrapStringEditor* self, Virtual_Dispose onDispose)
{
	self->RegisterDispose(onDispose);
}

WXNET_EXPORT(void)
  wxGridCellAutoWrapStringEditor_Create(wxGridCellAutoWrapStringEditor* self, wxWindow* parent, wxWindowID id, wxEvtHandler* evtHandler)
{
	self->Create(parent, id, evtHandler);
}

WXNET_EXPORT(wxGridCellEditor*)
  wxGridCellAutoWrapStringEditor_Clone(wxGridCellAutoWrapStringEditor* self)
{
	return self->Clone();
}

