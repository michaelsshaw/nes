//-----------------------------------------------------------------------------
// wx.NET - textdialog.cxx
//
// The wxTextEntryDialog proxy interface.
//
// Written by Alexander Olk (xenomorph2@onlinehome.de)
// (C) 2003 by Alexander Olk
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: textdialog.cxx,v 1.6 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/textdlg.h>
#include "local_events.h"

class _TextEntryDialog : public wxTextEntryDialog
{
    public:
        _TextEntryDialog(wxWindow* parent, const wxString message,
                const wxString& caption, const wxString& value,
                long style, const wxPoint& pos)
            : wxTextEntryDialog(parent, message, caption, value, style, pos)
        {
        }

        DECLARE_OBJECTDELETED(_TextEntryDialog)
};


//-----------------------------------------------------------------------------

WXNET_EXPORT(wxTextEntryDialog*)
  wxTextEntryDialog_ctor(wxWindow* parent, const wxString* messageArg,
        const wxString* captionArg, const wxString* valueArg, unsigned int style, int posX, int posY)
{
   wxString message;
   if (messageArg)
      message=*messageArg;
   wxString caption;
   if (captionArg)
      caption=*captionArg;
   wxString value;
   if (valueArg)
      value=*valueArg;
   return new _TextEntryDialog(parent, message, caption, value, style, wxPoint(posX, posY));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTextEntryDialog_dtor(wxTextEntryDialog* self)
{
    delete self;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxTextEntryDialog_ShowModal(wxTextEntryDialog* self)
{
    return self->ShowModal();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxTextEntryDialog_SetValue(wxTextEntryDialog* self, const wxString* val)
{
   if (self && val)
    self->SetValue(*val);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxTextEntryDialog_GetValue(wxTextEntryDialog* self)
{
    return new wxString(self->GetValue());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxGetPasswordFromUser_func(const wxString* messageArg, const wxString* captionArg,
                                     const wxString* defaultValueArg, wxWindow* parent)
{
    wxString message;
    if (messageArg)
       message=*messageArg;
    wxString caption;
    if (captionArg)
       caption=*captionArg;
    wxString defaultValue;
    if (defaultValueArg)
       defaultValue=*defaultValueArg;
    return new wxString(wxGetPasswordFromUser(message, caption, defaultValue, parent));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxGetTextFromUser_func(const wxString* messageArg, const wxString* captionArg,
                                 const wxString* defaultValueArg, wxWindow* parent,
                                 int x, int y, bool centre)
{
    wxString message;
    if (messageArg)
       message=*messageArg;
    wxString caption;
    if (captionArg)
       caption=*captionArg;
    wxString defaultValue;
    if (defaultValueArg)
       defaultValue=*defaultValueArg;
    return new wxString(wxGetTextFromUser(message, caption, defaultValue, parent, x, y, centre));
}



