//-----------------------------------------------------------------------------
// wx.NET - sizeritem.cxx
//
// The wxSizerItem proxy interface.
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 by Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: sizeritem.cxx,v 1.4 2008/12/25 17:01:35 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include "local_events.h"

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxSizerItem*)
  wxSizerItem_ctorSpace(int width, int height, int proportion, int flag, int border, wxObject* userData)
{
    return new wxSizerItem(width, height, proportion, flag, border, userData);
}

WXNET_EXPORT(wxSizerItem*)
  wxSizerItem_ctorWindow(wxWindow* window, int proportion, int flag, int border, wxObject* userData)
{
    return new wxSizerItem(window, proportion, flag, border, userData);
}

WXNET_EXPORT(wxSizerItem*)
  wxSizerItem_ctorSizer(wxSizer* sizer, int proportion, int flag, int border, wxObject* userData)
{
    return new wxSizerItem(sizer, proportion, flag, border, userData);
}

WXNET_EXPORT(wxSizerItem*)
  wxSizerItem_ctor()
{
    return new wxSizerItem();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxSizerItem_DeleteWindows(wxSizerItem* self)
{
    self->DeleteWindows();
}

WXNET_EXPORT(void)
  wxSizerItem_DetachSizer(wxSizerItem* self)
{
    self->DetachSizer();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxSizerItem_GetSize(wxSizerItem* self, wxSize* size)
{
    *size = self->GetSize();
}

WXNET_EXPORT(void)
  wxSizerItem_CalcMin(wxSizerItem* self, wxSize* min)
{
    *min = self->CalcMin();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxSizerItem_SetDimension(wxSizerItem* self, wxPoint pos, wxSize size)
{
    self->SetDimension(pos, size);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxSizerItem_GetMinSize(wxSizerItem* self, wxSize* size)
{
    *size = self->GetMinSize();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxSizerItem_SetInitSize(wxSizerItem* self, int x, int y)
{
    self->SetInitSize(x, y);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxSizerItem_SetRatio(wxSizerItem* self, int width, int height)
{
    self->SetRatio(width, height);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxSizerItem_SetRatioFloat(wxSizerItem* self, float ratio)
{
    self->SetRatio(ratio);
}

WXNET_EXPORT(float)
  wxSizerItem_GetRatioFloat(wxSizerItem* self)
{
    return self->GetRatio();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxSizerItem_IsWindow(wxSizerItem* self)
{
    return self->IsWindow()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxSizerItem_IsSizer(wxSizerItem* self)
{
    return self->IsSizer()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxSizerItem_IsSpacer(wxSizerItem* self)
{
    return self->IsSpacer()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxSizerItem_SetProportion(wxSizerItem* self, int proportion)
{
    self->SetProportion(proportion);
}

WXNET_EXPORT(int)
  wxSizerItem_GetProportion(wxSizerItem* self)
{
    return self->GetProportion();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxSizerItem_SetFlag(wxSizerItem* self, int flag)
{
    self->SetFlag(flag);
}

WXNET_EXPORT(int)
  wxSizerItem_GetFlag(wxSizerItem* self)
{
    return self->GetFlag();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxSizerItem_SetBorder(wxSizerItem* self, int border)
{
    self->SetBorder(border);
}

WXNET_EXPORT(int)
  wxSizerItem_GetBorder(wxSizerItem* self)
{
    return self->GetBorder();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxWindow*)
  wxSizerItem_GetWindow(wxSizerItem* self)
{
    return self->GetWindow();
}

WXNET_EXPORT(void)
  wxSizerItem_SetWindow(wxSizerItem* self, wxWindow* window)
{
    self->SetWindow(window);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxSizer*)
  wxSizerItem_GetSizer(wxSizerItem* self)
{
    return self->GetSizer();
}

WXNET_EXPORT(void)
  wxSizerItem_SetSizer(wxSizerItem* self, wxSizer* sizer)
{
    self->SetSizer(sizer);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxSizerItem_GetSpacer(wxSizerItem* self, wxSize* size)
{
    *size = self->GetSpacer();
}

WXNET_EXPORT(void)
  wxSizerItem_SetSpacer(wxSizerItem* self, wxSize* size)
{
    self->SetSpacer(*size);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxSizerItem_Show(wxSizerItem* self, bool show)
{
    self->Show(show);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxSizerItem_IsShown(wxSizerItem* self)
{
    return self->IsShown()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxObject*)
  wxSizerItem_GetUserData(wxSizerItem* self)
{
    return self->GetUserData();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxSizerItem_GetPosition(wxSizerItem* self, wxPoint* pos)
{
    *pos = self->GetPosition();
}

