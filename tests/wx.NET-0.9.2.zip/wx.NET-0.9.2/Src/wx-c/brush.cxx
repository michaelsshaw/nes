//-----------------------------------------------------------------------------
// wx.NET - brush.cxx
//
// The wxBrush proxy interface.
//
// Written by Jason Perkins (jason@379.com)
// (C) 2003 by 379, Inc.
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: brush.cxx,v 1.7 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#ifndef WXNET_GLOBAL_H
#include "wxnet_globals.h"
#endif

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxBrush*)
  wxBrush_ctor()
{
	return new wxBrush();
}

//-----------------------------------------------------------------------------

//wxBrush* wxBrush_ctor(const wxColour *colour, int style)
//wxBrush* wxBrush_ctor(const wxBitmap *stippleBitmap)

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxBrush_Ok(wxBrush* self)
{
	return self->Ok()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxBrush_GetStyle(wxBrush* self)
{
	return self->GetStyle();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxBitmap*)
  wxBrush_GetStipple(wxBrush* self)
{
	return self->GetStipple();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxBrush_SetColour(wxBrush* self, const wxColour* col)
{
	self->SetColour(*col);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxColour*)
  wxBrush_GetColour(wxBrush* self) 
{
    return new wxColour(self->GetColour());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxBrush_SetStyle(wxBrush* self, int style)
{
	self->SetStyle(style);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxBrush_SetStipple(wxBrush* self, const wxBitmap* stipple)
{
	self->SetStipple(*stipple);
}

