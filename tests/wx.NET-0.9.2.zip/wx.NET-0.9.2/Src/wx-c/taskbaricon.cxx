//-----------------------------------------------------------------------------
// wx.NET - taskbaricon.cxx
//
// The wxTaskBarIcon proxy interface.
//
// Written by Jacek Trublajewicz
// (C) 2008 by Jacek Trublajewicz
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: taskbaricon.cxx,v 1.2 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/taskbar.h>
#include "local_events.h"

//-----------------------------------------------------------------------------

typedef wxMenu* (*wxTaskBarIcon_CreatePopupMenuHandler)(void);

class _TaskBarIcon : public wxTaskBarIcon
{
public:
    wxTaskBarIcon_CreatePopupMenuHandler m_createPopupMenuHandler;

    _TaskBarIcon() : m_createPopupMenuHandler(NULL) {}
    DECLARE_OBJECTDELETED(_TaskBarIcon)

    virtual wxMenu* CreatePopupMenu()
    {
       if (m_createPopupMenuHandler)
          return (*m_createPopupMenuHandler)();
       else
          return NULL;
    }
};

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxTaskBarIcon*)
  wxTaskBarIcon_ctor()
{
	return new _TaskBarIcon();
}

WXNET_EXPORT(void)
  wxTaskBarIcon_dtor(wxTaskBarIcon* self)
{
	WXNET_DEL( self );
}

WXNET_EXPORT(void)
  wxTaskBarIcon_RegisterVirtuals(wxTaskBarIcon* selfArg, wxTaskBarIcon_CreatePopupMenuHandler handler)
{
   _TaskBarIcon* self=dynamic_cast<_TaskBarIcon*>(selfArg);
   if (self)
   {
      self->m_createPopupMenuHandler=handler;
   }
}

//-----------------------------------------------------------------------------


WXNET_EXPORT(bool)
  wxTaskBarIcon_IsOk(wxTaskBarIcon* self)
{
	return self->IsOk();
}

WXNET_EXPORT(bool)
  wxTaskBarIcon_IsIconInstalled(wxTaskBarIcon* self)
{
    return self->IsIconInstalled();
}

WXNET_EXPORT(bool)
  wxTaskBarIcon_SetIcon(wxTaskBarIcon* self, wxIcon* icon, wxString* tooltip)
{
    return self->SetIcon(*icon, *tooltip);
}

WXNET_EXPORT(bool)
  wxTaskBarIcon_RemoveIcon(wxTaskBarIcon* self)
{
	return self->RemoveIcon();
}

//-----------------------------------------------------------------------------


WXNET_EXPORT(bool)
  wxTaskBarIcon_PopupMenu(wxTaskBarIcon* self, wxMenu* menu)
{
	return self->PopupMenu(menu);
}








