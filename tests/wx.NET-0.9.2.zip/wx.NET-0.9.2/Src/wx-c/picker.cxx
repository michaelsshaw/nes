//-----------------------------------------------------------------------------
// wx.NET - picker.cxx
//
// Provides wrappers to some of wxWidget's picker controls.
//
// (C) 2008 by Harald Meyer auf'm Hofe
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: picker.cxx,v 1.4 2010/02/22 22:16:01 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include "wxnet_globals.h"
#include "local_events.h"

#include <wx/datectrl.h>
#include <wx/clrpicker.h>
#include <wx/fontpicker.h>

typedef void (CALLBACK* CBSetValue)(const wxDateTime* dt1);
typedef void (CALLBACK* CBGetValue)(wxDateTime*);

typedef void (CALLBACK* CBSetRange)(const wxDateTime* dt1, const wxDateTime* dt2);
typedef char (CALLBACK* CBGetRange)(wxDateTime *dt1, wxDateTime *dt2);


class _DatePickerCtrl : public wxDatePickerCtrl
{
public:
    _DatePickerCtrl() : _setValue(0), _getValue(0), _setRange(0), _getRange(0)
    {
    }

    _DatePickerCtrl(
                    wxWindow *parent,
                    wxWindowID id,
                    const wxDateTime& dt = wxDefaultDateTime,
                    const wxPoint& pos = wxDefaultPosition,
                    const wxSize& size = wxDefaultSize,
                    long style = wxDP_DEFAULT | wxDP_SHOWCENTURY,
                    const wxValidator& validator = wxDefaultValidator,
                    const wxString& name = wxDatePickerCtrlNameStr)
         : wxDatePickerCtrl(parent, id, dt, pos, size, style, validator, name),
           _setValue(0), _getValue(0), _setRange(0), _getRange(0)
    {
    }

    DECLARE_OBJECTDELETED(_DatePickerCtrl)

    CBSetValue _setValue;
    CBGetValue _getValue;
    CBSetRange _setRange;
    CBGetRange _getRange;

    void SetVirtuals(CBSetValue setValue, CBGetValue getValue, CBSetRange setRange, CBGetRange getRange)
    {
       this->_setValue=setValue;
       this->_getValue=getValue;
       this->_setRange=setRange;
       this->_getRange=getRange;
    }

    virtual void SetValue(const wxDateTime& dt)
    {
       if (this->_setValue)
       {
          (*_setValue)(&dt);
       }
       else
          wxDatePickerCtrl::SetValue(dt);
    }

    virtual wxDateTime GetValue() const
    {
       if (this->_getValue)
       {
          wxDateTime result;
          (*this->_getValue)(&result);
          return result;
       }
       else
          return wxDatePickerCtrl::GetValue();
    }

    // set/get the allowed valid range for the dates, if either/both of them
    // are invalid, there is no corresponding limit and if neither is set
    // GetRange() returns false
    virtual void SetRange(const wxDateTime& dt1, const wxDateTime& dt2)
    {
       if (this->_setRange)
       {
          (*this->_setRange)(&dt1, &dt2);
       }
       else
          wxDatePickerCtrl::SetRange(dt1, dt2);
    }
    virtual bool GetRange(wxDateTime *dt1, wxDateTime *dt2) const
    {
       if (this->_getRange)
       {
          return (*this->_getRange)(dt1, dt2)!=0;
       }
       else
          return wxDatePickerCtrl::GetRange(dt1, dt2);
    }

};


WXNET_EXPORT(_DatePickerCtrl*) wxDatePickerCtrl_DefaultCTor(void)
{
   return new _DatePickerCtrl();
}

WXNET_EXPORT(_DatePickerCtrl*) wxDatePickerCtrl_CTor(
                    wxWindow *parent,
                    wxWindowID id,
                    wxDateTime* dtArg,
                    int x, int y, int w, int h,
                    int style,
                    const wxString* nameArg)
{
   wxString name(wxDatePickerCtrlNameStr);
   if (nameArg)
      name=*nameArg;
   wxDateTime dt(wxDefaultDateTime);
   if (dtArg)
      dt=*dtArg;
   return new _DatePickerCtrl(parent, id, dt, wxPoint(x, y), wxSize(w, h), style, wxDefaultValidator, name);
}

WXNET_EXPORT(void) wxDatePickerCtrl_DTor(wxDatePickerCtrl* selfArg)
{
   _DatePickerCtrl* self = dynamic_cast<_DatePickerCtrl*>(selfArg);
   if (self)
   {
      WXNET_DEL(self);
   }
   else
   {
      WXNET_DEL(selfArg);
   }
}

WXNET_EXPORT(void) wxDatePickerCtrl_Create(
                    wxDatePickerCtrl* self,
                    wxWindow *parent,
                    int id,
                    wxDateTime* dtArg,
                    int x, int y, int w, int h,
                    int style,
                    const wxString* nameArg)
{
   if (self)
   {
      wxString name(wxDatePickerCtrlNameStr);
      if (nameArg)
         name=*nameArg;
      wxDateTime dt(wxDefaultDateTime);
      if (dtArg)
         dt=*dtArg;
      self->Create(parent, id, dt, wxPoint(x, y), wxSize(w, h), style, wxDefaultValidator, name);
   }
}

WXNET_EXPORT(void) wxDatePickerCtrl_SetValue(wxDatePickerCtrl* self, const wxDateTime* dt)
{
   if (self && dt)
      self->wxDatePickerCtrl::SetValue(*dt);
}

WXNET_EXPORT(wxDateTime*) wxDatePickerCtrl_GetValue(const wxDatePickerCtrl* self)
{
   if (self)
      return new wxDateTime(self->GetValue());
   else
      return 0;
}

WXNET_EXPORT(void) wxDatePickerCtrl_SetRange(wxDatePickerCtrl* self, const wxDateTime* dt1, const wxDateTime* dt2)
{
   if (self && dt1 && dt2)
      self->SetRange(*dt1, *dt2);
}

WXNET_EXPORT(char) wxDatePickerCtrl_GetRange(const wxDatePickerCtrl* self, wxDateTime *dt1, wxDateTime *dt2)
{
   if (self)
      return self->GetRange(dt1, dt2);
   else
      return false;
}

// _____________________________________________________________________________________

class _ColourPickerCtrl : public wxColourPickerCtrl
{
public:
    _ColourPickerCtrl()
    {
    }

    _ColourPickerCtrl(
                    wxWindow *parent,
                    wxWindowID id,
                    const wxColour& colour=*wxBLACK,
                    const wxPoint& pos = wxDefaultPosition,
                    const wxSize& size = wxDefaultSize,
                    long style = wxDP_DEFAULT | wxDP_SHOWCENTURY,
                    const wxValidator& validator = wxDefaultValidator,
                    const wxString& name = wxColourPickerCtrlNameStr)
         : wxColourPickerCtrl(parent, id, colour, pos, size, style, validator, name)
    {
    }

    DECLARE_OBJECTDELETED(_ColourPickerCtrl)
};

WXNET_EXPORT(_ColourPickerCtrl*) wxColourPickerCtrl_DefaultCTor(void)
{
   return new _ColourPickerCtrl();
}

WXNET_EXPORT(_ColourPickerCtrl*) wxColourPickerCtrl_CTor(wxWindow* parent, int id, const wxColour* colArg, int x, int y, int w, int h, int style, wxString* nameArg)
{
   wxString name(wxColourPickerCtrlNameStr);
   if (nameArg)
      name=*nameArg;
   wxColour col(*wxBLACK);
   if (colArg)
      col=*colArg;

   return new _ColourPickerCtrl(parent, id, col, wxPoint(x, y), wxSize(w, h), style, wxDefaultValidator, name);
}

WXNET_EXPORT(void) wxColourPickerCtrl_Create(wxColourPickerCtrl* self, wxWindow* parent, int id, const wxColour* colArg, int x, int y, int w, int h, int style, wxString* nameArg)
{
   wxString name(wxColourPickerCtrlNameStr);
   if (nameArg)
      name=*nameArg;
   wxColour col(*wxBLACK);
   if (colArg)
      col=*colArg;

   if (self)
      self->Create(parent, id, col, wxPoint(x, y), wxSize(w, h), style, wxDefaultValidator, name);
}

WXNET_EXPORT(wxColour*) wxColourPickerCtrl_GetColour(const wxColourPickerCtrl* self)
{
   if (self)
      return new wxColour(self->GetColour());
   else
      return NULL;
}

WXNET_EXPORT(void) wxColourPickerCtrl_SetColour(wxColourPickerCtrl* self, const wxColour* colour)
{
   if (self && colour)
      self->SetColour(*colour);
}

WXNET_EXPORT(void) wxColourPickerCtrl_SetColourFromString(wxColourPickerCtrl* self, const wxString* colour)
{
   if (self && colour)
      self->SetColour(*colour);
}

WXNET_EXPORT(wxColour*) wxColourPickerEvent_GetColour(wxColourPickerEvent* self)
{
   if (self)
      return new wxColour(self->GetColour());
   else
      return NULL;
}

WXNET_EXPORT(void) wxColourPickerEvent_SetColour(wxColourPickerEvent* self, const wxColour* colour)
{
   if (self && colour)
      self->SetColour(*colour);
}

// _____________________________________________________________________________________

class _FontPickerCtrl : public wxFontPickerCtrl
{
public:
    _FontPickerCtrl()
    {
    }

    _FontPickerCtrl(
                    wxWindow *parent,
                    wxWindowID id,
                    const wxFont& font=wxNullFont,
                    const wxPoint& pos = wxDefaultPosition,
                    const wxSize& size = wxDefaultSize,
                    long style = wxDP_DEFAULT | wxDP_SHOWCENTURY,
                    const wxValidator& validator = wxDefaultValidator,
                    const wxString& name = wxColourPickerCtrlNameStr)
         : wxFontPickerCtrl(parent, id, font, pos, size, style, validator, name)
    {
    }

    DECLARE_OBJECTDELETED(_FontPickerCtrl)
};

WXNET_EXPORT(_FontPickerCtrl*) wxFontPickerCtrl_DefaultCTor(void)
{
   return new _FontPickerCtrl();
}

WXNET_EXPORT(_FontPickerCtrl*) wxFontPickerCtrl_CTor(wxWindow* parent, int id, const wxFont* fontArg, int x, int y, int w, int h, int style, wxString* nameArg)
{
   wxString name(wxFontPickerCtrlNameStr);
   if (nameArg)
      name=*nameArg;
   wxFont font;
   if (fontArg)
      font=*fontArg;

   return new _FontPickerCtrl(parent, id, font, wxPoint(x, y), wxSize(w, h), style, wxDefaultValidator, name);
}

WXNET_EXPORT(void) wxFontPickerCtrl_Create(wxFontPickerCtrl* self, wxWindow* parent, int id, const wxFont* fontArg, int x, int y, int w, int h, int style, wxString* nameArg)
{
   wxString name(wxFontPickerCtrlNameStr);
   if (nameArg)
      name=*nameArg;
   wxFont font;
   if (fontArg)
      font=*fontArg;

   if (self)
      self->Create(parent, id, font, wxPoint(x, y), wxSize(w, h), style, wxDefaultValidator, name);
}

WXNET_EXPORT(wxFont*) wxFontPickerCtrl_GetSelectedFont(const wxFontPickerCtrl* self)
{
   if (self)
      return new wxFont(self->GetSelectedFont());
   else
      return NULL;
}

WXNET_EXPORT(void) wxFontPickerCtrl_SetSelectedFont(wxFontPickerCtrl* self, const wxFont* font)
{
   if (self && font)
      self->SetSelectedFont(*font);
}

WXNET_EXPORT(void) wxFontPickerCtrl_SetMaxPointSize(wxFontPickerCtrl* self, int maxPointSize)
{
   if (self)
      self->SetMaxPointSize((unsigned int) maxPointSize);
}

WXNET_EXPORT(int) wxFontPickerCtrl_GetMaxPointSize(const wxFontPickerCtrl* self)
{
   if (self)
      return self->GetMaxPointSize();
   else
      return 0;
}

// _____________________________________________________________________________________

WXNET_EXPORT(wxFont*) wxFontPickerEvent_GetFont(const wxFontPickerEvent* self)
{
   if (self)
      return new wxFont(self->GetFont());
   else
      return NULL;
}

WXNET_EXPORT(void) wxFontPickerEvent_SetFont(wxFontPickerEvent* self, const wxFont* font)
{
   if (self && font)
      self->SetFont(*font);
}

// _____________________________________________________________________________________
// wxPickerBase

WXNET_EXPORT(void) wxPickerBase_SetInternalMargin(wxPickerBase* self, int margin)
{
   if (self)
      self->SetInternalMargin(margin);
}

WXNET_EXPORT(int) wxPickerBase_GetInternalMargin(const wxPickerBase* self)
{
   if (self)
      return self->GetInternalMargin();
   else
      return 0;
}

WXNET_EXPORT(void) wxPickerBase_SetTextCtrlProportion(wxPickerBase* self, int prop)
{
   if (self)
      self->SetTextCtrlProportion(prop);
}

WXNET_EXPORT(void) wxPickerBase_SetPickerCtrlProportion(wxPickerBase* self, int prop)
{
   if (self)
      self->SetPickerCtrlProportion(prop);
}

WXNET_EXPORT(int) wxPickerBase_GetTextCtrlProportion(const wxPickerBase* self)
{
   if (self)
      return self->GetTextCtrlProportion();
   else
      return 0;
}

WXNET_EXPORT(int) wxPickerBase_GetPickerCtrlProportion(const wxPickerBase* self)
{
   if (self)
      return self->GetPickerCtrlProportion();
   else
      return 0;
}

WXNET_EXPORT(char) wxPickerBase_HasTextCtrl(const wxPickerBase* self)
{
   if (self)
      return self->HasTextCtrl();
   else
      return false;
}

WXNET_EXPORT(wxTextCtrl*) wxPickerBase_GetTextCtrl(wxPickerBase* self)
{
   if (self)
      return self->GetTextCtrl();
   else
      return NULL;
}

WXNET_EXPORT(char) wxPickerBase_IsTextCtrlGrowable(const wxPickerBase* self)
{
   if (self)
      return self->IsTextCtrlGrowable();
   else
      return false;
}

WXNET_EXPORT(void) wxPickerBase_SetPickerCtrlGrowable(wxPickerBase* self, char grow)
{
   if (self)
      self->SetPickerCtrlGrowable(grow!=0);
}

WXNET_EXPORT(void) wxPickerBase_SetTextCtrlGrowable(wxPickerBase* self, char grow)
{
   if (self)
      self->SetTextCtrlGrowable(grow!=0);
}

WXNET_EXPORT(char) wxPickerBase_IsPickerCtrlGrowable(const wxPickerBase* self)
{
   if (self)
      return self->IsPickerCtrlGrowable();
   else
      return false;
}

