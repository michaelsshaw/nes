//-----------------------------------------------------------------------------
// wx.NET - staticboxsizer.cxx
//
// The wxStaticBoxSizer proxy interface
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 by Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: staticboxsizer.cxx,v 1.6 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/sizer.h>
#ifndef WXNET_GLOBAL_H
#include "wxnet_globals.h"
#endif

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxStaticBoxSizer*)
  wxStaticBoxSizer_ctor(wxStaticBox *box, int orient)
{
	return new wxStaticBoxSizer(box, orient);
}

WXNET_EXPORT(wxStaticBoxSizer*)
  wxStaticBoxSizer_ctor2(int orient, wxWindow* parent, const wxString* label)
{
   wxString labelStr;
   if (label)
      labelStr=*label;
   return new wxStaticBoxSizer(orient, parent, labelStr);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxStaticBox*)
  wxStaticBoxSizer_GetStaticBox(wxStaticBoxSizer* self)
{
	return self->GetStaticBox();
}

//-----------------------------------------------------------------------------
