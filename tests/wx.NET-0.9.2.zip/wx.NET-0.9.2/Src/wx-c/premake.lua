-- Premake script for the wx.NET "wx-c" package.
-- See http://premake.sourceforge.net/ for more info about Premake.

package.name       = "wx-c"
package.language   = "c++"
package.kind       = "dll"

addoption("with-shared",   "Link wxWidgets as a shared library")
addoption("with-display",  "Builds wxDisplay class")
addoption("wx-config",     "Location of wx-config script (use PATH by default)")

addoption("wx-build-type", "wxWidgets build type (Debug|Release) (default from wx-config)")
addoption("wx-src-dir",    "wxWidgets source directory (win32 only)")

package.defines    = { "WXMAKINGDLL" }
package.buildflags = { "no-64bit-checks", "no-import-lib" }

-- The wxWidgets version we are building against; hard coded for now
WX_VERSION = 2.8
-- alternative values. 2.5 2.6 2.8

-- Define simple boolean variables for our platform
linux = (OS == "linux")
mac   = (OS == "macosx")
win   = (OS == "windows")

-- Define simple boolean variables for our Lua version
lua5_or_higher = (string) -- string is used by lua 5.x so check if it exists

-- This is brain dead; Lua has no concept of looking in the same directory that
-- the parent script is locatted when including another file; so because this
-- file is read from ../.. we hard code in the parent path. Uggg! Also call
-- from current directory just in case.

print(_VERSION)  -- used to help me debug

if lua5_or_higher then 
	-- the compat.lua is a file used to use some lua 4.x code under 5.x
	local compatfile = loadfile ("Src/wx-c/compat.lua")
	if not compatfile then
	  compatfile = assert(loadfile ("compat.lua")) 
	end
	assert(compatfile) -- This should always be a valid value
	compatfile ()
end  

-- Define the wxWidgets build type; necessary because WIN32 does not have
-- wx-config and the contrib packages are not supported by wx-config. But we
-- have the built-in support for different CONFIG types you say? But this
-- requires that the wxWidgets and wx.NET release types are in sync, which can
-- be a pain when you just want a Debug version of wx.NET and do not want to
-- compile a Debug version of wxWidgets.
if (options["wx-build-type"]) then
   if lua5_or_higher then
      wx_build_type = options["wx-build-type"]
   else
      wx_build_type = options["wx-build-type"][1]
   end   
   if (wx_build_type == "Debug") then
      wx_force_debug   = 1
      wx_debug_flag    = "d"
      wx_release_flag  = "d"
      wx_debug         = "Debug"
      wx_release       = "Debug"
   elseif (wx_build_type == "Release") then
      wx_force_release = 1
      wx_debug_flag    = ""
      wx_release_flag  = ""
      wx_debug         = "Release"
      wx_release       = "Release"
   end
else
   wx_debug_flag = "d"
   wx_release_flag = ""
   wx_debug = "Debug"
   wx_release = "Release"
end

-- UN*X options
if (linux or mac) then
    -- Use hard coded wx-config or use whatever is in PATH?
    if (options["wx-config"]) then
        if lua5_or_higher then -- Lua 5.x or above
            wxconfig = options["wx-config"]
        else
            wxconfig = options["wx-config"][1]
        end            
    else
        wxconfig = "wx-config"
    end

    if (options["with-shared"]) then
        buildoptions = "$(shell " .. wxconfig .. " --cxxflags)"
        linkoptions  = "$(shell " .. wxconfig .. " --libs)"
    else
        buildoptions = "$(shell " .. wxconfig .. " --static --cxxflags)"
        linkoptions  = "$(shell " .. wxconfig .. " --static --libs)"
    end

    buildoptions = buildoptions .. " -W -Wall -ansi"

    -- Mac options
    if (mac) then
       -- Premake 2.0 supports .dylib output now
       tinsert(package.buildflags, "dylib")
       linkoptions = linkoptions .. " -single_module"
    end

    package.buildoptions = { buildoptions }
    package.linkoptions  = { linkoptions }
end

-- WIN32 options
if (win) then
    tinsert(package.defines, { "WIN32", "_WINDOWS", "WINVER=0x400", "_MT",
                               "wxUSE_GUI=1" })
    tinsert(package.links,   { "kernel32", "user32", "gdi32", "shell32",
                               "comdlg32", "advapi32", "ole32", "comctl32",
                               "rpcrt4", "wsock32" })

    package.config["Debug"].defines   = { "_DEBUG", "__WXDEBUG", "WXDEBUG=1" }
    package.config["Release"].defines = { "NDEBUG" }
  
    if (options["with-shared"]) then
        tinsert(package.defines, "WXUSINGDLL")
    end

    if (options["wx-src-dir"]) then
        if lua5_or_higher then -- Lua 5.x or above
            wx_src = options["wx-src-dir"]
        else
            wx_src = options["wx-src-dir"][1]
        end    
        if (options["target"]) then
		        if lua5_or_higher then -- Lua 5.x or above
		            premake_target = options["target"]
		        else
		            premake_target = options["target"][1]
		        end
            print(premake_target)
        end 
        if (("cb-gcc" == premake_target) or ("gnu" == premake_target)) then
	        -- Include paths
	        package.config["Debug"].includepaths = 
	           { wx_src .. "/include", wx_src .. "/contrib/include", 
	             wx_src .. "/lib/gcc_lib/msw" .. wx_debug_flag }
	        package.config["Release"].includepaths = 
	           { wx_src .. "/include", wx_src .. "/contrib/include",
	             wx_src .. "/lib/gcc_lib/msw" .. wx_release_flag }
	
	        -- Linker paths
	        package.libpaths = { wx_src .. "/lib/gcc_lib" }
        else -- default to visual studio settings  
	        -- Include paths
	        package.config["Debug"].includepaths = 
	           { wx_src .. "/include", wx_src .. "/contrib/include", 
	             wx_src .. "/lib/vc_lib/msw" .. wx_debug_flag }
	        package.config["Release"].includepaths = 
	           { wx_src .. "/include", wx_src .. "/contrib/include",
	             wx_src .. "/lib/vc_lib/msw" .. wx_release_flag }
	
	        -- Linker paths
	        package.libpaths = { wx_src .. "/lib/vc_lib" }
	      end  

        -- TODO: add resource include path when supported by premake
    end
    
    -- HMaH: better use the functions here, but I never worked with LUA and PREBUILD.
    if (WX_VERSION == 2.6) then
          wx_links_debug = {
             "wxbase26d", "wxbase26d_xml", "wxexpatd", "wxjpegd", "wxmsw26d_adv",
             "wxmsw26d_core", "wxmsw26d_html", "wxpngd", "wxregexd", "wxtiffd",
              "wxzlibd", "wxmsw26d_xrc" }
          wx_links_release = {
             "wxbase26", "wxbase26_xml", "wxexpat", "wxjpeg", "wxmsw26_adv",
             "wxmsw26_core", "wxmsw26_html", "wxpng", "wxregex", "wxtiff", "wxzlib",
             "wxmsw26_xrc" }
    else -- assume (currently) version 2.8 by default
          wx_links_debug = {
             "wxbase28d", "wxbase28d_xml", "wxexpatd", "wxjpegd", "wxmsw28d_adv",
             "wxmsw28d_core", "wxmsw28d_html", "wxpngd", "wxregexd", "wxtiffd",
              "wxzlibd", "wxmsw28d_xrc" }
          wx_links_release = {
             "wxbase28u", "wxbase28u_xml", "wxexpat", "wxjpeg", "wxmsw28u_adv",
             "wxmsw28u_core", "wxmsw28u_html", "wxpng", "wxregexu", "wxtiff",
              "wxzlib", "wxmsw28_xrc" }
    end

    if (wx_force_debug) then
       wx_links_release = wx_links_debug
    end
    if (wx_force_release) then
       wx_links_debug = wx_links_release
    end

    package.config["Release"].links = wx_links_release
    package.config["Debug"].links   = wx_links_debug
end

-----------------------------------------------------------------------

package.files = { matchfiles("*.cxx") }

if (win) then
    tinsert(package.files, "windows.rc")
end

-----------------------------------------------------------------------

if (options["with-display"]) then
    tinsert(package.defines, "WXNET_DISPLAY")
end

-- This is brain dead; Lua has no concept of looking in the same directory that
-- the parent script is locatted when including another file; so because this
-- file is read from ../.. we hard code in the parent path. Uggg! Also call
-- from current directory just in case.

if lua5_or_higher then -- Lua 5.x or above
		local premake_funcs = loadfile ("Src/wx-c/premake-funcs.lua")
		if not premake_funcs then
		  premake_funcs = assert(loadfile ("premake-funcs.lua")) 
		end
		assert(premake_funcs) -- This should always be a valid value
		premake_funcs ()
else
    dofile("Src/wx-c/premake-funcs.lua")
    dofile("premake-funcs.lua")
end		 

-- StyledTextControl (STC)
if (options["enable-stc"]) then
    tinsert(package.defines, { "WXNET_STYLEDTEXTCTRL", "WXMAKINGDLL_STC" })
    add_contrib_link("stc")
end

