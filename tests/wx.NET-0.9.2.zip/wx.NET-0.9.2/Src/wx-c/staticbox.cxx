//-----------------------------------------------------------------------------
// wx.NET - staticbox.cxx
//
// The wxStaticBox proxy interface
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 by Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: staticbox.cxx,v 1.7 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/statbox.h>
#include "local_events.h"

//-----------------------------------------------------------------------------

class _StaticBox : public wxStaticBox
{
public:
    DECLARE_OBJECTDELETED(_StaticBox)
};

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxStaticBox*)
  wxStaticBox_ctor()
{
    return new _StaticBox();
}

WXNET_EXPORT(void)
  wxStaticBox_dtor(wxStaticBox* self)
{
    delete self;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxStaticBox_Create(wxStaticBox* self, wxWindow* parent, wxWindowID id,
                        const wxString* labelArg,
                        int posX, int posY, int width, int height,
                        long style, const wxString* nameArg)
{
    wxString name;
    if (nameArg == NULL)
        name = wxT("staticBox");
    else
       name=*nameArg;
    wxString label;
    if (labelArg)
       label=*labelArg;

    return self->Create(parent, id, label,
                        wxPoint(posX, posY), wxSize(width, height), style, name);
}

//-----------------------------------------------------------------------------
