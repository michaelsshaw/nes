//-----------------------------------------------------------------------------
// wx.NET - control.cxx
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: control.cxx,v 1.9 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/control.h>
#ifndef WXNET_GLOBAL_H
#include "wxnet_globals.h"
#endif

//-----------------------------------------------------------------------------
// C stubs for class methods

WXNET_EXPORT(void)
  wxControl_Command(wxControl *self, wxCommandEvent *event)
{
	self->Command(*event);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxControl_SetLabel(wxControl *self, const wxString* label)
{
   if (self && label)
	   self->SetLabel(*label);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxControl_GetLabel(wxControl *self)
{
	return new wxString(self->GetLabel());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxControl_GetAlignment(wxControl* self)
{
	return self->GetAlignment();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxControl_SetFont(wxControl* self, wxFont* font)
{
	return self->SetFont(*font)?1:0;
}

