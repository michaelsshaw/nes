//-----------------------------------------------------------------------------
// wx.NET - statbmp.cxx
//
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: staticbitmap.cxx,v 1.11 2010/01/01 16:55:10 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/statbmp.h>
#include "local_events.h"

//-----------------------------------------------------------------------------

class _StaticBitmap : public wxStaticBitmap
{
public:
    DECLARE_OBJECTDELETED(_StaticBitmap)
};

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxStaticBitmap*)
  wxStaticBitmap_ctor()
{
	return new _StaticBitmap();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxStaticBitmap_Create(wxStaticBitmap* self, wxWindow *parent, wxWindowID id, const wxBitmap *bitmap, int posX, int posY, int width, int height, unsigned int style, const wxString* nameArg)
{
   wxString name;
	if (nameArg == NULL)
		name = wxT("staticbitmap");
   else
      name=*nameArg;



   if (bitmap)
	return self->Create(parent, id, *bitmap, wxPoint(posX, posY), wxSize(width, height), style, name);
   else
	return self->Create(parent, id, wxNullBitmap, wxPoint(posX, posY), wxSize(width, height), style, name);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStaticBitmap_dtor(wxStaticBitmap* self)
{
	delete self;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStaticBitmap_SetIcon(wxStaticBitmap* self, const wxIcon* icon)
{
	self->SetIcon(*icon);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxStaticBitmap_SetBitmap(wxStaticBitmap* self, const wxBitmap* bitmap)
{
	self->SetBitmap(*bitmap);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxBitmap*)
  wxStaticBitmap_GetBitmap(wxStaticBitmap* self)
{
	return new wxBitmap(self->GetBitmap());
}

