//-----------------------------------------------------------------------------
// wx.NET - image.cxx
//
// The wxImage proxy interface.
//
// Written by Jason Perkins (jason@379.com)
// (C) 2003 by 379, Inc.
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: imagelist.cxx,v 1.7 2009/10/11 16:23:29 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/imaglist.h>
#ifndef WXNET_GLOBAL_H
#include "wxnet_globals.h"
#endif

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxImageList*)
  wxImageList_ctor(int width, int height, bool mask, int initialCount)
{
	return new wxImageList(width, height, mask, initialCount);
}

WXNET_EXPORT(wxImageList*)
  wxImageList_ctor2()
{
	return new wxImageList();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxImageList_AddBitmap1(wxImageList* self, const wxBitmap* bmp, const wxBitmap* mask)
{
	if (mask == NULL)
		mask = &wxNullBitmap;

	return self->Add(*bmp, *mask);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxImageList_AddBitmap(wxImageList* self, const wxBitmap* bmp, const wxColour* maskColour)
{
	return self->Add(*bmp, *maskColour);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxImageList_AddIcon(wxImageList* self, const wxIcon* icon)
{
	return self->Add(*icon);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxImageList_GetImageCount(wxImageList* self)
{
	return self->GetImageCount();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxImageList_Draw(wxImageList* self, int index, wxDC* dc, int x, int y, int flags, bool solidBackground)
{
	return self->Draw(index, *dc, x, y, flags, solidBackground)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxImageList_Create(wxImageList* self, int width, int height, bool mask, int initialCount)
{
	return self->Create(width, height, mask, initialCount)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxImageList_Replace(wxImageList* self, int index, const wxBitmap* bitmap)
{
	return self->Replace(index, *bitmap)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxImageList_Remove(wxImageList* self, int index)
{
	return self->Remove(index)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxImageList_RemoveAll(wxImageList* self)
{
	return self->RemoveAll()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(const wxBitmap*) wxImageList_GetBitmap(wxImageList* self, int index)
{
	return WXNET_NEW( wxBitmap, (self->GetBitmap(index)));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxImageList_GetSize(wxImageList* self, int index, int* width, int* height)
{
	return self->GetSize(index, *width, *height)?1:0;
}


