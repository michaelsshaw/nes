//-----------------------------------------------------------------------------
// wx.NET - listbook.cxx
//
// The wxListbook proxy interface.
//
// Written by Alexander Olk (xenomorph2@onlinehome.de)
// (C) 2004 by Alexander Olk
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: listbook.cxx,v 1.6 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/listbook.h>
#include "local_events.h"

//-----------------------------------------------------------------------------

class _Listbook : public wxListbook
{
public:
    DECLARE_OBJECTDELETED(_Listbook)
};

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxListbook*)
  wxListbook_ctor()
{
	return new _Listbook();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxListbook_Create(wxListbook *self, wxWindow* parent, wxWindowID id, int x, int y, int width, unsigned int height, int style, const wxString* nameArg)
{
   wxString name;
	if (nameArg == NULL)
		name = wxT("listbook");
   else
      name=*nameArg;

	return self->Create(parent, id, wxPoint(x, y), wxSize(width, height), style, name);
}
//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxListbook_GetSelection(wxListbook* self)
{
	return self->GetSelection();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxListbook_SetPageText(wxListbook* self, size_t n, const wxString* strText)
{
   if (self && strText)
	   return self->SetPageText(n, *strText);
   else
      return false;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxListbook_GetPageText(wxListbook* self, size_t n)
{
	return new wxString(self->GetPageText(n));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxListbook_GetPageImage(wxListbook* self, size_t n)
{
	return self->GetPageImage(n);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxListbook_SetPageImage(wxListbook* self, size_t n, int imageId)
{
	return self->SetPageImage(n, imageId)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxListbook_CalcSizeFromPage(wxListbook* self, int widthPage, int heightPage, int* outWidth, int* outHeight)
{
   if (self)
   {
      wxSize result=self->CalcSizeFromPage(wxSize(widthPage, heightPage));
      if (outWidth)
         *outWidth=result.GetWidth();
      if (outHeight)
         *outHeight=result.GetHeight();
   }
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxListbook_InsertPage(wxListbook* self, size_t n, wxWindow* page, const wxString* text, bool bSelect, int imageId)
{
   if (self && text)
	   return self->InsertPage(n, page, *text, bSelect, imageId);
   return false;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxListbook_SetSelection(wxListbook* self, size_t n)
{
	return self->SetSelection(n);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxListbook_SetImageList(wxListbook* self, wxImageList* imageList)
{
	self->SetImageList(imageList);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxListbook_IsVertical(wxListbook* self)
{
	return self->IsVertical()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxListbook_GetPageCount(wxListbook* self)
{
	return self->GetPageCount();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxWindow*)
  wxListbook_GetPage(wxListbook* self, size_t n)
{
	return self->GetPage(n);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxListbook_AssignImageList(wxListbook* self, wxImageList* imageList)
{
	self->AssignImageList(imageList);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxImageList*)
  wxListbook_GetImageList(wxListbook* self)
{
	return self->GetImageList();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxListbook_SetPageSize(wxListbook* self, const wxSize* size)
{
	self->SetPageSize(*size);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxListbook_DeletePage(wxListbook* self, int nPage)
{
	return self->DeletePage(nPage)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxListbook_RemovePage(wxListbook* self, int nPage)
{
	return self->RemovePage(nPage)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxListbook_DeleteAllPages(wxListbook* self)
{
	return self->DeleteAllPages()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxListbook_AddPage(wxListbook* self, wxWindow* page, const wxString* text, bool bselect, int imageId)
{
   if (self && text)
	   return self->AddPage(page, *text, bselect, imageId);
   return false;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxListbook_AdvanceSelection(wxListbook* self, bool forward)
{
	self->AdvanceSelection(forward);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxListbookEvent*)
  wxListbookEvent_ctor(wxEventType commandType, int id, int nSel, int nOldSel)
{
    return new wxListbookEvent(commandType, id, nSel, nOldSel);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxListbookEvent_GetSelection(wxListbookEvent* self)
{
    return self->GetSelection();
}

WXNET_EXPORT(void)
  wxListbookEvent_SetSelection(wxListbookEvent* self, int nSel)
{
    self->SetSelection(nSel);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxListbookEvent_GetOldSelection(wxListbookEvent* self)
{
    return self->GetOldSelection();
}

WXNET_EXPORT(void)
  wxListbookEvent_SetOldSelection(wxListbookEvent* self, int nOldSel)
{
    self->SetOldSelection(nOldSel);
}

WXNET_EXPORT(void)
  wxListbookEvent_Veto(wxListbookEvent* self)
{
    self->Veto();
}

WXNET_EXPORT(void)
  wxListbookEvent_Allow(wxListbookEvent* self)
{
    self->Allow();
}

WXNET_EXPORT(char)
  wxListbookEvent_IsAllowed(wxListbookEvent* self)
{
    return self->IsAllowed()?1:0;
}

