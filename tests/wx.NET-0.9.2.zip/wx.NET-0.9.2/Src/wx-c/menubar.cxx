//-----------------------------------------------------------------------------
// wx.NET - menubar.cxx
//
// The wxMenuBar proxy interface.
//
// Written by Jason Perkins (jason@379.com)
// (C) 2003 by 379, Inc.
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: menubar.cxx,v 1.14 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include "local_events.h"

//-----------------------------------------------------------------------------

class _MenuBar : public wxMenuBar
{
public:
    _MenuBar()
    	: wxMenuBar() {}
	
    _MenuBar(long style)
    	: wxMenuBar(style) {}
	
    DECLARE_OBJECTDELETED(_MenuBar)
};

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxMenuBar*)
  wxMenuBar_ctor()
{
	return new _MenuBar();
}

WXNET_EXPORT(wxMenuBar*)
  wxMenuBar_ctor2(int style)
{
	return new _MenuBar(style);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxMenuBar_Append(wxMenuBar* self, wxMenu* menu, const wxString* title)
{
   if (self && title)
	   return self->Append(menu, *title);
   else
      return false;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxMenuBar_Check(wxMenuBar* self, int id, bool check)
{
	self->Check(id, check);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxMenuBar_IsChecked(wxMenuBar* self, int id)
{
	return self->IsChecked(id)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxMenuBar_Insert(wxMenuBar* self, int pos, wxMenu* menu, const wxString* title)
{
   if (self && title)
      return self->Insert(pos, menu, *title);
   else
      return false;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxMenuItem*)
  wxMenuBar_FindItem(wxMenuBar* self, int id, wxMenu **menu)
{
    return self->FindItem(id, menu);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(size_t)
  wxMenuBar_GetMenuCount(wxMenuBar* self)
{
	return self->GetMenuCount();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxMenu*)
  wxMenuBar_GetMenu(wxMenuBar* self, size_t pos)
{
	return self->GetMenu(pos);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxMenu*)
  wxMenuBar_Replace(wxMenuBar* self, int pos, wxMenu* menu, const wxString* title)
{
   if (self && title)
	   return self->Replace(pos, menu, *title);
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxMenu*)
  wxMenuBar_Remove(wxMenuBar* self, int pos)
{
	return self->Remove(pos);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxMenuBar_EnableTop(wxMenuBar* self, int pos, bool enable)
{
	self->EnableTop(pos, enable);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxMenuBar_Enable(wxMenuBar* self, int id, const bool enable)
{
	self->Enable(id, enable);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxMenuBar_FindMenu(wxMenuBar* self, const wxString* title)
{
   if (self && title)
	   return self->FindMenu(*title);
   else
      return wxNOT_FOUND;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxMenuBar_FindMenuItem(wxMenuBar* self, const wxString* menustring, const wxString* itemString)
{
   if (self && menustring && itemString)
	   return self->FindMenuItem(*menustring, *itemString);
   else
      return wxNOT_FOUND;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxMenuBar_GetHelpString(wxMenuBar* self, int id)
{
	return new wxString(self->GetHelpString(id));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxMenuBar_GetLabel(wxMenuBar* self, int id)
{
	return new wxString(self->GetLabel(id));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxMenuBar_GetLabelTop(wxMenuBar* self, int pos)
{
	return new wxString(self->GetLabelTop(pos));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxMenuBar_IsEnabled(wxMenuBar* self, int id)
{
	return self->IsEnabled(id)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxMenuBar_Refresh(wxMenuBar* self)
{
	self->Refresh();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxMenuBar_SetHelpString(wxMenuBar* self, int id, const wxString* helpstring)
{
   if (self && helpstring)
	   self->SetHelpString(id, *helpstring);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxMenuBar_SetLabel(wxMenuBar* self, int id, const wxString* label)
{
   if (self && label)
	   self->SetLabel(id, *label);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxMenuBar_SetLabelTop(wxMenuBar* self, int pos, const wxString* label)
{
   if (self && label)
	   self->SetLabelTop(pos, *label);
}
