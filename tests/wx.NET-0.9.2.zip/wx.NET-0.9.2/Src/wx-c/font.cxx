//-----------------------------------------------------------------------------
// wx.NET - font.cxx
//
// The wxFont proxy interface
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 by Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: font.cxx,v 1.16 2008/12/14 00:36:20 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/font.h>
#include "local_events.h"

//-----------------------------------------------------------------------------

#if wxCHECK_VERSION(2, 8, 0)

WXNET_EXPORT(const wxFont*)
  wxFont_NORMAL_FONT()	{ return wxNORMAL_FONT; }
WXNET_EXPORT(const wxFont*)
  wxFont_SMALL_FONT()	{ return wxSMALL_FONT; }
WXNET_EXPORT(const wxFont*)
  wxFont_ITALIC_FONT()	{ return wxITALIC_FONT; }
WXNET_EXPORT(const wxFont*)
  wxFont_SWISS_FONT()	{ return wxSWISS_FONT; }
#else
WXNET_EXPORT(wxFont*)
  wxFont_NORMAL_FONT()	{ return wxNORMAL_FONT; }
WXNET_EXPORT(wxFont*)
  wxFont_SMALL_FONT()		{ return wxSMALL_FONT; }
WXNET_EXPORT(wxFont*)
  wxFont_ITALIC_FONT()	{ return wxITALIC_FONT; }
WXNET_EXPORT(wxFont*)
  wxFont_SWISS_FONT()		{ return wxSWISS_FONT; }
#endif



//-----------------------------------------------------------------------------

WXNET_EXPORT(wxFont*)
  wxFont_ctorDef()
{
    return new wxFont();
}

WXNET_EXPORT(wxFont*)
  wxFont_ctor(int pointSize, int family, int style, int weight, const bool underline, const wxString *faceNameArg, wxFontEncoding encoding)
{
   wxString faceName;
	if (faceNameArg)
		faceName = *faceNameArg;

	return new wxFont(pointSize, family, style, weight, underline, faceName, encoding);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxFont_dtor(wxFont* self)
{
	WXNET_DEL(self);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxFont_Ok(wxFont* self)
{
	return self->Ok();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxFont_GetPointSize(wxFont* self)
{
	return self->GetPointSize();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxFont_GetFamily(wxFont* self)
{
	return self->GetFamily();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxFont_GetStyle(wxFont* self)
{
	return self->GetStyle();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxFont_GetWeight(wxFont* self)
{
	return self->GetWeight();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxFont_GetUnderlined(wxFont* self)
{
	return self->GetUnderlined();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxFont_GetFaceName(wxFont* self)
{
	return new wxString(self->GetFaceName());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxFontEncoding)
  wxFont_GetEncoding(wxFont* self)
{
	return self->GetEncoding();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(const wxNativeFontInfo*)
  wxFont_GetNativeFontInfo(wxFont* self)
{
	return self->GetNativeFontInfo();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxFont_IsFixedWidth(wxFont* self)
{
	return self->IsFixedWidth();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxFont_GetNativeFontInfoDesc(wxFont* self)
{
	return new wxString(self->GetNativeFontInfoDesc());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxFont_GetNativeFontInfoUserDesc(wxFont* self)
{
	return new wxString(self->GetNativeFontInfoUserDesc());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxFont_SetPointSize(wxFont* self, int pointSize)
{
   if (self)
	self->SetPointSize(pointSize);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxFont_SetFamily(wxFont* self, wxFontFamily  family)
{
   if (self)
	self->SetFamily(family);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxFont_Set(wxFont* self, const wxFont* src)
{
   if (self && src)
	   (*self)=(*src);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxFont_SetStyle(wxFont* self, int style)
{
   if (self)
	self->SetStyle(style);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxFont_SetWeight(wxFont* self, int weight)
{
   if (self)
	self->SetWeight(weight);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxFont_SetFaceName(wxFont* self, const wxString* faceName)
{
   if (self && faceName)
	   self->SetFaceName(*faceName);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxFont_SetUnderlined(wxFont* self, bool underlined)
{
   if (self)
	self->SetUnderlined(underlined);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxFont_SetEncoding(wxFont* self, wxFontEncoding encoding)
{
   if (self)
	self->SetEncoding(encoding);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxFont_SetNativeFontInfoUserDesc(wxFont* self, const wxString* info)
{
   if (self && info)
	   self->SetNativeFontInfoUserDesc(*info);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxFont_GetFamilyString(wxFont* self)
{
   if (self)
	return new wxString(self->GetFamilyString());
   else
      return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxFont_GetStyleString(wxFont* self)
{
	return new wxString(self->GetStyleString());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxFont_GetWeightString(wxFont* self)
{
	return new wxString(self->GetWeightString());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxFont_SetNoAntiAliasing(wxFont* self, bool no)
{
	self->SetNoAntiAliasing(no);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxFont_GetNoAntiAliasing(wxFont* self)
{
	return self->GetNoAntiAliasing();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxFontEncoding)
  wxFont_GetDefaultEncoding()
{
	return wxFont::GetDefaultEncoding();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxFont_SetDefaultEncoding(wxFontEncoding encoding)
{
	wxFont::SetDefaultEncoding(encoding);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxFont*)
  wxFont_New(const wxString * strNativeFontDesc)
{
   if (strNativeFontDesc)
	   return wxFont::New(*strNativeFontDesc);
   else
      return NULL;
}
