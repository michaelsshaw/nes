//-----------------------------------------------------------------------------
// wx.NET - frame.cxx
//
// The wxFrame proxy interface.
//
// Written by Jason Perkins (jason@379.com)
// (C) 2003 by 379, Inc.
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: frame.cxx,v 1.18 2009/10/11 16:23:29 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include "local_events.h"

//-----------------------------------------------------------------------------

class _Frame : public wxFrame, public ValidatorStub
{
public:
    DECLARE_OBJECTDELETED(_Frame)
    
#include "panel.inc"
};

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxFrame*)
 wxFrame_ctor()
{
    return new _Frame();
}

WXNET_EXPORT(char)
 wxFrame_Create(wxFrame* self, wxWindow* parent, int id, const wxString* titleArg, int posX, int posY, int width, int height, unsigned int style, const wxString* nameArg)
{
    wxString title;
    if (titleArg==NULL)
       title=wxT("Dialog");
    else
       title=*titleArg;
    wxString name;
    if (nameArg!=NULL)
      name=*nameArg;
    return self->Create(parent, id, title, wxPoint(posX, posY), wxSize(width, height), style, name)?1:0;
}


//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
 wxFrame_ShowFullScreen(wxFrame *self, bool show, unsigned int style) 
{
    if (self)
        return self->ShowFullScreen(show, style)?1:0;
    else
        return 0;
}

WXNET_EXPORT(char)
 wxFrame_IsFullScreen(wxFrame* self)
{
    if (self)
    return self->IsFullScreen()?1:0;
    else
        return false;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxStatusBar*)
 wxFrame_CreateStatusBar(wxFrame* self, int number, unsigned int style, wxWindowID id, const wxString* name)
{
   if (self && name)
    return self->CreateStatusBar(number, style, id, *name);
   return NULL;
}

WXNET_EXPORT(wxStatusBar*)
 wxFrame_GetStatusBar(wxFrame* self)
{
    if (self)
    return self->GetStatusBar();
    else
       return NULL;
}

WXNET_EXPORT(void)
 wxFrame_SetStatusBar(wxFrame* self, wxStatusBar* statusbar)
{
    if (self)
    self->SetStatusBar(statusbar);
}

WXNET_EXPORT(void)
 wxFrame_SetStatusBarPane(wxFrame* self, int n)
{
    if (self)
    self->SetStatusBarPane(n);
}

WXNET_EXPORT(int)
 wxFrame_GetStatusBarPane(wxFrame* self)
{
    if (self)
    return self->GetStatusBarPane();
    else
        return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
 wxFrame_SendSizeEvent(wxFrame* self)
{
    if (self)
    self->SendSizeEvent();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
 wxFrame_SetIcon(wxFrame* self, const wxIcon* icon)
{
    if (self && icon)
    self->SetIcon(*icon);
}

WXNET_EXPORT(wxIcon*)
 wxFrame_GetIcon(wxFrame* self)
{
    if (self)
        return new wxIcon(self->GetIcon());
    return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
 wxFrame_SetMenuBar(wxFrame* self, wxMenuBar* menuBar)
{
    if (self)
    self->SetMenuBar(menuBar);
}

WXNET_EXPORT(wxMenuBar*)
 wxFrame_GetMenuBar(wxFrame* self)
{
    if (self)
    return self->GetMenuBar();
    else
        return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
 wxFrame_SetStatusText(wxFrame* self, const wxString* text, int number)
{
   if (self && text)
    self->SetStatusText(*text, number);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxToolBar*)
 wxFrame_CreateToolBar(wxFrame* self, unsigned int style, wxWindowID id, const wxString* nameArg)
{
    wxString name;
    if (nameArg==NULL)
       name=wxT("toolBar");
    else
       name=*nameArg;

    return self->CreateToolBar(style, id, name);
}

WXNET_EXPORT(wxToolBar*) wxFrame_GetToolBar(wxFrame* self)
{
    if (self)
    return self->GetToolBar();
    else
        return NULL;
}

WXNET_EXPORT(void) wxFrame_SetToolBar(wxFrame* self, wxToolBar* toolbar)
{
    if (self)
    self->SetToolBar(toolbar);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
 wxFrame_Maximize(wxFrame* self, bool iconize)
{
    if (self)
    self->Maximize(iconize);
}

WXNET_EXPORT(char)
 wxFrame_IsMaximized(wxFrame* self)
{
    if (self)
    return self->IsMaximized()?1:0;
    else
        return 0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
 wxFrame_Iconize(wxFrame* self, bool iconize)
{
    if (self)
    self->Iconize(iconize);
}

WXNET_EXPORT(char) wxFrame_IsIconized(wxFrame* self)
{
    if (self)
    return self->IsIconized()?1:0;
    else
    return 0;
}

//-----------------------------------------------------------------------------

/*extern "C" WXNET_EXPORT
bool wxFrame_SetShape(wxFrame* self, wxRegion* region)
{
    return self->SetShape(region);
}*/

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
 wxFrame_SetStatusWidths(wxFrame* self, int n, int* widths)
{
    if (self)
    self->SetStatusWidths(n, widths);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
 wxFrame_GetClientAreaOrigin(wxFrame* self, wxPoint* pt)
{
    if (pt && self)
	*pt=self->GetClientAreaOrigin();
}

