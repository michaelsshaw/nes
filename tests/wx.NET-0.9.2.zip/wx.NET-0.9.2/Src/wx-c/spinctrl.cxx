//-----------------------------------------------------------------------------
// wx.NET - spinctl.cxx
//
// The wxSpinCtrl proxy interface
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 by Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: spinctrl.cxx,v 1.12 2010/06/06 08:54:23 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/spinctrl.h>
#include "local_events.h"

//-----------------------------------------------------------------------------

class _SpinCtrl : public wxSpinCtrl
{
public:
    DECLARE_OBJECTDELETED(_SpinCtrl)
};

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxSpinCtrl*)
  wxSpinCtrl_ctor()
{
	return new _SpinCtrl();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxSpinCtrl_Create(wxSpinCtrl* self, wxWindow *parent, wxWindowID id, const wxString* valueArg, int posX, int posY, int width, int height, unsigned int style, int min, int max, int initial, const wxString* nameArg)
{
   wxString value;
	if (valueArg)
		value = *valueArg;
   wxString name;
	if (nameArg == NULL)
		name = wxT("spinctrl");
   else
      name=*nameArg;

	return self->Create(parent, id, value, wxPoint(posX, posY), wxSize(width, height), style, min, max, initial, name);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxSpinCtrl_dtor(wxSpinCtrl* self)
{
	WXNET_DEL( self );
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxSpinCtrl_SetValue(wxSpinCtrl* self, int val)
{
	self->SetValue(val);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxSpinCtrl_SetValueStr(wxSpinCtrl* self, const wxString* text)
{
   if (self && text)
	   self->SetValue(*text);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxSpinCtrl_SetRange(wxSpinCtrl* self, int min, int max)
{
	self->SetRange(min, max);
}

//-----------------------------------------------------------------------------

#if 0
WXNET_EXPORT(void)
  wxSpinCtrl_SetSelection(wxSpinCtrl* self, int from, int to)
{
   if (self)
	self->SetSelection(from, to);
}
#endif

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxSpinCtrl_GetValue(wxSpinCtrl* self)
{
	return self->GetValue();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxSpinCtrl_GetMin(wxSpinCtrl* self)
{
	return self->GetMin();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxSpinCtrl_GetMax(wxSpinCtrl* self)
{
	return self->GetMax();
}
