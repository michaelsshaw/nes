//-----------------------------------------------------------------------------
// wx.NET - choice.cxx
//
// The wxChoice wrapper class.
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: choice.cxx,v 1.16 2008/12/25 17:01:35 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/choice.h>
#include "local_events.h"

//-----------------------------------------------------------------------------

class _Choice : public wxChoice 
{
public:
    DECLARE_OBJECTDELETED(_Choice)
};

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxChoice*)
  wxChoice_ctor()
{
    return new _Choice();
}

WXNET_EXPORT(char)
  wxChoice_Create(wxChoice* self, wxWindow* parent, int id, int x, int y,
                     int w, int h, const wxArrayString* choices,
                     int style, const wxValidator* validator,
                     const wxString* nameArg)
{
    if (validator == NULL)
        validator = &wxDefaultValidator;

    wxString name;
    if (nameArg == NULL)
        name = wxT("choice");
    else
       name=*nameArg;

    if (choices)
       return self->Create(parent, id, wxPoint(x,y), wxSize(w,h), *choices, style, *validator, name);
    else
       return self->Create(parent, id, wxPoint(x,y), wxSize(w,h), 0, NULL, style, *validator, name);
}

WXNET_EXPORT(void)
  wxChoice_dtor(wxChoice* self)
{
    WXNET_DEL(self);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxChoice_SetColumns(wxChoice* self, int n)
{
    self->SetColumns(n);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxChoice_GetColumns(const wxChoice* self)
{
    return self->GetColumns();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxChoice_Command(wxChoice* self, wxCommandEvent* evt)
{
   if (self && evt)
      self->Command(*evt);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(int)
  wxChoice_GetCurrentSelection(const wxChoice* self)
{
   if (self)
      return self->GetCurrentSelection();
   else
      return -1;
}
