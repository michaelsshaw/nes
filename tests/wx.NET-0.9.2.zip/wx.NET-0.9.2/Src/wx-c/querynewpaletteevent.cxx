//-----------------------------------------------------------------------------
// wx.NET - querynewpaletteevent.cxx
// 
// The wxQueryNewPaletteEvent proxy interface.
//
// Written by Alexander Olk (xenomorph2@onlinehome.de)
// (C) 2004 by Alexander Olk
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: querynewpaletteevent.cxx,v 1.3 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#ifndef WXNET_GLOBAL_H
#include "wxnet_globals.h"
#endif

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxQueryNewPaletteEvent*)
  wxQueryNewPaletteEvent_ctor(wxEventType type)
{
    return new wxQueryNewPaletteEvent(type);
}

WXNET_EXPORT(bool)
  wxQueryNewPaletteEvent_GetPaletteRealized(wxQueryNewPaletteEvent* self)
{
	return self->GetPaletteRealized()?1:0;
}

WXNET_EXPORT(void)
  wxQueryNewPaletteEvent_SetPaletteRelized(wxQueryNewPaletteEvent* self, bool realized)
{
	self->SetPaletteRealized(realized);
}
