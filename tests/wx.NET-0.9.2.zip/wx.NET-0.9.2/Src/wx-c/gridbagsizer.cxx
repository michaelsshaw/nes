//-----------------------------------------------------------------------------
// wx.NET - gridbagsizer.cxx
//
// The wxGridBagSizer proxy interface
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 by Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/gbsizer.h>
#ifndef WXNET_GLOBAL_H
#include "wxnet_globals.h"
#endif

//-----------------------------------------------------------------------------
// wxGBSizerItem

WXNET_EXPORT(wxGBSizerItem*)
  wxGBSizerItem_ctor(int width, int height, wxGBPosition* pos, wxGBSpan* span, int flag, int border, wxObject* userData)
{
    return new wxGBSizerItem(width, height, *pos, *span, flag, border, userData);
}

WXNET_EXPORT(wxGBSizerItem*)
  wxGBSizerItem_ctorWindow(wxWindow* window, wxGBPosition* pos, wxGBSpan* span, int flag, int border, wxObject* userData)
{
    return new wxGBSizerItem(window, *pos, *span, flag, border, userData);
}

WXNET_EXPORT(wxGBSizerItem*)
  wxGBSizerItem_ctorSizer(wxSizer* sizer, wxGBPosition* pos, wxGBSpan* span, int flag, int border, wxObject* userData)
{
    return new wxGBSizerItem(sizer, *pos, *span, flag, border, userData);
}

WXNET_EXPORT(wxGBSizerItem*)
  wxGBSizerItem_ctorDefault()
{
    return new wxGBSizerItem();
}

WXNET_EXPORT(wxGBPosition*)
  wxGBSizerItem_GetPos(wxGBSizerItem* self)
{
    return new wxGBPosition(self->GetPos());
}

WXNET_EXPORT(wxGBSpan*)
  wxGBSizerItem_GetSpan(wxGBSizerItem* self)
{
    return new wxGBSpan(self->GetSpan());
}

WXNET_EXPORT(char)
  wxGBSizerItem_SetPos(wxGBSizerItem* self, wxGBPosition* pos)
{
    return self->SetPos(*pos)?1:0;
}

WXNET_EXPORT(char)
  wxGBSizerItem_SetSpan(wxGBSizerItem* self, wxGBSpan* span)
{
    return self->SetSpan(*span)?1:0;
}

WXNET_EXPORT(char)
  wxGBSizerItem_IntersectsSizer(wxGBSizerItem* self, wxGBSizerItem* other)
{
    return self->Intersects(*other)?1:0;
}

WXNET_EXPORT(char)
  wxGBSizerItem_IntersectsSpan(wxGBSizerItem* self, wxGBPosition* pos, wxGBSpan* span)
{
    return self->Intersects(*pos, *span)?1:0;
}

WXNET_EXPORT(void)
  wxGBSizerItem_GetEndPos(wxGBSizerItem* self, int* row, int* col)
{
    self->GetEndPos(*row, *col);
}

WXNET_EXPORT(wxGridBagSizer*)
  wxGBSizerItem_GetGBSizer(wxGBSizerItem* self)
{
    return self->GetGBSizer();
}

WXNET_EXPORT(void)
  wxGBSizerItem_SetGBSizer(wxGBSizerItem* self, wxGridBagSizer* sizer)
{
    self->SetGBSizer(sizer);
}

//-----------------------------------------------------------------------------
// wxGBSpan

WXNET_EXPORT(wxGBSpan*)
  wxGBSpan_ctorDefault()
{
    return new wxGBSpan();
}

WXNET_EXPORT(wxGBSpan*)
  wxGBSpan_ctor(int rowspan, int colspan)
{
    return new wxGBSpan(rowspan, colspan);
}

WXNET_EXPORT(int)
  wxGBSpan_GetRowspan(wxGBSpan* self)
{
    return self->GetRowspan();
}

WXNET_EXPORT(int)
  wxGBSpan_GetColspan(wxGBSpan* self)
{
    return self->GetColspan();
}

WXNET_EXPORT(void)
  wxGBSpan_SetRowspan(wxGBSpan* self, int rowspan)
{
    self->SetRowspan(rowspan);
}

WXNET_EXPORT(void)
  wxGBSpan_SetColspan(wxGBSpan* self, int colspan)
{
    self->SetColspan(colspan);
}

//-----------------------------------------------------------------------------
// wxGridBagSizer

WXNET_EXPORT(wxGridBagSizer*)
  wxGridBagSizer_ctor(int vgap, int hgap)
{
    return new wxGridBagSizer(vgap, hgap);
}

WXNET_EXPORT(char)
  wxGridBagSizer_AddWindow(wxGridBagSizer* self, wxWindow* window, wxGBPosition* pos, wxGBSpan* span, int flag, int border, wxObject* userData)
{
    return self->Add(window, *pos, *span, flag, border, userData)?1:0;
}

WXNET_EXPORT(char)
  wxGridBagSizer_AddSizer(wxGridBagSizer* self, wxSizer* sizer, wxGBPosition* pos, wxGBSpan* span, int flag, int border, wxObject* userData)
{
    return self->Add(sizer, *pos, *span, flag, border, userData)?1:0;
}

WXNET_EXPORT(char)
  wxGridBagSizer_Add(wxGridBagSizer* self, int width, int height, wxGBPosition* pos, wxGBSpan* span, int flag, int border, wxObject* userData)
{
    return self->Add(width, height, *pos, *span, flag, border, userData)?1:0;
}

WXNET_EXPORT(char)
  wxGridBagSizer_AddItem(wxGridBagSizer* self, wxGBSizerItem* item)
{
    return self->Add(item)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxGridBagSizer_GetEmptyCellSize(wxGridBagSizer* self, wxSize* size)
{
    *size = self->GetEmptyCellSize();
}

WXNET_EXPORT(void)
  wxGridBagSizer_SetEmptyCellSize(wxGridBagSizer* self, wxSize* sz)
{
    self->SetEmptyCellSize(*sz);
}

WXNET_EXPORT(void)
  wxGridBagSizer_GetCellSize(wxGridBagSizer* self, int row, int col, wxSize* size)
{
    *size = self->GetCellSize(row, col);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxGBPosition*)
  wxGridBagSizer_GetItemPosition(wxGridBagSizer* self, wxWindow* window)
{
    return new wxGBPosition(self->GetItemPosition(window));
}

WXNET_EXPORT(wxGBPosition*)
  wxGridBagSizer_GetItemPositionSizer(wxGridBagSizer* self, wxSizer* sizer)
{
    return new wxGBPosition(self->GetItemPosition(sizer));
}

WXNET_EXPORT(wxGBPosition*)
  wxGridBagSizer_GetItemPositionIndex(wxGridBagSizer* self, int index)
{
    return new wxGBPosition(self->GetItemPosition(index));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGridBagSizer_SetItemPosition(wxGridBagSizer* self, wxWindow* window, wxGBPosition* pos)
{
    return self->SetItemPosition(window, *pos)?1:0;
}

WXNET_EXPORT(char)
  wxGridBagSizer_SetItemPositionSizer(wxGridBagSizer* self, wxSizer* sizer, wxGBPosition* pos)
{
    return self->SetItemPosition(sizer, *pos)?1:0;
}

WXNET_EXPORT(char)
  wxGridBagSizer_SetItemPositionIndex(wxGridBagSizer* self, int index, wxGBPosition* pos)
{
    return self->SetItemPosition(index, *pos)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxGBSpan*)
  wxGridBagSizer_GetItemSpan(wxGridBagSizer* self, wxWindow* window)
{
    return new wxGBSpan(self->GetItemSpan(window));
}

WXNET_EXPORT(wxGBSpan*)
  wxGridBagSizer_GetItemSpanSizer(wxGridBagSizer* self, wxSizer* sizer)
{
    return new wxGBSpan(self->GetItemSpan(sizer));
}

WXNET_EXPORT(wxGBSpan*)
  wxGridBagSizer_GetItemSpanIndex(wxGridBagSizer* self, int index)
{
    return new wxGBSpan(self->GetItemSpan(index));
}

WXNET_EXPORT(char)
  wxGridBagSizer_SetItemSpan(wxGridBagSizer* self, wxWindow* window, wxGBSpan* span)
{
    return self->SetItemSpan(window, *span)?1:0;
}

WXNET_EXPORT(char)
  wxGridBagSizer_SetItemSpanSizer(wxGridBagSizer* self, wxSizer* sizer, wxGBSpan* span)
{
    return self->SetItemSpan(sizer, *span)?1:0;
}

WXNET_EXPORT(char)
  wxGridBagSizer_SetItemSpanIndex(wxGridBagSizer* self, int index, wxGBSpan* span)
{
    return self->SetItemSpan(index, *span)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxGBSizerItem*)
  wxGridBagSizer_FindItem(wxGridBagSizer* self, wxWindow* window)
{
    return self->FindItem(window);
}

WXNET_EXPORT(wxGBSizerItem*)
  wxGridBagSizer_FindItemSizer(wxGridBagSizer* self, wxSizer* sizer)
{
    return self->FindItem(sizer);
}

WXNET_EXPORT(wxGBSizerItem*)
  wxGridBagSizer_FindItemAtPosition(wxGridBagSizer* self, wxGBPosition* pos)
{
    return self->FindItemAtPosition(*pos);
}

WXNET_EXPORT(wxGBSizerItem*)
  wxGridBagSizer_FindItemAtPoint(wxGridBagSizer* self, wxPoint* pt)
{
    return self->FindItemAtPoint(*pt);
}

WXNET_EXPORT(wxGBSizerItem*)
  wxGridBagSizer_FindItemWithData(wxGridBagSizer* self, wxObject* userData)
{
    return self->FindItemWithData(userData);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxGridBagSizer_CheckForIntersectionItem(wxGridBagSizer* self, wxGBSizerItem* item, wxGBSizerItem* excludeItem)
{
    return self->CheckForIntersection(item, excludeItem)?1:0;
}

WXNET_EXPORT(char)
  wxGridBagSizer_CheckForIntersectionPos(wxGridBagSizer* self, wxGBPosition* pos, wxGBSpan* span, wxGBSizerItem* excludeItem)
{
    return self->CheckForIntersection(*pos, *span, excludeItem)?1:0;
}

//-----------------------------------------------------------------------------
// wxGBPosition

WXNET_EXPORT(wxGBPosition*)
  wxGBPosition_ctor()
{
    return new wxGBPosition();
}

WXNET_EXPORT(wxGBPosition*)
  wxGBPosition_ctorPos(int row, int col)
{
    return new wxGBPosition(row, col);
}

WXNET_EXPORT(int)
  wxGBPosition_GetRow(wxGBPosition* self)
{
    return self->GetRow();
}

WXNET_EXPORT(int)
  wxGBPosition_GetCol(wxGBPosition* self)
{
    return self->GetCol();
}

WXNET_EXPORT(void)
  wxGBPosition_SetRow(wxGBPosition* self, int row)
{
    self->SetRow(row);
}

WXNET_EXPORT(void)
  wxGBPosition_SetCol(wxGBPosition* self, int col)
{
    self->SetCol(col);
}

//-----------------------------------------------------------------------------

