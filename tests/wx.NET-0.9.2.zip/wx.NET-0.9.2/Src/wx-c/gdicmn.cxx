//-----------------------------------------------------------------------------
// wx.NET - gdicmn.cxx
// 
// The GDI common classes proxy interface.
//
// Written by Alexander Olk (xenomorph2@onlinehome.de)
// (C) 2004 by Alexander Olk
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: gdicmn.cxx,v 1.12 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/gdicmn.h>
#include "local_events.h"

//-----------------------------------------------------------------------------

#if wxCHECK_VERSION(2, 8, 0)
WXNET_EXPORT(const wxPen*)
 wxGDIObj_GetRedPen()
#else
WXNET_EXPORT(wxPen*) wxGDIObj_GetRedPen()
#endif
{
	return wxRED_PEN;
}

#if wxCHECK_VERSION(2, 8, 0)
WXNET_EXPORT(const wxPen*) wxGDIObj_GetCyanPen()
#else
WXNET_EXPORT(wxPen*) wxGDIObj_GetCyanPen()
#endif
{
	return wxCYAN_PEN;
}

#if wxCHECK_VERSION(2, 8, 0)
WXNET_EXPORT(const wxPen*) wxGDIObj_GetGreenPen()
#else
WXNET_EXPORT(wxPen*) wxGDIObj_GetGreenPen()
#endif
{
	return wxGREEN_PEN;
}

#if wxCHECK_VERSION(2, 8, 0)
WXNET_EXPORT(const wxPen*) wxGDIObj_GetBlackPen()
#else
WXNET_EXPORT(wxPen*) wxGDIObj_GetBlackPen()
#endif
{
	return wxBLACK_PEN;
}

#if wxCHECK_VERSION(2, 8, 0)
WXNET_EXPORT(const wxPen*) wxGDIObj_GetWhitePen()
#else
WXNET_EXPORT(wxPen*) wxGDIObj_GetWhitePen()
#endif
{
	return wxWHITE_PEN;
}

#if wxCHECK_VERSION(2, 8, 0)
WXNET_EXPORT(const wxPen*) wxGDIObj_GetTransparentPen()
#else
WXNET_EXPORT(wxPen*) wxGDIObj_GetTransparentPen()
#endif
{
	return wxTRANSPARENT_PEN;
}

#if wxCHECK_VERSION(2, 8, 0)
WXNET_EXPORT(const wxPen*) wxGDIObj_GetBlackDashedPen()
#else
WXNET_EXPORT(wxPen*) wxGDIObj_GetBlackDashedPen()
#endif
{
	return wxBLACK_DASHED_PEN;
}

#if wxCHECK_VERSION(2, 8, 0)
WXNET_EXPORT(const wxPen*) wxGDIObj_GetGreyPen()
#else
WXNET_EXPORT(wxPen*) wxGDIObj_GetGreyPen()
#endif
{
	return wxGREY_PEN;
}

#if wxCHECK_VERSION(2, 8, 0)
WXNET_EXPORT(const wxPen*) wxGDIObj_GetMediumGreyPen()
#else
WXNET_EXPORT(wxPen*) wxGDIObj_GetMediumGreyPen()
#endif
{
	return wxMEDIUM_GREY_PEN;
}

#if wxCHECK_VERSION(2, 8, 0)
WXNET_EXPORT(const wxPen*) wxGDIObj_GetLightGreyPen()
#else
WXNET_EXPORT(wxPen*) wxGDIObj_GetLightGreyPen()
#endif
{
	return wxLIGHT_GREY_PEN;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxBitmap*)
  wxNullBitmap_Get()
{
	return new wxBitmap(wxNullBitmap);
}

WXNET_EXPORT(wxIcon*)
  wxNullIcon_Get()
{
	return new wxIcon(wxNullIcon);
}

WXNET_EXPORT(wxCursor*)
  wxNullCursor_Get()
{
	return new wxCursor(wxNullCursor);
}

WXNET_EXPORT(wxPen*)
  wxNullPen_Get()
{
	return new wxPen(wxNullPen);
}

WXNET_EXPORT(wxBrush*)
  wxNullBrush_Get()
{
	return new wxBrush(wxNullBrush);
}

WXNET_EXPORT(wxPalette*)
  wxNullPalette_Get()
{
	return new wxPalette(wxNullPalette);
}

WXNET_EXPORT(wxFont*)
  wxNullFont_Get()
{
	return new wxFont(wxNullFont);
}

WXNET_EXPORT(wxColour*)
  wxNullColour_Get()
{
	return new wxColour(wxNullColour);
}

//-----------------------------------------------------------------------------

#if wxCHECK_VERSION(2, 8, 0)
WXNET_EXPORT(const wxBrush*) wxBLUE_BRUSH_Get()
#else
WXNET_EXPORT(wxBrush*) wxBLUE_BRUSH_Get()
#endif
{
	return wxBLUE_BRUSH;
}

#if wxCHECK_VERSION(2, 8, 0)
WXNET_EXPORT(const wxBrush*) wxGREEN_BRUSH_Get()
#else
WXNET_EXPORT(wxBrush*) wxGREEN_BRUSH_Get()
#endif
{
	return wxGREEN_BRUSH;
}

#if wxCHECK_VERSION(2, 8, 0)
WXNET_EXPORT(const wxBrush*) wxWHITE_BRUSH_Get()
#else
WXNET_EXPORT(wxBrush*) wxWHITE_BRUSH_Get()
#endif
{
	return wxWHITE_BRUSH;
}

#if wxCHECK_VERSION(2, 8, 0)
WXNET_EXPORT(const wxBrush*) wxBLACK_BRUSH_Get()
#else
WXNET_EXPORT(wxBrush*) wxBLACK_BRUSH_Get()
#endif
{
	return wxBLACK_BRUSH;
}

#if wxCHECK_VERSION(2, 8, 0)
WXNET_EXPORT(const wxBrush*) wxGREY_BRUSH_Get()
#else
WXNET_EXPORT(wxBrush*) wxGREY_BRUSH_Get()
#endif
{
	return wxGREY_BRUSH;
}

#if wxCHECK_VERSION(2, 8, 0)
WXNET_EXPORT(const wxBrush*) wxMEDIUM_GREY_BRUSH_Get()
#else
WXNET_EXPORT(wxBrush*) wxMEDIUM_GREY_BRUSH_Get()
#endif
{
	return wxMEDIUM_GREY_BRUSH;
}

#if wxCHECK_VERSION(2, 8, 0)
WXNET_EXPORT(const wxBrush*) wxLIGHT_GREY_BRUSH_Get()
#else
WXNET_EXPORT(wxBrush*) wxLIGHT_GREY_BRUSH_Get()
#endif
{
	return wxLIGHT_GREY_BRUSH;
}

#if wxCHECK_VERSION(2, 8, 0)
WXNET_EXPORT(const wxBrush*) wxTRANSPARENT_BRUSH_Get()
#else
WXNET_EXPORT(wxBrush*) wxTRANSPARENT_BRUSH_Get()
#endif
{
	return wxTRANSPARENT_BRUSH;
}

#if wxCHECK_VERSION(2, 8, 0)
WXNET_EXPORT(const wxBrush*) wxCYAN_BRUSH_Get()
#else
WXNET_EXPORT(wxBrush*) wxCYAN_BRUSH_Get()
#endif
{
	return wxCYAN_BRUSH;
}

#if wxCHECK_VERSION(2, 8, 0)
WXNET_EXPORT(const wxBrush*) wxRED_BRUSH_Get()
#else
WXNET_EXPORT(wxBrush*) wxRED_BRUSH_Get()
#endif
{
	return wxRED_BRUSH;
}

//-----------------------------------------------------------------------------
// wxColourDataBase

WXNET_EXPORT(wxColourDatabase*)
  wxColourDatabase_ctor()
{
	return new wxColourDatabase();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxColourDataBase_dtor(wxColourDatabase* self)
{
	WXNET_DEL( self );
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxColour*)
  wxColourDatabase_Find(wxColourDatabase* self, const wxString* name)
{
   if (name)
	   return new wxColour(self->Find(*name));
   return NULL;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxColourDatabase_FindName(wxColourDatabase* self, wxColour* colour)
{
	return new wxString(self->FindName(*colour));
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxColourDatabase_AddColour(wxColourDatabase* self, const wxString* name, wxColour* colour)
{
   if (self && name && colour)
	   self->AddColour(*name, *colour);
}

//-----------------------------------------------------------------------------
// wxPenList

WXNET_EXPORT(wxPenList*)
  wxPenList_ctor()
{
	return new wxPenList();
}

//-----------------------------------------------------------------------------

// HMaH
WXNET_EXPORT(void)
  wxPenList_dtor(wxPenList* self)
{
	WXNET_DEL( self );
}

//-----------------------------------------------------------------------------
// HMaH
WXNET_EXPORT(wxPenList*)
  wxPenList_ThePenList(void)
{
    return wxThePenList;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxPen*)
  wxPenList_FindOrCreatePen(wxPenList* self, wxColour* colour, int width, int style)
{
	return self->FindOrCreatePen(*colour, width, style);
}

//-----------------------------------------------------------------------------
// wxBrushList

WXNET_EXPORT(wxBrushList*)
  wxBrushList_ctor()
{
	return new wxBrushList();
}

//-----------------------------------------------------------------------------

// HMaH
WXNET_EXPORT(void)
  wxBrushList_dtor(wxBrushList* self)
{
	WXNET_DEL( self );
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxBrush*)
  wxBrushList_FindOrCreateBrush(wxBrushList* self, wxColour* colour, int style)
{
	return self->FindOrCreateBrush(*colour, style);
}

//-----------------------------------------------------------------------------
// HMaH
WXNET_EXPORT(wxBrushList*)
  wxBrushList_TheBrushList(void)
{
    return wxTheBrushList;
}

//-----------------------------------------------------------------------------
// wxFontList

WXNET_EXPORT(wxFontList*)
  wxFontList_ctor()
{
	return new wxFontList();
}

// HMaH
WXNET_EXPORT(void)
  wxFontList_dtor(wxFontList* self)
{
	WXNET_DEL( self );
}

WXNET_EXPORT(wxFont*)
  wxFontList_FindOrCreateFont(wxFontList* self, int pointSize, int family, int style, int weight,
                             bool underline,
                             const wxString* face,
                             wxFontEncoding encoding)
{
   if (self && face)
	   return self->FindOrCreateFont(pointSize, family, style, weight, underline, *face, encoding);
   else
      return NULL;
}

// HMaH
WXNET_EXPORT(wxFontList*)
  wxFontList_TheFontList(void)
{
    return wxTheFontList;
}

//-----------------------------------------------------------------------------
// wxBitmapList was removed in wxWidgets 2.8.0

#if (!wxCHECK_VERSION(2, 8, 0))
WXNET_EXPORT(wxBitmapList*)
  wxBitmapList_ctor()
{
	return new wxBitmapList();
}
#endif

//-----------------------------------------------------------------------------

// HMaH
#if (!wxCHECK_VERSION(2, 8, 0))
WXNET_EXPORT(void)
  wxBitmapList_dtor(wxBitmapList* self)
{
	WXNET_DEL( self );
}
#endif

//-----------------------------------------------------------------------------

#if (!wxCHECK_VERSION(2, 8, 0))
WXNET_EXPORT(void)
  wxBitmapList_AddBitmap(wxBitmapList* self, wxBitmap* bitmap)
{
	self->AddBitmap(bitmap);
}
#endif

//-----------------------------------------------------------------------------

#if (!wxCHECK_VERSION(2, 8, 0))
WXNET_EXPORT(void)
  wxBitmapList_RemoveBitmap(wxBitmapList* self, wxBitmap* bitmap)
{
	self->RemoveBitmap(bitmap);
}
#endif

//-----------------------------------------------------------------------------
// Stock cursors types

#if wxCHECK_VERSION(2, 8, 0)
WXNET_EXPORT(const wxCursor*) wxSTANDARD_CURSOR_Get()
#else
WXNET_EXPORT(wxCursor*) wxSTANDARD_CURSOR_Get()
#endif
{
	return wxSTANDARD_CURSOR;
}

//-----------------------------------------------------------------------------

#if wxCHECK_VERSION(2, 8, 0)
WXNET_EXPORT(const wxCursor*) wxHOURGLASS_CURSOR_Get()
#else
WXNET_EXPORT(wxCursor*) wxHOURGLASS_CURSOR_Get()
#endif
{
	return wxHOURGLASS_CURSOR;
}

//-----------------------------------------------------------------------------

#if wxCHECK_VERSION(2, 8, 0)
WXNET_EXPORT(const wxCursor*) wxCROSS_CURSOR_Get()
#else
WXNET_EXPORT(wxCursor*) wxCROSS_CURSOR_Get()
#endif
{
	return wxCROSS_CURSOR;
}

