//-----------------------------------------------------------------------------
// wx.NET - eraseevent.cxx
// 
// The wxEraseEvent proxy interface.
//
// Written by Alexander Olk (xenomorph2@onlinehome.de)
// (C) 2004 by Alexander Olk
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: eraseevent.cxx,v 1.3 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#ifndef WXNET_GLOBAL_H
#include "wxnet_globals.h"
#endif

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxEraseEvent*)
  wxEraseEvent_ctor(wxEventType type)
{
    return new wxEraseEvent(type);
}

WXNET_EXPORT(wxDC*)
  wxEraseEvent_GetDC(wxEraseEvent* self)
{
	return self->GetDC();
}
