//-----------------------------------------------------------------------------
// wx.NET - printer.cxx
//
// The wxPrinter proxy interface.
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 by Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
// 
// $Id: printer.cxx,v 1.12 2008/12/11 23:55:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

#include <wx/wx.h>
#include <wx/print.h>
#include "local_events.h"

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxPrinter*)
  wxPrinter_ctor(wxPrintDialogData* data)
{
    return new wxPrinter(data);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxWindow*)
  wxPrinter_CreateAbortWindow(wxPrinter* self, wxWindow* parent, wxPrintout* printout)
{
    return self->CreateAbortWindow(parent, printout);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPrinter_ReportError(wxPrinter* self, wxWindow* parent, wxPrintout* printout, const wxString* message)
{
   if (self && message)
      self->ReportError(parent, printout, *message);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxPrintDialogData*)
  wxPrinter_GetPrintDialogData(wxPrinter* self)
{
    return &(self->GetPrintDialogData());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxPrinter_GetAbort(wxPrinter* self)
{
    return self->GetAbort();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxPrinterError)
  wxPrinter_GetLastError(wxPrinter* self)
{
    return self->GetLastError();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxPrinter_Setup(wxPrinter* self, wxWindow* parent)
{
    return self->Setup(parent);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(char)
  wxPrinter_Print(wxPrinter* self, wxWindow* parent, wxPrintout* printout, bool prompt)
{
    return self->Print(parent, printout, prompt);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxDC*)
  wxPrinter_PrintDialog(wxPrinter* self, wxWindow* parent)
{
    return self->PrintDialog(parent);
}

//-----------------------------------------------------------------------------

// Virtual method delegate pointer types
typedef void (CALLBACK* Virtual_NoParams)();
typedef bool (CALLBACK* Virtual_ParamsInt)(int);
typedef bool (CALLBACK* Virtual_OnBeginDocument)(int, int);
typedef void (CALLBACK* Virtual_GetPageInfo)(int*, int*, int*, int*);

class _Printout : public wxPrintout
{
public:
    _Printout(const wxString& title) 
        : wxPrintout(title) { }

    bool OnBeginDocument(int startPage, int endPage) { return m_onBeginDocument(startPage, endPage); }
    void OnEndDocument() { m_onEndDocument(); }
    void OnBeginPrinting() { m_onBeginPrinting(); }
    void OnEndPrinting() { m_onEndPrinting(); }
    void OnPreparePrinting() { m_onPreparePrinting(); }
    bool HasPage(int page) { return m_hasPage(page); }
    bool OnPrintPage(int pageNum) { return m_onPrintPage(pageNum); }
    void GetPageInfo(int *minPage, int *maxPage, int *pageFrom, int *pageTo)
        { m_getPageInfo(minPage, maxPage, pageFrom, pageTo); }

    void RegisterVirtual(Virtual_OnBeginDocument onBeginDocument,
                         Virtual_NoParams onEndDocument, 
                         Virtual_NoParams onBeginPrinting,
                         Virtual_NoParams onEndPrinting,
                         Virtual_NoParams onPreparePrinting, 
                         Virtual_ParamsInt hasPage,
                         Virtual_ParamsInt onPrintPage,
                         Virtual_GetPageInfo getPageInfo)
    {
        m_onBeginDocument   = onBeginDocument;

        m_onEndDocument     = onEndDocument;
        m_onBeginPrinting   = onBeginPrinting;
        m_onEndPrinting     = onEndPrinting;
        m_onPreparePrinting = onPreparePrinting;

        m_hasPage           = hasPage;
        m_onPrintPage       = onPrintPage;

        m_getPageInfo       = getPageInfo;
    }

private:
    Virtual_NoParams m_onEndDocument, m_onBeginPrinting,
                     m_onEndPrinting, m_onPreparePrinting;
    Virtual_ParamsInt m_hasPage, m_onPrintPage;
    Virtual_OnBeginDocument m_onBeginDocument;
    Virtual_GetPageInfo m_getPageInfo;
};

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxPrintout*)
  wxPrintout_ctor(const wxString* titleArg)
{
   wxString title;
   if (titleArg == NULL)
        title = wxT("Printout");
   else
      title=*titleArg;

    return new _Printout(title);
}

WXNET_EXPORT(void)
  wxPrintout_RegisterVirtual(_Printout *self,
        Virtual_OnBeginDocument onBeginDocument, Virtual_NoParams onEndDocument, 
        Virtual_NoParams onBeginPrinting, Virtual_NoParams onEndPrinting,
        Virtual_NoParams onPreparePrinting, Virtual_ParamsInt hasPage,
        Virtual_ParamsInt onPrintPage, Virtual_GetPageInfo getPageInfo)
{
    self->RegisterVirtual(onBeginDocument, onEndDocument, 
                          onBeginPrinting, onEndPrinting, onPreparePrinting,
                          hasPage, onPrintPage, getPageInfo);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxPrintout_OnBeginDocument(_Printout* self, int startPage, int endPage)
{
    return self->wxPrintout::OnBeginDocument(startPage, endPage)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPrintout_OnEndDocument(_Printout* self)
{
    self->wxPrintout::OnEndDocument();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPrintout_OnBeginPrinting(_Printout* self)
{
    self->wxPrintout::OnBeginPrinting();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPrintout_OnEndPrinting(_Printout* self)
{
    self->wxPrintout::OnEndPrinting();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPrintout_OnPreparePrinting(_Printout* self)
{
    self->wxPrintout::OnPreparePrinting();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxPrintout_HasPage(_Printout* self, int page)
{
    return self->wxPrintout::HasPage(page)?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPrintout_GetPageInfo(_Printout* self, int* minPage, int* maxPage, int* pageFrom, int* pageTo)
{
    self->wxPrintout::GetPageInfo(minPage, maxPage, pageFrom, pageTo);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxString*)
  wxPrintout_GetTitle(_Printout* self)
{
    return new wxString(self->GetTitle());
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(wxDC*)
  wxPrintout_GetDC(_Printout* self)
{
    return self->GetDC();
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPrintout_SetDC(_Printout* self, wxDC* dc)
{
    self->SetDC(dc);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPrintout_SetPageSizePixels(_Printout* self, int w, int h)
{
    self->SetPageSizePixels(w, h);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPrintout_GetPageSizePixels(_Printout* self, int* w, int* h)
{
    self->GetPageSizePixels(w, h);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPrintout_SetPageSizeMM(_Printout* self, int w, int h)
{
    self->SetPageSizeMM(w, h);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPrintout_GetPageSizeMM(_Printout* self, int* w, int* h)
{
    self->GetPageSizeMM(w, h);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPrintout_SetPPIScreen(_Printout* self, int x, int y)
{
    self->SetPPIScreen(x, y);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPrintout_GetPPIScreen(_Printout* self, int* x, int* y)
{
    self->GetPPIScreen(x, y);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPrintout_SetPPIPrinter(_Printout* self, int x, int y)
{
    self->SetPPIPrinter(x, y);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPrintout_GetPPIPrinter(_Printout* self, int* x, int* y)
{
    self->GetPPIPrinter(x, y);
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(bool)
  wxPrintout_IsPreview(_Printout* self)
{
    return self->IsPreview()?1:0;
}

//-----------------------------------------------------------------------------

WXNET_EXPORT(void)
  wxPrintout_SetIsPreview(_Printout* self, bool p)
{
    self->SetIsPreview(p);
}


