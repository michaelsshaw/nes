/**
 * wx.NET Project
 * 
 * \file 
 * 
 * Provides wrappers of some pivker controls.
 * 
 * Written by Dr. Harald Meyer auf'm Hofe (C) 2008 
 * Licensed under the wxWidgets license, see LICENSE.txt for details.
 *
 * $Id: Picker.cs,v 1.5 2010/05/08 19:54:35 harald_meyer Exp $
 */

using System;
using System.Drawing;
using System.Runtime.InteropServices;

namespace wx
{
    public class DatePickerCtrl : Control
    {
        #region C API
        [DllImport("wx-c")]
        static extern IntPtr wxDatePickerCtrl_DefaultCTor();
        [DllImport("wx-c")]
        static extern void wxDatePickerCtrl_DTor(IntPtr self);
        [DllImport("wx-c")]
        static extern IntPtr wxDatePickerCtrl_CTor(IntPtr parent, int id, IntPtr dtArg, int x, int y, int w, int h, int style, IntPtr nameArg);
        [DllImport("wx-c")]
        static extern void wxDatePickerCtrl_Create(IntPtr self, IntPtr parent, int id, IntPtr dtArg, int x, int y, int w, int h, int style, IntPtr nameArg);
        [DllImport("wx-c")]
        static extern void wxDatePickerCtrl_SetValue(IntPtr self, IntPtr dt);
        [DllImport("wx-c")]
        static extern IntPtr wxDatePickerCtrl_GetValue(IntPtr self);
        [DllImport("wx-c")]
        static extern void wxDatePickerCtrl_SetRange(IntPtr self, IntPtr dt1, IntPtr dt2);
        [DllImport("wx-c")][return:MarshalAs(UnmanagedType.U1)]
        static extern bool wxDatePickerCtrl_GetRange(IntPtr self, IntPtr dt1, IntPtr dt2);
        #endregion

        #region CTor
        /** <summary>CTor for internal use only.</summary>*/
        public DatePickerCtrl(IntPtr cptr)
            : base(cptr)
        {
        }

        /** <summary>CTor for 2 step construction.
         * Use create to provide the control with data.</summary>*/
        public DatePickerCtrl()
            : this(wxDatePickerCtrl_DefaultCTor())
        {
        }

        internal DatePickerCtrl(Window parent, int id, wxDateTime dt, Point position, Size size, WindowStyles style, wxString name)
            : this(wxDatePickerCtrl_CTor(Object.SafePtr(parent), id, Object.SafePtr(dt), position.X, position.Y, size.Width, size.Height, (int)style, Object.SafePtr(name)))
        {
        }
        public DatePickerCtrl(Window parent, int id, DateTime dt, Point position, Size size, WindowStyles style, string name)
            : this(parent, id, (wxDateTime)dt, position, size, style, wxString.SafeNew(name))
        {
        }
        public DatePickerCtrl(Window parent, int id, DateTime dt, Point position, Size size, WindowStyles style)
            : this(parent, id, dt, position, size, style, (string)null)
        {
        }
        public DatePickerCtrl(Window parent, DateTime dt, Point position, Size size, WindowStyles style)
            : this(parent, -1, dt, position, size, style, (string)null)
        {
        }
        public DatePickerCtrl(Window parent, DateTime dt)
            : this(parent, -1, dt, wxDefaultPosition, wxDefaultSize, WindowStyles.DP_DEFAULT | WindowStyles.DP_SHOWCENTURY, (string)null)
        {
        }

        internal void Create(Window parent, int id, wxDateTime dt, Point position, Size size, WindowStyles style, wxString name)
        {
            wxDatePickerCtrl_Create(this.wxObject, Object.SafePtr(parent), id, Object.SafePtr(dt), position.X, position.Y, size.Width, size.Height, (int)style, Object.SafePtr(name));
        }
        public void Create(Window parent, int id, DateTime dt, Point position, Size size, WindowStyles style)
        {
            this.Create(parent, id, (wxDateTime)dt, position, size, style, null);
        }
        
        protected override void CallDTor ()
        {
            wxDatePickerCtrl_DTor(this.wxObject);
        }

        #endregion

        #region Public Types
        public struct Interval
        {
            public DateTime From;
            public DateTime To;

            public Interval(DateTime from, DateTime to)
            {
                this.From = from;
                this.To = to;
            }

            public override string ToString()
            {
                return string.Format("{0}-{1}", this.From, this.To);
            }
        }
        #endregion

        #region Properties
        public DateTime Value
        {
            get
            {
                wxDateTime result = new wxDateTime(wxDatePickerCtrl_GetValue(this.wxObject));
                return result;
            }
            set
            {
                wxDateTime newValue = (wxDateTime)value;
                wxDatePickerCtrl_SetValue(this.wxObject, Object.SafePtr(newValue));
            }
        }

        /** <summary>Constraint on the allowed values.</summary>*/
        public Interval Range
        {
            get
            {
                using (wxDateTime from=new wxDateTime())
                using (wxDateTime to = new wxDateTime())
                {
                    if (wxDatePickerCtrl_GetRange(this.wxObject, from.wxObject, to.wxObject))
                    {
                        return new Interval(from, to);
                    }
                    else
                        return new Interval(DateTime.MinValue, DateTime.MaxValue);
                }
            }
            set
            {
                wxDateTime newFrom = (wxDateTime)value.From;
                wxDateTime newTo = (wxDateTime)value.To;
                wxDatePickerCtrl_SetRange(this.wxObject, Object.SafePtr(newFrom), Object.SafePtr(newTo));
            }
        }
        #endregion
    }

    /** <summary>This event class holds information about a date change and is used together with wx.DatePickerCtrl.
     * It also serves as a base class for wx.CalendarEvent.</summary>*/
    public class DateEvent : CommandEvent
    {
        #region C API
        [DllImport("wx-c")]
        static extern IntPtr wxDateEvent_GetDate(IntPtr self);
        #endregion

        #region CTor
        public DateEvent(IntPtr cptr)
            : base(cptr)
        {
        }
        #endregion

        #region Public Properties
        public DateTime Date
        {
            get { return new wxDateTime(wxDateEvent_GetDate(wxObject)); }
        }
        #endregion
    }

    public abstract class PickerBase : Control
    {
        #region C API
        [DllImport("wx-c")]
        static extern void wxPickerBase_SetInternalMargin(IntPtr self, int margin);
        [DllImport("wx-c")]
        static extern int wxPickerBase_GetInternalMargin(IntPtr self);
        [DllImport("wx-c")]
        static extern void wxPickerBase_SetTextCtrlProportion(IntPtr self, int prop);
        [DllImport("wx-c")]
        static extern void wxPickerBase_SetPickerCtrlProportion(IntPtr self, int prop);
        [DllImport("wx-c")]
        static extern int wxPickerBase_GetTextCtrlProportion(IntPtr self);
        [DllImport("wx-c")]
        static extern int wxPickerBase_GetPickerCtrlProportion(IntPtr self);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxPickerBase_HasTextCtrl(IntPtr self);
        [DllImport("wx-c")]
        static extern IntPtr wxPickerBase_GetTextCtrl(IntPtr self);
        [DllImport("wx-c")]
        static extern void wxPickerBase_SetPickerCtrlGrowable(IntPtr self, [MarshalAs(UnmanagedType.U1)] bool grow);
        [DllImport("wx-c")]
        static extern void wxPickerBase_SetTextCtrlGrowable(IntPtr self, [MarshalAs(UnmanagedType.U1)] bool grow);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxPickerBase_IsTextCtrlGrowable(IntPtr self);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxPickerBase_IsPickerCtrlGrowable(IntPtr self);
        #endregion

        public PickerBase(IntPtr cptr)
            : base(cptr)
        {
        }

        public int InternalMargin
        {
            get
            {
                return wxPickerBase_GetInternalMargin(this.wxObject);
            }
            set
            {
                wxPickerBase_SetInternalMargin(this.wxObject, value);
            }
        }

        /** <summary>True if the picker grows with the control.</summary>*/
        public bool IsPickerCtrlGrowable
        {
            get
            {
                return wxPickerBase_IsPickerCtrlGrowable(this.wxObject);
            }
            set
            {
                wxPickerBase_SetPickerCtrlGrowable(this.wxObject, value);
            }
        }

        /** <summary>True if the contained text control grows with the whole control.</summary>*/
        public bool IsTextCtrlGrowable
        {
            get
            {
                return wxPickerBase_IsTextCtrlGrowable(this.wxObject);
            }
            set
            {
                wxPickerBase_SetTextCtrlGrowable(this.wxObject, value);
            }
        }

        /** <summary>Read or set the text control's proportion.</summary>*/
        public int TextCtrlProportion
        {
            get
            {
                return wxPickerBase_GetTextCtrlProportion(this.wxObject);
            }
            set
            {
                wxPickerBase_SetTextCtrlProportion(this.wxObject, value);
            }
        }

        /** <summary>Read or set the picker control's proportion.</summary>*/
        public int PickerCtrlProportion
        {
            get
            {
                return wxPickerBase_GetPickerCtrlProportion(this.wxObject);
            }
            set
            {
                wxPickerBase_SetPickerCtrlProportion(this.wxObject, value);
            }
        }

        /** <summary>True iff this shows a text control.</summary>*/
        public bool HasTextCtrl
        {
            get { return wxPickerBase_HasTextCtrl(this.wxObject); }
        }

        /** <summary>Reads the text control. 
         * This is <c>null</c> if this does not show a text control.</summary>*/
        public TextCtrl TextCtrl
        {
            get
            {
                return (wx.TextCtrl)Object.FindObject(wxPickerBase_GetTextCtrl(this.wxObject), typeof(wx.TextCtrl));
            }
        }
    }

    /** <summary>This control allows the user to select a colour.
     * The generic implementation is a button which brings up a wx.ColourDialog when clicked. Native implementation may differ but this
     * is usually a (small) widget which give access to the colour-chooser dialog.
     * 
     * Available styles: wx.WindowStyles.CLRP_DEFAULT_STYLE, wx.WindowStyles.CLRP_USE_TEXTCTRL, wx.WindowStyles.CLRP_SHOW_LABEL.</summary>*/
    public class ColourPickerCtrl : PickerBase
    {
        #region C API
        [DllImport("wx-c")]
        static extern IntPtr wxColourPickerCtrl_DefaultCTor();
        [DllImport("wx-c")]
        static extern IntPtr wxColourPickerCtrl_CTor(IntPtr parent, int id, IntPtr colArg, int x, int y, int w, int h, int style, IntPtr nameArg);
        //[DllImport("wx-c")]static extern void wxColourPickerCtrl_Create(IntPtr self, IntPtr parent, int id, IntPtr colArg, int x, int y, int w, int h, int style, IntPtr nameArg);
        [DllImport("wx-c")]
        static extern IntPtr wxColourPickerCtrl_GetColour(IntPtr self);
        [DllImport("wx-c")]
        static extern void wxColourPickerCtrl_SetColour(IntPtr self, IntPtr colour);
        [DllImport("wx-c")]
        static extern void wxColourPickerCtrl_SetColourFromString(IntPtr self, IntPtr colour);
        #endregion

        #region CTor
        /** <summary>Default CTor for two step construction using Create().</summary>*/
        public ColourPickerCtrl()
            : base(wxColourPickerCtrl_DefaultCTor())
        {
        }

        public ColourPickerCtrl(Window parent, int id, Colour colour, Point position, Size size, WindowStyles style, wxString name)
            : base(wxColourPickerCtrl_CTor(Object.SafePtr(parent), id, Object.SafePtr(colour), position.X, position.Y, size.Width, size.Height, (int) style, Object.SafePtr(name)))
        {
        }
        public ColourPickerCtrl(Window parent, int id, Colour colour, Point position, Size size, WindowStyles style, string name)
            : this(parent, id, colour, position, size, style, wxString.SafeNew(name))
        {
        }

        public ColourPickerCtrl(Window parent, int id, Colour colour, Point position, Size size, WindowStyles style)
            : this(parent, id, colour, position, size, style, (wxString) null)
        {
        }

        public ColourPickerCtrl(Window parent, Colour colour, Point position, Size size, WindowStyles style)
            : this(parent, -1, colour, position, size, style, (wxString)null)
        {
        }
        #endregion

        #region Public Methods
        /** <summary>Setting the clour from a string.
         * This accepts: colour names (those listed in wx.Colour.TheColourDatabase), the CSS-like "RGB(r,g,b)" syntax
         * (case insensitive) and the HTML-like syntax (i.e. "#" followed by 6 hexadecimal digits for red, green, blue components).</summary>*/
        public void SetColour(string colour)
        {
            this.SetColour(wxString.SafeNew(colour));
        }

        /** <summary>Setting the clour from a string.
         * This accepts: colour names (those listed in wx.Colour.TheColourDatabase), the CSS-like "RGB(r,g,b)" syntax
         * (case insensitive) and the HTML-like syntax (i.e. "#" followed by 6 hexadecimal digits for red, green, blue components).</summary>*/
        public void SetColour(wxString colour)
        {
            wxColourPickerCtrl_SetColourFromString(this.wxObject, Object.SafePtr(colour));
        }
        #endregion

        #region Public Properties
        /** <summary>The displayed colour.</summary>*/
        public wx.Colour Colour
        {
            get
            {
                return new Colour(wxColourPickerCtrl_GetColour(this.wxObject));
            }
            set
            {
                wxColourPickerCtrl_SetColour(this.wxObject, Object.SafePtr(value));
            }
        }
        #endregion
    }

    /** <summary>Events raised by the wx.ColourPickerCtrl</summary>*/
    public class ColourPickerEvent : CommandEvent
    {
        #region C API
        [DllImport("wx-c")]
        static extern IntPtr wxColourPickerEvent_GetColour(IntPtr self);
        [DllImport("wx-c")]
        static extern void wxColourPickerEvent_SetColour(IntPtr self, IntPtr colour);
        #endregion

        #region CTor
        public ColourPickerEvent(IntPtr cptr) : base(cptr) { }
        #endregion

        #region Properties
        /** <summary>The affected colour.
         * If this indicates a change, then this is e.g. the new colour.</summary>*/
        public wx.Colour Colour
        {
            get
            {
                return new wx.Colour(wxColourPickerEvent_GetColour(this.wxObject));
            }
            set
            {
                wxColourPickerEvent_SetColour(this.wxObject, Object.SafePtr(value));
            }
        }
        #endregion
    }


    /** <summary>This control allows the user to select a font.
     * The generic implementation is a button which brings up a wxFontDialog when clicked.
     * Native implementation may differ but this is usually a (small) widget which give access to the font-chooser dialog.
     * 
     * Uses the styles wx.WindowStyles.FNTP_FONTDESC_AS_LABEL, wx.WindowStyles.FNTP_USEFONT_FOR_LABEL,
     * wx.WindowStyles.FNTP_USE_TEXTCTRL, wx.WindowStyles.FNTP_DEFAULT_STYLE.</summary>*/
    public class FontPickerCtrl : PickerBase
    {
        #region C API
        [DllImport("wx-c")]
        static extern IntPtr wxFontPickerCtrl_DefaultCTor();
        [DllImport("wx-c")]
        static extern IntPtr wxFontPickerCtrl_CTor(IntPtr parent, int id, IntPtr fontArg, int x, int y, int w, int h, int style, IntPtr nameArg);
        [DllImport("wx-c")]
        static extern IntPtr wxFontPickerCtrl_Create(IntPtr self, IntPtr parent, int id, IntPtr fontArg, int x, int y, int w, int h, int style, IntPtr nameArg);
        [DllImport("wx-c")]
        static extern IntPtr wxFontPickerCtrl_GetSelectedFont(IntPtr self);
        [DllImport("wx-c")]
        static extern void wxFontPickerCtrl_SetSelectedFont(IntPtr self, IntPtr font);
        [DllImport("wx-c")]
        static extern int wxFontPickerCtrl_GetMaxPointSize(IntPtr self);
        [DllImport("wx-c")]
        static extern void wxFontPickerCtrl_SetMaxPointSize(IntPtr self, int maxPointSize);
        #endregion

        #region CTor
        public FontPickerCtrl(IntPtr cptr)
            : base(cptr)
        {
        }

        /** <summary>Default CTor.
         * Use this in two step construction in combination with <c>Create()</c>.</summary>*/
        public FontPickerCtrl()
            : base(wxFontPickerCtrl_DefaultCTor())
        {
        }

        public FontPickerCtrl(Window parent, int id, Font font, Point position, Size size, WindowStyles style, wxString name)
            : base(wxFontPickerCtrl_CTor(Object.SafePtr(parent), id, Object.SafePtr(font), position.X, position.Y, size.Width, size.Height, (int)style, Object.SafePtr(name)))
        {
        }
        public FontPickerCtrl(Window parent, int id, Font font, Point position, Size size, WindowStyles style, string name)
            : this(parent, id, font, position, size, style, wxString.SafeNew(name))
        {
        }
        public FontPickerCtrl(Window parent, int id, Font font, Point position, Size size, WindowStyles style)
            : this(parent, id, font, position, size, style, (wxString)null)
        {
        }
        public FontPickerCtrl(Window parent, Font font, Point position, Size size, WindowStyles style)
            : this(parent, -1, font, position, size, style, (wxString)null)
        {
        }

        /** <summary>Second step in 2-step construction.</summary>*/
        public void Create(Window parent, int id, Font font, Point position, Size size, WindowStyles style, wxString name)
        {
            wxFontPickerCtrl_Create(this.wxObject, Object.SafePtr(parent), id, Object.SafePtr(font), position.X, position.Y, size.Width, size.Height, (int)style, Object.SafePtr(name));
        }
        #endregion

        #region Public Properties
        /** <summary>Get or set the selected font.
         * Please keep care that the result will be finalized as soon as possible since
         * some platforms only allow a certain amount of allocated font objects.</summary>*/
        public Font SelectedFont
        {
            get
            {
                return new Font(wxFontPickerCtrl_GetSelectedFont(this.wxObject));
            }
            set
            {
                wxFontPickerCtrl_SetSelectedFont(this.wxObject, Object.SafePtr(value));
            }
        }

        /** <summary>Reads or defines the maximal point size of a font.</summary>*/
        public int MaxPointSize
        {
            get
            {
                return wxFontPickerCtrl_GetMaxPointSize(this.wxObject);
            }
            set
            {
                wxFontPickerCtrl_SetMaxPointSize(this.wxObject, value);
            }
        }
        #endregion
    }

    /** <summary>This event refers to wx.FontPickerCtrl</summary>*/
    public class FontPickerEvent : CommandEvent
    {
        #region C API
        [DllImport("wx-c")]
        static extern IntPtr wxFontPickerEvent_GetFont(IntPtr self);
        [DllImport("wx-c")]
        static extern void wxFontPickerEvent_SetFont(IntPtr self, IntPtr font);
        #endregion

        #region CTor
        public FontPickerEvent(IntPtr cptr) : base (cptr) { }
        #endregion

        #region Public Properties
        /** <summary>Get or set the affected font.
         * Please keep care that the result will be finalized as soon as possible since
         * some platforms only allow a certain amount of allocated font objects.</summary>*/
        public wx.Font Font
        {
            get 
            {
                return new Font(wxFontPickerEvent_GetFont(this.wxObject));
            }
            set
            {
                wxFontPickerEvent_SetFont(this.wxObject, Object.SafePtr(value));
            }
        }
        #endregion
    }
}

