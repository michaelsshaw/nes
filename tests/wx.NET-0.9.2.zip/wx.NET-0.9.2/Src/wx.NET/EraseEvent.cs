//-----------------------------------------------------------------------------
// wx.NET - EraseEvent.cs
//
// The wxEraseEvent wrapper class.
//
// Written by Alexander Olk (xenomorph2@onlinehome.de)
// (C) 2004 by Alexander Olk
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: EraseEvent.cs,v 1.3 2009/07/03 18:49:48 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Runtime.InteropServices;

namespace wx
{
	public class EraseEvent : Event
	{
		[DllImport("wx-c")] static extern IntPtr wxEraseEvent_ctor(int type);
		[DllImport("wx-c")] static extern IntPtr wxEraseEvent_GetDC(IntPtr self);
		
		//-----------------------------------------------------------------------------

		public EraseEvent(IntPtr wxObject) 
			: base(wxObject) { }

        static IntPtr LockedCTor(int type)
        {
            lock (DllSync)
            {
                return wxEraseEvent_ctor(type);
            }
        }

		public EraseEvent(int type)
			: this(LockedCTor(type)) { }

		//-----------------------------------------------------------------------------	
		
		public DC DC
		{
			get { return (DC)FindObject(wxEraseEvent_GetDC(wxObject), typeof(DC)); }
		}
	}
}
