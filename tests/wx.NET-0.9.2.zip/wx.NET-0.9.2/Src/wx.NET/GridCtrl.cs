//-----------------------------------------------------------------------------
// wx.NET - GridCtrl.cs
//
// The wxGrid controls wrapper class.
//
// Written by Alexander Olk (xenomorph2@onlinehome.de)
// (C) 2004 by Alexander Olk
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: GridCtrl.cs,v 1.14 2010/04/19 19:32:00 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Runtime.InteropServices;
using System.Drawing;
using wx;

namespace wx.GridCtrl
{
    namespace Renderers
    {
        /** <summary>Wrapper of the <c>wxGridCellDateTimeRenderer</c>.
         * This editor uses format strings according to  wxWidgets convention for output.
         * Refer to GridCellDateTimeMaskRenderer / GridCellDateTimeMaskEditor for more .NET
         * like implementations.
         * </summary>
         */
        public class GridCellDateTimeRenderer : GridCellStringRenderer
        {
            [DllImport("wx-c")]
            public static extern IntPtr GridCellDateTimeRenderer_GetWxClassInfo();
            [DllImport("wx-c")]
            static extern IntPtr wxGridCellDateTimeRenderer_ctor(IntPtr outformat, IntPtr informat);
            [DllImport("wx-c")]
            static extern void wxGridCellDateTimeRenderer_dtor(IntPtr self);
            [DllImport("wx-c")]
            static extern void wxGridCellDateTimeRenderer_Draw(IntPtr self, IntPtr grid, IntPtr attr, IntPtr dc, ref Rectangle rect, int row, int col, bool isSelected);
            [DllImport("wx-c")]
            static extern void wxGridCellDateTimeRenderer_GetBestSize(IntPtr self, IntPtr grid, IntPtr attr, IntPtr dc, int row, int col, out Size size);
            [DllImport("wx-c")]
            static extern IntPtr wxGridCellDateTimeRenderer_Clone(IntPtr self);
            [DllImport("wx-c")]
            static extern void wxGridCellDateTimeRenderer_SetParameters(IntPtr self, IntPtr parameter);

            public GridCellDateTimeRenderer()
                : this("%c", "%c") { }

            public GridCellDateTimeRenderer(string outformat)
                : this(outformat, "%c") { }

            public GridCellDateTimeRenderer(string outformat, string informat)
                : this(wxString.SafeNew(outformat), wxString.SafeNew(informat)) { }

            public GridCellDateTimeRenderer(wxString outformat, wxString informat)
                : this(wxGridCellDateTimeRenderer_ctor(Object.SafePtr(outformat), Object.SafePtr(informat)), true) { }

            public GridCellDateTimeRenderer(IntPtr wxObject)
                : base(wxObject)
            {
                this.wxObject = wxObject;
            }

            internal GridCellDateTimeRenderer(IntPtr wxObject, bool memOwn)
                : base(wxObject)
            {
                this.memOwn = memOwn;
                this.wxObject = wxObject;
            }

            //---------------------------------------------------------------------

            public override void Dispose()
            {
                if (!disposed)
                {
                    if (wxObject != IntPtr.Zero)
                    {
                        if (memOwn)
                        {
                            wxGridCellDateTimeRenderer_dtor(wxObject);
                            memOwn = false;
                        }
                    }
                    RemoveObject(wxObject);
                    wxObject = IntPtr.Zero;
                    --validInstancesCount;
                    disposed = true;
                }

                base.Dispose();
                GC.SuppressFinalize(this);
            }

            //---------------------------------------------------------------------

            ~GridCellDateTimeRenderer()
            {
                Dispose();
            }

            public override void SetParameters(string parameter)
            {
                wxString wxParam = wxString.SafeNew(parameter);
                wxGridCellDateTimeRenderer_SetParameters(wxObject, Object.SafePtr(wxParam));
            }

            public override void Draw(Grid grid, GridCellAttr attr, DC dc, Rectangle rect, int row, int col, bool isSelected)
            {
                wxGridCellDateTimeRenderer_Draw(wxObject, Object.SafePtr(grid), Object.SafePtr(attr), Object.SafePtr(dc), ref rect, row, col, isSelected);
            }

            public override Size GetBestSize(Grid grid, GridCellAttr attr, DC dc, int row, int col)
            {
                Size size = new Size();
                wxGridCellDateTimeRenderer_GetBestSize(wxObject, Object.SafePtr(grid), Object.SafePtr(attr), Object.SafePtr(dc), row, col, out size);
                return size;
            }

            public override GridCellRenderer Clone()
            {
                return (GridCellRenderer)FindObject(wxGridCellDateTimeRenderer_Clone(wxObject), typeof(GridCellRenderer));
            }
        }

        //-----------------------------------------------------------------------------

        /** <summary>Renders an enumeration.
         * Enumerations are specified either as comma separated list or as an array of strings.
         * However, also this array will be passed to the renderer as comma separated list so avoid
         * comma in items.</summary>*/
        public class GridCellEnumRenderer : GridCellStringRenderer
        {
            [DllImport("wx-c")]
            public static extern IntPtr GridCellEnumRenderer_GetWxClassInfo();
            [DllImport("wx-c")]
            static extern IntPtr wxGridCellEnumRenderer_ctor(IntPtr choices);
            [DllImport("wx-c")]
            static extern void wxGridCellEnumRenderer_dtor(IntPtr self);
            [DllImport("wx-c")]
            static extern void wxGridCellEnumRenderer_Draw(IntPtr self, IntPtr grid, IntPtr attr, IntPtr dc, ref Rectangle rect, int row, int col, bool isSelected);
            [DllImport("wx-c")]
            static extern void wxGridCellEnumRenderer_GetBestSize(IntPtr self, IntPtr grid, IntPtr attr, IntPtr dc, int row, int col, out Size size);
            [DllImport("wx-c")]
            static extern IntPtr wxGridCellEnumRenderer_Clone(IntPtr self);
            [DllImport("wx-c")]
            static extern void wxGridCellEnumRenderer_SetParameters(IntPtr self, IntPtr parameter);

            public GridCellEnumRenderer()
                : this("") { }

            static internal string ProduceCommaSeparatedList(string[] choices)
            {
                System.Text.StringBuilder sb = new System.Text.StringBuilder();
                int index = 0;
                foreach (string choice in choices)
                {
                    if (index > 0)
                        sb.Append(",");
                    sb.Append(choice);
                    ++index;
                }
                return sb.ToString();
            }

            public GridCellEnumRenderer(string[] choices)
                : this(ProduceCommaSeparatedList(choices))
            {
            }

            /** <summary>Argument is a comma separated list.</summary>*/
            public GridCellEnumRenderer(string choices)
                : this(wxString.SafeNew(choices))
            {
            }
            /** <summary>Argument is a comma separated list.</summary>*/
            public GridCellEnumRenderer(wxString choices)
                : this(wxGridCellEnumRenderer_ctor(Object.SafePtr(choices)), true) { }

            public GridCellEnumRenderer(IntPtr wxObject)
                : base(wxObject)
            {
                this.wxObject = wxObject;
            }

            internal GridCellEnumRenderer(IntPtr wxObject, bool memOwn)
                : base(wxObject)
            {
                this.memOwn = memOwn;
                this.wxObject = wxObject;
            }

            //---------------------------------------------------------------------

            public override void Dispose()
            {
                if (!disposed)
                {
                    if (wxObject != IntPtr.Zero)
                    {
                        if (memOwn)
                        {
                            wxGridCellEnumRenderer_dtor(wxObject);
                            memOwn = false;
                        }
                    }
                    RemoveObject(wxObject);
                    wxObject = IntPtr.Zero;
                    --validInstancesCount;
                    disposed = true;
                }

                base.Dispose();
                GC.SuppressFinalize(this);
            }

            //---------------------------------------------------------------------

            ~GridCellEnumRenderer()
            {
                Dispose();
            }

            /** <summary>The <c>parameter</c> is a comma separated list of the items to be rendered.</summary>*/
            public override void SetParameters(string parameter)
            {
                wxString wxParam = wxString.SafeNew(parameter);
                wxGridCellEnumRenderer_SetParameters(wxObject, Object.SafePtr(wxParam));
            }

            public override void Draw(Grid grid, GridCellAttr attr, DC dc, Rectangle rect, int row, int col, bool isSelected)
            {
                wxGridCellEnumRenderer_Draw(wxObject, Object.SafePtr(grid), Object.SafePtr(attr), Object.SafePtr(dc), ref rect, row, col, isSelected);
            }

            public override Size GetBestSize(Grid grid, GridCellAttr attr, DC dc, int row, int col)
            {
                Size size = new Size();
                wxGridCellEnumRenderer_GetBestSize(wxObject, Object.SafePtr(grid), Object.SafePtr(attr), Object.SafePtr(dc), row, col, out size);
                return size;
            }

            public override GridCellRenderer Clone()
            {
                return (GridCellRenderer)FindObject(wxGridCellEnumRenderer_Clone(wxObject), typeof(GridCellRenderer));
            }
        }
    }

    /** Editors of the wx.GridCtrl control.
     */
    namespace Editors
    {

        /** <summary>Editor for an enumeration.
         * Enumerations are specified either as comma separated list or as an array of strings.
         * However, also this array will be passed to the renderer as comma separated list so avoid
         * comma in items.</summary>*/
        public class GridCellEnumEditor : GridCellChoiceEditor
        {
            #region C API
            [DllImport("wx-c")]
            new public static extern IntPtr GridCellEnumEditor_GetWxClassInfo();
            [DllImport("wx-c")]
            static extern IntPtr wxGridCellEnumEditor_ctor(IntPtr choices);
            [DllImport("wx-c")]
            static extern void wxGridCellEnumEditor_dtor(IntPtr self);
            [DllImport("wx-c")]
            static extern void wxGridCellEnumEditor_BeginEdit(IntPtr self, int row, int col, IntPtr grid);
            [DllImport("wx-c")]
            static extern bool wxGridCellEnumEditor_EndEdit(IntPtr self, int row, int col, IntPtr grid);
            [DllImport("wx-c")]
            static extern IntPtr wxGridCellEnumEditor_Clone(IntPtr self);
            #endregion

            #region CTor / DTor
            public GridCellEnumEditor()
                : this("") { }

            public GridCellEnumEditor(string[] choices)
                : this(Renderers.GridCellEnumRenderer.ProduceCommaSeparatedList(choices))
            {
            }

            /** <summary>Argument is a comma separated list of items.</summary>*/
            public GridCellEnumEditor(string choices)
                : this(wxString.SafeNew(choices))
            {
            }

            /** <summary>Argument is a comma separated list of items.</summary>*/
            public GridCellEnumEditor(wxString choices)
                : this(wxGridCellEnumEditor_ctor(Object.SafePtr(choices)), true) { }

            public GridCellEnumEditor(IntPtr wxObject)
                : base(wxObject)
            {
                this.wxObject = wxObject;
            }

            internal GridCellEnumEditor(IntPtr wxObject, bool memOwn)
                : base(wxObject)
            {
                this.memOwn = memOwn;
                this.wxObject = wxObject;
            }

            protected override void CallDTor()
            {
                wxGridCellEnumEditor_dtor(wxObject);
            }

            ~GridCellEnumEditor()
            {
                Dispose();
            }
            #endregion

            public override void BeginEdit(int row, int col, Grid grid)
            {
                wxGridCellEnumEditor_BeginEdit(wxObject, row, col, Object.SafePtr(grid));
            }

            public override bool EndEdit(int row, int col, Grid grid)
            {
                return wxGridCellEnumEditor_EndEdit(wxObject, row, col, Object.SafePtr(grid));
            }

            public override GridCellEditor Clone()
            {
                return (GridCellEditor)FindObject(wxGridCellEnumEditor_Clone(wxObject), typeof(GridCellEditor));
            }
        }

        //-----------------------------------------------------------------------------

        /** <summary>String editor for potentially longer strings containing blanks.
         * You may input explicit line breaks using the CTRL key in conjunctions
         * with the return or enter key.</summary>*/
        public class GridCellAutoWrapStringEditor : GridCellTextEditor
        {
            [DllImport("wx-c")]
            public static extern IntPtr GridCellAutoWrapStringEditor_GetWxClassInfo();
            [DllImport("wx-c")]
            static extern IntPtr wxGridCellAutoWrapStringEditor_ctor();
            [DllImport("wx-c")]
            static extern void wxGridCellAutoWrapStringEditor_dtor(IntPtr self);
            [DllImport("wx-c")]
            static extern void wxGridCellAutoWrapStringEditor_RegisterDisposable(IntPtr self, Virtual_Dispose onDispose);
            [DllImport("wx-c")]
            static extern void wxGridCellAutoWrapStringEditor_Create(IntPtr self, IntPtr parent, int id, IntPtr evtHandler);
            [DllImport("wx-c")]
            static extern IntPtr wxGridCellAutoWrapStringEditor_Clone(IntPtr self);

            public GridCellAutoWrapStringEditor()
                : this(wxGridCellAutoWrapStringEditor_ctor(), true)
            {
                virtual_Dispose = new Virtual_Dispose(VirtualDispose);
                wxGridCellAutoWrapStringEditor_RegisterDisposable(wxObject, virtual_Dispose);
            }

            public GridCellAutoWrapStringEditor(IntPtr wxObject)
                : base(wxObject)
            {
                this.wxObject = wxObject;
            }

            internal GridCellAutoWrapStringEditor(IntPtr wxObject, bool memOwn)
                : base(wxObject)
            {
                this.memOwn = memOwn;
                this.wxObject = wxObject;
            }

            //---------------------------------------------------------------------

            protected override void CallDTor()
            {
                wxGridCellAutoWrapStringEditor_dtor(wxObject);
            }

            //---------------------------------------------------------------------

            ~GridCellAutoWrapStringEditor()
            {
                Dispose();
            }

            public override void Create(Window parent, int id, EvtHandler evtHandler)
            {
                wxGridCellAutoWrapStringEditor_Create(wxObject, Object.SafePtr(parent), id, Object.SafePtr(evtHandler));
            }

            public override GridCellEditor Clone()
            {
                return (GridCellEditor)FindObject(wxGridCellAutoWrapStringEditor_Clone(wxObject), typeof(GridCellEditor));
            }
        }
    }

	//-----------------------------------------------------------------------------

    /** Renderers of the wx.GridCtrl control.
     */
    namespace Renderers
    {
        /** <summary>String renderer for potentially longer strings containing blanks.
         * Texts rendered by instances of this class will not overlap into empty cells
         * in the neighbourhood. Longer strings will be displayed wrapped instead.</summary>*/
        public class GridCellAutoWrapStringRenderer : GridCellStringRenderer
        {
            [DllImport("wx-c")]
            public static extern IntPtr GridCellAutoWrapStringRenderer_GetWxClassInfo();
            [DllImport("wx-c")]
            static extern IntPtr wxGridCellAutoWrapStringRenderer_ctor();
            [DllImport("wx-c")]
            static extern void wxGridCellAutoWrapStringRenderer_dtor(IntPtr self);
            [DllImport("wx-c")]
            static extern void wxGridCellAutoWrapStringRenderer_RegisterDisposable(IntPtr self, Virtual_Dispose onDispose);
            [DllImport("wx-c")]
            static extern void wxGridCellAutoWrapStringRenderer_Draw(IntPtr self, IntPtr grid, IntPtr attr, IntPtr dc, ref Rectangle rect, int row, int col, bool isSelected);
            [DllImport("wx-c")]
            static extern void wxGridCellAutoWrapStringRenderer_GetBestSize(IntPtr self, IntPtr grid, IntPtr attr, IntPtr dc, int row, int col, out Size size);
            [DllImport("wx-c")]
            static extern IntPtr wxGridCellAutoWrapStringRenderer_Clone(IntPtr self);

            public GridCellAutoWrapStringRenderer()
                : this(wxGridCellAutoWrapStringRenderer_ctor(), true)
            {
                virtual_Dispose = new Virtual_Dispose(VirtualDispose);
                wxGridCellAutoWrapStringRenderer_RegisterDisposable(wxObject, virtual_Dispose);
            }

            public GridCellAutoWrapStringRenderer(IntPtr wxObject)
                : base(wxObject)
            {
                this.wxObject = wxObject;
            }

            internal GridCellAutoWrapStringRenderer(IntPtr wxObject, bool memOwn)
                : base(wxObject)
            {
                this.memOwn = memOwn;
                this.wxObject = wxObject;
            }

            //---------------------------------------------------------------------

            public override void Dispose()
            {
                if (!disposed)
                {
                    if (wxObject != IntPtr.Zero)
                    {
                        if (memOwn)
                        {
                            wxGridCellAutoWrapStringRenderer_dtor(wxObject);
                            memOwn = false;
                        }
                    }
                    RemoveObject(wxObject);
                    wxObject = IntPtr.Zero;
                    --validInstancesCount;
                    disposed = true;
                }

                base.Dispose();
                GC.SuppressFinalize(this);
            }

            //---------------------------------------------------------------------

            ~GridCellAutoWrapStringRenderer()
            {
                Dispose();
            }

            public override void Draw(Grid grid, GridCellAttr attr, DC dc, Rectangle rect, int row, int col, bool isSelected)
            {
                wxGridCellAutoWrapStringRenderer_Draw(wxObject, Object.SafePtr(grid), Object.SafePtr(attr), Object.SafePtr(dc), ref rect, row, col, isSelected);
            }

            public override Size GetBestSize(Grid grid, GridCellAttr attr, DC dc, int row, int col)
            {
                Size size = new Size();
                wxGridCellAutoWrapStringRenderer_GetBestSize(wxObject, Object.SafePtr(grid), Object.SafePtr(attr), Object.SafePtr(dc), row, col, out size);
                return size;
            }

            public override GridCellRenderer Clone()
            {
                return (GridCellRenderer)FindObject(wxGridCellAutoWrapStringRenderer_Clone(wxObject), typeof(GridCellRenderer));
            }
        }
    }
}
