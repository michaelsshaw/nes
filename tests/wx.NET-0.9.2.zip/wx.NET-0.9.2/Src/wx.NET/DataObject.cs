//-----------------------------------------------------------------------------
// wx.NET - Dataobj.cs
//
// The wxDataObject wrapper class.
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 by Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: DataObject.cs,v 1.15 2010/05/08 19:52:40 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Runtime.InteropServices;

namespace wx
{
    /** <summary>wx.DataObject represents a piece of data which knows which formats it
    * supports and knows how to render itself in each of them - <c>GetDataHere()</c>,
    * and how to restore data from the buffer (SetData()).
    *
    * Although this class may be used directly (i.e. custom classes may be
    * derived from it), in many cases it might be simpler to use either
    * wx.DataObjectSimple or wxDataObjectComposite classes.
    *
    * A data object may be "read only", i.e. support only GetData() functions or
    * "read-write", i.e. support both GetData() and SetData() (in principle, it
    * might be "write only" too, but this is rare). Moreover, it doesn't have to
    * support the same formats in Get() and Set() directions: for example, a data
    * object containing JPEG image might accept BMPs in GetData() because JPEG
    * image may be easily transformed into BMP but not in SetData(). Accordingly,
    * all methods dealing with formats take an additional "direction" argument
    * which is either SET or GET and which tells the function if the format needs
    * to be supported by SetData() or GetDataHere().</summary>*/
	public abstract class DataObject : Object
	{
		public enum DataDirection
		{
			Get = 0x01,
			Set = 0x02,
			Both = 0x03
		}
		
		//---------------------------------------------------------------------

		public DataObject(IntPtr wxObject)
			: base(wxObject) 
		{
			this.wxObject = wxObject;
		}
		
		internal DataObject(IntPtr wxObject, bool memOwn)
			: base(wxObject)
		{ 
			this.memOwn = memOwn;
			this.wxObject = wxObject;
		}
		
		//---------------------------------------------------------------------
				
		public override void Dispose()
		{
			if (!disposed)
			{
                if (wxObject != IntPtr.Zero)
				{
					if (memOwn)
					{
						memOwn = false;
					}
				}
				RemoveObject(wxObject);
				wxObject = IntPtr.Zero;
                --validInstancesCount;
                disposed = true;
			}
			
			base.Dispose();
			GC.SuppressFinalize(this);
		}
		
		//---------------------------------------------------------------------
		
		~DataObject() 
		{
			Dispose();
		}
	}
	
	//---------------------------------------------------------------------

	public abstract class DataObjectSimple : DataObject
	{
		//[DllImport("wx-c")] static extern IntPtr wxDataObjectSimple_ctor(IntPtr format);
		[DllImport("wx-c")] static extern void wxDataObjectSimple_dtor(IntPtr self);
		//[DllImport("wx-c")] static extern void wxDataObjectSimple_SetFormat(IntPtr self, IntPtr format);
		//[DllImport("wx-c")] static extern uint wxDataObjectSimple_GetDataSize(IntPtr self);
		//[DllImport("wx-c")] static extern bool wxDataObjectSimple_GetDataHere(IntPtr self, IntPtr buf);
		//[DllImport("wx-c")] static extern bool wxDataObjectSimple_SetData(IntPtr self, uint len, IntPtr buf);
		
		//---------------------------------------------------------------------

		public DataObjectSimple(IntPtr wxObject)
			: base(wxObject)
		{
			this.wxObject = wxObject;
		}
		
		internal DataObjectSimple(IntPtr wxObject, bool memOwn)
			: base(wxObject)
		{ 
			this.memOwn = memOwn;
			this.wxObject = wxObject;
		}
		
		//---------------------------------------------------------------------
				
		public override void Dispose()
		{
			if (!disposed)
			{
                if (wxObject != IntPtr.Zero)
				{
					if (memOwn)
					{
						wxDataObjectSimple_dtor(wxObject);
						memOwn = false;
					}
				}
				RemoveObject(wxObject);
				wxObject = IntPtr.Zero;
                --validInstancesCount;
                disposed = true;
			}
			
			base.Dispose();
			GC.SuppressFinalize(this);
		}
		
		//---------------------------------------------------------------------
		
		~DataObjectSimple() 
		{
			Dispose();
		}
	}
	
	//---------------------------------------------------------------------

	public class TextDataObject : DataObjectSimple
	{
		[DllImport("wx-c")] static extern IntPtr wxTextDataObject_ctor(IntPtr text);
		[DllImport("wx-c")] static extern void wxTextDataObject_dtor(IntPtr self);
		[DllImport("wx-c")] static extern void wxTextDataObject_RegisterDisposable(IntPtr self, Virtual_Dispose onDispose);
		[DllImport("wx-c")] static extern int wxTextDataObject_GetTextLength(IntPtr self);
		[DllImport("wx-c")] static extern IntPtr wxTextDataObject_GetText(IntPtr self);
		[DllImport("wx-c")] static extern void wxTextDataObject_SetText(IntPtr self, IntPtr text);
		
		//---------------------------------------------------------------------

		public TextDataObject(IntPtr wxObject)
			: base(wxObject) 
		{
			this.wxObject = wxObject;
		}
			
		internal TextDataObject(IntPtr wxObject, bool memOwn)
			: base(wxObject)
		{ 
			this.memOwn = memOwn;
			this.wxObject = wxObject;
		}

		public TextDataObject()
			: this("") {}

        public TextDataObject(string text)
            : this(wxString.SafeNew(text))
        {
        }

        static IntPtr LockedCTor(wxString text)
        {
            lock (DllSync)
            {
                return wxTextDataObject_ctor(Object.SafePtr(text));
            }
        }

		public TextDataObject(wxString text)
			: this(LockedCTor(text), true) 
		{
			virtual_Dispose = new Virtual_Dispose(VirtualDispose);
			wxTextDataObject_RegisterDisposable(wxObject, virtual_Dispose);
		}
			
		//---------------------------------------------------------------------
				
		public override void Dispose()
		{
			if (!disposed)
			{
                if (wxObject != IntPtr.Zero)
				{
					if (memOwn)
					{
						wxTextDataObject_dtor(wxObject);
						memOwn = false;
					}
				}
				RemoveObject(wxObject);
				wxObject = IntPtr.Zero;
                --validInstancesCount;
                disposed = true;
			}
			
			base.Dispose();
			GC.SuppressFinalize(this);
		}
		
		//---------------------------------------------------------------------
		
		~TextDataObject() 
		{
			Dispose();
		}
			
		//---------------------------------------------------------------------

		public int TextLength
		{
			get { return wxTextDataObject_GetTextLength(wxObject); }
		}
		
		//---------------------------------------------------------------------

		public string Text
		{
			get { return new wxString(wxTextDataObject_GetText(wxObject), true); }
			set
            {
                wxString wxValue = wxString.SafeNew(value);
                wxTextDataObject_SetText(wxObject, Object.SafePtr(wxValue));
            }
		}
	}
	
	//---------------------------------------------------------------------

    /// <summary>
    /// wx.FileDataObject is a specialization of wxDataObject for file names.
    /// The program works with it just as if it were a list of absolute file names,
    /// but internally it uses the same format as Explorer and other compatible programs
    /// under Windows or GNOME/KDE filemanager under Unix which makes it possible to receive
    /// files from them using this class.
    ///
    /// Warning: Under all non-Windows platforms this class is currently "input-only", i.e.
    /// you can receive the files from another application, but copying (or dragging) file(s)
    /// from a wxWidgets application is not currently supported. PS: GTK2 should work as well.
    /// </summary>
	public class FileDataObject : DataObjectSimple
	{
#region C API
		[DllImport("wx-c")] static extern IntPtr wxFileDataObject_ctor();
		[DllImport("wx-c")] static extern void wxFileDataObject_dtor(IntPtr self);
		[DllImport("wx-c")] static extern void wxFileDataObject_RegisterDisposable(IntPtr self, Virtual_Dispose onDispose);
		[DllImport("wx-c")] static extern void wxFileDataObject_AddFile(IntPtr self, IntPtr filename);
		[DllImport("wx-c")] static extern IntPtr wxFileDataObject_GetFilenames(IntPtr self);
#endregion
		
		//---------------------------------------------------------------------
		
		public FileDataObject(IntPtr wxObject)
			: base(wxObject) 
		{
			this.wxObject = wxObject;
		}
			
		internal FileDataObject(IntPtr wxObject, bool memOwn)
			: base(wxObject)
		{ 
			this.memOwn = memOwn;
			this.wxObject = wxObject;
		}
			

        static IntPtr LockedCTor()
        {
            lock (DllSync)
            {
                return wxFileDataObject_ctor();
            }
        }

		public FileDataObject()
			: this(LockedCTor(), true) 
		{
			virtual_Dispose = new Virtual_Dispose(VirtualDispose);
			wxFileDataObject_RegisterDisposable(wxObject, virtual_Dispose);
		}
		
		//---------------------------------------------------------------------
				
		public override void Dispose()
		{
			if (!disposed)
			{
                if (wxObject != IntPtr.Zero)
				{
					if (memOwn)
					{
						wxFileDataObject_dtor(wxObject);
						memOwn = false;
					}
				}
				RemoveObject(wxObject);
				wxObject = IntPtr.Zero;
                --validInstancesCount;
                disposed = true;
			}
			
			base.Dispose();
			GC.SuppressFinalize(this);
		}
		
		//---------------------------------------------------------------------
		
		~FileDataObject() 
		{
			Dispose();
		}
			
		//---------------------------------------------------------------------
			
		public void AddFile(string filename)
		{
            wxString wxFilename = wxString.SafeNew(filename);
			wxFileDataObject_AddFile(wxObject, Object.SafePtr(wxFilename));
		}
		
		public string[] Filenames
		{
			get { return new ArrayString(wxFileDataObject_GetFilenames(wxObject), true); }
		}
	}

    public class BitmapDataObject : DataObjectSimple
    {
        #region C API
		[DllImport("wx-c")] static extern IntPtr wxBitmapDataObject_ctor(IntPtr bitmap);
		[DllImport("wx-c")] static extern void wxBitmapDataObject_RegisterDisposable(IntPtr self, Virtual_Dispose onDispose);
		[DllImport("wx-c")] static extern IntPtr wxBitmapDataObject_GetBitmap(IntPtr self);
		[DllImport("wx-c")] static extern void wxBitmapDataObject_SetBitmap(IntPtr self, IntPtr bitmap);
        #endregion

        #region CTor
        static IntPtr LockedCTor(Bitmap bitmap)
        {
            lock (DllSync)
            {
                return wxBitmapDataObject_ctor(Object.SafePtr(bitmap));
            }
        }

        public BitmapDataObject(Bitmap bitmap) : base(LockedCTor(bitmap))
        {
            this.virtual_Dispose = new Virtual_Dispose(this.VirtualDispose);
            wxBitmapDataObject_RegisterDisposable(this.wxObject, this.virtual_Dispose);
        }

        public BitmapDataObject()
            : this(null)
        {
        }
        #endregion

        #region Public Properties
        public Bitmap GetBitmap()
        {
            lock (DllSync)
            {
                return new Bitmap(wxBitmapDataObject_GetBitmap(this.wxObject));
            }
        }

        public void SetBitmap(Bitmap bitmap)
        {
            wxBitmapDataObject_SetBitmap(this.wxObject, Object.SafePtr(bitmap));
        }
        #endregion
    }

    /** <summary>wx.DataObjectComposite is the simplest way to implement wx.DataObject supporting multiple formats.
    * It contains several wx.DataObjectSimple and
    * supports all formats supported by any of them.
    *
    * This class shouldn't be (normally) derived from, but may be used directly.
    * If you need more flexibility than what it provides, you should probably use
    * wxDataObject directly.
    * </summary>
    */
    public class DataObjectComposite : DataObject
    {
        #region C API
        [DllImport("wx-c")]
        static extern IntPtr wxDataObjectComposite_ctor();
        [DllImport("wx-c")]
        static extern void wxDataObjectComposite_RegisterDisposable(IntPtr self, Virtual_Dispose onDispose);
        [DllImport("wx-c")]
        static extern void wxDataObjectComposite_Add(IntPtr self, IntPtr simpleDataobject, bool preferred);
        [DllImport("wx-c")]
        static extern IntPtr wxDataObjectComposite_GetReceivedFormat(IntPtr self);
        #endregion

        #region CTor
        static IntPtr LockedCTor()
        {
            lock (DllSync)
            {
                return wxDataObjectComposite_ctor();
            }
        }

        public DataObjectComposite()
            : base(LockedCTor())
        {
            this.virtual_Dispose = new Virtual_Dispose(this.VirtualDispose);
            wxDataObjectComposite_RegisterDisposable(this.wxObject, this.virtual_Dispose);
        }
        #endregion

        #region Methods
        /** <summary>Add data object (it will be deleted by wx.DataObjectComposite).
         * </summary>
         * <param name="preferred"> specifies with <c>true</c>, that the format of <c>newPart</c> will become the preferred one.
         * </param>
         */
        public void Add(DataObjectSimple newPart, bool preferred)
        {
            if (!newPart.memOwn)
                throw new Exception("Cannot accept an already used instance of a simple data object as part of a composite.");
            newPart.memOwn=false;
            wxDataObjectComposite_Add(this.wxObject, Object.SafePtr(newPart), preferred);
        }

        /** <summary>Add data object (it will be deleted by wx.DataObjectComposite).
        * The format of <c>newPart</c> will become the preferred one.</summary>*/
        public void Add(DataObjectSimple newPart)
        {
            this.Add(newPart, true);
        }

        /** <summary>Report the format passed to the SetData method.
        * This should be the
        * format of the data object within the composite that recieved data from
        * the clipboard or the DnD operation.  You can use this method to find
        * out what kind of data object was recieved.</summary>*/
        public wx.DataFormat GetReceivedFormat()
        {
            return new DataFormat(wxDataObjectComposite_GetReceivedFormat(this.wxObject));
        }

        #endregion
    }
}
