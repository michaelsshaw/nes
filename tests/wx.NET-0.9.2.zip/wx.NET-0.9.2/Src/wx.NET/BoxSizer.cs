//-----------------------------------------------------------------------------
// wx.NET - Sizer.cs
//
// The wxBoxSizer wrapper class.
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: BoxSizer.cs,v 1.17 2009/12/12 10:36:37 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Drawing;
using System.Runtime.InteropServices;

namespace wx
{
    /** <summary>Wrapps the  wxWidgets <c>wxBoxSizer</c> class, the most frequently used specification of dynamic layouts.</summary><remarks>
     * 
     * The basic idea behind a wxBoxSizer is that windows will most often be laid out in
     * rather simple basic geometry, typically in a row or a column or several
     * hierarchies of either.
     *
     * As an example, we will construct a dialog that will contain a text field at the
     * top and two buttons at the bottom. This can be seen as a top-hierarchy column with
     * the text at the top and buttons at the bottom and a low-hierarchy row with an
     * OK button to the left and a Cancel button to the right. In many cases
     * (particularly dialogs under Unix and normal frames) the main window will be
     * resizable by the user and this change of size will have to get propagated to
     * its children. In our case, we want the text area to grow with the dialog, whereas
     * the button shall have a fixed size. In addition, there will be a thin border
     * around all controls to make the dialog look nice and - to make matter worse - the
     * buttons shall be centred as the width of the dialog changes.
     * 
     * It is the unique feature of a box sizer, that it can grow in both directions
     * (height and width) but can distribute its growth in the main direction (horizontal
     * for a row) unevenly among its children. In our example case, the vertical sizer
     * is supposed to propagate all its height changes to only the text area, not to the
     * button area. This is determined by the proportion parameter when adding a window
     * (or another sizer) to a sizer. It is interpreted as a weight factor, i.e. it can
     * be zero, indicating that the window may not be resized at all, or above zero.
     * If several windows have a value above zero, the value is interpreted relative
     * to the sum of all weight factors of the sizer, so when adding two windows with
     * a value of 1, they will both get resized equally much and each half as much as
     * the sizer owning them. Then what do we do when a column sizer changes its width?
     * This behaviour is controlled by flags (the second parameter of the wx.Sizer.Add()
     * function): Zero or no flag indicates that the window will preserve it is original
     * size, wx.SizerFlag.wxGROW flag (same as wx.SizerFlag.wxEXPAND) forces the window
     * to grow with the sizer, and wx.SizerFlag.wxSHAPED flag tells the window to change
     * it is size proportionally, preserving original aspect ratio. When
     * wx.SizerFlag.wxGROW flag is not used, the item can be aligned within available
     * space. wx.SizerFlag.wxALIGN_LEFT, wx.SizerFlag.wxALIGN_TOP,
     * wx.SizerFlag.wxALIGN_RIGHT, wx.SizerFlag.wxALIGN_BOTTOM,
     * wx.SizerFlag.wxALIGN_CENTER_HORIZONTAL and wx.SizerFlag.wxALIGN_CENTER_VERTICAL do
     * what they say. wx.SizerFlag.wxALIGN_CENTRE (same as wx.SizerFlag.wxALIGN_CENTER)
     * is defined as
     * \verbatim
     (wx.SizerFlag.wxALIGN_CENTER_HORIZONTAL | wx.SizerFlag.wxALIGN_CENTER_VERTICAL).
     \endverbatim
     * Default alignment is <c>wx.SizerFlag.wxALIGN_LEFT</c> \c | <c>wx.SizerFlag.wxALIGN_TOP</c>.
     * 
     * As mentioned above, any window belonging to a sizer may have border, and it can be specified which of the four sides may have this border, using the wxTOP, wxLEFT, wxRIGHT and wxBOTTOM constants or wxALL for all directions (and you may also use wxNORTH, wxWEST etc instead). These flags can be used in combination with the alignment flags above as the second parameter of the Add() method using the binary or operator |. The sizer of the border also must be made known, and it is the third parameter in the Add() method. This means, that the entire behaviour of a sizer and its children can be controlled by the three parameters of the Add() method.
     *
     * <code>
     * 
     * // we want to get a dialog that is stretchable because it
     * // has a text ctrl at the top and two buttons at the bottom
     * 
     * MyDialog(Frame *parent, int id, string title )
     *   : Dialog(parent, id, title, wxDefaultPosition, wxDefaultSize,
     *               DIALOG_DEFAULT_STYLE | RESIZE_BORDER)
     * {
     *   BoxSizer topsizer = new BoxSizer( Orientation.wxVERTICAL );
     * 
     *   // create text ctrl with minimal size 100x60
     *   topsizer.Add(
     *     new TextCtrl( this, -1, "My text.", wxDefaultPosition, wxSize(100,60), TE_MULTILINE),
     *     1,                      // make vertically stretchable
     *     SizerFlag.wxEXPAND |    // make horizontally stretchable
     *     SizerFlag.wxALL,        //   and make border all around
     *     10 );                   // set border width to 10
     * 
     * 
     *   BoxSizer button_sizer = new BoxSizer( Orientation.wxHORIZONTAL );
     *   button_sizer.Add(
     *      new Button( this, -1, "OK" ),
     *      0,                  // make horizontally unstretchable
     *      SizerFlag.wxALL,    // make border all around (implicit top alignment)
     *      10 );               // set border width to 10
     *   button_sizer.Add(
     *      new Button( this, -1, "Cancel" ),
     *      0,                  // make horizontally unstretchable
     *      SizerFlag.wxALL,    // make border all around (implicit top alignment)
     *      10 );               // set border width to 10
     * 
     *   topsizer.Add(
     *      button_sizer,
     *      0,                           // make vertically unstretchable
     *      SizerFlag.wxALIGN_CENTER );  // no border and centre horizontally
     * 
     *   this.SetSizer( topsizer );      // use the sizer for layout
     * 
     *   topsizer.SetSizeHints( this ); // set size hints to honour minimum size
     * }
     * </code>
     * Note that the new way of specifying flags to wxSizer is via wxSizerFlags. This class greatly eases the burden of passing flags to a wxSizer.
     * Here's how you'd do the previous example with wxSizerFlags:
     * 
     * <code>
     * // we want to get a dialog that is stretchable because it
     * // has a text ctrl at the top and two buttons at the bottom
     * 
     * MyDialog(Frame *parent, int id, string title )
     *        : Dialog(parent, id, title, wxDefaultPosition, wxDefaultSize,
     *                    DIALOG_DEFAULT_STYLE | RESIZE_BORDER)
     * {
     *   BoxSizer topsizer = new BoxSizer( Orientation.wxVERTICAL );
     * 
     *   // create text ctrl with minimal size 100x60 that is horizontally and 
     *   // vertically stretchable with a border width of 10
     *   topsizer.Add(
     *     new TextCtrl( this, -1, "My text.", wxDefaultPosition, new Size(100,60), TE_MULTILINE),
     *     SizerFlag.wxALIGN|SizerFlag.wxEXPAND|SizerFlag.wxALL, 10);
     * 
     *   BoxSizer button_sizer = new BoxSizer( Orientation.wxHORIZONTAL );
     * 
     *   //create two buttons that are horizontally unstretchable, 
     *   // with an all-around border with a width of 10 and implicit top alignment
     *   button_sizer.Add(
     *      new Button( this, -1, "OK" ),
     *      SizerFlag.wxEXPAND|SiserFlag.wxALL, 10);       
     * 
     *   button_sizer.Add(
     *      new Button( this, -1, "Cancel" ),
     *      SizerFlag.wxALIGN|SizerFlags.wxEXPAND|SizerFlags.wxALL, 10);    
     * 
     *   //create a sizer with no border and centered horizontally
     *   topsizer.Add(
     *      button_sizer,
     *      SizerFlag.wxALIGN_CENTER ); 
     * 
     *   this.SetSizer( topsizer );      // use the sizer for layout
     * 
     *   topsizer.SetSizeHints( this );  // set size hints to honour minimum size
     * }
     * </code>
     * </remarks>
     */
    public class BoxSizer : Sizer
	{
		private delegate void Virtual_voidvoid();
		private delegate IntPtr Virtual_wxSizevoid();
		
		private Virtual_voidvoid recalcSizes;
		
		[DllImport("wx-c")] static extern void wxBoxSizer_RegisterVirtual(IntPtr self, Virtual_voidvoid recalcSizes);	
		[DllImport("wx-c")] static extern void wxBoxSizer_RegisterDisposable(IntPtr self, Virtual_Dispose onDispose);
	
		[DllImport("wx-c")] static extern IntPtr wxBoxSizer_ctor(int orient);
		[DllImport("wx-c")] static extern void wxBoxSizer_RecalcSizes(IntPtr self);
        [DllImport("wx-c")] static extern int wxBoxSizer_GetOrientation(IntPtr self);
		[DllImport("wx-c")] static extern void wxBoxSizer_SetOrientation(IntPtr self, int orient);

		//---------------------------------------------------------------------

		public BoxSizer(IntPtr wxObject)
			: base(wxObject) { }

        static IntPtr LockedCTor(wx.Orientation orient)
        {
            lock (DllSync)
            {
                return wxBoxSizer_ctor((int)orient);
            }
        }

        /** <summary>Creates a new sizer of the designated orientation.
         * Refer to class wx.Orientation for applicable flags.
         *</summary>*/
		public BoxSizer(wx.Orientation orient)
            : this(LockedCTor(orient)) 
		{ 
			recalcSizes = new Virtual_voidvoid(RecalcSizes);
			wxBoxSizer_RegisterVirtual(wxObject, recalcSizes);
			
			virtual_Dispose = new Virtual_Dispose(VirtualDispose);
			wxBoxSizer_RegisterDisposable(wxObject, virtual_Dispose);
		}
			
		//---------------------------------------------------------------------
		
		public override void RecalcSizes()
		{
			wxBoxSizer_RecalcSizes(wxObject);
		}
		
		//---------------------------------------------------------------------
				
		public int Orientation
		{
			get { return wxBoxSizer_GetOrientation(wxObject); }
			set { wxBoxSizer_SetOrientation(wxObject, value); }
		}
	}
}
