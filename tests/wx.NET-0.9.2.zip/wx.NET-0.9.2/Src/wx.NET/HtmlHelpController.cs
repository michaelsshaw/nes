//-----------------------------------------------------------------------------
// wx.NET - HtmlHelpController.cs
//
// The wxHtmlHelpController wrapper class
//
// Written by Alexander Olk (xenomorph2@onlinehome.de)
// (C) 2004 by Alexander Olk
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: HtmlHelpController.cs,v 1.12 2009/11/04 17:59:10 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Runtime.InteropServices;

/** <summary>This namespace provides wrappers to the  wxWidgets help controller and html help data.
 * Refer to the implementation of the <c>helpview.exe</c> application.
 * \image html helpview.jpg "The HTML help viewer."</summary>*/
namespace wx.Html.Help
{
    public enum HelpSearchMode
    {
        wxHELP_SEARCH_INDEX,
        wxHELP_SEARCH_ALL
    }
	
    /// <summary>
    /// The help controller.
    /// </summary>
    /// <remarks>
    /// \image html htmlhelpsmall.png
    /// </remarks>
	public class HtmlHelpController : Object
	{
        #region Enumerations
        /** <summary>Some style flags for the HtmlHelpController.</summary>*/
        [Flags]
        public enum Style
        {
            TOOLBAR = 0x0001,
            CONTENTS = 0x0002,
            INDEX = 0x0004,
            SEARCH = 0x0008,
            BOOKMARKS = 0x0010,
            OPEN_FILES = 0x0020,
            PRINT = 0x0040,
            FLAT_TOOLBAR = 0x0080,
            MERGE_BOOKS = 0x0100,
            ICONS_BOOK = 0x0200,
            ICONS_BOOK_CHAPTER = 0x0400,
            ICONS_FOLDER = 0x0000, //!< this is 0 since it is default
            DEFAULT_STYLE = (int) (TOOLBAR | CONTENTS | INDEX | SEARCH | BOOKMARKS |PRINT)
        }
        #endregion

        //-----------------------------------------------------------------------------
	
		[DllImport("wx-c")] static extern IntPtr wxHtmlHelpController_ctor(uint style);
        [DllImport("wx-c")] static extern void wxHtmlHelpController_SetTitleFormat(IntPtr self, IntPtr format);
        [DllImport("wx-c")] static extern void wxHtmlHelpController_SetTempDir(IntPtr self, IntPtr path);
        [DllImport("wx-c")] static extern bool wxHtmlHelpController_AddBook(IntPtr self, IntPtr book_url);
        [DllImport("wx-c")] static extern bool wxHtmlHelpController_Display(IntPtr self, IntPtr x);
		[DllImport("wx-c")] static extern bool   wxHtmlHelpController_DisplayInt(IntPtr self, int id);
		[DllImport("wx-c")] static extern bool   wxHtmlHelpController_DisplayContents(IntPtr self);
		[DllImport("wx-c")] static extern bool   wxHtmlHelpController_DisplayIndex(IntPtr self);
        [DllImport("wx-c")] static extern bool wxHtmlHelpController_KeywordSearch(IntPtr self, IntPtr keyword, int mode);
        [DllImport("wx-c")] static extern void wxHtmlHelpController_UseConfig(IntPtr self, IntPtr config, IntPtr rootpath);
        [DllImport("wx-c")] static extern void wxHtmlHelpController_ReadCustomization(IntPtr self, IntPtr cfg, IntPtr path);
        [DllImport("wx-c")] static extern void wxHtmlHelpController_WriteCustomization(IntPtr self, IntPtr cfg, IntPtr path);
		[DllImport("wx-c")] static extern IntPtr wxHtmlHelpController_GetFrame(IntPtr self);
        [DllImport("wx-c")] static extern void wxHtmlHelpController_OnCloseFrame(IntPtr self, IntPtr closeEvent);
		//-----------------------------------------------------------------------------
		
		public HtmlHelpController(IntPtr wxObject)
			: base(wxObject) {}
			
		public HtmlHelpController()
			: this(Style.DEFAULT_STYLE) {}
			
		public HtmlHelpController(Style style)
			: base(wxHtmlHelpController_ctor((uint)style)) {}
			
		//-----------------------------------------------------------------------------
		
        /** <summary>This property is for writing only and set the title format.</summary>*/
		public string TitleFormat
		{
			set
            {
                wxString wxValue = new wxString(value);
                wxHtmlHelpController_SetTitleFormat(this.wxObject, wxValue.wxObject);
            }
		}
		
		//-----------------------------------------------------------------------------
		
        /** <summary>Write-only property to set the directory for temporary files (option for better performance).</summary>*/
		public string TempDir 
		{
			set
            {
                wxString wxValue = new wxString(value);
                wxHtmlHelpController_SetTempDir(this.wxObject, wxValue.wxObject);
            }
		}
		
		//-----------------------------------------------------------------------------
		
		/** <summary>Adds the book at the provided file name.
		  * In contrast to the  wxWidgets version, this method
		  * silently installs the  wx file handler for zip file
		  * entries. The file system is currently not wrapped since
		  * the .NET framework implements most of the provided functions.
		  * However, handling of zip-archives is required to deal with
		  * hyper text books (HTB), so this ability will be installed on
		  * using it.</summary>*/
		public bool AddBook(string book_url)
		{
            using (wxString wxbookurl = new wxString(book_url))
            {
                return AddBook(new wxString(wxbookurl));
            }
		}
        public bool AddBook(wxString book_url)
        {
            return wxHtmlHelpController_AddBook(wxObject, book_url.wxObject);
        }
		
		//-----------------------------------------------------------------------------
		
		public bool Display(string x)
		{
            using (wxString wxx = new wxString(x))
            {
                return this.Display(wxx);
            }
		}
        public bool Display(wxString x)
        {
            return wxHtmlHelpController_Display(this.wxObject, x.wxObject);
        }
		
		//-----------------------------------------------------------------------------
		
		public bool Display(int id)
		{
			return wxHtmlHelpController_DisplayInt(wxObject, id); 
		}
		
		//-----------------------------------------------------------------------------
		
		public bool DisplayContents()
		{
			return wxHtmlHelpController_DisplayContents(wxObject);
		}
		
		//-----------------------------------------------------------------------------
		
		public bool DisplayIndex()
		{
			return wxHtmlHelpController_DisplayIndex(wxObject);
		}
		
		//-----------------------------------------------------------------------------
		
		public bool KeywordSearch(string keyword)
		{
			return KeywordSearch(keyword, HelpSearchMode.wxHELP_SEARCH_ALL);
		}
		
		public bool KeywordSearch(string keyword, HelpSearchMode mode)
		{
			return this.KeywordSearch(new wxString(keyword), mode);
		}
        public bool KeywordSearch(wxString keyword, HelpSearchMode mode)
        {
            return wxHtmlHelpController_KeywordSearch(wxObject, keyword.wxObject, (int)mode);
        }
		
		//-----------------------------------------------------------------------------
		
		public void UseConfig(Config config)
		{
			UseConfig(config, "");
		}
		
		public void UseConfig(Config config, string rootpath)
		{
			this.UseConfig(config, new wxString(rootpath));
		}
        public void UseConfig(Config config, wxString rootpath)
        {
            wxHtmlHelpController_UseConfig(wxObject, Object.SafePtr(config), rootpath.wxObject);
        }
		
		//-----------------------------------------------------------------------------
		
		public void ReadCustomization(Config cfg)
		{
			ReadCustomization(cfg, "");
		}
		
		public void ReadCustomization(Config cfg, string path)
		{
			this.ReadCustomization(cfg, new wxString(path));
		}
        public void ReadCustomization(Config cfg, wxString path)
        {
            wxHtmlHelpController_ReadCustomization(wxObject, Object.SafePtr(cfg), path.wxObject);
        }
		
		//-----------------------------------------------------------------------------
		
		public void WriteCustomization(Config cfg)
		{
			WriteCustomization(cfg, "");
		}
		
		public void WriteCustomization(Config cfg, string path)
		{
			this.WriteCustomization(cfg, new wxString(path));
		}
        public void WriteCustomization(Config cfg, wxString path)
        {
            wxHtmlHelpController_WriteCustomization(wxObject, Object.SafePtr(cfg), path.wxObject);
        }

        public void OnCloseFrame(CloseEvent evt)
        {
            wxHtmlHelpController_OnCloseFrame(this.wxObject, evt.wxObject);
        }

		//-----------------------------------------------------------------------------
		
		public Frame Frame
		{
			get { 
				IntPtr tmp = wxHtmlHelpController_GetFrame(wxObject); 
				if ( tmp != IntPtr.Zero )
					return (Frame)FindObject(tmp, typeof(Frame)); // this instance might have been selected before
				else
					return null;
			}
		}
	}
}
