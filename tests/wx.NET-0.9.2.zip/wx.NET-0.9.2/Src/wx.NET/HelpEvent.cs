//-----------------------------------------------------------------------------
// wx.NET - HelpEvent.cs
//
// The wxHelpEvent wrapper class.
//
// Written by Alexander Olk (xenomorph2@onlinehome.de)
// (C) 2004 by Alexander Olk
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: HelpEvent.cs,v 1.6 2008/04/19 21:13:26 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Drawing;
using System.Runtime.InteropServices;
using wx;

namespace wx.Html.Help
{
	public class HelpEvent : CommandEvent
	{
		[DllImport("wx-c")] static extern IntPtr wxHelpEvent_ctor(int type);
		[DllImport("wx-c")] static extern void   wxHelpEvent_GetPosition(IntPtr self, ref Point pos);
		[DllImport("wx-c")] static extern void   wxHelpEvent_SetPosition(IntPtr self, ref Point pos);
		[DllImport("wx-c")] static extern IntPtr wxHelpEvent_GetLink(IntPtr self);
		[DllImport("wx-c")] static extern void   wxHelpEvent_SetLink(IntPtr self, IntPtr link);
		[DllImport("wx-c")] static extern IntPtr wxHelpEvent_GetTarget(IntPtr self);
		[DllImport("wx-c")] static extern void   wxHelpEvent_SetTarget(IntPtr self, IntPtr target);
		
		//-----------------------------------------------------------------------------

		public HelpEvent(IntPtr wxObject) 
			: base(wxObject) { }

		public HelpEvent(int type)
			: this(wxHelpEvent_ctor(type)) { }

		//-----------------------------------------------------------------------------	
		
		public Point Position
		{
			get { 
				Point p = new Point();
				wxHelpEvent_GetPosition(wxObject, ref p); 
				return p;
			}
			
			set { wxHelpEvent_SetPosition(wxObject, ref value); }
		}
		
		//-----------------------------------------------------------------------------	
		
		public string Link
		{
			get { return new wxString(wxHelpEvent_GetLink(wxObject), true); }
			set
            {
                wxString wxValue = wxString.SafeNew(value);
                wxHelpEvent_SetLink(wxObject, Object.SafePtr(wxValue));
            }
		}
		
		//-----------------------------------------------------------------------------	
		
		public string Target
		{
			get { return new wxString(wxHelpEvent_GetTarget(wxObject), true); }
			set
            {
                wxString wxValue = wxString.SafeNew(value);
                wxHelpEvent_SetTarget(wxObject, Object.SafePtr(wxValue));
            }
		}
	}
}
