//-----------------------------------------------------------------------------
// wx.NET - Locale.cs
//
// The wxLocale wrapper class.
//
// Written by Alexander Olk (xenomorph2@onlinehome.de)
// (C) 2004 by Alexander Olk
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: Locale.cs,v 1.11 2009/10/11 16:23:20 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Runtime.InteropServices;

namespace wx
{
    /// <summary>
    /// Enumeration of langiages.
    /// </summary>
	public enum Language
	{
        /// <summary>
        /// user's default language as obtained from the operating system 
        /// </summary>
		wxLANGUAGE_DEFAULT,

        /// <summary>
        /// returned by Locale.GetSystemLanguage() if it fails to detect the default language 
        /// </summary>
		wxLANGUAGE_UNKNOWN,
		
		wxLANGUAGE_ABKHAZIAN,
		wxLANGUAGE_AFAR,
		wxLANGUAGE_AFRIKAANS,
		wxLANGUAGE_ALBANIAN,
		wxLANGUAGE_AMHARIC,
		wxLANGUAGE_ARABIC,
		wxLANGUAGE_ARABIC_ALGERIA,
		wxLANGUAGE_ARABIC_BAHRAIN,
		wxLANGUAGE_ARABIC_EGYPT,
		wxLANGUAGE_ARABIC_IRAQ,
		wxLANGUAGE_ARABIC_JORDAN,
		wxLANGUAGE_ARABIC_KUWAIT,
		wxLANGUAGE_ARABIC_LEBANON,
		wxLANGUAGE_ARABIC_LIBYA,
		wxLANGUAGE_ARABIC_MOROCCO,
		wxLANGUAGE_ARABIC_OMAN,
		wxLANGUAGE_ARABIC_QATAR,
		wxLANGUAGE_ARABIC_SAUDI_ARABIA,
		wxLANGUAGE_ARABIC_SUDAN,
		wxLANGUAGE_ARABIC_SYRIA,
		wxLANGUAGE_ARABIC_TUNISIA,
		wxLANGUAGE_ARABIC_UAE,
		wxLANGUAGE_ARABIC_YEMEN,
		wxLANGUAGE_ARMENIAN,
		wxLANGUAGE_ASSAMESE,
		wxLANGUAGE_AYMARA,
		wxLANGUAGE_AZERI,
		wxLANGUAGE_AZERI_CYRILLIC,
		wxLANGUAGE_AZERI_LATIN,
		wxLANGUAGE_BASHKIR,
		wxLANGUAGE_BASQUE,
		wxLANGUAGE_BELARUSIAN,
		wxLANGUAGE_BENGALI,
		wxLANGUAGE_BHUTANI,
		wxLANGUAGE_BIHARI,
		wxLANGUAGE_BISLAMA,
		wxLANGUAGE_BRETON,
		wxLANGUAGE_BULGARIAN,
		wxLANGUAGE_BURMESE,
		wxLANGUAGE_CAMBODIAN,
		wxLANGUAGE_CATALAN,
		wxLANGUAGE_CHINESE,
		wxLANGUAGE_CHINESE_SIMPLIFIED,
		wxLANGUAGE_CHINESE_TRADITIONAL,
		wxLANGUAGE_CHINESE_HONGKONG,
		wxLANGUAGE_CHINESE_MACAU,
		wxLANGUAGE_CHINESE_SINGAPORE,
		wxLANGUAGE_CHINESE_TAIWAN,
		wxLANGUAGE_CORSICAN,
		wxLANGUAGE_CROATIAN,
		wxLANGUAGE_CZECH,
		wxLANGUAGE_DANISH,
		wxLANGUAGE_DUTCH,
		wxLANGUAGE_DUTCH_BELGIAN,
		wxLANGUAGE_ENGLISH,
		wxLANGUAGE_ENGLISH_UK,
		wxLANGUAGE_ENGLISH_US,
		wxLANGUAGE_ENGLISH_AUSTRALIA,
		wxLANGUAGE_ENGLISH_BELIZE,
		wxLANGUAGE_ENGLISH_BOTSWANA,
		wxLANGUAGE_ENGLISH_CANADA,
		wxLANGUAGE_ENGLISH_CARIBBEAN,
		wxLANGUAGE_ENGLISH_DENMARK,
		wxLANGUAGE_ENGLISH_EIRE,
		wxLANGUAGE_ENGLISH_JAMAICA,
		wxLANGUAGE_ENGLISH_NEW_ZEALAND,
		wxLANGUAGE_ENGLISH_PHILIPPINES,
		wxLANGUAGE_ENGLISH_SOUTH_AFRICA,
		wxLANGUAGE_ENGLISH_TRINIDAD,
		wxLANGUAGE_ENGLISH_ZIMBABWE,
		wxLANGUAGE_ESPERANTO,
		wxLANGUAGE_ESTONIAN,
		wxLANGUAGE_FAEROESE,
		wxLANGUAGE_FARSI,
		wxLANGUAGE_FIJI,
		wxLANGUAGE_FINNISH,
		wxLANGUAGE_FRENCH,
		wxLANGUAGE_FRENCH_BELGIAN,
		wxLANGUAGE_FRENCH_CANADIAN,
		wxLANGUAGE_FRENCH_LUXEMBOURG,
		wxLANGUAGE_FRENCH_MONACO,
		wxLANGUAGE_FRENCH_SWISS,
		wxLANGUAGE_FRISIAN,
		wxLANGUAGE_GALICIAN,
		wxLANGUAGE_GEORGIAN,
		wxLANGUAGE_GERMAN,
		wxLANGUAGE_GERMAN_AUSTRIAN,
		wxLANGUAGE_GERMAN_BELGIUM,
		wxLANGUAGE_GERMAN_LIECHTENSTEIN,
		wxLANGUAGE_GERMAN_LUXEMBOURG,
		wxLANGUAGE_GERMAN_SWISS,
		wxLANGUAGE_GREEK,
		wxLANGUAGE_GREENLANDIC,
		wxLANGUAGE_GUARANI,
		wxLANGUAGE_GUJARATI,
		wxLANGUAGE_HAUSA,
		wxLANGUAGE_HEBREW,
		wxLANGUAGE_HINDI,
		wxLANGUAGE_HUNGARIAN,
		wxLANGUAGE_ICELANDIC,
		wxLANGUAGE_INDONESIAN,
		wxLANGUAGE_INTERLINGUA,
		wxLANGUAGE_INTERLINGUE,
		wxLANGUAGE_INUKTITUT,
		wxLANGUAGE_INUPIAK,
		wxLANGUAGE_IRISH,
		wxLANGUAGE_ITALIAN,
		wxLANGUAGE_ITALIAN_SWISS,
		wxLANGUAGE_JAPANESE,
		wxLANGUAGE_JAVANESE,
		wxLANGUAGE_KANNADA,
		wxLANGUAGE_KASHMIRI,
		wxLANGUAGE_KASHMIRI_INDIA,
		wxLANGUAGE_KAZAKH,
		wxLANGUAGE_KERNEWEK,
		wxLANGUAGE_KINYARWANDA,
		wxLANGUAGE_KIRGHIZ,
		wxLANGUAGE_KIRUNDI,
		wxLANGUAGE_KONKANI,
		wxLANGUAGE_KOREAN,
		wxLANGUAGE_KURDISH,
		wxLANGUAGE_LAOTHIAN,
		wxLANGUAGE_LATIN,
		wxLANGUAGE_LATVIAN,
		wxLANGUAGE_LINGALA,
		wxLANGUAGE_LITHUANIAN,
		wxLANGUAGE_MACEDONIAN,
		wxLANGUAGE_MALAGASY,
		wxLANGUAGE_MALAY,
		wxLANGUAGE_MALAYALAM,
		wxLANGUAGE_MALAY_BRUNEI_DARUSSALAM,
		wxLANGUAGE_MALAY_MALAYSIA,
		wxLANGUAGE_MALTESE,
		wxLANGUAGE_MANIPURI,
		wxLANGUAGE_MAORI,
		wxLANGUAGE_MARATHI,
		wxLANGUAGE_MOLDAVIAN,
		wxLANGUAGE_MONGOLIAN,
		wxLANGUAGE_NAURU,
		wxLANGUAGE_NEPALI,
		wxLANGUAGE_NEPALI_INDIA,
		wxLANGUAGE_NORWEGIAN_BOKMAL,
		wxLANGUAGE_NORWEGIAN_NYNORSK,
		wxLANGUAGE_OCCITAN,
		wxLANGUAGE_ORIYA,
		wxLANGUAGE_OROMO,
		wxLANGUAGE_PASHTO,
		wxLANGUAGE_POLISH,
		wxLANGUAGE_PORTUGUESE,
		wxLANGUAGE_PORTUGUESE_BRAZILIAN,
		wxLANGUAGE_PUNJABI,
		wxLANGUAGE_QUECHUA,
		wxLANGUAGE_RHAETO_ROMANCE,
		wxLANGUAGE_ROMANIAN,
		wxLANGUAGE_RUSSIAN,
		wxLANGUAGE_RUSSIAN_UKRAINE,
		wxLANGUAGE_SAMOAN,
		wxLANGUAGE_SANGHO,
		wxLANGUAGE_SANSKRIT,
		wxLANGUAGE_SCOTS_GAELIC,
		wxLANGUAGE_SERBIAN,
		wxLANGUAGE_SERBIAN_CYRILLIC,
		wxLANGUAGE_SERBIAN_LATIN,
		wxLANGUAGE_SERBO_CROATIAN,
		wxLANGUAGE_SESOTHO,
		wxLANGUAGE_SETSWANA,
		wxLANGUAGE_SHONA,
		wxLANGUAGE_SINDHI,
		wxLANGUAGE_SINHALESE,
		wxLANGUAGE_SISWATI,
		wxLANGUAGE_SLOVAK,
		wxLANGUAGE_SLOVENIAN,
		wxLANGUAGE_SOMALI,
		wxLANGUAGE_SPANISH,
		wxLANGUAGE_SPANISH_ARGENTINA,
		wxLANGUAGE_SPANISH_BOLIVIA,
		wxLANGUAGE_SPANISH_CHILE,
		wxLANGUAGE_SPANISH_COLOMBIA,
		wxLANGUAGE_SPANISH_COSTA_RICA,
		wxLANGUAGE_SPANISH_DOMINICAN_REPUBLIC,
		wxLANGUAGE_SPANISH_ECUADOR,
		wxLANGUAGE_SPANISH_EL_SALVADOR,
		wxLANGUAGE_SPANISH_GUATEMALA,
		wxLANGUAGE_SPANISH_HONDURAS,
		wxLANGUAGE_SPANISH_MEXICAN,
		wxLANGUAGE_SPANISH_MODERN,
		wxLANGUAGE_SPANISH_NICARAGUA,
		wxLANGUAGE_SPANISH_PANAMA,
		wxLANGUAGE_SPANISH_PARAGUAY,
		wxLANGUAGE_SPANISH_PERU,
		wxLANGUAGE_SPANISH_PUERTO_RICO,
		wxLANGUAGE_SPANISH_URUGUAY,
		wxLANGUAGE_SPANISH_US,
		wxLANGUAGE_SPANISH_VENEZUELA,
		wxLANGUAGE_SUNDANESE,
		wxLANGUAGE_SWAHILI,
		wxLANGUAGE_SWEDISH,
		wxLANGUAGE_SWEDISH_FINLAND,
		wxLANGUAGE_TAGALOG,
		wxLANGUAGE_TAJIK,
		wxLANGUAGE_TAMIL,
		wxLANGUAGE_TATAR,
		wxLANGUAGE_TELUGU,
		wxLANGUAGE_THAI,
		wxLANGUAGE_TIBETAN,
		wxLANGUAGE_TIGRINYA,
		wxLANGUAGE_TONGA,
		wxLANGUAGE_TSONGA,
		wxLANGUAGE_TURKISH,
		wxLANGUAGE_TURKMEN,
		wxLANGUAGE_TWI,
		wxLANGUAGE_UIGHUR,
		wxLANGUAGE_UKRAINIAN,
		wxLANGUAGE_URDU,
		wxLANGUAGE_URDU_INDIA,
		wxLANGUAGE_URDU_PAKISTAN,
		wxLANGUAGE_UZBEK,
		wxLANGUAGE_UZBEK_CYRILLIC,
		wxLANGUAGE_UZBEK_LATIN,
		wxLANGUAGE_VIETNAMESE,
		wxLANGUAGE_VOLAPUK,
		wxLANGUAGE_WELSH,
		wxLANGUAGE_WOLOF,
		wxLANGUAGE_XHOSA,
		wxLANGUAGE_YIDDISH,
		wxLANGUAGE_YORUBA,
		wxLANGUAGE_ZHUANG,
		wxLANGUAGE_ZULU,
		
		wxLANGUAGE_USER_DEFINED
	}
	
	//-----------------------------------------------------------------------------
	
	public enum LocaleCategory
	{
		wxLOCALE_CAT_NUMBER,
		wxLOCALE_CAT_DATE,
		wxLOCALE_CAT_MONEY,
		wxLOCALE_CAT_MAX
	}
	
	//-----------------------------------------------------------------------------

	public enum LocaleInfo
	{
		wxLOCALE_THOUSANDS_SEP,
		wxLOCALE_DECIMAL_POINT
	}
	
	//-----------------------------------------------------------------------------

    /** <summary>Flags for initializing instances of Locale.
     * Please note that wxLOCALE_CONV_ENCODING() shall be avoided on unicode builds.</summary>
     * */
    [Flags]
    public enum LocaleInitFlags
	{
        /** <summary>Load the message catalog for the given locale containing the translations of standard wxWidgets messages automatically.</summary>
         */
		wxLOCALE_LOAD_DEFAULT  = 0x0001,

        /** <summary>This will cause wxWidgets to convert all imported
         * catalogs into the current standard encoding (like western-1259-1).
         * Since this is always wrong on unicode builds, this flag will silently
         * be ignored then.</summary>
         */
        wxLOCALE_CONV_ENCODING = 0x0002 
	}
	
	//-----------------------------------------------------------------------------
	
	public class LanguageInfo : Object
	{
		[DllImport("wx-c")] static extern IntPtr wxLanguageInfo_ctor();
		[DllImport("wx-c")] static extern void   wxLanguageInfo_dtor(IntPtr self);
		[DllImport("wx-c")] static extern void   wxLanguageInfo_SetLanguage(IntPtr self, int value);
		[DllImport("wx-c")] static extern int    wxLanguageInfo_GetLanguage(IntPtr self);
		[DllImport("wx-c")] static extern void   wxLanguageInfo_SetCanonicalName(IntPtr self, IntPtr name);
		[DllImport("wx-c")] static extern IntPtr wxLanguageInfo_GetCanonicalName(IntPtr self);
        [DllImport("wx-c")] static extern void   wxLanguageInfo_SetDescription(IntPtr self, IntPtr name);
		[DllImport("wx-c")] static extern IntPtr wxLanguageInfo_GetDescription(IntPtr self);
		
		//-----------------------------------------------------------------------------

		public LanguageInfo(IntPtr wxObject)
			: base(wxObject)
		{
			this.wxObject = wxObject;
		}
			
		internal LanguageInfo(IntPtr wxObject, bool memOwn)
			: base(wxObject)
		{
			this.memOwn = memOwn;
			this.wxObject = wxObject;
		}
		
		public LanguageInfo()
			: this(wxLanguageInfo_ctor(), true) {}
		
		//---------------------------------------------------------------------

		public override void Dispose()
		{
			if (!disposed)
			{
                if (wxObject != IntPtr.Zero)
				{
					if (memOwn)
					{
						wxLanguageInfo_dtor(wxObject);
					}
				}
				RemoveObject(wxObject);
				wxObject = IntPtr.Zero;
                --validInstancesCount;
                disposed = true;
			}
			
			virtual_Dispose = null;
			base.Dispose();
			GC.SuppressFinalize(this);
		}
		
		//---------------------------------------------------------------------
		
		~LanguageInfo() 
		{
			Dispose();
		}
		
		//---------------------------------------------------------------------
		
		public Language Language
		{
			get { return (Language)wxLanguageInfo_GetLanguage(wxObject); }
			set { wxLanguageInfo_SetLanguage(wxObject, (int)value); }
		}
		
		//---------------------------------------------------------------------
		
		public string CanonicalName
		{
			get { return new wxString(wxLanguageInfo_GetCanonicalName(wxObject), true); }
			set
            {
                wxString wxValue = wxString.SafeNew(value);
                wxLanguageInfo_SetCanonicalName(wxObject, wxValue.wxObject);
            }
		}
		
		//---------------------------------------------------------------------
		
		public string Description
		{
			get { return new wxString(wxLanguageInfo_GetDescription(wxObject), true); }
			set
            {
                wxString wxValue = wxString.SafeNew(value);
                wxLanguageInfo_SetDescription(wxObject, wxValue.wxObject);
            }
		}
	}
	
	//-----------------------------------------------------------------------------

    /** <summary>This class wrapps <c>wxLocale</c>.</summary>
     */
	public class Locale : Object
	{
		[DllImport("wx-c")] static extern IntPtr wxLocale_ctor();
		[DllImport("wx-c")] static extern IntPtr wxLocale_ctor2(int language, int flags);
		[DllImport("wx-c")] static extern void   wxLocale_dtor(IntPtr self);
		[DllImport("wx-c")] static extern int    wxLocale_Init(IntPtr self, int language, int flags);
		[DllImport("wx-c")] static extern int    wxLocale_AddCatalog(IntPtr self, IntPtr szDomain);
		[DllImport("wx-c")] static extern int    wxLocale_AddCatalog2(IntPtr self, IntPtr szDomain, int msgIdLanguage, IntPtr msgIdCharset);
		[DllImport("wx-c")] static extern void   wxLocale_AddCatalogLookupPathPrefix(IntPtr self, IntPtr prefix);
		[DllImport("wx-c")] static extern void   wxLocale_AddLanguage(IntPtr info);
        [DllImport("wx-c")] static extern IntPtr wxLocale_FindLanguageInfo(IntPtr locale);
		[DllImport("wx-c")] static extern IntPtr wxLocale_GetCanonicalName(IntPtr self);
		[DllImport("wx-c")] static extern int    wxLocale_GetLanguage(IntPtr self);
		[DllImport("wx-c")] static extern IntPtr wxLocale_GetLanguageInfo(int lang);
		[DllImport("wx-c")] static extern IntPtr wxLocale_GetLanguageName(int lang);
		[DllImport("wx-c")] static extern IntPtr wxLocale_GetLocale(IntPtr self);
		[DllImport("wx-c")] static extern IntPtr wxLocale_GetName(IntPtr self);
        [DllImport("wx-c")] static extern IntPtr wxLocale_GetString(IntPtr self, IntPtr szOrigString, IntPtr szDomain);
        [DllImport("wx-c")] static extern IntPtr wxLocale_GetHeaderValue(IntPtr self, IntPtr szHeader, IntPtr szDomain);
		[DllImport("wx-c")] static extern IntPtr wxLocale_GetSysName(IntPtr self);
		[DllImport("wx-c")] static extern int    wxLocale_GetSystemEncoding();
		[DllImport("wx-c")] static extern IntPtr wxLocale_GetSystemEncodingName();
		[DllImport("wx-c")] static extern int    wxLocale_GetSystemLanguage();
		[DllImport("wx-c")] static extern int    wxLocale_IsLoaded(IntPtr self, IntPtr domain);
		[DllImport("wx-c")] static extern int    wxLocale_IsOk(IntPtr self);
		
		//-----------------------------------------------------------------------------

		public Locale(IntPtr wxObject)
			: base(wxObject)
		{
			this.wxObject = wxObject;
		}
			
		internal Locale(IntPtr wxObject, bool memOwn)
			: base(wxObject)
		{
			this.memOwn = memOwn;
			this.wxObject = wxObject;
		}
		
		public Locale()
			: this(wxLocale_ctor(), true) {}

        public Locale(Language language)
			: this(language, LocaleInitFlags.wxLOCALE_LOAD_DEFAULT | LocaleInitFlags.wxLOCALE_CONV_ENCODING) {}

        public Locale(Language language, LocaleInitFlags flags)
			: this(wxLocale_ctor2((int)language, (int)flags), true) {}
		
		//---------------------------------------------------------------------

		public override void Dispose()
		{
			if (!disposed)
			{
                if (wxObject != IntPtr.Zero)
				{
					if (memOwn)
					{
						wxLocale_dtor(wxObject);
					}
				}
				RemoveObject(wxObject);
				wxObject = IntPtr.Zero;
                --validInstancesCount;
                disposed = true;
			}
			
			virtual_Dispose = null;
			base.Dispose();
			GC.SuppressFinalize(this);
		}
		
		//---------------------------------------------------------------------
		
		~Locale() 
		{
			Dispose();
		}
		
		//-----------------------------------------------------------------------------

        /// <summary>
        /// Initializes this locale with the users default language as obtained from the operating system.
        /// </summary>
        /// <returns>True on success and false if the locale has not been set.</returns>
        public bool Init()
		{
			return Init(Language.wxLANGUAGE_DEFAULT, LocaleInitFlags.wxLOCALE_LOAD_DEFAULT | LocaleInitFlags.wxLOCALE_CONV_ENCODING);
		}
		
        /// <summary>
        /// Initializes this locale with the provided language.
        /// </summary>
        /// <param name="language">Language to be used for translation.</param>
        /// <returns>True on success and false if the locale has not been set.</returns>
		public bool Init(Language language)
		{
			return Init(language,  LocaleInitFlags.wxLOCALE_LOAD_DEFAULT | LocaleInitFlags.wxLOCALE_CONV_ENCODING);
		}

        /// <summary>
        /// Initializes this locale with the provided language.
        /// </summary>
        /// <param name="language">Language to be used for translation.</param>
        /// <param name="flags">Flags</param>
        /// <returns>True on success and false if the locale has not been set.</returns>
        public bool Init(Language language, LocaleInitFlags flags)
		{
			return wxLocale_Init(wxObject, (int)language, (int)flags) > 0;
		}
		
		//-----------------------------------------------------------------------------

        /** <summary>Add a catalog for use with the current locale: it is searched for in standard places
         * (current directory first, then the system one), but you may also prepend additional directories
         * to the search path with AddCatalogLookupPathPrefix().</summary>
         * <remarks> All loaded catalogs will be used for message lookup by GetString() for the current locale.
         *
         * Returns true if catalog was successfully loaded, false otherwise (which might mean that the catalog is not
         * found or that it isn't in the correct format).
         * </remarks>
         * <param name="szDomain">Descriptor of the domain that is covered by the requested catalog, i.e. the basename
         *  of the catalog file.</param>
         */
		public bool AddCatalog(string szDomain)
		{
            wxString wxSzDomain = new wxString(szDomain);
            return wxLocale_AddCatalog(wxObject, wxSzDomain.wxObject) > 0;
		}

        /** <summary>Add a catalog for use with the current locale: it is searched for in standard places
         * (current directory first, then the system one), but you may also prepend additional directories
         * to the search path with AddCatalogLookupPathPrefix().</summary>
         * <remarks> All loaded catalogs will be used for message lookup by GetString() for the current locale.
         *
         * Returns true if catalog was successfully loaded, false otherwise (which might mean that the catalog is not
         * found or that it isn't in the correct format).
         * </remarks>
         * <param name="szDomain">Descriptor of the domain that is covered by the requested catalog, i.e. the basename
         *  of the catalog file.</param>
         *  <param name="msgIdLanguage">The target language of translations from this catalog.</param>
         *  <param name="msgIdCharset">msgIdCharset lets you specify the charset used for msgids in sources in case they use
         *  8-bit characters (e.g. German or French strings). This argument has no effect in Unicode build, because literals
         *  in sources are Unicode strings; you have to use compiler-specific method of setting the right charset when
         *  compiling with Unicode.</param>
         */
        public bool AddCatalog(string szDomain, Language msgIdLanguage, string msgIdCharset)
		{
            wxString wxSzDomain = new wxString(szDomain);
            wxString wxMsgIdCharset = new wxString(msgIdCharset);
            return wxLocale_AddCatalog2(wxObject, wxSzDomain.wxObject, (int)msgIdLanguage, wxMsgIdCharset.wxObject) > 0;
		}
		
		//-----------------------------------------------------------------------------
		
        /// <summary>
        /// Add a prefix to the catalog lookup path: the message catalog files will be looked up under
        /// prefix/(CANONICAL_LANGUAGE_STRING)/LC_MESSAGES, prefix/(CANONICAL_LANGUAGE_STRING) and prefix (in this order).
        ///
        /// This only applies to subsequent invocations of AddCatalog().
        /// </summary>
        /// <param name="prefix">New prefix directories where to search for language catalogs.</param>
		public void AddCatalogLookupPathPrefix(string prefix)
		{
            wxString wxPrefix = new wxString(prefix);
            wxLocale_AddCatalogLookupPathPrefix(wxObject, wxPrefix.wxObject);
		}
		
		//-----------------------------------------------------------------------------
		
		public static void AddLanguage(LanguageInfo info)
		{
			wxLocale_AddLanguage(Object.SafePtr(info));
		}
		
		//-----------------------------------------------------------------------------
		
		public static LanguageInfo FindLanguageInfo(string locale)
		{
            wxString wxLocale = new wxString(locale);
			return (LanguageInfo)Object.FindObject(wxLocale_FindLanguageInfo(wxLocale.wxObject), typeof(LanguageInfo));
		}
		
		//-----------------------------------------------------------------------------
		
        /// <summary>
        /// Canonical name of the language that is used by this locale. Examples: "en", "de-de".
        /// </summary>
		public string CanonicalName
		{
			get { return new wxString(wxLocale_GetCanonicalName(wxObject), true); }
		}
		
		//-----------------------------------------------------------------------------
		
		public Language Language
		{
			get { return (Language)wxLocale_GetLanguage(wxObject); }
		}
		
		//-----------------------------------------------------------------------------
		
        /// <summary>
        /// Information struct on the language as designated by the argument.
        /// </summary>
        /// <param name="lang">The language designator. Language.wxLANGUAGE_DEFAULT will
        /// be replaced by the system language.
        /// </param>
        /// <returns>Language information</returns>
		public static LanguageInfo GetLanguageInfo(Language lang)
		{
            if (lang == Language.wxLANGUAGE_DEFAULT)
                lang = Locale.SystemLanguage;
			return (LanguageInfo)Object.FindObject(wxLocale_GetLanguageInfo((int)lang), typeof(LanguageInfo));
		}
		
		//-----------------------------------------------------------------------------

        /// <summary>
        /// Long name of the language as designated by the argument (e.g. "German").
        /// </summary>
        /// <param name="lang">The language designator. Language.wxLANGUAGE_DEFAULT will
        /// be replaced by the system language.
        /// </param>
        /// <returns>Language information</returns>
        public static string GetLanguageName(Language lang)
		{
            if (lang == Language.wxLANGUAGE_DEFAULT)
                lang = Locale.SystemLanguage;
            return new wxString(wxLocale_GetLanguageName((int)lang), true);
		}
		
		//-----------------------------------------------------------------------------
		
		public string GetLocale()
		{
			return new wxString(wxLocale_GetLocale(wxObject), true);
		}
		
		//-----------------------------------------------------------------------------
		
		public string Name
		{
			get { return new wxString(wxLocale_GetName(wxObject), true); }
		}
		
		//-----------------------------------------------------------------------------
		
		public string GetString(string szOrigString)
		{
			return GetString(szOrigString, null);
		}
		
		public string GetString(string szOrigString, string szDomain)
		{
            wxString wxSzOrigString = wxString.SafeNew(szOrigString);
            wxString wxSzDomain = wxString.SafeNew(szDomain);
			return new wxString(wxLocale_GetString(wxObject, wxSzOrigString.wxObject, wxSzDomain==null ? IntPtr.Zero : wxSzDomain.wxObject), true);
		}
		
		//-----------------------------------------------------------------------------
		
		public string GetHeaderValue(string szHeader)
		{
			return GetHeaderValue(szHeader, null);
		}
		
		public string GetHeaderValue(string szHeader, string szDomain)
		{
            wxString wxSzHeader = wxString.SafeNew(szHeader);
            wxString wxSzDomain = wxString.SafeNew(szDomain);
			return new wxString(wxLocale_GetHeaderValue(wxObject, wxSzHeader.wxObject, wxSzDomain.wxObject), true);
		}
		
		//-----------------------------------------------------------------------------
		
		public string SysName
		{
			get { return new wxString(wxLocale_GetSysName(wxObject), true); }
		}
		
		//-----------------------------------------------------------------------------
		
		public static FontEncoding SystemEncoding
		{
			get { return (FontEncoding)wxLocale_GetSystemEncoding(); }
		}
		
		//-----------------------------------------------------------------------------
		
        /// <summary>
        /// Tries to detect the name of the user's default font encoding.
        /// This string isn't particularly useful for the application as its form is platform-dependent and so you
        /// should probably use GetSystemEncoding() instead.
        ///
        /// Returns a user-readable string value or an empty string if it couldn't be determined.
        /// </summary>
		public static string SystemEncodingName
		{
			get { return new wxString(wxLocale_GetSystemEncodingName(), true); }
		}
		
		//-----------------------------------------------------------------------------
		
        /// <summary>
        /// Tries to detect the user's default language setting.
        /// Returns wxLanguage.LANGUAGE_UNKNOWN if the language-guessing algorithm failed.
        /// </summary>
		public static Language SystemLanguage
		{
			get { return (Language)wxLocale_GetSystemLanguage(); }
		}
		
		//-----------------------------------------------------------------------------
		
		public bool IsLoaded(string domain)
		{
            wxString wxDomain = wxString.SafeNew(domain);
			return wxLocale_IsLoaded(wxObject, wxDomain.wxObject) > 0;
		}
		
		//-----------------------------------------------------------------------------
		
		public bool IsOk
		{
			get { return wxLocale_IsOk(wxObject) > 0; }
		}
	}
}