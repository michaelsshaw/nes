//-----------------------------------------------------------------------------
// wx.NET - FileSys.cs
//
// Wrapper for wxWidgets file system wxInputStream, wxFSFile, wxFileSystemHandler.
//
// Written by Harald Meyer auf'm Hofe
// (C) 2006 by Harald Meyer auf'm Hofe
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: FileSys.cs,v 1.24 2010/05/08 19:52:40 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Runtime.InteropServices;
using System.IO;
using System.Text;
using System.Reflection;
using System.Diagnostics;
using wx;

/** This contains a wrapper of the \e wxWidgets file system.
 */
namespace wx.FileSys
{
    /** <summary>Analogously to class wxString, this class wraps wxInputStream.
     * Anatomy: This inherits from wx.Object and is, thus, a wx.NET wrapper class.
     * Constructors either are required by wx.Object to implement the FindObject service
     * or they pass a System.IO.Stream. This instance then serves as a wxWidgets fassade
     * to the stream that you originally provided. On instance creation, this instance
     * sets callback to implement a wxInputStream using the framework stream as source.
     * 
     * However, instances of this class may occur in another state: Without a framework
     * stream as source. In that case, the instance simply wrapps a fully functional
     * wxWidgets input stream without setting callbacks.
     *</summary>*/
    public class wxInputStreamWrapper : wx.Object
    {
        #region Callback Declarations
        private delegate int Virtual_InputStream_LastRead();
        private delegate int Virtual_InputStream_Read(IntPtr byteBuffer);
        private delegate bool Virtual_InputStream_CanRead();
        private delegate bool Virtual_InputStream_CanSeek();
        private delegate long Virtual_InputStream_Seek(long pos, System.IO.SeekOrigin fromWhere);
        private delegate long Virtual_InputStream_Tell();
        private delegate long Virtual_InputStream_GetLength();
        #endregion
        #region C API
        [DllImport("wx-c")] static extern IntPtr wxInputStreamWrapper_ctor();
        [DllImport("wx-c")] static extern void wxInputStreamWrapper_dtor(IntPtr self);
        [DllImport("wx-c")] static extern void wxInputStreamWrapper_RegisterVirtual
                        (IntPtr self,
                         Virtual_Dispose onDispose,
                         Virtual_InputStream_LastRead lastRead,
                         Virtual_InputStream_Read sysRead,
                         Virtual_InputStream_CanRead canRead,
                         Virtual_InputStream_CanSeek canSeek,
                         Virtual_InputStream_Seek seek,
                         Virtual_InputStream_Tell tell,
                         Virtual_InputStream_GetLength getLength);
        [DllImport("wx-c")] static extern void wxInputStreamWrapper_UnregisterVirtual(IntPtr self);
        //[DllImport("wx-c")] static extern byte wxInputStreamWrapper_Peek(IntPtr self);
        //[DllImport("wx-c")] static extern byte wxInputStreamWrapper_GetC(IntPtr self);
        [DllImport("wx-c")] static extern int wxInputStreamWrapper_ReadIntoBuffer(IntPtr self, IntPtr buffer);
        //[DllImport("wx-c")] static extern int wxInputStreamWrapper_LastRead(IntPtr self);
        [DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)] static extern bool wxInputStreamWrapper_CanRead(IntPtr self);
        //[DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)] static extern bool wxInputStreamWrapper_Eof(IntPtr self);
        //[DllImport("wx-c")] static extern int wxInputStreamWrapper_UngetBuffer(IntPtr self, byte[] buffer, int size);
        //[DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)] static extern bool wxInputStreamWrapper_Ungetch(IntPtr self, byte c);
        [DllImport("wx-c")] static extern long wxInputStreamWrapper_SeekI(IntPtr self, long pos, System.IO.SeekOrigin mode);
        [DllImport("wx-c")] static extern long wxInputStreamWrapper_TellI(IntPtr self);
        #endregion

        #region State
        internal Stream src;
        int lastRead = 0;
        bool seekFailed = false;

        // Saved instances of delegates to avoid undesired disposals
        Virtual_InputStream_CanRead _Virtual_InputStream_CanRead = null;
        Virtual_InputStream_CanSeek _Virtual_InputStream_CanSeek = null;
        Virtual_InputStream_LastRead _Virtual_InputStream_LastRead = null;
        Virtual_InputStream_Read _Virtual_InputStream_Read = null;
        Virtual_InputStream_Seek _Virtual_InputStream_Seek = null;
        Virtual_InputStream_Tell _Virtual_InputStream_Tell = null;
        Virtual_InputStream_GetLength _Virtual_InputStream_GetLength = null;
        #endregion

        #region CTor, DTor
        static IntPtr SyncCTor()
        {
            lock (DllSync)
            {
                return wxInputStreamWrapper_ctor();
            }
        }

        /** <summary>Generates a new  wxWidgets <c>wxInputStream</c> instance whose basic functions refer to methods of <c>src</c>.
         *</summary>*/
        public wxInputStreamWrapper(Stream src)
            : base(SyncCTor(), StorageMode.RegisteredObject, true)
        {
                this.src = src;
                virtual_Dispose=new Virtual_Dispose(this.VirtualDispose);
                _Virtual_InputStream_LastRead=new Virtual_InputStream_LastRead(this.LastReadFromSrc);
                _Virtual_InputStream_Read=new Virtual_InputStream_Read(this.ReadFromSrc);
                _Virtual_InputStream_CanRead=new Virtual_InputStream_CanRead(this.CanReadFromSrc);
                _Virtual_InputStream_CanSeek=new Virtual_InputStream_CanSeek(this.CanSeekSrc);
                _Virtual_InputStream_Seek=new Virtual_InputStream_Seek(this.SeekSrc);
                _Virtual_InputStream_Tell=new Virtual_InputStream_Tell(this.TellSrc);
                _Virtual_InputStream_GetLength = new Virtual_InputStream_GetLength(this.GetLength);
                wxInputStreamWrapper_RegisterVirtual(this.wxObject,
                    virtual_Dispose,
                    _Virtual_InputStream_LastRead,
                    _Virtual_InputStream_Read,
                    _Virtual_InputStream_CanRead,
                    _Virtual_InputStream_CanSeek,
                    _Virtual_InputStream_Seek,
                    _Virtual_InputStream_Tell,
                    _Virtual_InputStream_GetLength);
        }

        /** <summary>Generates an instance wrapping a fully functional  wxWidgets <c>wxInputStream</c>.</summary>*/
        public wxInputStreamWrapper(IntPtr wxObject)
          : base(wxObject, StorageMode.RegisteredObject, true)
        {
            this.src = new wxInputStream(this);
        }

        public override void Dispose()
        {
            if (!disposed)
            {
                lock (DllSync)
                {
                    --validInstancesCount;
                    if (wxObject != IntPtr.Zero)
                    {
                        if (memOwn)
                        {
                            wxInputStreamWrapper_dtor(wxObject);
                            memOwn = false;
                            wxInputStreamWrapper_UnregisterVirtual(wxObject);
                        }
                    }
                    RemoveObject(wxObject);
                    wxObject = IntPtr.Zero;
                    disposed = true;
                }
            }

            base.Dispose();
            GC.SuppressFinalize(this);
        }
        #endregion

        #region Public Properties
        /** <summary>This is the C# stream that is used as data source.
         * Depending of the mode of this implementation this may either be a standard System.IO.Stream
         * providing data for an internal <c>wxInputStream</c> or an instance of class wxInputStream
         * wrapping a  wxWidgets input stream.
         *</summary>*/
        public Stream Src { get { return this.src; } }

        /** <summary>This returns whether a seek operation failed in the past or the wrapped stream does not provide a current position.</summary>*/
        public bool CanSeek
        {
            get
            {
                if (!seekFailed) return false;
                return this.Src.CanSeek;
                /*
                try
                {
                    return Position >= 0;
                }
                catch (Exception)
                {
                }
                return false;
                 */
            }
        }

        public bool CanRead { get { return wxInputStreamWrapper_CanRead(wxObject); } }

        /** <summary>This is not supported.
         *</summary>*/
        public long Length
        {
            get
            {
                long result = this.GetLength();
                if (result < 0)
                    throw new NotSupportedException();
                return result;
            }
        }

        /** <summary>This will throw an <c>NotSupportedException</c> iff the wrapped <c>wxInputStream</c> does not support the analogous operation.
         *</summary>*/
        public long Position
        {
            get
            {
                long result = wxInputStreamWrapper_TellI(wxObject);
                if (result < 0)
                    throw new NotSupportedException();
                return result;
            }
            set
            {
                long result = wxInputStreamWrapper_SeekI(wxObject, value, SeekOrigin.Begin);
                if (result < 0)
                {
                    this.seekFailed = true;
                    throw new NotSupportedException();
                }
            }
        }
        #endregion

        #region Public Methods
        /** <summary>This is not supported.
         *</summary>*/
        public long Seek(long offset, SeekOrigin origin)
        {
            long result = wxInputStreamWrapper_SeekI(wxObject, offset, origin);
            if (result < 0)
            {
                this.seekFailed = true;
                throw new NotSupportedException();
            }
            return result;
        }
        public int Read(byte[] buffer, int offset, int count)
        {
            if (buffer == null)
                throw new ArgumentNullException();
            if (offset + count > buffer.Length)
                throw new ArgumentException();
            if (offset < 0 || count < 0)
                throw new ArgumentOutOfRangeException();
            int result=0;
            if (count > 0)
            {
                ByteBuffer useBuffer = new ByteBuffer(count);
                result = wxInputStreamWrapper_ReadIntoBuffer(wxObject, useBuffer.wxObject);
                for (int i = 0; i < useBuffer.SizeFilled; ++i)
                {
                    buffer[i + offset] = useBuffer[i];
                }
                //Console.Out.WriteLine(string.Format("Read {0} bytes, filled {1} of {2} bytes.", result, useBuffer.SizeFilled, useBuffer.SizeReserved));
            }
            return result;
        }
        #endregion

        #region Implementations of Delegates
        /** \name Implementations of Delegates
          */
        private int LastReadFromSrc()
        {
            return this.lastRead;
        }
        private int ReadFromSrc(IntPtr wxByteBuffer)
        {
            //Console.Out.WriteLine(string.Format("ReadFromSrc: {1}, {0}", wxByteBuffer, wxObject));
            if (this.src != null && wxByteBuffer != IntPtr.Zero)
            {
                using (ByteBuffer byteBuffer = new ByteBuffer(wxByteBuffer, StorageMode.VolatileObject, false))
                {
                    //Console.Out.WriteLine(string.Format("ReadFromSrc: Want to read {0} bytes from pos {1}.", byteBuffer.SizeReserved, src.Position));
                    //if (src.Position == 0) Console.Out.WriteLine("\n\n");
                    byte[] buffer = new byte[byteBuffer.SizeReserved];
                    this.lastRead = src.Read(buffer, 0, buffer.Length);
                    for (int i = 0; i < this.lastRead; ++i)
                    {
                        //if ((src.Position + i - this.lastRead) % 16 == 0)
                        //    Console.Out.Write(string.Format("\n{0}: ", Convert.ToString(src.Position + i - this.lastRead, 16)));
                        byteBuffer[i] = buffer[i];
                        //Console.Out.Write(string.Format("{1} ", byteBuffer[i], Convert.ToString(byteBuffer[i], 16)));
                    }
                    if (this.lastRead < buffer.Length)
                    {
                        // EOF reached.
                        this.src.Close();
                        this.src = null;
                    }
                }
                return this.lastRead;
            }
            else
            {
                //Console.Out.WriteLine("ReadFromSrc: Failure.");
                return 0;
            }
        }
        private bool CanReadFromSrc()
        {
            if (this.src != null)
                return this.src.CanRead;
            else
                return false;
        }
        private bool CanSeekSrc()
        {
            if (this.src != null)
                return this.src.CanSeek;
            else
                return false;
        }
        private long SeekSrc(long pos, System.IO.SeekOrigin fromWhere)
        {
            if (this.src != null)
                return this.src.Seek(pos, fromWhere);
            else
            {
                this.seekFailed = true;
                return -1;
            }
        }
        private long TellSrc()
        {
            if (this.src != null)
                return this.src.Position;
            else
                return -1;
        }
        /** <summary>In contrast to property Length this does not throw exceptions but returns -1.
         *</summary>*/
        public long GetLength()
        {
            if (this.src != null)
            {
                try
                {
                    return this.src.Length;
                }
                catch (Exception )
                {
                    return -1;
                }
            }
            else
                return -1;
        }
        #endregion
    }

    /** <summary>This is a .NET framework stream wrapping a  wxWidgets <c>wxInputStream</c>.
     * The wrapper of a <c>wxInputStream</c> falls into 2 parts. This is the instance that directly
     * inherits from Stream and, thus, provides a fassades compliant to the standard .NET framework.
     * Class <c>wxInputStreamWrapper</c> inherits from <c>wx.Object</c> instead and wrapps the pointer
     * to a  wxWidgets stream.
     *</summary>*/
    public class wxInputStream : Stream, IDisposable
    {
        #region State
        internal wxInputStreamWrapper src;
        #endregion

        #region CTor / DTor
        public wxInputStream(wxInputStreamWrapper src)
        {
            this.src = src;
            src.src=this;
        }

        /** <summary>Receives an IntPtr to a <c>wxInputStream</c>.
         *</summary>*/
        public wxInputStream(IntPtr wxObject)
          : this(new wxInputStreamWrapper(wxObject))
        {
        }

        /*
        new public void Dispose()
        {
            GC.SuppressFinalize(this);
        }
         */
        #endregion

        #region Public Properties
        /** <summary>Tests whether this can tell and
         *</summary>*/
        public override bool CanSeek { get { return src.CanSeek; } }
        /** <summary>This is false.</summary>*/
        public override bool CanWrite { get { return false; } }
        public override bool CanRead { get { return src.CanRead; } }
        /** <summary>This typically returns the length of the stream in position units.
         *</summary>*/
        public override long Length
        {
            get
            {
                return src.Length;
            }
        }
        /** <summary>This is supported if the source supports <c>TellI</c> and <c>SeekI</c>.
         *</summary>*/
        public override long Position
        {
            get { return src.Position; }
            set { src.Position=value; }
        }
        #endregion

        #region Public Methods
        /** <summary>This is not supported.
         *</summary>*/
        public override long Seek(long offset, SeekOrigin origin)
        {
            return src.Seek(offset, origin);
        }
        /** <summary>This is not supported.
         *</summary>*/
        public override void SetLength(long value)
        {
            throw new NotSupportedException();
        }
        public override int Read(byte[] buffer, int offset, int count)
        {
            return src.Read(buffer, offset, count);
        }
        /** <summary>This is not implemented.
         *</summary>*/
        public override void Write(byte[] buffer, int offset, int count)
        {
            throw new Exception("The method or operation is not implemented.");
        }
        public override void Flush()
        {
        }
        #endregion
    }

    /** <summary>This is a wrapper to <c>wxFSFile</c>.
     * Purpose: Provide some additional information on a file read through
     * the <c>wxWidgets</c> file system. Unfortunately, the known characteristics of a <c>wxWidgets</c> file
     * differ strongly from the <c>FileInfo</c> class: Instances of this class know s stream
     *</summary>
     */
    public class FSFile : wx.Object
    {
        #region C API
        [DllImport("wx-c")]
        static extern IntPtr wxFSFile_ctor(IntPtr aWxInputStream, IntPtr location, IntPtr mimetype, IntPtr anchor, IntPtr modificationTime);
        [DllImport("wx-c")]
        static extern void wxFSFile_SetDisposeCallback(IntPtr self, Virtual_Dispose callback);
        [DllImport("wx-c")]
        static extern void wxFSFile_UnsetDisposeCallback(IntPtr self);
        [DllImport("wx-c")]
        static extern IntPtr wxFSFile_dtor(IntPtr self);
        [DllImport("wx-c")]
        static extern IntPtr wxFSFile_GetAnchor(IntPtr self);
        [DllImport("wx-c")]
        static extern IntPtr wxFSFile_GetLocation(IntPtr self);
        [DllImport("wx-c")]
        static extern IntPtr wxFSFile_GetMimeType(IntPtr self);
        [DllImport("wx-c")]
        static extern IntPtr wxFSFile_GetStream(IntPtr self);
        [DllImport("wx-c")]
        static extern IntPtr wxFSFile_GetModificationTime(IntPtr self);
        #endregion

        #region State
        wxInputStreamWrapper _streamWrapper = null;
        #endregion

        #region CTor
        /** <summary>This CTor receives an IntPtr of a <c>wxFSFile</c>.
         *</summary>*/
        internal FSFile(IntPtr wxObject)
          : base(wxObject, StorageMode.RegisteredObject, true)
        {
        }

        static IntPtr SyncCTor(IntPtr wxStream, IntPtr location, IntPtr mimetype, IntPtr anchor, IntPtr modificationTime)
        {
            lock (DllSync)
            {
                return wxFSFile_ctor(wxStream, location, mimetype, anchor, modificationTime);
            }
        }

        /** <summary>This creates a file descriptor reading content from the provided stream.
        * Please note, that this will try to take ownership of the <c>wxObject</c> of <c>streamWrapper</c>.
        * This will raise an exception, if this operation fails.</summary>*/
        internal FSFile(wxInputStreamWrapper streamWrapper, string location, string mimetype, string anchor, DateTime modificationTime)
            : base(SyncCTor(streamWrapper.wxObject, new wxString(location).wxObject, (new wxString(mimetype)).wxObject, (new wxString(anchor)).wxObject, Object.SafePtr((wxDateTime)modificationTime)))
        {
            virtual_Dispose = new Virtual_Dispose(VirtualDispose);
            wxFSFile_SetDisposeCallback(this.wxObject, virtual_Dispose);
            if (!streamWrapper.memOwn)
                throw new Exception("Cannot take ownership of an already shared ouput stream wrapper.");
            this._streamWrapper = streamWrapper;
            this._streamWrapper.memOwn=false;
        }

        /** <summary>This creates a file descriptor reading content from the provided stream.</summary>*/
        public FSFile(Stream stream, string location, string mimetype, string anchor, DateTime modificationTime)
            : this(new wxInputStreamWrapper(stream), location, mimetype, anchor, modificationTime)
        {
        }

        public FSFile(wxInputStream stream, string location, string mimetype, string anchor, DateTime modificationTime)
            : this(stream.src, location, mimetype, anchor, modificationTime)
        {
        }
        public override void Dispose()
        {
            if (!disposed)
            {
                --validInstancesCount;
                if (wxObject != IntPtr.Zero)
                {
                    lock (DllSync)
                    {
                        if (memOwn)
                        {
                            wxFSFile_UnsetDisposeCallback(this.wxObject);
                            wxFSFile_dtor(wxObject);
                            memOwn = false;
                        }
                    }
                }
                RemoveObject(wxObject);
                wxObject = IntPtr.Zero;
                disposed = true;
            }

            base.Dispose();
            GC.SuppressFinalize(this);
        }
        #endregion

        #region Public Properties
        /** <summary>The "anchor" part of a hyper link.
             * Refer to the  wxWidgets documentation for details.
             *</summary>*/
        public string Anchor { get { return new wxString(wxFSFile_GetAnchor(wxObject)); } }

        /** <summary>The "location" of the source of the stream data.</summary><remarks>
         * This is the full location description of the file, e.g.
         * \verbatim
         http://www.wxwidgets.org
         http://www.ms.mff.cuni.cz/~vsla8348/wxhtml/archive.zip#zip:info.txt
         file:/home/vasek/index.htm
         relative-file.htm
         \endverbatim
         *</remarks>*/
        public string Location { get { return new wxString(wxFSFile_GetLocation(wxObject)); } }

        /** <summary>The mime type description (in text form).</summary>*/
        public string MimeType { get { return new wxString(wxFSFile_GetMimeType(wxObject)); } }

        /** <summary>A stream for receiving the data.
         *</summary>*/
        public Stream Stream
        {
            get
            {
                if (this._streamWrapper==null)
                    this._streamWrapper=(wxInputStreamWrapper)FindObject(wxFSFile_GetStream(wxObject), typeof(wxInputStreamWrapper));
                return this._streamWrapper.Src;
            }
        }

        public DateTime ModificationTime
        {
           get
           {
              try
              {
                 wxDateTime result = new wxDateTime(wxFSFile_GetModificationTime(wxObject));
                 return (DateTime)result;
              }
              catch (Exception exc)
              {
                 Trace.WriteLine(exc);
              }
              return new DateTime();
           }
        }

        /** <summary>A comprehensable text description of this file.
         *</summary>*/
        public override string ToString()
        {
           StringBuilder sb = new StringBuilder();
           sb.AppendFormat("FSFile: location: {0}, anchor: {1}, mime type: {2}, modification time: {3}",
              this.Location, this.Anchor, this.MimeType, this.ModificationTime);
           return sb.ToString();
        }
        #endregion
    }

    public enum KindOfFile
    {
        /** <summary>Either a directory or usual data file, I don't mind.
         *</summary>*/
        Indifferent = 0,

        /** <summary>Operate on data files only.</summary>*/
        wxFILE = 1,

        /** <summary>Operate on directories only.</summary>*/
        wxDIR = 2
    }

    /** <summary>This class wrapps  wxWidgets class <c>wxFileSystemHandler</c> and all inheritors.
     * Investigate the documetnation of subclasses for details on predefined file system
     * handlers. For instance class IOStreamFSHandler enables the implementation of  wxWidgets
     * file system handlers as streams of the .NET framework.
     *</summary>*/
    public abstract class FileSystemHandler : wx.Object
    {
        #region C API
        [DllImport("wx-c")]
        static extern bool wxFileSystemHandler_CanOpen(IntPtr self, IntPtr location);
        [DllImport("wx-c")]
        static extern IntPtr wxFileSystemHandler_FindFirst(IntPtr self, IntPtr wildcard, int kindOfFile);
        [DllImport("wx-c")]
        static extern IntPtr wxFileSystemHandler_FindNext(IntPtr self);
        [DllImport("wx-c")]
        static extern IntPtr wxFileSystemHandler_GetAnchor(IntPtr self, IntPtr location);
        [DllImport("wx-c")]
        static extern IntPtr wxFileSystemHandler_GetProtocol(IntPtr self, IntPtr location);
        [DllImport("wx-c")]
        static extern IntPtr wxFileSystemHandler_GetLeftLocation(IntPtr self, IntPtr location);
        [DllImport("wx-c")]
        static extern IntPtr wxFileSystemHandler_GetRightLocation(IntPtr self, IntPtr location);
        [DllImport("wx-c")]
        static extern IntPtr wxFileSystemHandler_GetMimeTypeFromExt(IntPtr self, IntPtr location);
        #endregion

        #region CTor
        internal FileSystemHandler(IntPtr wxObject)
            : base(wxObject)
        {
        }
        #endregion

        #region Private calls to original implementations
        bool OriginalCanOpen(string location)
        {
            wxString wxLocation = new wxString(location);
            return wxFileSystemHandler_CanOpen(wxObject, wxLocation.wxObject);
        }

        string OriginalFindFirst(string wildcard, KindOfFile kindOfFile)
        {
            wxString wxWildcard = new wxString(wildcard);
            return new wxString(wxFileSystemHandler_FindFirst(wxObject, wxWildcard.wxObject, (int)kindOfFile));
        }

        string OriginalFindNext()
        {
            return new wxString(wxFileSystemHandler_FindNext(wxObject));
        }
        #endregion

        #region Public Virtual Methods
        /** <summary>Returns an instance of FSFile that provides a stream over the data as denoted by <c>location</c>.
         * \param location absolute location of the desired data.
         * \param fs is the parent file system. This parameter still exists maybe because of historical reasons.
         * The manual 2.6.3. refers to <c>wxZipFSHandler</c> as a reference for using this parameter but this
         * class in the meanwhile explicitely refers to a freshly created file system to avoid infinite recursions
         * (as the remark says).
         *</summary>*/
        public abstract FSFile OpenFile(FileSystem fs, string location);

        /** <summary>The handler identifies himself with result <c>true</c> to be appropriate to deal with a file at the provided location.</summary><remarks>
         * Example: A handler for the HTTP protocol over the internet could answer here with
         * \code
         return this.GetProtocol(location) == "http";
         \endcode
         * 
         * Please note, that this method should also work with the allowed wildcards, since this method
         * also works as a filter for FindFirst().
         *</remarks>*/
        public virtual bool CanOpen(string location)
        {
            return OriginalCanOpen(location);
        }

        /** <summary>Returns the first matching filename or an empty string if nothing matches.
         * This will only be called if the <c>wildcard</c> can be opened (CanOpen()).
         *</summary>*/
        public virtual string FindFirst(string wildcard, KindOfFile kindOfFile)
        {
            return OriginalFindFirst(wildcard, kindOfFile);
        }

        /** <summary>Returns the next filename matching with the constraints of the previous FindFirst() or an empty string if nothing matches.
         *</summary>*/
        public virtual string FindNext()
        {
            return OriginalFindNext();
        }
        #endregion

        #region Protected Helpers
        /** \name Methods to divide a location into protocol, left location, right location, and anchor.
         */
        //{
        /** <summary>Returns the anchor if present in the location.
         * Example:
         * <code>
         * GetAnchor("index.htm#chapter2") == "chapter2"
         * </code>
         *
         * Note: the anchor is NOT part of the left location.
         *</summary>*/
        protected string GetAnchor(string location)
        {
            wxString wxLocation = new wxString(location);
            return new wxString(wxFileSystemHandler_GetAnchor(wxObject, wxLocation.wxObject));
        }
        /** <summary>Returns the protocol string extracted from location. 
          * <code>Example: GetProtocol("file:myzipfile.zip#zip:index.htm") == "zip"</code>
         *</summary>*/
        protected string GetProtocol(string location)
        {
            wxString wxLocation = new wxString(location);
            return new wxString(wxFileSystemHandler_GetProtocol(wxObject, wxLocation.wxObject), true);
        }
        /** <summary>Returns the left location string extracted from location. 
         * Example:
         * <code>
         * GetLeftLocation("file:myzipfile.zip#zip:index.htm") == "file:myzipfile.zip"
         * </code>
         *</summary>*/
        protected string GetLeftLocation(string location)
        {
            wxString wxLocation = new wxString(location);
            return new wxString(wxFileSystemHandler_GetLeftLocation(wxObject, wxLocation.wxObject));
        }
        /** <summary>Returns the right location string extracted from location. 
         * Example : 
         * <code>
         * GetRightLocation("file:myzipfile.zip#zip:/index.htm") == "/index.htm"
         * </code>
         * /summary>
         */
        protected string GetRightLocation(string location)
        {
            wxString wxLocation = new wxString(location);
            return new wxString(wxFileSystemHandler_GetRightLocation(wxObject, wxLocation.wxObject), true);
        }
        //@}

        /** <summary>Returns the MIME type based on extension of location.
         * (While FSFile.MimeType returns real MIME type - either extension-based or queried
         * from HTTP.) However, particular handlers may use this to generate an FSFile of 
         * an appropriate mime type if nothing particular is known on such things.
         *
         * Example : 
         * <code>
         * this.GetMimeTypeFromExt("index.htm") == "text/html"
         * </code>
         *</summary>*/
        public string GetMimeTypeFromExt(string location)
        {
            wxString wxLocation = new wxString(location);
            return new wxString(wxFileSystemHandler_GetMimeTypeFromExt(wxObject, wxLocation.wxObject), true);
        }
        #endregion

        #region Static Helpers
        static FileSystemHandler _sinstance = null;
        /** <summary>A static public version of GetMimeTypeFromExt() running on a particular, transparently generated instance.
         * This method may be changed in order to add some support for additional types.
         *</summary>*/
        static public string MimeTypeFromExt(string location)
        {
            if (_sinstance == null)
                _sinstance = new IOStreamFSHandler();
            return _sinstance.GetMimeTypeFromExt(location);
        }
        #endregion
    }

    /** <summary>This wrapps <c>wxFileSystem</c> but concentrates on the methods that are not already implemented in the .NET framework.
     *</summary>*/
    public class FileSystem : wx.Object
    {
        #region C API
        [DllImport("wx-c")]
        static extern IntPtr wxFileSystem_ctor();
        [DllImport("wx-c")]
        static extern void wxFileSystem_AddHandler(IntPtr fileSystemHandler);
        [DllImport("wx-c")]
        static extern void wxFileSystem_ChangePathTo(IntPtr self, IntPtr location, bool is_dir);
        [DllImport("wx-c")]
        static extern IntPtr wxFileSystem_GetPath(IntPtr self);
        [DllImport("wx-c")]
        static extern IntPtr wxFileSystem_FindFirst(IntPtr self, IntPtr wildcard, int mode);
        [DllImport("wx-c")]
        static extern IntPtr wxFileSystem_FindNext(IntPtr self);
        [DllImport("wx-c")]
        static extern IntPtr wxFileSystem_OpenFile(IntPtr self, IntPtr location);
        [DllImport("wx-c")]
        static extern void wxFileSystem_CleanUpHandlers();
        #endregion

        #region CTor
        static IntPtr SyncCTor()
        {
            lock (DllSync)
            {
                return wxFileSystem_ctor();
            }
        }

        /** <summary>The  wxWidgets file system uses instances created by the default constructor as handles for accessing files systems of various types through something like an URL.
         * File system are implemented by a handler (refer to class FileSystemHandler). This wrapper to the .NET framework also
         * allows file system handlers to be written in C# or another CRL language.
         *</summary>*/
        public FileSystem()
            : base(SyncCTor())
        {
           memOwn=true;
        }

        internal FileSystem(IntPtr wxObject)
            : base(wxObject)
        {
        }
        #endregion

        #region Static Public Methods
        /** <summary>Adds the provided instance as a handler to the handler list.
         * Refer for instance to <c>MemoryFSHandler</c> for a wrapper to a standard
         *  wxWidgets resource handler. Note, that all inheritors of FileSystemHandler may
         * be used here.
         *
         * The native object wrapped by <c>handler</c> will be owned by the singleton managing file system handlers.
         * This will raise an exception, if te handler instance is already shared by another object.
         * 
         * Please refer also to CleanUpHandlers().
         *</summary>*/
        public static void AddHandler(FileSystemHandler handler)
        {
            if (!handler.memOwn)
                throw new Exception("The wx singleton managing file system handlers cannot take ownership of an already shared file system handler.");
            handler.memOwn=false; // don't call C++ DTor since this object will be destructed by wxWidgets
            wxFileSystem_AddHandler(handler.wxObject);
        }
        /** <summary>Clean up all installed file handlers.
         * Calling this method is unfortunately necessary on shutting down applications
         * installing some kinds of file system handlers by using AddHandler(). The reason
         * is:  wxWidgets will delete the C++ instances of installed file system handlers
         * on shutting down. However,  wxWidgets can of course not delete the corresponding
         * .NET instances. These may also try to delete C++ instances on being disposed. So,
         * we will likely to get access violations.
         *</summary>*/
        public static void CleanUpHandlers()
        {
            wxFileSystem_CleanUpHandlers();
        }
        #endregion

        #region Public Properties
       /** <summary>Returns the path according to ChangePathTo().
        * Setting this value is synonym to ChangePathTo(). 
        *</summary>*/
       public string Path
       {
          get
          {
             return new wxString(wxFileSystem_GetPath(wxObject), true);
          }
          set
          {
             ChangePathTo(value);
          }
       }
        #endregion

        #region Public Methods
        /** <summary>Sets the current location.</summary><remarks>
         * <c>location</c> parameter passed to OpenFile is relative to this path.
         * \b Caution!
         * Unless <c>is_dir</c> is true the location parameter is not the directory name but
         * the name of the file in this directory. All these commands change the path to
         * "dir/subdir/":
         * \code
        FileSystem fs=new FileSystem();
        fs.ChangePathTo("dir/subdir/xh.htm");
        fs.ChangePathTo("dir/subdir", true);
        fs.ChangePathTo("dir/subdir/", true);
        \endcode
        * \param location the new location. Its meaning depends on the value of <c>is_dir</c>
        * \param is_dir if <c>true</c> location is new directory. If false (default) location
        *  is file in the new directory.
        *
        * Example:
        \code
  f = fs -> OpenFile("hello.htm"); // opens file 'hello.htm'
  fs -> ChangePathTo("subdir/folder", true);
  f = fs -> OpenFile("hello.htm"); // opens file 'subdir/folder/hello.htm' !!
       \endcode
         *</remarks>*/
        public void ChangePathTo(string location, bool is_dir)
        {
            wxString wxLocation = new wxString(location);
            wxFileSystem_ChangePathTo(wxObject, wxLocation.wxObject, is_dir);
        }
        public void ChangePathTo(string location)
        {
            this.ChangePathTo(location, false);
        }

        /** <summary>Returns name of the first filename (within filesystem's current path) that matches wildcard.
         *  <c>flags</c> may be one of KindOfFile.wxFILE (only files), KindOfFile.wxDIR (only directories)
         * or KindOfFile.Indifferent (both).
         * 
         * Returns filename or empty string if no more matching file exists.
         *</summary>*/
        public string FindFirst(string wildcard, KindOfFile kind)
        {
            return new wxString(wxFileSystem_FindFirst(wxObject, (new wxString(wildcard)).wxObject, (int) kind));
        }

        /** <summary>Finds the next filename matching constraints of the previous FindFirst().
         * Returns filename or empty string if no more matching file exists.
         *</summary>*/
        public string FindNext()
        {
            return new wxString(wxFileSystem_FindNext(wxObject));
        }

        /** <summary>Opens the file and returns a <c>FSFile</c> object or <c>null</c> if failed.
         * It first tries to open the file in relative scope (based on value passed to
         * ChangePathTo() method) and then as an absolute path.
         *</summary>*/
        public FSFile OpenFile(string location)
        {
            wxString wxLocation = new wxString(location);
            IntPtr result = wxFileSystem_OpenFile(wxObject, wxLocation.wxObject);
            if (result == IntPtr.Zero)
                return null;
            else
                return new FSFile(result);
        }
        #endregion
    }

    /** <summary>A wrapper to <c>wxZipFSHandler</c>. 
     * This is a handler for FileSystem that can deal with Zip archives.
     * In contrast to most other handlers, this one uses first and second part locations where
     * the first part describes the archive file and the second part describes the archived file.
     * </summary>
     * <remarks>
     * Example: 
     * <code>
     * "file:ZipFile.zip#anHTMLIndex.htm#aChapterInThisIndex"
     * </code>
     * </remarks>
     */
    public class ZipFSHandler : FileSystemHandler
    {
        #region C API
        [DllImport("wx-c")]
        static extern IntPtr wxZipFSHandler_ctor();
        [DllImport("wx-c")]
        static extern IntPtr wxZipFSHandler_OpenFile(IntPtr self, IntPtr fs, IntPtr location);
        #endregion

        #region CTor
        static IntPtr SyncCTor()
        {
            lock (DllSync)
            {
                return wxZipFSHandler_ctor();
            }
        }

        /// <summary>
        /// Creates a handler of a file system that can deal with Zip archives.
        /// In contrast to most other handlers, this one uses first and second part locations where
        /// the first part describes the archive file and the second part describes the archived file.
        /// </summary>
        public ZipFSHandler()
            : base(SyncCTor())
        {
           memOwn=true;
        }
        #endregion

        #region Public Virtual Methods
        public override FSFile OpenFile(FileSystem fs, string location)
        {
            wxString wxLocation = new wxString(location);
            IntPtr result = wxZipFSHandler_OpenFile(this.wxObject, fs.wxObject, wxLocation.wxObject);
            if (result == IntPtr.Zero)
                return null;
            else
                return new FSFile(result);            
        }
        #endregion
    }

    /** <summary>A wrapper to <c>wxInternetFSHandler</c>.
     * Instances of this class provide a handler for FileSystem to deal with FTP and HTTP files.
     *</summary>
     */
    public class InternetFSHandler : FileSystemHandler
    {
        #region C API
        [DllImport("wx-c")]
        static extern IntPtr wxInternetFSHandler_ctor();
        [DllImport("wx-c")]
        static extern IntPtr wxInternetFSHandler_OpenFile(IntPtr self, IntPtr fs, IntPtr location);
        #endregion

        #region CTor
        static IntPtr SyncCTor()
        {
            lock (DllSync)
            {
                return wxInternetFSHandler_ctor();
            }
        }
        public InternetFSHandler()
            : base(SyncCTor())
        {
           memOwn=true;
        }
        #endregion

        #region Public Virtual Methods
        public override FSFile OpenFile(FileSystem fs, string location)
        {
            wxString wxLocation = new wxString(location);
            IntPtr result = wxInternetFSHandler_OpenFile(this.wxObject, fs.wxObject, wxLocation.wxObject);
            if (result == IntPtr.Zero)
                return null;
            else
                return new FSFile(result);
        }
        #endregion
    }

    /** <summary>This FileSystem handler can store arbitrary data in memory stream and make them
     * accessible via URL. It is particularly suitable for storing bitmaps from resources
     * or included XPM files so that they can be used with wx.HTML.
     *
     * Filenames are prefixed with <c> "memory:"</c>, e.g. <c>"memory:myfile.html"</c>.
     *</summary>
     */
    public class MemoryFSHandler : FileSystemHandler
    {
        #region C API
        [DllImport("wx-c")]
        static extern IntPtr wxMemoryFSHandler_ctor();
        [DllImport("wx-c")]
        static extern void wxMemoryFSHandler_AddImage(IntPtr filename, IntPtr image, long type);
        //[DllImport("wx-c")]static extern void wxMemoryFSHandler_AddBitmap(IntPtr filename, IntPtr image, long type);
        [DllImport("wx-c")]
        static extern void wxMemoryFSHandler_AddText(IntPtr filename, string text);
        [DllImport("wx-c")]
        static extern void wxMemoryFSHandler_AddBinaryData(IntPtr filename, byte[] binaryData, int binaryDataLength);
        [DllImport("wx-c")]
        static extern IntPtr wxMemoryFSHandler_OpenFile(IntPtr self, IntPtr fs, IntPtr location);
        [DllImport("wx-c")]
        static extern IntPtr wxMemoryFSHandler_RemoveFile(IntPtr location);
        #endregion

        #region CTor
        static IntPtr SyncCTor()
        {
            lock (DllSync)
            {
                return wxMemoryFSHandler_ctor();
            }
        }
        public MemoryFSHandler()
            : base(SyncCTor())
        {
           memOwn=true;
        }
        #endregion

        #region Public Virtual Methods
        public override FSFile OpenFile(FileSystem fs, string location)
        {
            wxString wxLocation = new wxString(location);
            IntPtr result = wxMemoryFSHandler_OpenFile(this.wxObject, fs.wxObject, wxLocation.wxObject);
            if (result == IntPtr.Zero)
                return null;
            else
                return new FSFile(result);
        }
        #endregion

        #region Static Public Functions
        /** \name Functions to add files to the virtual file system in memory.
         */
        //@{
        /** <summary>Adds an image as a file of the specified type.
         * Please note, that the type argument shall be something like 
         * <c>wx.BitmapType.wxBITMAP_TYPE_PNG</c> that  wxWidgets can save.
         *</summary>*/
        public static void Add(string filename, wx.Image image, wx.BitmapType type)
        {
            wxString wxFilename = new wxString(filename);
            wxMemoryFSHandler_AddImage(wxFilename.wxObject, image.wxObject, (long)type);
        }
        /** <summary>Adds an image as a file of the specified type.
         * Please note, that the type argument shall be something like 
         * <c>wx.BitmapType.wxBITMAP_TYPE_PNG</c> that  wxWidgets can save.
         *</summary>*/
        public static void Add(string filename, wx.Bitmap image, wx.BitmapType type)
        {
            wxString wxFilename = new wxString(filename);
            wxMemoryFSHandler_AddImage(wxFilename.wxObject, image.wxObject, (long)type);
        }
        public static void Add(string filename, string text)
        {
            wxString wxFilename = new wxString(filename);
            wxMemoryFSHandler_AddText(wxFilename.wxObject, text);
        }
        public static void Add(string filename, byte[] binaryData)
        {
            wxString wxFilename = new wxString(filename);
            wxMemoryFSHandler_AddBinaryData(wxFilename.wxObject, binaryData, binaryData.Length);
        }
        public static void Remove(string filename)
        {
            wxString wxFilename = new wxString(filename);
            wxMemoryFSHandler_RemoveFile(wxFilename.wxObject);
        }
        //@}
        #endregion
    }

    /** <summary>Class of  wxWidgets file system handlers that are implemented by a <c>System.IO.Stream</c>. 
     * Generate an instance of this class and install this (call FileSystemHandler.AddHandler)
     * to provide the ability to deal with the following protocols:
     * <list type="bullet"> 
     * <item> <c>file:file</c> and <c>dotnetfile:file</c> implemented by a FileStream.</item>
     * <item> <c>rs:file</c> or <c>rs:assembly.filename//file </c> tries to find the provided file name in the manifest
     *     and returns (if possible) a stream over the data of a resource file. Source assembly <c>assembly.filename</c> will be loaded by
     *     Assembly.LoadFile(). If the source assembly is omitted,
     *     this will refer to the entry assembly. You may also use the long protocol name <c>resource:file</c>.</item>
     * <item> <c>zrs:archivefile//resourcefile</c> loads resource <c>resourcefile</c> from
     *     the ZRS archive <c>archivefile</c> (refer to class ZipResource). Long protocol name
     *     <c>zipresource:archivefile//resourcefile</c> also works.
     * </item>
     * </list>
     * </summary>>
     */
    public class IOStreamFSHandler : FileSystemHandler
    {
        #region Callback Declarations
        private delegate bool Virtual_FileSystemHandler_CanOpen(IntPtr location);
        private delegate IntPtr Virtual_FileSystemHandler_OpenFile(IntPtr fs, IntPtr location);
        private delegate IntPtr Virtual_FileSystemHandler_FindFirst(IntPtr wildcard, KindOfFile kindOfFile);
        private delegate IntPtr Virtual_FileSystemHandler_FindNext();
        #endregion

        #region C API
        [DllImport("wx-c")]
        static extern IntPtr dotNetFileSystemHandler_ctor();
        [DllImport("wx-c")]
        static extern void dotNetFileSystemHandler_RegisterVirtual(IntPtr self,
                                                                   Virtual_Dispose virtualDispose,
                                                                   Virtual_FileSystemHandler_CanOpen fnCanOpen,
                                                                   Virtual_FileSystemHandler_OpenFile fnOpenFile,
                                                                   Virtual_FileSystemHandler_FindFirst fnFindFirst,
                                                                   Virtual_FileSystemHandler_FindNext fnFindNext);
        [DllImport("wx-c")]
        static extern void dotNetFileSystemHandler_UnregisterVirtual(IntPtr self);
        #endregion

        #region State / saved instances of the virtual callbacks
        // we have to save the instances of the used callbacks since they may otherwise be disposed too early
        Virtual_FileSystemHandler_CanOpen _Virtual_FileSystemHandler_CanOpen;
        Virtual_FileSystemHandler_OpenFile _Virtual_FileSystemHandler_OpenFile;
        Virtual_FileSystemHandler_FindFirst _Virtual_FileSystemHandler_FindFirst;
        Virtual_FileSystemHandler_FindNext _Virtual_FileSystemHandler_FindNext;
        #endregion

        #region CTor
        static IntPtr SyncCTor()
        {
            return dotNetFileSystemHandler_ctor();
        }

        /** <summary>Creates a file system handler providing the ability to deal with the following protocols:
         * <list type="bullet"> 
         * <item> <c>file:file</c> and <c>dotnetfile:file</c> implemented by a FileStream.</item>
         * <item> <c>rs:file</c> or <c>rs:assembly.filename//file </c> tries to find the provided file name in the manifest
         *     and returns (if possible) a stream over the data of a resource file. Source assembly <c>assembly.filename</c> will be loaded by
         *     Assembly.LoadFile(). If the source assembly is omitted,
         *     this will refer to the entry assembly. You may also use the long protocol name <c>resource:file</c>.</item>
         * <item> <c>zrs:archivefile//resourcefile</c> loads resource <c>resourcefile</c> from
         *     the ZRS archive <c>archivefile</c> (refer to class ZipResource). Long protocol name
         *     <c>zipresource:archivefile//resourcefile</c> also works.
         * </item>
         * </list>
         * </summary>>
         */
        public IOStreamFSHandler()
            : base(SyncCTor())
        {
            memOwn=true;
            this.virtual_Dispose = new Virtual_Dispose(this.VirtualDispose);
            _Virtual_FileSystemHandler_CanOpen  =new Virtual_FileSystemHandler_CanOpen(DoCanOpen);
            _Virtual_FileSystemHandler_OpenFile =new Virtual_FileSystemHandler_OpenFile(DoOpenFile);
            _Virtual_FileSystemHandler_FindFirst=new Virtual_FileSystemHandler_FindFirst(DoFindFirst);
            _Virtual_FileSystemHandler_FindNext =new Virtual_FileSystemHandler_FindNext(DoFindNext);
            dotNetFileSystemHandler_RegisterVirtual(this.wxObject,
                                                    this.virtual_Dispose,
                                                    this._Virtual_FileSystemHandler_CanOpen,
                                                    this._Virtual_FileSystemHandler_OpenFile,
                                                    this._Virtual_FileSystemHandler_FindFirst,
                                                    this._Virtual_FileSystemHandler_FindNext);
        }

        protected override void Dispose(bool disposing)
        {
            dotNetFileSystemHandler_UnregisterVirtual(this.wxObject);
            base.Dispose(disposing);
        }
        #endregion
        
        #region Public Helpers
        /** <summary>Returns the primary file.
         * First and second file names complete standard  wxWidgets elements of
         * file system names (protocol, left location, right location, anchor).
         * Both filenames are subelements of the right location spanning over the filename
         * right from the protocol and left from the (optional) anchor.
         * If this filename contains a double slash (//), the filename left from this separator
         * is called first filename and the filename on the right is called second filename.
         * The first name is optional (i.e. is empty if the whole file name is without
         * a double slash).
         * </summary>
         */
        public string GetFirstFilename(string location)
        {
            location = GetRightLocation(location);
            int pos=location.IndexOf("//");
            if (pos >= 0)
            {
               return location.Substring(0, pos);
            }
            else
               return ""; // the full location is a primary filename
        }
        public string GetSecondFilename(string location)
        {
            location = GetRightLocation(location);
            int pos=location.IndexOf("//");
            if (pos >= 0)
            {
               return location.Substring(pos+2);
            }
            else
               return location; // the full location is a primary filename
        }
        #endregion

        #region Internal Implementations of Callbacks
        internal IntPtr DoOpenFile(IntPtr fs, IntPtr location)
        {
            try
            {
                FSFile fsresult = OpenFile(new FileSystem(fs), new wxString(location, false));
                IntPtr result = fsresult.wxObject;
                fsresult.memOwn = false; // do not call C++ destructor on C# deallocation
                return result;
            }
            catch (Exception exc)
            {
                Trace.WriteLine(exc);
                return IntPtr.Zero;
            }
        }
         
        internal bool DoCanOpen(IntPtr location)
        {
            return CanOpen(new wxString(location, false));
        }
        
        /** <summary>Currently not supported.</summary>*/
        internal IntPtr DoFindFirst(IntPtr wildcard, KindOfFile kindOfFile)
        {
            return (new wxString(FindFirst(new wxString(wildcard, false), kindOfFile))).wxObject;
        }
        /** <summary>Currently not supported.</summary>*/
        internal IntPtr DoFindNext()
        {
            return (new wxString(FindNext())).wxObject;
        }
        #endregion
        
        #region Public Virtual Methods
        /** <summary>Returns an instance of FSFile that provides a stream over the data as denoted by <c>location</c>.
         * \param location absolute location of the desired data.
         * \param fs is the parent file system.
         * The manual 2.6.3. refers to <c>wxZipFSHandler</c> as a reference for using this parameter but this
         * class in the meanwhile explicitely refers to a freshly created file system to avoid infinite recursions
         * (as the remark says). I found out that this parameter contains the path.
         *</summary>*/
        public override FSFile OpenFile(FileSystem fs, string location)
        {
            FSFile result=null;
            string protocol=GetProtocol(location);
            string path = fs.Path;
            string rLocation = GetRightLocation(location);
            if (path!=null && path != "")
               rLocation = Path.Combine(path, rLocation);
            string mimeType = GetMimeTypeFromExt(location);
            if (protocol=="file" || protocol=="dotnetfile")
            {
               result = new FSFile(new FileStream(rLocation, FileMode.Open),
                                   location, mimeType,
                                   "",
                                   File.GetCreationTime(rLocation));
            }
            else if (protocol=="rs" || protocol=="resource")
            {
                string primaryLocation = GetFirstFilename(rLocation);
                string secondaryLocation = GetSecondFilename(rLocation);
                primaryLocation.Trim();
                Assembly src=null;
                if (primaryLocation.Length == 0)
                    src = Assembly.GetEntryAssembly();
                else
                    src = Assembly.LoadFrom(primaryLocation);

                ManifestResourceInfo mri = src.GetManifestResourceInfo(secondaryLocation);
                if (mri != null)
                {
                    Stream stream = src.GetManifestResourceStream(secondaryLocation);
                    result = new FSFile(stream, location, mimeType, "", new DateTime());
                }
            }
            else if (protocol == "zrs" || protocol == "zipresource")
            {
                string archiveName = GetFirstFilename(location);
                string resourceName = GetSecondFilename(location);
                result = wx.Archive.ZipResource.ResourceFileAppropriateType(archiveName, resourceName);
            }
            if (result==null)
            {
               throw new FileNotFoundException(location);
            }
            return result;
        }

        /** <summary>The handler identifies himself with result <c>true</c> to be appropriate to deal with a file at the provided location.
         * 
         *</summary>*/
        public override bool CanOpen(string location)
        {
            string protocol=GetProtocol(location);
            return protocol=="rs" || protocol=="resource" /*|| protocol=="file"*/ || protocol=="dotnetfile" || protocol=="zrs";
        }

        /** <summary>Returns the first matching filename or an empty string if nothing matches.
         * This will only be called if the <c>wildcard</c> can be opened (CanOpen()).
         *</summary>*/
        public override string FindFirst(string wildcard, KindOfFile kindOfFile)
        {
            return "";
        }

        /** <summary>Returns the next filename matching with the constraints of the previous FindFirst() or an empty string if nothing matches.
         *</summary>*/
        public override string FindNext()
        {
            return "";
        }
        #endregion
    }
}
