//-----------------------------------------------------------------------------
// wx.NET - StaticBoxSizer.cs
//
// The wxStaticBoxSizer proxy interface.
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
// $Id: StaticBoxSizer.cs,v 1.9 2010/01/01 16:52:35 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Drawing;
using System.Runtime.InteropServices;

namespace wx
{
    /// <summary>
    /// A BoxSizer surrounded by a static box.
    /// </summary>
	public class StaticBoxSizer : BoxSizer
	{
		[DllImport("wx-c")] static extern IntPtr wxStaticBoxSizer_ctor(IntPtr box, int orient);
		[DllImport("wx-c")] static extern IntPtr wxStaticBoxSizer_ctor2(int orient, IntPtr parent, IntPtr label);
		[DllImport("wx-c")] static extern IntPtr wxStaticBoxSizer_GetStaticBox(IntPtr self);

		//---------------------------------------------------------------------

        /** <summary>For internal use only.</summary>*/
		public StaticBoxSizer(IntPtr wxObject)
			: base(wxObject)
		{
		}

        /** <summary>Creates a layout resuing a predefined static box.</summary>*/
		public StaticBoxSizer(StaticBox box, wx.Orientation orient)
			: base(wxStaticBoxSizer_ctor(Object.SafePtr(box), (int)orient))
		{
		}

        /** <summary>Creates an instance of the provided orientation without a a label.</summary>*/
        public StaticBoxSizer(wx.Orientation orient, wx.Window parent)
            : this(orient, parent, (wxString) null)
        {
        }

        /** <summary>Creates an instance of the provided orientation with the specified label.</summary>*/
        public StaticBoxSizer(wx.Orientation orient, wx.Window parent, string label)
            : this(orient, parent, wxString.SafeNew(label))
        {
        }

        /** <summary>Creates an instance of the provided orientation with the specified label.</summary>*/
        public StaticBoxSizer(wx.Orientation orient, wx.Window parent, wxString label)
            : base(wxStaticBoxSizer_ctor2((int)orient, Object.SafePtr(parent), Object.SafePtr(label)))
        {
        }

		//---------------------------------------------------------------------

		public StaticBox StaticBox
		{
			get
			{
				return (StaticBox)FindObject(
                                    wxStaticBoxSizer_GetStaticBox(wxObject)
                                );
			}
		}

		//---------------------------------------------------------------------
	}
}
