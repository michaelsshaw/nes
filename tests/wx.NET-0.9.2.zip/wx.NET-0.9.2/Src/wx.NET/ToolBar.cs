//-----------------------------------------------------------------------------
// wx.NET - Tbarbase.cs
// 
// The wxToolBar wrapper class.
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: ToolBar.cs,v 1.25 2010/05/08 19:54:35 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Drawing;
using System.Runtime.InteropServices;

namespace wx
{
	public class ToolBarTool : Object
	{
		[DllImport("wx-c")] static extern IntPtr wxToolBarToolBase_ctor(IntPtr tbar, int toolid, IntPtr label, IntPtr bmpNormal, IntPtr bmpDisabled, int kind, IntPtr clientData, IntPtr shortHelpString, IntPtr longHelpString);
		[DllImport("wx-c")] static extern IntPtr wxToolBarToolBase_ctorCtrl(IntPtr tbar, IntPtr control);
		[DllImport("wx-c")] static extern int    wxToolBarToolBase_GetId(IntPtr self);
		[DllImport("wx-c")] static extern IntPtr wxToolBarToolBase_GetControl(IntPtr self);
		[DllImport("wx-c")] static extern IntPtr wxToolBarToolBase_GetToolBar(IntPtr self);
		[DllImport("wx-c")] static extern bool   wxToolBarToolBase_IsButton(IntPtr self);
		[DllImport("wx-c")] static extern bool   wxToolBarToolBase_IsControl(IntPtr self);
		[DllImport("wx-c")] static extern bool   wxToolBarToolBase_IsSeparator(IntPtr self);
		[DllImport("wx-c")] static extern uint   wxToolBarToolBase_GetStyle(IntPtr self);
		[DllImport("wx-c")] static extern int    wxToolBarToolBase_GetKind(IntPtr self);
		[DllImport("wx-c")] static extern bool   wxToolBarToolBase_IsEnabled(IntPtr self);
		[DllImport("wx-c")] static extern bool   wxToolBarToolBase_IsToggled(IntPtr self);
		[DllImport("wx-c")] static extern bool   wxToolBarToolBase_CanBeToggled(IntPtr self);
		[DllImport("wx-c")] static extern IntPtr wxToolBarToolBase_GetLabel(IntPtr self);
		[DllImport("wx-c")] static extern IntPtr wxToolBarToolBase_GetShortHelp(IntPtr self);
		[DllImport("wx-c")] static extern IntPtr wxToolBarToolBase_GetLongHelp(IntPtr self);
		[DllImport("wx-c")] static extern IntPtr wxToolBarToolBase_GetClientData(IntPtr self);
		[DllImport("wx-c")] static extern bool   wxToolBarToolBase_Enable(IntPtr self, bool enable);
		[DllImport("wx-c")] static extern bool   wxToolBarToolBase_Toggle(IntPtr self, bool toggle);
		[DllImport("wx-c")] static extern bool   wxToolBarToolBase_SetToggle(IntPtr self, bool toggle);
		[DllImport("wx-c")]
        [return:MarshalAs(UnmanagedType.U1)]
        static extern bool   wxToolBarToolBase_SetShortHelp(IntPtr self, IntPtr help);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxToolBarToolBase_SetLongHelp(IntPtr self, IntPtr help);
		[DllImport("wx-c")] static extern void   wxToolBarToolBase_Toggle(IntPtr self);
		[DllImport("wx-c")] static extern void   wxToolBarToolBase_SetNormalBitmap(IntPtr self, IntPtr bmp);
		[DllImport("wx-c")] static extern void   wxToolBarToolBase_SetDisabledBitmap(IntPtr self, IntPtr bmp);
		[DllImport("wx-c")] static extern void   wxToolBarToolBase_SetLabel(IntPtr self, IntPtr label);
		[DllImport("wx-c")] static extern void   wxToolBarToolBase_SetClientData(IntPtr self, IntPtr clientData);
		[DllImport("wx-c")] static extern void   wxToolBarToolBase_Detach(IntPtr self);
		[DllImport("wx-c")] static extern void   wxToolBarToolBase_Attach(IntPtr self, IntPtr tbar);

        //---------------------------------------------------------------------
        
        public ToolBarTool(IntPtr wxObject) 
            : base(wxObject) { }

        public ToolBarTool(ToolBar tbar, int toolid, string label, Bitmap bmpNormal, Bitmap bmpDisabled, ItemKind kind, ClientData clientData, string shortHelpString, string longHelpString)
            : this(tbar, toolid, wxString.SafeNew(label), bmpNormal, bmpDisabled, kind, clientData, wxString.SafeNew(shortHelpString), wxString.SafeNew(longHelpString))
        {
        }
        public ToolBarTool(ToolBar tbar, int toolid, wxString label, Bitmap bmpNormal, Bitmap bmpDisabled, ItemKind kind, ClientData clientData, wxString shortHelpString, wxString longHelpString)
            : this(wxToolBarToolBase_ctor(Object.SafePtr(tbar), toolid, Object.SafePtr(label), Object.SafePtr(bmpNormal), Object.SafePtr(bmpDisabled), (int)kind, Object.SafePtr(clientData), Object.SafePtr(shortHelpString), Object.SafePtr(longHelpString))) { }

        public ToolBarTool(ToolBar tbar, Control control)
            : this(wxToolBarToolBase_ctorCtrl(Object.SafePtr(tbar), Object.SafePtr(control))) { }

        //---------------------------------------------------------------------

		public int ID
        {
            get {return wxToolBarToolBase_GetId(wxObject); }
        }

		public Control Control
        {
            get { return (Control)FindObject(wxToolBarToolBase_GetControl(wxObject)); }
        }

		public ToolBar ToolBar
        {
            get { return (ToolBar)FindObject(wxToolBarToolBase_GetToolBar(wxObject), typeof(ToolBar)); }
        }

        //---------------------------------------------------------------------

		public bool IsButton
        {
            get { return wxToolBarToolBase_IsButton(wxObject); }
        }

		public bool IsControl
        {
            get { return wxToolBarToolBase_IsControl(wxObject); }
        }

		public bool IsSeparator
        {
            get { return wxToolBarToolBase_IsSeparator(wxObject); }
        }

        //---------------------------------------------------------------------

		public uint style
        {
            get { return wxToolBarToolBase_GetStyle(wxObject); }
        }

		public ItemKind Kind
        {
            get { return (ItemKind)wxToolBarToolBase_GetKind(wxObject); }
        }

        //---------------------------------------------------------------------

		public string Label
        {
            get { return new wxString(wxToolBarToolBase_GetLabel(wxObject), true); }
            set 
            {
                wxString wxvalue = wxString.SafeNew(value);
                wxToolBarToolBase_SetLabel(wxObject, Object.SafePtr(wxvalue));
            }
        }

		public string ShortHelp
        {
            get { return new wxString(wxToolBarToolBase_GetShortHelp(wxObject), true); }
            set
            {
                wxString wxvalue = wxString.SafeNew(value);
                wxToolBarToolBase_SetShortHelp(wxObject, Object.SafePtr( wxvalue));
            }
        }

		public string LongHelp
        {
            get { return new wxString(wxToolBarToolBase_GetLongHelp(wxObject), true); }
            set
            {
                wxString wxvalue = wxString.SafeNew(value);
                wxToolBarToolBase_SetLongHelp(wxObject, Object.SafePtr(wxvalue));
            }
        }

        //---------------------------------------------------------------------
        
		public ClientData ClientData
        {
            get { return (ClientData)Object.FindObject(wxToolBarToolBase_GetClientData(wxObject)); }
            set { wxToolBarToolBase_SetClientData(wxObject, Object.SafePtr(value)); }
        }

        //---------------------------------------------------------------------

		public bool Enabled
        {
            set { wxToolBarToolBase_Enable(wxObject, value); }
            get {return wxToolBarToolBase_IsEnabled(wxObject); }
        }

		public bool Toggled
        {
            set { wxToolBarToolBase_SetToggle(wxObject, value); }
            get { return wxToolBarToolBase_IsToggled(wxObject); }
        }
        
        public bool CanBeToggled
        {
            get { return wxToolBarToolBase_CanBeToggled(this.wxObject); }
        }
        
        /// <summary>
        /// Toggles the tool.
        /// </summary>
        public void Toggle()
        {
            wxToolBarToolBase_Toggle(this.wxObject);
        }

        
        /// <summary>
        /// Toggles a tool on or off. This does not cause any event to get emitted.
        /// Only applies to a tool that has been specified as a toggle tool.
        /// </summary>
        /// <param name="toggle">If true, toggles the tool on, otherwise toggles it off.</param>
        /// <seealso cref="GetToolState"/>
        public void Toggle(bool toggle)
        {
            wxToolBarToolBase_Toggle(this.wxObject, toggle);
        }
        
        //---------------------------------------------------------------------

		public Bitmap NormalBitmap
        {
            set { wxToolBarToolBase_SetNormalBitmap(wxObject, Object.SafePtr(value)); }
        }

		public Bitmap DisabledBitmap
        {
            set { wxToolBarToolBase_SetDisabledBitmap(wxObject, Object.SafePtr(value)); }
        }

        //---------------------------------------------------------------------

		public void Detach()
        {
            wxToolBarToolBase_Detach(wxObject);
        }

		public void Attach(ToolBar tbar)
        {
            wxToolBarToolBase_Attach(wxObject, Object.SafePtr(tbar));
        }

        //---------------------------------------------------------------------
	}

    /// <summary>
    /// You may also create a toolbar that is managed by the frame, by calling wx.Frame.CreateToolBar(). Under Pocket PC,
    /// you should always use this function for creating the toolbar to be managed by the frame, so that wxWidgets can use
    /// a combined menubar and toolbar. Where you manage your own toolbars, create a wxToolBar as usual.
    ///
    /// The meaning of a "separator" is a vertical line under Windows and simple space under GTK+.
    /// </summary>
    /// <remarks>
    /// The toolbar family of classes allows an application to use toolbars in a variety of configurations and styles.
    ///
    /// The toolbar is a popular user interface component and contains a set of bitmap buttons or toggles.
    /// A toolbar gives faster access to an application's facilities than menus, which have to be popped up and
    /// selected rather laboriously.
    /// 
    /// For each platform, the symbol wxToolBar is defined to be one of the specific toolbar classes.
    ///
    /// A toolbar might appear as a single row of images under the menubar, or it might be in a separate frame layout
    /// in several rows and columns. The class handles the layout of the images, unless explicit positioning is requested.
    ///
    /// A tool is a bitmap which can either be a button (there is no 'state', it just generates an event when clicked) or
    /// it can be a toggle. If a toggle, a second bitmap can be provided to depict the 'on' state; if the second bitmap is
    /// omitted, either the inverse of the first bitmap will be used (for monochrome displays) or a thick border is drawn
    /// around the bitmap (for colour displays where inverting will not have the desired result).
    ///
    /// The Windows-specific toolbar classes expect 16-colour bitmaps that are 16 pixels wide and 15 pixels high. If you
    /// want to use a different size, call SetToolBitmapSize as the demo shows, before adding tools to the button bar.
    /// Don't supply more than one bitmap for each tool, because the toolbar generates all three images (normal,
    /// depressed and checked) from the single bitmap you give it.
    /// </remarks>
	public class ToolBar : Control
	{
		[DllImport("wx-c")] static extern IntPtr wxToolBar_ctor(IntPtr parent, int id, ref Point pos, ref Size size, uint style);
		[DllImport("wx-c")] static extern IntPtr wxToolBar_AddTool1(IntPtr self, int toolid, IntPtr label, IntPtr bitmap, IntPtr bmpDisabled, int kind, IntPtr shortHelp, IntPtr longHelp, IntPtr data);
		[DllImport("wx-c")] static extern IntPtr wxToolBar_AddTool2(IntPtr self, int toolid, IntPtr label, IntPtr bitmap, IntPtr shortHelp, int kind);
		[DllImport("wx-c")] static extern IntPtr wxToolBar_AddCheckTool(IntPtr self, int toolid, IntPtr label, IntPtr bitmap, IntPtr bmpDisabled, IntPtr shortHelp, IntPtr longHelp, IntPtr data);
		[DllImport("wx-c")] static extern IntPtr wxToolBar_AddRadioTool(IntPtr self, int toolid, IntPtr label, IntPtr bitmap, IntPtr bmpDisabled, IntPtr shortHelp, IntPtr longHelp, IntPtr data);
		[DllImport("wx-c")] static extern IntPtr wxToolBar_AddControl(IntPtr self, IntPtr control);
		[DllImport("wx-c")] static extern IntPtr wxToolBar_InsertControl(IntPtr self, int pos, IntPtr control);
		[DllImport("wx-c")] static extern IntPtr wxToolBar_FindControl(IntPtr self, int toolid);
		[DllImport("wx-c")] static extern IntPtr wxToolBar_AddSeparator(IntPtr self);
		[DllImport("wx-c")] static extern IntPtr wxToolBar_InsertSeparator(IntPtr self, int pos);
		[DllImport("wx-c")] static extern IntPtr wxToolBar_RemoveTool(IntPtr self, int toolid);
		[DllImport("wx-c")] static extern bool   wxToolBar_DeleteToolByPos(IntPtr self, int pos);
		[DllImport("wx-c")] static extern bool   wxToolBar_DeleteTool(IntPtr self, int toolid);
		[DllImport("wx-c")] static extern void   wxToolBar_ClearTools(IntPtr self);
		[DllImport("wx-c")] static extern bool   wxToolBar_Realize(IntPtr self);
		[DllImport("wx-c")] static extern void   wxToolBar_EnableTool(IntPtr self, int toolid, bool enable);
		[DllImport("wx-c")] static extern void   wxToolBar_ToggleTool(IntPtr self, int toolid, bool toggle);
		[DllImport("wx-c")] static extern IntPtr wxToolBar_GetToolClientData(IntPtr self, int toolid);
		[DllImport("wx-c")] static extern void   wxToolBar_SetToolClientData(IntPtr self, int toolid, IntPtr clientData);
		[DllImport("wx-c")] static extern bool   wxToolBar_GetToolState(IntPtr self, int toolid);
		[DllImport("wx-c")] static extern bool   wxToolBar_GetToolEnabled(IntPtr self, int toolid);
		[DllImport("wx-c")] static extern void   wxToolBar_SetToolShortHelp(IntPtr self, int toolid, IntPtr helpString);
		[DllImport("wx-c")] static extern IntPtr wxToolBar_GetToolShortHelp(IntPtr self, int toolid);
		[DllImport("wx-c")] static extern void   wxToolBar_SetToolLongHelp(IntPtr self, int toolid, IntPtr helpString);
		[DllImport("wx-c")] static extern IntPtr wxToolBar_GetToolLongHelp(IntPtr self, int toolid);
		[DllImport("wx-c")] static extern void   wxToolBar_SetMargins(IntPtr self, int x, int y);
		[DllImport("wx-c")] static extern void   wxToolBar_SetToolPacking(IntPtr self, int packing);
		[DllImport("wx-c")] static extern void   wxToolBar_SetToolSeparation(IntPtr self, int separation);
		[DllImport("wx-c")] static extern void   wxToolBar_GetToolMargins(IntPtr self, ref int width, ref int height);
		[DllImport("wx-c")] static extern int    wxToolBar_GetToolPacking(IntPtr self);
		[DllImport("wx-c")] static extern int    wxToolBar_GetToolSeparation(IntPtr self);
		[DllImport("wx-c")] static extern void   wxToolBar_SetRows(IntPtr self, int nRows);
		[DllImport("wx-c")] static extern void   wxToolBar_SetMaxRowsCols(IntPtr self, int rows, int cols);
		[DllImport("wx-c")] static extern int    wxToolBar_GetMaxRows(IntPtr self);
		[DllImport("wx-c")] static extern int    wxToolBar_GetMaxCols(IntPtr self);
		[DllImport("wx-c")] static extern void   wxToolBar_SetToolBitmapSize(IntPtr self, int width, int height);
		[DllImport("wx-c")] static extern void   wxToolBar_GetToolBitmapSize(IntPtr self, ref int width, ref int height);
        [DllImport("wx-c")]
        static extern void wxToolBar_GetToolSize(IntPtr self, ref int width, ref int height);
		[DllImport("wx-c")] static extern IntPtr wxToolBar_FindToolForPosition(IntPtr self, int x, int y);
		[DllImport("wx-c")] static extern bool   wxToolBar_IsVertical(IntPtr self);
        [DllImport("wx-c")]
        static extern IntPtr wxToolBar_AddTool3(IntPtr self, int toolid, IntPtr bitmap, IntPtr bmpDisabled, bool toggle, IntPtr clientData, IntPtr shortHelpString, IntPtr longHelpString);
        [DllImport("wx-c")]
        static extern IntPtr wxToolBar_AddTool4(IntPtr self, int toolid, IntPtr bitmap, IntPtr shortHelpString, IntPtr longHelpString);
        [DllImport("wx-c")]
        static extern IntPtr wxToolBar_AddTool5(IntPtr self, int toolid, IntPtr bitmap, IntPtr bmpDisabled, bool toggle, int xPos, int yPos, IntPtr clientData, IntPtr shortHelp, IntPtr longHelp);
        [DllImport("wx-c")]
        static extern IntPtr wxToolBar_InsertTool(IntPtr self, int pos, int toolid, IntPtr bitmap, IntPtr bmpDisabled, bool toggle, IntPtr clientData, IntPtr shortHelp, IntPtr longHelp);
		[DllImport("wx-c")] static extern bool   wxToolBar_AcceptsFocus(IntPtr self);

        //---------------------------------------------------------------------

        public ToolBar(IntPtr wxObject) 
            : base(wxObject) { }

        public ToolBar(Window parent, int id)
            : this(parent, id, wxDefaultPosition, wxDefaultSize, wx.WindowStyles.ORIENT_HORIZONTAL | wx.WindowStyles.BORDER_NONE) { }

        public ToolBar(Window parent, int id, Point pos)
            : this(parent, id, pos, wxDefaultSize, wx.WindowStyles.ORIENT_HORIZONTAL | wx.WindowStyles.BORDER_NONE) { }

        public ToolBar(Window parent, int id, Point pos, Size size)
            : this(parent, id, pos, size, wx.WindowStyles.ORIENT_HORIZONTAL | wx.WindowStyles.BORDER_NONE) { }

        public ToolBar(Window parent, int id, Point pos, Size size, wx.WindowStyles style)
            : this(wxToolBar_ctor(Object.SafePtr(parent), id, ref pos, ref size, (uint)style)) { }
	    
	//---------------------------------------------------------------------
	// ctors with self created id
	    
	public ToolBar(Window parent)
        : this(parent, Window.UniqueID, wxDefaultPosition, wxDefaultSize, wx.WindowStyles.ORIENT_HORIZONTAL | wx.WindowStyles.BORDER_NONE) { }

        public ToolBar(Window parent, Point pos)
            : this(parent, Window.UniqueID, pos, wxDefaultSize, wx.WindowStyles.ORIENT_HORIZONTAL | wx.WindowStyles.BORDER_NONE) { }

        public ToolBar(Window parent, Point pos, Size size)
            : this(parent, Window.UniqueID, pos, size, wx.WindowStyles.ORIENT_HORIZONTAL | wx.WindowStyles.BORDER_NONE) { }

        public ToolBar(Window parent, Point pos, Size size, wx.WindowStyles style)
	    : this(parent, Window.UniqueID, pos, size, style) {}

        //---------------------------------------------------------------------

        /// <summary>
        /// Adds a tool to the toolbar.
        /// After you have added tools to a toolbar, you must call wx.ToolBar.Realize in order to have the tools appear.
        /// </summary>
        /// <param name="toolid">An integer by which the tool may be identified in subsequent operations.</param>
        /// <param name="label">String label of the tool.</param>
        /// <param name="bitmap">The primary tool bitmap</param>
        /// <returns>The added tool</returns>
        public ToolBarTool AddTool(int toolid, string label, Bitmap bitmap)
        {
            return AddTool(toolid, label, bitmap, "", 0);
        }
        /// <summary>
        /// Adds a tool to the toolbar.
        /// After you have added tools to a toolbar, you must call wx.ToolBar.Realize in order to have the tools appear.
        /// </summary>
        /// <param name="toolid">An enumeration value, that defines tool id and label of the new tool.
        /// The conversion to integer is a kay by which the tool may be identified in subsequent operations.
        /// The translation will be used as label.</param>
        /// <param name="bitmap">The primary tool bitmap</param>
        /// <returns>The added tool</returns>
        public ToolBarTool AddTool(Enum toolid, Bitmap bitmap)
        {
            return AddTool(Convert.ToInt32(toolid), _(toolid), bitmap, "", 0);
        }

        /// <summary>
        /// Adds a tool to the toolbar.
        /// After you have added tools to a toolbar, you must call wx.ToolBar.Realize in order to have the tools appear.
        /// </summary>
        /// <param name="toolid">An integer by which the tool may be identified in subsequent operations.</param>
        /// <param name="label">String label of the tool.</param>
        /// <param name="bitmap">The primary tool bitmap</param>
        /// <param name="bmpDisabled">The bitmap used when the tool is disabled. If it is equal to wx.NullBitmap,
        /// the disabled bitmap is automatically generated by greing the normal one.</param>
        /// <returns>The added tool</returns>
        public ToolBarTool AddTool(int toolid, string label, Bitmap bitmap, Bitmap bmpDisabled, ItemKind kind, string shortHelp, string longHelp, ClientData clientData)
        {
            return this.AddTool(toolid, wxString.SafeNew(label), bitmap, bmpDisabled, kind, wxString.SafeNew(shortHelp), wxString.SafeNew(longHelp), clientData);
        }

        /// <summary>
        /// Adds a tool to the toolbar.
        /// After you have added tools to a toolbar, you must call wx.ToolBar.Realize in order to have the tools appear.
        /// </summary>
        /// <param name="toolid">An integer by which the tool may be identified in subsequent operations.</param>
        /// <param name="label">String label of the tool.</param>
        /// <param name="bitmap">The primary tool bitmap</param>
        /// <param name="bmpDisabled">The bitmap used when the tool is disabled. If it is equal to wx.NullBitmap,
        /// the disabled bitmap is automatically generated by greing the normal one.</param>
        /// <returns>The added tool</returns>
        public ToolBarTool AddTool(int toolid, wxString label, Bitmap bitmap, Bitmap bmpDisabled, ItemKind kind, wxString shortHelp, wxString longHelp, ClientData clientData)
        {
            return new ToolBarTool(wxToolBar_AddTool1(wxObject, toolid, Object.SafePtr(label), Object.SafePtr(bitmap), Object.SafePtr(bmpDisabled), (int)kind, Object.SafePtr(shortHelp), Object.SafePtr(longHelp), Object.SafePtr(clientData)));
        }

        /// <summary>
        /// Adds a tool to the toolbar.
        /// After you have added tools to a toolbar, you must call wx.ToolBar.Realize in order to have the tools appear.
        /// </summary>
        /// <param name="toolid">An integer by which the tool may be identified in subsequent operations.</param>
        /// <param name="label">String label of the tool.</param>
        /// <param name="bitmap">The primary tool bitmap</param>
        /// <returns>The added tool</returns>
        public ToolBarTool AddTool(int toolid, string label, Bitmap bitmap, string shortHelp, ItemKind kind)
        {
            return this.AddTool(toolid, wxString.SafeNew(label), bitmap, wxString.SafeNew(shortHelp), kind);
        }

        /// <summary>
        /// Adds a tool to the toolbar.
        /// After you have added tools to a toolbar, you must call wx.ToolBar.Realize in order to have the tools appear.
        /// </summary>
        /// <param name="toolid">An integer by which the tool may be identified in subsequent operations.</param>
        /// <param name="label">String label of the tool.</param>
        /// <param name="bitmap">The primary tool bitmap</param>
        /// <returns></returns>
        public ToolBarTool AddTool(int toolid, wxString label, Bitmap bitmap, wxString shortHelp, ItemKind kind)
        {
            return new ToolBarTool(wxToolBar_AddTool2(wxObject, toolid, Object.SafePtr(label), Object.SafePtr(bitmap), Object.SafePtr(shortHelp), (int)kind));
        }

        /// <summary>
        /// Adds a tool to the toolbar.
        /// After you have added tools to a toolbar, you must call wx.ToolBar.Realize in order to have the tools appear.
        /// </summary>
        /// <param name="toolid">An integer by which the tool may be identified in subsequent operations.</param>
        /// <param name="label">String label of the tool.</param>
        /// <param name="bitmap">The primary tool bitmap</param>
        /// <returns></returns>
        public ToolBarTool AddTool(int toolid, Bitmap bitmap, Bitmap bmpDisabled, bool toggle, ClientData clientData, string shortHelpString, string longHelpString)
        {
            return this.AddTool(toolid, bitmap, bmpDisabled, toggle, clientData, wxString.SafeNew(shortHelpString), wxString.SafeNew(longHelpString));
        }

        public ToolBarTool AddTool(int toolid, Bitmap bitmap, Bitmap bmpDisabled, bool toggle, ClientData clientData, wxString shortHelpString, wxString longHelpString)
        {
            return new ToolBarTool(wxToolBar_AddTool3(wxObject, toolid, Object.SafePtr(bitmap), Object.SafePtr(bmpDisabled), toggle, Object.SafePtr(clientData), Object.SafePtr(shortHelpString), Object.SafePtr(longHelpString)));
        }

        public ToolBarTool AddTool(int toolid, Bitmap bitmap, string shortHelpString)
        {
            return AddTool(toolid, bitmap, shortHelpString, "");
        }

        /// <summary>
        /// Adds a tool to the toolbar.
        /// After you have added tools to a toolbar, you must call wx.ToolBar.Realize in order to have the tools appear.
        /// </summary>
        /// <param name="toolid">An enumeration value, that defines tool id and label of the new tool.
        /// The conversion to integer is a kay by which the tool may be identified in subsequent operations.
        /// The translation will be used as label.</param>
        /// <param name="bitmap">The primary tool bitmap</param>
        /// <param name="shortHelpString">A short help string.</param>
        /// <returns>The added tool</returns>
        public ToolBarTool AddTool(Enum toolid, Bitmap bitmap, string shortHelpString)
        {
            return AddTool(Convert.ToInt32(toolid), _(toolid), bitmap, shortHelpString, 0);
        }

        public ToolBarTool AddTool(int toolid, Bitmap bitmap, string shortHelpString, string longHelpString)
        {
            return this.AddTool(toolid, bitmap, wxString.SafeNew(shortHelpString), wxString.SafeNew(longHelpString));
        }
        public ToolBarTool AddTool(int toolid, Bitmap bitmap, wxString shortHelpString, wxString longHelpString)
        {
            return new ToolBarTool(wxToolBar_AddTool4(wxObject, toolid, Object.SafePtr(bitmap), Object.SafePtr(shortHelpString), Object.SafePtr(longHelpString)));
        }

        public ToolBarTool AddTool(int toolid, Bitmap bitmap, Bitmap bmpDisabled, bool toggle, int xPos, int yPos, ClientData clientData, string shortHelp, string longHelp)
        {
            return this.AddTool(toolid, bitmap, bmpDisabled, toggle, xPos, yPos, clientData, wxString.SafeNew(shortHelp), wxString.SafeNew(longHelp));
        }
        public ToolBarTool AddTool(int toolid, Bitmap bitmap, Bitmap bmpDisabled, bool toggle, int xPos, int yPos, ClientData clientData, wxString shortHelp, wxString longHelp)
        {
            return new ToolBarTool(wxToolBar_AddTool5(wxObject, toolid, Object.SafePtr(bitmap), Object.SafePtr(bmpDisabled), toggle, xPos, yPos, Object.SafePtr(clientData), Object.SafePtr(shortHelp), Object.SafePtr(longHelp)));
        }

        //---------------------------------------------------------------------

        public ToolBarTool InsertTool(int pos, int toolid, Bitmap bitmap, Bitmap bmpDisabled, bool toggle, ClientData clientData, string shortHelp, string longHelp)
        {
            return this.InsertTool(pos, toolid, bitmap, bmpDisabled, toggle, clientData, wxString.SafeNew(shortHelp), wxString.SafeNew(longHelp));
        }
        public ToolBarTool InsertTool(int pos, int toolid, Bitmap bitmap, Bitmap bmpDisabled, bool toggle, ClientData clientData, wxString shortHelp, wxString longHelp)
        {
            return new ToolBarTool(wxToolBar_InsertTool(wxObject, pos, toolid, Object.SafePtr(bitmap), Object.SafePtr(bmpDisabled), toggle, Object.SafePtr(clientData), Object.SafePtr(shortHelp), Object.SafePtr(longHelp)));
        }

        //---------------------------------------------------------------------

        public ToolBarTool AddCheckTool(int toolid, string label, Bitmap bitmap, Bitmap bmpDisabled, string shortHelp, string longHelp)
        {
            return this.AddCheckTool(toolid, wxString.SafeNew(label), bitmap, bmpDisabled, wxString.SafeNew(shortHelp), wxString.SafeNew(longHelp));
        }
        public ToolBarTool AddCheckTool(int toolid, wxString label, Bitmap bitmap, Bitmap bmpDisabled, wxString shortHelp, wxString longHelp)
        {
            return new ToolBarTool(wxToolBar_AddCheckTool(wxObject, toolid, Object.SafePtr(label), Object.SafePtr(bitmap), Object.SafePtr(bmpDisabled), Object.SafePtr(shortHelp), Object.SafePtr(longHelp), Object.SafePtr(null)));
        }

        public ToolBarTool AddRadioTool(int toolid, string label, Bitmap bitmap, Bitmap bmpDisabled, string shortHelp, string longHelp)
        {
            return this.AddRadioTool(toolid, wxString.SafeNew(label), bitmap, bmpDisabled, wxString.SafeNew(shortHelp), wxString.SafeNew(longHelp));
        }
        public ToolBarTool AddRadioTool(int toolid, wxString label, Bitmap bitmap, Bitmap bmpDisabled, wxString shortHelp, wxString longHelp)
        {
            return new ToolBarTool(wxToolBar_AddRadioTool(wxObject, toolid, Object.SafePtr(label), Object.SafePtr(bitmap), Object.SafePtr(bmpDisabled), Object.SafePtr(shortHelp), Object.SafePtr(longHelp), Object.SafePtr(null)));
        }

        //---------------------------------------------------------------------

        public ToolBarTool AddControl(Control ctrl)
        {
            return new ToolBarTool(wxToolBar_AddControl(wxObject, Object.SafePtr(ctrl)));
        }

        public ToolBarTool InsertControl(int pos, Control ctrl)
        {
            return new ToolBarTool(wxToolBar_InsertControl(wxObject, pos, Object.SafePtr(ctrl)));
        }

        public ToolBarTool FindControl(int toolid)
        {
            return (ToolBarTool)FindObject(wxToolBar_FindControl(wxObject, toolid), typeof(ToolBarTool));
        }

        //---------------------------------------------------------------------

        public ToolBarTool AddSeparator()
        {
            return new ToolBarTool(wxToolBar_AddSeparator(wxObject));
        }

        public ToolBarTool InsertSeparator(int pos)
        {
            return new ToolBarTool(wxToolBar_InsertSeparator(wxObject, pos));
        }

        //---------------------------------------------------------------------

        public ToolBarTool RemoveTool(int toolid)
        {
            return (ToolBarTool)FindObject(wxToolBar_RemoveTool(wxObject, toolid), typeof(ToolBarTool));
        }

        public bool DeleteToolByPos(int pos)
        {
            return wxToolBar_DeleteToolByPos(wxObject, pos);
        }

        public bool DeleteTool(int toolid)
        {
            return wxToolBar_DeleteTool(wxObject, toolid);
        }

        public void ClearTools()
        {
            wxToolBar_ClearTools(wxObject);
        }

        //---------------------------------------------------------------------

        /// <summary>
        /// This function should be called after you have added tools.
        /// </summary>
        public bool Realize()
        {
            return wxToolBar_Realize(wxObject);
        }

        //---------------------------------------------------------------------

        public void EnableTool(int toolid, bool enable)
        {
            wxToolBar_EnableTool(wxObject, toolid, enable);
        }

        public void ToggleTool(int toolid, bool toggle)
        {
            wxToolBar_ToggleTool(wxObject, toolid, toggle);
        }

        //---------------------------------------------------------------------

        public void SetToolClientData(int toolid, ClientData clientData)
        {
            wxToolBar_SetToolClientData(wxObject, toolid, Object.SafePtr(clientData));
        }

        public ClientData GetToolClientData(int toolid)
        {
            return (ClientData)Object.FindObject(wxToolBar_GetToolClientData(wxObject, toolid));
        }

        //---------------------------------------------------------------------
        
        public bool GetToolState(int toolid)
        {
            return wxToolBar_GetToolState(wxObject, toolid);
        }

        public bool GetToolEnable(int toolid)
        {
            return wxToolBar_GetToolEnabled(wxObject, toolid);
        }

        //---------------------------------------------------------------------

        public string GetToolShortHelp(int toolid)
        {
            return new wxString(wxToolBar_GetToolShortHelp(wxObject, toolid), true);
        }

        public void SetToolShortHelp(int toolid, string helpString)
        {
            wxString wxhelpstring = wxString.SafeNew(helpString);
            wxToolBar_SetToolShortHelp(wxObject, toolid, Object.SafePtr(wxhelpstring));
        }

        //---------------------------------------------------------------------

        public string GetToolLongHelp(int toolid)
        {
            return new wxString(wxToolBar_GetToolLongHelp(wxObject, toolid), true);
        }

        public void SetToolLongHelp(int toolid, string helpString)
        {
            wxString wxhelpstring = wxString.SafeNew(helpString);
            wxToolBar_SetToolLongHelp(wxObject, toolid, Object.SafePtr(wxhelpstring));
        }

        //---------------------------------------------------------------------

        public void SetMargins(int x, int y)
        {
            Margins = new Size(x, y);
        }

        public Size Margins
        {
            get { 
                int width=-1;
                int height=-1;
			    wxToolBar_GetToolMargins(wxObject, ref width, ref height);
                return new Size(width, height);
			}
            set { wxToolBar_SetMargins(wxObject, value.Width, value.Height); }
        }

        //---------------------------------------------------------------------

        public int ToolPacking
        {
            get { return wxToolBar_GetToolPacking(wxObject); }
            set { wxToolBar_SetToolPacking(wxObject, value); }
        }

        //---------------------------------------------------------------------

        public int Separation
        {
            get { return wxToolBar_GetToolSeparation(wxObject); }
            set { wxToolBar_SetToolSeparation(wxObject, value); }
        }

        //---------------------------------------------------------------------

        public int Rows
        {
            set { wxToolBar_SetRows(wxObject, value); }
        }

        public int MaxRows
        {
            get { return wxToolBar_GetMaxRows(wxObject); }
        }

        public int MaxCols
        {
            get { return wxToolBar_GetMaxCols(wxObject); }
        }

        //---------------------------------------------------------------------

        public void SetMaxRowsCols(int rows, int cols)
        {
            wxToolBar_SetMaxRowsCols(wxObject, rows, cols);
        }

        //---------------------------------------------------------------------

        public Size ToolBitmapSize
        {
            get {
                int width = -1;
                int height = -1;
                wxToolBar_GetToolBitmapSize(wxObject, ref width, ref height); 
                return new Size(width, height);
            }
            set { wxToolBar_SetToolBitmapSize(wxObject, value.Width, value.Height); }
        }

        //---------------------------------------------------------------------

        public Size ToolSize
        {
            get {
                int width = -1;
                int height = -1;
                wxToolBar_GetToolSize(wxObject, ref width, ref height);
                return new Size(width, height);
            }
        }

        //---------------------------------------------------------------------

        public ToolBarTool FindToolForPosition(int x, int y)
        {
            return (ToolBarTool)FindObject(wxToolBar_FindToolForPosition(wxObject, x, y), typeof(ToolBarTool));
        }

        //---------------------------------------------------------------------

        public bool IsVertical
        {
            get { return wxToolBar_IsVertical(wxObject); }
        }

        //---------------------------------------------------------------------

        public override bool AcceptsFocus()
        {
            return wxToolBar_AcceptsFocus(wxObject); 
        }

	}
}

