/** Property collection for STC styles including a dialog.
 * 
 * \file 
 * 
 * (c) 2008 Dr. Harald Meyer auf'm Hofe, harald_meyer@sourceforge.net
 * Licensed under the wxWidgets license, see LICENSE.txt for details.
 * 
 */

#if WXNET_STYLEDTEXTCTRL

using System;
using System.Collections.Generic;
using System.Drawing;
using wx.ComponentModel;

namespace wx.StyledText
{
    /** <summary>Parameters referring to a particular lexer.
     * You may collect all style properties referring to a particular type of text within an instance
     * of this type and apply this styles to a wx.StyledText.StyledTextCtrl if appropriate.</summary>*/
    [Serializable]
    public class StcStyleCollection : System.Xml.Serialization.IXmlSerializable
    {
        #region Nested Types
        /** <summary>Records the text properties that may be associated with styles.
         * Please note, that each property might be <c>null</c> is not defined.</summary>*/
        public class TextProperties : System.Xml.Serialization.IXmlSerializable
        {
            wx.Colour _foreground;
            wx.Colour _background;
            wx.Font _font;
            bool? _underline = null;
            bool _isVisible = true;
            bool? _useItalic = null;
            bool? _useBold = null;
            CaseForce? _lettercase = null;

            public TextProperties()
            {
                this._foreground = null;
                this._background = null;
                this._font = null;
            }

            public TextProperties(wx.Colour foreground, wx.Colour background, wx.Font font)
            {
                this._foreground = foreground;
                this._background = background;
                this._font = font;
            }

            /** <summary>Use predefined settings or derive heuristically a default text property from the state name.</summary>*/
            public TextProperties(LexerStates state, string statename)
            {
                switch (state)
                {
                    case LexerStates.C_PREPROCESSOR:
                        this._foreground = wx.Colour.wxLIGHT_GREY;
                        break;
                    case LexerStates.C_COMMENTDOCKEYWORD:
                        this._foreground = wx.Colour.TheColourDatabase.Find("FOREST GREEN");
                        this._useBold = true;
                        this._useItalic = true;
                        break;
                    case LexerStates.C_CHARACTER:
                        this._foreground = wx.Colour.TheColourDatabase.Find("VIOLET RED");
                        break;
                    case LexerStates.C_OPERATOR:
                        //this._foreground = wx.Colour.TheColourDatabase.Find("SKY BLUE");
                        this._useBold = true;
                        break;
                    default:
                        {
                            if (statename==null)
                                statename = state.ToString();
                            statename=statename.ToLower();
                            if (statename.Contains("comment"))
                                this._foreground = wx.Colour.TheColourDatabase.Find("FOREST GREEN");
                            else if (statename.Contains("string"))
                                this._foreground = wx.Colour.TheColourDatabase.Find("VIOLET RED");
                            else if (statename.Contains("number"))
                                this._foreground = wx.Colour.TheColourDatabase.Find("VIOLET RED");
                            else if (statename.Contains("word"))
                            {
                                //this._foreground = wx.Colour.wxBLUE;
                                this._useBold=true;
                            }
                            else if (statename.Contains("identifier"))
                            {
                                this._foreground = wx.Colour.TheColourDatabase.Find("MIDNIGHT BLUE");
                                this._useItalic = true;
                            }
                            else
                                this._foreground = wx.Colour.TheColourDatabase.Find("DARK GREY");
                            break;
                        }
                }
            }

            [FormItemGroup("Colours", null, "de", "Farben", null)]
            [FormItem("Background Colour", null, "de", "Hintergrundfarbe", null, Sort=1)]
            public wx.Colour Background { get { return this._background; } set { this._background = value; } }
            [FormItem("Foreground Colour", null, "de", "Schriftfarbe", null, Sort = 2)]
            [FormItemGroup("Colours")]
            public wx.Colour Foreground { get { return this._foreground; } set { this._foreground = value; } }

            [FormItemGroup("Font Attributes", null, "de", "Schriftattribute", null)]
            [FormItem("Font", "Defines the font that will be used to display text of this kind. You may define the style flags like \"underline\" or \"bold\" instead.",
                               "de", "Schrift", "Definiert die Schrift, die f�r den Text des hier definierten Stils verwendet wird. Anstatt die Schrift exakt anzugeben, k?nnen einzelne Schriftattribute wie \"unterstrichen\" und \"fett\" durch andere Eigenschaften des Formulars spezifiziert werden.")]
            public wx.Font Font { get { return this._font; } set { this._font = value; } }

            [FormItemGroup("Font Attributes")]
            [FormItem("Underline", null, "de", "unterstrichen", "Text diesen Stils wird unterstrichen dargestellt.")]
            public bool? Underline { get { return this._underline; } set { this._underline = value; } }

            [FormItemGroup("Font Attributes")]
            [FormItem("Visible", null, "de", "sichtbar", null)]
            public bool IsVisible { get { return this._isVisible; } set { this._isVisible = value; } }

            [FormItemGroup("Font Attributes")]
            [FormItem("Italics", null, "de", "kursiv", null)]
            public bool? Italics { get { return _useItalic; } set { this._useItalic = value; } }

            [FormItemGroup("Font Attributes")]
            [FormItem("Bold", null, "de", "fett", null)]
            public bool? Boldface { get { return _useBold; } set { this._useBold = value; } }

            [FormItemGroup("Font Attributes")]
            [FormItem("Lettercase", null, "de", "Gro�-/Kleinschreibung", null)]
            public CaseForce? Lettercase { get { return _lettercase; } set { this._lettercase = value; } }

            #region IXmlSerializable Member
            /** <summary>Not yet implemented.</summary>*/
            public System.Xml.Schema.XmlSchema GetSchema()
            {
                throw new Exception("The method or operation is not implemented.");
            }

            /** <summary></summary>*/
            public void ReadXml(System.Xml.XmlReader reader)
            {
                if (!reader.IsStartElement("stc_textproperties"))
                    throw new FormatException(Window._("Expected <stc_textproperties> parsing XML."));
                reader.MoveToAttribute("visible");
                this._isVisible = Convert.ToInt32(reader.Value) > 0;
                reader.ReadStartElement();
                if (reader.IsStartElement("foreground"))
                {
                    reader.ReadStartElement();
                    XmlSerializer serializer = new XmlSerializer();
                    serializer.ReadXml(reader);
                    this._foreground = serializer.Colour;
                    reader.ReadEndElement();
                }
                if (reader.IsStartElement("background"))
                {
                    reader.ReadStartElement();
                    XmlSerializer serializer = new XmlSerializer();
                    serializer.ReadXml(reader);
                    this._background = serializer.Colour;
                    reader.ReadEndElement();
                }
                if (reader.IsStartElement("font"))
                {
                    XmlSerializer serializer = new XmlSerializer();
                    serializer.ReadXml(reader);
                    this._font = serializer.Font;
                }
                if (reader.IsStartElement("boldface"))
                {
                    reader.ReadStartElement();
                    this._useBold = Convert.ToInt32(reader.ReadString()) > 0;
                    reader.ReadEndElement();
                }
                if (reader.IsStartElement("italics"))
                {
                    reader.ReadStartElement();
                    this._useItalic = Convert.ToInt32(reader.ReadString()) > 0;
                    reader.ReadEndElement();
                }
                if (reader.IsStartElement("underline"))
                {
                    reader.ReadStartElement();
                    this._underline = Convert.ToInt32(reader.ReadString()) > 0;
                    reader.ReadEndElement();
                }
                if (reader.IsStartElement("lettercase"))
                {
                    reader.ReadStartElement();
                    this._lettercase = (CaseForce)Enum.Parse(typeof(CaseForce), reader.ReadString());
                    reader.ReadEndElement();
                }
                reader.ReadEndElement();
            }

            /** <summary>write properties into a <c>stc_textproperties</c> tag.</summary>*/
            public void WriteXml(System.Xml.XmlWriter writer)
            {
                writer.WriteStartElement("stc_textproperties");
                writer.WriteAttributeString("visible", this.IsVisible?"1":"0");
                if (this.Foreground != null)
                {
                    writer.WriteStartElement("foreground");
                    XmlSerializer serializer = new XmlSerializer(this.Foreground);
                    serializer.WriteXml(writer);
                    writer.WriteEndElement();
                }
                if (this.Background != null)
                {
                    writer.WriteStartElement("background");
                    XmlSerializer serializer = new XmlSerializer(this.Background);
                    serializer.WriteXml(writer);
                    writer.WriteEndElement();
                }
                if (this.Font != null)
                {
                    XmlSerializer serializer = new XmlSerializer(this.Font);
                    serializer.WriteXml(writer);
                }
                if (this.Boldface != null && this.Boldface.HasValue)
                    writer.WriteElementString("boldface", this.Boldface.Value ? "1" : "0");
                if (this.Italics != null && this.Italics.HasValue)
                    writer.WriteElementString("italics", this.Italics.Value ? "1" : "0");
                if (this.Underline != null && this.Underline.HasValue)
                    writer.WriteElementString("underline", this.Underline.Value ? "1" : "0");
                if (this.Lettercase != null && this.Lettercase.HasValue)
                    writer.WriteElementString("lettercase", this.Lettercase.Value.ToString());
                writer.WriteEndElement();
            }

            #endregion
        }
        #endregion

        #region Private State
        string _name;
        LexerId _lexer;
        Dictionary<Keywords, string[]> _kewordSets = new Dictionary<Keywords, string[]>();
        Dictionary<LexerStates, TextProperties> _lexerStateProps = new Dictionary<LexerStates, TextProperties>();

        Dictionary<StyledTextCtrl, StyledTextCtrl> _affectedCtrls = new Dictionary<StyledTextCtrl, StyledTextCtrl>();

        Dictionary<StyledTextCtrl, StyledTextCtrl> _activatedForCtrls= new Dictionary<StyledTextCtrl,StyledTextCtrl>();
        #endregion

        #region CTor
        /** <summary>Creates a new set of properties.</summary>
         * <param name="languageName">defines the name of the programming language. This will be used in lists to identify this style properties.</param>
         * <param name="stylesForLexer"> defines the used lexer that will analyse the language.</param>
         */
        public StcStyleCollection(string languageName, LexerId stylesForLexer)
        {
            this._name = languageName;
            this.SyntaxEnable = true;
            this._lexer = stylesForLexer;

            this._lexerStateProps[LexerStates.DEFAULT] = new TextProperties(wx.Colour.TheColourDatabase.Find("DARK GREY"), null, null);
            this._lexerStateProps[LexerStates.INDENTGUIDE] = new TextProperties(wx.Colour.wxLIGHT_GREY, null, null);
            this._lexerStateProps[LexerStates.LINENUMBER] = new TextProperties(wx.Colour.TheColourDatabase.Find("DARK GREY"), null, null);
            this._lexerStateProps[LexerStates.BRACELIGHT] = new TextProperties(wx.Colour.TheColourDatabase.Find("MAGENTA"), null, null);
            this._lexerStateProps[LexerStates.BRACEBAD] = new TextProperties(wx.Colour.TheColourDatabase.Find("MAROON"), null, null);
            this._lexerStateProps[LexerStates.CONTROLCHAR] = new TextProperties(wx.Colour.TheColourDatabase.Find("CYAN"), null, null);

            string[] prefixes = StyledTextCtrl.StatePrefixForLexer(stylesForLexer);
            foreach (string lexerStateName in Enum.GetNames(typeof(LexerStates)))
            {
                LexerStates enumInstance=(LexerStates) Enum.Parse(typeof(LexerStates), lexerStateName);
                if (!this._lexerStateProps.ContainsKey(enumInstance))
                {
                    if (lexerStateName.IndexOf('_') < 0)
                        this._lexerStateProps[enumInstance] = new TextProperties(enumInstance, lexerStateName);
                    else if (prefixes != null)
                    {
                        // this is a little hack to avoid explicit definition of those styles that are appropriate to the used lexer.
                        // we use the prefix of the lexer state name according to StatePrefixForLexer() to identify the relevant styles.
                        foreach (string prefix in prefixes)
                        {
                            if (lexerStateName.StartsWith(prefix))
                            {
                                this._lexerStateProps[enumInstance] = new TextProperties(enumInstance, lexerStateName);
                                break;
                            }
                        }
                    }
                }
            }
        }
        #endregion

        #region Public State And Properties
        [FormItem("File suffixes", "Defines the file suffixes (characters after the final \".\" in the filename) referring to this style. This will be used to identify appropriate styles to files loaded from an editor.")]
        public string[] FileSuffixes = null;

        [FormItem("Syntax Highlighting", "Enables or disables syntax highlighting.")]
        public bool SyntaxEnable;

        [FormItem("View \"End Of Line\"", "Defines the way that line endings will be displayed.")]
        public bool ViewEOL = false;

        [FormItem("View white spaces", "Defines the way that white spaces will be displayed.")]
        public WhiteSpaceModes ViewWhiteSpace = WhiteSpaceModes.VISIBLEALWAYS;

        [FormItemGroup("Line Wrapping", null)]
        [FormItem("Word wrapping", "Defines whether lines will be wrapped that are too long to fit into the displayed client size.")]
        public WrapModes WrapMode = WrapModes.NONE;

        [FormItemGroup("Line Wrapping")]
        [FormItem("Edge Mode", null)]
        public EdgeModes EdgeMode = EdgeModes.NONE;

        [FormItemGroup("Line Wrapping")]
        [FormItem("Edge Column", "Maximal number of characters displayed in one line without inserting edges.")]
        public int EdgeColumn = 80;

        [FormItemGroup("Indention", null)]
        [FormItem("Overtype (or indent) mode", "Defines whether to use white characters instead of tabs.")]
        public bool Overtype = false;

        [FormItemGroup("Indention")]
        [FormItem("Indention", null)]
        public int Indent = 3;

        [FormItemGroup("Indention")]
        [FormItem("Tab Width", "Number of white spaces that are equivalent to a TAB.")]
        public int TabWidth = 3;

        [FormItemGroup("Indention")]
        [FormItem("Tab Indents", "True iff TABs are used to indent lines.")]
        public bool TabIndents = true;

        [FormItemGroup("Indention")]
        [FormItem("Use Tabs", "True iff this editor accepts TAB keys.")]
        public bool UseTabs = true;

        [FormItemGroup("Indention")]
        [FormItem("Backspace Unindents", "True iff this editor accepts TAB keys.")]
        public bool BackSpaceUnIndents = true;

        [FormItemGroup("Indention")]
        [FormItem("Indention Guides", null)]
        public bool IndentationGuides = true;

        [FormItem("View Line Numbers", null)]
        public bool ViewLineNumbers = true;

        [FormItem("Folding", null)]
        public bool IsFolding = true;

        [FormItem("Language", "The name of the displayed programming language.", IsReadOnly=true)]
        public string Name { get { return this._name; } }

        [FormItem("Use Lexer", "The chosen lexer implementation.", IsReadOnly=true)]
        public LexerId Lexer { get { return this._lexer; } }

        [FormItem("Specific styles", "Defines the appearance of the particular styles.")]
        public IDictionary<LexerStates, TextProperties> LexerStateProperties { get { return this._lexerStateProps; } }

        [FormItem("Keyword sets", null)]
        public IDictionary<Keywords, string[]> KeywordSets { get { return this._kewordSets; } }
        #endregion

        #region Application
        /** <summary>Deactivates this style for the provided control.
         * From calling this method on, this style will not react on events sent from <c>stc</c> (e.g. for folding).
         * Run this if you want to use another style in <c>stc</c> in order to avoid side-effects between both.</summary>*/
        public void DeactivateFor(wx.StyledText.StyledTextCtrl stc)
        {
            if (this._activatedForCtrls.ContainsKey(stc))
                this._activatedForCtrls.Remove(stc);
        }

        /** <summary>This will apply the represented settings to the provided styled text editor.
         * This method activated this style i.e. all events from the <c>destination</c> will be processed.
         * Do not forget do Deactivate() this if the control loads another style.</summary>*/
        public void Apply(wx.StyledText.StyledTextCtrl destination)
        {
            destination.StyleClearAll();

            destination.Lexer = this._lexer;
            destination.ViewEOL = this.ViewEOL;
            destination.ViewWhiteSpace = this.ViewWhiteSpace;
            destination.WrapMode = this.WrapMode;
            destination.Overtype = this.Overtype;
            destination.Indent = this.Indent;
            destination.EdgeMode = this.EdgeMode;
            destination.SetMarginType(0, MarginType.NUMBER);

            destination.TabWidth = this.TabWidth;
            destination.UseTabs = this.UseTabs;
            destination.TabIndents = this.TabIndents;
            destination.BackSpaceUnIndents = this.BackSpaceUnIndents;

            destination.IndentationGuides = true;
            destination.EdgeColumn = this.EdgeColumn;

            string maxLineString="000";
            if (destination.LineCount > 200)
                maxLineString = "0000";
            if (destination.LineCount > 8000)
                maxLineString = "00000";
            int marginWidth = 0;
            if (this.ViewLineNumbers)
            {
                int height;
                destination.GetTextExtent(maxLineString, out marginWidth, out height);
            }
            destination.SetMarginWidth(0, marginWidth);

            // folding
            /*
            destination.SetMarginType(1, MarginType.SYMBOL);
            destination.SetMarginMask(1, MarginMask.NONE);
            destination.SetMarginWidth(1, 0);
            destination.SetMarginSensitive(1, false);
            */
            if (this.IsFolding)
            {
                destination.SetMarginWidth(2, 16);
                destination.SetMarginMask(2, MarginMask.FOLDERS);
                destination.SetMarginType(2, MarginType.SYMBOL);
                destination.SetMarginSensitive(2, true);

                destination.SetProperty("fold", "1");
                destination.SetProperty("fold.comment", "1");
                destination.SetProperty("fold.compact", "1");
                destination.SetProperty("fold.preprocessor", "1");

                destination.SetProperty("fold.html", "1");
                destination.SetProperty("fold.htmlprep", "1");
                destination.SetProperty("fold.commentpy", "1");
                destination.SetProperty("fold.quotespy", "1");
            }
            else
                destination.SetProperty("fold", "0");
            destination.FoldFlags = TheFoldFlags.LINEBEFORE_CONTRACTED | TheFoldFlags.LINEAFTER_CONTRACTED;

            destination.MarkerDefine(MarkNum.FOLDER, Mark.BOXPLUS);
            destination.MarkerDefine(MarkNum.FOLDEROPEN, Mark.BOXMINUS);
            destination.MarkerDefine(MarkNum.FOLDERSUB, Mark.VLINE, Colour.wxBLACK, Colour.wxBLACK);
            destination.MarkerDefine(MarkNum.FOLDEREND, Mark.CIRCLEPLUS);
            destination.MarkerDefine(MarkNum.FOLDEROPENMID, Mark.CIRCLEMINUS);
            destination.MarkerDefine(MarkNum.FOLDERMIDTAIL, Mark.VLINE, Colour.wxBLACK, Colour.wxBLACK);
            destination.MarkerDefine(MarkNum.FOLDERTAIL, Mark.VLINE, Colour.wxBLACK, Colour.wxBLACK);

            this._activatedForCtrls[destination] = destination;
            if (!this._affectedCtrls.ContainsKey(destination))
            {
                destination.MarginClick += new EventListener(this.OnFoldMarginClick);
                this._affectedCtrls.Add(destination, destination);
            }

            if (this.SyntaxEnable)
            {
                foreach (KeyValuePair<LexerStates, TextProperties> pairs in this._lexerStateProps)
                {
                    if (pairs.Value.Font != null)
                        destination.StyleSetFont(pairs.Key, pairs.Value.Font);
                    if (pairs.Value.Foreground != null)
                        destination.StyleSetForeground(pairs.Key, pairs.Value.Foreground);
                    if (pairs.Value.Background != null)
                        destination.StyleSetBackground(pairs.Key, pairs.Value.Background);
                    destination.StyleSetVisible(pairs.Key, pairs.Value.IsVisible);

                    if (pairs.Value.Lettercase.HasValue)
                        destination.StyleSetCase(pairs.Key, pairs.Value.Lettercase.Value);
                    if (pairs.Value.Underline.HasValue)
                        destination.StyleSetUnderline(pairs.Key, pairs.Value.Underline.Value);
                    if (pairs.Value.Boldface.HasValue)
                        destination.StyleSetBold(pairs.Key, pairs.Value.Boldface.Value);
                }
                foreach (Keywords keywordSetId in this._kewordSets.Keys)
                {
                    destination.SetKeyWords(keywordSetId, this._kewordSets[keywordSetId]);
                }
            }
        }
        #endregion

        #region Events
        /** <summary>This will fold or unfold the clicked region.
         * The sender probably is a styled text control where this configuration has been applied to.</summary>*/
        void OnFoldMarginClick(object senderOrig, Event evtOrig)
        {
            StyledTextEvent evt = evtOrig as StyledTextEvent;
            StyledTextCtrl sender = senderOrig as StyledTextCtrl;
            if (this.IsFolding && sender != null
                && evt != null
                && evt.Margin==2
                && this._activatedForCtrls.ContainsKey(sender))
            {
                // well, most probably the margin used for folding has been hit by the mouse
                int lineClick = sender.LineFromPosition(evt.Position);
                FoldLevel levelClick = sender.GetFoldLevelFlags(lineClick);
                if ((levelClick & FoldLevel.HEADERFLAG) == FoldLevel.HEADERFLAG)
                {
                    sender.ToggleFold(lineClick);
                }
            }
        }
        #endregion

        #region IXmlSerializable Member
        /** <summary>Not yet implemented.</summary>*/
        public System.Xml.Schema.XmlSchema GetSchema()
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public void ReadXml(System.Xml.XmlReader reader)
        {
            if (!reader.IsStartElement("stc_styles"))
                throw new System.FormatException(Window._("Expected <stc_styles> tag parsing XML."));
            reader.MoveToAttribute("name");
            this._name = reader.Value;
            reader.MoveToAttribute("lexer");
            this._lexer = (LexerId)Enum.Parse(typeof(LexerId), reader.Value);
            reader.ReadStartElement();
            while (true)
            {
                if (reader.IsStartElement("suffixes"))
                {
                    List<string> suffixes = new List<string>();
                    reader.ReadStartElement();
                    while (reader.IsStartElement("suffix"))
                    {
                        reader.ReadStartElement();
                        suffixes.Add(reader.ReadString());
                        reader.ReadEndElement();
                    }
                    reader.ReadEndElement();
                    this.FileSuffixes = suffixes.ToArray();
                }
                else if (reader.NodeType == System.Xml.XmlNodeType.EndElement && reader.Name == "stc_styles")
                    break; // finished
                else if (reader.IsStartElement("keywordset"))
                {
                    reader.MoveToAttribute("index");
                    Keywords index = (Keywords)Convert.ToInt32(reader.Value);
                    reader.ReadStartElement();
                    List<string> keywords = new List<string>();
                    while (reader.IsStartElement("keyword"))
                    {
                        reader.ReadStartElement();
                        keywords.Add(reader.ReadString());
                        reader.ReadEndElement();
                    }
                    reader.ReadEndElement();
                    this.KeywordSets[index] = keywords.ToArray();
                }
                else if (reader.IsStartElement("lexerstate"))
                {
                    reader.MoveToAttribute("name");
                    reader.ReadStartElement();
                    while (reader.IsStartElement("stc_textproperties"))
                    {
                        TextProperties newProps = new TextProperties();
                        newProps.ReadXml(reader);
                    }
                    reader.ReadEndElement();
                }
                else
                    throw new FormatException(Window._("Unknown xml element {0} in <stc_styles>.", reader.Name));
            }
        }

        /** <summary>Writes all properties into <c>stc_styles</c> tag.</summary>*/
        public void WriteXml(System.Xml.XmlWriter writer)
        {
            writer.WriteStartElement("stc_styles");
            writer.WriteAttributeString("name", this.Name);
            writer.WriteAttributeString("lexer", this.Lexer.ToString());
            if (this.FileSuffixes != null)
            {
                writer.WriteStartElement("suffixes");
                foreach (string suffix in this.FileSuffixes)
                {
                    writer.WriteElementString("suffix", suffix);
                }
                writer.WriteEndElement();
            }
            foreach (KeyValuePair<Keywords, string[]> keywordPair in this.KeywordSets)
            {
                writer.WriteStartElement("keywordset");
                writer.WriteAttributeString("index", ((int)keywordPair.Key).ToString());
                foreach (string keyword in keywordPair.Value)
                    writer.WriteElementString("keyword", keyword);
                writer.WriteEndElement();
            }
            foreach (KeyValuePair<LexerStates, TextProperties> textStyles in this.LexerStateProperties)
            {
                writer.WriteStartElement("lexerstate");
                writer.WriteAttributeString("name", StyledTextCtrl.GetLexerStateName(textStyles.Key, this.Lexer));
                textStyles.Value.WriteXml(writer);
                writer.WriteEndElement();
            }
            writer.WriteEndElement();
        }

        #endregion
    }

    /** <summary>Stores a full set of configurations.
     * This creates a default set of styles for some programming languages and manages them.
     * You may add or remove instances of StcStyleCollection as you like. This class also assigns
     * styles to text files referring to their name in the file system. 
     * Use instances of this class as a database of styles defining the way that text files are
     * presented in a wx.StyledText.StyledTextCtrl.</summary>*/
    public class StcStyleConfiguration : System.Xml.Serialization.IXmlSerializable
    {
        #region State
        public List<StcStyleCollection> Data = new List<StcStyleCollection>();
        #endregion

        #region CTor
        public StcStyleConfiguration()
        {
            this.Data.Add(new StcStyleCollection("C++", LexerId.CPP));
            this.Data.Add(new StcStyleCollection("Python", LexerId.PYTHON));
            this.Data.Add(new StcStyleCollection("C#", LexerId.CPP));
            this.Data.Add(new StcStyleCollection("HTML", LexerId.HTML));
            this.Data.Add(new StcStyleCollection("Default", LexerId.NULL));

            StcStyleCollection cpp = this.Data[0];
            StcStyleCollection csharp = this.Data[2];
            StcStyleCollection python = this.Data[1];
            StcStyleCollection html = this.Data[3];
            StcStyleCollection nullStyles = this.Data[4];

            cpp.FileSuffixes = new string[] { "c", "cpp", "cxx", "cc", "h", "hpp", "hh", "hxx" };
            cpp.KeywordSets[Keywords.C_WORD] = new string[]
                { "abstract", "asm", "auto", "bool", "break", "case", "catch", "char", "class", "const", "const_cast",
                  "continue", "default", "delete", "do", "double", "dynamic_cast", "else", "enum", "explicit",
                  "export", "extern", "false", "float", "for", "friend", "goto", "if", "inline", "int", "long",
                  "mutable", "namespace", "new", "operator", "private", "protected", "public", "register",
                  "reinterpret_cast", "return", "short", "signed", "sizeof", "static", "static_cast",
                  "struct", "switch", "template", "this", "throw", "true", "try", "typedef", "typeid",
                  "typename", "union", "unsigned", "using", "virtual", "void", "volatile", "wchar_t",
                  "while"
                };
            cpp.KeywordSets[Keywords.C_WORD2] = new string[] { "file" };
            // doxygen comments.
            cpp.KeywordSets[Keywords.C_COMMENTDOCKEYWORD] = new string[]
                {
                    "a", "addindex", "addtogroup", "anchor", "arg", "attention", "author", "b", "brief", "bug", "c",
                    "class", "code", "date", "def", "defgroup", "deprecated", "dontinclude", "e", "em", "endcode",
                    "endhtmlonly", "endif", "endlatexonly", "endlink", "endverbatim", "enum", "example",
                    "exception", "f$", "f[", "f]", "file", "fn", "hideinitializer", "htmlinclude",
                    "htmlonly", "if", "image", "include", "ingroup", "internal", "invariant", "interface",
                    "latexonly", "li", "line", "link", "mainpage", "name", "namespace", "nosubgrouping", "note",
                    "overload", "p", "page", "par", "param", "post", "pre", "ref", "relates", "remarks", "return",
                    "retval", "sa", "section", "see", "showinitializer", "since", "skip", "skipline", "struct",
                    "subsection", "test", "throw", "todo", "typedef", "union", "until", "var", "verbatim",
                    "verbinclude", "version", "warning", "weakgroup", "$", "@", "\"\"", "&", "<", ">", "#", "{", "}"
                };

            csharp.FileSuffixes = new string[] { "cs" };
            csharp.KeywordSets[Keywords.C_WORD] = new string[]
                { "abstract", "bool", "break", "case", "catch", "char", "class", "const",
                  "continue", "default", "do", "double", "else", "enum", "extern", 
                  "false", "finally", "float", "for", "foreach", "if", "int", "interface", "long",
                  "namespace", "new", "operator", "override", "private", "protected", "public",
                  "return", "short", "signed", "static", "string",
                  "struct", "switch", "this", "throw", "true", "try",
                  "unsigned", "using", "virtual", "void", "while"
                };
            csharp.KeywordSets[Keywords.C_WORD2] = new string[] { "file" };
            // doxygen comments.
            csharp.KeywordSets[Keywords.C_COMMENTDOCKEYWORD] = new string[]
                {
                    "a", "addindex", "addtogroup", "anchor", "arg", "attention", "author", "b", "brief", "bug", "c",
                    "class", "code", "date", "def", "defgroup", "deprecated", "dontinclude", "e", "em", "endcode",
                    "endhtmlonly", "endif", "endlatexonly", "endlink", "endverbatim", "enum", "example",
                    "exception", "f$", "f[", "f]", "file", "fn", "hideinitializer", "htmlinclude",
                    "htmlonly", "if", "image", "include", "ingroup", "internal", "invariant", "interface",
                    "latexonly", "li", "line", "link", "mainpage", "name", "namespace", "nosubgrouping", "note",
                    "overload", "p", "page", "par", "param", "post", "pre", "ref", "relates", "remarks", "return",
                    "retval", "sa", "section", "see", "showinitializer", "since", "skip", "skipline", "struct",
                    "subsection", "test", "throw", "todo", "typedef", "union", "until", "var", "verbatim",
                    "verbinclude", "version", "warning", "weakgroup", "$", "@", "\"\"", "&", "<", ">", "#", "{", "}"
                };

            python.FileSuffixes = new string[] { "py", "pyw" };
            python.KeywordSets[Keywords.PY_WORD] = new string[]
                {
                  "and", "assert", "break", "class", "continue", "def", "del", "elif", "else", "except", "exec",
                  "finally", "for", "from", "global", "if", "import", "in", "is", "lambda", "None", "not", "or", "pass",
                  "print", "raise", "return", "try", "while", "yield"
                };
            python.KeywordSets[Keywords.PY_DEFNAME] = new string[]
                {
                    "ACCELERATORS", "ALT", "AUTO3STATE", "AUTOCHECKBOX", "AUTORADIOBUTTON", "BEGIN",
                    "BITMAP", "BLOCK", "BUTTON", "CAPTION", "CHARACTERISTICS", "CHECKBOX", "CLASS",
                    "COMBOBOX", "CONTROL", "CTEXT", "CURSOR", "DEFPUSHBUTTON", "DIALOG", "DIALOGEX",
                    "DISCARDABLE", "EDITTEXT", "END", "EXSTYLE", "FONT", "GROUPBOX", "ICON", "LANGUAGE",
                    "LISTBOX", "LTEXT", "MENU", "MENUEX", "MENUITEM", "MESSAGETABLE", "POPUP", "PUSHBUTTON",
                    "RADIOBUTTON", "RCDATA", "RTEXT", "SCROLLBAR", "SEPARATOR", "SHIFT", "STATE3",
                    "STRINGTABLE", "STYLE", "TEXTINCLUDE", "VALUE", "VERSION", "VERSIONINFO", "VIRTKEY"
                };

            html.FileSuffixes = new string[] { "html", "htm" };


            nullStyles.SyntaxEnable = false;
        }
        #endregion

        #region Selectors
        /** <summary>Returns the styles appropriate to a file names <c>filename</c>.
         * This will look for a matching suffix property of a contained style description.
         * This will return the first style without suffix constraint if none of the contained
         * description matches the file name.</summary>*/
        public StcStyleCollection ForFilename(string filename)
        {
            StcStyleCollection defaultrecord = null;
            filename = filename.ToLower();
            foreach (StcStyleCollection record in this.Data)
            {
                if (record.FileSuffixes == null)
                {
                    if (defaultrecord == null)
                        defaultrecord = record;
                }
                else
                {
                    foreach (string suffix in record.FileSuffixes)
                    {
                        if (filename.EndsWith(suffix))
                            return record;
                    }
                }
            }
            return defaultrecord;
        }
        #endregion

        #region IXmlSerializable Member
        /** <summary>Not yet implemented.</summary>*/
        public System.Xml.Schema.XmlSchema GetSchema()
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public void ReadXml(System.Xml.XmlReader reader)
        {
            reader.ReadStartElement("stc_config");
            while (reader.IsStartElement("stc_styles"))
            {
                StcStyleCollection newStyles = new StcStyleCollection("unknown", LexerId.NULL);
                newStyles.ReadXml(reader);
                this.Data.Add(newStyles);
            }
            reader.ReadEndElement();
        }

        public void WriteXml(System.Xml.XmlWriter writer)
        {
            writer.WriteStartElement("stc_config");
            foreach (StcStyleCollection styles in this.Data)
                styles.WriteXml(writer);
            writer.WriteEndElement();
        }

        #endregion
    }
}

#endif 
