//-----------------------------------------------------------------------------
// wx.NET - Pen.cs
//
// The wxPen wrapper class.
//
// Written by Jason Perkins (jason@379.com)
// (C) 2003 by 379, Inc.
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: Pen.cs,v 1.14 2010/04/11 16:14:27 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Runtime.InteropServices;

namespace wx
{
	public class Pen : GDIObject
	{
		[DllImport("wx-c")] static extern IntPtr wxPen_ctor(IntPtr col, int width, int style);
		[DllImport("wx-c")] static extern IntPtr wxPen_ctorByName(IntPtr name, int width, int style);
	
		[DllImport("wx-c")] static extern IntPtr wxPen_GetColour(IntPtr self);
		[DllImport("wx-c")] static extern void   wxPen_SetColour(IntPtr self, IntPtr col);
	
		[DllImport("wx-c")] static extern void   wxPen_SetWidth(IntPtr self, int width);
		[DllImport("wx-c")] static extern int    wxPen_GetWidth(IntPtr self);
		
		[DllImport("wx-c")] static extern int    wxPen_GetCap(IntPtr self);
		[DllImport("wx-c")] static extern int    wxPen_GetJoin(IntPtr self);
		[DllImport("wx-c")] static extern int    wxPen_GetStyle(IntPtr self);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxPen_Ok(IntPtr self);
		[DllImport("wx-c")] static extern void   wxPen_SetCap(IntPtr self, int capStyle);
		[DllImport("wx-c")] static extern void   wxPen_SetJoin(IntPtr self, int join_style);
		[DllImport("wx-c")] static extern void   wxPen_SetStyle(IntPtr self, int style);

		//---------------------------------------------------------------------

        /** <summary>Styles for pens.</summary>*/
        public enum Styles
        {
            SOLID = 100,
            DOT,
            LONG_DASH,
            SHORT_DASH,
            DOT_DASH,
            USER_DASH,

            TRANSPARENT,

            STIPPLE = 110,
            BDIAGONAL_HATCH,
            CROSSDIAG_HATCH,
            FDIAGONAL_HATCH,
            CROSS_HATCH,
            HORIZONTAL_HATCH,
            VERTICAL_HATCH,
        }

		public Pen(IntPtr wxObject) 
			: base(wxObject) { }

		public Pen(string name) 
			: this(name, 1, Styles.SOLID) { }
			
		public Pen(string name, int width)
            : this(name, width, Styles.SOLID) { }
			
		public Pen(string name, int width, Styles style) 
			: this(wxString.SafeNew(name), width, style) { }

        public Pen(wxString name, int width, Styles style)
            : base(wxPen_ctorByName(Object.SafePtr(name), width, (int)style)) { }

        public Pen(Colour colour) 
			: this(colour, 1, Styles.SOLID) { }
			
		public Pen(Colour colour, int width) 
			: this(colour, width, Styles.SOLID) { }
			
		public Pen(Colour col, int width, Styles style)
			: base(wxPen_ctor(Object.SafePtr(col), width, (int)style)) { }

        /** <summary>This is the synonym to wx.PenList.ThePenList.</summary>*/
        public static PenList ThePenList
        {
            get { return wx.PenList.ThePenList; }
        }
		//---------------------------------------------------------------------
        
		public Colour Colour
		{
			get { return (Colour)FindObject(wxPen_GetColour(wxObject), typeof(Colour)); }
			set {
                if (this.IsReadonly)
                    throw new CannotChangeReadonly();
                wxPen_SetColour(wxObject, Object.SafePtr(value));
            }
		}

		//---------------------------------------------------------------------

		public int Width 
		{
			get { return wxPen_GetWidth(wxObject); }
			set {
                if (this.IsReadonly)
                    throw new CannotChangeReadonly();
                wxPen_SetWidth(wxObject, value);
            }
		}
	
		//---------------------------------------------------------------------
	
		public int Cap
		{
			get { return wxPen_GetCap(wxObject); }
			set {
                if (this.IsReadonly)
                    throw new CannotChangeReadonly();
                wxPen_SetCap(wxObject, value);
            }
		}
	
		//---------------------------------------------------------------------
	
		public int Join
		{
			get { return wxPen_GetJoin(wxObject); }
			set {
                if (this.IsReadonly)
                    throw new CannotChangeReadonly();
                wxPen_SetJoin(wxObject, value);
            }
		}
	
		//---------------------------------------------------------------------
	
		public Styles Style
		{
			get { return (Styles)wxPen_GetStyle(wxObject); }
			set {
                if (this.IsReadonly)
                    throw new CannotChangeReadonly();
                wxPen_SetStyle(wxObject, (int)value);
            }
		}
	
		//---------------------------------------------------------------------
	
		public bool Ok
		{
			get { return wxPen_Ok(wxObject); }
		}
    }
}
