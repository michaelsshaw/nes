//-----------------------------------------------------------------------------
// wx.NET - DocManager.cs
//
// Wrapper for wxArchiveInputStream and wxArchiveOutputStream.
//
// Written by Harald Meyer auf'm Hofe
// (C) 2010 by Harald Meyer auf'm Hofe
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: DocManager.cs,v 1.2 2010/07/12 18:23:50 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using wx.NetMacros;

/** This namespace contains classes to deal with .NET documentation.
*/
namespace wx.Doc
{

    /// <summary>
    /// Instances are document entries for types.
    /// </summary>
    public class TypeDoc
    {
        string _summary = "";
        TypeDescriptor _type = null;
        string[] _seealso = new string[0];
        string[] _see = new string[0];

        public TypeDoc()
        {
        }

        /// <summary>
        /// Creates a document entry.
        /// </summary>
        /// <param name="t">The documented type.</param>
        /// <param name="summary">The summary description of the type (XML).</param>
        public TypeDoc(TypeDescriptor t, string summary)
        {
            this._type = t;
            this._summary = summary;
        }

        /// <summary>
        /// The documented type.
        /// </summary>
        public TypeDescriptor Type { get { return this._type; } set { this._type = value; } }

        /// <summary>
        /// The content of the summary tag.
        /// </summary>
        public string Summary { get { return this._summary; } set { this._summary = value; } }

        /// <summary>
        /// List of references (serializations of TypeDesciptor, MemberDescriptor, or MethodDescriptor)
        /// pointing at the documentation of another code element
        /// </summary>
        public string[] SeeAlso { get { return this._seealso; } set { this._seealso = value; } }

        /// <summary>
        /// List of references (serializations of TypeDesciptor, MemberDescriptor, or MethodDescriptor)
        /// pointing at the documentation of another code element
        /// </summary>
        public string[] See { get { return this._see; } set { this._see = value; } }

        public override string ToString()
        {
            System.IO.StringWriter sb = new System.IO.StringWriter();
            using (System.Xml.XmlTextWriter dest = new System.Xml.XmlTextWriter(sb))
            {
                dest.Formatting = System.Xml.Formatting.Indented;
                dest.WriteStartElement("member");
                dest.WriteAttributeString("name", this._type.ToString());
                if (this.Summary.Length > 0)
                {
                    dest.WriteStartElement("summary");
                    dest.WriteString(this.Summary);
                    dest.WriteEndElement();
                }
                foreach (string see in this._see)
                {
                    dest.WriteStartElement("see");
                    dest.WriteAttributeString("cref", see);
                    dest.WriteEndElement();
                }
                foreach (string see in this._seealso)
                {
                    dest.WriteStartElement("see");
                    dest.WriteAttributeString("cref", see);
                    dest.WriteEndElement();
                }
            }
            return sb.ToString();
        }
    }

    /// <summary>
    /// Instances are document entries for properties of classes.
    /// </summary>
    public class PropertyDoc
    {
        string _summary = "";
        MemberDescriptor _property = null;
        string[] _seealso = new string[0];
        string[] _see = new string[0];

        public PropertyDoc()
        {
        }

        /// <summary>
        /// Creates a document entry.
        /// </summary>
        /// <param name="pi">The documented property.</param>
        /// <param name="summary">The summary description of the property (XML).</param>
        public PropertyDoc(MemberDescriptor pi, string summary)
        {
            this._property = pi;
            this._summary = summary;
        }

        /// <summary>
        /// The documented type.
        /// </summary>
        public MemberDescriptor Property { get { return this._property; } set { this._property = value; } }

        /// <summary>
        /// The content of the summary tag.
        /// </summary>
        public string Summary { get { return this._summary; } set { this._summary = value; } }

        /// <summary>
        /// List of references (serializations of TypeDesciptor, MemberDescriptor, or MethodDescriptor)
        /// pointing at the documentation of another code element
        /// </summary>
        public string[] SeeAlso { get { return this._seealso; } set { this._seealso = value; } }

        /// <summary>
        /// List of references (serializations of TypeDesciptor, MemberDescriptor, or MethodDescriptor)
        /// pointing at the documentation of another code element
        /// </summary>
        public string[] See { get { return this._see; } set { this._see = value; } }


        public override string ToString()
        {
            System.IO.StringWriter sb = new System.IO.StringWriter();
            using (System.Xml.XmlTextWriter dest = new System.Xml.XmlTextWriter(sb))
            {
                dest.Formatting = System.Xml.Formatting.Indented;
                dest.WriteStartElement("member");
                dest.WriteAttributeString("name", this._property.ToString());
                if (this.Summary.Length > 0)
                {
                    dest.WriteStartElement("summary");
                    dest.WriteString(this.Summary);
                    dest.WriteEndElement();
                }
                foreach (string see in this._see)
                {
                    dest.WriteStartElement("see");
                    dest.WriteAttributeString("cref", see);
                    dest.WriteEndElement();
                }
                foreach (string see in this._seealso)
                {
                    dest.WriteStartElement("see");
                    dest.WriteAttributeString("cref", see);
                    dest.WriteEndElement();
                }
            }
            return sb.ToString();
        }

    }

    /// <summary>
    /// Class to represent document entries on methods.
    /// </summary>
    public class MethodDoc
    {
        SortedList<string, string> _docOnParameters = new SortedList<string, string>();
        MemberDescriptor _methodName;
        string _summary = "";
        string _returns = "";
        SortedList<TypeDescriptor, string> _exceptions = new SortedList<TypeDescriptor, string>();
        string[] _seealso = new string[0];
        string[] _see = new string[0];

        public MethodDoc()
        {
            this._methodName = null;
        }

        /// <summary>
        /// Creates a dosumentation entry describing a method.
        /// </summary>
        /// <param name="methodName">Designator of the documented method.</param>
        /// <param name="summary">Summary text.</param>
        public MethodDoc(MemberDescriptor methodName, string summary)
        {
            this._methodName = methodName;
            this._summary = summary;
        }

        /// <summary>
        /// Adds documentation for a parameter.
        /// </summary>
        /// <param name="parametername">The name of the parameter.</param>
        /// <param name="parameterdoc">The documentation of the parameter (content of PARAM tag).</param>
        public void AddParameter(string parametername, string parameterdoc)
        {
            this._docOnParameters[parametername] = parameterdoc;
        }

        /// <summary>
        /// The name of the documented method. This is an instance of MethodDescriptor if the documentation
        /// shall be used for a particular implementation of the method (depending on the types of the parameters).
        /// </summary>
        public MemberDescriptor MethodName { get { return this._methodName; } set { this._methodName = value; } }

        /// <summary>
        /// Returns a collection of pairs of parameter names and documentation on the parameter.
        /// </summary>
        public ICollection<KeyValuePair<string, string>> DocOnParameters { get { return this._docOnParameters; }
            set
            {
                this._docOnParameters.Clear();
                foreach (KeyValuePair<string, string> parNameParDocPair in value)
                    this._docOnParameters[parNameParDocPair.Key] = parNameParDocPair.Value;
            }
        }

        /// <summary>
        /// Content of the summary tag.
        /// </summary>
        public string Summary { get { return this._summary; } set { this._summary = value; } }

        /// <summary>
        /// The content of the RETURNS tag.
        /// </summary>
        public string Returns { get { return this._returns; } set { this._returns = value; } }

        /// <summary>
        /// List of references (serializations of TypeDesciptor, MemberDescriptor, or MethodDescriptor)
        /// pointing at the documentation of another code element
        /// </summary>
        public string[] SeeAlso { get { return this._seealso; } set { this._seealso = value; } }

        /// <summary>
        /// List of references (serializations of TypeDesciptor, MemberDescriptor, or MethodDescriptor)
        /// pointing at the documentation of another code element
        /// </summary>
        public string[] See { get { return this._see; } set { this._see = value; } }


        public override string ToString()
        {
            System.IO.StringWriter sb = new System.IO.StringWriter();
            using (System.Xml.XmlTextWriter dest = new System.Xml.XmlTextWriter(sb))
            {
                dest.Formatting = System.Xml.Formatting.Indented;
                dest.WriteStartElement("member");
                dest.WriteAttributeString("name", this._methodName.ToString());
                if (this.Summary.Length > 0)
                {
                    dest.WriteStartElement("summary");
                    dest.WriteString(this.Summary);
                    dest.WriteEndElement();
                }
                foreach (KeyValuePair<string, string> param in this._docOnParameters)
                {
                    dest.WriteStartElement("param");
                    dest.WriteAttributeString("name", param.Key);
                    dest.WriteString(param.Value);
                    dest.WriteEndElement();
                }
                if (this.Returns.Length > 0)
                {
                    dest.WriteStartElement("returns");
                    dest.WriteString(this.Summary);
                    dest.WriteEndElement();
                }
                foreach (string see in this._see)
                {
                    dest.WriteStartElement("see");
                    dest.WriteAttributeString("cref", see);
                    dest.WriteEndElement();
                }
                foreach (string see in this._seealso)
                {
                    dest.WriteStartElement("see");
                    dest.WriteAttributeString("cref", see);
                    dest.WriteEndElement();
                }
                foreach (KeyValuePair<TypeDescriptor, string> exc in this._exceptions)
                {
                    dest.WriteStartElement("exception");
                    dest.WriteAttributeString("cref", exc.Key.ToString());
                    dest.WriteString(exc.Value);
                    dest.WriteEndElement();
                }
            }
            return sb.ToString();
        }
    }

    /// <summary>
    /// Includes the documentation entries for one assembly.
    /// </summary>
    public class AssemblyDocBase
    {
        Uri _filename=null;
        string _error=null;
        string _assemblyName = null;
        Dictionary<TypeDescriptor, TypeDoc> _typeDocs = new Dictionary<TypeDescriptor, TypeDoc>();
        Dictionary<MemberDescriptor, PropertyDoc> _propertyDocs = new Dictionary<MemberDescriptor, PropertyDoc>();
        Dictionary<MemberDescriptor, MethodDoc> _methodDocs = new Dictionary<MemberDescriptor, MethodDoc>();

        public AssemblyDocBase(System.Reflection.Assembly assembly)
        {
            this._filename = new Uri(assembly.CodeBase.Substring(0, assembly.CodeBase.Length-4)+".xml");
            this.Load(this._filename);
        }

        /// <summary>
        /// Normalization of string content. Remove line breaks and multible blanks.
        /// Remove * if preceeded by line break and blanks.S
        /// </summary>
        /// <param name="original"></param>
        /// <returns></returns>
        static string NormalizeStringContent(string original)
        {
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            bool foundLineFeed = false;
            bool foundBlank = false;
            foreach (char c in original)
            {
                if (c == '\n')
                {
                    foundBlank = true;
                    foundLineFeed = true;
                    if (!foundBlank)
                        sb.Append(' ');
                }
                else if (c <= ' ')
                {
                    if (!foundBlank)
                        sb.Append(' ');
                    foundBlank = true;
                }
                else if (c == '*')
                {
                    if (!foundLineFeed)
                    {
                        foundBlank = false;
                        foundLineFeed = false;
                        sb.Append('*');
                    }
                }
                else
                {
                    foundLineFeed = false;
                    foundBlank = false;
                    sb.Append(c);
                }
            }
            return sb.ToString();
        }

        void Load(Uri filename)
        {
            this._filename =filename;
            this._typeDocs.Clear();
            this._propertyDocs.Clear();
            this._methodDocs.Clear();
            try
            {
                using (System.Xml.XmlReader reader=new System.Xml.XmlTextReader(this._filename.AbsoluteUri))
                {
                    reader.ReadStartElement("doc");
                    reader.ReadStartElement("assembly");
                    this._assemblyName=reader.ReadElementString("name");
                    reader.ReadEndElement();
                    reader.ReadStartElement("members");
                    while (reader.IsStartElement("member"))
                    {
                        string name=reader.GetAttribute("name");
                        if (name.StartsWith("T:"))
                        {
                            TypeDoc node = new TypeDoc();
                            List<string> listofsee = new List<string>();
                            List<string> listofseealso = new List<string>();
                            node.Type = TypeDescriptor.Parse(name);
                            reader.Read();
                            while (reader.NodeType != System.Xml.XmlNodeType.Element
                                   && reader.NodeType != System.Xml.XmlNodeType.EndElement)
                            {
                                reader.Read();
                            }
                            while (reader.IsStartElement())
                            {
                                if (reader.IsStartElement("summary"))
                                {
                                    node.Summary = NormalizeStringContent( reader.ReadInnerXml() );
                                }
                                else if (reader.IsStartElement("see"))
                                {
                                    string see = reader.GetAttribute("cref");
                                    listofsee.Add(see);
                                    reader.Read();
                                }
                                else if (reader.IsStartElement("seealso"))
                                {
                                    string seealso = reader.GetAttribute("cref");
                                    listofseealso.Add(seealso);
                                    reader.Read();
                                }
                                else
                                {
                                    reader.ReadOuterXml();
                                }
                                while (reader.NodeType != System.Xml.XmlNodeType.Element
                                       && reader.NodeType != System.Xml.XmlNodeType.EndElement)
                                {
                                    reader.Read();
                                }
                            }
                            node.See = listofsee.ToArray();
                            node.SeeAlso = listofseealso.ToArray();
                            this._typeDocs.Add(node.Type, node);
                            reader.ReadEndElement();
                        }
                        else if (name.StartsWith("M:"))
                        {
                            MethodDoc node = new MethodDoc();
                            List<string> listofsee = new List<string>();
                            List<string> listofseealso = new List<string>();
                            if (name.Contains("("))
                                node.MethodName = MethodDescriptor.Parse(name);
                            else
                                node.MethodName = MemberDescriptor.Parse(name);
                            reader.Read();
                            while (reader.NodeType != System.Xml.XmlNodeType.Element
                                   && reader.NodeType != System.Xml.XmlNodeType.EndElement)
                            {
                                reader.Read();
                            }
                            while (reader.IsStartElement())
                            {
                                if (reader.IsStartElement("summary"))
                                {
                                    node.Summary = NormalizeStringContent(reader.ReadInnerXml());
                                }
                                else if (reader.IsStartElement("returns"))
                                {
                                    node.Returns = NormalizeStringContent(reader.ReadInnerXml());
                                }
                                else if (reader.IsStartElement("param"))
                                {
                                    string paramName=reader.GetAttribute("name");
                                    node.AddParameter(paramName, NormalizeStringContent( reader.ReadInnerXml() ));
                                }
                                else if (reader.IsStartElement("see"))
                                {
                                    string see = reader.GetAttribute("cref");
                                    listofsee.Add(see);
                                    reader.Read();
                                }
                                else if (reader.IsStartElement("seealso"))
                                {
                                    string seealso = reader.GetAttribute("cref");
                                    listofseealso.Add(seealso);
                                    reader.Read();
                                }
                                else
                                {
                                    reader.ReadOuterXml();
                                }
                                while (reader.NodeType != System.Xml.XmlNodeType.Element
                                       && reader.NodeType != System.Xml.XmlNodeType.EndElement)
                                {
                                    reader.Read();
                                }
                            }
                            node.See = listofsee.ToArray();
                            node.SeeAlso = listofseealso.ToArray();
                            this._methodDocs[node.MethodName] = node;
                            if (node.MethodName is MethodDescriptor
                                && !this._methodDocs.ContainsKey(((MethodDescriptor)node.MethodName).Generalized))
                                this._methodDocs.Add(((MethodDescriptor)node.MethodName).Generalized, node);
                            reader.ReadEndElement();
                        }
                        else if (name.StartsWith("P:"))
                        {
                            PropertyDoc node = new PropertyDoc();
                            List<string> listofsee = new List<string>();
                            List<string> listofseealso = new List<string>();
                            node.Property = MemberDescriptor.Parse(name);
                            reader.Read();
                            while (reader.NodeType != System.Xml.XmlNodeType.Element
                                   && reader.NodeType != System.Xml.XmlNodeType.EndElement)
                            {
                                reader.Read();
                            }
                            while (reader.IsStartElement())
                            {
                                if (reader.IsStartElement("summary"))
                                {
                                    node.Summary = NormalizeStringContent(reader.ReadInnerXml());
                                }
                                else if (reader.IsStartElement("see"))
                                {
                                    string see = reader.GetAttribute("cref");
                                    listofsee.Add(see);
                                    reader.Read();
                                }
                                else if (reader.IsStartElement("seealso"))
                                {
                                    string seealso = reader.GetAttribute("cref");
                                    listofseealso.Add(seealso);
                                    reader.Read();
                                }
                                else
                                {
                                    reader.ReadOuterXml();
                                }
                                while (reader.NodeType != System.Xml.XmlNodeType.Element
                                       && reader.NodeType != System.Xml.XmlNodeType.EndElement)
                                {
                                    reader.Read();
                                }
                            }
                            node.See = listofsee.ToArray();
                            node.SeeAlso = listofseealso.ToArray();
                            this._propertyDocs[node.Property] = node;
                            reader.ReadEndElement();
                        }
                        else
                        {
                            reader.ReadOuterXml();
                        }
                    }
                    reader.ReadEndElement();
                    reader.ReadEndElement();
                }
            }
            catch (Exception exc)
            {
                System.Diagnostics.Trace.WriteLine(exc.Message);
                this._error=exc.Message;
            }
        }

        /// <summary>
        /// This is an error message if something went wrong on loading.
        /// This is <c>null</c> if everything is OK.
        /// </summary>
        public string Error { get { return this._error; } }

        /// <summary>
        /// The source of the documentation.
        /// </summary>
        public Uri Filename { get { return this._filename; } }

        /// <summary>
        /// The name of the assembly as read from the documentation file. This may be <c>null</c> on read errors.
        /// </summary>
        public string AssemblyName { get { return this._assemblyName; } }

        /// <summary>
        /// Returns the documentation of the designated type if one has been loaded.
        /// </summary>
        /// <param name="t">The type whose documentation is requested</param>
        /// <returns></returns>
        public TypeDoc GetTypeDoc(TypeDescriptor t)
        {
                if (this._typeDocs.ContainsKey(t))
                    return this._typeDocs[t];
                else
                    return null;
        }

        /// <summary>
        /// Returns the documentation of the designated method if one has been loaded.
        /// </summary>
        /// <param name="m">Designates the method whose documentation is requested. If this is a MethodDescriptor,
        /// then this will also search for a documentation to MethodDescriptor.Generalized.</param>
        /// <returns></returns>
        /// <seealso cref="MethodDescriptor"/>
        public MethodDoc GetMethodDoc(MemberDescriptor m)
        {
            MethodDoc result = null;
            if (this._methodDocs.ContainsKey(m))
                result = this._methodDocs[m];
            else if (m is MethodDescriptor && this._methodDocs.ContainsKey(((MethodDescriptor)m).Generalized))
                result = this._methodDocs[((MethodDescriptor)m).Generalized];
            return result;
        }

        /// <summary>
        /// Returns the documentation of the designated property if one has been loaded.
        /// </summary>
        /// <param name="p">Designates the property whose documentation is requested.</param>
        /// <returns></returns>
        public PropertyDoc GetPropertyDoc(MemberDescriptor p)
        {
            PropertyDoc result = null;
            if (this._propertyDocs.ContainsKey(p))
                result = this._propertyDocs[p];
            return result;
        }
    }
}
