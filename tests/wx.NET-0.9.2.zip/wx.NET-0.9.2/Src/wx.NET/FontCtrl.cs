/**
 * wx.NET Project
 * 
 * \file 
 * 
 * A form that will be build automatically edit arbitrary .NET instances using reflection.
 * 
 * Written by Dr. Harald Meyer auf'm Hofe (C) 2008 
 * Licensed under the wxWidgets license, see LICENSE.txt for details.
 *
 * $Id: FontCtrl.cs,v 1.4 2010/05/08 19:52:40 harald_meyer Exp $
 */

using System.Drawing;
using System;

namespace wx
{
    /** <summary>This is a control to put in fonts that may be used within forms or tables.
     * This is a panel composed of a masked edit control allowing for the input of plattform indpendent font attributes and
     * a button, that will rise a font dialog if pressed. 
     * 
     * Use the styles wx.WindowStyles.FONTCTRL_EDIT_POINT_SIZE, wx.WindowStyles.FONTCTRL_EDIT_FONT_FAMILY,
     * wx.WindowStyles.FONTCTRL_EDIT_FONT_WEIGHT, wx.WindowStyles.FONTCTRL_EDIT_FONT_STYLE, and wx.WindowStyles.FONTCTRL_EDIT_FONT_COLOUR
     * to customize the input fields</summary>*/
    public class FontCtrl : Panel
    {
        #region State
        Button _dialogStarter;
        MaskedEdit.MaskedEdit _edit;
        Font _fontValue;
        Colour _colourValue;
        #endregion

        #region CTor
        public FontCtrl(Window parent, int id, Point position, Size size, WindowStyles style, Font initialFontValue)
            : this(parent, id, position, size, style, initialFontValue , wx.Colour.wxBLACK)
        {
        }

        public FontCtrl(Window parent, int id, Point position, Size size, WindowStyles style, Font initialFontValue, Colour initialColourValue)
            : base(parent, id, position, size, style | WindowStyles.TAB_TRAVERSAL)
        {
            BoxSizer sizer = new StaticBoxSizer(Orientation.wxHORIZONTAL, this);

            if ( (int)(style & WindowStyles.FONTCTRL_EDIT_ALL) > 0 )
            {
                #region Define the edit fields
                MaskedEdit.EditField[] editFields = new MaskedEdit.EditField[]
                {
                    MaskedEdit.EditIntField.New("pointsize").SetWidth(2).SetIn(3, 99).SetEmptyChar(' '),
                    MaskedEdit.StringEditField.New("family").SetWidth(14).SetChoices(typeof(wx.FontFamily)),
                    MaskedEdit.StringEditField.New("weight").SetWidth(8).SetChoices(typeof(wx.FontWeight)),
                    MaskedEdit.StringEditField.New("style").SetWidth(8).SetChoices(typeof(wx.FontStyle)),

                    MaskedEdit.EditIntField.New("red").SetWidth(3).SetIn(0, 255).SetEmptyChar('0').SetTextAttributes(new TextAttr(wx.Colour.wxRED)),
                    MaskedEdit.EditIntField.New("green").SetWidth(3).SetIn(0, 255).SetEmptyChar('0').SetTextAttributes(new TextAttr(new wx.Colour(0, 192, 0))),
                    MaskedEdit.EditIntField.New("blue").SetWidth(3).SetIn(0, 255).SetEmptyChar('0').SetTextAttributes(new TextAttr(wx.Colour.wxBLUE)),
                    MaskedEdit.EditIntField.New("alpha").SetWidth(3).SetIn(0, 255).SetEmptyChar('0'),
                };
                #endregion

                #region Define the edit mask referring to window styles.
                bool separatorRequired = false;
                System.Text.StringBuilder textmask = new System.Text.StringBuilder();
                if ((style & WindowStyles.FONTCTRL_EDIT_POINT_SIZE) == WindowStyles.FONTCTRL_EDIT_POINT_SIZE)
                {
                    if (separatorRequired)
                        textmask.Append(", ");
                    textmask.Append("{0}pt");
                    separatorRequired = true;
                }
                if ((style & WindowStyles.FONTCTRL_EDIT_FONT_FAMILY) == WindowStyles.FONTCTRL_EDIT_FONT_FAMILY)
                {
                    if (separatorRequired)
                        textmask.Append(", ");
                    textmask.Append(GetTranslation(typeof(wx.FontFamily)) + ": {1}");
                    separatorRequired = true;
                }
                if ((style & WindowStyles.FONTCTRL_EDIT_FONT_WEIGHT) == WindowStyles.FONTCTRL_EDIT_FONT_WEIGHT)
                {
                    if (separatorRequired)
                        textmask.Append(", ");
                    textmask.Append(GetTranslation(typeof(wx.FontWeight)) + ": {2}");
                    separatorRequired = true;
                }
                if ((style & WindowStyles.FONTCTRL_EDIT_FONT_STYLE) == WindowStyles.FONTCTRL_EDIT_FONT_STYLE)
                {
                    if (separatorRequired)
                        textmask.Append(", ");
                    textmask.Append(GetTranslation(typeof(wx.FontStyle)) + ": {3}");
                    separatorRequired = true;
                }
                if ((style & WindowStyles.FONTCTRL_EDIT_FONT_COLOUR) == WindowStyles.FONTCTRL_EDIT_FONT_COLOUR)
                {
                    if (separatorRequired)
                        textmask.Append(", ");
                    textmask.Append(GetTranslation(typeof(wx.Colour)) + " {4}x{5}x{6}:{7}");
                    separatorRequired = true;
                }
                #endregion

                this._edit = new wx.MaskedEdit.MaskedEdit(this, textmask.ToString(), editFields);
                this._edit.BackgroundColour = wx.Colour.wxWHITE;
                sizer.Add(this._edit, 1, SizerFlag.wxALIGN_CENTER);
            }
            else
                this._edit = null;

            this._dialogStarter = new Button(this, initialFontValue.FaceName, wxDefaultPosition, new Size(80, 32), WindowStyles.BORDER_RAISED);
            this._dialogStarter.ForegroundColour = initialColourValue;
            sizer.Add(this._dialogStarter, 1, SizerFlag.wxEXPAND | SizerFlag.wxALIGN_CENTER);
            this.Sizer = sizer;

            this._fontValue = new Font(initialFontValue);
            this._colourValue = new Colour(initialColourValue);

            if (this._edit != null)
            {
                this._edit[0].Object = this._fontValue.PointSize;
                this._edit[1].Object = this._fontValue.Family;
                this._edit[2].Object = this._fontValue.Weight;
                this._edit[3].Object = this._fontValue.Style;

                this._edit[4].Object = this._colourValue.Red;
                this._edit[5].Object = this._colourValue.Green;
                this._edit[6].Object = this._colourValue.Blue;
                this._edit[7].Object = this._colourValue.Alpha;

                this._edit[0].OnChanged += new wx.MaskedEdit.MaskedEditFieldValueChangedHandler(this.OnChangedPointsize);
                this._edit[1].OnChanged += new wx.MaskedEdit.MaskedEditFieldValueChangedHandler(this.OnChangedFontFamily);
                this._edit[2].OnChanged += new wx.MaskedEdit.MaskedEditFieldValueChangedHandler(this.OnChangedFontWeight);
                this._edit[3].OnChanged += new wx.MaskedEdit.MaskedEditFieldValueChangedHandler(this.OnChangedFontStyle);

                this._edit[4].OnChanged += new wx.MaskedEdit.MaskedEditFieldValueChangedHandler(this.OnChangedColourField);
                this._edit[5].OnChanged += new wx.MaskedEdit.MaskedEditFieldValueChangedHandler(this.OnChangedColourField);
                this._edit[6].OnChanged += new wx.MaskedEdit.MaskedEditFieldValueChangedHandler(this.OnChangedColourField);
                this._edit[7].OnChanged += new wx.MaskedEdit.MaskedEditFieldValueChangedHandler(this.OnChangedColourField);
            }
            this._dialogStarter.EVT_BUTTON(-1, new EventListener(this.OnPressedFontCtrl));
        }

        public FontCtrl(Window parent, Point position, Size size, WindowStyles style, Font initialValue)
            : this(parent, -1, position, size, style, initialValue, wx.Colour.wxBLACK)
        {
        }
        #endregion

        #region Events
        /** <summary>Argument of change event handlers.</summary>*/
        public class OnChangedEvent : EventArgs
        {
            #region State
            wx.Colour _newColour;
            wx.Font _newFont;
            #endregion

            #region CTor
            public OnChangedEvent(Font newFont, Colour newColour)
            {
                this._newFont = newFont;
                this._newColour = newColour;
            }
            #endregion

            #region Public Properties
            public Colour NewColour { get { return this._newColour; } }
            public Font NewFont { get { return this._newFont; } }
            #endregion
        }

        /** <summary>Handler of the "value changed" event.</summary>*/
        public delegate void OnChangedHandler(object sender, OnChangedEvent evt);

        /** <summary>This will be called immediately after a value has been changed.</summary>*/
        public event OnChangedHandler OnChanged;

        bool _changeEventLock = false;
        void RaiseChangedEvent()
        {
            if (!this._changeEventLock && this.OnChanged != null)
            {
                try
                {
                    this._changeEventLock = true;
                    this.OnChanged(this, new OnChangedEvent(this._fontValue, this._colourValue));
                }
                finally
                {
                    this._changeEventLock = false;
                }
            }
        }

        void OnChangedColourField(object sender, MaskedEdit.MaskedEditFieldValueChangedEvent evt)
        {
            if (evt.Field.Name.Equals("red"))
                this._colourValue.Red = (byte)(int)evt.Field.Object;
            else if (evt.Field.Name.Equals("green"))
                this._colourValue.Green = (byte)(int)evt.Field.Object;
            else if (evt.Field.Name.Equals("blue"))
                this._colourValue.Blue = (byte)(int)evt.Field.Object;
            else if (evt.Field.Name.Equals("alpha"))
                this._colourValue.Alpha = (byte)(int)evt.Field.Object;

            this.UpdateButtonlabel();
        }

        void UpdateButtonlabel()
        {
            this._dialogStarter.SetFont(this._fontValue);
            this._dialogStarter.ForegroundColour = this._colourValue;
            string fontname = this._fontValue.FaceName;
            if (fontname.Length > 0)
                this._dialogStarter.Label = fontname;
            else
                this._dialogStarter.Label = GetTranslation(typeof(wx.Font));
            this.RaiseChangedEvent();
        }

        void OnChangedPointsize(object sender, MaskedEdit.MaskedEditFieldValueChangedEvent evt)
        {
            this._fontValue.PointSize = (int)evt.Field.Object;
            this.UpdateButtonlabel();
        }

        void OnChangedFontFamily(object sender, MaskedEdit.MaskedEditFieldValueChangedEvent evt)
        {
            this._fontValue.Family = (FontFamily)evt.Field.Object;
            this.UpdateButtonlabel();
        }

        void OnChangedFontWeight(object sender, MaskedEdit.MaskedEditFieldValueChangedEvent evt)
        {
            this._fontValue.Weight = (FontWeight)evt.Field.Object;
            this.UpdateButtonlabel();
        }

        void OnChangedFontStyle(object sender, MaskedEdit.MaskedEditFieldValueChangedEvent evt)
        {
            this._fontValue.Style = (FontStyle)evt.Field.Object;
            this.UpdateButtonlabel();
        }

        void OnPressedFontCtrl(object sender, Event evt)
        {
            FontData fontData=new FontData(this._fontValue, this._colourValue);
            fontData.AllowSymbols = true;
            FontDialog dialog=new FontDialog(this, fontData);
            ShowModalResult result = dialog.ShowModal();
            if (result == ShowModalResult.OK || result == ShowModalResult.YES)
            {
                bool changeEventLockOrig = this._changeEventLock;
                try
                {
                    this._changeEventLock = true;
                    this._fontValue = dialog.FontData.ChosenFont;
                    this._colourValue = dialog.FontData.Colour;
                    if (this._edit == null)
                        this.UpdateButtonlabel();
                    else
                    {
                        this._edit[0].Object = this._fontValue.PointSize;
                        this._edit[1].Object = this._fontValue.Family;
                        this._edit[2].Object = this._fontValue.Weight;
                        this._edit[3].Object = this._fontValue.Style;
                        this._edit[4].Object = this._colourValue.Red;
                        this._edit[5].Object = this._colourValue.Green;
                        this._edit[6].Object = this._colourValue.Blue;
                        this._edit[7].Object = this._colourValue.Alpha;
                    }
                    if (!changeEventLockOrig && this.OnChanged != null)
                    {
                        this.OnChanged(this, new OnChangedEvent(this._fontValue, this._colourValue));
                    }
                }
                finally
                {
                    this._changeEventLock = changeEventLockOrig;
                }
            }
        }
        #endregion
    }
}
