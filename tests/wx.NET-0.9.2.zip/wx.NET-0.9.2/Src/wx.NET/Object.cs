//-----------------------------------------------------------------------------
// wx.NET - Object.cs
//
// The wxObject wrapper class.
//
// Written by Jason Perkins (jason@379.com)
// (C) 2003 by 379, Inc.
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: Object.cs,v 1.53 2010/07/12 18:23:50 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Collections;
using System.Runtime.InteropServices;

/** <summary>This namespace contains all basic  wxWidgets wrappers.</summary>*/
namespace wx
{
    /** <summary>This is the base class of all <c>wxWidgets</c> objects. This class manages pointers to C++ objects.
     * </summary>
     * <remarks>
     * When wrapping C++ to be used in modern OO programming languages like C# or JAVA, the main
     * difficulties arise from the different object model. On C++ instances are structs. In most
     * other languages (keeping ancient things like Simula 1967 aside) instances are references
     * to structs. C++ knows a lot of modifiers for data types without correlation in C#.
     * One of the most problematic thing is wrapping <c>const</c> <c>wxObject &amp;</c> results from selectors.
     * Requirements:
     * \li Since most  wx.NET wrappers provide the full of  wxWidgets objects, the  wx.NET
     *     generates many instances to generate independent objects. This is for instances the case
     *     with strings (class wx.wxString). In these cases  wx.NET will take ownership of the
     *     new object and destroy it on disposing the  wx.NET wrapper.
     * \li Another option that is used in some rare cases is to wrap the pointer of a const referenced
     *     object into a wrapper that does not provide any opportunity to modify the represented value.
     *     Problem: One needs wrappers without any modifiers. Prerequisite:  wxWidgets continues to
     *     have full ownership of the referenced memory but  wx.NET is preferred to reuse a wrapper
     *     instance. So, this class as a static container of all generated members of this kind.
     *     This container can be searched by method wx.Object.FindObject(). Problem: Garbage collection will never
     *     destroy the wrapper instances. So, this functon can be turned off using enumeration
     *     <c>StorageMode.VolatileObject</c>. In these case the C++ object usually receives a callback to
     *     be used on destruction to delete all references of the .NET wrapper to the deleted C++ object.
     *     Please keep also in mind, that using wx.Object.FindObject() usually means tha one wants to find
     *     a previous wrapper on an instance retrieved from C++. So, this instance is likely to be destroyed
     *     by the C++ implementation and not by the .NET wrapper. Consequently, you have to deactivate wx.Object.memOwn.
     * \li A rare specialization of the previous case: Since the  wxWidgets object does not provide the opportunity
     *     to call back on destruction, the object will be deleted on destroying the  wxWidgets container that probably
     *     hold the object. Consider wx.HtmlBookRecord and wx.HtmlBookRecords as examples.
     * \li The standard defensive way is to use both: New instances owned by  wx.NET plus static container
     *     of instances.
     * \li Refer to wx.Object.DllSync. Use this object to synchronze calls to the <c>wx-c</c> DLL at least
     *     if these calls create new C++ objects or delete them.
     * \li Usually, you will use FindObject() to identify preexisting wrappers for pointers to
     *     C++ instances of <c>wxObject</c>. This method may also serve as a factory for wrappers if you
     *     know the  wx.NET class of this new wrapper. If you don't know the class that shall be used
     *     for the creation of wrappers, you have the option to use the interface to the  wxWidgets
     *     RTTI. Refer to the remarks on wx.Object.ClassInfo.
     * 
     * Classes wrapping a class implementing a non-virtual desctructor have to implement
     * their own Dispose() method. Most of the other needs for managing C++ pointers are
     * satisfied by this class.
     * 
     * AddObject() and RemoveObject() implement a data base containing all wrappers to C++ pointers.
     * So, methods receiving a pointer to a already wrapped object can retrieve this preexisting wrapper
     * and reuse it by FindObject().
     * 
     * More elaborate classes do not wrap the original  wxWidgets object but a C++ wrapper informing
     * wx.NET on deallocating the  wxWidgets object. Usually, such wrappers receive a delegate of type
     * Virtual_Dispose() that calls VirtualDispose().  Please  note  whenever  passing  delegates  to  C++
     *  objects: Load class member variables with these delegates in order to prevent undesired disposal
     * of the delegates. This class offers member variable virtual_Dispose() to store the delegate
     * of type Virtual_Dispose().  Please  note, that some  wxWidgets classes like <c>wxString</c> or
     * <c>wxArrayString</c> have non-virtual destructors that, nevertheless, must run on destruction. So,
     * adding callbacks on destruction is not applicable to all  wxWidget classes.
     * File <c>local_events.h</c> in the <c>wx-c</c> directory of the sources contains some support for callbacks
     * on desctruction and some other frequent cases on wrapping.
     * 
     * Contributors should also not forget to initialize all callbacks to NULL on construction and to
     * call only callbacks which are not NULL. This is important to achieve reliant code - it is important
     * that instances with callbacks also run before these callbacks have been registered.
     *</remarks>
     */
    public class Object : IDisposable
    {
        #region Public Types
        /** <summary>This wrapps the  wxWidgets <c>wxClassInfo</c>.
         * This class implements a DB of registered class informations.
         * This DB may be used to identify pointers to <c>wxObject</c> by
         * FindClassInfoOf(). Prerequisite: The wrapper class (e.g. HtmlCell) implements a public and static
         * method <c>GetWxClassInfo()</c> or <c>HtmlCell_GetWxClassInfo()</c> returning a <c>System.IntPtr</c> to the
         * <c>wxClassInfo</c> of the C++ objects wrapped by that class.
         * </summary>
         */
        public class ClassInfo
        {
            #region C API
            [DllImport("wx-c")]
            static extern IntPtr wxClassInfo_GetName(IntPtr obj);
            [DllImport("wx-c")]
            static extern IntPtr wxClassInfo_GetBaseClassName1(IntPtr self);
            [DllImport("wx-c")]
            static extern IntPtr wxClassInfo_GetBaseClassName2(IntPtr self);
            [DllImport("wx-c")]
            static extern int wxClassInfo_GetSize(IntPtr self);
            [DllImport("wx-c")]
            static extern IntPtr wxGridCellEditor_GetClassInfoOnInstance(IntPtr self);
            [DllImport("wx-c")]
            static extern IntPtr wxGridCellRenderer_GetClassInfoOnInstance(IntPtr self);
            #endregion

            #region State
            IntPtr _cptr;
            Type _wrapperType;
            #endregion

            #region CTor
            ClassInfo(IntPtr cptr, Type wrapperType)
            {
                this._cptr = cptr;
                this._wrapperType = wrapperType;
            }

            /** <summary>This will return the wrapper for the  wxWidgets <c>wxClassInfo</c> <c>cptr</c>. or create one if necessary.</summary>*/
            public static ClassInfo FindOrCreate(IntPtr cptr, Type wrapperType)
            {
                if (s_cptrToNetWrapper.ContainsKey(cptr))
                    return (ClassInfo)s_cptrToNetWrapper[cptr];
                else
                {
                    ClassInfo result = new ClassInfo(cptr, wrapperType);
                    s_cptrToNetWrapper[cptr] = result;
                    s_nameToNetWrapper[result.Name] = result;
                    return result;
                }
            }
            #endregion

            #region Properties
            public string Name
            {
                get
                {
                    wxString wxName = wxString.SafeNew(wxClassInfo_GetName(this._cptr));
                    if (wxName == null)
                        return null;
                    else
                        return wxName.ToString();
                }
            }

            /** <summary>First base class or <c>null</c>.
             * </summary>
             */
            public string BaseClass1
            {
                get
                {
                    wxString wxName = wxString.SafeNew(wxClassInfo_GetBaseClassName1(this._cptr));
                    if (wxName == null)
                        return null;
                    else
                        return wxName.ToString();
                }
            }

            /** <summary>Second base class or <c>null</c>.
             * </summary>
             */
            public string BaseClass2
            {
                get
                {
                    wxString wxName = wxString.SafeNew(wxClassInfo_GetBaseClassName2(this._cptr));
                    if (wxName == null)
                        return null;
                    else
                        return wxName.ToString();
                }
            }

            /** <summary>The size of the native object.</summary>*/
            public int Size
            {
                get
                {
                    return wxClassInfo_GetSize(this._cptr);
                }
            }

            /** <summary>This is the  wx.NET wrapper class.</summary>*/
            public Type wxNetType
            {
                get
                {
                    return this._wrapperType;
                }
            }
            #endregion

            #region Database of class infos
            static bool s_searchedTheAssembly = false;

            /** <summary>This will find the class info referring to a native instance of <c>wxObject</c>.
             * Please note, that not all  wxWidgets classes inerit from <c>wxObject</c>.
             * </summary>
             */
            public static ClassInfo FindWxObject(IntPtr wxObject)
            {
                IntPtr classInfo = wxObject_GetClassInfo(wxObject);
                return Find(wxObject, classInfo);
            }

            /** <summary>This will find the class info referring to a native instance of <c>wxGridCellEditor</c>.
             * </summary>
             */
            public static ClassInfo FindWxGridCellEditor(IntPtr wxGridCellWorker)
            {
                return Find(wxGridCellWorker, wxGridCellEditor_GetClassInfoOnInstance(wxGridCellWorker));
            }

            /** <summary>This will find the class info referring to a native instance of <c>wxGridCellRenderer</c>.
             * </summary>
             */
            public static ClassInfo FindWxGridCellRenderer(IntPtr wxGridCellWorker)
            {
                return Find(wxGridCellWorker, wxGridCellRenderer_GetClassInfoOnInstance(wxGridCellWorker));
            }

            /** <summary>Internal helper that finds a class info for <c>nativeInstance</c> provided that <c>classInfo</c> is a pointer to the <c>wxWidgets</c> class info.
             * </summary>
             */
            static ClassInfo Find(IntPtr nativeInstance, IntPtr classInfo)
            {
                if (classInfo == IntPtr.Zero)
                    return null;
                if (nativeInstance == IntPtr.Zero)
                    return null;

                if (!s_searchedTheAssembly)
                {
                    System.Reflection.Assembly wxNetAssembly = System.Reflection.Assembly.GetExecutingAssembly();
                    foreach (Type t in wxNetAssembly.GetTypes())
                    {
                        foreach (System.Reflection.MethodInfo mi in t.GetMethods())
                        {
                            if (mi.IsStatic
                                && (mi.Name == "GetWxClassInfo"
                                    || mi.Name == t.Name+"_"+"GetWxClassInfo"))
                            {
                                IntPtr cptr = (IntPtr)mi.Invoke(null, null);
                                ClassInfo.FindOrCreate(cptr, t);
                                break;
                            }
                        }
                    }
                    s_searchedTheAssembly = true;
                }

                if (s_cptrToNetWrapper.ContainsKey(classInfo))
                    return (ClassInfo)s_cptrToNetWrapper[classInfo];
                ClassInfo prelim = new ClassInfo(classInfo, null);
                string className=prelim.Name;
                if (s_nameToNetWrapper.Contains(className))
                    return (ClassInfo)s_nameToNetWrapper[className];
                return null;
            }
            #endregion

        }

        static Hashtable s_cptrToNetWrapper = new Hashtable();
        static Hashtable s_nameToNetWrapper = new Hashtable();
        #endregion

        internal delegate void Virtual_Dispose();
		internal Virtual_Dispose virtual_Dispose;
	
		[DllImport("wx-c")] static extern IntPtr wxObject_GetTypeName(IntPtr obj);
        [DllImport("wx-c")] static extern IntPtr wxObject_GetClassInfo(IntPtr obj);
        [DllImport("wx-c")] static extern void wxObject_dtor(IntPtr self);

		//---------------------------------------------------------------------

		//! Reference to the associated C++ object
		internal IntPtr wxObject = IntPtr.Zero;
		internal bool disposed = false;

		/** <summary>Hashtable to associate C++ objects with C# references</summary>*/
		private static Hashtable objects = new Hashtable();

        /** <summary>Use this to get the number of valid/undisposed instances of  wxWidgets objects.</summary>*/
        public static int SavedInstancesCount { get { return objects.Count; } }

        internal static int validInstancesCount = 0;
        /** <summary>Use this to read the number of valid instances.
         * This will return the number of generated and undisposed instances of this class
         * regardless whether these objects have been saved in the static container for
         * instances or not.</summary>*/
        public static int InstancesCount { get { return validInstancesCount; } }

        /** <summary>Use this object to synchronize calls to the <c>wx-c</c> DLL.
         * Apparently, allocation and deallocation of C++ objects using <c>new</c> and <c>delete</c>
         * must be synchronized at least on  Windows. It is generally a good idea, to synchronize
         * most of calls to the DLL. Please keep in mind, that the garbage collector runs in
         * parallel to the program. So, you typically have at least two threads running that
         * use the <c>wx-c</c> DLL.
         *</summary>*/
        public static object DllSync { get { return typeof(Object); } }

		/** <summary>memOwn is true when we create a new instance with the wrapper ctor
		 or if a call to a wrapper function returns new c++ instance.
		 Otherwise the created c++ object won't be deleted by the Dispose member.
         
         This member will now usually be set explicitely or depending on the StorageMode.</summary>*/
		internal bool memOwn = false;
		
		//---------------------------------------------------------------------

        /** <summary>Use constants of this kind to tell the CTor whether to hold the newly created object into the static container of instances or not.</summary>*/
        internal enum StorageMode
        {
            RegisteredObject,
            VolatileObject
        }
        internal Object(IntPtr wxObject)
            : this(wxObject, StorageMode.RegisteredObject)
        {
        }

        /** <summary>Default construction for objects of defined storage mode but with default memory ownership.
         * wx.Object.StorageMode.VolatileObject will be allocated with memory ownership.
         * Registered Objects will usually be allocated without memory ownership.</summary>*/
        internal Object(IntPtr wxObject, StorageMode mode)
            : this(wxObject, mode, false)
        {
            if (mode == StorageMode.VolatileObject)
                this.memOwn = true;
        }

		internal Object(IntPtr wxObject, StorageMode mode, bool memOwn)
		{
			lock(typeof(Object)) {
				this.wxObject = wxObject;
                ++validInstancesCount;
				if (wxObject == IntPtr.Zero) {
					throw new NullReferenceException("Unable to create instance of " + this.ToString());
				}

                if (mode == StorageMode.RegisteredObject)
                    AddObject(this);
                this.memOwn = memOwn;
			}
		}

		//---------------------------------------------------------------------

		internal static IntPtr SafePtr(Object obj)
		{
			return (obj != null) ? obj.wxObject : IntPtr.Zero;
		}

        //---------------------------------------------------------------------
        #region this is for Locale gettext support...

        [DllImport("wx-c")] static extern IntPtr wxGetTranslation_func(IntPtr str);

        /** <summary>This will return a translation of the type name.</summary>
         * <remarks>Translations of types may be useful if the type represent a notion in the real world that has a name.
         * For instance, wx.Font represents fonts. "Font" is a human readable name. If you want to print information on an
         * object <c>o</c> - what kind of object is this - you might use wx.Object.GetTranslation(o.GetType()).
         * 
         * Types may either provide a human readable name as defined by a wx.Globalization.TypeNameTranslationsAttribute attribute.
         * Or they are translated by a \e gettext catalogue. This method will first search for a translation of the full qualified
         * name. Then, this will search for a translation of the short type name.
         * 
         * This will return a translation into the current wx.Locale.Language.</remarks>
         */
        public static string GetTranslation(Type aType)
        {
            string query = aType.Namespace + "." + aType.Name;
            string result = GetTranslation(query);
            if (result == query)
            {
                object[] attrs = aType.GetCustomAttributes(typeof(wx.Globalization.TypeNameTranslationsAttribute), false);
                if (attrs != null && attrs.Length > 0)
                {
                    using (Locale l = new Locale())
                    {
                        string attrTranslation = ((wx.Globalization.TypeNameTranslationsAttribute)attrs[0]).Name.GetTranslation(l.Language);
                        if (attrTranslation != null)
                            return attrTranslation;
                    }
                }
                return aType.Name;
            }
            else
                return result;
        }

        /** <summary>This will translate the provided enumeration value.</summary>
         * <remarks>
         * You have two options to translate enumeration values.
         * The enumeration might provide attributes of type wx.Globalization.EnumValueTranslations. If present, these
         * will be used for translation first.
         * However, if this fails, this will query the known \c gettext catalogs for a string \c "namespace.enumeration_type.enumeration_value".
         * If this query fails, this will simply return \c "enumeration_value". Use tool \c getenums.exe to load
         * enumeration values of an assembly into a gettext POT file.
         * 
         * All translations will be done into the current \c wx.Locale.Language.
         * </remarks>
         */
        public static string GetTranslation(Enum enumerationValue)
        {
            string query = enumerationValue.GetType().Namespace + "." + enumerationValue.GetType().Name + "." + enumerationValue.ToString();
            string result = GetTranslation(query);
            if (result == query)
            {
                object[] attrs = enumerationValue.GetType().GetCustomAttributes(typeof(wx.Globalization.EnumValueTranslationsAttribute), false);
                if (attrs != null)
                {
                    int enumValueAsInt=Convert.ToInt32(enumerationValue);
                    foreach (wx.Globalization.EnumValueTranslationsAttribute attr in attrs)
                    {
                        if (attr.EnumIntValue == enumValueAsInt)
                        {
                            using (Locale l = new Locale())
                            {
                                string translation = attr.Name.GetTranslation(l.Language);
                                if (translation != null)
                                    return translation;
                            }
                        }
                    }
                }
                return enumerationValue.ToString();
            }
            else
                return result;
        }

        /** <summary>This will translate <c>str</c> into the currently selected locale.
         * Refer to wx.Locale.</summary>
         */
        public static string GetTranslation(string str)
        {
            wxString wxStr = wxString.SafeNew(str);
            return GetTranslation(wxStr);
        }

        /** <summary>This will translate <c>str</c> into the currently selected locale.
         * Refer to wx.Locale.</summary>
         */
        public static wxString GetTranslation(wxString str)
		{
            return new wxString(wxGetTranslation_func(str.wxObject), true);
		}

        /** <summary>This will translate <c>str</c> into the currently selected locale.
         * Refer to wx.Locale.</summary>
         */
        public static string _(string str)
		{
            return GetTranslation(str);
		}

        /** <summary>This will return a translation of the type name.</summary>
         * <remarks>Translations of types may be useful if the type represent a notion in the real world that has a name.
         * For instance, wx.Font represents fonts. "Font" is a human readable name. If you want to print information on an
         * object <c>o</c> - what kind of object is this - you might use wx.Object.GetTranslation(o.GetType()).
         * 
         * Types may either provide a human readable name as defined by a wx.Globalization.TypeNameTranslationsAttribute attribute.
         * Or they are translated by a gettext catalogue. This method will first search for a translation of the full qualified
         * name. Then, this will search for a translation of the short type name.
         * 
         * This will return a translation into the current wx.Locale.Language.
         * </remarks>
         */
        public static string _(Type t)
        {
            return GetTranslation(t);
        }

        /** <summary>Returns the translation of the enumeration value.
         * Suppose, we have an enumeration <c>Assembly.Enumeration</c> containing a value <c>Assembly.Enumeration.Value</c>.
         * Then, this will look for a translation of "Assembly.Enumeration.Value" first and then, if this fails, for a
         * translation of "Value".
         *
         * Translations may also be provided by wx.Globalization.EnumValueTranslations.</summary>*/
        public static string _(Enum enumerationValue)
        {
            return GetTranslation(enumerationValue);
        }

		/** <summary>This will translate <c>format</c> into the currently selected locale and then paste sting versions of the arguments into the result.
         * Refer to wx.Locale.</summary>*/
		public static string _(string format, params object[] args)
		{
            return string.Format(GetTranslation(format), args);
		}

        /** <summary>This is a dummy method that programmers may use to mark a text as to be translated by GETTEXT but not here.</summary><remarks>
         * Example:
         * \code
         string theUntranslatedText=wx.Object.__("The untranslated text.");
         System.Diagnostics.Trace.WriteLine(theUntranslatedText);     // this can be understood by developers.
         System.Console.WriteLine(wx.Object._(theUntranslatedString); // this can be understood by the user of the program.
         \endcode
         * </remarks>*/
        public static string __(string str)
        {
            return str;
        }
        #endregion

        //---------------------------------------------------------------------

        #region Interface to wxWidgets type system
        /** <summary>This will return the name of the C++ class of the wrapped pointer.
         * Information will be derived from the  wxWidgets RTTI.</summary>*/
		internal static string GetTypeName(IntPtr wxObject)
		{
			return new wxString(wxObject_GetTypeName(wxObject), true);
		}

        /** <summary>This will return the name of the C++ class of the wrapped pointer.
         * Information will be derived from the  wxWidgets RTTI.</summary>*/
        public string GetTypeName()
		{
			return new wxString(wxObject_GetTypeName(wxObject), true);
		}

        /** <summary>This will return a wrapper of the  wxWidgets RTTI representation.</summary>*/
        public ClassInfo GetClassInfo()
        {
            return ClassInfo.FindOrCreate(wxObject_GetClassInfo(this.wxObject), this.GetType());
        }
        #endregion

        //---------------------------------------------------------------------

        #region Object creation and object database
        /** <summary>Registers an Object, so that it can be referenced using a C++ object
		 pointer.</summary>*/
		internal static void AddObject(Object obj)
		{
			if (obj.wxObject != IntPtr.Zero) {
				if (objects.ContainsKey(obj.wxObject)) {
					objects[obj.wxObject] = obj;
				}
				else {
					objects.Add(obj.wxObject, obj);
				}
			}
		}
		
		//---------------------------------------------------------------------

        /** <summary>Finds an existing wrapper or creates one if necessary from information of ClassInfo.
         * This will throw an exception of type information is required but ClassInfo fails to
         * provide.
         * 
         * The wrappers that are created by this method do not own the C++ objects.</summary>*/
        internal static Object FindOrCreateObjectUsingClassInfo(IntPtr ptr)
        {
            return FindOrCreateObjectUsingClassInfo(ptr, false);
        }

        /// <summary>Finds an existing wrapper or creates one if necessary from information of ClassInfo.
        /// This will throw an exception of type information is required but ClassInfo fails to
        /// provide.</summary>
        /// <param name="memOwn">defines whether this method creates wrappers owning the C++ object or not.</param>
        internal static Object FindOrCreateObjectUsingClassInfo(IntPtr ptr, bool memOwn)
        {
            if (ptr == IntPtr.Zero)
                return null;
            Object result = FindObject(ptr);
            if (result != null)
                return result;
            // we have to create an instance.
            ClassInfo ci = ClassInfo.FindWxObject(ptr);
            if (ci == null || ci.wxNetType==null)
                throw new ArgumentException("wx.Object.FindOrCreateObjectUsingClassInfo cannot infer type information.");

            result = (Object)Activator.CreateInstance(ci.wxNetType, new object[]{ptr});
            result.memOwn=memOwn;
            return result;
        }

        /** <summary>Locates the registered object that references the given C++ object pointer.
          
        If the pointer is not found, a reference to the object is created 
        using type.
        
        Wrappers created by this method will not own the memory allocated by <c>ptr</c>.</summary>*/
        internal static Object FindObject(IntPtr ptr, Type type)
        {
          return Object.FindObject(ptr, type, false);
        }

        /** <summary>Locates the registered object that references the given C++ object pointer.
         *
         * The result is assignable to <c>type</c>.
         * 
         * If the pointer is not found, a reference to the object is created 
         * using type.
         *
         * Argument <c>memOwn</c> defines, whether a fresh created wrapper owns
         * the memory allcoated by <c>ptr</c>.
         *
         * </summary>*/
        internal static Object FindObject(IntPtr ptr, Type type, bool memOwn)
        {
            return FindObject(ptr, type, type, memOwn);
        }

        /** <summary>Locates the registered object that references the given C++ object pointer.
         *
         * If the pointer is not found, a reference to the object is created 
         * using type.
         *
         * If this creates a new wrapper, this wrapper will NOT own the native instance.
         * </summary>
         * <param name="ptr">C++ pointer that shall be wrapped.</param>
         * <param name="returnType">The resulting wrapper will be assignable to this type.</param>
         * <param name="defaultType">Newly created wrappers will be of this type. Instances of this type shall be assignable to the return type.</param>
         */
        internal static Object FindObject(IntPtr ptr, Type defaultType, Type returnType)
        {
            return FindObject(ptr, defaultType, returnType, false);
        }

        /** <summary>Locates the registered object that references the given C++ object pointer.
         *
         * If the pointer is not found, a reference to the object is created 
         * using type.
         *
         * Argument <c>memOwn</c> defines, whether a fresh created wrapper owns
         * the memory allcoated by <c>ptr</c>.
         * </summary>
         * <param name="ptr">C++ pointer that shall be wrapped.</param>
         * <param name="memOwn">Indicates with true that newly created instances shall own the native memory.</param>
         * <param name="returnType">The resulting wrapper will be assignable to this type.</param>
         * <param name="defaultType">Newly created wrappers will be of this type. Instances of this type shall be assignable to the return type.</param>
         */
        internal static Object FindObject(IntPtr ptr, Type defaultType, Type returnType, bool memOwn)
        {
            if (ptr == IntPtr.Zero) {
                return null;
            }

            Object o = FindObject(ptr);

            // If the object wasn't found, create it
            if (o != null && returnType != null
                && !(returnType.IsAssignableFrom(o.GetType())))
            {
                // Apparently inkonsistent object base. A previously used instance
                // has obviousl not been removed.
                // throw new InvalidCastException("wx.NET wrapper of unexpected type.");
                RemoveObject(ptr);
                o = null;
            }
            if (defaultType != null && o == null)
            {
                  o = (Object)Activator.CreateInstance(defaultType, new object[]{ptr});
                  o.memOwn=memOwn;
            }

            return o;
        }

		/** <summary>Locates the registered object that references the given C++ object
		  * pointer.</summary>*/
		internal static Object FindObject(IntPtr ptr)
		{
			if (ptr != IntPtr.Zero && objects.ContainsKey(ptr)) {
				return (Object)objects[ptr];
			}

			return null;
		}
		
		//---------------------------------------------------------------------

		/** <summary>Removes a registered object.
		 returns true if the object is found in the
		 Hashtable and is removed (for Dispose)</summary>*/
		internal static bool RemoveObject(IntPtr ptr)
		{
			bool retval = false;

            if (ptr != IntPtr.Zero)
			{
				if(objects.Contains(ptr)) {
					objects.Remove(ptr);
					retval = true;
				}
			}
			
			return retval;
		}
		
		//---------------------------------------------------------------------
		
		/** <summary>called when an C++ (wx)Object dtor gets invoked
         * This method may be passed to native objects that can use a 
         * Virtual_Dispose method that will be called on deleting the native
         * object.
         *</summary>*/
        internal protected void VirtualDispose()
        {
            this.VirtualDispose(true);
        }
		void VirtualDispose(bool removeFromObjectsBase)
		{
            if (removeFromObjectsBase)
			    RemoveObject(wxObject);
			wxObject = IntPtr.Zero;
            if (!disposed)
                --validInstancesCount;
            disposed = true;
			virtual_Dispose = null;
            this.DeregisterWrapper();
		}

        /** <summary>Dispose all safed instances of wrappers.
         * This will be done for instance on closing the application.</summary>*/
        internal static void VirtualDisposeAll()
        {
            foreach (Object wxWrapper in objects.Values)
                wxWrapper.VirtualDispose(false);
        }

		public virtual void Dispose()
		{
            Dispose(true);
			GC.SuppressFinalize(this);
		}

        /** <summary>This will be called by Dispose() to delete the C++ object.
         * Overload this if you have to use another DTor.</summary>*/
        protected virtual void CallDTor()
        {
            wxObject_dtor(this.wxObject);
        }

        /** <summary>Use this to implement services that decouple the .NET wrapper from the native  wxWidgets objects.
         * Example: Remove callback function pointers.
         * Please note that this may be called more than once.</summary>*/
        protected virtual void DeregisterWrapper()
        {
        }

		protected virtual void Dispose(bool disposing)
		{
            bool still_there = RemoveObject(wxObject);
            if (disposed)
                this.DeregisterWrapper();
            else
			{
                lock (DllSync)
                {
                    if (wxObject != IntPtr.Zero && memOwn && still_there)
                    {
                            this.CallDTor();
                    }
                    else
                        this.DeregisterWrapper();
				}
				
				virtual_Dispose = null;
				wxObject = IntPtr.Zero;
				memOwn = false;
                --validInstancesCount;
            }

			disposed = true;
		}
		
		~Object()
		{
			Dispose();
		}

        /// <summary>
        /// True if this does not refer to a valid C++ object.
        /// This situation typically occurs when a wrapped C++ object gets deallocated but
        /// the wrapper has net yet been finalized.
        /// </summary>
        public bool IsNULL
        {
            get { return this.wxObject == IntPtr.Zero || this.disposed; }
        }
        #endregion
    }
}
