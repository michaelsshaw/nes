//-----------------------------------------------------------------------------
// wx.NET - Log.cs
//
// The Log wrapper classes.
//
// Written by Alexander Olk (xenomorph2@onlinehome.de)
// (C) 2003 Alexander Olk
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: Log.cs,v 1.13 2010/05/08 19:54:35 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Drawing;
using System.Diagnostics;
using System.Runtime.InteropServices;

namespace wx
{
    /** <summary>Wrapper of the  wxWidgets log class.
     * Refer to LogTraceListener for System.Diagnostics.Trace support.</summary>*/
    public class Log: Object
	{
		/// <summary>
		/// The redundant managed flag that implements disabling of the protocol.
		/// </summary>
		internal static bool _enabled=true;
	
		public enum eLogLevel : int
		{
			xLOGMESSAGE,
			xFATALERROR,
			xERROR,
			xWARNING,
			xINFO,
			xVERBOSE,
			xSTATUS,
			xSYSERROR
		}
		
		[DllImport("wx-c")] static extern IntPtr wxLog_ctor();
		[DllImport("wx-c")] static extern bool wxLog_IsEnabled();
        [DllImport("wx-c")] static extern void wxLog_EnableLogging(bool yesOrNo);
		[DllImport("wx-c")] static extern void wxLog_FlushActive();
		[DllImport("wx-c")] static extern IntPtr wxLog_SetActiveTargetTextCtrl(IntPtr pLogger);
		[DllImport("wx-c")] static internal extern void wxLog_Log_Function(int what, IntPtr szFormat);
		[DllImport("wx-c")] static extern void wxLog_AddTraceMask(IntPtr tmask);
        [DllImport("wx-c")] static extern void wxLog_RemoveTraceMask(IntPtr tmask);
        [DllImport("wx-c")] static extern void wxLog_LogTraceStringMask(IntPtr mask, IntPtr msg);
        [DllImport("wx-c")] static extern IntPtr wxLog_GetTraceMasks();
        [DllImport("wx-c")] static extern void wxLog_ClearTraceMasks();
        [DllImport("wx-c")][return:MarshalAs(UnmanagedType.U1)] static extern bool wxLog_IsAllowedTraceMask(IntPtr mask);
        [DllImport("wx-c")] static extern void wxLog_Suspend();
        [DllImport("wx-c")] static extern void wxLog_Resume();
        [DllImport("wx-c")] static extern void wxLog_SetTimestamp(IntPtr ts);
        [DllImport("wx-c")] static extern IntPtr wxLog_GetTimestamp();
		
		public Log(IntPtr wxObject)
		    : base(wxObject) {}

		public Log()
		    : base(wxLog_ctor()) {}

        /// <summary>Read whether this is enabled or not and enable or disable assigning <c>true</c> or
        /// <c>false</c> respectively.</summary>
        /// <remarks>By the way - this will manage two flags for enable /diable: On in the native wxWidgets 
        /// implementations and one in the managed code. Goal: If logging is disabled, wx.NET will not
        /// even call the native DLL functions.</remarks>
		public static bool IsEnabled
		{
			get { return _enabled && wxLog_IsEnabled(); }
            set
            {
                _enabled=value;
                wxLog_EnableLogging(value);
            }
		}

        /** <summary>Gets or sets the timestamp format prepended by the default log targets to all messages.
         * The string may contain any normal characters as well as % prefixed
         * format specificators, see strftime() manual for details.
         * Passing a <c>null</c> value (not empty string) to this function disables
         * message timestamping.</summary>*/
        public static string Timestamp
        {
            get { return new wxString(wxLog_GetTimestamp()); }
            set
            {
                wxString wxValue = wxString.SafeNew(value);
                wxLog_SetTimestamp(Object.SafePtr(wxValue));
            }
        }

        public static void Suspend()
        { wxLog_Suspend(); }
        public static void Resume()
        { wxLog_Resume(); }

		public static void FlushActive()
		{
			if (_enabled)
			wxLog_FlushActive();
		}

		/** <summary>at the moment only TextCtrl</summary>*/
		public static void SetActiveTarget(TextCtrl pLogger)
		{
			if (_enabled)
			wxLog_SetActiveTargetTextCtrl(Object.SafePtr(pLogger));
		}

        /** <summary>Add the mask to the list of allowed masks for LogTrace().</summary>*/
		public static void AddTraceMask(string tmask)
		{
			if (_enabled)
            AddTraceMask(new wxString(tmask));
        }

        public static void AddTraceMask(wxString tmask)
        {
			if (_enabled)
			wxLog_AddTraceMask(tmask.wxObject);
		}
		
		public static void ClearTraceMask()
		{
			wxLog_ClearTraceMasks();
		}

        /** <summary>Remove the mask from the list of allowed masks for LogTrace().
          *See also: AddTraceMask().</summary>*/
        public static void RemoveTraceMask(string tmask)
        {
            Log.RemoveTraceMask(wxString.SafeNew(tmask));
        }
        public static void RemoveTraceMask(wxString tmask)
        {
			if (_enabled)
            wxLog_RemoveTraceMask(Object.SafePtr(tmask));
        }
        public static string[] TraceMasks
        {
            get
            {
                ArrayString masks = new ArrayString(wxLog_GetTraceMasks());
                return masks.ToArray();
            }
        }
        /** <summary>True if mask <c>tmask</c> is in TraceMasks().
         * This means that output with this mask will be logged.</summary>*/
        public static bool IsAllowedTraceMask(string tmask)
        {
            return IsAllowedTraceMask(wxString.SafeNew(tmask));
        }
        public static bool IsAllowedTraceMask(wxString tmask)
        {
            return wxLog_IsAllowedTraceMask(Object.SafePtr(tmask));
        }
        /** <summary>Trace functions only do something in debug build and expand to nothing in the release one.
         * The reason for making it a separate function from it is that usually there are a lot of trace
         * messages, so it might make sense to separate them from other debug messages.
         * 
         * For the second function (taking a string mask), the message is logged only if the mask has been previously enabled by the call to AddTraceMask or by setting WXTRACE environment variable. The predefined string trace masks used by wxWidgets are:
         * \li <c>wxTRACE_MemAlloc</c>: trace memory allocation (new/delete) 
         * \li <c>wxTRACE_Messages</c>: trace window messages/X callbacks 
         * \li <c>wxTRACE_ResAlloc</c>: trace GDI resource allocation 
         * \li <c>wxTRACE_RefCount</c>: trace various ref counting operations 
         * \li <c>wxTRACE_OleCalls</c>: trace OLE method calls (Win32 only)</summary>*/
        public static void LogTrace(string mask, string format, params object[] param)
        {
			if (_enabled)
            LogTrace(wxString.SafeNew(mask), wxString.SafeNew(string.Format(format, param)));
        }
        public static void LogTrace(wxString mask, wxString msg)
        {
			if (_enabled)
            wxLog_LogTraceStringMask(Object.SafePtr(mask), Object.SafePtr(msg));
        }

		public static void LogMessage(string message, params object[] param)
		{
            LogMessage(new wxString(string.Format(message, param)));
		}
        public static void LogMessage(string message)
        {
			if (_enabled)
            LogMessage(new wxString(message));
        }
        public static void LogMessage(wxString message)
        {
			if (_enabled)
            wxLog_Log_Function((int)eLogLevel.xLOGMESSAGE, message.wxObject);
        }

		public static void LogFatalError(string message, params object[] param)
		{
			if (_enabled)
            LogFatalError(new wxString(string.Format(message, param)));
		}
        public static void LogFatalError(string message)
        {
			if (_enabled)
            LogFatalError(new wxString(message));
        }
        public static void LogFatalError(wxString message)
        {
			if (_enabled)
            wxLog_Log_Function((int)eLogLevel.xFATALERROR, message.wxObject);
        }


		public static void LogError(string message, params object[] param)
		{
            LogError(new wxString(string.Format(message, param)));
		}
        public static void LogError(string message)
        {
            LogError(new wxString(message));
        }
        public static void LogError(wxString message)
        {
			if (_enabled)
            wxLog_Log_Function((int)eLogLevel.xERROR, message.wxObject);
        }

		public static void LogWarning(string message, params object[] param)
		{
            LogWarning(new wxString(string.Format(message, param)));
		}
        public static void LogWarning(string message)
        {
            LogWarning(new wxString(message));
        }
        public static void LogWarning(wxString message)
        {
			if (_enabled)
            wxLog_Log_Function((int)eLogLevel.xWARNING, message.wxObject);
        }

		public static void LogInfo(string message, params object[] param)
		{
			if (_enabled)
            LogInfo(new wxString(string.Format(message, param)));
		}
        public static void LogInfo(string message)
        {
            LogInfo(new wxString(message));
        }
        public static void LogInfo(wxString message)
        {
			if (_enabled)
            wxLog_Log_Function((int)eLogLevel.xINFO, message.wxObject);
        }

		public static void LogVerbose(string message, params object[] param)
		{
			if (_enabled)
            LogVerbose(new wxString(string.Format(message, param)));
		}
        public static void LogVerbose(string message)
        {
            LogVerbose(new wxString(message));
        }
        public static void LogVerbose(wxString message)
        {
			if (_enabled)
            wxLog_Log_Function((int)eLogLevel.xVERBOSE, message.wxObject);
        }


		public static void LogStatus(string message, params object[] param)
		{
			if (_enabled)
            LogStatus(new wxString(string.Format(message, param)));
		}
        public static void LogStatus(string message)
        {
            LogStatus(new wxString(message));
        }
        public static void LogStatus(wxString message)
        {
			if (_enabled)
            wxLog_Log_Function((int)eLogLevel.xSTATUS, message.wxObject);
        }


		public static void LogSysError(string message, params object[] param)
        {
			if (_enabled)
            LogSysError(new wxString(string.Format(message, param)));
        }
        public static void LogSysError(string message)
        {
			if (_enabled)
            LogSysError(new wxString(message));
        }
        public static void LogSysError(wxString message)
        {
			if (_enabled)
			wxLog_Log_Function((int)eLogLevel.xSYSERROR, message.wxObject);
		}
	}

    /** <summary>This class integrates  wxWidget's Log into .NET's trace capability.
     * Add an instance of this listener to the Trace and all output to the Trace log
     * will also appear in listeners to  wxWidget's Log.
     *</summary>*/
    public class LogTraceListener : TraceListener
    {
        Log.eLogLevel _eLevel;

        public LogTraceListener(Log.eLogLevel level)
        {
            this._eLevel = level;
        }
        /** <summary>This will post all messages to the Trace as Log.eLogLevel.xLOGMESSAGE().
         *</summary>*/
        public LogTraceListener()
            : this(Log.eLogLevel.xLOGMESSAGE)
        {
        }

        public override void Write(string message)
        {
            using (wxString wxMessage = new wxString(message))
            {
                if (Log._enabled)
                Log.wxLog_Log_Function((int)this._eLevel, wxMessage.wxObject);
            }
        }

        public override void WriteLine(string message)
        {
            using (wxString wxMessage = new wxString(message + "\n"))
            {
                if (Log._enabled)
                Log.wxLog_Log_Function((int)this._eLevel, wxMessage.wxObject);
            }
        }

        /** <summary>Returns the log level.
         *</summary>*/
        public Log.eLogLevel Level { get { return this._eLevel; } }
    }
}
