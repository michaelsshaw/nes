//------------------------------------------------------------------------
// wx.NET - Display.cs
// 
// Michael S. Muegel mike _at_ muegel dot org
// complete redesign of PInvoke interface 2009 Harald Meyer auf'm Hofe
//
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// TODO:
//    + Memory management review
//
// wxWidgets-based quirks of note:
//    + Display resolution did not change on my Fedora1 test system
//      under both wxWidgets display sample and my port.
//    + IsPrimary is wrong, at least on WIN32: assumes display #0
//      is primary, which may not be the case. For example, I have
//      three horizontally aligned displays. wxWidgets numbers them
//      0, 1, 2. But it's #1 is actually the primary, not 0. Note also
//      that the numbering scheme differs from how windows numbers
//      them, which has more to do with the display adapter used. This
//      is not an issue really, but something to be aware of should
//      you be expecting them to match.
//------------------------------------------------------------------------

#if WXNET_DISPLAY

using System;
using System.Drawing;
using System.Runtime.InteropServices;

namespace wx
{
    /** <summary>Use static method GetDisplay() to generate instances.
     * Please note, that this method will generate at most on instance for each display.
     * 
     * Currently, this class causes access violations with Windows.
     *</summary>*/
	public class Display : Object
	{
		#region C API
		[DllImport("wx-c")] static extern IntPtr wxDisplay_ctor(int index);
        [DllImport("wx-c")] static extern void wxDisplay_RegisterOnDispose(IntPtr self, Virtual_Dispose virtualDisposeMethod);
		[DllImport("wx-c")] static extern int wxDisplay_GetCount();
		[DllImport("wx-c")] static extern int wxDisplay_GetFromPoint(ref Point pt);
		[DllImport("wx-c")] static extern int wxDisplay_GetFromWindow(IntPtr window);
        [DllImport("wx-c")]
        static extern void wxDisplay_GetGeometry(IntPtr self, out int x, out int y, out int w, out int h);
		[DllImport("wx-c")] static extern IntPtr wxDisplay_GetName(IntPtr self);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxDisplay_IsPrimary(IntPtr self);
		[DllImport("wx-c")] static extern void wxDisplay_GetCurrentMode(IntPtr self,out int w, out int h, out int bpp, out int refreshFrequency);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxDisplay_ChangeMode(IntPtr self, VideoMode mode);


		[DllImport("wx-c")] static extern int wxArrayVideoModes_Count(IntPtr self);
        [DllImport("wx-c")] static extern void wxArrayVideoModes_Item(IntPtr self, int index, out int w, out int h, out int bpp, out int freq);
        [DllImport("wx-c")]
        static extern void wxArrayVideoModes_Delete(IntPtr self);
		[DllImport("wx-c")] static extern IntPtr wxDisplay_GetModes(IntPtr self, VideoMode mode);

		
		[DllImport("wx-c")] static extern void wxDisplay_ResetMode(IntPtr self);
		[DllImport("wx-c")] static extern void wxDisplay_dtor(IntPtr self);
		#endregion

		//------------------------------------------------------------------------

		/** <summary>Symbolic constant used by all Find()-like functions returning positive
		  * integer on success as failure indicator. While this is global in
		  * wxWidgets it makes more sense to be in each class that uses it??? 
		  * Or maybe move it to Window.cs.
         *</summary>*/
		public const int wxNOT_FOUND = -1;
		
		//------------------------------------------------------------------------
		#region CTor /DTor
		public Display(IntPtr wxObject)
			: base(wxObject)
		{ 
			this.wxObject = wxObject;
            this.virtual_Dispose = new Virtual_Dispose(this.VirtualDispose);
            wxDisplay_RegisterOnDispose(this.wxObject, this.virtual_Dispose);
		}
			
		internal Display(IntPtr wxObject, bool memOwn)
			: base(wxObject)
		{ 
			this.memOwn = memOwn;
			this.wxObject = wxObject;
            this.virtual_Dispose = new Virtual_Dispose(this.VirtualDispose);
            wxDisplay_RegisterOnDispose(this.wxObject, this.virtual_Dispose);
        }

		//------------------------------------------------------------------------
        static IntPtr SynchronizedCTor(int index)
        {
            lock (DllSync)
            {
                return wxDisplay_ctor(index);
            }
        }

        internal Display(int index)
			: this(SynchronizedCTor(index), true)
        {
        }

		//------------------------------------------------------------------------
		
		protected override void CallDTor ()
		{
			wxDisplay_dtor(this.wxObject);
		}

		
		~Display() 
		{
			Dispose();
		}
		#endregion
		
		//------------------------------------------------------------------------
		public static int Count
		{
			get { return wxDisplay_GetCount(); }
		}

        static Display[] s_displays=null;

		/** <summary>The array of all Displays indexed by display number.
         * These are all instance of this class that should ever live.</summary>*/
		public static Display[] GetDisplays()
		{
            if (s_displays == null)
            {
                s_displays = new Display[Count];
                for (int i = 0; i < Count; i++)
                {
                    // currently, destruction of display instances crashes the system
                    // "access violation". i cannot imagine why.
                    s_displays[i] = new Display(i);
                    s_displays[i].memOwn = false;
                }
            }
            return s_displays;
		}

        /** <summary>Returns the representation of the desired display.
         * \return null iff the index is too large.</summary>*/
        public static Display GetDisplay(int index)
        {
            if (s_displays == null) GetDisplays();
            if (index < 0 || index >= s_displays.Length)
            {
                return null;
            }
            return s_displays[index];
        }

        //------------------------------------------------------------------------
		// An array of available VideoModes for this display.
		virtual public VideoMode[] GetModes()
		{
			return GetModes(new VideoMode(0,0,0,0));
		}

		/** <summary>An array of the VideoModes that match mode.
        * A match occurs when
		* the resolution and depth matches and the refresh frequency in 
		* equal to or greater than mode.RefreshFrequency.</summary>*/
		virtual public VideoMode[] GetModes(VideoMode mode)
		{
            IntPtr modeArray = IntPtr.Zero;
            try
            {
                modeArray = wxDisplay_GetModes(this.wxObject, mode);
                VideoMode[] result = new VideoMode[wxArrayVideoModes_Count(modeArray)];
                for (int i = 0; i < result.Length; ++i)
                {
                    int w, h, bpp, freq;
                    wxArrayVideoModes_Item(modeArray, i, out w, out h, out bpp, out freq);
                    result[i] = new VideoMode(w, h, bpp, freq);
                }
                return result;
            }
            finally
            {
                if (modeArray != IntPtr.Zero)
                    wxArrayVideoModes_Delete(modeArray);
            }
		}


		//------------------------------------------------------------------------

		public static int GetFromPoint(Point pt)
		{
			return wxDisplay_GetFromPoint(ref pt);
		}

		//------------------------------------------------------------------------

        /** <summary>This returns the display that shows <c>window</c>.
         * This will throw an exception of this is not Windows.
         * </summary>
         */
		public int GetFromWindow(Window window)
		{
            if (ReflectConfig.CheckWxMSW())
				return wxDisplay_GetFromWindow(Object.SafePtr(window));
			else
				throw new ApplicationException("Display.GetFromWindow is only available on WIN32");
		}

		//------------------------------------------------------------------------

		public Rectangle Geometry
		{
			get 
			{
                int x, y, w, h;
				wxDisplay_GetGeometry(this.wxObject, out x, out y, out w, out h);
				return new Rectangle(new Point(x, y), new Size(w, h));
			}
		}

		//------------------------------------------------------------------------

		virtual public string Name
		{
			get 
			{
				return new wxString(wxDisplay_GetName(wxObject), true);
			}
		}

		//------------------------------------------------------------------------

		virtual public bool IsPrimary
		{
			get 
			{ 
				return wxDisplay_IsPrimary(wxObject);
			}
		}

		//------------------------------------------------------------------------


		virtual public VideoMode CurrentMode
		{
			get
			{
                int h,w, d, freq;
				wxDisplay_GetCurrentMode(wxObject, out w, out h, out d, out freq);
                VideoMode mode = new VideoMode(w, h, d, freq);
				return mode;
			}
		}

		//------------------------------------------------------------------------

		virtual public bool ChangeMode(VideoMode mode)
		{
			return wxDisplay_ChangeMode(wxObject, mode);
		}

		//------------------------------------------------------------------------

		virtual public void ResetMode()
		{
			wxDisplay_ResetMode(wxObject);
		}

		//------------------------------------------------------------------------

	}

}

#endif
