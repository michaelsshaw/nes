//-----------------------------------------------------------------------------
// wx.NET - ControlWithItems.cs
//
// The ControlWithItems wrapper class.
//
// Written by Harald Meyer auf'm Hofe
// (C) 2007 Harald Meyer auf'm Hofe
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: ControlWithItems.cs,v 1.6 2010/05/08 19:52:40 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Collections;
using System.Runtime.InteropServices;

namespace wx
{
    /// <summary>
    /// base class of some controls presenting a list of items.
    /// </summary>
    public class ControlWithItems : Control
    {
        #region CAPI
        [DllImport("wx-c")]
        static extern void wxControlWithItems_SetSelection(IntPtr self, int n);
        [DllImport("wx-c")]
        static extern IntPtr wxControlWithItems_GetStringSelection(IntPtr self);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxControlWithItems_SetStringSelection(IntPtr self, IntPtr value);


        [DllImport("wx-c")]
        static extern int wxControlWithItems_FindString(IntPtr self, IntPtr str);

        [DllImport("wx-c")]
        static extern void wxControlWithItems_Delete(IntPtr self, int n);
        [DllImport("wx-c")]
        static extern void wxControlWithItems_Clear(IntPtr self);

        [DllImport("wx-c")]
        static extern int wxControlWithItems_Append(IntPtr self, IntPtr item);
        [DllImport("wx-c")]
        static extern int wxControlWithItems_AppendWithData(IntPtr self, IntPtr item, IntPtr data);

        [DllImport("wx-c")]
        static extern int wxControlWithItems_GetCount(IntPtr self);
        [DllImport("wx-c")]
        static extern IntPtr wxControlWithItems_GetString(IntPtr self, int n);
        [DllImport("wx-c")]
        static extern int wxControlWithItems_GetSelection(IntPtr self);

        [DllImport("wx-c")]
        static extern int wxControlWithItems_Insert(IntPtr self, IntPtr item, int pos);
        [DllImport("wx-c")]
        static extern int wxControlWithItems_InsertWithData(IntPtr self, IntPtr item, int pos, IntPtr data);

        //[DllImport("wx-c")] static extern IntPtr wxControlWithItems_GetStrings(IntPtr self);

        [DllImport("wx-c")]
        static extern IntPtr wxControlWithItems_GetClientObject(IntPtr self, int n);
        [DllImport("wx-c")]
        static extern void wxControlWithItems_SetClientObject(IntPtr self, int n, IntPtr data);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxControlWithItems_HasClientObjectData(IntPtr self, int n);

        [DllImport("wx-c")]
        static extern void wxControlWithItems_SetString(IntPtr self, int n, IntPtr text);

        //[DllImport("wx-c")] static extern void wxControlWithItems_Select(IntPtr self, int n);

        [DllImport("wx-c")] [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxControlWithItems_ShouldInheritColours(IntPtr self);

        [DllImport("wx-c")] [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxControlWithItems_IsEmpty(IntPtr self);
        #endregion

        #region CTor
        public ControlWithItems(IntPtr wxObject) 
			: base(wxObject) { }
        #endregion

        #region Public Properties
		public int Selection
		{
            get
            {
                if (this.IsEmpty)
                    return -1;
                return wxControlWithItems_GetSelection(this.wxObject);
            }
            set
            {
                wxControlWithItems_SetSelection(this.wxObject, value);
            }
		}

        /** <summary>Also refer to method SetStringSelection() that returns a Boolean that is true on success and false otherwise.
         *</summary>*/
        public string StringSelection
        {
            get
            {
                if (this.IsEmpty)
                    return "";
                return new wxString(wxControlWithItems_GetStringSelection(wxObject), true);
            }
            set
            {
                wxString wxValue = new wxString(value);
                wxControlWithItems_SetStringSelection(wxObject, wxValue.wxObject);
            }
        }

        /** <summary>Returns the number of items.
         *</summary>*/
        public int Count { get { return wxControlWithItems_GetCount(this.wxObject); } }

        /** <summary>True iff this is empty.
         *</summary>*/
        public bool IsEmpty { get { return wxControlWithItems_IsEmpty(this.wxObject); } }

        /** <summary>All the currently known labels.
         * Read only property. Alternatively, use the indexer of this class.
         *</summary>*/
        public string[] Strings
        {
            get
            {
                string[] result = new string[this.Count];
                for (int i = 0; i < result.Length; ++i)
                    result[i] = this.GetString(i);
                return result;
            }
        }

        /** <summary>This is equivalent to the methods GetString() and SetString().
         *</summary>*/
        public string this[int n]
        {
            get { return this.GetString(n); }
            set { this.SetString(n, value); }
        }
        #endregion

        #region Public Methods
        /** <summary>Set the label of the entry of index <c>n</c>.
         * Refer also to the indexer of this class.
         * </summary>
         */
        public void SetString(int n, string label)
        {
            wxString wxLabel = new wxString(label);
            wxControlWithItems_SetString(this.wxObject, n, wxLabel.wxObject);
        }
        /** <summary>Get the label of the entry of index <c>n</c>.
         * Refer also to the indexer of this class.
         *</summary>*/
        public string GetString(int n)
        {
            return new wxString(wxControlWithItems_GetString(this.wxObject, n));
        }

        /** <summary>Finds an item whose label matches the given string.</summary>
         * <returns> The zero-based position of the item, or -1 if the string was not found.</returns>*/
        public int FindString(string str)
        {
            return this.FindString(new wxString(str));
        }
        public int FindString(wxString str)
        {
            return wxControlWithItems_FindString(wxObject, str.wxObject);
        }

        /** <summary>Select the designated label. Return <c>true</c> on success and <c>false</c> otherwise.
         * Refer also to property <c>StringSelection()</c>.
         *</summary>
         */
        public bool SetStringSelection(string selectedLabel)
        {
            wxString wxLabel=new wxString(selectedLabel);
            return wxControlWithItems_SetStringSelection(this.wxObject, wxLabel.wxObject);
        }

        /** \name Client data of items
         * The .NET interface does not distinguish between client data and client object:
         * The interface only supports client objects. Refer  to class SystemObjectClientData.
         */ 
        //@{
        /** <summary>Reads client data for item <c>n</c>.
         * </summary>
         */
        public ClientData GetClientObject(int n)
        {
            ClientData result = (ClientData)Object.FindObject(wxControlWithItems_GetClientObject(this.wxObject, n), typeof(ClientData));
            // this might seem surplus but in case changes to client data committed within the wx-c dll, this will
            // ensure an update of the client data list at least on reading the changed item.
            return result;
        }

        public void SetClientData(int n, ClientData data)
        {
            data.memOwn = false;
            wxControlWithItems_SetClientObject(this.wxObject, n, data.wxObject);
        }

        public bool HasClientObjectData(int n)
        {
            return wxControlWithItems_HasClientObjectData(this.wxObject, n);
        }
        //@}

        /** \name Maintaining items.
         */
        //@{
        public void Append(string[] items)
        {
            foreach(string item in items)
                this.Append(item);
        }
        public int Append(string item)
        {
            return this.Append(item, null);
        }
        public int Append(wxString item, ClientData clientData)
        {
            if (clientData == null)
                return wxControlWithItems_Append(this.wxObject, item.wxObject);
            else
            {
                int result=wxControlWithItems_AppendWithData(this.wxObject, item.wxObject, clientData.wxObject);
                return result;
            }
        }
        /** <summary>This will append <c>item</c> to the end of the item list and associate it with the provided client data.
         * The client data may be <c>null</c>.
         *</summary> 
         * <returns> The index of the new item.</returns>
         */
        public int Append(string item, ClientData clientData)
        {
            return this.Append(new wxString(item), clientData);
        }

        public int Insert(string item, int pos)
        {
            return this.Insert(item, pos, null);
        }
        public int Insert(wxString item, int pos, ClientData clientData)
        {
            if (clientData == null)
                return wxControlWithItems_Insert(this.wxObject, item.wxObject, pos);
            else
            {
                int result = wxControlWithItems_InsertWithData(this.wxObject, item.wxObject, pos, clientData.wxObject);
                return result;
            }
        }

        /** <summary>Inserts the item into the list before pos, associating the given, typed or untyped, client data pointer with the item.
         * Not valid for ListBox.wxLB_SORT or ComboBox.wxCB_SORT styles, use Append() instead.</summary>
         * <returns> The return value is the index of the newly inserted item. If the insertion failed for some reason, -1 is returned.</returns>*/
        public int Insert(string item, int pos, ClientData clientData)
        {
            return this.Insert(new wxString(item), pos, clientData);
        }

        /** <summary>Deletes all items.
         *</summary>*/
        public void Clear()
        {
            lock (wx.Object.DllSync)
            {
                wxControlWithItems_Clear(this.wxObject);
            }
        }

        public void Delete(int n)
        {
            lock (wx.Object.DllSync)
            {
                wxControlWithItems_Delete(this.wxObject, n);
            }
        }
        //@}

        public override bool ShouldInheritColours()
        {
            return wxControlWithItems_ShouldInheritColours(this.wxObject);
        }
        #endregion
    }
}
