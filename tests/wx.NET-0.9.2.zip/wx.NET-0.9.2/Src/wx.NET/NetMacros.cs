/**
 * wx.NET Project
 * 
 * \file 
 * 
 * Component model for \e wx-NET.
 * 
 * Written by Harald Meyer auf'm Hofe (C) 2010
 * Licensed under the wxWidgets license, see LICENSE.txt for details.
 *
 * $Id: NetMacros.cs,v 1.2 2010/07/12 18:23:50 harald_meyer Exp $
 */

using System;
using System.Reflection;
using System.Collections.Generic;

/** This namespace implements a very simple programming language using the .NET framework.
 * This programming language is not meant to be used to produce program source code - C#
 * is deffinitely a better choice for this purpose. Applications may use this language instead
 * to define macros (e.g. text editing). This simple framework has been implemented for the
 * RAD tool, but may be used in a quite similar fashion in other applications.
 * 
 * This system consists of classes like TypeDescriptor or MethodDescriptor whose
 * instances designate types and method provided by .NET assemblies. These
 * designators can be used in classes like Generator to build executable statements.
 * These executable statements can be passed to a RuntimeEnv for execution.
 * 
 * Executable objects have been designed for XML serialization / deserialization
 * by System.Xml.Serialization.XmlSerializer. Thus, macros that have been expressed
 * in this little language can be stored in or loaded from files. However, you should
 * not expect the result to be readable by humans. As mentioned above, use C# or BOO
 * if you want to code. Use this if you want to generate executable code that you
 * want to be composed or analyzed by computer programs. 
 */
namespace wx.NetMacros
{
    /// <summary>
    /// Simply a component containing  
    /// a namespace name, and a type name. The are the properties of a type
    /// that will be serialized.
    /// </summary>
    public class TypeDescriptor : IComparable, System.Xml.Serialization.IXmlSerializable
    {
        string _namespace;
        string _typename;

        /// <summary>
        /// Creates a representation of type System.Object. 
        /// This ctor is meant to be used on deserialization.
        /// </summary>
        public TypeDescriptor()
            : this(typeof(object))
        {
        }

        public TypeDescriptor(Type t)
        {
            this._typename = t.Name;
            this._namespace = t.Namespace;
        }

        public string Namespace { get { return this._namespace; } set { this._namespace = value; } }
        public string Name { get { return this._typename; } set { this._typename = value; } }

        public override bool Equals(object obj)
        {
            return this.CompareTo(obj)==0;
        }

        public override int  GetHashCode()
        {
 	         return this._namespace.GetHashCode() ^ this._typename.GetHashCode();
        }

        public override string ToString()
        {
            return string.Format("T:{0}.{1}", this.Namespace, this.Name);
        }
    
        #region IComparable Member
        /// <summary>
        /// Compares Name and Namespace.
        /// </summary>
        /// <param name="obj">The object to compare with.</param>
        /// <returns></returns>
        public int CompareTo(object obj)
        {
 	        int result=0;
            TypeDescriptor arg=obj as TypeDescriptor;
            if (arg == null)
                result = this.GetType().FullName.CompareTo(obj.GetType().FullName);
            else
            {
                result=this.Namespace.CompareTo(arg.Namespace);
                if (result==0)
                    result=this.Name.CompareTo(arg.Name);
            }
            return result;
        }

        #endregion

        #region IXmlSerializable Member

        public System.Xml.Schema.XmlSchema GetSchema()
        {
            return null;
        }

        /// <summary>
        /// Parses a string and creates a type descriptor.
        /// </summary>
        /// <param name="str">A string like "M:wx.Object" or "wx.Object".</param>
        /// <returns></returns>
        public static TypeDescriptor Parse(string str)
        {
            TypeDescriptor ti = new TypeDescriptor();
            ti.SetFromString(str);
            return ti;
        }

        /// <summary>
        /// Parses a string and sets the properties of this instance accordingly.
        /// </summary>
        /// <param name="str">A string like "M:wx.Object" or "wx.Object".</param>
        /// <returns></returns>
        void SetFromString(string str)
        {
            if (str.StartsWith("T:"))
                str = str.Substring(2);

            int i = str.LastIndexOf('.');
            if (i < 0)
            {
                this._typename = str;
                this._namespace = "";
            }
            else
            {
                this._typename = str.Substring(i + 1);
                this._namespace = str.Substring(0, i);
            }
        }

        public void ReadXml(System.Xml.XmlReader reader)
        {
            string str = reader.ReadString();
            this.SetFromString(str);
        }

        public void WriteXml(System.Xml.XmlWriter writer)
        {
            writer.WriteString(this.ToString());
        }

        #endregion
    }

    /// <summary>
    /// Used to define in instances of member descriptor whether this is
    /// a method or a property.
    /// </summary>
    public enum MemberType
    {
        Property,
        Method,
    }

    /// <summary>
    /// Instances of this class combine a TypeDescriptor with an additional
    /// member name. Instances will be used to designate members of classes,
    /// properties or methods.
    /// </summary>
    public class MemberDescriptor : IComparable, System.Xml.Serialization.IXmlSerializable
    {
        TypeDescriptor _type;
        string _membername;
        MemberType _memberType;


        /// <summary>
        /// Default ctor creating a reference to the member Name of this class.
        /// This is a dummy that will be used be deserialization.
        /// </summary>
        public MemberDescriptor()
        {
            this._type = new TypeDescriptor(this.GetType());
            this._membername = "Name";
            this._memberType = MemberType.Property;
        }

        /// <summary>
        /// Creates an instance of the specified properties.
        /// </summary>
        /// <param name="membertype">The type of member (method or property)</param>
        /// <param name="type">The type declaring the member.</param>
        /// <param name="membername">the name of the member.</param>
        public MemberDescriptor(MemberType membertype, TypeDescriptor type, string membername)
        {
            this._memberType = membertype;
            this._membername = membername;
            this._type = type;
        }

        /// <summary>
        /// Creates an instance designating the provided property.
        /// </summary>
        /// <param name="pi">Information on a property</param>
        public MemberDescriptor(PropertyInfo pi)
        {
            this._type = new TypeDescriptor(pi.DeclaringType);
            this._membername = pi.Name;
            this._memberType = MemberType.Property;
        }

        /// <summary>
        /// Creates an instance designating the provided method.
        /// </summary>
        /// <param name="mi">Information on a method</param>
        public MemberDescriptor(MethodInfo mi)
        {
            this._type = new TypeDescriptor(mi.DeclaringType);
            this._membername = mi.Name;
            this._memberType = MemberType.Method;
        }

        /// <summary>
        /// This will parse strings of the form <c>"M:Namespace.ClassName.MemberName"</c>.
        /// </summary>
        /// <param name="str">The properties of the returned instance as string.</param>
        /// <returns></returns>
        static public MemberDescriptor Parse(string str)
        {
            MemberDescriptor result = new MemberDescriptor();
            result.SetFromString(str);
            return result;
        }

        public TypeDescriptor DeclaringType { get { return this._type; } set { this._type = value; } }
        public string Name { get { return this._membername; } set { this._membername = value; } }
        public MemberType Membertype { get { return this._memberType; } set { this._memberType = value; } }

        public override bool Equals(object obj)
        {
            return this.CompareTo(obj) == 0;
        }

        public override int GetHashCode()
        {
            return this._type.GetHashCode() ^ this._membername.GetHashCode();
        }

        public override string ToString()
        {
            string memberType="";
            switch (this._memberType)
            {
                case MemberType.Method: memberType="M:"; break;
                case MemberType.Property: memberType="P:"; break;
            }
            return string.Format("{0}{1}.{2}.{3}", memberType, this.DeclaringType.Namespace, this.DeclaringType.Name, this.Name);
        }

        #region IComparable Member

        public virtual int CompareTo(object obj)
        {
            MemberDescriptor arg = obj as MemberDescriptor;
            if (arg == null)
            {
                return this.GetType().FullName.CompareTo(obj.GetType().FullName);
            }
            else
            {
                int result = 0;
                if (result == 0)
                    result = this.DeclaringType.CompareTo(arg.DeclaringType);
                if (result == 0)
                    result = this.Membertype.CompareTo(arg.Membertype);
                if (result == 0)
                    result = this.Name.CompareTo(arg.Name);
                return result;
            }
        }

        #endregion

        /// <summary>
        /// Parses a string and sets the properties of this instance accordingly.
        /// </summary>
        /// <param name="str">A string like "T:wx.Object" or "wx.Object".</param>
        /// <returns></returns>
        protected virtual void SetFromString(string str)
        {
            if (str.StartsWith("M:"))
            {
                this._memberType = MemberType.Method;
                str=str.Substring(2);
            }
            else if (str.StartsWith("P:"))
            {
                this._memberType = MemberType.Property;
                str = str.Substring(2);
            }
            int openBracket = str.IndexOf('(');
            if (openBracket > 0)
                str = str.Substring(0, openBracket);
            int i = str.LastIndexOf('.');
            if (i < 0)
            {
                this._membername = str;
                this._type = TypeDescriptor.Parse("");
            }
            else
            {
                this._membername = str.Substring(i + 1);
                this._type = TypeDescriptor.Parse( str.Substring(0, i) );
            }
        }

        #region IXmlSerializable Member

        public System.Xml.Schema.XmlSchema GetSchema()
        {
            return null;
        }

        public void ReadXml(System.Xml.XmlReader reader)
        {
            string str = reader.ReadString();
            this.SetFromString(str);
        }

        public void WriteXml(System.Xml.XmlWriter writer)
        {
            writer.WriteString(this.ToString());
        }

        #endregion
    }

    /// <summary>
    /// A member descriptor with attached signature - list of types in a parameter list. 
    /// </summary>
    public class MethodDescriptor : MemberDescriptor
    {
        TypeDescriptor[] _signature = null;

        /// <summary>
        /// Crates empty data. Use this e.g. for serialization.
        /// </summary>
        public MethodDescriptor()
        {
        }

        /// <summary>
        /// Creates an instance describing the provided method.
        /// </summary>
        /// <param name="mi"></param>
        public MethodDescriptor(MethodInfo mi)
            : base(mi)
        {
            List<TypeDescriptor> signature=new List<TypeDescriptor>();
            foreach (ParameterInfo pi in mi.GetParameters())
            {
                signature.Add(new TypeDescriptor(pi.ParameterType));
            }
            this._signature = signature.ToArray();
        }

        MemberDescriptor _generalized = null;
        /// <summary>
        /// Generalized form without argument list. An unspecific designation of
        /// all implementations of the method.
        /// </summary>
        public MemberDescriptor Generalized
        {
            get
            {
                if (this._generalized == null)
                    this._generalized = new MemberDescriptor(MemberType.Method, this.DeclaringType, this.Name);
                return this._generalized;
            }
        }

        /// <summary>
        /// Creates an instance referring to the provided string.
        /// This will expect a string of the format
        /// <c>"M:Namespace.Classname.Methodname(Namespace.TypeOfArg0,Namespace.TypeOfArg1)"</c>
        /// </summary>
        /// <param name="str"></param>
        /// <exception cref="System.FormatException">Thrown if string is of an unknown format.</exception>
        public static MethodDescriptor Parse(string str)
        {
            MethodDescriptor result = new MethodDescriptor();
            result.SetFromString(str);
            return result;
        }

        public TypeDescriptor[] Signature { get { return this._signature; } set { this._signature = value; } }

        public override int CompareTo(object obj)
        {
            int cmp= base.CompareTo(obj);
            if (cmp == 0 && obj is MethodDescriptor)
            {
                MethodDescriptor md = (MethodDescriptor)obj; // non
                for (int i = 0; i < this.Signature.Length && i < md.Signature.Length; ++i)
                {
                    if (cmp != 0)
                        break;
                    cmp = this.Signature[i].CompareTo(md.Signature[i]);
                }
                if (cmp == 0)
                    cmp = this.Signature.Length.CompareTo(md.Signature.Length);
            }
            else if (cmp == 0)
            {
                cmp = this.GetType().FullName.CompareTo(obj.GetType().FullName);
            }
            return cmp;
        }

        public override string ToString()
        {
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            sb.Append(base.ToString());
            sb.Append("(");
            for (int i = 0; i < this.Signature.Length; ++i)
            {
                if (i > 0)
                    sb.Append(",");
                sb.Append(this.Signature[i].Namespace);
                sb.Append(".");
                sb.Append(this.Signature[i].Name);
            }
            sb.Append(")");
            return sb.ToString();
        }

        /// <summary>
        /// Loads the properties of this instance according to the provided string.
        /// This will expect a string of the format
        /// <c>"M:Namespace.Classname.Methodname(Namespace.TypeOfArg0,Namespace.TypeOfArg1)"</c>
        /// </summary>
        /// <param name="str"></param>
        /// <exception cref="System.FormatException">Thrown if string is of an unknown format.</exception>
        protected override void SetFromString(string str)
        {
            if (str.StartsWith("M:"))
            {
                base.SetFromString(str);
            }
            int sigStart = str.IndexOf("(");
            int sigEnd = str.LastIndexOf(")");
            if (sigStart < 0)
                throw new FormatException("Missing bracket opening the parameter list in method descriptor.");
            if (sigEnd < 0)
                throw new FormatException("Missing bracket opening the parameter list in method descriptor.");
            string args = str.Substring(sigStart + 1, sigEnd - sigStart - 1);
            string[] argTypes = args.Split(',');
            List<TypeDescriptor> signature = new List<TypeDescriptor>();
            foreach (string argType in argTypes)
                signature.Add(TypeDescriptor.Parse(argType));
            this._signature = signature.ToArray();
        }
    }

    /// <summary>
    /// Represents a call to a method.
    /// </summary>
    public class MethodCall
    {
        object[] _args = null;
        object _self = null;
        MemberDescriptor _mi = null;
        bool _isStatic = false;

        /// <summary>
        /// Used for serializaton. Produces a call to System.Object.ToString().
        /// </summary>
        public MethodCall()
        {
            this._args = null;
            this._mi = new MemberDescriptor(typeof(object).GetMethod("ToString"));
            this._self = this;
            this._isStatic = false;
        }

        /// <summary>
        /// Creates a call of method <c>mi</c> of object <c>self</c> with parameters <c>args</c>.
        /// This ctor will not test the consistency of hte arguments, i.e. whether this is of the
        /// declaring type of the method.
        /// </summary>
        /// <param name="mi">This is the method that will be called.</param>
        /// <param name="self">This is the object where the method will be called. This parameter will be ignored on static
        /// methods.</param>
        /// <param name="args">These objects will be passed as parameters to the method.</param>
        public MethodCall(MethodInfo mi, object self, params object[] args)
        {
            this._self = self;
            this._args = args;
            if (this._args != null && this._args.Length == 0)
                this._args = null;
            this._mi = new MemberDescriptor(mi);
            this._isStatic = mi.IsStatic;
        }

        public override string ToString()
        {
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            if (this.IsStatic)
                sb.AppendFormat("{1}.{2}.{0}(", this._mi.Name, this._mi.DeclaringType.Namespace, this._mi.DeclaringType.Name);
            else if (this._self != null)
                sb.AppendFormat("(({1}.{2}) {3}).{0}(", this._mi.Name, this._mi.DeclaringType.Namespace, this._mi.DeclaringType.Name, this._self);
            else
                sb.AppendFormat("(({1}.{2}) this).{0}(", this._mi.Name, this._mi.DeclaringType.Namespace, this._mi.DeclaringType.Name, this._self);
            if (this._args != null)
            {
                for (int i = 0; i < this._args.Length; ++i)
                {
                    if (i != 0)
                        sb.Append(", ");
                    sb.Append(this._args[i]);
                }
            }
            sb.Append(")");
            return sb.ToString();
        }

        /// <summary>
        /// Descriptor of the method that will be called.
        /// </summary>
        public MemberDescriptor Method { get { return this._mi; } set { this._mi = value; } }

        /// <summary>
        /// This is the object that implements the method. The method will be called at this object.
        /// This will be <c>null</c> on static methods.
        /// </summary>
        public object Self { get { if (this.IsStatic) return null; else return this._self; } set { this._self = value; } }

        /// <summary>
        /// The arguments that will be passed to the method as parameters. this shall be <c>null</c>
        /// for methods without arguments.
        /// </summary>
        public object[] Args { get { return this._args; } set { this._args = value; } }

        /// <summary>
        /// True iff the called method is static.
        /// </summary>
        public bool IsStatic { get { return this._isStatic; } set { this._isStatic = value; } }
    }

    /// <summary>
    /// Represents the assignment to a property. Properties are: A descriptor of the property and the
    /// assigned value.
    /// </summary>
    public class SetterCall
    {
        MemberDescriptor _mi;
        object _self;
        object _value;

        /// <summary>
        /// Represents setting the value from the parameters to the property designated by the property info.
        /// </summary>
        /// <param name="pi">The property that will be set.</param>
        /// <param name="self">The object that exhibits this property and that will be changed on setting a value.</param>
        /// <param name="value">The value that will be set.</param>
        public SetterCall(PropertyInfo pi, object self, object value)
        {
            this._mi = new MemberDescriptor(pi);
            this._value = value;
            this._self=self;
        }

        /// <summary>
        /// This will be used by the XmlSerializer - a dumy action: Assigning 0 to property Value
        /// of this class.
        /// </summary>
        public SetterCall()
        {
            this._mi = new MemberDescriptor(this.GetType().GetProperty("Value"));
            this._self = this;
            this._value = 0;
        }

        /// <summary>
        /// The object that exhibits this property and that will be changed on setting a value.
        /// </summary>
        public object Self { get { return this._self; } set { this._self = value; } }

        /// <summary>
        /// The value that will be assigned.
        /// </summary>
        public object Value { get { return this._value; } set { this._value = this; } }

        /// <summary>
        /// The property that will get a new value on evaluating this. Only assign members of correct
        /// member type.
        /// </summary>
        public MemberDescriptor Property { get { return this._mi; } set { this._mi = value; } }

        public override string ToString()
        {
            if (this._self==null)
                return string.Format("(({0}.{1}) this).{2}={3}", this._mi.DeclaringType.Namespace,
                    this._mi.DeclaringType.Name, this._mi.Name, this._value);
            else
                return string.Format("(({0}.{1}) {4}).{2}={3}", this._mi.DeclaringType.Namespace,
                    this._mi.DeclaringType.Name, this._mi.Name, this._value, this._self);
        }
    }

    /// <summary>
    /// Base class of all visual components. This class simply represents a call to the 
    /// constructor of a class. You may add a sequence of setter calls to modify the created instance.
    /// You may add a sequence of method calls to modify the created instance.
    /// </summary>
    public class Generator
    {
        TypeDescriptor _type = null;
        object[] _args;
        MemberDescriptor _mi = null;

        List<SetterCall> _setters = new List<SetterCall>();
        List<MethodCall> _modifiers = new List<MethodCall>();

        /// <summary>
        /// Creates an instance of this class providing a type and an array of arguments for a constructor.
        /// </summary>
        /// <param name="type">This �s a factory that will create instances of this type. This must not be an
        /// abstract type.</param>
        /// <param name="ctorArgs">Arguments to the ctor of <c>type</c> that shall be used.</param>
        public Generator(Type type, params object[] ctorArgs)
        {
            this._type = new TypeDescriptor(type);
            this._args = ctorArgs;
            if (this._args != null && this._args.Length == 0)
                this._args = null;
        }

        /// <summary>
        /// This will create an instance using the provided method.
        /// If the method descriptor designates a static method, the arguments will be passed to
        /// this method as provided to this ctor. If the method descriptor designated a non-static
        /// method, this method will be called at the first element of the argument list. The rest of
        /// the argument list will be passed as arguments to the called method.
        /// </summary>
        /// <param name="mi">Descriptor of the method that creates the instance.</param>
        /// <param name="methodArgs">Argument list that will be passed to the designated method.</param>
        public Generator(MethodInfo mi, params object[] methodArgs)
        {
            this._mi = new MemberDescriptor(mi);
            this._type = new TypeDescriptor(mi.ReturnType);
            this._args = methodArgs;
            if (this._args != null && this._args.Length == 0)
                this._args = null;
        }

        /// <summary>
        /// Creates an instance of this class providing a type. The created instance will implement a
        /// factory using the default ctor to create instances.
        /// </summary>
        /// <param name="type">This �s a factory that will create instances of this type. This must not be an
        /// abstract type.</param>
        protected Generator(Type type)
        {
            this._type = new TypeDescriptor(type);
            this._args = null;
        }

        /// <summary>
        /// Adds a new assignment that shall be executed immediately after the new instance has been created.
        /// The declaring type of the property of the setter shall be if the same class as the instance
        /// that has been created by this generator. Setters will run in the order in which they have been added
        /// before the modifiers. The SetterCall.Self member will be ignored. Please note, that side effects on this
        /// property might happen while executing the generator.
        /// </summary>
        /// <param name="sc"></param>
        public void AddSetter(SetterCall sc)
        {
            this._setters.Add(sc);
        }

        /// <summary>
        /// Adds a method that will be called in <c>Create</c> immediately after creating the instance.
        /// This makes only sense if this method is a modifier. The added modifiers will be called in the
        /// order  in which they have been added. Modifiers will be evaluated after the setters have been executed.
        /// The SetterCall.Self member will be ignored. Please note, that side effects on this
        /// property might happen while executing the generator.
        /// </summary>
        /// <param name="mc"></param>
        public void AddModifier(MethodCall mc)
        {
            this._modifiers.Add(mc);
        }

        /// <summary>
        /// This instance will create an instance of this type.
        /// </summary>
        /// <seealso cref="Create"/>
        public TypeDescriptor DeclaringType
        {
            get
            {
                return this._type;
            }
            set
            {
                this._type = value;
            }
        }

        /// <summary>
        /// This will try to create an instance of <c>CreateInstanceOfType</c>
        /// using these arguments.
        /// </summary>
        public object[] Args { get { return this._args; } set { this._args = value; } }

        public SetterCall[] Setters
        {
            get { return this._setters.ToArray(); }
            set
            {
                this._setters.Clear();
                foreach (SetterCall sc in value)
                    this._setters.Add(sc);
            }
        }

        /// <summary>
        /// Modifiers that will be called in <c>Create</c> immediately after the instance has been created.
        /// </summary>
        public MethodCall[] Modifiers { get { return this._modifiers.ToArray(); }
            set
            {
                this._modifiers.Clear();
                foreach (MethodCall sc in value)
                    this._modifiers.Add(sc);
            }
        }


        public override string ToString()
        {
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            if (this._mi == null && this._type != null)
            {
                sb.AppendFormat("new {0}(", this._type.Name);
            }
            else if (this._mi != null)
                sb.AppendFormat("{0}(", this._mi.Name);
            if (this._args != null)
            {
                for (int i = 0; i < this._args.Length; ++i)
                {
                    if (i != 0)
                        sb.Append(", ");
                    sb.Append(this._args[i].ToString());
                }
            }
            return sb.ToString();
        }
    }

    /// <summary>
    /// A very simple execution environment for runable components of the .NET macro collection.
    /// </summary>
    public class RuntimeEnv
    {
        List<Assembly> _callableAssembles = new List<Assembly>();

        /// <summary>
        /// Creates a runtime environment where all public ctors, methods, and properties 
        /// of the listed assemblies can be called.
        /// </summary>
        /// <param name="callableAssembles">A collection of assemblies. All ctors, methods, and properties of these 
        /// assemblies can be called/executed in this runtime environment.</param>
        public RuntimeEnv(params Assembly[] callableAssembles)
        {
            if (callableAssembles != null)
                foreach (Assembly a in callableAssembles)
                    this._callableAssembles.Add(a);
        }

        #region Get Assemblies, Types, Properties, and Methods
        /// <summary>
        /// Returns a read-only collection of those assemblies forming the runtime environment.
        /// All public ctors, methods, and properties of these assembles my be accessed by actions
        /// executed by this runtime environment.
        /// </summary>
        public ICollection<Assembly> CallableAssemblies
        {
            get
            {
                return this._callableAssembles;
            }
        }

        Dictionary<TypeDescriptor, Type> _types = new Dictionary<TypeDescriptor, Type>();
        /// <summary>
        /// Finds the type designated by the descriptor in the parameter list.
        /// </summary>
        /// <param name="ti">Name and namespace of the type to return.</param>
        /// <returns>The designated type or <c>null</c> if non of the callable assemblies
        /// knows a type of the requested name.</returns>
        public Type GetType(TypeDescriptor ti)
        {
            if (this._types.ContainsKey(ti))
                return this._types[ti];
            foreach (Assembly a in this._callableAssembles)
            {
                foreach (Type t in a.GetExportedTypes())
                    if (t.Namespace == ti.Namespace
                        && t.Name == ti.Name)
                    {
                        this._types[ti] = t;
                        return t;
                    }
            }
            return null;
        }

        /// <summary>
        /// Returns information on the method designated by the argument.
        /// </summary>
        /// <param name="mi">A member designator that is expected to designate a method.</param>
        /// <returns>Information on the designated method or <c>null</c> if hte method has not been found.</returns>
        public MethodInfo GetMethod(MemberDescriptor mi)
        {
            Type t = this.GetType(mi.DeclaringType);
            if (t == null)
                return null;
            return t.GetMethod(mi.Name);
        }

        /// <summary>
        /// Returns information on the property designated by the argument.
        /// </summary>
        /// <param name="mi">A member designator that is expected to designate a property.</param>
        /// <returns>Information on the designated method or <c>null</c> if hte property has not been found.</returns>
        public PropertyInfo GetProperty(MemberDescriptor mi)
        {
            Type t = this.GetType(mi.DeclaringType);
            if (t == null)
                return null;
            return t.GetProperty(mi.Name);
        }
        #endregion

        #region Execute Statements
        /// <summary>
        /// Executes a mathod.
        /// </summary>
        /// <param name="mc">The method to be executed.</param>
        /// <exception cref="System.ArgumentExeption">This will be thrown if some necessary properties of the method call are missing.
        /// This exception will arise for instance if the type is unknown.</exception>
        /// <returns>The object that results from the call. This is <c>null</c> for <c>void</c> methods.</returns>
        public object Invoke(MethodCall mc)
        {
            MethodInfo mi = this.GetMethod(mc.Method);
            if (mi == null)
                throw new ArgumentException(string.Format("Unknown method {0}.", mc));
            return mi.Invoke(mc.Self, mc.Args);
        }

        /// <summary>
        /// Executes a setter.
        /// </summary>
        /// <param name="sc">The setter (assignment to a property) that will be executed.</param>
        /// <exception cref="System.ArgumentExeption">This will be thrown if some necessary properties of the method call are missing.
        /// This exception will arise for instance if the type is unknown.</exception>
        public void Invoke(SetterCall sc)
        {
            PropertyInfo pi = this.GetProperty(sc.Property);
            if (pi == null)
                throw new ArgumentException(string.Format("Unknown property {0}.", pi));
            pi.SetValue(sc.Self, sc.Value, null);
        }

        /// <summary>
        /// Creates an instance following the instructions included in the provided generator.
        /// This method will change MethodCall.Self and SetterCall.Self of all stters and modifiers
        /// of the generator: Self will be set to the newly created instance.
        /// </summary>
        /// <param name="generator">Activator call and subsequent setter and modifier calls that shall be executed to create
        /// the desired instance.</param>
        /// <returns>The created instance.</returns>
        /// <exception cref="System.ArgumentExeption">This will be thrown if some necessary properties of the method call are missing.
        /// This exception will arise for instance if the type is unknown.</exception>
        public object CreateInstance(Generator generator)
        {
            Type declaringType = this.GetType(generator.DeclaringType);
            if (declaringType == null)
                throw new ArgumentException(string.Format("Cannot find type {0}.", generator.DeclaringType));
            object instance=Activator.CreateInstance(declaringType, generator.Args);
            foreach (SetterCall sc in generator.Setters)
            {
                sc.Self = instance;
                this.Invoke(sc);
            }
            foreach (MethodCall mc in generator.Modifiers)
            {
                mc.Self = instance;
                this.Invoke(mc);
            }
            return instance;
        }
        #endregion

        #region Documentation
        #endregion
    }
}
