//-----------------------------------------------------------------------------
// wx.NET - Defs.cs
//
// Symbol definitions that do not belong to any particular class.
//
// Written by Jason Perkins (jason@379.com)
// (C) 2003 by 379, Inc.
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: Defs.cs,v 1.44 2010/01/24 13:40:48 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Drawing;

namespace wx
{
    /** <summary>Standard menu IDs. </summary>*/
	public enum MenuIDs
	{
		wxID_LOWEST = 4999,

		wxID_OPEN,
		wxID_CLOSE,
		wxID_NEW,
		wxID_SAVE,
		wxID_SAVEAS,
		wxID_REVERT,
		wxID_EXIT,
		wxID_UNDO,
		wxID_REDO,
		wxID_HELP,
		wxID_PRINT,
		wxID_PRINT_SETUP,
		wxID_PREVIEW,
		wxID_ABOUT,
		wxID_HELP_CONTENTS,
		wxID_HELP_COMMANDS,
		wxID_HELP_PROCEDURES,
		wxID_HELP_CONTEXT,
		wxID_CLOSE_ALL,
		wxID_PREFERENCES ,
		
		wxID_CUT = 5030,
		wxID_COPY,
		wxID_PASTE,
		wxID_CLEAR,
		wxID_FIND,
		wxID_DUPLICATE,
		wxID_SELECTALL,
		wxID_DELETE,
		wxID_REPLACE,
		wxID_REPLACE_ALL,
		wxID_PROPERTIES,
		
		wxID_VIEW_DETAILS,
		wxID_VIEW_LARGEICONS,
		wxID_VIEW_SMALLICONS,
		wxID_VIEW_LIST,
		wxID_VIEW_SORTDATE,
		wxID_VIEW_SORTNAME,
		wxID_VIEW_SORTSIZE,
		wxID_VIEW_SORTTYPE,
		
		wxID_FILE1 = 5050,
		wxID_FILE2,
		wxID_FILE3,
		wxID_FILE4,
		wxID_FILE5,
		wxID_FILE6,
		wxID_FILE7,
		wxID_FILE8,
		wxID_FILE9,
		
		/*  Standard button and menu IDs */
		wxID_OK = 5100,
		wxID_CANCEL,
		wxID_APPLY,
		wxID_YES,
		wxID_NO,
		wxID_STATIC,
		wxID_FORWARD,
		wxID_BACKWARD,
		wxID_DEFAULT,
		wxID_MORE,
		wxID_SETUP,
		wxID_RESET,
		wxID_CONTEXT_HELP,
		wxID_YESTOALL,
		wxID_NOTOALL,
		wxID_ABORT,
		wxID_RETRY,
		wxID_IGNORE,
		wxID_ADD,
		wxID_REMOVE,
		
		wxID_UP,
		wxID_DOWN,
		wxID_HOME,
		wxID_REFRESH,
		wxID_STOP,
		wxID_INDEX,
		
		wxID_BOLD,
		wxID_ITALIC,
		wxID_JUSTIFY_CENTER,
		wxID_JUSTIFY_FILL,
		wxID_JUSTIFY_RIGHT,
		wxID_JUSTIFY_LEFT,
		wxID_UNDERLINE,
		wxID_INDENT,
		wxID_UNINDENT,
		wxID_ZOOM_100,
		wxID_ZOOM_FIT,
		wxID_ZOOM_IN,
		wxID_ZOOM_OUT,
		wxID_UNDELETE,
		wxID_REVERT_TO_SAVED,
		
		/*  System menu IDs (used by wxUniv): */
		wxID_SYSTEM_MENU = 5200,
		wxID_CLOSE_FRAME,
		wxID_MOVE_FRAME,
		wxID_RESIZE_FRAME,
		wxID_MAXIMIZE_FRAME,
		wxID_ICONIZE_FRAME,
		wxID_RESTORE_FRAME,
		
		/*  IDs used by generic file dialog (13 consecutive starting from this value) */
		wxID_FILEDLGG = 5900,
		
		wxID_HIGHEST = 5999
	}

    /** <summary>Designators for eys on the keyboard.</summary>*/
    public enum KeyCode
    {
        WXK_BACK = 8,
        WXK_TAB = 9,
        WXK_RETURN = 13,
        WXK_ESCAPE = 27,
        WXK_SPACE = 32,
        WXK_DELETE = 127,

        WXK_START = 300,
        WXK_LBUTTON,
        WXK_RBUTTON,
        WXK_CANCEL,
        WXK_MBUTTON,
        WXK_CLEAR,
        WXK_SHIFT,
        WXK_ALT,
        WXK_CONTROL,
        WXK_MENU,
        WXK_PAUSE,
        WXK_CAPITAL,
        WXK_END,
        WXK_HOME,
        WXK_LEFT,
        WXK_UP,
        WXK_RIGHT,
        WXK_DOWN,
        WXK_SELECT,
        WXK_PRINT,
        WXK_EXECUTE,
        WXK_SNAPSHOT,
        WXK_INSERT,
        WXK_HELP,
        WXK_NUMPAD0,
        WXK_NUMPAD1,
        WXK_NUMPAD2,
        WXK_NUMPAD3,
        WXK_NUMPAD4,
        WXK_NUMPAD5,
        WXK_NUMPAD6,
        WXK_NUMPAD7,
        WXK_NUMPAD8,
        WXK_NUMPAD9,
        WXK_MULTIPLY,
        WXK_ADD,
        WXK_SEPARATOR,
        WXK_SUBTRACT,
        WXK_DECIMAL,
        WXK_DIVIDE,
        WXK_F1,
        WXK_F2,
        WXK_F3,
        WXK_F4,
        WXK_F5,
        WXK_F6,
        WXK_F7,
        WXK_F8,
        WXK_F9,
        WXK_F10,
        WXK_F11,
        WXK_F12,
        WXK_F13,
        WXK_F14,
        WXK_F15,
        WXK_F16,
        WXK_F17,
        WXK_F18,
        WXK_F19,
        WXK_F20,
        WXK_F21,
        WXK_F22,
        WXK_F23,
        WXK_F24,
        WXK_NUMLOCK,
        WXK_SCROLL,
        WXK_PAGEUP,
        WXK_PAGEDOWN,
        WXK_NUMPAD_SPACE,
        WXK_NUMPAD_TAB,
        WXK_NUMPAD_ENTER,
        WXK_NUMPAD_F1,
        WXK_NUMPAD_F2,
        WXK_NUMPAD_F3,
        WXK_NUMPAD_F4,
        WXK_NUMPAD_HOME,
        WXK_NUMPAD_LEFT,
        WXK_NUMPAD_UP,
        WXK_NUMPAD_RIGHT,
        WXK_NUMPAD_DOWN,
        WXK_NUMPAD_PAGEUP,
        WXK_NUMPAD_PAGEDOWN,
        WXK_NUMPAD_END,
        WXK_NUMPAD_BEGIN,
        WXK_NUMPAD_INSERT,
        WXK_NUMPAD_DELETE,
        WXK_NUMPAD_EQUAL,
        WXK_NUMPAD_MULTIPLY,
        WXK_NUMPAD_ADD,
        WXK_NUMPAD_SEPARATOR,
        WXK_NUMPAD_SUBTRACT,
        WXK_NUMPAD_DECIMAL,
        WXK_NUMPAD_DIVIDE,

        WXK_WINDOWS_LEFT,
        WXK_WINDOWS_RIGHT,
        WXK_WINDOWS_MENU,
        WXK_COMMAND,

        /* Hardware-specific buttons */
        WXK_SPECIAL1 = 193,
        WXK_SPECIAL2,
        WXK_SPECIAL3,
        WXK_SPECIAL4,
        WXK_SPECIAL5,
        WXK_SPECIAL6,
        WXK_SPECIAL7,
        WXK_SPECIAL8,
        WXK_SPECIAL9,
        WXK_SPECIAL10,
        WXK_SPECIAL11,
        WXK_SPECIAL12,
        WXK_SPECIAL13,
        WXK_SPECIAL14,
        WXK_SPECIAL15,
        WXK_SPECIAL16,
        WXK_SPECIAL17,
        WXK_SPECIAL18,
        WXK_SPECIAL19,
        WXK_SPECIAL20,
    }

    /** <summary>This enumerates possible results of Dialog.ShowModal.</summary>*/
    [Flags]
    public enum ShowModalResult
    {
        /** <summary>YES button has been pressed.</summary>*/
        YES = 0x00000002,
        /** <summary>OK button has been pressed.</summary>*/
        OK = 0x00000004,
        /** <summary>NO button has been pressed.</summary>*/
        NO = 0x00000008,
        /** <summary>CANCEL button has been pressed.</summary>*/
        CANCEL = 0x00000010,
    }

    /** <summary>These are the flags that are used in instances of Window (and inheriting classes) to configure appearance and behaviour.
     * Some enumeration instances apply to only some classes of windows. 
     * The same enumeration value may be used for different enumeration instances.
     * This means in general that the enumeration isntances (sharing the same value)
     * shall be applied to different classes of windows.
     * 
     * Note, that flags are named similar to their origin in  wxWidgets but they do
     * not necessarily bear the same name. Reason: Better navigation with IntelliSence.
     * Example: You may type WindowStyles.BOR to navigate through all styles referring to
     * borders.</summary>*/
    [Flags]
    public enum WindowStyles : uint
    {
        /** <summary>An empty style definition.
         * This may be useful for some occasions as default argument.
         * It is simply an enumeration instance for zero.</summary>*/
        NO_STYLE = 0,

        /** <summary>Default border.
         * Applicable to all windows.</summary>*/
        BORDER_DEFAULT = 0x00000000,
        /** <summary>No border.
         * Overriding the default behaviour of the window. Applicable to all windows.</summary>*/
        BORDER_NONE = 0x00200000,
        /** <summary>Displays a border suitable for a static control.
         * Applicable to all windows but effect only on machines using OS Windows.</summary>*/
        BORDER_STATIC = 0x01000000,
        /** <summary>Displays a thin border around the window.
         * Applicable to all windows.</summary>*/
        BORDER_SIMPLE = 0x02000000,
        /** <summary>Displays a raised border.
         * Applicable to all windows.</summary>*/
        BORDER_RAISED = 0x04000000,
        /** <summary>Displays a sunken border.
         * Applicable to all windows.</summary>*/
        BORDER_SUNKEN = 0x08000000,
        /** <summary>Displays a double border.
         * Mac only. Applicable to all windows.
         *
         * This is \b deprecated. In fact, this is just another name
         * of the bit representing the <c>BORDER_THEME</c>.
         * </summary>
         */
        BORDER_DOUBLE = 0x10000000,
        /** <summary>Starting with wxWidgets 2.8.5, you can specify the <c>BORDER_THEME</c> style to have  wxWidgets use a themed border.
         * Using the default XP theme, this is a thin 1-pixel blue border, with an extra 1-pixel border in the window
         * client background colour (usually white) to separate the client area's scrollbars from the border.
         *
         * If you don't specify a border style for a wxTextCtrl in rich edit mode,  wxWidgets now gives the control themed
         * borders automatically, where previously they would take the Windows 95-style sunken border. Other native controls
         * such as <c>wx.TextCtrl</c> in non-rich edit mode, and wxComboBox, already paint themed borders where appropriate.
         * To use themed borders on other windows, such as <c>wx.Panel</c>, pass the <c>BORDER_THEME</c> style.
         *
         * Note that in  wxWidgets 2.9 and above, <c>BORDER_THEME</c> will be used on all platforms to indicate that there
         * should definitely be a border, whose style is determined by  wxWidgets for the current platform.
         *  wxWidgets  2.9 and above will also be better at determining whether there should be a themed border.
         * Because of the requirements of binary compatibility, this automatic border capability could not be put into
         *  wxWidgets 2.8 except for built-in, native controls. In 2.8, the border must be specified for custom controls
         * and windows.
         * </summary>
         */
        BORDER_THEME = 0x10000000,

        /** <summary>All bits defining the border of the window.</summary>*/
        BORDER_MASK = 0x1f200000,

        /** <summary>Use this to enable tab traversal for non-dialog windows.</summary>*/
        TAB_TRAVERSAL = 0x00080000,

        /** <summary>Now obsolete.
         * On Windows, this style used to disable repainting the window completely
         * when its size is changed. Since this behaviour is now the default,
         * the style is now obsolete and no longer has an effect.</summary>*/
        NO_FULL_REPAINT_ON_RESIZE = 0x00010000,

        /** <summary>Use this style to force a complete redraw of the window whenever it is resized instead of redrawing just the part of the window affected by resizing.
         * Note that this was the behaviour by default before 2.5.1 release and
         * that if you experience redraw problems with code which previously used
         * to work you may want to try this.
         * Currently this style applies on GTK+ 2 and Windows only, and full
         * repainting is always done on other platforms.</summary>*/
        FULL_REPAINT_ON_RESIZE = 0x00010000,

        /** <summary>Use this to indicate that the window wants to get all char/key events for all keys - even for keys like TAB or ENTER which are usually used for dialog navigation and which wouldn't be generated without this style.
         * If you need to use this style in order to get the arrows or etc., but
         * would still like to have normal keyboard navigation take place, you
         * should create and send a NavigationKeyEvent in response to the key events for Tab and Shift-Tab.</summary>*/
        WANTS_CHARS = 0x00040000,

        /** <summary>Use this style to enable a vertical scrollbar.</summary>*/
        VSCROLL = 0x80000000,
        /** <summary>Use this style to enable a horizontal scrollbar.</summary>*/
        HSCROLL = 0x40000000,
        /** <summary>If a window has scrollbars, disable them instead of hiding them when they are not needed (i.e. when the size of the window is big enough to not require the scrollbars to navigate it).
         * This style is currently only implemented for <c>wxMSW</c> and <c>wxUniversal</c>
         * and does nothing on the other platforms.</summary>*/
        ALWAYS_SHOW_SB = 0x00800000,

        /** <summary>Use this style to eliminate flicker caused by the background being repainted, then children being painted over them.
         * Windows only.</summary>*/
        CLIP_CHILDREN = 0x00400000,

        CLIP_SIBLINGS = 0x20000000,

        /** <summary>The window is transparent, that is, it will not receive paint events.
         * Windows only.</summary>*/
        TRANSPARENT_WINDOW = 0x00100000,

        /** <summary>Set this flag to create a special popup window:
         * it will be always shown on top of other windows, will capture the mouse
         * and will be dismissed when the mouse is clicked outside of it or if it
         * loses focus in any other way.</summary>*/
        POPUP_WINDOW = 0x00020000,

        /** <summary>A mask which can be used to filter (out) all wxWindow-specific styles.</summary>*/
        WINDOW_STYLE_MASK = VSCROLL | HSCROLL | BORDER_MASK | ALWAYS_SHOW_SB | CLIP_CHILDREN | CLIP_SIBLINGS
          | TRANSPARENT_WINDOW | TAB_TRAVERSAL | WANTS_CHARS | POPUP_WINDOW | FULL_REPAINT_ON_RESIZE | NO_FULL_REPAINT_ON_RESIZE,

        /** <summary>Puts a caption on the frame. 
         * Applicable to instances of Frame.</summary>*/
        CAPTION = 0x20000000,

        /** <summary>Comprises all those styles that apply to a frame by default.</summary>*/
        FRAME_DEFAULT_STYLE = SYSTEM_MENU | RESIZE_BORDER |
                                MINIMIZE_BOX | MAXIMIZE_BOX | CAPTION |
                                CLIP_CHILDREN | CLOSE_BOX,

        /** <summary>Comprises those styles that apply to dialogs by default.</summary>*/
        DIALOG_DEFAULT_STYLE = SYSTEM_MENU | CAPTION | CLOSE_BOX,

        /** <summary>Display the frame iconized (minimized).
         * Windows only. Applicable to top level windows.</summary>*/
        MINIMIZE = 0x4000,
        /** <summary>Displays a minimize box on the frame.
         * Applicable to top level windows.</summary>*/
        MINIMIZE_BOX = 0x00000400,
        /** <summary>Displays a close box on the frame.
         * Applicable to top level windows.</summary>*/
        CLOSE_BOX = 0x1000,
        /** <summary>Stay on top of all other windows.
         * Applicable to top level windows. Refer also to FRAME_FLOAT_ON_PARENT.</summary>*/
        STAY_ON_TOP = 0x8000,
        /** <summary>Displays the frame maximized.
         * Windows only.</summary>*/
        MAXIMIZE = 0x2000,
        /** <summary>Displays a maximize box on the frame.</summary>*/
        MAXIMIZE_BOX = 0x0200,
        /** <summary>Displays a resizeable border around the window.</summary>*/
        RESIZE_BORDER = 0x00000040,
        /** <summary>Displays a system menu.</summary>*/
        SYSTEM_MENU = 0x00000800,

        /** <summary>Creates an otherwise normal frame but it does not appear in the taskbar under Windows or GTK+
         * (note that it will minimize to the desktop window under Windows
         * which may seem strange to the users and thus it might be better to
         * use this style only without MINIMIZE_BOX style). In <c>wxGTK</c>, the
         * flag is respected only if GTK+ is at least version 2.2 and the
         * window manager supports <c>_NET_WM_STATE_SKIP_TASKBAR</c> hint. Has no
         * effect under other platforms.</summary>*/
        FRAME_NO_TASKBAR = 0x0002,
        /** <summary>Causes a frame with a small titlebar to be created;
         * the frame does not appear in the taskbar under Windows or GTK+.</summary>*/
        FRAME_TOOL_WINDOW = 0x0004,
        /** <summary>The frame will always be on top of its parent (unlike STAY_ON_TOP).
         * A frame created with this style must have a non-NULL parent.</summary>*/
        FRAME_FLOAT_ON_PARENT = 0x0008,

        /** <summary>Windows with this style are allowed to have their shape changed with the SetShape method.</summary>*/
        FRAME_SHAPED = 0x0010,

        // wxNO_3D omitted since deprecated

        /** <summary>By default, a dialog created with a <c>null</c> parent window will be given the application's top level window as parent.
         * Use this style to prevent this from happening and create an orphan
         * dialog. This is not recommended for modal dialogs.</summary>*/
        DIALOG_NO_PARENT = 0x0001,

        /** <summary>Show an YES button.
         * This shall be used together either with DIALOG_NO or DIALOG_CANCEL.
         * There is a wxWidgets assertion.
         * </summary>*/
        DIALOG_YES = 0x00000002,
        /** <summary>Show an OK button.</summary>*/
        DIALOG_OK = 0x00000004,
        /** <summary>Show an NO button.
         * This shall be used together either with DIALOG_YES.
         * There is a wxWidgets assertion.
         * </summary>*/
        DIALOG_NO = 0x00000008,
        /** <summary>Show an CANCEL button.</summary>*/
        DIALOG_CANCEL = 0x00000010,
        /** <summary>Show YES and NO button.</summary>*/
        DIALOG_YES_NO = (DIALOG_YES | DIALOG_NO),

        /** <summary>Used with <c>DIALOG_YES</c>, makes YES button the default - which is the default behaviour.</summary>*/
        DIALOG_YES_DEFAULT = 0x00000000,
        /** <summary>Used with <c>DIALOG_NO</c>, makes NO button the default.</summary>*/
        DIALOG_NO_DEFAULT = 0x00000080,

        /** <summary>Centre the message.
         * Applicable to message dialog and certain standard dialogs.
         * Not Windows.</summary>*/
        DIALOG_CENTRE = 0x001,

        /** <summary>Refer to DIALOG_CENTRE().</summary>*/
        DIALOG_CENTER=DIALOG_CENTRE,

        /** <summary>Shows an exclamation mark icon.
         * An icon for some standard dialogs.</summary>*/
        ICON_EXCLAMATION = 0x00000100,
        /** <summary>Shows an error icon. 
         * An icon for some standard dialogs.</summary>*/
        ICON_HAND = 0x00000200,
        /** <summary>Shows an exclamation mark icon.
         * An icon for some standard dialogs.</summary>*/
        ICON_WARNING = ICON_EXCLAMATION,
        /** <summary>Shows an error icon. 
         * An icon for some standard dialogs.</summary>*/
        ICON_ERROR = ICON_HAND,
        /** <summary>Shows a question mark icon. 
         * An icon for some standard dialogs.</summary>*/
        ICON_QUESTION = 0x00000400,
        /** <summary>An icon for some standard dialogs.</summary>*/
        ICON_INFORMATION = 0x00000800,
        /** <summary>An icon for some standard dialogs.</summary>*/
        ICON_STOP = ICON_HAND,
        /** <summary>An icon for some standard dialogs.</summary>*/
        ICON_ASTERISK = ICON_INFORMATION,
        /** <summary>A bit mask for filtering those styles referring to icons.
         * An icon for some standard dialogs.</summary>*/
        ICON_MASK = (0x00000100 | 0x00000200 | 0x00000400 | 0x00000800),
        

        /** <summary> For instances of wx.TextCtrtl.</summary>*/
        TE_NO_VSCROLL = 0x0002,

        /** <summary> For instances of wx.TextCtrtl.</summary>*/
        TE_AUTO_SCROLL = 0x0008,

        /** <summary>The text will not be user-editable. 
         * For instances of wx.TextCtrtl.</summary>*/
        TE_READONLY = 0x0010,

        /** <summary>The text control allows multiple lines. 
         * For instances of wx.TextCtrtl.</summary>*/
        TE_MULTILINE        = 0x0020,

        /** <summary>The control will receive <c>wxEVT_CHAR</c> events for TAB pressed - normally, TAB is used for passing to the next control in a dialog instead.
         * For the control created with this style, you can still use
         * Ctrl-Enter to pass to the next control from the keyboard. 
         * For instances of wx.TextCtrtl.</summary>*/
        TE_PROCESS_TAB      = 0x0040,

        /** <summary>The text in the control will be left-justified (default). 
         * For instances of wx.TextCtrtl.</summary>*/
        TE_LEFT             = 0x0000,

        /** <summary>The text in the control will be centered (currently <c>wxMSW</c> and <c>wxGTK2</c> only). 
         * For instances of wx.TextCtrtl.</summary>*/
        TE_CENTER           = Alignment.wxALIGN_CENTER,

        /** <summary>The text in the control will be right-justified (currently wxMSW and wxGTK2 only). 
         * For instances of wx.TextCtrtl.</summary>*/
        TE_RIGHT = Alignment.wxALIGN_RIGHT,

        /** <summary>Use rich text control under Win32, this allows to have more than 64KB of text in the control even under Win9x.
         * This style is ignored under other platforms. 
         * For instances of wx.TextCtrtl.</summary>*/
        TE_RICH             = 0x0080,

        /** <summary>The control will generate the event <c>wxEVT_COMMAND_TEXT_ENTER</c>
         * (otherwise pressing Enter key is either processed internally by
         * the control or used for navigation between dialog controls). 
         * For instances of wx.TextCtrl, wx.ComboCtrl.</summary>*/
        TE_PROCESS_ENTER    = 0x0400,

        /** <summary>The text will be echoed as asterisks. 
         * For instances of wx.TextCtrtl.</summary>*/
        TE_PASSWORD         = 0x0800,

        /** <summary>Highlight the URLs and generate the TextUrlEvents when mouse events occur over them.
         * This style is only supported for <c>TE_RICH</c> Win32 and multi-line
         * <c>wxGTK2</c> text controls. 
         * For instances of wx.TextCtrtl.</summary>*/
        TE_AUTO_URL         = 0x1000,

        /** <summary>Show selection even if not focussed.
         * By default, the Windows text control doesn't show the selection
         * when it doesn't have focus - use this style to force it to always
         * show it. It doesn't do anything under other platforms. 
         * For instances of wx.TextCtrtl.</summary>*/
        TE_NOHIDESEL        = 0x2000,

        /** <summary>Tells a wx.TextCtrl to wrap lines that are too long to be displayed in the control.
         * This is another name for the standard behaviour. Refer also to <c>TE_BESTWRAP</c>.
         * </summary>
         */
        TE_LINEWRAP = TE_BESTWRAP,
        /** <summary>Same as <c>HSCROLL</c> style: don't wrap at all, show horizontal scrollbar instead.
         * For instances of wx.TextCtrtl.
         * </summary>
         */
        TE_DONTWRAP         = wx.WindowStyles.HSCROLL,
        /** <summary>Wrap the lines too long to be shown entirely at any position (<c>wxUniv</c> and <c>wxGTK2</c> only). 
         * For instances of wx.TextCtrtl.
         * </summary>
         */
        TE_CHARWRAP = 0x4000,
        /** <summary>Wrap the lines too long to be shown entirely at word boundaries (<c>wxUniv</c> and <c>wxGTK2</c> only). 
         * For instances of wx.TextCtrtl.
         * </summary>
         */
        TE_WORDWRAP = 0x0001,
        /** <summary>Wrap the lines at word boundaries or at any other character if there are words longer than the window width (this is the default). 
         * For instances of wx.TextCtrtl.
         * </summary>
         */
        TE_BESTWRAP = 0,
        /** <summary>Use rich text control version 2.0 or 3.0 under Win32.
         * This style is ignored under other platforms.
         * Style flag for instances of wx.TextCtrl.
         * </summary>
         */
        TE_RICH2 = 0x8000,

        /** <summary>Default style bits for instances of wx.TextEntryDialog.
         * </summary>
         */
        TE_DIALOG_STYLE = DIALOG_OK | DIALOG_CANCEL | DIALOG_CENTRE,


        /** <summary> Applicable to wx.HtmlWindow.</summary>*/
        HW_SCROLLBAR_NEVER   = 0x0002,
        /** <summary> Applicable to wx.HtmlWindow.</summary>*/
        HW_SCROLLBAR_AUTO = 0x0004,
        /** <summary> Applicable to wx.HtmlWindow.</summary>*/
        HW_NO_SELECTION = 0x0008,

        /** <summary>A style for wx.SplahScreen.</summary>*/
        SPLASH_CENTRE_ON_PARENT   = 0x01,
        /** <summary>A style for wx.SplahScreen.</summary>*/
        SPLASH_CENTRE_ON_SCREEN = 0x02,
        /** <summary>A style for wx.SplahScreen.</summary>*/
        SPLASH_NO_CENTRE = 0x00,
        /** <summary>A style for wx.SplahScreen.</summary>*/
        SPLASH_TIMEOUT = 0x04,
        /** <summary>A style for wx.SplahScreen.</summary>*/
        SPLASH_NO_TIMEOUT = 0x00,
        /** <summary>The bits defining the default style for wx.SplahScreen.</summary>*/
        SPLASH_DEFAULT = BORDER_SIMPLE | FRAME_NO_TASKBAR | STAY_ON_TOP,

        /** <summary>Style for wx.ListBox.
         * </summary>*/
        LB_SORT             = 0x0010,
        /** <summary>Style for wx.ListBox.</summary>*/
        LB_SINGLE = 0x0020,
        /** <summary>Style for wx.ListBox.</summary>*/
        LB_MULTIPLE = 0x0040,
        /** <summary>Style for wx.ListBox.</summary>*/
        LB_EXTENDED = 0x0080,
        /** <summary>Style for wx.ListBox.</summary>*/
        LB_OWNERDRAW = 0x0100,
        /** <summary>Style for wx.ListBox.</summary>*/
        LB_NEED_SB = 0x0200,
        /** <summary>Style for wx.ListBox.</summary>*/
        LB_ALWAYS_SB = 0x0400,
        /** <summary>Style for wx.ListBox.</summary>*/
        LB_HSCROLL = HSCROLL,
        /** <summary>Style for wx.ListBox.</summary>*/
        LB_INT_HEIGHT = 0x0800,

        /** <summary>Draws light vertical rules between columns in report mode.  
         * Style for wx.ListCtrl.</summary>*/
        LC_VRULES           = 0x0001,
        /** <summary>Draws light horizontal rules between rows in report mode. 
         * Style for wx.ListCtrl.</summary>*/
        LC_HRULES = 0x0002,

        /** <summary>Large icon view, with optional labels. 
         * Style for wx.ListCtrl.</summary>*/
        LC_ICON = 0x0004,
        /** <summary>Small icon view, with optional labels. 
         * Style for wx.ListCtrl.</summary>*/
        LC_SMALL_ICON = 0x0008,
        /** <summary>Multicolumn list view, with optional small icons.
         * Columns are computed automatically, i.e. you don't set columns as in wx.WindowStyles.LC_REPORT.
         * In other words, the list wraps, unlike a wx.ListBox.
         * Style for wx.ListCtrl.</summary>*/
        LC_LIST = 0x0010,
        /** <summary>Single or multicolumn report view, with optional header. 
         * Style for wx.ListCtrl.</summary>*/
        LC_REPORT = 0x0020,

        /** <summary>Icons align to the top. Win32 default, Win32 only. 
         * Style for wx.ListCtrl.</summary>*/
        LC_ALIGN_TOP = 0x0040,
        /** <summary>Icons align to the left. 
         * Style for wx.ListCtrl.</summary>*/
        LC_ALIGN_LEFT = 0x0080,
        /** <summary>Icons arrange themselves. Win32 only.
         * Style for wx.ListCtrl.</summary>*/
        LC_AUTO_ARRANGE = 0x0100,
        /** <summary>The application provides items text on demand.
         * May only be used with wx.WindowsStyles.LC_REPORT. 
         * Style for wx.ListCtrl.</summary>*/
        LC_VIRTUAL = 0x0200,
        /** <summary>Labels are editable: the application will be notified when editing starts. 
         * Style for wx.ListCtrl.</summary>*/
        LC_EDIT_LABELS = 0x0400,
        /** <summary>No header in report mode. 
         * Style for wx.ListCtrl.</summary>*/
        LC_NO_HEADER = 0x0800,
        /** <summary> Style for wx.ListCtrl.</summary>*/
        LC_NO_SORT_HEADER = 0x1000,
        /** <summary>Single selection (default is multiple). 
         * Style for wx.ListCtrl.</summary>*/
        LC_SINGLE_SEL = 0x2000,
        /** <summary>Sort in ascending order (must still supply a comparison callback in wx.ListCtrl.SortItems()). 
         * Style for wx.ListCtrl.</summary>*/
        LC_SORT_ASCENDING = 0x4000,
        /** <summary>Sort in descending order (must still supply a comparison callback in wx.ListCtrl.SortItems). 
         * Style for wx.ListCtrl.</summary>*/
        LC_SORT_DESCENDING = 0x8000,

        /** <summary>Mask of style bits defining the kind of presentation in instances of wx.ListCtrl.
         * Style for wx.ListCtrl.</summary>*/
        LC_MASK_TYPE = (LC_ICON | LC_SMALL_ICON | LC_LIST | LC_REPORT),
        /** <summary>Mask of style bits referring to the alignment in instances of wx.ListCtrl.
         * Style for wx.ListCtrl.</summary>*/
        LC_MASK_ALIGN = (LC_ALIGN_TOP | LC_ALIGN_LEFT),
        /** <summary>Mask of styles referring to sorting instances of wx.ListCtrl.
         * Style for wx.ListCtrl.</summary>*/
        LC_MASK_SORT = (LC_SORT_ASCENDING | LC_SORT_DESCENDING),


        /** <summary>Default style bits for instances of wx.SingleChoiceDialog.</summary>*/
        CHOICEDLG_STYLE = DIALOG_DEFAULT_STYLE | RESIZE_BORDER | DIALOG_OK | DIALOG_CANCEL | DIALOG_CENTRE,

        /** <summary>Default style bits for instances of wx.MDIParentFrame.</summary>*/
        MDI_FRAME_DEFAULT_STYLE = FRAME_DEFAULT_STYLE | VSCROLL | HSCROLL,

        /** <summary> Style for wx.ToolBar, wx.ScrollBar, wx.Slider, wx.RadioBox, wx.Gauge wx.SpinCtrl and wx.SpinButton</summary>*/
        ORIENT_HORIZONTAL = (uint)Orientation.wxHORIZONTAL,
        /** <summary>Style for wx.ToolBar, wx.ScrollBar, wx.Slider, wx.RadioBox, wx.Gauge wx.SpinCtrl and wx.SpinButton</summary>*/
        ORIENT_VERTICAL = (uint)Orientation.wxVERTICAL,
        /** <summary>Style for wx.ToolBar.</summary>*/
        TB_3DBUTTONS = 0x0010,
        /** <summary>Style for wx.ToolBar.</summary>*/
        TB_FLAT = 0x0020,
        /** <summary>Style for wx.ToolBar.</summary>*/
        TB_DOCKABLE = 0x0040,
        /** <summary>Style for wx.ToolBar.</summary>*/
        TB_NOICONS = 0x0080,
        /** <summary>Style for wx.ToolBar.</summary>*/
        TB_TEXT = 0x0100,
        /** <summary>Style for wx.ToolBar.</summary>*/
        TB_NODIVIDER = 0x0200,
        /** <summary>Style for wx.ToolBar.</summary>*/
        TB_NOALIGN = 0x0400,

        /** <summary>Style for wx.SashWindow.</summary>*/
        SW_NOBORDER	= 0x0000,
        /** <summary>Style for wx.SashWindow.</summary>*/
        SW_BORDER = 0x0020,
        /** <summary>Style for wx.SashWindow.</summary>*/
        SW_3DSASH = 0x0040,
        /** <summary>Style for wx.SashWindow.</summary>*/
        SW_3DBORDER = 0x0080,
        /** <summary>Style for wx.SashWindow.</summary>*/
        SW_3D = SW_3DSASH | SW_3DBORDER,

        /** <summary> Style for wx.Slider.</summary>*/
        SL_NOTIFY_DRAG = 0x0000,
        /** <summary> Style for wx.Slider.</summary>*/
        SL_TICKS = 0x0010,
        /** <summary> Style for wx.Slider.</summary>*/
        SL_AUTOTICKS = SL_TICKS,
        /** <summary> Style for wx.Slider.</summary>*/
        SL_LABELS = 0x0020,
        /** <summary> Style for wx.Slider.</summary>*/
        SL_LEFT = 0x0040,
        /** <summary> Style for wx.Slider.</summary>*/
        SL_TOP = 0x0080,
        /** <summary> Style for wx.Slider.</summary>*/
        SL_RIGHT = 0x0100,
        /** <summary> Style for wx.Slider.</summary>*/
        SL_BOTTOM = 0x0200,
        /** <summary> Style for wx.Slider.</summary>*/
        SL_BOTH = 0x0400,
        /** <summary> Style for wx.Slider.</summary>*/
        SL_SELRANGE = 0x0800,

        /** <summary> Style for wx.RadioBox.</summary>*/
        RA_LEFTTORIGHT    = 0x0001,
        /** <summary> Style for wx.RadioBox.</summary>*/
        RA_TOPTOBOTTOM = 0x0002,
        /** <summary> Style for wx.RadioBox.</summary>*/
        RA_SPECIFY_COLS = (uint)Orientation.wxHORIZONTAL,
        /** <summary> Style for wx.RadioBox.</summary>*/
        RA_SPECIFY_ROWS = (uint)Orientation.wxVERTICAL,

        /** <summary>The user can use arrow keys to change the value. 
         * Style for wx.SpinCtrl and wx.SpinButton.</summary>*/
        SP_ARROW_KEYS       = 0x1000,
        /** <summary>The value wraps at the minimum and maximum. 
         * Style for wx.SpinCtrl and wx.SpinButton.</summary>*/
        SP_WRAP             = 0x2000,

        /** <summary>A style for the wx.SplitterWindow turning on 3D effect for borders.</summary>*/
        SP_3DBORDER		= 0x00000200,
        /** <summary>A style for the wx.SplitterWindow.</summary>*/
        SP_LIVE_UPDATE = 0x00000080,
        /** <summary>A style for the wx.SplitterWindow turning on 3D effect for borders and sash.</summary>*/
        SP_3D = (SP_3DBORDER | SP_3DSASH),
        /** <summary>A style for the wx.SplitterWindow turning on 3D effect for the sash.
         * <c>SP_3D</c> combines this with  <c>SP_3BORDER</c> to turn on both 3D effects.</summary>*/
        SP_3DSASH = 0x00000100,

        /** <summary> Style for wx.Gauge.</summary>*/
        GA_PROGRESSBAR = 0x0010,
        /** <summary> Style for wx.Gauge.</summary>*/
		GA_SMOOTH           = 0x0020,

        /** <summary> Style for wx.CalendarCtrl.</summary>*/
        CAL_SUNDAY_FIRST               = 0x0000,
        /** <summary> Style for wx.CalendarCtrl.</summary>*/
        CAL_MONDAY_FIRST = 0x0001,
        /** <summary> Style for wx.CalendarCtrl.</summary>*/
        CAL_SHOW_HOLIDAYS = 0x0002,
        /** <summary> Style for wx.CalendarCtrl.</summary>*/
        CAL_NO_YEAR_CHANGE = 0x0004,
        /** <summary> Style for wx.CalendarCtrl.</summary>*/
        CAL_NO_MONTH_CHANGE = 0x000c,
        /** <summary> Style for wx.CalendarCtrl.</summary>*/
        CAL_SEQUENTIAL_MONTH_SELECTION = 0x0010,
        /** <summary> Style for wx.CalendarCtrl.</summary>*/
        CAL_SHOW_SURROUNDING_WEEKS = 0x0020,

        /** <summary> Style flag for wx.ProgressDialog.</summary>*/
        PD_CAN_ABORT      = 0x0001,
        /** <summary> Style flag for wx.ProgressDialog.</summary>*/
        PD_APP_MODAL = 0x0002,
        /** <summary> Style flag for wx.ProgressDialog.</summary>*/
        PD_AUTO_HIDE = 0x0004,
        /** <summary> Style flag for wx.ProgressDialog.</summary>*/
        PD_ELAPSED_TIME = 0x0008,
        /** <summary> Style flag for wx.ProgressDialog.</summary>*/
        PD_ESTIMATED_TIME = 0x0010,
        /** <summary> Style flag for wx.ProgressDialog.</summary>*/
        PD_REMAINING_TIME = 0x0040,

        /** <summary> Style flag for wx.RadioButton.</summary>*/
        RB_GROUP     = 0x0004,
        /** <summary> Style flag for wx.RadioButton.</summary>*/
        RB_SINGLE = 0x0008,

        /** <summary> Style flag fow wx.Notebook.</summary>*/
		NB_FIXEDWIDTH       = 0x0010,
        /** <summary> Style flag fow wx.Notebook.</summary>*/
        NB_TOP = 0x0000,
        /** <summary> Style flag fow wx.Notebook.</summary>*/
        NB_LEFT = 0x0020,
        /** <summary> Style flag fow wx.Notebook.</summary>*/
        NB_RIGHT = 0x0040,
        /** <summary> Style flag fow wx.Notebook.</summary>*/
        NB_BOTTOM = 0x0080,
        /** <summary> Style flag fow wx.Notebook.</summary>*/
        NB_MULTILINE = 0x0100,

        /** <summary>For convenience to document that no buttons are to be drawn. 
         * Style for wx.TreeCtrl.</summary>*/
		TR_NO_BUTTONS                = 0x0000,
        /** <summary>Use this style to show + and - buttons to the left of parent items. 
         * Style for wx.TreeCtrl.</summary>*/
        TR_HAS_BUTTONS = 0x0001,
        /** <summary> Style for wx.TreeCtrl.</summary>*/
        TR_TWIST_BUTTONS = 0x0010,
        /** <summary>Use this style to hide vertical level connectors. 
         * Style for wx.TreeCtrl.</summary>*/
        TR_NO_LINES = 0x0004,
        /** <summary>Use this style to show lines between root nodes.
         * Only applicable if <c>TR_HIDE_ROOT</c> is set and <c>TR_NO_LINES</c> is not set. 
         * Style for wx.TreeCtrl.</summary>*/
        TR_LINES_AT_ROOT = 0x0008,
        /** <summary> Deprecated style for wx.TreeCtrl.</summary>*/
        TR_MAC_BUTTONS = 0,
        /** <summary> Deprecated style for wx.TreeCtrl.</summary>*/
        TR_AQUA_BUTTONS = 0,

        /** <summary> Style for wx.TreeCtrl.
         * This defines single selection and is standard behaviour.</summary>*/
        TR_SINGLE = 0x0000,
        /** <summary>Use this style to allow a range of items to be selected.
         * If a second range is selected, the current range, if any, is deselected. 
         * Style for wx.TreeCtrl.</summary>*/
        TR_MULTIPLE = 0x0020,
        /** <summary>Use this style to allow disjoint items to be selected.
         * (Only partially implemented; may not work in all cases.) 
         * Style for wx.TreeCtrl.</summary>*/
        TR_EXTENDED = 0x0040,
        /** <summary>Use this style to have the background colour and the selection highlight extend over the entire horizontal row of the tree control window.
         * (This flag is ignored under Windows unless you specify <c>TR_NO_LINES</c> as well.) 
         * Style for wx.TreeCtrl.</summary>*/
        TR_FULL_ROW_HIGHLIGHT = 0x2000,

        /** <summary>Use this style if you wish the user to be able to edit labels in the tree control. 
         * Style for wx.TreeCtrl.
         *</summary>*/
        TR_EDIT_LABELS = 0x0200,
        /** <summary>Use this style to draw a contrasting border between displayed rows. 
         * Style for wx.TreeCtrl.</summary>*/
        TR_ROW_LINES = 0x0400,
        /** <summary>Use this style to suppress the display of the root node, effectively causing the first-level nodes to appear as a series of root nodes. 
         * Style for wx.TreeCtrl.</summary>*/
        TR_HIDE_ROOT = 0x0800,
        /** <summary>Use this style to cause row heights to be just big enough to fit the content.
         * If not set, all rows use the largest row height.
         * Style for wx.TreeCtrl. The default is that this flag is unset. Generic only.</summary>*/
        TR_HAS_VARIABLE_ROW_HEIGHT = 0x0080,

        /** <summary>Style for wx.FontCtrl.
         * Turns on text edit field for point size.</summary>*/
        FONTCTRL_EDIT_POINT_SIZE = 0x0001,
        /** <summary>Style for wx.FontCtrl.
         * Turns on text edit field for font family.</summary>*/
        FONTCTRL_EDIT_FONT_FAMILY = 0x0002,
        /** <summary>Style for wx.FontCtrl.
         * Turns on text edit field for font weight.</summary>*/
        FONTCTRL_EDIT_FONT_WEIGHT = 0x0004,
        /** <summary>Style for wx.FontCtrl.
         * Turns on text edit field for font style.</summary>*/
        FONTCTRL_EDIT_FONT_STYLE = 0x0008,
        /** <summary>Style for wx.FontCtrl.
         * Turns on text edit field for text colour.</summary>*/
        FONTCTRL_EDIT_FONT_COLOUR = 0x0010,
        /** <summary>Style for wx.FontCtrl.
         * Turns on all edit fields.</summary>*/
        FONTCTRL_EDIT_ALL = 0x001f,

        /** <summary>This is a dialog requesting a file to be opened.
         * Style for wx.FileDialog and wx.FileSelector</summary>
         */
        FD_OPEN              = 0x0001,
        /** <summary>This is a save dialog. 
         * Style for wx.FileDialog and wx.FileSelector</summary>
         */
        FD_SAVE = 0x0002,
        /** <summary>For save dialog only: prompt for a confirmation if a file will be overwritten. 
         * Style for wx.FileDialog and wx.FileSelector.</summary>
         */
        FD_OVERWRITE_PROMPT = 0x0004,
        /** <summary>Do not display the checkbox to toggle display of read-only files.
         * Deprecated in 2.6; the checkbox is never shown.
         * Style for wx.FileDialog and wx.FileSelector.</summary>
         */
        FD_HIDE_READONLY = 0x0008,
        /** <summary>The user may only select files that actually exist. 
         * Style for wx.FileDialog and wx.FileSelector.</summary>
         */
        FD_FILE_MUST_EXIST = 0x0010,
        /** <summary>For open dialog only: allows selecting multiple files. 
         * Style for wx.FileDialog and wx.FileSelector.
         * </summary>
         */
        FD_MULTIPLE = 0x0020,
        /** <summary>
         * Show the preview of the selected files (currently only supported by wxGTK using GTK+ 2.4 or later). 
         * Style for wx.FileDialog and wx.FileSelector.
         * </summary>
         */
        FD_PREVIEW           = 0x0100,


        /** <summary>Two different meanings in wx.FileDialog and wx.FileSeletor.
         * <list type="table">
         * <item><term>wx.FileDialog</term><description> Change the current working directory to the directory where the file(s) chosen by the user are.</description></item> 
         * <item><term>wx.FileSelector</term><description> Select a directory rather than a file.</description></item>
         * </list>
         * </summary>
         */
        FD_CHANGE_DIR = 0x0040,

        /** <summary>Inititializes replace dialog (otherwise find dialog).
         * Style flag for wx.FindReplaceDialog.</summary>*/
        FR_REPLACEDIALOG = 1,
        /** <summary>Don't allow changing the search direction.
         * Style flag for wx.FindReplaceDialog.
         * If this is set, controls for changing search direction will be disabled.</summary>*/
        FR_NOUPDOWN = 2,
        /** <summary>Don't allow case sensitive searching.
         * Style flag for wx.FindReplaceDialog.
         * If this is set, controls for changing relevance of letter case will be disabled.</summary>*/
        FR_NOMATCHCASE = 4,
        /** <summary>don't allow whole word searching 
         * Style flag for wx.FindReplaceDialog.
         * If this is set, controls for defining search for whole words only will be disabled.</summary>*/
        FR_NOWHOLEWORD = 8,

        /** <summary>Style for wx.Choice, wx.ComboBox etc.</summary>*/
		CB_SIMPLE           = 0x0004,

        /** <summary>Style for wx.Choice, wx.ComboBox, wx.ComboCtrl etc.
         * Sorts the entries in the list alphabetically.</summary>*/
        CB_SORT = 0x0008,

        /** <summary>Style for wx.Choice, wx.ComboBox, wx.ComboCtrl etc.
         * Text will not be editable.</summary>*/
        CB_READONLY = 0x0010,

        /** <summary>Style for wx.Choice, wx.ComboBox etc.</summary>*/
        CB_DROPDOWN = 0x0020,

        /** <summary>Style for wx.ComboCtrl: Button is preferred outside the border (GTK style).</summary>*/
        CC_BUTTON_OUTSIDE_BORDER = 0x0001,

        /** <summary>Style for wx.ComboCtrl: Show popup on mouse up instead of mouse down (which is the Windows style)</summary>*/
        CC_POPUP_ON_MOUSE_UP = 0x0002,

        /** <summary>Style for wx.ComboCtrl: All text is not automatically selected on click</summary>*/
        CC_NO_TEXT_AUTO_SELECT = 0x0004,


        /** <summary>Style flag for static text and wx.StatusBar. Static text fields also use alignment flags.</summary>*/
        ST_NO_AUTORESIZE = 0x0001,

        /** <summary>Style flag for wx.StatusBar.</summary>*/
		ST_SIZEGRIP         = 0x0010,
		
		/** <summary>Style flag for wx.StatusBar.</summary>*/
		SB_NORMAL	= 0x000,
		/** <summary>Style flag for wx.StatusBar.</summary>*/
		SB_FLAT	= 0x001,
		/** <summary>Style flag for wx.StatusBar.</summary>*/
		SB_RAISED	= 0x002,

        /** <summary>Flags for alignment are also used with wx.StaticText.</summary>*/
        ALIGN_LEFT = 0,
        /** <summary>Flags for alignment are also used with wx.StaticText.</summary>*/
        ALIGN_RIGHT = 0x0200,
        /** <summary>Flags for alignment are also used with wx.StaticText.</summary>*/
        ALIGN_CENTRE = 0x0900,
        /** <summary>Flags for alignment are also used with wx.StaticText.</summary>*/
        ALIGN_CENTER = ALIGN_CENTRE,

        /** <summary>Style flag for wx.Button and wx.BitmapButton.</summary>*/
		BU_LEFT          =  0x0040,
        /** <summary>Style flag for wx.Button and wx.BitmapButton.</summary>*/
        BU_TOP = 0x0080,
        /** <summary>Style flag for wx.Button and wx.BitmapButton.</summary>*/
        BU_RIGHT = 0x0100,
        /** <summary>Style flag for wx.Button and wx.BitmapButton.</summary>*/
        BU_BOTTOM = 0x0200,
        /** <summary>Style flag for wx.Button and wx.BitmapButton.</summary>*/
        BU_EXACTFIT = 0x0001,


        /** <summary>Style flag for instances of wx.BitmapButton.</summary>*/
        BU_AUTODRAW      =  0x0004,

        /** <summary>This defines the <c>wx.GridSelectionMode</c> of a wx.Grid.</summary>*/
        GRID_SELECT_CELLS=0,
        /** <summary>This defines the <c>wx.GridSelectionMode</c> of a wx.Grid.</summary>*/
        GRID_SELECT_ROWS = 1,
        /** <summary>This defines the <c>wx.GridSelectionMode</c> of a wx.Grid.</summary>*/
        GRID_SELECT_COLUMNS = 2,

        /** <summary>Specifies that a generic form will not be user-editable. 
         * wx.GenericForm.GenericFormPanel.</summary>*/
        GENERICFORM_READONLY = 0x0010,

        /** <summary>wx.DatePickerCtrl style.
         * Default style on this platform, either <c>DP_SPIN</c> or <c>DP_DROPDOWN</c>.
         * </summary>
         */
        DP_DEFAULT = 0,

        /** <summary>wx.DatePickerCtrl style.
         *  A spin control-like date picker (not supported in generic version)
         *  </summary>
         */
        DP_SPIN = 1,

        /** <summary>wx.DatePickerCtrl style.
         *  A combobox-like date picker (not supported in mac version)
         *  </summary>
         */
        DP_DROPDOWN = 2,

        /** <summary>wx.DatePickerCtrl style.
         *  Always show century in the default date display (otherwise it depends on
         * the system date format which may include the century or not)
         * </summary>
         */
        DP_SHOWCENTURY = 4,

        /** <summary>wx.DatePickerCtrl style.
         *  Allow not having any valid date in the control (by default it always has
         * some date, today initially if no valid date specified in ctor)
         * </summary>
         */
        DP_ALLOWNONE = 8,

        /** <summary>wx.ColourPickerCtrl style.
         * The default style: 0.
         * </summary>
         */
        CLRP_DEFAULT_STYLE = 0,

        /** <summary>wx.ColourPickerCtrl style.
         * Creates a text control to the left of the picker button which is completely managed by the wx.ColourPickerCtrl
         * and which can be used by the user to specify a colour (see <c>SetColour</c>).
         * The text control is automatically synchronized with button's value.
         * </summary>
         */
        CLRP_USE_TEXTCTRL = 2,

        /** <summary>wx.ColourPickerCtrl style.
         * Shows the colour in HTML form (AABBCC) as colour button label (instead of no label at all).
         * </summary>
         */
        CLRP_SHOW_LABEL = 8,

        /** <summary>wx.FontPickerCtrl style.
         * Keeps the label of the button updated with the fontface name and font size.
         * E.g. choosing "Times New Roman bold, italic with size 10" from the fontdialog,
         * updates the button label (overwriting any previous label)
         * with the "Times New Roman, 10" text (only fontface + fontsize is displayed
         * to avoid extralong labels).
         * </summary>
         */
        FNTP_FONTDESC_AS_LABEL = 8,

        /** <summary>wx.FontPickerCtrl style.
         * Uses the currently selected font to draw the label of the button.</summary>*/
        FNTP_USEFONT_FOR_LABEL = 0x0010,

        /** <summary>wx.FontPickerCtrl style.
         * Creates a text control to the left of the picker button which is completely managed by the wx.FontPickerCtrl
         * and which can be used by the user to specify a font.
         * The text control is automatically synchronized with button's value.</summary>*/
        FNTP_USE_TEXTCTRL = 2,

        /** <summary>Default style for wx.FontPickerCtrl.
         * Currently <c>FNTP_FONTDESC_AS_LABEL</c>|FNTP_USEFONT_FOR_LABEL, i.e. if <c>FNTP_USE_TEXTCTRL</c> is active,
         * then use a textual description of the font as label and display it in the selected font.</summary>*/
        FNTP_DEFAULT_STYLE = (FNTP_FONTDESC_AS_LABEL|FNTP_USEFONT_FOR_LABEL),

        /// <summary>
        /// Equivalent to a combination of DEFAULT_DIALOG_STYLE and RESIZE_BORDER (the last one is not used under wxWinCE).
        /// </summary>
        DD_DEFAULT_STYLE = DIALOG_DEFAULT_STYLE | RESIZE_BORDER,

        /// <summary>
        /// The dialog will allow the user to choose only an existing folder. When this style is not given, a "Create new directory"
        /// button is added to the dialog (on Windows) or some other way is provided to the user to type the name of a new folder.
        /// </summary>
        DD_DIR_MUST_EXIST = 0x0200,

        /// <summary>
        /// Change the current working directory to the directory chosen by the user.
        /// </summary>
        DD_CHANGE_DIR = 0x0100,

        /// <summary>
        /// Create a 2-state checkbox. This is the default.  
        /// </summary>
        CHK_2STATE = 0x0000,

        /// <summary>
        ///   Create a 3-state checkbox. Not implemented in wxMGL, wxOS2 and wxGTK built against GTK+ 1.2.  
        /// </summary>
        CHK_3STATE = 0x1000,

        /// <summary>
        /// By default a user can't set a 3-state checkbox to the third state. It can only be done from code. Using this flags allows the user to set the checkbox to the third state by clicking.  
        /// </summary>
        CHK_ALLOW_3RD_STATE_FOR_USER = 0x2000,

        /// <summary>
        ///   Makes the text appear on the left of the checkbox.  
        /// </summary>
        CHK_ALIGN_RIGHT=Alignment.wxALIGN_RIGHT,

    }

    /** <summary>Represent a direction.
     * Used to specify dynamic layouts.</summary>*/
    [Flags]
	public enum Direction 
	{
		wxLEFT    = 0x0010,
		wxRIGHT   = 0x0020,
		wxUP      = 0x0040,
		wxDOWN    = 0x0080,
		wxTOP     = wxUP,
		wxBOTTOM  = wxDOWN,
		wxNORTH   = wxUP,
		wxSOUTH   = wxDOWN,
		wxWEST    = wxLEFT,
		wxEAST    = wxRIGHT,
		wxALL     = (wxUP | wxDOWN | wxRIGHT | wxLEFT),
	}

    /** <summary>Used to define how polygons will be filled.
     * cf. wx.DC.</summary>*/
    public enum FillRule
    {
        ODDEVEN_RULE = 1,
        WINDING_RULE
    }

    /** <summary>Used to define the background mode in wx.DC.</summary>*/
    public enum DCBackgroundMode
    {
        SOLID = 100,
        TRANSPARENT=106,
    }

	public enum FillStyle
	{
		DEFAULT = 70,
		DECORATIVE,
		ROMAN,
		SCRIPT,
		SWISS,
		MODERN,
		TELETYPE,
		
		VARIABLE = 80,
		FIXED,
		
		NORMAL = 90,
		LIGHT,
		BOLD,
		ITALIC,
		SLANT,
		
		SOLID = 100,
		DOT,
		LONG_DASH,
		SHORT_DASH,
		DOT_DASH,
		USER_DASH,
		TRANSPARENT,
		STIPPLE_MASK_OPAQUE,
		STIPPLE_MASK,
		
		STIPPLE = 110,
		BDIAGONAL_HATCH,
		CROSSDIAG_HATCH,
		FDIAGONAL_HATCH,
		CROSS_HATCH,
		HORIZONTAL_HATCH,
		VERTICAL_HATCH,
		
		JOIN_BEVEL = 120,
		JOIN_MITER,
		JOIN_ROUND,
		
		CAP_ROUND = 130,
		CAP_PROJECTING,
		CAP_BUTT,
		
		// Polygon fill style
		ODDEVEN_RULE = 1,
		WINDING_RULE
	}

    /** <summary>Operations to merge pixels for instance on blitting an image onto another.</summary>*/
	[Flags]
	public enum Logic
	{
		wxCLEAR,        wxROP_BLACK = wxCLEAR,             wxBLIT_BLACKNESS = wxCLEAR,        // 0
		wxXOR,          wxROP_XORPEN = wxXOR,              wxBLIT_SRCINVERT = wxXOR,          // src XOR dst
		wxINVERT,       wxROP_NOT = wxINVERT,              wxBLIT_DSTINVERT = wxINVERT,       // NOT dst
		wxOR_REVERSE,   wxROP_MERGEPENNOT = wxOR_REVERSE,  wxBLIT_00DD0228 = wxOR_REVERSE,    // src OR (NOT dst)
		wxAND_REVERSE,  wxROP_MASKPENNOT = wxAND_REVERSE,  wxBLIT_SRCERASE = wxAND_REVERSE,   // src AND (NOT dst)
		wxCOPY,         wxROP_COPYPEN = wxCOPY,            wxBLIT_SRCCOPY = wxCOPY,           // src
		wxAND,          wxROP_MASKPEN = wxAND,             wxBLIT_SRCAND = wxAND,             // src AND dst
		wxAND_INVERT,   wxROP_MASKNOTPEN = wxAND_INVERT,   wxBLIT_00220326 = wxAND_INVERT,    // (NOT src) AND dst
		wxNO_OP,        wxROP_NOP = wxNO_OP,               wxBLIT_00AA0029 = wxNO_OP,         // dst
		wxNOR,          wxROP_NOTMERGEPEN = wxNOR,         wxBLIT_NOTSRCERASE = wxNOR,        // (NOT src) AND (NOT dst)
		wxEQUIV,        wxROP_NOTXORPEN = wxEQUIV,         wxBLIT_00990066 = wxEQUIV,         // (NOT src) XOR dst
		wxSRC_INVERT,   wxROP_NOTCOPYPEN = wxSRC_INVERT,   wxBLIT_NOTSCRCOPY = wxSRC_INVERT,  // (NOT src)
		wxOR_INVERT,    wxROP_MERGENOTPEN = wxOR_INVERT,   wxBLIT_MERGEPAINT = wxOR_INVERT,   // (NOT src) OR dst
		wxNAND,         wxROP_NOTMASKPEN = wxNAND,         wxBLIT_007700E6 = wxNAND,          // (NOT src) OR (NOT dst)
		wxOR,           wxROP_MERGEPEN = wxOR,             wxBLIT_SRCPAINT = wxOR,            // src OR dst
		wxSET,          wxROP_WHITE = wxSET,               wxBLIT_WHITENESS = wxSET           // 1
	}

    /** <summary>Represents an orientation (e.g. of a sizer).
     * </summary>
     */
    [Flags]
	public enum Orientation
	{
        /// <summary>
        /// Vertical orientation.
        /// </summary>
		wxVERTICAL     = 0x0008,

        /// <summary>
        /// Horizontal orientation.
        /// </summary>
		wxHORIZONTAL   = 0x0004,
		
        /// <summary>
        /// Both orientations, horizontal and vertical.
        /// </summary>
		wxBOTH     = (wxVERTICAL | wxHORIZONTAL),
	}

    /** <summary>Stretching behaviour in dynamic layouts.
     * Refer to wx.Sizer.
     * </summary>
     */
    [Flags]
    public enum Stretch
	{
		wxSTRETCH_NOT     = 0x0000,
		wxSHRINK          = 0x1000,
		wxGROW            = 0x2000,
		wxEXPAND          = wxGROW,
		wxSHAPED          = 0x4000,
		wxFIXED_MINSIZE   = 0x8000,
		wxTILE            = 0xc000,
		
		/** <summary>changed in wxWidgets 2.5.2, see discussion on wx-dev</summary>
         */
        wxADJUST_MINSIZE  = 0x0000,
	}

    /** <summary>Alignments.
     * for instance in instances of wx.Sizer.
     * </summary>
     */
    [Flags]
    public enum Alignment
	{
		wxALIGN_NOT               = 0x0000,
		wxALIGN_CENTER_HORIZONTAL = 0x0100,
		wxALIGN_LEFT              = wxALIGN_NOT,
		wxALIGN_TOP               = wxALIGN_NOT,
		wxALIGN_RIGHT             = 0x0200,
		wxALIGN_BOTTOM            = 0x0400,
		wxALIGN_CENTER_VERTICAL   = 0x0800,
		
		wxALIGN_CENTER            = (wxALIGN_CENTER_HORIZONTAL | wxALIGN_CENTER_VERTICAL),
		
		wxALIGN_MASK              = 0x0f00,
		
		// Alternate spellings
		wxALIGN_CENTRE_VERTICAL   = wxALIGN_CENTER_VERTICAL,
		wxALIGN_CENTRE_HORIZONTAL = wxALIGN_CENTER_HORIZONTAL,
		wxALIGN_CENTRE            = wxALIGN_CENTER,
	}

    /** <summary>Flags from <c>wx.Stretch</c>, <c>wx.Direction</c> and <c>wx.Alignment</c>.
     * This will be used in instances of wx.Sizer when adding new windows.
     * </summary>
     */
    [Flags]
    public enum SizerFlag
    {
        /** <summary>No flag at all.
         * If unique, specifies default behaviour.</summary>
         */
        wxNo_FLAG = 0,
        /** <summary>Specifies a direction as in wx.Direction.</summary>
         */
        wxLEFT = (int) Direction.wxLEFT,
        /** <summary>Specifies a direction as in wx.Direction.</summary>
         */
        wxRIGHT = (int)Direction.wxRIGHT,
        /** <summary>Specifies a direction as in wx.Direction.</summary>
         */
        wxUP = (int)Direction.wxUP,
        /** <summary>Specifies a direction as in wx.Direction.</summary>
         */
        wxDOWN = (int)Direction.wxDOWN,
        /** <summary>Specifies a direction as in wx.Direction.</summary>
         */
        wxTOP = (int)Direction.wxUP,
        /** <summary>Specifies a direction as in wx.Direction.</summary>
         */
        wxBOTTOM = (int)Direction.wxBOTTOM,
        /** <summary>Specifies a direction as in wx.Direction.</summary>
         */
        wxNORTH = (int)Direction.wxUP,
        /** <summary>Specifies a direction as in wx.Direction.</summary>
         */
        wxSOUTH = (int)Direction.wxDOWN,
        /** <summary>Specifies a direction as in wx.Direction.</summary>
         */
        wxWEST = wxLEFT,
        /** <summary>Specifies a direction as in wx.Direction.</summary>
         */
        wxEAST = wxRIGHT,
        /** <summary>Specifies a direction as in wx.Direction.</summary>
         */
        wxALL = (wxUP | wxDOWN | wxRIGHT | wxLEFT),

        /** <summary>This is a flag on stretching.
         * Refer to wx.Stretch.</summary>*/
        wxSTRETCH_NOT = (int)wx.Stretch.wxSTRETCH_NOT,
        /** <summary>This is a flag on stretching.
         * refer to wx.Stretch.</summary>*/
        wxSHRINK = (int)wx.Stretch.wxSHRINK,
        /** <summary>This is a flag on stretching.
         * refer to wx.Stretch.</summary>*/
        wxGROW = (int)wx.Stretch.wxGROW,
        /** <summary>This is a flag on stretching.
         * refer to wx.Stretch.</summary>*/
        wxEXPAND = (int)wx.Stretch.wxEXPAND,
        /** <summary>This is a flag on stretching.
         * refer to wx.Stretch.</summary>*/
        wxSHAPED = (int)wx.Stretch.wxSHAPED,
        /** <summary>This is a flag on stretching.
         * refer to wx.Stretch.</summary>*/
        wxFIXED_MINSIZE = (int)wx.Stretch.wxFIXED_MINSIZE,
        /** <summary>This is a flag on stretching.
         * refer to wx.Stretch.</summary>*/
        wxTILE = (int)wx.Stretch.wxTILE,

        /** <summary>This is a flag on stretching.
         * refer to wx.Stretch.
         * changed in wxWidgets 2.5.2, see discussion on wx-dev</summary>*/
        wxADJUST_MINSIZE = 0x0000,

        /** <summary>This flag is on alignment.
         * Refer to wx.Alignment.</summary>*/
        wxALIGN_NOT = (int)Alignment.wxALIGN_NOT,
        /** <summary>This flag is on alignment.
         * Refer to wx.Alignment.</summary>*/
        wxALIGN_CENTER_HORIZONTAL = (int)Alignment.wxALIGN_CENTRE_HORIZONTAL,
        /** <summary>This flag is on alignment.
         * Refer to wx.Alignment.</summary>*/
        wxALIGN_LEFT = (int)Alignment.wxALIGN_NOT,
        /** <summary>This flag is on alignment.
         * Refer to wx.Alignment.</summary>*/
        wxALIGN_TOP = (int)Alignment.wxALIGN_NOT,
        /** <summary>This flag is on alignment.
         * Refer to wx.Alignment.</summary>*/
        wxALIGN_RIGHT = (int)Alignment.wxALIGN_RIGHT,
        /** <summary>This flag is on alignment.
         * Refer to wx.Alignment.</summary>*/
        wxALIGN_BOTTOM = (int)Alignment.wxALIGN_BOTTOM,
        /** <summary>This flag is on alignment.
         * Refer to wx.Alignment.</summary>*/
        wxALIGN_CENTER_VERTICAL = (int)Alignment.wxALIGN_CENTRE_VERTICAL,

        /** <summary>This flag is on alignment.
         * Refer to wx.Alignment.</summary>*/
        wxALIGN_CENTER = (wxALIGN_CENTER_HORIZONTAL | wxALIGN_CENTER_VERTICAL),

        /** <summary>This flag is on alignment.
         * Refer to wx.Alignment.</summary>*/
        wxALIGN_MASK = (int)Alignment.wxALIGN_MASK,

        /** <summary>This flag is on alignment.
         * Refer to wx.Alignment.</summary>*/
        wxALIGN_CENTRE_VERTICAL = (int)Alignment.wxALIGN_CENTER_VERTICAL,
        /** <summary>This flag is on alignment.
         * Refer to wx.Alignment.</summary>*/
        wxALIGN_CENTRE_HORIZONTAL = (int)Alignment.wxALIGN_CENTER_HORIZONTAL,
        /** <summary>This flag is on alignment.
         * Refer to wx.Alignment.</summary>*/
        wxALIGN_CENTRE = (int)Alignment.wxALIGN_CENTER,
    }

	[Flags]
	public enum ItemKind
	{
		wxITEM_SEPARATOR = -1,
		wxITEM_NORMAL,
		wxITEM_CHECK,
		wxITEM_RADIO,
		wxITEM_MAX
	}

	public enum FloodStyle
	{
		wxFLOOD_SURFACE = 1,
		wxFLOOD_BORDER = 2,
	}
    
    /** <summary>Enumeration of mouse buttons.</summary>*/
	public enum MouseButton
	{
		ANY     = -1,
		NONE    = 0,
		LEFT    = 1,
		MIDDLE  = 2,
		RIGHT   = 3
	}
	
	public enum UpdateUIMode
	{
		// Send UI update events to all windows
		wxUPDATE_UI_PROCESS_ALL,

		// Send UI update events to windows that have
		// the wxWS_EX_PROCESS_UI_UPDATES flag specified
		wxUPDATE_UI_PROCESS_SPECIFIED
	}
}
