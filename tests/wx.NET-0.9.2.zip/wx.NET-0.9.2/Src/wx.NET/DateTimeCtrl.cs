//-----------------------------------------------------------------------------
// wx.NET - DateTimeCtrl.cs
// 
// The wxCalendarCtrl wrapper class.
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: DateTimeCtrl.cs,v 1.3 2009/10/11 16:23:19 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System.Runtime.InteropServices;
using System.Drawing;
using System;

namespace wx
{
    /** <summary>A simple event that fires after a value has been changed.
     *</summary>*/
    public class DateTimeValueChangedEvent : EventArgs
    {
        #region State
        DateTime? _newValue;
        #endregion

        #region CTor
        /** <summary>The value has been set to <c>null</c>.
         * </summary>
         */
        public DateTimeValueChangedEvent()
        {
            this._newValue=null;
        }

        public DateTimeValueChangedEvent(DateTime? newValue)
        {
            this._newValue=newValue;
        }
        #endregion

        #region Public Properties
        /** <summary>Returns the new value that caused this event.
         * The result may be <c>null</c> if this indicated the removal of a value.</summary>*/
        public DateTime? NewValue { get { return this._newValue; } }
        #endregion
    }

    /** <summary>This is the type of the handlers of a DateTimeValueChangedEvent.
     * </summary>
     */
    public delegate void DateTimeValueChangedEventHandler(object sender, DateTimeValueChangedEvent evt);

    /** <summary>This is a combination if the <c>wx.MaskedEdit.DateTimeEdit</c> and the <c>wx.CalendarCtrl</c>.
     * You may use this to put in full time date information with calendar support.
     * </summary>
     */
    public class DateTimeCtrl : Panel
    {
        #region State
        MaskedEdit.DateTimeEdit _edit;
        CalendarCtrl _calCtrl;
        #endregion

        #region CTor
        /** <summary>CTor of the control
         * \param startValue is an optional value that will be displayed on start.
         * \param textMask is a string containing format characters according to the class documentation, e.g. "%d". Refer to
         *                 the documentation of class <c>wx.MaskedEdit.DateTimeEdit</c> for further remarks on this.
         * \param minValue is a lower bound or the input.
         * \param maxValue is an upper bound of the input.
         * All other arguments follow the standard  wx.NET CTors.
         * Please note, that this control always has a value. Use <c>wx.MaskedEdit.DateTimeEdit</c> instead if you want
         * to allow optional input of data.</summary>*/
        public DateTimeCtrl(Window parent, int id, Point position, Size size, WindowStyles style,
            DateTime startValue, string textMask, DateTime minValue, DateTime maxValue)
            : base(parent, id, position, size, style)
        {
            this.AutoLayout = true;
            this._edit = new wx.MaskedEdit.DateTimeEdit(this, wxDefaultPosition, wxDefaultSize,
                style | wx.WindowStyles.BORDER_SUNKEN,
                startValue, textMask, minValue, maxValue, false);
            this._calCtrl = new CalendarCtrl(this, -1, startValue, wxDefaultPosition, wxDefaultSize,
                (style
                & ~wx.WindowStyles.CAL_SHOW_SURROUNDING_WEEKS
                & ~wx.WindowStyles.CAL_SEQUENTIAL_MONTH_SELECTION
                )
                | wx.WindowStyles.CAL_SHOW_SURROUNDING_WEEKS);
            this._calCtrl.SetDateRange(minValue, maxValue);
            BoxSizer sizer = new BoxSizer(Orientation.wxVERTICAL);

            sizer.Add(this._edit, 0, SizerFlag.wxEXPAND);
            sizer.Add(this._calCtrl, 1, SizerFlag.wxEXPAND);

            this.Sizer = sizer;
            sizer.SetSizeHints(this); // set size hints to honour minimal sizes

            this._edit.OnValueChanged += new DateTimeValueChangedEventHandler(this.RaiseOnValueChanged);
            this._calCtrl.DayChange += new EventListener(this.PropagateChangeInCalenderCtrl);
            this._calCtrl.YearChange += new EventListener(this.PropagateChangeInCalenderCtrl);
            this._calCtrl.MonthChange += new EventListener(this.PropagateChangeInCalenderCtrl);
        }

        /** <summary>CTor of the control</summary>
         * <param name="startValue"> is an optional value that will be displayed on start.</param>
         * <param name="textMask"> is a string containing format characters according to the class documentation, e.g. "%d". Refer to
         *                 the documentation of class <c>wx.MaskedEdit.DateTimeEdit</c> for further remarks on this.</param>
         * <param name="minValue"> is a lower bound or the input.</param>
         * <param name="maxValue"> is an upper bound of the input.</param>
         * <remarks>
         * All other arguments follow the standard  wx.NET CTors.
         * Please note, that this control always has a value. Use <c>wx.MaskedEdit.DateTimeEdit</c> instead if you want
         * to allow optional input of data.
         * </remarks>
         */
        public DateTimeCtrl(Window parent, Point position, Size size, WindowStyles style,
            DateTime startValue, string textMask, DateTime minValue, DateTime maxValue)
            : this(parent, -1, position, size, style, startValue, textMask, minValue, maxValue)
        {
        }
        #endregion

        #region Events
        /** <summary>This will be called after the value of the control changed.</summary>*/
        public DateTimeValueChangedEventHandler OnValueChanged;

        bool _raiseOnValueChangedRecursionGuard = false;
        void RaiseOnValueChanged(object sender, DateTimeValueChangedEvent evt)
        {
            if (!this._raiseOnValueChangedRecursionGuard)
            {
                try
                {
                    this._raiseOnValueChangedRecursionGuard = true;
                    this._calCtrl.Date = evt.NewValue.Value;
                    if (this.OnValueChanged != null)
                    {
                        this.OnValueChanged(this, evt);
                    }
                }
                finally
                {
                    this._raiseOnValueChangedRecursionGuard = false;
                }
            }
        }
        void PropagateChangeInCalenderCtrl(object sender, Event evt)
        {
            TimeSpan timeclock = this._edit.Value.Value - this._edit.Value.Value.Date;
            this._edit.Value = this._calCtrl.Date.Add(timeclock);
        }
        #endregion

        #region Properties
        /** <summary>Read or write the value that will be displayed by this control.</summary>*/
        public DateTime Value
        {
            get
            {
                return this._edit.Value.Value;
            }
            set
            {
                this._edit.Value = value;
            }
        }

        /** <summary>Holidays that will be displayed in the calendar control.</summary>*/
        public Calendar SpecialDays
        {
            get
            {
                return this._calCtrl.SpecialDays;
            }
            set
            {
                this._calCtrl.SpecialDays = value;
            }
        }
        #endregion

        #region Public Methods
        /** <summary>This defines the colours to be used in the calendar control on holidays.</summary>*/
        public void SetHolidayColours(Colour foreground, Colour background)
        {
            this._calCtrl.SetHolidayColours(foreground, background);
        }

        public void SetHighlightColours(Colour foreground, Colour background)
        {
            this._calCtrl.SetHighlightColours(foreground, background);
        }
        #endregion
    }
}
