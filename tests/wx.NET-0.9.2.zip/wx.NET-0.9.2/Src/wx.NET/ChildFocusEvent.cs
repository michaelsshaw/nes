//-----------------------------------------------------------------------------
// wx.NET - ChildFocusEvent.cs
//
// The wxChildFocusEvent wrapper class.
//
// Written by Alexander Olk (xenomorph2@onlinehome.de)
// (C) 2004 by Alexander Olk
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: ChildFocusEvent.cs,v 1.4 2009/07/03 18:49:29 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Runtime.InteropServices;

namespace wx
{
	public class ChildFocusEvent : CommandEvent
	{
		[DllImport("wx-c")] static extern IntPtr wxChildFocusEvent_ctor(IntPtr win);
		[DllImport("wx-c")] static extern IntPtr wxChildFocusEvent_GetWindow(IntPtr self);
		
		//-----------------------------------------------------------------------------

		public ChildFocusEvent(IntPtr wxObject) 
			: base(wxObject) { }
			
		public ChildFocusEvent()
			: this(null) {}

        static IntPtr LockedCTor(Window win)
        {
            lock (DllSync)
            {
                return wxChildFocusEvent_ctor(Object.SafePtr(win));
            }
        }

		public ChildFocusEvent(Window win)
			: base(LockedCTor(win)) { }

		//-----------------------------------------------------------------------------	
		
		public Window Window
		{
			get { return (Window)FindObject(wxChildFocusEvent_GetWindow(wxObject), typeof(Window)); }
		}
	}
}
