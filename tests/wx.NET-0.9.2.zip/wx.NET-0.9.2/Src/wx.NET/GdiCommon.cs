//-----------------------------------------------------------------------------
// wx.NET - ActivateEvent.cs
//
// The wxActivateEvent wrapper class.
//
// Written by Alexander Olk (xenomorph2@onlinehome.de)
// (C) 2004 by Alexander Olk
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: GdiCommon.cs,v 1.16 2010/04/11 16:14:27 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Runtime.InteropServices;

namespace wx
{
    /// <summary>
    /// Objects implement this interface if they can be readonly. In that case, all 
    /// calls to modifiers will cause exceptions of class  CannotChangeReadonly.
    /// </summary>
    public interface ICanBeMadeReadonly
    {
        /// <summary>
        /// If this is true, all modifiers will cause exceptions. If this is false,
        /// modfiers can be used.
        /// </summary>
        bool IsReadonly { get; }

        /// <summary>
        /// From this call, all calls to modifiers will cause exceptions.
        /// This shall return <c>this</c>.
        /// </summary>
        object MakeReadOnly();
    }

    /// <summary>
    /// This exception will be thrown if modifiers of readonly (ICanBeMadeReadonly) objects are used.
    /// </summary>
    public class CannotChangeReadonly : Exception
    {
        public CannotChangeReadonly()
            : base()
        {
        }

        public CannotChangeReadonly(string message)
            : base(message)
        {
        }
    }

    public class GDIPens
    {
        [DllImport("wx-c")]
        static extern IntPtr wxGDIObj_GetRedPen();
        [DllImport("wx-c")]
        static extern IntPtr wxGDIObj_GetCyanPen();
        [DllImport("wx-c")]
        static extern IntPtr wxGDIObj_GetGreenPen();
        [DllImport("wx-c")]
        static extern IntPtr wxGDIObj_GetBlackPen();
        [DllImport("wx-c")]
        static extern IntPtr wxGDIObj_GetWhitePen();
        [DllImport("wx-c")]
        static extern IntPtr wxGDIObj_GetTransparentPen();
        [DllImport("wx-c")]
        static extern IntPtr wxGDIObj_GetBlackDashedPen();
        [DllImport("wx-c")]
        static extern IntPtr wxGDIObj_GetGreyPen();
        [DllImport("wx-c")]
        static extern IntPtr wxGDIObj_GetMediumGreyPen();
        [DllImport("wx-c")]
        static extern IntPtr wxGDIObj_GetLightGreyPen();

        public readonly static Pen wxRED_PEN = (Pen)(new Pen(wxGDIObj_GetRedPen()).MakeReadOnly());
        public readonly static Pen wxCYAN_PEN = (Pen)(new Pen(wxGDIObj_GetCyanPen()).MakeReadOnly());
        public readonly static Pen wxGREEN_PEN = (Pen)(new Pen(wxGDIObj_GetGreenPen()).MakeReadOnly());
        public readonly static Pen wxBLACK_PEN = (Pen)(new Pen(wxGDIObj_GetBlackPen()).MakeReadOnly());
        public readonly static Pen wxWHITE_PEN = (Pen)(new Pen(wxGDIObj_GetWhitePen()).MakeReadOnly());
        public readonly static Pen wxTRANSPARENT_PEN = (Pen)(new Pen(wxGDIObj_GetTransparentPen()).MakeReadOnly());
        public readonly static Pen wxBLACK_DASHED_PEN = (Pen)(new Pen(wxGDIObj_GetBlackDashedPen()).MakeReadOnly());
        public readonly static Pen wxGREY_PEN = (Pen)(new Pen(wxGDIObj_GetGreyPen()).MakeReadOnly());
        public readonly static Pen wxMEDIUM_GREY_PEN = (Pen)(new Pen(wxGDIObj_GetMediumGreyPen()).MakeReadOnly());
        public readonly static Pen wxLIGHT_GREY_PEN = (Pen)(new Pen(wxGDIObj_GetLightGreyPen()).MakeReadOnly());
    }

    //-----------------------------------------------------------------------------

    public class GDIBrushes
    {
        [DllImport("wx-c")]
        static extern IntPtr wxBLUE_BRUSH_Get();
        [DllImport("wx-c")]
        static extern IntPtr wxGREEN_BRUSH_Get();
        [DllImport("wx-c")]
        static extern IntPtr wxWHITE_BRUSH_Get();
        [DllImport("wx-c")]
        static extern IntPtr wxBLACK_BRUSH_Get();
        [DllImport("wx-c")]
        static extern IntPtr wxGREY_BRUSH_Get();
        [DllImport("wx-c")]
        static extern IntPtr wxMEDIUM_GREY_BRUSH_Get();
        [DllImport("wx-c")]
        static extern IntPtr wxLIGHT_GREY_BRUSH_Get();
        [DllImport("wx-c")]
        static extern IntPtr wxTRANSPARENT_BRUSH_Get();
        [DllImport("wx-c")]
        static extern IntPtr wxCYAN_BRUSH_Get();
        [DllImport("wx-c")]
        static extern IntPtr wxRED_BRUSH_Get();

        public static Brush wxBLUE_BRUSH = (Brush)(new Brush(wxBLUE_BRUSH_Get())).MakeReadOnly();
        public static Brush wxGREEN_BRUSH = (Brush)(new Brush(wxGREEN_BRUSH_Get())).MakeReadOnly();
        public static Brush wxWHITE_BRUSH = (Brush)(new Brush(wxWHITE_BRUSH_Get())).MakeReadOnly();
        public static Brush wxBLACK_BRUSH = (Brush)(new Brush(wxBLACK_BRUSH_Get())).MakeReadOnly();
        public static Brush wxGREY_BRUSH = (Brush)(new Brush(wxGREY_BRUSH_Get())).MakeReadOnly();
        public static Brush wxMEDIUM_GREY_BRUSH = (Brush)(new Brush(wxMEDIUM_GREY_BRUSH_Get())).MakeReadOnly();
        public static Brush wxLIGHT_GREY_BRUSH = (Brush)(new Brush(wxLIGHT_GREY_BRUSH_Get())).MakeReadOnly();
        public static Brush wxTRANSPARENT_BRUSH = (Brush)(new Brush(wxTRANSPARENT_BRUSH_Get())).MakeReadOnly();
        public static Brush wxCYAN_BRUSH = (Brush)(new Brush(wxCYAN_BRUSH_Get())).MakeReadOnly();
        public static Brush wxRED_BRUSH = (Brush)(new Brush(wxRED_BRUSH_Get())).MakeReadOnly();
    }

    //-----------------------------------------------------------------------------

    public class NullObjects
    {
        [DllImport("wx-c")]
        static extern IntPtr wxNullBitmap_Get();
        [DllImport("wx-c")]
        static extern IntPtr wxNullIcon_Get();
        [DllImport("wx-c")]
        static extern IntPtr wxNullCursor_Get();
        [DllImport("wx-c")]
        static extern IntPtr wxNullPen_Get();
        [DllImport("wx-c")]
        static extern IntPtr wxNullBrush_Get();
        [DllImport("wx-c")]
        static extern IntPtr wxNullPalette_Get();
        [DllImport("wx-c")]
        static extern IntPtr wxNullFont_Get();
        [DllImport("wx-c")]
        static extern IntPtr wxNullColour_Get();

        public static wx.Bitmap wxNullBitmap = (wx.Bitmap)(new wx.Bitmap(wxNullBitmap_Get())).MakeReadOnly();
        public static Icon wxNullIcon = (Icon)(new Icon(wxNullIcon_Get())).MakeReadOnly();
        public static Cursor wxNullCursor = (Cursor)(new Cursor(wxNullCursor_Get())).MakeReadOnly();
        public static Pen wxNullPen = (Pen)(new Pen(wxNullPen_Get())).MakeReadOnly();
        public static Brush wxNullBrush = (Brush)(new Brush(wxNullBrush_Get())).MakeReadOnly();
        public static Palette wxNullPalette = (Palette)(new Palette(wxNullPalette_Get())).MakeReadOnly();
        public static Font wxNullFont = (Font)(new Font(wxNullFont_Get())).MakeReadOnly();
        public static Colour wxNullColour = (Colour)(new Colour(wxNullColour_Get())).MakeReadOnly();
    }

    //-----------------------------------------------------------------------------

    /** <summary>The database of colours.
     * Use whenever possible a database of colours.
     * Property <c>TheColourDatabase</c> provides access to  wxWidget's standard colour database.</summary>*/
    public class ColourDatabase : Object
    {
        [DllImport("wx-c")]
        static extern IntPtr wxColourDatabase_ctor();
        [DllImport("wx-c")]
        static extern void wxColourDataBase_dtor(IntPtr self);
        [DllImport("wx-c")]
        static extern IntPtr wxColourDatabase_Find(IntPtr self, IntPtr name);
        [DllImport("wx-c")]
        static extern IntPtr wxColourDatabase_FindName(IntPtr self, IntPtr colour);
        [DllImport("wx-c")]
        static extern void wxColourDatabase_AddColour(IntPtr self, IntPtr name, IntPtr colour);

        //-----------------------------------------------------------------------------

        public ColourDatabase(IntPtr wxObject)
            : base(wxObject)
        {
            this.wxObject = wxObject;
        }

        internal ColourDatabase(IntPtr wxObject, bool memOwn)
            : base(wxObject)
        {
            this.memOwn = memOwn;
            this.wxObject = wxObject;
        }

        static IntPtr LockedCTor()
        {
            lock (DllSync)
            {
                return wxColourDatabase_ctor();
            }
        }

        public ColourDatabase()
            : this(LockedCTor(), true) { }

        static ColourDatabase _theColourDatabase = null;
        /** <summary>The standard database.
         * The standard database contains at least the following colours:
         * AQUAMARINE, BLACK, BLUE, BLUE VIOLET, BROWN, CADET BLUE, CORAL, CORNFLOWER BLUE, CYAN, DARK GREY,
         * DARK GREEN, DARK OLIVE GREEN, DARK ORCHID, DARK SLATE BLUE, DARK SLATE GREY DARK TURQUOISE,
         * DIM GREY, FIREBRICK, FOREST GREEN, GOLD, GOLDENROD, GREY, GREEN, GREEN YELLOW, INDIAN RED, KHAKI,
         * LIGHT BLUE, LIGHT GREY, LIGHT STEEL BLUE, LIME GREEN, MAGENTA, MAROON, MEDIUM AQUAMARINE, MEDIUM BLUE,
         * MEDIUM FOREST GREEN, MEDIUM GOLDENROD, MEDIUM ORCHID, MEDIUM SEA GREEN, MEDIUM SLATE BLUE,
         * MEDIUM SPRING GREEN, MEDIUM TURQUOISE, MEDIUM VIOLET RED, MIDNIGHT BLUE, NAVY, ORANGE, ORANGE RED,
         * ORCHID, PALE GREEN, PINK, PLUM, PURPLE, RED, SALMON, SEA GREEN, SIENNA, SKY BLUE, SLATE BLUE,
         * SPRING GREEN, STEEL BLUE, TAN, THISTLE, TURQUOISE, VIOLET, VIOLET RED, WHEAT, WHITE, YELLOW,
         * YELLOW GREEN.</summary>*/
        static public ColourDatabase TheColourDatabase
        {
            get
            {
                if (_theColourDatabase == null)
                {
                    _theColourDatabase = new ColourDatabase();
                }
                return _theColourDatabase;
            }
        }

        //---------------------------------------------------------------------

        public override void Dispose()
        {
            if (!disposed)
            {
                if (wxObject != IntPtr.Zero)
                {
                    if (memOwn)
                    {
                        wxColourDataBase_dtor(wxObject);
                        memOwn = false;
                    }
                }
                RemoveObject(wxObject);
                wxObject = IntPtr.Zero;
                --validInstancesCount;
                disposed = true;
            }

            base.Dispose();
            GC.SuppressFinalize(this);
        }

        //---------------------------------------------------------------------

        ~ColourDatabase()
        {
            Dispose();
        }

        //-----------------------------------------------------------------------------

        public Colour Find(string name)
        {
            wxString wxname = wxString.SafeNew(name);
            return (Colour)((Colour)FindObject(wxColourDatabase_Find(wxObject, Object.SafePtr(wxname)), typeof(Colour))).MakeReadOnly();
        }

        //-----------------------------------------------------------------------------

        public string FindName(Colour colour)
        {
            return new wxString(wxColourDatabase_FindName(wxObject, Object.SafePtr(colour)), true);
        }

        //-----------------------------------------------------------------------------

        public void AddColour(string name, Colour colour)
        {
            wxString wxname = wxString.SafeNew(name);
            wxColourDatabase_AddColour(wxObject, Object.SafePtr(wxname), Object.SafePtr(colour));
        }
    }

    //-----------------------------------------------------------------------------

    /** <summary>Wrapper for <c>wxPenList</c>.
      * Whenever possible use static property <c>ThePenList() </c>.
      * </summary>
      */
    public class PenList : Object
    {
        [DllImport("wx-c")]
        static extern IntPtr wxPenList_ThePenList();
        [DllImport("wx-c")]
        static extern IntPtr wxPenList_ctor();
        [DllImport("wx-c")]
        static extern void wxPenList_dtor(IntPtr self);
        [DllImport("wx-c")]
        static extern IntPtr wxPenList_FindOrCreatePen(IntPtr self, IntPtr colour, int width, uint style);

        //-----------------------------------------------------------------------------

        public PenList(IntPtr wxObject)
            : base(wxObject) { }

        static IntPtr LockedCTor()
        {
            lock (DllSync)
            {
                return wxPenList_ctor();
            }
        }

        public PenList()
            : base(LockedCTor()) { }

        //---------------------------------------------------------------------
        static private PenList _thePenList = null;
        /** <summary>The global font list.
        * Use this whenever possible to retrieve fonts.
        *</summary>*/
        static public PenList ThePenList
        {
            get
            {
                if (_thePenList == null)
                {
                    _thePenList = new PenList(wxPenList_ThePenList());
                    _thePenList.memOwn = false;
                }
                return _thePenList;
            }
        }
        //---------------------------------------------------------------------

        /** <summary>\internal HMaH: Needs to be disposed explcitley since non-virtual but also non-trivial DTor.</summary>*/
        public override void Dispose()
        {
            if (!disposed)
            {
                if (wxObject != IntPtr.Zero)
                {
                    if (memOwn)
                    {
                        wxPenList_dtor(wxObject);
                        memOwn = false;
                    }
                }
                RemoveObject(wxObject);
                wxObject = IntPtr.Zero;
                --validInstancesCount;
                disposed = true;
            }

            base.Dispose();
            GC.SuppressFinalize(this);
        }

        //-----------------------------------------------------------------------------

        public Pen FindOrCreatePen(Colour colour, int width, wx.Pen.Styles style)
        {
            return FindOrCreatePen(colour, width, (uint)style);
        }

        public Pen FindOrCreatePen(Colour colour, int width, uint style)
        {
            return (Pen)((Pen)FindObject(wxPenList_FindOrCreatePen(wxObject, Object.SafePtr(colour), width, (uint)style),
                typeof(Pen))).MakeReadOnly();
        }
    }

    //-----------------------------------------------------------------------------

    /** <summary>Wrapper for <c>wxBrushList</c>.
     * Whenever possible use static property <c>TheBrushList()</c>.
     * </summary>
     */
    public class BrushList : Object
    {
        [DllImport("wx-c")]
        static extern IntPtr wxBrushList_TheBrushList();
        [DllImport("wx-c")]
        static extern IntPtr wxBrushList_ctor();
        [DllImport("wx-c")]
        static extern void wxBrushList_dtor(IntPtr self);
        [DllImport("wx-c")]
        static extern IntPtr wxBrushList_FindOrCreateBrush(IntPtr self, IntPtr colour, uint style);

        //-----------------------------------------------------------------------------

        public BrushList(IntPtr wxObject)
            : base(wxObject) { }

        static IntPtr LockedCTor()
        {
            lock (DllSync)
            {
                return wxBrushList_ctor();
            }
        }

        public BrushList()
            : base(LockedCTor()) { }

        //---------------------------------------------------------------------
        static private BrushList _theBrushList = null;
        /** <summary>The global font list.
        * Use this whenever possible to retrieve fonts.
        *</summary>*/
        static public BrushList TheBrushList
        {
            get
            {
                if (_theBrushList == null)
                {
                    _theBrushList = new BrushList(wxBrushList_TheBrushList());
                    _theBrushList.memOwn = false;
                }
                return _theBrushList;
            }
        }
        //---------------------------------------------------------------------

        /** <summary>\internal HMaH: Needs to be disposed explcitley since non-virtual but also non-trivial DTor.</summary>*/
        public override void Dispose()
        {
            if (!disposed)
            {
                if (wxObject != IntPtr.Zero)
                {
                    if (memOwn)
                    {
                        wxBrushList_dtor(wxObject);
                        memOwn = false;
                    }
                }
                RemoveObject(wxObject);
                wxObject = IntPtr.Zero;
                --validInstancesCount;
                disposed = true;
            }

            base.Dispose();
            GC.SuppressFinalize(this);
        }

        //-----------------------------------------------------------------------------
        public Brush FindOrCreateBrush(Colour colour, wx.Brush.Styles style)
        {
            return FindOrCreateBrush(colour, (uint)style);
        }

        public Brush FindOrCreateBrush(Colour colour, uint style)
        {
            return (Brush)((Brush)FindObject(wxBrushList_FindOrCreateBrush(wxObject, Object.SafePtr(colour), (uint)style),
                typeof(Brush))).MakeReadOnly();
        }
    }

    //-----------------------------------------------------------------------------

    /** <summary>Wrapper for <c>wxFontList</c>.
     * Whenever possible use property TheFontList() to retrieve fonts.
     * </summary>
     */
    public class FontList : Object
    {
        [DllImport("wx-c")]
        static extern IntPtr wxFontList_TheFontList();
        [DllImport("wx-c")]
        static extern IntPtr wxFontList_ctor();
        [DllImport("wx-c")]
        static extern void wxFontList_dtor(IntPtr self);
        [DllImport("wx-c")]
        static extern IntPtr wxFontList_FindOrCreateFont(IntPtr self,
                                                        int pointSize,
                                                        int family,
                                                        uint style,
                                                        int weight,
                                                        bool underline,
                                                        IntPtr face,
                                                        FontEncoding encoding);

        //-----------------------------------------------------------------------------

        public FontList(IntPtr wxObject)
            : base(wxObject) { }

        static IntPtr LockedCTor()
        {
            lock (DllSync)
            {
                return wxFontList_ctor();
            }
        }

        public FontList()
            : base(LockedCTor()) { }

        //---------------------------------------------------------------------

        static private FontList _theFontList = null;
        /** <summary>The global font list.
        * Use this whenever possible to retrieve fonts.
        *</summary>*/
        static public FontList TheFontList
        {
            get
            {
                if (_theFontList == null)
                {
                    _theFontList = new FontList(wxFontList_TheFontList());
                    _theFontList.memOwn = false;
                }
                return _theFontList;
            }
        }

        //---------------------------------------------------------------------

        /** <summary>\internal HMaH: Needs to be disposed explcitley since non-virtual but also non-trivial DTor.</summary>*/
        public override void Dispose()
        {
            if (!disposed)
            {
                if (wxObject != IntPtr.Zero)
                {
                    if (memOwn)
                    {
                        wxFontList_dtor(wxObject);
                        memOwn = false;
                    }
                }
                RemoveObject(wxObject);
                wxObject = IntPtr.Zero;
                --validInstancesCount;
                disposed = true;
            }

            base.Dispose();
            GC.SuppressFinalize(this);
        }

        //-----------------------------------------------------------------------------

        public Font FindOrCreateFont(int pointSize, wx.FontFamily family, wx.FontStyle style, wx.FontWeight weight)
        {
            return FindOrCreateFont(pointSize, (int)family, (uint)style, (int)weight);
        }
        public Font FindOrCreateFont(int pointSize, int family, uint style, int weight)
        {
            return FindOrCreateFont(pointSize, family, style, weight, false, "", FontEncoding.wxFONTENCODING_DEFAULT);
        }

        public Font FindOrCreateFont(int pointSize, wx.FontFamily family, wx.FontStyle style, wx.FontWeight weight, bool underline)
        {
            return FindOrCreateFont(pointSize, (int)family, (uint)style, (int)weight, underline);
        }
        public Font FindOrCreateFont(int pointSize, int family, uint style, int weight, bool underline)
        {
            return FindOrCreateFont(pointSize, family, style, weight, underline, "", FontEncoding.wxFONTENCODING_DEFAULT);
        }

        public Font FindOrCreateFont(int pointSize, wx.FontFamily family, wx.FontStyle style, wx.FontWeight weight, bool underline, string face)
        {
            return FindOrCreateFont(pointSize, (int)family, (uint)style, (int)weight, underline, face);
        }
        public Font FindOrCreateFont(int pointSize, int family, uint style, int weight, bool underline, string face)
        {
            return FindOrCreateFont(pointSize, family, style, weight, underline, face, FontEncoding.wxFONTENCODING_DEFAULT);
        }
        public Font FindOrCreateFont(int pointSize, int family, uint style, int weight, bool underline, string face, FontEncoding encoding)
        {
            wxString wxface = wxString.SafeNew(face);
            return (Font)((Font)FindObject(wxFontList_FindOrCreateFont(wxObject, pointSize, family, style, weight, underline, Object.SafePtr(wxface), encoding),
                typeof(Font))).MakeReadOnly();
        }
        //-----------------------------------------------------------------------------
        /** <summary>Get a font with all properties from <c>prototype</c> but of the given <c>family</c>.
         *</summary>
         */
        public Font FindOrCreateWithFamily(wx.Font prototype, wx.FontFamily family)
        {
            return FindOrCreateFont(prototype.PointSize, family, prototype.Style, prototype.Weight, prototype.Underlined);
        }
        /** <summary>Get a font with all properties from <c>prototype</c> but of the given <c>weight</c>.
         * </summary>
         */
        public Font FindOrCreateWithWeight(wx.Font prototype, wx.FontWeight weight)
        {
            return FindOrCreateFont(prototype.PointSize, prototype.Family, prototype.Style, weight, prototype.Underlined);
        }
        /** <summary>Get a font with all properties from <c>prototype</c> but of the given <c>style</c>.
         *</summary>
         */
        public Font FindOrCreateWithStyle(wx.Font prototype, wx.FontStyle style)
        {
            return FindOrCreateFont(prototype.PointSize, prototype.Family, style, prototype.Weight, prototype.Underlined);
        }
        /** <summary>Get a font with all properties from <c>prototype</c> but of the given <c>size</c>.
         *</summary>
         */
        public Font FindOrCreateWithSize(wx.Font prototype, int size)
        {
            return FindOrCreateFont(size, prototype.Family, prototype.Style, prototype.Weight, prototype.Underlined);
        }
        /** <summary>Get a font with all properties from <c>prototype</c> but underlined according to <c>isUnderlined</c>.
         *</summary>
         */
        public Font FindOrCreateUnderlined(wx.Font prototype, bool isUnderlined)
        {
            return FindOrCreateFont(prototype.PointSize, prototype.Family, prototype.Style, prototype.Weight, isUnderlined);
        }
    }

    //-----------------------------------------------------------------------------

    /// <summary>
    /// List of bitmaps that can be used in controls (ListCtrl) to associate data with icons.
    /// </summary>
    public class BitmapList : Object
    {
        [DllImport("wx-c")]
        static extern IntPtr wxBitmapList_ctor();
        [DllImport("wx-c")]
        static extern void wxBitmapList_dtor(IntPtr self);
        [DllImport("wx-c")]
        static extern void wxBitmapList_AddBitmap(IntPtr self, IntPtr bitmap);
        [DllImport("wx-c")]
        static extern void wxBitmapList_RemoveBitmap(IntPtr self, IntPtr bitmap);

        //-----------------------------------------------------------------------------

        public BitmapList(IntPtr wxObject)
            : base(wxObject) { }

        static IntPtr LockedCTor()
        {
            lock (DllSync)
            {
                return wxBitmapList_ctor();
            }
        }

        public BitmapList()
            : base(LockedCTor()) { }

        //---------------------------------------------------------------------

        /** <summary>\internal HMaH: Needs to be disposed explcitley since non-virtual but also non-trivial DTor.</summary>*/
        public override void Dispose()
        {
            if (!disposed)
            {
                if (wxObject != IntPtr.Zero)
                {
                    if (memOwn)
                    {
                        wxBitmapList_dtor(wxObject);
                        memOwn = false;
                    }
                }
                RemoveObject(wxObject);
                wxObject = IntPtr.Zero;
                --validInstancesCount;
                disposed = true;
            }

            base.Dispose();
            GC.SuppressFinalize(this);
        }

        //-----------------------------------------------------------------------------

        public void AddBitmap(Bitmap bitmap)
        {
            wxBitmapList_AddBitmap(wxObject, Object.SafePtr(bitmap));
        }

        //-----------------------------------------------------------------------------

        public void RemoveBitmap(Bitmap bitmap)
        {
            wxBitmapList_RemoveBitmap(wxObject, Object.SafePtr(bitmap));
        }
    }

    //-----------------------------------------------------------------------------

    public struct StockCursors
    {
        [DllImport("wx-c")]
        static extern IntPtr wxSTANDARD_CURSOR_Get();
        [DllImport("wx-c")]
        static extern IntPtr wxHOURGLASS_CURSOR_Get();
        [DllImport("wx-c")]
        static extern IntPtr wxCROSS_CURSOR_Get();

        //-----------------------------------------------------------------------------

        public static Cursor wxSTANDARD_CURSOR = (Cursor)((Cursor)new Cursor(wxSTANDARD_CURSOR_Get())).MakeReadOnly();
        public static Cursor wxHOURGLASS_CURSOR = (Cursor)((Cursor)new Cursor(wxHOURGLASS_CURSOR_Get())).MakeReadOnly();
        public static Cursor wxCROSS_CURSOR = (Cursor)((Cursor)new Cursor(wxCROSS_CURSOR_Get())).MakeReadOnly();
    }
}

