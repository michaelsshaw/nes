//-----------------------------------------------------------------------------
// wx.NET - Control.cs
//
// The wxControl wrapper class.
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: Control.cs,v 1.17 2010/05/08 19:52:40 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Drawing;
using System.Runtime.InteropServices;

namespace wx
{
    /** <summary>This is the base class for a control or "widget''.
    * A control is generally a small window which processes user input and/or displays one or more item of data.
    *</summary>*/
	public class Control : Window
	{
		//[DllImport("wx-c")] static extern void   wxControl_Command(IntPtr self, IntPtr evt);
		[DllImport("wx-c")] static extern IntPtr wxControl_GetLabel(IntPtr self);
		[DllImport("wx-c")] static extern void   wxControl_SetLabel(IntPtr self, IntPtr label);
		
		[DllImport("wx-c")] static extern int wxControl_GetAlignment(IntPtr self);
		[DllImport("wx-c")] static extern bool wxControl_SetFont(IntPtr self, IntPtr font);

		//---------------------------------------------------------------------

		public Control(IntPtr wxObject) 
			: base(wxObject) {}

		public Control(Window parent, int id, Point pos, Size size, wx.WindowStyles style, string name)
			: base(parent, id, pos, size, style, name) {}

        public Control(Window parent, Point pos, Size size, wx.WindowStyles style, string name)
			: base(parent, Window.UniqueID, pos, size, style, name) {}

		//---------------------------------------------------------------------

		public void Command() {}

		//---------------------------------------------------------------------

		public string Label 
		{
			get { return new wxString(wxControl_GetLabel(wxObject), true); }
			set
			{
				wxString wxValue=new wxString(value);
				wxControl_SetLabel(this.wxObject, wxValue.wxObject);
			}
		}
		
		//---------------------------------------------------------------------
		
		public int GetAlignment()
		{
			return wxControl_GetAlignment(wxObject);
		}
		
		//---------------------------------------------------------------------
		
		public bool SetFont(Font font)
		{
			return wxControl_SetFont(wxObject, Object.SafePtr(font));
		}
	}
}

