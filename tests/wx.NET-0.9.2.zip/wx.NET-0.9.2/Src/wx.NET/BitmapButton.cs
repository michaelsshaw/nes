//-----------------------------------------------------------------------------
// wx.NET - BitmapButton.cs
//
// The wxBitmapButton wrapper class.
//
// Written by Robert Roebling
// (C) 2003 Robert Roebling
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: BitmapButton.cs,v 1.23 2009/10/11 16:23:18 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Drawing;
using System.Runtime.InteropServices;

namespace wx
{
    /** <summary>Button showing a bitmap.
     * Special style flag: wx.WindowStyles.BU_AUTODRAW.</summary>*/
    public class BitmapButton : Control
	{
		private delegate void Virtual_OnSetBitmap();
		
		[DllImport("wx-c")] static extern IntPtr wxBitmapButton_ctor();
		[DllImport("wx-c")] static extern void   wxBitmapButton_RegisterVirtual(IntPtr self, Virtual_OnSetBitmap onSetBitmap);
		//[DllImport("wx-c")] static extern void   wxBitmapButton_RegisterDisposable(IntPtr self, Virtual_Dispose onDispose);
        [DllImport("wx-c")]
        static extern bool wxBitmapButton_Create(IntPtr self, IntPtr parent, int id, IntPtr label, int x, int y, int w, int h, uint style, IntPtr validator, IntPtr name);
		[DllImport("wx-c")] static extern void   wxBitmapButton_SetDefault(IntPtr self);
		
		[DllImport("wx-c")] static extern void wxBitmapButton_SetLabel(IntPtr self, IntPtr label);
		[DllImport("wx-c")] static extern IntPtr wxBitmapButton_GetLabel(IntPtr self);
		
		[DllImport("wx-c")] static extern bool wxBitmapButton_Enable(IntPtr self, bool enable);

		[DllImport("wx-c")] static extern void   wxBitmapButton_SetBitmapLabel(IntPtr self, IntPtr bitmap);
		[DllImport("wx-c")] static extern IntPtr wxBitmapButton_GetBitmapLabel(IntPtr self);
		
		[DllImport("wx-c")] static extern void wxBitmapButton_SetBitmapSelected(IntPtr self, IntPtr bitmap);
		[DllImport("wx-c")] static extern IntPtr wxBitmapButton_GetBitmapSelected(IntPtr self);

		[DllImport("wx-c")] static extern void wxBitmapButton_SetBitmapFocus(IntPtr self, IntPtr bitmap);
		[DllImport("wx-c")] static extern IntPtr wxBitmapButton_GetBitmapFocus(IntPtr self);

		[DllImport("wx-c")] static extern void wxBitmapButton_SetBitmapDisabled(IntPtr self, IntPtr bitmap);
		[DllImport("wx-c")] static extern IntPtr wxBitmapButton_GetBitmapDisabled(IntPtr self);
		
		[DllImport("wx-c")] static extern void wxBitmapButton_OnSetBitmap(IntPtr self);
		
		//[DllImport("wx-c")] static extern void wxBitmapButton_ApplyParentThemeBackground(IntPtr self, IntPtr colour);

		//---------------------------------------------------------------------
				
		public BitmapButton(IntPtr wxObject) 
			: base(wxObject) { }

        static IntPtr LockedCTor()
        {
            return wxBitmapButton_ctor();
        }

		public BitmapButton()
			: this(LockedCTor()) 
		{
			wxBitmapButton_RegisterVirtual(wxObject, new Virtual_OnSetBitmap(OnSetBitmap));
		}

		public BitmapButton(Window parent, int id, Bitmap label)
			: this(parent, id, label, wxDefaultPosition, wxDefaultSize, 0, null)	{ }

		public BitmapButton(Window parent, int id, Bitmap label, Point pos)
			: this(parent, id, label, pos, wxDefaultSize, 0, null) { }

		public BitmapButton(Window parent, int id, Bitmap label, Point pos, Size size)
			: this(parent, id, label, pos, size, 0, null) { } 

		public BitmapButton(Window parent, int id, Bitmap label, Point pos, Size size, wx.WindowStyles style)
			: this(parent, id, label, pos, size, style, null) { }

         Virtual_OnSetBitmap _onSetBitmap=null;
         public BitmapButton(Window parent, int id, Bitmap label, Point pos, Size size, wx.WindowStyles style, string name)
               : this(LockedCTor())
         {
             this._onSetBitmap=new Virtual_OnSetBitmap(OnSetBitmap);
             wxBitmapButton_RegisterVirtual(wxObject, this._onSetBitmap);
               
             if (!Create(parent, id, label, pos, size, style, name))
             {
                throw new InvalidOperationException("Failed to create BitmapButton");
             }
         }
			
		//---------------------------------------------------------------------
		// ctors with self created id
			
		public BitmapButton(Window parent, Bitmap label)
			: this(parent, Window.UniqueID, label, wxDefaultPosition, wxDefaultSize, 0, null)	{ }

		public BitmapButton(Window parent, Bitmap label, Point pos)
			: this(parent, Window.UniqueID, label, pos, wxDefaultSize, 0, null) { }

		public BitmapButton(Window parent, Bitmap label, Point pos, Size size)
			: this(parent, Window.UniqueID, label, pos, size, 0, null) { } 

		public BitmapButton(Window parent, Bitmap label, Point pos, Size size, wx.WindowStyles style)
			: this(parent, Window.UniqueID, label, pos, size, style, null) { }

		public BitmapButton(Window parent, Bitmap label, Point pos, Size size, wx.WindowStyles style, string name)
			: this(parent, Window.UniqueID, label, pos, size, style, name) {}

		//---------------------------------------------------------------------
		
		public bool Create(Window parent, int id, Bitmap label, Point pos, Size size, wx.WindowStyles style, string name)
		{
            wxString wxname = wxString.SafeNew(name);
			return wxBitmapButton_Create(this.wxObject, Object.SafePtr(parent), id, Object.SafePtr(label), pos.X, pos.Y, size.Width, size.Height, (uint)style, IntPtr.Zero, Object.SafePtr(wxname));
		}

		//---------------------------------------------------------------------		

		public void SetDefault()
		{
			wxBitmapButton_SetDefault(wxObject);
		}
		
		//---------------------------------------------------------------------		
		
		public string StringLabel
		{
			get { return new wxString(wxBitmapButton_GetLabel(wxObject), true); }
			set
            {
                wxString wxValue = wxString.SafeNew(value);
                wxBitmapButton_SetLabel(wxObject, Object.SafePtr(wxValue));
            }
		}
		
		public void SetLabel(string label)
		{
            wxString wxLabel = wxString.SafeNew(label);
			wxBitmapButton_SetLabel(this.wxObject, Object.SafePtr(wxLabel));
		}
		
		public string GetLabel()
		{
			return new wxString(wxBitmapButton_GetLabel(wxObject), true);
		}
		
		//---------------------------------------------------------------------
		
		public bool Enable()
		{
			return Enable(true);
		}
		
		public bool Enable(bool enable)
		{
			return wxBitmapButton_Enable(wxObject, enable);
		}

		//---------------------------------------------------------------------

		public wx.Bitmap BitmapLabel
		{
			get { return (wx.Bitmap)FindObject(wxBitmapButton_GetBitmapLabel(wxObject), typeof(Bitmap)); }
			set { wxBitmapButton_SetBitmapLabel(wxObject, Object.SafePtr(value)); }
		}

		public new wx.Bitmap Label
		{
			get { return (wx.Bitmap)FindObject(wxBitmapButton_GetBitmapLabel(wxObject), typeof(Bitmap)); }
			set { wxBitmapButton_SetBitmapLabel(wxObject, Object.SafePtr(value)); }
		}
		
		//---------------------------------------------------------------------
		
		public Bitmap BitmapSelected
		{
			get { return (wx.Bitmap)FindObject(wxBitmapButton_GetBitmapSelected(wxObject), typeof(Bitmap)); }
			set { wxBitmapButton_SetBitmapSelected(wxObject, Object.SafePtr(value)); }
		}
		
		public Bitmap BitmapFocus
		{
			get { return (wx.Bitmap)FindObject(wxBitmapButton_GetBitmapFocus(wxObject), typeof(Bitmap)); }
			set { wxBitmapButton_SetBitmapFocus(wxObject, Object.SafePtr(value)); }
		}

		public Bitmap BitmapDisabled
		{
			get { return (wx.Bitmap)FindObject(wxBitmapButton_GetBitmapDisabled(wxObject), typeof(Bitmap)); }
			set { wxBitmapButton_SetBitmapDisabled(wxObject, Object.SafePtr(value)); }
		}

		//---------------------------------------------------------------------
		
		protected virtual void OnSetBitmap()
		{
			wxBitmapButton_OnSetBitmap(wxObject);
		}
		
		//---------------------------------------------------------------------
		
		/*public virtual void ApplyParentThemeBackground(Colour bg)
		{
			wxBitmapButton_ApplyParentThemeBackground(wxObject, Object.SafePtr(bg));
		}*/
	}
}
