//-----------------------------------------------------------------------------
// wx.NET - Window.cs
//
// The wxWindow wrapper class.
//
// Written by Jason Perkins (jason@379.com)
// (C) 2003 by 379, Inc.
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: Window.cs,v 1.101 2010/06/05 11:58:26 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Drawing;
using System.Runtime.InteropServices;

namespace wx
{
	public enum WindowVariant
	{
        /** <summary>Normal size</summary>*/
		wxWINDOW_VARIANT_NORMAL,
        /** <summary>Smaller size (about 25 % smaller than normal)</summary>*/
		wxWINDOW_VARIANT_SMALL,  
        /** <summary>Mini size (about 33 % smaller than normal)</summary>*/
        wxWINDOW_VARIANT_MINI, 
        /** <summary>Large size (about 25 % larger than normal)</summary>*/
        wxWINDOW_VARIANT_LARGE, 
	};	
	
	//---------------------------------------------------------------------

    /** <summary>The background style indicates whether background colour
     * should be determined by the system (wxBG_STYLE_SYSTEM),
     * be set to a specific colour (wxBG_STYLE_COLOUR),
     * or should be left to the application to implement (wxBG_STYLE_CUSTOM).</summary>*/
	public enum BackgroundStyle
	{
		wxBG_STYLE_SYSTEM,
		wxBG_STYLE_COLOUR,
		wxBG_STYLE_CUSTOM
	};
	
	//---------------------------------------------------------------------
	
    [Flags]
	public enum Border
	{
		wxBORDER_DEFAULT = 0,

		wxBORDER_NONE   = 0x00200000,
		wxBORDER_STATIC = 0x01000000,
		wxBORDER_SIMPLE = 0x02000000,
		wxBORDER_RAISED = 0x04000000,
		wxBORDER_SUNKEN = 0x08000000,
		wxBORDER_DOUBLE = 0x10000000,

		wxBORDER_MASK   = 0x1f200000,
		
		wxDOUBLE_BORDER   = wxBORDER_DOUBLE,
		wxSUNKEN_BORDER   = wxBORDER_SUNKEN,
		wxRAISED_BORDER   = wxBORDER_RAISED,
		wxBORDER          = wxBORDER_SIMPLE,
		wxSIMPLE_BORDER   = wxBORDER_SIMPLE,
		wxSTATIC_BORDER   = wxBORDER_STATIC,
		wxNO_BORDER       = wxBORDER_NONE
	};
	
	//---------------------------------------------------------------------
	
	public class VisualAttributes : Object
	{
		[DllImport("wx-c")] static extern IntPtr wxVisualAttributes_ctor();
		[DllImport("wx-c")] static extern void   wxVisualAttributes_dtor(IntPtr self);
		[DllImport("wx-c")] static extern void   wxVisualAttributes_RegisterDisposable(IntPtr self, Virtual_Dispose onDispose);
		[DllImport("wx-c")] static extern void   wxVisualAttributes_SetFont(IntPtr self, IntPtr font);
		[DllImport("wx-c")] static extern IntPtr wxVisualAttributes_GetFont(IntPtr self);
		[DllImport("wx-c")] static extern void   wxVisualAttributes_SetColourFg(IntPtr self, IntPtr colour);
		[DllImport("wx-c")] static extern IntPtr wxVisualAttributes_GetColourFg(IntPtr self);
		[DllImport("wx-c")] static extern void   wxVisualAttributes_SetColourBg(IntPtr self, IntPtr colour);
		[DllImport("wx-c")] static extern IntPtr wxVisualAttributes_GetColourBg(IntPtr self);
		
		//---------------------------------------------------------------------

		public VisualAttributes(IntPtr wxObject)
			: base(wxObject)
		{ 
			this.wxObject = wxObject;
		}
		
		internal VisualAttributes(IntPtr wxObject, bool memOwn)
			: base(wxObject)
		{ 
			this.memOwn = memOwn;
			this.wxObject = wxObject;
		}
			
		public VisualAttributes()
			: this(wxVisualAttributes_ctor(), true) 
		{ 
			virtual_Dispose = new Virtual_Dispose(VirtualDispose);
			wxVisualAttributes_RegisterDisposable(wxObject, virtual_Dispose);
		}
		
		//---------------------------------------------------------------------

		public Font font 
		{
			get { return new Font(wxVisualAttributes_GetFont(wxObject), true); }
			set { wxVisualAttributes_SetFont(wxObject, Object.SafePtr(value)); }
		}
		
		//---------------------------------------------------------------------
		
		public Colour colFg
		{
			get { return new Colour(wxVisualAttributes_GetColourFg(wxObject), true); }
			set { wxVisualAttributes_SetColourFg(wxObject, Object.SafePtr(value)); }
		}
		
		//---------------------------------------------------------------------
		
		public Colour colBg
		{
			get { return new Colour(wxVisualAttributes_GetColourBg(wxObject), true); }
			set { wxVisualAttributes_SetColourBg(wxObject, Object.SafePtr(value)); }
		}
		
		//---------------------------------------------------------------------
				
		public override void Dispose()
		{
			if (!disposed)
			{
                if (wxObject != IntPtr.Zero)
				{
					if (memOwn)
					{
						wxVisualAttributes_dtor(wxObject);
						memOwn = false;
					}
				}
				RemoveObject(wxObject);
				wxObject = IntPtr.Zero;
                --validInstancesCount;
                disposed = true;
			}
			
			base.Dispose();
			GC.SuppressFinalize(this);
		}
		
		//---------------------------------------------------------------------
		
		~VisualAttributes() 
		{
			Dispose();
		}
	}

	//---------------------------------------------------------------------


    /** <summary>Window is the base class for all windows and represents any visible object on screen.
     * All controls, top level windows and so on are windows. Sizers and device contexts are not,
     * however, as they don't appear on screen themselves.
     * Please note that all children of the window will be deleted automatically by
     * the destructor before the window itself is deleted which means that you
     * don't have to worry about deleting them manually.
     *</summary>*/
	public class Window : EvtHandler
	{
        /// <summary>
        /// Default ID of the OK button.
        /// </summary>
		public const int  wxID_OK			= 5100;

        /// <summary>
        /// Default ID of the cancel button.
        /// </summary>
		public const int  wxID_CANCEL			= 5101;

        /// <summary>
        /// Default ID of the YES button.
        /// </summary>
		public const int  wxID_YES			= 5103;

        /// <summary>
        /// Default ID of the NO button.
        /// </summary>
		public const int  wxID_NO			= 5104;
	 
        /// <summary>
        /// Indefinite window ID: -1.
        /// </summary>
		public const int wxID_ANY			= -1;

        /// <summary>
        /// Default ID of the about box.
        /// </summary>
		public const int wxID_ABOUT	    = 5013;
		
		public const int wxFRAME_EX_CONTEXTHELP	= 0x00000004;

		//---------------------------------------------------------------------
	
		private static int uniqueID			= 10000; // start with 10000 to not interfere with the old id system

		//---------------------------------------------------------------------

        delegate char InternalValidator();

		[DllImport("wx-c")] static extern IntPtr wxWindow_ctor(IntPtr parent, int id, int posX, int posY, int width, int height, uint style, IntPtr name);
		[DllImport("wx-c")][return:MarshalAs(UnmanagedType.U1)] static extern bool   wxWindow_Close(IntPtr self, bool force);
		[DllImport("wx-c")] static extern void   wxWindow_GetBestSize(IntPtr self, out Size size);
		[DllImport("wx-c")] static extern void   wxWindow_GetClientSize(IntPtr self, out Size size);
		[DllImport("wx-c")] static extern int    wxWindow_GetId(IntPtr self);
		[DllImport("wx-c")] static extern uint   wxWindow_GetWindowStyleFlag(IntPtr self);
		[DllImport("wx-c")] static extern uint   wxWindow_Layout(IntPtr self);
		[DllImport("wx-c")] static extern void   wxWindow_SetAutoLayout(IntPtr self, bool autoLayout);
		[DllImport("wx-c")] static extern void   wxWindow_SetBackgroundColour(IntPtr self, IntPtr colour);
		[DllImport("wx-c")] static extern IntPtr wxWindow_GetBackgroundColour(IntPtr self);
		[DllImport("wx-c")] static extern void   wxWindow_SetForegroundColour(IntPtr self, IntPtr colour);
		[DllImport("wx-c")] static extern IntPtr wxWindow_GetForegroundColour(IntPtr self);
		[DllImport("wx-c")] static extern IntPtr wxWindow_GetCursor(IntPtr self);
        [DllImport("wx-c")]
        static extern void wxWindow_SetCursor(IntPtr self, IntPtr cursor);
        [DllImport("wx-c")]
        static extern void wxWindow_SetId(IntPtr self, int id);
		[DllImport("wx-c")] static extern void   wxWindow_SetSize(IntPtr self, int x, int y, int width, int height, uint flags);
		[DllImport("wx-c")] static extern void   wxWindow_SetSize2(IntPtr self, int width, int height);
		[DllImport("wx-c")] static extern void   wxWindow_SetSize3(IntPtr self, ref Size size);
		[DllImport("wx-c")] static extern void   wxWindow_SetSizer(IntPtr self, IntPtr sizer, bool deleteOld);
		[DllImport("wx-c")] static extern void   wxWindow_SetWindowStyleFlag(IntPtr self, uint style);
		[DllImport("wx-c")][return:MarshalAs(UnmanagedType.U1)] static extern bool   wxWindow_Show(IntPtr self, bool show);
		[DllImport("wx-c")][return:MarshalAs(UnmanagedType.U1)] static extern bool   wxWindow_SetFont(IntPtr self, IntPtr font);
		[DllImport("wx-c")] static extern IntPtr wxWindow_GetFont(IntPtr self);
		[DllImport("wx-c")] static extern void   wxWindow_SetToolTip(IntPtr self, IntPtr tip);
        [DllImport("wx-c")] static extern IntPtr wxWindow_GetToolTip(IntPtr self);
		[DllImport("wx-c")][return:MarshalAs(UnmanagedType.U1)] static extern bool wxWindow_Enable(IntPtr self, bool enable);
        [DllImport("wx-c")][return:MarshalAs(UnmanagedType.U1)] static extern bool wxWindow_IsEnabled(IntPtr self);

        [DllImport("wx-c")] static extern void wxWindow_RegisterValidator(IntPtr self, InternalValidator validator);

        [DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)] static extern bool wxWindow_Destroy(IntPtr self);
        [DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)] static extern bool wxWindow_DestroyChildren(IntPtr self);
		[DllImport("wx-c")] static extern void   wxWindow_SetTitle(IntPtr self, IntPtr title);
		[DllImport("wx-c")] static extern IntPtr wxWindow_GetTitle(IntPtr self);
		[DllImport("wx-c")] static extern void   wxWindow_SetName(IntPtr self, IntPtr name);
		[DllImport("wx-c")] static extern IntPtr wxWindow_GetName(IntPtr self);
		[DllImport("wx-c")] static extern int    wxWindow_NewControlId();
		[DllImport("wx-c")] static extern int    wxWindow_NextControlId(int id);
		[DllImport("wx-c")] static extern int    wxWindow_PrevControlId(int id);
		[DllImport("wx-c")] static extern void   wxWindow_Move(IntPtr self, int x, int y, int flags);
		[DllImport("wx-c")] static extern void   wxWindow_Raise(IntPtr self);
		[DllImport("wx-c")] static extern void   wxWindow_Lower(IntPtr self);
		[DllImport("wx-c")] static extern void   wxWindow_SetClientSize(IntPtr self, int width, int height);
		[DllImport("wx-c")] static extern void   wxWindow_GetPosition(IntPtr self, out Point point);
		[DllImport("wx-c")] static extern void   wxWindow_GetSize(IntPtr self, out Size size);
		[DllImport("wx-c")] static extern void   wxWindow_GetRect(IntPtr self, out Rectangle rect);
		[DllImport("wx-c")] static extern void   wxWindow_GetClientAreaOrigin(IntPtr self, out Point point);
		[DllImport("wx-c")] static extern void   wxWindow_GetClientRect(IntPtr self, out Rectangle rect);
		[DllImport("wx-c")] static extern void   wxWindow_GetAdjustedBestSize(IntPtr self, out Size size);
		[DllImport("wx-c")] static extern void   wxWindow_Center(IntPtr self, int direction);
		[DllImport("wx-c")] static extern void   wxWindow_CenterOnScreen(IntPtr self, int dir);
		[DllImport("wx-c")] static extern void   wxWindow_CenterOnParent(IntPtr self, int dir);
		[DllImport("wx-c")] static extern void   wxWindow_Fit(IntPtr self);
		[DllImport("wx-c")] static extern void   wxWindow_FitInside(IntPtr self);
		[DllImport("wx-c")] static extern void   wxWindow_SetSizeHints(IntPtr self, int minW, int minH, int maxW, int maxH, int incW, int incH);
		[DllImport("wx-c")] static extern void   wxWindow_SetVirtualSizeHints(IntPtr self, int minW, int minH, int maxW, int maxH);
		[DllImport("wx-c")] static extern int    wxWindow_GetMinWidth(IntPtr self);
		[DllImport("wx-c")] static extern int    wxWindow_GetMinHeight(IntPtr self);
        [DllImport("wx-c")] static extern int    wxWindow_SetMinSize(IntPtr self, int w, int h);
        [DllImport("wx-c")] static extern int    wxWindow_GetMaxWidth(IntPtr self);
		[DllImport("wx-c")] static extern int    wxWindow_GetMaxHeight(IntPtr self);
        [DllImport("wx-c")] static extern int    wxWindow_SetMaxSize(IntPtr self, int w, int h);
        [DllImport("wx-c")] static extern void   wxWindow_SetVirtualSize(IntPtr self, int w, int h);
		[DllImport("wx-c")] static extern void   wxWindow_GetVirtualSize(IntPtr self, out Size size);
		[DllImport("wx-c")] static extern void   wxWindow_GetBestVirtualSize(IntPtr self, out Size size);
        [DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)] static extern bool wxWindow_Hide(IntPtr self);
        [DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)] static extern bool wxWindow_Disable(IntPtr self);
        [DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)] static extern bool wxWindow_IsShown(IntPtr self);
		[DllImport("wx-c")] static extern void   wxWindow_SetWindowStyle(IntPtr self, uint style);
		[DllImport("wx-c")] static extern uint   wxWindow_GetWindowStyle(IntPtr self);
        [DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)] static extern bool wxWindow_HasFlag(IntPtr self, uint flag);
        [DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)] static extern bool wxWindow_IsRetained(IntPtr self);
		[DllImport("wx-c")] static extern void   wxWindow_SetExtraStyle(IntPtr self, uint exStyle);
		[DllImport("wx-c")] static extern uint   wxWindow_GetExtraStyle(IntPtr self);
		//[DllImport("wx-c")] static extern void wxWindow_MakeModal(IntPtr self, bool modal);
		[DllImport("wx-c")] static extern void   wxWindow_SetThemeEnabled(IntPtr self, bool enableTheme);
        [DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)] static extern bool wxWindow_GetThemeEnabled(IntPtr self);
		[DllImport("wx-c")] static extern void   wxWindow_SetFocus(IntPtr self);
		[DllImport("wx-c")] static extern void   wxWindow_SetFocusFromKbd(IntPtr self);
		[DllImport("wx-c")] static extern IntPtr wxWindow_FindFocus();
        [DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)] static extern bool wxWindow_AcceptsFocus(IntPtr self);
        [DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)] static extern bool wxWindow_AcceptsFocusFromKeyboard(IntPtr self);
		[DllImport("wx-c")] static extern IntPtr wxWindow_GetParent(IntPtr self);
		[DllImport("wx-c")] static extern IntPtr wxWindow_GetGrandParent(IntPtr self);
        [DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)]static extern bool wxWindow_IsTopLevel(IntPtr self);
		[DllImport("wx-c")] static extern void   wxWindow_SetParent(IntPtr self, IntPtr parent);
        [DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)] static extern bool wxWindow_Reparent(IntPtr self, IntPtr newParent);
		//[DllImport("wx-c")] static extern void   wxWindow_AddChild(IntPtr self, IntPtr child);
		//[DllImport("wx-c")] static extern void   wxWindow_RemoveChild(IntPtr self, IntPtr child);
		[DllImport("wx-c")] static extern IntPtr wxWindow_FindWindowId(IntPtr self, int id);
		[DllImport("wx-c")] static extern IntPtr wxWindow_FindWindowName(IntPtr self, IntPtr name);
		[DllImport("wx-c")] static extern IntPtr wxWindow_FindWindowById(int id, IntPtr parent);
		[DllImport("wx-c")] static extern IntPtr wxWindow_FindWindowByName(IntPtr name, IntPtr parent);
		[DllImport("wx-c")] static extern IntPtr wxWindow_FindWindowByLabel(IntPtr label, IntPtr parent);
		[DllImport("wx-c")] static extern IntPtr wxWindow_GetEventHandler(IntPtr self);
		[DllImport("wx-c")] static extern void   wxWindow_SetEventHandler(IntPtr self, IntPtr handler);
		[DllImport("wx-c")] static extern void   wxWindow_PushEventHandler(IntPtr self, IntPtr handler);
		[DllImport("wx-c")] static extern IntPtr wxWindow_PopEventHandler(IntPtr self, bool deleteHandler);
        [DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)] static extern bool wxWindow_RemoveEventHandler(IntPtr self, IntPtr handler);
		//[DllImport("wx-c")] static extern void   wxWindow_SetValidator(IntPtr self, IntPtr validator);
		//[DllImport("wx-c")] static extern IntPtr wxWindow_GetValidator(IntPtr self);
        //[DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)] static extern bool wxWindow_Validate(IntPtr self);
        //[DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)] static extern bool wxWindow_TransferDataToWindow(IntPtr self);
        //[DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)] static extern bool wxWindow_TransferDataFromWindow(IntPtr self);
		//[DllImport("wx-c")] static extern void   wxWindow_InitDialog(IntPtr self);
		[DllImport("wx-c")] static extern void   wxWindow_SetAcceleratorTable(IntPtr self, IntPtr accel);
		[DllImport("wx-c")] static extern IntPtr wxWindow_GetAcceleratorTable(IntPtr self);
		[DllImport("wx-c")] static extern void   wxWindow_ConvertPixelsToDialogPoint(IntPtr self, ref Point pt, out Point point);
		[DllImport("wx-c")] static extern void   wxWindow_ConvertDialogToPixelsPoint(IntPtr self, ref Point pt, out Point point);
		[DllImport("wx-c")] static extern void   wxWindow_ConvertPixelsToDialogSize(IntPtr self, ref Size sz, out Size size);
		//[DllImport("wx-c")] static extern void   wxWindow_ConvertDialogToPixelsSize(IntPtr self, ref Size sz, out Size size);
		[DllImport("wx-c")] static extern void   wxWindow_WarpPointer(IntPtr self, int x, int y);
		[DllImport("wx-c")] static extern void   wxWindow_CaptureMouse(IntPtr self);
		[DllImport("wx-c")] static extern void   wxWindow_ReleaseMouse(IntPtr self);
		[DllImport("wx-c")] static extern IntPtr wxWindow_GetCapture();
        [DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)] static extern bool wxWindow_HasCapture(IntPtr self);
		[DllImport("wx-c")] static extern void   wxWindow_Refresh(IntPtr self, bool eraseBackground, ref Rectangle rect);
		[DllImport("wx-c")] static extern void   wxWindow_RefreshRect(IntPtr self, ref Rectangle rect);
		[DllImport("wx-c")] static extern void   wxWindow_Update(IntPtr self);
		[DllImport("wx-c")] static extern void   wxWindow_ClearBackground(IntPtr self);
		[DllImport("wx-c")] static extern void   wxWindow_Freeze(IntPtr self);
		[DllImport("wx-c")] static extern void   wxWindow_Thaw(IntPtr self);
		[DllImport("wx-c")] static extern void   wxWindow_PrepareDC(IntPtr self, IntPtr dc);
        [DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)] static extern bool wxWindow_IsExposed(IntPtr self, int x, int y, int w, int h);
		[DllImport("wx-c")] static extern void   wxWindow_SetCaret(IntPtr self, IntPtr caret);
		[DllImport("wx-c")] static extern IntPtr wxWindow_GetCaret(IntPtr self);
		[DllImport("wx-c")] static extern int    wxWindow_GetCharHeight(IntPtr self);
		[DllImport("wx-c")] static extern int    wxWindow_GetCharWidth(IntPtr self);
		[DllImport("wx-c")] static extern void   wxWindow_GetTextExtent(IntPtr self, IntPtr str, out int x, out int y, out int descent, out int externalLeading, IntPtr theFont);
		[DllImport("wx-c")] static extern void   wxWindow_ClientToScreen(IntPtr self, ref int x, ref int y);
		[DllImport("wx-c")] static extern void   wxWindow_ScreenToClient(IntPtr self, ref int x, ref int y);
		[DllImport("wx-c")] static extern void   wxWindow_ClientToScreen(IntPtr self, ref Point pt, out Point point);
		[DllImport("wx-c")] static extern void   wxWindow_ScreenToClient(IntPtr self, ref Point pt, out Point point);
		//[DllImport("wx-c")] static extern wxHitTest wxWindow_HitTest(IntPtr self, Coord x, Coord y);
		//[DllImport("wx-c")] static extern wxHitTest wxWindow_HitTest(IntPtr self, ref Point pt);
		[DllImport("wx-c")] static extern int    wxWindow_GetBorder(IntPtr self);
		[DllImport("wx-c")] static extern int    wxWindow_GetBorderByFlags(IntPtr self, uint flags);
		[DllImport("wx-c")] static extern void   wxWindow_UpdateWindowUI(IntPtr self);
        [DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)] static extern bool wxWindow_PopupMenu(IntPtr self, IntPtr menu, ref Point pos);
        [DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)] static extern bool wxWindow_HasScrollbar(IntPtr self, int orient);
		[DllImport("wx-c")] static extern void   wxWindow_SetScrollbar(IntPtr self, int orient, int pos, int thumbvisible, int range, bool refresh);
		[DllImport("wx-c")] static extern void   wxWindow_SetScrollPos(IntPtr self, int orient, int pos, bool refresh);
		[DllImport("wx-c")] static extern int    wxWindow_GetScrollPos(IntPtr self, int orient);
		[DllImport("wx-c")] static extern int    wxWindow_GetScrollThumb(IntPtr self, int orient);
		[DllImport("wx-c")] static extern int    wxWindow_GetScrollRange(IntPtr self, int orient);
		[DllImport("wx-c")] static extern void   wxWindow_ScrollWindow(IntPtr self, int dx, int dy, ref Rectangle rect);
        [DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)] static extern bool wxWindow_ScrollLines(IntPtr self, int lines);
        [DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)] static extern bool wxWindow_ScrollPages(IntPtr self, int pages);
        [DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)] static extern bool wxWindow_LineUp(IntPtr self);
        [DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)] static extern bool wxWindow_LineDown(IntPtr self);
        [DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)] static extern bool wxWindow_PageUp(IntPtr self);
        [DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)] static extern bool wxWindow_PageDown(IntPtr self);
		[DllImport("wx-c")] static extern void   wxWindow_SetHelpText(IntPtr self, IntPtr text);
		[DllImport("wx-c")] static extern void   wxWindow_SetHelpTextForId(IntPtr self, IntPtr text);
		[DllImport("wx-c")] static extern IntPtr wxWindow_GetHelpText(IntPtr self);
		[DllImport("wx-c")] static extern void   wxWindow_SetDropTarget(IntPtr self, IntPtr dropTarget);
		[DllImport("wx-c")] static extern IntPtr wxWindow_GetDropTarget(IntPtr self);
		//[DllImport("wx-c")] static extern void   wxWindow_SetConstraints(IntPtr self, IntPtr constraints);
		//[DllImport("wx-c")] static extern IntPtr wxWindow_GetConstraints(IntPtr self);
        [DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)] static extern bool wxWindow_GetAutoLayout(IntPtr self);
		[DllImport("wx-c")] static extern void   wxWindow_SetSizerAndFit(IntPtr self, IntPtr sizer, bool deleteOld);
		[DllImport("wx-c")] static extern IntPtr wxWindow_GetSizer(IntPtr self);
		[DllImport("wx-c")] static extern void   wxWindow_SetContainingSizer(IntPtr self, IntPtr sizer);
		[DllImport("wx-c")] static extern IntPtr wxWindow_GetContainingSizer(IntPtr self);
		[DllImport("wx-c")] static extern IntPtr wxWindow_GetPalette(IntPtr self);
		[DllImport("wx-c")] static extern void   wxWindow_SetPalette(IntPtr self, IntPtr pal);
        [DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)] static extern bool wxWindow_HasCustomPalette(IntPtr self);
		[DllImport("wx-c")] static extern IntPtr wxWindow_GetUpdateRegion(IntPtr self);
		
		[DllImport("wx-c")] static extern void   wxWindow_SetWindowVariant(IntPtr self, int variant);
		[DllImport("wx-c")] static extern int    wxWindow_GetWindowVariant(IntPtr self);
        [DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)] static extern bool wxWindow_IsBeingDeleted(IntPtr self);
		[DllImport("wx-c")] static extern void   wxWindow_InvalidateBestSize(IntPtr self);
		[DllImport("wx-c")] static extern void   wxWindow_CacheBestSize(IntPtr self, ref Size size);
        [DllImport("wx-c")]
        static extern void wxWindow_GetEffectiveMinSize(IntPtr self, ref Size size);
        [DllImport("wx-c")]
        static extern void wxWindow_SetInitialSize(IntPtr self, ref Size size);
		[DllImport("wx-c")] static extern IntPtr wxWindow_GetChildren(IntPtr self, int num);
		[DllImport("wx-c")] static extern int    wxWindow_GetChildrenCount(IntPtr self);
		[DllImport("wx-c")] static extern IntPtr wxWindow_GetDefaultAttributes(IntPtr self);
		[DllImport("wx-c")] static extern IntPtr wxWindow_GetClassDefaultAttributes(int variant);
		[DllImport("wx-c")] static extern void   wxWindow_SetBackgroundStyle(IntPtr self, uint style);
		[DllImport("wx-c")] static extern int    wxWindow_GetBackgroundStyle(IntPtr self);
		[DllImport("wx-c")] static extern IntPtr wxWindow_GetAncestorWithCustomPalette(IntPtr self);
		[DllImport("wx-c")] static extern void   wxWindow_InheritAttributes(IntPtr self);
        [DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)] static extern bool wxWindow_ShouldInheritColours(IntPtr self);

		//---------------------------------------------------------------------

        /** <summary>Default position.
         * Use this when you are allowed to provide a position
         * but you do not want to provide a particular position.
         * </summary>
         */
        public static readonly Point wxDefaultPosition = new Point(-1, -1);
        /** <summary>Default size.
         * Use this when you are allowed to provide a size
         * but you do not want to specify a particular size.</summary>
         */
        public static readonly Size wxDefaultSize = new Size(-1, -1);
        /** <summary>Default coordinate.
         * Use this when you are allowed to provide a coordinate
         * but you do not want to provide information on a particular coordinate.</summary>
         */
        public static readonly int wxDefaultCoord = -1;

        /// <summary>
        /// In addition to the client data concept in wxWidgets, wx.NET offers you the 
        /// option to tag each window with client data. The motivation for this: When
        /// you deal with events, you usually know the sender. You may use the client data
        /// to attach data to the sender that is required to deal with the event. For instance,
        /// you may have a button that shall have an effect on a particular widget. You may
        /// ease implementation of such a solution assigning the widget to the button's
        /// client data. Thus, the event handler may retrieve the widgets that is required
        /// to implement the action directly from the control that caused the action.
        /// </summary>
        public object ClientData = null;

		//---------------------------------------------------------------------

		public Window(Window parent)
			: this(parent, -1, wxDefaultPosition, wxDefaultSize, wx.WindowStyles.NO_STYLE, null)
        {
        }

        public Window(Window parent, int id, Point pos, Size size, wx.WindowStyles style, string name)
            : this(parent, id, pos, size, style, wxString.SafeNew(name))
        {
        }
        public Window(Window parent, int id, Point pos, Size size, wx.WindowStyles style, wxString name)
			: this(wxWindow_ctor(Object.SafePtr(parent), id, pos.X, pos.Y, size.Width, size.Height, (uint)style, Object.SafePtr(name)), true)
        {
        }

        public Window(Window parent, Point pos, Size size, WindowStyles style, string name)
			: this(parent, Window.UniqueID, pos, size, style, name)
        {
        }


        //InternalValidator _internalValidator;
		public Window(IntPtr wxObject) 
			: base(wxObject)
		{
            memOwn = true;

//            this._internalValidator = new InternalValidator(this.TransferDataFromWindow);
//            wxWindow_RegisterValidator(this.wxObject, this._internalValidator);
            AddEventListener(Event.wxEVT_OBJECTDELETED, new EventListener(OnObjectDeleted));
        }
		
		internal Window(IntPtr wxObject, bool memOwn)
			: base(wxObject)
		{ 
			this.memOwn = memOwn;
			this.wxObject = wxObject;

            //this._internalValidator = new InternalValidator(this.TransferDataFromWindow);
//            wxWindow_RegisterValidator(this.wxObject, this._internalValidator);
            AddEventListener(Event.wxEVT_OBJECTDELETED, new EventListener(OnObjectDeleted));
        }

        /** <summary>Simply a delegator for validation.
         * Asign <c>false</c> to the argument if you want to indicate</summary>*/
        public delegate void Validator(ref bool accepted);

        /** <summary>This will be called on <c>wxWindow</c>::TransferDataFromWindow.
         * This is the right place for validation.</summary>*/
        public event Validator OnTransferDataFromWindow;

        char TransferDataFromWindow()
        {
            if (this.OnTransferDataFromWindow != null)
            {
                bool accepted = true;
                this.OnTransferDataFromWindow(ref accepted);
                return accepted ? (char)255 : (char)0;
            }
            else
                return (char)255;
        }

        /** <summary>Overriden disposition.
         * Even if we do not own the memory, we have to delete the window, since this
         * is apparently intended by the user calling this method.</summary>*/
        protected override void Dispose(bool disposing)
        {
            if (!this.memOwn && !this.disposed)
                this.Destroy();
            base.Dispose(disposing);
        }


		//---------------------------------------------------------------------

		public virtual Colour BackgroundColour
		{
			set
			{
				wxWindow_SetBackgroundColour(wxObject, Object.SafePtr(value));
			}
			get
			{
				return new Colour(wxWindow_GetBackgroundColour(wxObject), true);
			}
		}

		public virtual Colour ForegroundColour
		{
			get
			{
				return new Colour(wxWindow_GetForegroundColour(wxObject), true);
			}
			set
			{
				wxWindow_SetForegroundColour(wxObject, Object.SafePtr(value));
			}
		}

		//---------------------------------------------------------------------

		// Note: was previously defined as WindowFont
		public virtual Font Font
		{
			set
			{
				wxWindow_SetFont(wxObject, value.wxObject);
			}
			
			get
			{
				return new Font(wxWindow_GetFont(wxObject), true);
			}
		}


		//---------------------------------------------------------------------

		public virtual Size BestSize
		{
			get
			{
				Size size;
				wxWindow_GetBestSize(wxObject, out size);
				return size;
			}
		}

		//---------------------------------------------------------------------

		public Size ClientSize
		{
			get
			{
				Size size = new Size();
				wxWindow_GetClientSize(wxObject, out size);
				return size;
			}
			set
			{
				wxWindow_SetClientSize(wxObject, value.Width, value.Height);
			}
		}

		//---------------------------------------------------------------------

        /** <summary>This function simply generates a wxCloseEvent whose handler usually tries to close the window.
         * It doesn't close the window itself, however.
         *
         * Close calls the close handler for the window, providing an opportunity for the window to choose whether to destroy
         * the window. Usually it is only used with the top level windows (wx.Frame and wx.Dialog classes) as the others are
         * not supposed to have any special <c>OnClose()</c> logic.
         *
         * The close handler should check whether the window is being deleted forcibly, using wx.CloseEvent.CanVeto, in which
         * case it should destroy the window using wx.Window.Destroy().
         *
         * Note that calling <c>Close()</c> does not guarantee that the window will be destroyed; but it provides a way to simulate a manual
         * close of a window, which may or may not be implemented by destroying the window. The default implementation of
         * <c>wx.Dialog.OnCloseWindow()</c> does not necessarily delete the dialog, since it will simply simulate an <c>wxID_CANCEL</c> event
         * which is handled by the appropriate button event handler and may do anything at all.
         *
         * To guarantee that the window will be destroyed, call wx.Window.Destroy instead.</summary>*/
		public bool Close()
		{
			return wxWindow_Close(wxObject, false);
		}

        /** <summary>This will create a <c>wx.CloseEvent</c> but handlers are not allowed to veto if <c>force</c> is <c>true</c>.
         * Try wx.Utils.Exit() if you want the application to be exited. Otherwise, the application will exit
         * automatically, if all top level windows are closed.
         * 
         * Refer also to Close().</summary>*/
		public bool Close(bool force)
		{
			return wxWindow_Close(wxObject, force);
		}

		//---------------------------------------------------------------------

		public int ID 
		{
			get { return wxWindow_GetId(wxObject); }
			set { wxWindow_SetId(wxObject, value); }
		}
		
		//---------------------------------------------------------------------
		
        /** <summary>This always returns a unique ID that is appropriate to denote windows.</summary>*/
		public static int UniqueID
		{
			get {
				uniqueID++;
				return uniqueID;
			}
		}
		
		//---------------------------------------------------------------------

		public void Layout()
		{
			wxWindow_Layout(wxObject);
		}

		//---------------------------------------------------------------------

		public Cursor Cursor 
		{
            get { return Cursor.SafeNew(wxWindow_GetCursor(this.wxObject)); }
			set { wxWindow_SetCursor(wxObject, Object.SafePtr(value)); }
		}

		//---------------------------------------------------------------------

		public void SetSize(int x, int y, int width, int height)
		{
			wxWindow_SetSize(wxObject, x, y, width, height, 0);
		}
		
		public void SetSize(int width, int height)
		{
			wxWindow_SetSize2(wxObject, width, height);
		}
		
		public void SetSize(Size size)
		{
			wxWindow_SetSize3(wxObject, ref size);
		}

		//---------------------------------------------------------------------

		public void SetSizer(Sizer sizer )
		{ 
			SetSizer( sizer, true); 
		}

		public void SetSizer(Sizer sizer, bool deleteOld)
		{
			wxWindow_SetSizer(wxObject, sizer.wxObject, deleteOld);
		}

		//---------------------------------------------------------------------

        /** <summary>Shows or hides the window.
         * You may need to call Raise() for a top level window if you want to bring it to top, although this
         * is not needed if Show() is called immediately after the frame creation.
         * </summary>
         * <returns>true if the window has been shown or hidden or false if nothing was done because
         * it already was in the requested state.</returns>
         * <seealso cref="IsShown"/>
         * <seealso cref="Hide"/>
         * <seealso cref="Raise"/>
         */
        public bool Show()
		{
			return Show(true);
		}

        /** <summary>Shows or hides the window.
         * You may need to call Raise() for a top level window if you want to bring it to top, although this
         * is not needed if Show() is called immediately after the frame creation.
         * </summary>
         * <param name="show">If true displays the window. Otherwise, hides it.</param>
         * <returns>true if the window has been shown or hidden or false if nothing was done because
         * it already was in the requested state.</returns>
         * <seealso cref="IsShown"/>
         * <seealso cref="Hide"/>
         * <seealso cref="Raise"/>
         */
        public bool Show(bool show)
		{
			return wxWindow_Show(wxObject, show);
		}

		//---------------------------------------------------------------------

        /** <summary>This will set or get the styles flags that define this window.</summary>*/
		public virtual WindowStyles StyleFlags
		{
			get
			{
				return (WindowStyles) wxWindow_GetWindowStyleFlag(this.wxObject);
			}
			set
			{
				wxWindow_SetWindowStyleFlag(wxObject, (uint) value);
			}
		}

        //---------------------------------------------------------------------

        new private void OnObjectDeleted(object sender, Event e)
        {
            this.VirtualDispose();
            e.Skip();
        }

		//---------------------------------------------------------------------

		public virtual string ToolTip
		{
            get
            {
                return new wxString(wxWindow_GetToolTip(this.wxObject));
            }
			set
			{
                wxString wxvalue = wxString.SafeNew(value);
				wxWindow_SetToolTip(wxObject, Object.SafePtr(wxvalue));
			}
		}

		//---------------------------------------------------------------------

        /** <summary>Returns true iff enabled.</summary>*/
        public bool IsEnabled()
        {
            return wxWindow_IsEnabled(wxObject);
        }

        /** <summary>Enable or disable cf. read whether enabled or disabled.</summary>*/
		public virtual bool Enabled
		{
			set
			{
				wxWindow_Enable(wxObject, value);
			}
			get
			{
				return this.IsEnabled();
			}
		}

		//---------------------------------------------------------------------

        /** <summary>Destroy the window.
         * Call this only is you do not want to show it again.</summary>*/
		public virtual bool Destroy()
		{
            if (wxObject != IntPtr.Zero)
            {
                bool result = wxWindow_Destroy(wxObject);
                this.wxObject = IntPtr.Zero;
                return result;
            }
            else
                return false;
		}

        /** <summary>Destroy the window's children.
         * Call this only is you do not want to show them again.</summary>*/
        public virtual bool DestroyChildren()
		{
            if (wxObject != IntPtr.Zero)
                return wxWindow_DestroyChildren(wxObject);
            else
                return false;
        }

		//---------------------------------------------------------------------

		public virtual string Title
		{
			set
			{
                wxString wxvalue = wxString.SafeNew(value);
				wxWindow_SetTitle(wxObject, Object.SafePtr(wxvalue));
			}
			get
			{
				return new wxString(wxWindow_GetTitle(wxObject), true);
			}
		}

		//---------------------------------------------------------------------

		public virtual string Name
		{
			set
			{
                wxString wxvalue = wxString.SafeNew(value);
				wxWindow_SetName(wxObject, Object.SafePtr(wxvalue));
			}
			get
			{
				return new wxString(wxWindow_GetName(wxObject), true);
			}
		}

		//---------------------------------------------------------------------

        /** <summary>Generate a control id for the controls which were not given one by
         * user.
         * 
         *  wx.NET provides property wx.Window.UniqueID to generate unqie IDs
         * which are appropriate to designate windows.</summary>*/
        public static int NewControlId()
		{
			return wxWindow_NewControlId();
		}

        /** <summary>Get the id of the control following the one with the given
          * (autogenerated) id.</summary>*/
		public static int NextControlId(int id)
		{
			return wxWindow_NextControlId(id);
		}

        /** <summary>Get the id of the control preceding the one with the given
          * (autogenerated) id</summary>*/
		public static int PrevControlId(int id)
		{
			return wxWindow_PrevControlId(id);
		}

		//---------------------------------------------------------------------

		public virtual void Move(int x, int y, int flags)
		{
			wxWindow_Move(wxObject, x, y, flags);
		}

		//---------------------------------------------------------------------

        /** <summary>Raises the window to the top of the window hierarchy (z-order).
         *In current version of wxWidgets this works both for managed and child windows.
         * </summary>
         * <seealso cref="Lower"/>
         */
		public virtual void Raise()
		{
			wxWindow_Raise(wxObject);
		}


        /// <summary>
        /// Lowers the window to the bottom of the window hierarchy (z-order).
        /// </summary>
        /// <seealso cref="Raise"/>
		public virtual void Lower()
		{
			wxWindow_Lower(wxObject);
		}

		//---------------------------------------------------------------------

		public virtual Point Position
		{
			get
			{
				Point point = new Point();
				wxWindow_GetPosition(wxObject, out point);
				return point;
			}
			set
			{
				Move(value.X, value.Y, 0);
			}
		}

		//---------------------------------------------------------------------

		public virtual Size Size
		{
			get
			{
				Size size = new Size();
				wxWindow_GetSize(wxObject, out size);
				return size;
			}
			set
			{
				wxWindow_SetSize(wxObject, Position.X, Position.Y,
								 value.Width, value.Height, 0);
			}
		}

		//---------------------------------------------------------------------

		public virtual Rectangle Rect
		{
			get
			{
				Rectangle rect = new Rectangle();
				wxWindow_GetRect(wxObject, out rect);
				return rect;
			}
		}

		//---------------------------------------------------------------------

		public virtual Point ClientAreaOrigin
		{
			get 
			{
				Point point = new Point();
				wxWindow_GetClientAreaOrigin(wxObject, out point);
				return point;
			}
		}

		//---------------------------------------------------------------------

		public virtual Rectangle ClientRect
		{
			get
			{
				Rectangle rect = new Rectangle();
				wxWindow_GetClientRect(wxObject, out rect);
				return rect;
			}
		}

		//---------------------------------------------------------------------

		public virtual Size AdjustedBestSize
		{
			get { 
				Size size = new Size();
				wxWindow_GetAdjustedBestSize(wxObject, out size);
				return size;
			}
		}

		//---------------------------------------------------------------------

		public void Centre()
		{ 
			Center( Orientation.wxBOTH ); 
		}
		
		public void Center()
		{ 
			Center( Orientation.wxBOTH ); 
		}
		
		public void Centre(Orientation direction)
		{ 
			Center( direction ); 
		}
		
		public void Center(Orientation direction)
		{
			wxWindow_Center(wxObject, (int)direction);
		}

		public void CentreOnScreen()
		{ 
			CenterOnScreen( Orientation.wxBOTH ); 
		}
		
		public void CenterOnScreen()
		{ 
			CenterOnScreen( Orientation.wxBOTH ); 
		}
		
		public void CentreOnScreen(Orientation direction)
		{ 
			CenterOnScreen( direction ); 
		}
		
		public void CenterOnScreen(Orientation direction)
		{
			wxWindow_CenterOnScreen(wxObject, (int)direction);
		}

        /// <summary>
        /// Centres the window on its parent. This is a more readable synonym for Centre.
        /// This methods provides for a way to center top level windows over their parents instead of the entire screen.
        /// If there is no parent or if the window is not a top level window, then behaviour is the same as wx.Window.Centre().
        /// </summary>
        public void CentreOnParent()
		{ 
			CenterOnParent( Orientation.wxBOTH ); 
		}

        /// <summary>
        /// Centres the window on its parent. This is a more readable synonym for Centre.
        /// This methods provides for a way to center top level windows over their parents instead of the entire screen.
        /// If there is no parent or if the window is not a top level window, then behaviour is the same as wx.Window.Centre().
        /// </summary>
        public void CenterOnParent()
		{ 
			CenterOnParent( Orientation.wxBOTH ); 
		}

        /// <summary>
        /// Centres the window on its parent. This is a more readable synonym for Centre.
        /// This methods provides for a way to center top level windows over their parents instead of the entire screen.
        /// If there is no parent or if the window is not a top level window, then behaviour is the same as wx.Window.Centre().
        /// </summary>
        /// <param name="direction">Specifies the direction for the centering. May be Orientation.wxHORIZONTAL,
        /// Orientation.wxVERTICAL or Orientation.wxBOTH.
        /// </param>
        public void CentreOnParent(Orientation direction)
		{ 
			CenterOnParent( direction ); 
		}
		
        /// <summary>
        /// Centres the window on its parent. This is a more readable synonym for Centre.
        /// This methods provides for a way to center top level windows over their parents instead of the entire screen.
        /// If there is no parent or if the window is not a top level window, then behaviour is the same as wx.Window.Centre().
        /// </summary>
        /// <param name="direction">Specifies the direction for the centering. May be Orientation.wxHORIZONTAL,
        /// Orientation.wxVERTICAL or Orientation.wxBOTH.
        /// </param>
		public void CenterOnParent(Orientation direction)
		{
			wxWindow_CenterOnParent(wxObject, (int)direction);
		}

		//---------------------------------------------------------------------

        /// <summary>
        /// Sizes the window so that it fits around its subwindows. This function won't do anything if there
        /// are no subwindows and will only really work correctly if the sizers are used for the subwindows layout.
        /// </summary>
        /// <remarks>
        /// Also, if the window has exactly one subwindow it is better (faster and the result is more precise as
        /// Fit() adds some margin to account for fuzziness of its calculations) to call
        /// <code>
        ///  window->SetClientSize(child->GetSize());
        /// </code>
        /// instead of calling Fit.
        /// </remarks>
		public void Fit()
		{
			wxWindow_Fit(wxObject);
		}

        /// <summary>
        /// Similar to Fit, but sizes the interior (virtual) size of a window.
        /// Mainly useful with scrolled windows to reset scrollbars after sizing changes that do not trigger
        /// a size event, and/or scrolled windows without an interior sizer.
        /// This function similarly won't do anything if there are no subwindows.
        /// </summary>
		public void FitInside()
		{
			wxWindow_FitInside(wxObject);
		}

		//---------------------------------------------------------------------

        /// <summary>
        /// Use of this function for windows which are not toplevel windows (such as wxDialog or wx.Frame) is discouraged.
        /// Please assign to <c>MinSize</c> and <c>MaxSize</c> instead.
        /// </summary>
        /// <param name="minimalSize">Minimal size of the dialog or frame that will be propagated to the size of the children.</param>
        public void SetSizeHints(Size minimalSize)
        {
            SetSizeHints(minimalSize.Width, minimalSize.Height, -1, -1, -1, -1);
        }

        /// <summary>
        /// Use of this function for windows which are not toplevel windows (such as wxDialog or wx.Frame) is discouraged.
        /// Please assign to <c>MinSize</c> and <c>MaxSize</c> instead.
        /// </summary>
        /// <param name="minW">Minimal width of the dialog or frame that will be propagated to the size of the children.</param>
        /// <param name="minH">Minimal width of the dialog or frame that will be propagated to the size of the children.</param>
		public void SetSizeHints(int minW, int minH)
		{ 
			SetSizeHints(minW, minH, -1, -1, -1, -1); 
		}

        /// <summary>
        /// Use of this function for windows which are not toplevel windows (such as wxDialog or wx.Frame) is discouraged.
        /// Please assign to <c>MinSize</c> and <c>MaxSize</c> instead.
        /// </summary>
        public void SetSizeHints(int minW, int minH, int maxW, int maxH)
		{ 
			SetSizeHints(minW, minH, maxW, maxH, -1, -1); 
		}

        /// <summary>
        /// Use of this function for windows which are not toplevel windows (such as wxDialog or wx.Frame) is discouraged.
        /// Please assign to <c>MinSize</c> and <c>MaxSize</c> instead.
        /// </summary>
        public void SetSizeHints(int minW, int minH, int maxW, int maxH, int incW, int incH)
		{
			wxWindow_SetSizeHints(wxObject, minW, minH, maxW, maxH, incW, incH);
		}

		public void SetVirtualSizeHints(int minW, int minH, int maxW, int maxH)
		{
			wxWindow_SetVirtualSizeHints(wxObject, minW, minH, maxW, maxH);
		}

		//---------------------------------------------------------------------

        /** <summary>Get or set the minimal width of the window.</summary>*/
        public int MinWidth
		{
			get
			{
				return wxWindow_GetMinWidth(wxObject);
			}
            set
            {
                this.MinSize = new Size(value, this.MinHeight);
            }
        }

        /** <summary>Get or set the minimal height of the window.</summary>*/
        public int MinHeight
		{
			get
			{
				return wxWindow_GetMinHeight(wxObject);
			}
            set
            {
                this.MinSize = new Size(this.MinWidth, value);
            }
		}

        /** <summary>Read and set the minimum size of the window.
         * This should be set after changing the size for instance after construction and before
         * adding this to tha parent sizer.
         * However, you should consider to set size hints instead of using this method.</summary>*/
        public Size MinSize
        {
            get { return new Size(this.MinWidth, this.MinHeight); }
            set { wxWindow_SetMinSize(this.wxObject, value.Width, value.Height); }
        }

        /** <summary>This is a read-only property. Use wx.Window.MaxSize to change this.</summary>*/
		public int MaxWidth
		{
			get
			{
				return wxWindow_GetMaxWidth(wxObject);
			}
		}

		public int MaxHeight
		{
			get
			{
				return wxWindow_GetMaxHeight(wxObject);
			}
		}

        /** <summary>Read and set the maximum size of the window.
         * This should be set after changing the size for instance after construction and before
         * adding this to tha parent sizer.
         * However, you should consider to set size hints instead of using this method.</summary>*/
        public Size MaxSize
        {
            get { return new Size(this.MaxWidth, this.MaxHeight); }
            set { wxWindow_SetMaxSize(this.wxObject, value.Width, value.Height); }
        }


		//---------------------------------------------------------------------

		public Size VirtualSize
		{
			get
			{
				Size size = new Size();
				wxWindow_GetVirtualSize(wxObject, out size);
				return size;
			}
			set
			{
				wxWindow_SetVirtualSize(wxObject, value.Width, value.Height);
			}
		}

		//---------------------------------------------------------------------

		public Size BestVirtualSize
		{
			get {
				Size size = new Size();
				wxWindow_GetBestVirtualSize(wxObject, out size);
				return size;
			}
		}

		//---------------------------------------------------------------------

		public bool Hide()
		{
			return wxWindow_Hide(wxObject);
		}

		public bool Disable()
		{
			return wxWindow_Disable(wxObject);
		}

		public bool IsShown
		{
			get { return wxWindow_IsShown(wxObject); }
		}

		//---------------------------------------------------------------------

		public wx.WindowStyles WindowStyle
		{
			get
			{
				return (wx.WindowStyles)wxWindow_GetWindowStyle(wxObject);
			}
			set
			{
				wxWindow_SetWindowStyle(wxObject, (uint)value);
			}
		}

        /** <summary>True if the designated style flag has been set for this window.</summary>*/
		public virtual bool HasFlag(WindowStyles flag)
		{
			return wxWindow_HasFlag(wxObject, (uint)flag);
		}

		//---------------------------------------------------------------------

        /// <summary>
        /// Returns true if the window is retained, false otherwise.
        ///
        /// Remarks: Retained windows are only available on X platforms.
        /// </summary>
		public bool IsRetained
		{
			get { return wxWindow_IsRetained(wxObject); }
		}

		//---------------------------------------------------------------------

		public virtual uint ExtraStyle
		{
			get
			{
				return wxWindow_GetExtraStyle(this.wxObject);
			}
			set
			{
				wxWindow_SetExtraStyle(wxObject, value);
			}
		}

		//---------------------------------------------------------------------

		public bool ThemeEnabled
		{
			get
			{
				return wxWindow_GetThemeEnabled(wxObject);
			}
			set
			{
				wxWindow_SetThemeEnabled(wxObject, value);
			}
		}

		//---------------------------------------------------------------------

        /** <summary>This sets the window to receive keyboard input.
         * Please note, that this method cannot be overridden from any class.
         * Currently, inheritors of <c>wx.Panel</c> and <c>wx.Dialog</c> can override this.</summary>*/
        public virtual void SetFocus()
		{
			wxWindow_SetFocus(wxObject);
		}

        /** <summary>This function is called by  wxWidgets keyboard navigation code
         * when the user gives the focus to this window from keyboard (e.g. using TAB key).
         * By default this method simply calls <c>SetFocus</c> but can be overridden to do something in addition
         * to this in the derived classes.
         * Please note, that this method cannot be overridden from any class.
         * Currently, inheritors of <c>wx.Panel</c> and <c>wx.Dialog</c> can override this.</summary>*/
        public virtual void SetFocusFromKbd()
		{
			wxWindow_SetFocusFromKbd(wxObject);
		}

        /// <summary>
        /// Finds the window or control which currently has the keyboard focus.
        /// 
        /// Note that this is a static function, so it can be called without needing a wx.Window pointer.
        /// </summary>
		public static Window FindFocus()
		{
			return (Window)FindObject(wxWindow_FindFocus());
		}

		//---------------------------------------------------------------------

        /// <summary>
        /// can this window have focus?
        /// </summary>
		public virtual bool AcceptsFocus()
		{
			return wxWindow_AcceptsFocus(wxObject);
		}

        /// <summary>
        /// can this window be given focus by keyboard navigation? if not, the
        /// only way to give it focus (provided it accepts it at all) is to
        /// click it
        /// </summary>
        public virtual bool AcceptsFocusFromKeyboard()
		{
			return wxWindow_AcceptsFocusFromKeyboard(wxObject);
		}

		//---------------------------------------------------------------------

		public virtual Window Parent
		{
			get { return (Window)FindObject(wxWindow_GetParent(wxObject)); }
			set { wxWindow_SetParent(wxObject, Object.SafePtr(value)); }
		}

		public virtual Window GrandParent
		{
			get { return (Window)FindObject(wxWindow_GetGrandParent(wxObject)); }
		}

		public virtual bool Reparent(Window newParent)
		{
			return wxWindow_Reparent(wxObject, Object.SafePtr(newParent));
		}

		//---------------------------------------------------------------------

		public virtual bool IsTopLevel
		{
			get { return wxWindow_IsTopLevel(wxObject); }
		}
		//---------------------------------------------------------------------

        /// <summary>
        /// Adds a child window. This is called automatically by window creation functions so should not be required by the application programmer.
        ///
        /// Notice that this function is mostly internal to wxWidgets and shouldn't be called by the user code.
        /// </summary>
        /// <param name="child">Child window to add.</param>
        /*
		public void AddChild(Window child)
		{
			wxWindow_AddChild(wxObject, Object.SafePtr(child));
		}

		public virtual void RemoveChild(Window child)
		{
			wxWindow_RemoveChild(wxObject, Object.SafePtr(child));
		}
        */

		//---------------------------------------------------------------------

		public virtual Window FindWindow(int id)
		{
			return (Window)FindObject(wxWindow_FindWindowId(wxObject, id));
		}

        /** <summary>This will find the window of the provided <c>id</c> and or create one of class <c>type</c>.
         * </summary>
         */
		public virtual Window FindWindow(int id, Type type)
		{
            // Windows will usually generated with memory ownership.
			return (Window)FindObject(wxWindow_FindWindowId(wxObject, id), type, true);
		}

        public virtual Window FindWindow(string name)
        {
            return this.FindWindow(wxString.SafeNew(name));
        }
		public virtual Window FindWindow(wxString name)
		{
			return (Window)FindObject(wxWindow_FindWindowName(wxObject, Object.SafePtr(name)));
		}

		//---------------------------------------------------------------------

		public static Window FindWindowById(int id, Window parent)
		{
			return (Window)FindObject(wxWindow_FindWindowById(id, Object.SafePtr(parent)));
		}

        public static Window FindWindowByName(string name, Window parent)
        {
            return FindWindowByName(wxString.SafeNew(name), parent);
        }
		public static Window FindWindowByName(wxString name, Window parent)
		{
			return (Window)FindObject(wxWindow_FindWindowByName(Object.SafePtr(name), Object.SafePtr(parent)));
		}

        public static Window FindWindowByLabel(string label, Window parent)
        {
            return FindWindowByLabel(wxString.SafeNew(label), parent);
        }
		public static Window FindWindowByLabel(wxString label, Window parent)
		{
			return (Window)FindObject(wxWindow_FindWindowByLabel(Object.SafePtr(label), Object.SafePtr(parent)));
		}

		//---------------------------------------------------------------------

		public EvtHandler EventHandler
		{
			get
			{
				return (EvtHandler)FindObject(
						wxWindow_GetEventHandler(wxObject),
						typeof(EvtHandler)
					);
			}
			set
			{
				wxWindow_SetEventHandler(wxObject, Object.SafePtr(value));
			}
		}

		//---------------------------------------------------------------------

        /** <summary>Pushes this event handler onto the event stack for the window.
          * \param handler Specifies the handler to be pushed.
          * An event handler is an object that is capable of processing the events sent to a window.
         * By default, the window is its own event handler, but an application may wish to substitute another, 
         * for example to allow central implementation of event-handling for a variety of different window classes.
         *
         * wx.Window.PushEventHandler allows an application to set up a chain of event handlers, where an event not
         * handled by one event handler is handed to the next one in the chain. Use wx.Window.PopEventHandler to remove
         * the event handler.</summary>*/
		public void PushEventHandler(EvtHandler handler)
		{
			wxWindow_PushEventHandler(wxObject, Object.SafePtr(handler));
		}

        /** <summary>cf. PushEventHandler().</summary>*/
		public EvtHandler PopEventHandler(bool deleteHandler)
		{
			return (EvtHandler)FindObject(
					wxWindow_PopEventHandler(wxObject, deleteHandler),
					typeof(EvtHandler)
	               );
		}

		public bool RemoveEventHandler(EvtHandler handler)
		{
			return wxWindow_RemoveEventHandler(wxObject, Object.SafePtr(handler));
		}

		public virtual Point ConvertPixelsToDialog(Point pt)
		{
			Point point = new Point();
			wxWindow_ConvertPixelsToDialogPoint(wxObject, ref pt, out point);
			return point;
		}

		public virtual Point ConvertDialogToPixels(Point pt)
		{
			Point point = new Point();
			wxWindow_ConvertDialogToPixelsPoint(wxObject, ref pt, out point);
			return point;
		}

		public virtual Size ConvertPixelsToDialog(Size sz)
		{
			Size size = new Size();
			wxWindow_ConvertPixelsToDialogSize(wxObject, ref sz, out size);
			return size;
		}

		public virtual Size ConvertDialogToPixels(Size sz)
		{
			Size size = new Size();
			wxWindow_ConvertPixelsToDialogSize(wxObject, ref sz, out size);
			return size;
		}

		//---------------------------------------------------------------------

		public virtual void WarpPointer(int x, int y)
		{
			wxWindow_WarpPointer(wxObject, x, y);
		}

        /// <summary>
        /// Directs all mouse input to this window. Call wxWindow::ReleaseMouse to release the capture.
        ///
        /// Note that wxWidgets maintains the stack of windows having captured the mouse and when the mouse is released 
        /// the capture returns to the window which had had captured it previously and it is only really released if there
        /// were no previous window. In particular, this means that you must release the mouse as many times as you capture
        /// it, unless the window receives the wx.MouseCaptureLostEvent event.
        ///
        /// Any application which captures the mouse in the beginning of some operation must handle wx.MouseCaptureLostEvent 
        /// and cancel this operation when it receives the event. The event handler must not recapture mouse.
        /// </summary>
		public virtual void CaptureMouse()
		{
			wxWindow_CaptureMouse(wxObject);
		}

        /// <summary>
        /// Releases mouse input captured with wx.Window.CaptureMouse().
        /// </summary>
        public virtual void ReleaseMouse()
		{
			wxWindow_ReleaseMouse(wxObject);
		}

        /// <summary>
        /// Returns the currently captured window.
        /// </summary>
        /// <seealso cref="CaptureMouse"/>
		public static Window GetCapture()
		{
			return (Window)FindObject(wxWindow_GetCapture());
		}

        /// <summary>
        /// Returns true if this window has the current mouse capture.
        /// </summary>
        /// <seealso cref="CaptureMouse"/>
		public virtual bool HasCapture()
		{
			return wxWindow_HasCapture(wxObject);
		}

		//---------------------------------------------------------------------

		public virtual void Refresh()
		{
			Refresh(true, ClientRect);
		}

		public virtual void Refresh(bool eraseBackground, Rectangle rect)
		{
			wxWindow_Refresh(wxObject, eraseBackground, ref rect);
		}

		public virtual void RefreshRectangle(Rectangle rect)
		{
			wxWindow_RefreshRect(wxObject, ref rect);
		}

		//---------------------------------------------------------------------

		public virtual void Update()
		{
			wxWindow_Update(wxObject);
		}

		public virtual void ClearBackground()
		{
			wxWindow_ClearBackground(wxObject);
		}

		//---------------------------------------------------------------------

		public virtual void Freeze()
		{
			wxWindow_Freeze(wxObject);
		}

		public virtual void Thaw()
		{
			wxWindow_Thaw(wxObject);
		}

		//---------------------------------------------------------------------

        /** <summary>This prepares the argument for drawing.</summary>*/
		public virtual void PrepareDC(DC dc)
		{
			wxWindow_PrepareDC(wxObject, Object.SafePtr(dc));
		}

		//---------------------------------------------------------------------

        /** <summary>Returns true if the given point or rectangle area has been exposed since the last repaint.
         * Call this in an paint event handler to optimize redrawing by only redrawing
         * those areas, which have been exposed.</summary>*/
		public virtual bool IsExposed(int x, int y, int w, int h)
		{
			return wxWindow_IsExposed(wxObject, x, y, w, h);
		}

		//---------------------------------------------------------------------

		public virtual Caret Caret
		{
			get
			{
				return (Caret)Object.FindObject(wxWindow_GetCaret(wxObject),
						typeof(Caret));
			}
			set
			{
				wxWindow_SetCaret(wxObject, Object.SafePtr(value));
			}
		}

		//---------------------------------------------------------------------

		public virtual int CharHeight
		{
			get { return wxWindow_GetCharHeight(wxObject); }
		}

		public virtual int CharWidth
		{
			get { return wxWindow_GetCharWidth(wxObject); }
		}

		//---------------------------------------------------------------------

        public void GetTextExtent(string str, out int x, out int y, out int descent,
                                  out int externalLeading)
        {
            this.GetTextExtent(str, out x, out y, out descent, out externalLeading, null);
        }
        public void GetTextExtent(string str, out int x, out int y, out int descent,
                                  out int externalLeading, Font font)
        {
            this.GetTextExtent(wxString.SafeNew(str), out x, out y, out descent, out externalLeading, font);
        }
		public void GetTextExtent(wxString str, out int x, out int y, out int descent,
								  out int externalLeading, Font font)
		{
			wxWindow_GetTextExtent(wxObject, Object.SafePtr(str), out x, out y, out descent,
								   out externalLeading, Object.SafePtr(font));
		}
        public void GetTextExtent(string str, out int x, out int y)
        {
            this.GetTextExtent(str, out x, out y, null);
        }
		public void GetTextExtent(string str, out int x, out int y, Font font)
		{
		   int descent=0;
		   int externalLeading=0;
		   this.GetTextExtent(str, out x, out y, out descent, out externalLeading, font);
		}

        public Size GetTextExtent(string str)
        {
            int x, y;
            this.GetTextExtent(str, out x, out y, null);
            return new Size(x, y);
        }

		//---------------------------------------------------------------------

		public void ClientToScreen(ref int x, ref int y)
		{
			wxWindow_ClientToScreen(wxObject, ref x, ref y);
		}

		public Point ClientToScreen(Point clientPoint)
		{
			Point screenPoint;
			wxWindow_ClientToScreen(wxObject, ref clientPoint, out screenPoint);
			return screenPoint;
		}

		public virtual void ScreenToClient(ref int x, ref int y)
		{
			wxWindow_ScreenToClient(wxObject, ref x, ref y);
		}

		public Point ScreenToClient(Point screenPoint)
		{
			Point clientPoint;
			wxWindow_ScreenToClient(wxObject, ref screenPoint, out clientPoint);
			return clientPoint;
		}

		//---------------------------------------------------------------------

		public virtual void UpdateWindowUI()
		{
			wxWindow_UpdateWindowUI(wxObject);
		}

		//---------------------------------------------------------------------

        public bool PopupMenu(Menu menu)
        {
            return this.PopupMenu(menu, wxDefaultPosition);
        }

		public virtual bool PopupMenu(Menu menu, Point pos)
		{
            //connecting events should be done before first 
            //PopupMenu call Jacek Trublajewicz <gothic@os.pl>
            menu.ConnectEvents(this);
			bool tmpbool = wxWindow_PopupMenu(wxObject, Object.SafePtr(menu), ref pos);
			return tmpbool;
		}

		//---------------------------------------------------------------------

		public virtual bool HasScrollbar(int orient)
		{
			return wxWindow_HasScrollbar(wxObject, orient);
		}

		public virtual void SetScrollbar(int orient, int pos, int thumbSize, int range, bool refresh)
		{
			wxWindow_SetScrollbar(wxObject, orient, pos, thumbSize, range, refresh);
		}

		public virtual void SetScrollPos(int orient, int pos, bool refresh)
		{
			wxWindow_SetScrollPos(wxObject, orient, pos, refresh);
		}

		//---------------------------------------------------------------------

		public virtual int GetScrollPos(int orient)
		{
			return wxWindow_GetScrollPos(wxObject, orient);
		}

		public virtual int GetScrollThumb(int orient)
		{
			return wxWindow_GetScrollThumb(wxObject, orient);
		}

		public virtual int GetScrollRange(int orient)
		{
			return wxWindow_GetScrollRange(wxObject, orient);
		}

		//---------------------------------------------------------------------

		public virtual void ScrollWindow(int dx, int dy, Rectangle rect)
		{
			wxWindow_ScrollWindow(wxObject, dx, dy, ref rect);
		}

        /// <summary>
        /// Scrolls the window by the given number of lines down (if lines is positive) or up.
        /// </summary>
        /// <param name="lines">Number of lines to scroll down (positive) or up (negative)</param>
        /// <returns>Returns true if the window was scrolled, false if it was already on top/bottom and nothing was done.</returns>
		public virtual bool ScrollLines(int lines)
		{
			return wxWindow_ScrollLines(wxObject, lines);
		}

        /// <summary>
        /// Scrolls the window by the given number of pages down (if pages is positive) or up.
        /// </summary>
        /// <param name="pages">Number of pages to scroll down (positive) or up.</param>
        /// <returns>This function is currently only implemented under MSW and wxGTK.</returns>
		public virtual bool ScrollPages(int pages)
		{
			return wxWindow_ScrollPages(wxObject, pages);
		}

		//---------------------------------------------------------------------

		public virtual bool LineUp()
		{
			return wxWindow_LineUp(wxObject);
		}

		public virtual bool LineDown()
		{
			return wxWindow_LineDown(wxObject);
		}

		public virtual bool PageUp()
		{
			return wxWindow_PageUp(wxObject);
		}

		public virtual bool PageDown()
		{
			return wxWindow_PageDown(wxObject);
		}

		//---------------------------------------------------------------------

        /// <summary>
        /// Refer to wx.Html.HtmlHelpController.
        /// </summary>
		public virtual string HelpText
		{
			get
			{
				return new wxString(wxWindow_GetHelpText(wxObject), true);
			}
			set
			{
                wxString wxvalue = wxString.SafeNew(value);
				wxWindow_SetHelpText(wxObject, Object.SafePtr(wxvalue));
			}
		}

		public virtual void SetHelpTextForId(string text)
		{
            wxString wxtext = wxString.SafeNew(text);
            wxWindow_SetHelpTextForId(wxObject, Object.SafePtr(wxtext));
		}

		//---------------------------------------------------------------------

        /// <summary>
        /// On setting a value: Associates a drop target with this window.
        /// If the window already has a drop target, it is deleted.
        /// On getting the value: Returns the associated drop target, which may be NULL.
        /// </summary>
        /// <remarks>
        /// Cf. \ref drag-and-drop.
        /// </remarks>
        public virtual DropTarget DropTarget
		{
			get
			{
				return (DropTarget)Object.FindObject(wxWindow_GetDropTarget(wxObject),
							typeof(DropTarget));
			}
			set
			{
				wxWindow_SetDropTarget(wxObject, Object.SafePtr(value));
			}
		}

		//---------------------------------------------------------------------

		// LayoutConstraints are now depreciated.  Should this be implemented?
		/*public LayoutContraints Constraints
		{
			get
			{
				return new LayoutConstraints(wxWindow_GetConstraints(wxObject));
			}
			set
			{
				wxWindow_SetConstraints(wxObject, Object.SafePtr(value));
			}
		}*/

		//---------------------------------------------------------------------

		public virtual bool AutoLayout
		{
			get
			{
				return wxWindow_GetAutoLayout(wxObject);
			}
			set
			{
				wxWindow_SetAutoLayout(wxObject, value);
			}
		}

		//---------------------------------------------------------------------

        /// <summary>
        /// The same as assigning a Sizer, except it also sets the size hints for the window based on the sizer's minimum size.
        /// </summary>
        /// <param name="sizer">The new sizer to use.</param>
        /// <seealso cref="Sizer"/>
		public virtual void SetSizerAndFit(Sizer sizer)
		{
			wxWindow_SetSizerAndFit(wxObject, Object.SafePtr(sizer), true);
		}

        /// <summary>
        /// The same as assigning a Sizer, except it also sets the size hints for the window based on the sizer's minimum size.
        /// </summary>
        /// <param name="sizer">The new sizer to use.</param>
        /// <param name="deleteOld">Default is true</param>
        /// <seealso cref="Sizer"/>
        public virtual void SetSizerAndFit(Sizer sizer, bool deleteOld)
        {
            wxWindow_SetSizerAndFit(wxObject, Object.SafePtr(sizer), deleteOld);
        }

		//---------------------------------------------------------------------

        /// <summary>
        /// The sizer of this window (if defined).
        /// Assign to this property to specify a dynamic layout providing a sizer.
        /// </summary>
		public virtual Sizer Sizer
		{
			get
			{
				return (Sizer)FindObject(wxWindow_GetSizer(wxObject));
			}
			set
			{
				SetSizer(value, true);
			}
		}

		//---------------------------------------------------------------------

		public virtual Sizer ContainingSizer
		{
			get
			{
				return (Sizer)FindObject(wxWindow_GetContainingSizer(wxObject));
			}
			set
			{
				wxWindow_SetContainingSizer(wxObject, Object.SafePtr(value));
			}
		}

		//---------------------------------------------------------------------

		public virtual Palette Palette
		{
			get
			{
				return new Palette(wxWindow_GetPalette(wxObject));
			}
			set
			{
				wxWindow_SetPalette(wxObject, Object.SafePtr(value));
			}
		}

		//---------------------------------------------------------------------

		public virtual bool HasCustomPalette()
		{
			return wxWindow_HasCustomPalette(wxObject);
		}

		//---------------------------------------------------------------------

        [DllImport("wx-c")] static extern int wxGlobal_GetNumberFromUser(IntPtr msg, IntPtr prompt, IntPtr caption, int value, int min, int max, IntPtr parent, ref Point pos);
		
		public static int GetNumberFromUser(string msg, string prompt,
					string caption, int value)
		{
			return GetNumberFromUser(msg, prompt, caption,
					value, 0, 100, null,
					wxDefaultPosition);
		}

        public static int GetNumberFromUser(string msg, string prompt,
					string caption, int value, int min)
		{
			return GetNumberFromUser(msg, prompt, caption,
					value, min, 100, null,
					wxDefaultPosition);
		}
		
		public static int GetNumberFromUser(string msg, string prompt,
					string caption, int value, int min, int max)
		{
			return GetNumberFromUser(msg, prompt, caption,
					value, min, max, null,
					wxDefaultPosition);
		}
		
		public static int GetNumberFromUser(string msg, string prompt,
					string caption, int value, int min, int max, Window parent)
		{
			return GetNumberFromUser(msg, prompt, caption,
					value, min, max, parent,
					wxDefaultPosition);
		}

        public static int GetNumberFromUser(string msg, string prompt,
                    string caption, int value, int min, int max,
                    Window parent, Point pos)
        {
            return GetNumberFromUser(new wxString(msg), new wxString(prompt), new wxString(caption), value, min, max, parent, pos);
        }
		public static int GetNumberFromUser(wxString msg, wxString prompt,
					wxString caption, int value, int min, int max,
					Window parent, Point pos)
		{
			return wxGlobal_GetNumberFromUser(msg.wxObject, prompt.wxObject, caption.wxObject,
					value, min, max, Object.SafePtr(parent),
					ref pos);
		}

        //---------------------------------------------------------------------

		public virtual Region UpdateRegion
		{
			get { return new wx.Region(wxWindow_GetUpdateRegion(wxObject)); }
		}

		//---------------------------------------------------------------------
		
		// Implement very common System.Windows.Forms.Control members

		public virtual int Top 
		{
			get	{ return this.Position.Y; }
			set	{ this.Move(this.Position.X, value,	0);	}
		}

		public virtual int Left	
		{
			get	{ return this.Position.X; }
			set	{ this.Move(value, this.Position.Y,	0);	}
		}

		public virtual int Right 
		{
			get	{ return this.Position.X + this.Size.Width;	}
			set	{ this.Move(value -	this.Size.Width, this.Position.Y, 0); }
		}

		public virtual int Bottom 
		{
			get	{ return this.Position.Y + this.Size.Height; }
			set	{ this.Move(this.Position.X, value - this.Size.Height, 0); }
		}

		public virtual int Width 
		{
			get	{ return this.Size.Width; }
			set	{ this.Size	= new Size(value, this.Size.Height); }
		}

		public virtual int Height 
		{
			get	{ return this.Size.Height; }
			set	{ this.Size	= new Size(this.Size.Width,	value);	}
		}

		//---------------------------------------------------------------------
		
		public WindowVariant WindowVariant
		{
			get { return (WindowVariant)wxWindow_GetWindowVariant(wxObject); }
			set { wxWindow_SetWindowVariant(wxObject, (int)value); }
		}
		
		//---------------------------------------------------------------------
		
		public bool IsBeingDeleted()
		{
			return wxWindow_IsBeingDeleted(wxObject);
		}
		
		//---------------------------------------------------------------------
		
		public void CacheBestSize(Size size)
		{
			wxWindow_CacheBestSize(wxObject, ref size);
		}
		
		//---------------------------------------------------------------------
		
		public void InvalidateBestSize()
		{
			wxWindow_InvalidateBestSize(wxObject);
		}
		
		//---------------------------------------------------------------------
		
		public Size BestFittingSize
		{
			get {
				Size size = new Size();
                wxWindow_GetEffectiveMinSize(wxObject, ref size);
				return size;
			}

            set { wxWindow_SetInitialSize(wxObject, ref value); }
		}
		
		//---------------------------------------------------------------------
		
        /** <summary>The children of this window in an array.</summary>*/
		public Window[] Children
		{
			get {
				int count = wxWindow_GetChildrenCount(wxObject);
                System.Collections.Generic.List<Window> al = new System.Collections.Generic.List<Window>(count);
				
				for (int num = 0; num < count; num++)
				{
                    Window child = (Window)FindObject(wxWindow_GetChildren(wxObject, num));
                    if (child != null)
					    al.Add(child);
				}
				
				return al.ToArray();
			}
		}
		

        /** <summary>Get the next Window in the TAB order of the parent.
         * This may be <c>null</c> if either this does not have a parent or the parent only has one child.</summary>*/
        public Window GetNextWindow()
        {
            if (this.Parent==null)
                return null;
            Window[] children = this.Parent.Children;
            if (children.Length < 2)
            {
                if (this.Parent.Parent == null)
                    return null;
                else
                    return this.Parent.GetNextWindow();
            }
            bool foundthis = false;
            for (int i = 0; i < children.Length; ++i)
            {
                if (children[i] == this)
                    foundthis = true;
                else if (foundthis && children[i].Enabled)
                    return children[i];
            }
            return this.Parent.GetNextWindow();
        }

        /** <summary>Get the previous Window in the TAB order of the parent.
         * This may be <c>null</c> if either this does not have a parent or the parent only has one child.</summary>*/
        public Window GetPreviousWindow()
        {
            if (this.Parent == null)
                return null;
            Window[] children = this.Parent.Children;
            if (children.Length < 2)
            {
                if (this.Parent.Parent == null)
                    return null;
                else
                    return this.Parent.GetPreviousWindow();
            }
            Window prev = null;
            for (int i = 0; i < children.Length; ++i)
            {
                if (this == children[i])
                {
                    if (prev == null)
                    {
                        if (this.Parent.Parent == null)
                            return null;
                        else
                            return this.Parent.GetPreviousWindow();
                    }
                    else
                        return prev;
                }
                if (children[i].Enabled)
                    prev = children[i];
            }
            return this.Parent.GetPreviousWindow();
        }

        //---------------------------------------------------------------------

        /// <summary>
        /// The accelerator table that is associated to this window.
        /// </summary>
        public AcceleratorTable AcceleratorTable
		{
			get { return (AcceleratorTable)FindObject(wxWindow_GetAcceleratorTable(wxObject), typeof(AcceleratorTable)); }
			set { wxWindow_SetAcceleratorTable(wxObject, Object.SafePtr(value)); }
		}
		
		//---------------------------------------------------------------------
		
		public virtual VisualAttributes DefaultAttributes
		{
			get { return new VisualAttributes(wxWindow_GetDefaultAttributes(wxObject), true); }
		}
		
		//---------------------------------------------------------------------
		
		public static VisualAttributes ClassDefaultAttributes()
		{
			return ClassDefaultAttributes(WindowVariant.wxWINDOW_VARIANT_NORMAL);
		}
		
		public static VisualAttributes ClassDefaultAttributes(WindowVariant variant)
		{
			return new VisualAttributes(wxWindow_GetClassDefaultAttributes((int)variant), true);
		}
		
		//---------------------------------------------------------------------

        /** <summary>Returns or defines the background mode of the window.
         * The background style indicates whether background colour should be determined by the system
         * (wxBG_STYLE_SYSTEM), be set to a specific colour (wxBG_STYLE_COLOUR), or should be left to the
         * application to implement (wxBG_STYLE_CUSTOM).
         *
         * On GTK+, use of wxBG_STYLE_CUSTOM allows the flicker-free drawing of a custom background, such
         * as a tiled bitmap. Currently the style has no effect on other platforms.</summary>*/
        public BackgroundStyle BackgroundStyle
		{
			get { return (BackgroundStyle)wxWindow_GetBackgroundStyle(wxObject); }
			set { wxWindow_SetBackgroundStyle(wxObject, (uint)value); }
		}
		
		//---------------------------------------------------------------------
		
		public Border Border
		{
			get { return (Border)wxWindow_GetBorder(wxObject); }
		}
		
		public Border BorderByFlags(int flags)
		{
			return (Border)wxWindow_GetBorderByFlags(wxObject, (uint)flags);
		}
		
		//---------------------------------------------------------------------
				
		public Window AncestorWithCustomPalette
		{
			get { return (Window)FindObject(wxWindow_GetAncestorWithCustomPalette(wxObject), typeof(Window)); }
		}
		
		//---------------------------------------------------------------------
		
		public virtual void InheritAttributes()
		{
			wxWindow_InheritAttributes(wxObject);
		}
		
		//---------------------------------------------------------------------
		
		public virtual bool ShouldInheritColours()
		{
			return wxWindow_ShouldInheritColours(wxObject);
		}
		
		//---------------------------------------------------------------------

        /// <summary>
        /// Adds a listener to the wx.Event.wxEVT_LEFT_UP.
        /// </summary>
        public event EventListener LeftUp
		{
			add { AddCommandListener(Event.wxEVT_LEFT_UP, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

        /// <summary>
        /// Adds a listener to the wx.Event.wxEVT_RIGHT_UP.
        /// </summary>
        public event EventListener RightUp
		{
			add { AddCommandListener(Event.wxEVT_RIGHT_UP, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

        /// <summary>
        /// Adds a listener to the wx.Event.wxEVT_MIDDLE_UP.
        /// </summary>
        public event EventListener MiddleUp
		{
			add { AddCommandListener(Event.wxEVT_MIDDLE_UP, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

        /// <summary>
        /// Adds a listener to the wx.Event.wxEVT_LEFT_DOWN.
        /// </summary>
        public event EventListener LeftDown
		{
			add { AddCommandListener(Event.wxEVT_LEFT_DOWN, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

        /// <summary>
        /// Adds a listener to the wx.Event.wxEVT_MIDDLE_DOWN.
        /// </summary>
        public event EventListener MiddleDown
		{
			add { AddCommandListener(Event.wxEVT_MIDDLE_DOWN, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

        /// <summary>
        /// Adds a listener to the wx.Event.wxEVT_RIGHT_DOWN.
        /// </summary>
        public event EventListener RightDown
		{
			add { AddCommandListener(Event.wxEVT_RIGHT_DOWN, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

        /// <summary>
        /// Adds a listener to the wx.Event.wxEVT_LEFT_DCLICK.
        /// </summary>
        public event EventListener LeftDoubleClick
		{
			add { AddCommandListener(Event.wxEVT_LEFT_DCLICK, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

        /// <summary>
        /// Adds a listener to the wx.Event.wxEVT_RIGHT_DCLICK.
        /// </summary>
        public event EventListener RightDoubleClick
		{
			add { AddCommandListener(Event.wxEVT_RIGHT_DCLICK, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

        /// <summary>
        /// Adds a listener to the wx.Event.wxEVT_MIDDLE_DCLICK.
        /// </summary>
        public event EventListener MiddleDoubleClick
		{
			add { AddCommandListener(Event.wxEVT_MIDDLE_DCLICK, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

        /// <summary>
        /// Adds a listener to the wx.Event.wxEVT_MOTION.
        /// </summary>
        public event EventListener MouseMove
		{
			add { AddCommandListener(Event.wxEVT_MOTION, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

        /// <summary>
        /// Adds a listener to the wx.Event.wxEVT_SCROLL_THUMBTRACK.
        /// </summary>
        public event EventListener MouseThumbTrack
		{
			add { AddCommandListener(Event.wxEVT_SCROLL_THUMBTRACK, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

        /// <summary>
        /// Adds a listener to the wx.Event.wxEVT_ENTER_WINDOW.
        /// </summary>
        public event EventListener MouseEnter
		{
			add { AddCommandListener(Event.wxEVT_ENTER_WINDOW, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

        /// <summary>
        /// Adds a listener to the wx.Event.wxEVT_LEAVE_WINDOW.
        /// </summary>
        public event EventListener MouseLeave
		{
			add { AddCommandListener(Event.wxEVT_LEAVE_WINDOW, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

        /// <summary>
        /// Adds a listener to the wx.Event.wxEVT_SCROLL_LINEUP.
        /// </summary>
        public event EventListener ScrollLineUp
		{
			add { AddCommandListener(Event.wxEVT_SCROLL_LINEUP, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

        /// <summary>
        /// Adds a listener to the wx.Event.wxEVT_SCROLL_LINEDOWN.
        /// </summary>
        public event EventListener ScrollLineDown
		{
			add { AddCommandListener(Event.wxEVT_SCROLL_LINEDOWN, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

        /// <summary>
        /// Adds a listener to the wx.Event.wxEVT_UPDATE_UI.
        /// </summary>
        public virtual event EventListener UpdateUI
		{
			add { AddCommandListener(Event.wxEVT_UPDATE_UI, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

        /// <summary>
        /// Adds a listener to the wx.Event.wxEVT_KEY_DOWN.
        /// </summary>
        public virtual event EventListener KeyDown
		{
			add { AddCommandListener(Event.wxEVT_KEY_DOWN, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

        /// <summary>
        /// Adds a listener to the wx.Event.wxEVT_KEY_UP.
        /// </summary>
        public event EventListener KeyUp
		{
			add { AddCommandListener(Event.wxEVT_KEY_UP, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

        /// <summary>
        /// Adds a listener to the wx.Event.wxEVT_CHAR.
        /// </summary>
		public event EventListener Char
		{
			add { AddCommandListener(Event.wxEVT_CHAR, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

        /// <summary>
        /// Adds a listener to the wx.Event.wxEVT_CLOSE_WINDOW.
        /// </summary>
        public event EventListener Closing
		{
			add { AddCommandListener(Event.wxEVT_CLOSE_WINDOW, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

        /// <summary>
        /// Adds a listener to the wx.Event.wxEVT_ACTIVATE.
        /// </summary>
        public event EventListener Activated
		{
			add { AddCommandListener(Event.wxEVT_ACTIVATE, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

        /// <summary>
        /// Adds a listener to the wx.Event.wxEVT_MOVE.
        /// </summary>
        public event EventListener Moved
		{
			add { AddCommandListener(Event.wxEVT_MOVE, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

        /// <summary>
        /// Adds a listener to the wx.Event.wxEVT_SIZE.
        /// </summary>
        public event EventListener Resized
		{
			add { AddCommandListener(Event.wxEVT_SIZE, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}
	}
}

