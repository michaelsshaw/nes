//-----------------------------------------------------------------------------
// wx.NET - ImageHandlers.cs
//
// The wxImageHandlers wrapper classes.
//
// Written by Alexander Olk (xenomorph2@onlinehome.de)
// (C) 2004 by Alexander Olk
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: ImgHandlers.cs,v 1.2 2007/04/18 21:07:57 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Drawing;
using System.Runtime.InteropServices;

namespace wx
{
public class BMPHandler : ImageHandler 
{
  [DllImport("wx-c")] static extern IntPtr wxBMPHandler_ctor();
  
  public BMPHandler(IntPtr wxObject) 
    : base(wxObject) {}

  public BMPHandler()
      : this(wxBMPHandler_ctor())
  {
  }
}

public class ICOHandler : BMPHandler 
{
  [DllImport("wx-c")] static extern IntPtr wxICOHandler_ctor();
  
  public ICOHandler(IntPtr wxObject) 
    : base(wxObject) {}

  public ICOHandler()
      : this(wxICOHandler_ctor())
  {
  }
}

public class CURHandler : ICOHandler 
{
  [DllImport("wx-c")] public static extern IntPtr wxCURHandler_ctor();
  
  public CURHandler(IntPtr wxObject) 
    : base(wxObject) {}

  public CURHandler()
      : this(wxCURHandler_ctor())
  {
  }
}

public class ANIHandler : CURHandler 
{
    [DllImport("wx-c")] static extern IntPtr wxANIHandler_ctor();

  public ANIHandler(IntPtr wxObject) 
    : base(wxObject) {}

  public ANIHandler()
      : this(wxANIHandler_ctor())
  {
  }
}

public class PNGHandler : ImageHandler 
{
  [DllImport("wx-c")] static extern IntPtr wxPNGHandler_ctor();

  public PNGHandler(IntPtr wxObject) 
    : base(wxObject) {}

  public PNGHandler()
      : this(wxPNGHandler_ctor())
  {
  }
}

public class GIFHandler : ImageHandler 
{
  [DllImport("wx-c")] static extern IntPtr wxGIFHandler_ctor();

  public GIFHandler(IntPtr wxObject) 
    : base(wxObject) {}

  public GIFHandler()
      : this(wxGIFHandler_ctor())
  {
  }
}

public class PCXHandler : ImageHandler 
{
  [DllImport("wx-c")] static extern IntPtr wxPCXHandler_ctor();

  public PCXHandler(IntPtr wxObject) 
    : base(wxObject) {}

  public PCXHandler()
      : this(wxPCXHandler_ctor())
  {
  }
}

public class JPEGHandler : ImageHandler 
{
  [DllImport("wx-c")] static extern IntPtr wxJPEGHandler_ctor();

  public JPEGHandler(IntPtr wxObject) 
    : base(wxObject) {}

  public JPEGHandler()
      : this(wxJPEGHandler_ctor())
  {
  }
}

public class PNMHandler : ImageHandler 
{
  [DllImport("wx-c")] static extern IntPtr wxPNMHandler_ctor();

  public PNMHandler(IntPtr wxObject) 
    : base(wxObject) {}

  public PNMHandler()
      : this(wxPNMHandler_ctor())
  {
  }
}

public class XPMHandler : ImageHandler 
{
  [DllImport("wx-c")] static extern IntPtr wxXPMHandler_ctor();

  public XPMHandler(IntPtr wxObject) 
    : base(wxObject) {}

  public XPMHandler()
      : this(wxXPMHandler_ctor())
  {
  }
}

public class TIFFHandler : ImageHandler 
{
  [DllImport("wx-c")] static extern IntPtr wxTIFFHandler_ctor();

  public TIFFHandler(IntPtr wxObject) 
    : base(wxObject) {}

  public TIFFHandler()
      : this(wxTIFFHandler_ctor())
  {
  }
}

}
