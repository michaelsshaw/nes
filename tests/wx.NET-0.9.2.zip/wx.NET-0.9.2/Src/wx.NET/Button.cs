//-----------------------------------------------------------------------------
// wx.NET - Button.cs
//
// The wxButton wrapper class.
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: Button.cs,v 1.30 2009/10/11 16:23:18 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Drawing;
using System.Runtime.InteropServices;

namespace wx
{
    /** <summary>Class of buttons with text labels. Refer also to wx.BitmapButton.
     * Style flags (enumeration wx.WindowStyles) applying to this class of control
     * in particular start with BU_ as prefix.</summary>*/
	public class Button : Control
	{
		[DllImport("wx-c")] static extern IntPtr wxButton_ctor();
        [DllImport("wx-c")][return:MarshalAs(UnmanagedType.U1)] static extern bool wxButton_Create(IntPtr self, IntPtr parent, int id, IntPtr label, int x, int y, int w, int h, uint style, IntPtr validator, IntPtr name);
		[DllImport("wx-c")] static extern void wxButton_SetDefault(IntPtr self);
		[DllImport("wx-c")] static extern void wxButton_GetDefaultSize(IntPtr size);
		
		[DllImport("wx-c")] static extern void wxButton_SetImageMargins(IntPtr self, int x, int y);
		[DllImport("wx-c")] static extern void wxButton_SetImageLabel(IntPtr self, IntPtr bitmap);
		
		[DllImport("wx-c")] static extern void wxButton_SetLabel(IntPtr self, IntPtr label);
        [DllImport("wx-c")] static extern IntPtr wxButton_GetLabel(IntPtr self);

		//---------------------------------------------------------------------
		
		public Button(IntPtr wxObject) 
			: base(wxObject) { }

        static IntPtr LockedCTor()
        {
            lock (DllSync)
            {
                return wxButton_ctor();
            }
        }

		public Button()
			: this(LockedCTor()) { }

		public Button(Window parent, int id, string label)
			: this(parent, id, label, wxDefaultPosition, wxDefaultSize, 0, null) { }

		public Button(Window parent, int id, string label, Point pos)
			: this(parent, id, label, pos, wxDefaultSize, 0, null) { }
		
		public Button(Window parent, int id, string label, Point pos, Size size)
			: this(parent, id, label, pos, size, 0, null) { }
		
		public Button(Window parent, int id, string label, Point pos, Size size, wx.WindowStyles style)
			: this(parent, id, label, pos, size, style, null) { }
		
		public Button(Window parent, int id, string label, Point pos, Size size, wx.WindowStyles style, string name)
			: this(LockedCTor())
		{
			if (!Create(parent, id, label, pos, size, style, name))
			{
				throw new InvalidOperationException("Failed to create Button");
			}
		}
		
		//---------------------------------------------------------------------
		// ctors with self created id
		
		public Button(Window parent, string label)
			: this(parent, Window.UniqueID, label, wxDefaultPosition, wxDefaultSize, wx.WindowStyles.NO_STYLE, null) { }

		public Button(Window parent, string label, Point pos)
			: this(parent, Window.UniqueID, label, pos, wxDefaultSize, wx.WindowStyles.NO_STYLE, null) { }
		
		public Button(Window parent, string label, Point pos, Size size)
			: this(parent, Window.UniqueID, label, pos, size, wx.WindowStyles.NO_STYLE, null) { }
		
		public Button(Window parent, string label, Point pos, Size size, wx.WindowStyles style)
			: this(parent, Window.UniqueID, label, pos, size, style, null) { }
		
		public Button(Window parent, string label, Point pos, Size size, wx.WindowStyles style, string name)
			: this(parent, Window.UniqueID, label, pos, size, style, null) {}
			
		//---------------------------------------------------------------------

		public bool Create(Window parent, int id, string label, Point pos, Size size, wx.WindowStyles style, string name)
		{
            return this.Create(parent, id, new wxString(label), pos, size, style, new wxString(name));
		}
        public bool Create(Window parent, int id, wxString label, Point pos, Size size, wx.WindowStyles style, wxString name)
        {
            return wxButton_Create(wxObject, Object.SafePtr(parent), id, Object.SafePtr(label), pos.X, pos.Y, size.Width, size.Height, (uint)style, IntPtr.Zero, Object.SafePtr(name));
        }

		//---------------------------------------------------------------------

		public void SetDefault()
		{
			wxButton_SetDefault(wxObject);
		}

		//---------------------------------------------------------------------

		public static Size GetDefaultSize()
		{
			wxSize size = new wxSize();
			wxButton_GetDefaultSize(size.wxObject);
			return (Size)size;
		}
		
		//---------------------------------------------------------------------
		
		public virtual Bitmap ImageLabel
		{
			set { wxButton_SetImageLabel(wxObject, Object.SafePtr(value)); }
		}
		
		//---------------------------------------------------------------------
		
		public virtual void SetImageMargins(int x, int y)
		{
			wxButton_SetImageMargins(wxObject, x, y);
		}
		
		//---------------------------------------------------------------------
		// Do we need get also ?
		
		public new string Label
		{
			set
            {
                wxString wxlabel = new wxString(value);
                wxButton_SetLabel(wxObject, wxlabel.wxObject);
            }
            get
            {
                return new wxString(wxButton_GetLabel(this.wxObject));
            }
		}
		
		//---------------------------------------------------------------------
		
		public event EventListener Click
		{
			add { AddCommandListener(Event.wxEVT_COMMAND_BUTTON_CLICKED, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}
	}
}

