//-----------------------------------------------------------------------------
// wx.NET - wxString.cs
//
// The wxString wrapper class.
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 Bryan Bulten
// major changes 2006 Dr. Harald Meyer auf'm Hofe
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: wxString.cs,v 1.34 2010/06/06 08:58:07 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Runtime.InteropServices;

namespace wx
{

    /** <summary>Wrapper for the  wxWidgets string class <c>wxString</c>.</summary>
      * <remarks>
      * Objectives: 
      * \li Several <c>wx.NET</c> implementations interchange string data with the used  wxWidgets library.
      *     Conversion from .NET strings to  wxWidgets strings shall be hidden. .NET implementations shall
      *     be able to use something like a lazy conversion: Simply getting a string from one method of
      *      wxWidgets and sending it to another shall be possible without conversion to .NET strings.
      * \li  wxWidgets class might be compiled in Unicode or ANSI mode. This shall be hidden completely to
      *     the <c>wx.NET</c> implementation.
      *
      * The changed implementation follows the guidelines of the  wxWidgets manual for implementations.
      * The internal character encoding within the .NET framework is uniquely defined to UTF 16.
      * The used constructors and selectors use an explicit conversion as argument (on the <c>wx-c</c> side)
      * to convert from or to this encoding. So, the interface provided by <c>wx-c</c> is always UTF 16 whether
      * the library is able to represent such strings internally or not.
      * An <c>MarshalAsAttribute</c> is used to define a more verbatim marshalling scheme on DLL import.
      *
      * So, any kind of conversion is done by  wxWidgets (if necessary) and not by the .NET framework.
      * 
      * Refer to wxWCharBuffer and DisposableStringBox for remarks on helper classes for dealing with strings.
      *  </remarks>
     */
    public class wxString : Object
    {
#if WXNET_INTERNAL_USE_UTF8
      [DllImport("wx-c")] static extern IntPtr wxString_ctorUTF8([MarshalAs(UnmanagedType.LPWStr)]string str);
#else
      [DllImport("wx-c")] static extern IntPtr wxString_ctorUTF16([MarshalAs(UnmanagedType.LPWStr)]string str);
#endif
      [DllImport("wx-c")] static extern void wxString_dtor(IntPtr self);
      [DllImport("wx-c")] [return: MarshalAs(UnmanagedType.U2)] static extern char wxString_CharAtUTF16(IntPtr self, int pos);
      [DllImport("wx-c")] static extern int wxString_GetLength(IntPtr self);
      [DllImport("wx-c")] static extern IntPtr wxString_Conversion(IntPtr self);
      //---------------------------------------------------------------------

      public wxString(IntPtr wxObject)
          : base(wxObject, Object.StorageMode.VolatileObject)
          { 
            this.wxObject = wxObject;
          }
               
      internal wxString(IntPtr wxObject, bool memOwn)
          : base(wxObject, Object.StorageMode.VolatileObject, memOwn)
        { 
            this.wxObject = wxObject;
        }

      public wxString()
        : this("") { }


#if WXNET_INTERNAL_USE_UTF8
      static IntPtr SyncWxStringUTF8(string str)
        {
            lock (DllSync)
            {
                return wxString_ctorUTF8(str);
            }
        }
      public wxString(string str)
        : this(SyncWxStringUTF8(str), true)
      {
      }
#else
        static IntPtr SyncWxStringUTF16(string str)
        {
            lock (DllSync)
            {
                return wxString_ctorUTF16(str);
            }
        }
      public wxString(string str)
        : this(SyncWxStringUTF16(str), true)
      {
      }
#endif

      /** <summary>This will safely create an instance of wx.wxString without throwing exceptions on argument <c>null</c>.
       * Instead the method will return result <c>null</c> on argument <c>null</c>.
       * </summary>
       */
      public static wxString SafeNew(string str)
      {
          if (str == null)
              return null;
          else
              return new wxString(str);
      }


        public static wxString SafeNew(IntPtr ptrToStr)
        {
            return SafeNew(ptrToStr, false);
        }

        public static wxString SafeNew(IntPtr ptrToStr, bool memOwn)
        {
            if (ptrToStr == IntPtr.Zero)
                return null;
            else
                return new wxString(ptrToStr, memOwn);
        }

      //---------------------------------------------------------------------
      		
		protected override void CallDTor ()
		{
            wxString_dtor(wxObject);
        }

		
      //---------------------------------------------------------------------
		
      ~wxString() 
        {
            this.Dispose();
        }
        
      //---------------------------------------------------------------------

      public static implicit operator string(wxString str)
      {
          if (str == null) return null;
          return str.ToString();
      }

      /** <summary>Conversion of <c>wxString</c> into a string.
       * This method works different on Unicode- and ANSI-builds of  wxWidgets.
       * On Unicode builds we can directly refer to the internal buffer using
       * the indexer of this class. Otherwise we read a wxWCharBuffer and convert this.
       *
       * Special case: PNET with internal UTF8 character encoding if <c>WXNET_INTERNAL_USE_UTF8</c>.
       * In this case, we always have to decode.
       *</summary>*/
      public override string ToString()
        {
#if WXNET_INTERNAL_USE_UTF8
                wxWCharBuffer conversion = new wxWCharBuffer(wxString_ConversionUTF8(this.wxObject));
                return conversion.ToString();
#else
            if (ReflectConfig.CheckUseUnicode())
            {
                int length = this.Length;
                char[] result = new char[length];
                for (int i = 0; i < length; ++i)
                    result[i] = this[i];
                return new string(result);
            }
            else
            {
                lock (DllSync)
                {
                    using (wxWCharBuffer conversion = new wxWCharBuffer(wxString_Conversion(this.wxObject)))
                    {
                        return conversion.ToString();
                    }
                }
            }
#endif
        }
        
        /*
      public static implicit operator wxString (string str) 
        {
            if (str == null) return null;
            return new wxString(str);
        }
      */

      //---------------------------------------------------------------------

        /** <summary>Get the n-th character.
          * Returns a 2 byte UTF16 character. Only <c>get</c> implemented.
          * Undefined positions will result in a 0.
          * This works perfect on a Unicode build (ReflectConfig.CheckUseUnicode)
          * since internal characer encoding of <c>wxString</c> is the same as the encoding
          * in C#. On ANSI builds this will return blanks as replacemetns of non-ascii
          * characters.
          * 
          * Correction: Microsoft and Mono use UTF16 as internal string representation just
          * like <c>wxWidgets</c> with wide character Unicode support compiled in. However, PNET
          * seems to use UTF 8 instead. If this assumes internal UTF 8 strings, this method
          * will return ASCII only.</summary>*/
      public char this[int n]
      {
        get
          {
#if WXNET_INTERNAL_USE_UTF8
            char result=wxString_CharAtUTF16(wxObject, n);
            if (result < 0 || result >= 128)
              return ' ';
            else
              return result;
#else
            return wxString_CharAtUTF16(wxObject, n);
#endif
          }
      }
       
      //---------------------------------------------------------------------
      
      /** <summary>Returns the length of the encapsulated string.</summary>*/
      public int Length
      {
        get
          {
            return wxString_GetLength(wxObject);
          }
      }
      
      //---------------------------------------------------------------------

      internal static IntPtr SafePtr(wxString obj)
        {
          return (obj == null) ? IntPtr.Zero : obj.wxObject;
        }
  }

  /** <summary>This is a wrapper for the  wxWidgets class of the same type.
   * This class is required for interchanging strings with ANSI builds of  wxWidgets.
   * In such situations, we have to request the <c>wxString</c>, that internally holds an
   * ANSI representation, into a wide character UTF-16 string buffer.
   *</summary>*/
  internal class wxWCharBuffer : Object
    {
        [DllImport("wx-c")]
        static extern IntPtr wxWCharBuffer_ctorUTF16([MarshalAs(UnmanagedType.LPWStr)]string str);
        [DllImport("wx-c")]
        static extern void wxWCharBuffer_dtor(IntPtr self);
        [DllImport("wx-c")] [return: MarshalAs(UnmanagedType.U2)]
        static extern char wxWCharBuffer_WideCharAt(IntPtr self, int pos);
        [DllImport("wx-c")]
        static extern bool wxWCharBuffer_IsEmpty(IntPtr self);
        [DllImport("wx-c")]
        static extern int wxWCharBuffer_GetLength(IntPtr self);
        //---------------------------------------------------------------------

        public wxWCharBuffer(IntPtr wxObject)
            : base(wxObject)
        {
            this.wxObject = wxObject;
        }

        internal wxWCharBuffer(IntPtr wxObject, bool memOwn)
            : base(wxObject)
        {
            this.memOwn = memOwn;
            this.wxObject = wxObject;
        }

        public wxWCharBuffer()
            : this("") { }

        static IntPtr SyncCtorUTF16(string str)
        {
            lock (DllSync)
            {
                return wxWCharBuffer_ctorUTF16(str);
            }
        }

        public wxWCharBuffer(string str)
            : this(SyncCtorUTF16(str), true) { }

        //---------------------------------------------------------------------

        public override void Dispose()
        {
            if (!disposed)
            {
                lock (DllSync)
                {
                    --validInstancesCount;
                    if (wxObject != IntPtr.Zero)
                    {
                        if (memOwn)
                        {
                            wxWCharBuffer_dtor(wxObject);
                            memOwn = false;
                        }
                    }
                    RemoveObject(wxObject);
                    wxObject = IntPtr.Zero;
                    disposed = true;
                }
            }

            base.Dispose();
            GC.SuppressFinalize(this);
        }

        //---------------------------------------------------------------------

        ~wxWCharBuffer()
        {
            Dispose();
        }

        //---------------------------------------------------------------------

        #region Public Properties
        public bool IsEmpty
        {
            get { return wxWCharBuffer_IsEmpty(this.wxObject); }
        }

        public int Length
        {
            get { return wxWCharBuffer_GetLength(this.wxObject); }
        }
        #endregion

        /** <summary>Conversion into a string.
         * Copies character by character into a .NET string.</summary>*/
        public override string ToString()
        {
            int length = this.Length;
            char[] result = new char[length];
            for (int i = 0; i < length; ++i)
            {
                result[i] = this[i];
            }
            return new string(result);
        }

        public char this[int n]
        {
            get
            {
                return wxWCharBuffer_WideCharAt(this.wxObject, n);
            }
        }
    }


    /** <summary>This is a box for instances of wxString that calls wxString.Dispose() on deletion of the box and deletes the string instance.
     * Use this class to pass instances of wxString from C# callbacks implementing virtual methods.
     * Refer to <c>wx.ListCtrl.OnDoGetItemText()</c> for an example.</summary>*/
    internal class DisposableStringBox : Object
    {
        [DllImport("wx-c")]
        static extern IntPtr DisposableStringBox_CTor(IntPtr val);
        [DllImport("wx-c")]
        static extern void DisposableStringBox_RegisterDispose(IntPtr self, Virtual_Dispose virtualDispose);

        wxString _val;

        static int validStringsCount = 0;
        /** <summary>This is the number of valid string instances.</summary>*/
        new public static int InstancesCount { get { return validStringsCount; } }

        static IntPtr SyncCTor(IntPtr val)
        {
            lock (DllSync)
            {
                return DisposableStringBox_CTor(val);
            }
        }
        public DisposableStringBox(wxString val)
            : base(SyncCTor(val.wxObject))
        {
            virtual_Dispose = new Virtual_Dispose(VirtualDispose);
            DisposableStringBox_RegisterDispose(this.wxObject, virtual_Dispose);
            this._val = val;
            ++validStringsCount;
        }

        new internal void VirtualDispose()
        {
            base.VirtualDispose();
            --validStringsCount;
            this._val.VirtualDispose();
            this._val = null;
        }

        public override string ToString()
        {
            return string.Format("DisposableStringBox({0})", this._val);
        }
    }
}
