//-----------------------------------------------------------------------------
// wx.NET - App.cs
//
// The wxApp wrapper class.
//
// Written by Jason Perkins (jason@379.com)
// (C) 2003 by 379, Inc.
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: App.cs,v 1.25 2010/05/08 19:51:26 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Runtime.InteropServices;

/** <summary>This namespace contains all standard wrappers of  wxWidgets elements.</summary>*/
namespace wx
{
    /** <summary>The wxApp class represents the application itself.
     * It is used to:
     * <list type="bullet">
     * <item> set and get application-wide properties; </item>
     * <item> implement the windowing system message or event loop; </item>
     * <item> initiate application processing via wxApp.OnInit();</item>
     * <item> allow default processing of events not handled by other objects in the application. </item> 
     * </list>
     * </summary>
     */
    public abstract class App : EvtHandler
    {
        #region Virtual Methods: Delegate types and instances
        private delegate bool Virtual_OnInit();
        private delegate int Virtual_OnExit();
        private delegate bool Virtual_OnExceptionInMainLoop();
        private delegate void Virtual_OnFatalException();

        private Virtual_OnInit virtual_OnInit;
        private Virtual_OnExit virtual_OnExit;
        private Virtual_OnExceptionInMainLoop virtual_OnExceptionInMainLoop;
        private Virtual_OnFatalException virtual_OnFatalException;
        #endregion

        #region C API
        [DllImport("wx-c")]
        static extern int OS_GetLastOSError();

        [DllImport("wx-c")]
        static extern IntPtr wxApp_ctor();

        [DllImport("wx-c")]
        static extern void wxApp_RegisterVirtual(IntPtr self, Virtual_OnInit onInit, Virtual_OnExit onExit, Virtual_OnExceptionInMainLoop onExceptionInMainLoop, Virtual_OnFatalException onFatalException);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxApp_OnInit(IntPtr self);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxApp_OnExceptionInMainLoop(IntPtr self);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxApp_IsActive(IntPtr self);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxApp_IsMainLoopRunning(IntPtr self);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxApp_SetHandleFatalExceptions(bool doIt);
        [DllImport("wx-c")]
        static extern int wxApp_OnExit(IntPtr self);

        [DllImport("wx-c")]
        static extern void wxApp_Run(int argc, string[] argv);

        [DllImport("wx-c")]
        static extern void wxApp_SetVendorName(IntPtr self, IntPtr name);
        [DllImport("wx-c")]
        static extern IntPtr wxApp_GetVendorName(IntPtr self);

        [DllImport("wx-c")]
        static extern void wxApp_SetAppName(IntPtr self, IntPtr name);
        [DllImport("wx-c")]
        static extern IntPtr wxApp_GetAppName(IntPtr self);

        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxApp_SafeYield(IntPtr win, bool onlyIfNeeded);
        [DllImport("wx-c")][return:MarshalAs(UnmanagedType.U1)]
        static extern bool wxApp_Yield(IntPtr self, bool onlyIfNeeded);
        [DllImport("wx-c")]
        static extern void wxApp_WakeUpIdle();
        #endregion

        /// <summary>
        /// This method is a helper for platform specific diagnostics.
        /// The method will return an error code directly from the operating system or other
        /// platform specific software. The resulting code is platform specific but 0 is guaranteed
        /// to mean "no error" or "this function is not supported".
        /// 
        /// The currently only supported platform is MS WINDOWS, where this return 
        /// <c>GetLastError()</c>.
        /// </summary>
        /// <returns>Error code or 0 if not error or not supported.</returns>
        public static int GetLastOSError()
        {
            return OS_GetLastOSError();
        }

        private static App app;

        /** <summary>Returns the application instance.</summary>
         */
        public static App TheApp { get { return app; } }

        static IntPtr LockedCTor()
        {
            lock (DllSync)
            {
                return wxApp_ctor();
            }
        }

        protected App()
            : base(LockedCTor())
        {
            app = this;

            this.virtual_OnInit = new Virtual_OnInit(OnInit);
            this.virtual_OnExit = new Virtual_OnExit(OnExit);
            this.virtual_OnExceptionInMainLoop = new Virtual_OnExceptionInMainLoop(OnExceptionInMainLoop);
            this.virtual_OnFatalException = new Virtual_OnFatalException(OnFatalException);

            wxApp_RegisterVirtual(wxObject, virtual_OnInit, virtual_OnExit, virtual_OnExceptionInMainLoop, virtual_OnFatalException);
        }

        //---------------------------------------------------------------------

        /** <summary>This must be provided by the application, and will usually create the application's main window, optionally calling wx.App.SetTopWindow.
         * You may use wx.App.OnExit to clean up anything initialized here, provided that the function
         * returns true.
         *
         * Notice that if you want to to use the command line processing provided by wxWidgets you have
         * to call the base class version in the derived class OnInit().
         * 
         * Please note, that the <c>STAThreadAttribute</c> shall be set in threads running this. wxWidgets as well as 
         * .NET will conduct OLE initialization and these initializations must be done consistently.
         *</summary>
         * <returns>
         * Return true to continue processing, false to exit the application immediately
         * </returns>
         */
        public virtual bool OnInit()
        {
            return wxApp_OnInit(wxObject);
        }

        /** <summary>This function is called if an unhandled exception occurs inside the main application event loop.
         * It can return true to ignore the exception and to continue running the loop or false to exit the
         * loop and terminate the program. \b Warning: Do not throw an exception here.
         *
         * The default behaviour of this function is the latter in all ports except under Windows where
         * a dialog is shown to the user which allows him to choose between the different options.
         * You may override this function in your class to do something more appropriate.
         * </summary>
        */
        public virtual bool OnExceptionInMainLoop()
        {
            return wxApp_OnExceptionInMainLoop(this.wxObject);
        }

        /** <summary>This will be called in the standard implementation of OnExit() before closing down the application.</summary>
         */
        public event EventHandler OnExitEvent;

        /** <summary>Override this member function for any processing which needs to be done as the application is about to exit.
         * OnExit() is called after destroying all application windows and controls, but before
         * wxWidgets cleanup. Note that it is not called at all if OnInit() failed.
         *
         * The return value of this function is currently ignored, return the same value as returned
         * by the base class method if you override it.
         * </summary>
         */
        public virtual int OnExit()
        {
            if (this.OnExitEvent != null)
                this.OnExitEvent(this, new EventArgs());
            return wxApp_OnExit(wxObject);
        }

        /** <summary>This function may be called if something fatal happens: an unhandled exception under Win32 or a a fatal signal under Unix, for example.
         * However, this will not happen by default: you have to explicitly call
         * SetHandleFatalExceptions() to enable this.
         *
         * Generally speaking, this function should only show a message to the user and return.
         * You may attempt to save unsaved data but this is not guaranteed to work and, in fact,
         * probably won't.
         * 
         * The standard implementation does nothing.
         * </summary>
         */
        public virtual void OnFatalException()
        {
        }

        /** <summary>Enable callback on fatal exceptions.
         * Refer to OnFatalException().</summary>
         */
        static public bool SetHandleFatalException(bool doIt)
        {
            return wxApp_SetHandleFatalExceptions(doIt);
        }

        /** <summary>Returns true if the application is active, i.e. if one of its windows is currently in the foreground. </summary>
         */
        public bool IsActive
        {
            get
            {
                return wxApp_IsActive(this.wxObject);
            }
        }

        /** <summary>Returns true if the main event loop is currently running, i.e. if the application is initialized and runs.
         *
         * This can be useful to test whether the events can be dispatched. For example, if this
         * function returns false, non-blocking sockets cannot be used because the events from them
         * would never be processed.
         * </summary>
         */
        public bool IsMainLoopRunning
        {
            get
            {
                return wxApp_IsMainLoopRunning(this.wxObject);
            }
        }

        public static App GetApp()
        {
            return app;
        }

        //---------------------------------------------------------------------

        public void Run()
        {
            string[] args = Environment.GetCommandLineArgs();
            wxApp_Run(args.Length, args);
        }

        //---------------------------------------------------------------------

        /// <summary>
        /// Name of the vendor.
        /// Will be used e.g. in the hierarchy of the Windows registry entries.
        /// </summary>
        public string VendorName
        {
            set
            {
                wxString wxValue = wxString.SafeNew(value);
                wxApp_SetVendorName(wxObject, Object.SafePtr(wxValue));
            }
            get { return new wxString(wxApp_GetVendorName(wxObject), true); }
        }

        /// <summary>
        /// Name of the application.
        /// Will be used e.g. to create keys in the hierarchy of registry entries.
        /// </summary>
        public string AppName
        {
            set
            {
                wxString wxValue = wxString.SafeNew(value);
                wxApp_SetAppName(wxObject, Object.SafePtr(wxValue));
            }
            get { return new wxString(wxApp_GetAppName(wxObject), true); }
        }

        //---------------------------------------------------------------------

        /** <summary>This function is similar to wx.App.Yield(), except that it disables the user input to all program windows before calling wx.App.Yield and re-enables it again afterwards.
         * Returns the result of the call to wx.App.Yield().
         * </summary>
         */
        public bool SafeYield()
        {
            lock (Object.DllSync)
            {
                return wxApp_SafeYield(Object.SafePtr(null), false);
            }
        }

        /** <summary>This function is similar to wx.App.Yield(), except that it disables the user input to all program windows before calling wx.App.Yield and re-enables it again afterwards.
         * If win is not NULL, this window will remain enabled, allowing the implementation
         * of some limited user interaction.
         *</summary>
         *<returns>
         * Returns the result of the call to wx.App.Yield().
         * </returns>
         * <param name="win">A top level window that will remain enabled or <c>null</c>.</param>
         */
        public bool SafeYield(Window win)
        {
            return this.SafeYield(win, false);
        }

        /** <summary>This function is similar to wx.App.Yield(), except that it disables the user input to all program windows before calling wx.App.Yield and re-enables it again afterwards.
         * If win is not NULL, this window will remain enabled, allowing the implementation
         * of some limited user interaction.
         *</summary>
         *<returns>
         * Returns the result of the call to wx.App.Yield().
         *</returns>
         * <param name="win">A top level window that will remain enabled or <c>null</c>.</param>
         */
        public bool SafeYield(Window win, bool onlyIfNeeded)
        {
            lock (Object.DllSync)
            {
                return wxApp_SafeYield(Object.SafePtr(win), onlyIfNeeded);
            }
        }

        /** <summary>cf. Yield(bool).</summary>
         */
        public bool Yield()
        {
            return this.Yield(false);
        }

        /** <summary>Yields control to pending messages in the windowing system.
         * This can be useful, for example, when a time-consuming process writes to
         * a text window. Without an occasional yield, the text window will not be
         * updated properly, and on systems with cooperative multitasking, such as
         * Windows 3.1 other processes will not respond.
         *
         * Caution should be exercised, however, since yielding may allow the user to
         * perform actions which are not compatible with the current task. Disabling
         * menu items or whole menus during processing can avoid unwanted reentrance
         * of code: see wx.App.SafeYield for a better function.
         *
         * Note that Yield() will not flush the message logs. This is intentional as
         * calling Yield() is usually done to quickly update the screen and popping up
         * a message box dialog may be undesirable. If you do wish to flush the log
         * messages immediately (otherwise it will be done during the next idle loop
         * iteration), call wx.Log.FlushActive.
         *
         * Calling Yield() recursively is normally an error and an assert failure is
         * raised in debug build if such situation is detected. However if the
         * <c>onlyIfNeeded</c> parameter is true, the method will just silently return
         * false instead.
         * </summary>
        */
        public bool Yield(bool onlyIfNeeded)
        {
            lock (Object.DllSync)
            {
                return wxApp_Yield(wxObject, onlyIfNeeded);
            }
        }

        //---------------------------------------------------------------------

        public static void WakeUpIdle()
        {
            lock (Object.DllSync)
            {
                wxApp_WakeUpIdle();
            }
        }
    }
}
