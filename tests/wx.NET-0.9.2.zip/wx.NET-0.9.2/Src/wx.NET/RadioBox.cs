//-----------------------------------------------------------------------------
// wx.NET - RadioBox.cs
//
// The wxRadioBox wrapper class.
//
// Written by Jason Perkins (jason@379.com)
// (C) 2003 by 379, Inc.
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: RadioBox.cs,v 1.19 2010/05/08 19:54:35 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Drawing;
using System.Runtime.InteropServices;

namespace wx
{
    /** <summary>This control throws exceptions on creating instances without providing choices.
     * According to the wxWidgets documentation, this is a control with items but it is not.
     * You can neither add items dynamically not associate items with client data.
     * </summary>
     */
	public class RadioBox : Control
	{
		[DllImport("wx-c")] static extern IntPtr wxRadioBox_ctor();
		[DllImport("wx-c")] static extern bool   wxRadioBox_Create(IntPtr self, IntPtr parent, int id,
		                                                           IntPtr label, ref Point pos, ref Size size,
		                                                           IntPtr choices, int majorDimension,
		                                                           uint style, IntPtr val, IntPtr name);

		[DllImport("wx-c")] static extern void   wxRadioBox_Enable(IntPtr self, int n, bool enable);
		[DllImport("wx-c")] static extern void   wxRadioBox_Show(IntPtr self, int n, bool show);

        [DllImport("wx-c")] static extern int wxRadioBox_FindString(IntPtr self, IntPtr aString);
        [DllImport("wx-c")] static extern int wxRadioBox_GetSelection(IntPtr self);
        [DllImport("wx-c")] static extern void wxRadioBox_SetSelection(IntPtr self, int item);
        [DllImport("wx-c")] static extern IntPtr wxRadioBox_GetStringSelection(IntPtr self);
        [DllImport("wx-c")] static extern void wxRadioBox_SetStringSelection(IntPtr self, IntPtr aString);
        //[DllImport("wx-c")] static extern IntPtr wxRadioBox_GetString(IntPtr self, int n);

        [DllImport("wx-c")] static extern int wxRadioBox_GetCount(IntPtr self);

		[DllImport("wx-c")] static extern IntPtr wxRadioBox_GetLabel(IntPtr self);
		[DllImport("wx-c")] static extern void   wxRadioBox_SetLabel(IntPtr self, IntPtr label);

		//---------------------------------------------------------------------
		
		public RadioBox(IntPtr wxObject)
			: base(wxObject) {}
			
		public RadioBox(Window parent, int id, string label, Point pos, Size size, string[] choices)
			: this(parent, id, label, pos, size, choices, 0, wx.WindowStyles.RA_SPECIFY_COLS, null) {} 
			
		public RadioBox(Window parent, int id, string label, Point pos, Size size, string[] choices, int majorDimension)
            : this(parent, id, label, pos, size, choices, majorDimension, wx.WindowStyles.RA_SPECIFY_COLS, null) { } 

		public RadioBox(Window parent, int id, string label, Point pos, Size size, string[] choices, int majorDimension, wx.WindowStyles style)
			: this(parent, id, label, pos, size, choices, majorDimension, style, null) { }
			
        public RadioBox(Window parent, int id, string label, Point pos, Size size, string[] choices, int majorDimension, wx.WindowStyles style, string name)
            : this(parent, id, new wxString(label), pos, size, ArrayString.SafeNewFrom(choices), majorDimension, style, new wxString(name))
        {
        }

		internal RadioBox(Window parent, int id, wxString label, Point pos, Size size, ArrayString choices, int majorDimension, wx.WindowStyles style, wxString name)
			: base(wxRadioBox_ctor())
		{
			if (!wxRadioBox_Create(wxObject, Object.SafePtr(parent), id, Object.SafePtr(label), ref pos, ref size,
			                       Object.SafePtr(choices), majorDimension, (uint)style, IntPtr.Zero, Object.SafePtr(name)))
			{
				throw new InvalidOperationException("failed to create checkbox");
			}
		}
		
		//---------------------------------------------------------------------
		// ctors with self created id
		
		public RadioBox(Window parent, string label)
            : this(parent, Window.UniqueID, label, wxDefaultPosition, wxDefaultSize, new string[] { }, 0, wx.WindowStyles.RA_SPECIFY_COLS, null) { } 
			
		public RadioBox(Window parent, string label, Point pos)
            : this(parent, Window.UniqueID, label, pos, wxDefaultSize, new string[] { }, 0, wx.WindowStyles.RA_SPECIFY_COLS, null) { } 
			
		public RadioBox(Window parent, string label, Point pos, Size size)
            : this(parent, Window.UniqueID, label, pos, size, new string[] { }, 0, wx.WindowStyles.RA_SPECIFY_COLS, null) { } 
			
		public RadioBox(Window parent, string label, Point pos, Size size, string[] choices)
			: this(parent, Window.UniqueID, label, pos, size, choices, 0, wx.WindowStyles.RA_SPECIFY_COLS, null) {} 
			
		public RadioBox(Window parent, string label, Point pos, Size size, string[] choices, int majorDimension)
			: this(parent, Window.UniqueID, label, pos, size, choices, majorDimension, wx.WindowStyles.RA_SPECIFY_COLS, null) {} 

		public RadioBox(Window parent, string label, Point pos, Size size, string[] choices, int majorDimension, wx.WindowStyles style)
			: this(parent, Window.UniqueID, label, pos, size, choices, majorDimension, style, null) { }
	
		public RadioBox(Window parent, string label, Point pos, Size size, string[] choices, int majorDimension, wx.WindowStyles style, string name)
			: this(parent, Window.UniqueID, label, pos, size, choices, majorDimension, style, name) {}

		//---------------------------------------------------------------------

		public void Enable(int n, bool enable)
		{
			wxRadioBox_Enable(wxObject, n, enable);
		}

		public void Show(int n, bool show)
		{
			wxRadioBox_Show(wxObject, n , show);
		}

        public int FindString(string aString)
        {
            return this.FindString(new wxString(aString));
        }

        public int FindString(wxString aString)
        {
            return wxRadioBox_FindString(this.wxObject, aString.wxObject);
        }

        public int Count
        {
            get { return wxRadioBox_GetCount(this.wxObject); }
        }

        public int Selection
        {
            get { return wxRadioBox_GetSelection(this.wxObject); }
            set { wxRadioBox_SetSelection(this.wxObject, value); }
        }

        public string StringSelection
        {
            get { return new wxString(wxRadioBox_GetStringSelection(this.wxObject)); }
            set { wxString wxValue = new wxString(value); wxRadioBox_SetStringSelection(this.wxObject, wxValue.wxObject); }
        }

		//---------------------------------------------------------------------
		
		public new string Label
		{
			get { return new wxString(wxRadioBox_GetLabel(wxObject), true); }
			set
            {
                wxString wxValue = new wxString(value);
                wxRadioBox_SetLabel(wxObject, wxValue.wxObject);
            }
		}
		
		//---------------------------------------------------------------------

		public event EventListener Select
		{
			add { AddCommandListener(Event.wxEVT_COMMAND_RADIOBOX_SELECTED, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}
	}
}
