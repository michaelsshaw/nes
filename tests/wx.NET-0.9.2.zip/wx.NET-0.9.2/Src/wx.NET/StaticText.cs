//-----------------------------------------------------------------------------
// wx.NET - StaticText.cs
//
// The wxStaticText wrapper class.
//
// Written by Jason Perkins (jason@379.com)
// (C) 2003 by 379, Inc.
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: StaticText.cs,v 1.13 2009/09/20 14:10:58 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Drawing;
using System.Runtime.InteropServices;

namespace wx
{
    /** <summary>This displays a static text field.
     * These controls consume wx.WindowStyles.ST_NO_AUTORESIZE and the flags on alignment.</summary>*/
    public class StaticText : Control
	{
		[DllImport("wx-c")] static extern IntPtr wxStaticText_ctor();
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxStaticText_Create(IntPtr self, IntPtr parent, int id, IntPtr label, int posX, int posY, int width, int height, uint style, IntPtr name);

		//---------------------------------------------------------------------
		
		public StaticText(IntPtr wxObject) 
			: base(wxObject) {}

		public StaticText()
			: base(wxStaticText_ctor())	{ }

		public StaticText(Window parent, int id, string label)
			: this(parent, id, label, wxDefaultPosition, wxDefaultSize, 0, null) { }

		public StaticText(Window parent, int id, string label, Point pos)
			: this(parent, id, label, pos, wxDefaultSize, 0, null) { }

		public StaticText(Window parent, int id, string label, Point pos, Size size)
			: this(parent, id, label, pos, size, 0, null) { }

		public StaticText(Window parent, int id, string label, Point pos, Size size, wx.WindowStyles style)
			: this(parent, id, label, pos, size, style, null) { }
			
		public StaticText(Window parent, int id, string label, Point pos, Size size, wx.WindowStyles style, string name)
			: base(wxStaticText_ctor())
		{
			if (!Create(parent, id, label, pos, size, style, name))
			{
				throw new InvalidOperationException("Failed to create StaticText");
			}
		}
		
		//---------------------------------------------------------------------
		// ctors with self created id
		
		public StaticText(Window parent, string label)
			: this(parent, Window.UniqueID, label, wxDefaultPosition, wxDefaultSize, 0, null) { }

		public StaticText(Window parent, string label, Point pos)
			: this(parent, Window.UniqueID, label, pos, wxDefaultSize, 0, null) { }

		public StaticText(Window parent, string label, Point pos, Size size)
			: this(parent, Window.UniqueID, label, pos, size, 0, null) { }

		public StaticText(Window parent, string label, Point pos, Size size, wx.WindowStyles style)
			: this(parent, Window.UniqueID, label, pos, size, style, null) { }
			
		public StaticText(Window parent, string label, Point pos, Size size, wx.WindowStyles style, string name)
			: this(parent, Window.UniqueID, label, pos, size, style, name) {}
		
		//---------------------------------------------------------------------

		public bool Create(Window parent, int id, string label, Point pos, Size size, wx.WindowStyles style, string name)
		{
            return this.Create(parent, id, wxString.SafeNew(label), pos, size, style, wxString.SafeNew(name));
        }
		public bool Create(Window parent, int id, wxString label, Point pos, Size size, wx.WindowStyles style, wxString name)
		{
			return wxStaticText_Create(wxObject, Object.SafePtr(parent), id, Object.SafePtr( label), pos.X, pos.Y, size.Width, size.Height, (uint)style, Object.SafePtr( name));
		}
	}
}
