//-----------------------------------------------------------------------------
// wx.NET - DirectAcyclGraph.cs
//
// Wrapper for wxArchiveInputStream and wxArchiveOutputStream.
//
// Written by Harald Meyer auf'm Hofe
// (C) 2010 by Harald Meyer auf'm Hofe
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: Graph.cs,v 1.2 2010/05/08 19:52:40 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Collections.Generic;

/** Classes on representing graphs.
 */
namespace wx.Graph
{
    /// <summary>
    /// Methods of graphs that can be provided without references to internal representations.
    /// </summary>
    public interface IGraph<DataType> : ICanBeMadeReadonly
    {
        /// <summary>
        /// Collection of node IDs.
        /// </summary>
        ICollection<int> NodeIDs { get; }

        /// <summary>
        /// A collection of tuples of integers that represent the arcs between the nodes.
        /// The integers are node IDs.
        /// </summary>
        ICollection<int[]> Arcs { get; }

        /// <summary>
        /// Returns a collection of that nodes A (designated by their IDs) where there is an arc from A to
        /// the node designated by <c>nodeID</c>.
        /// </summary>
        /// <param name="nodeID">The node that is the target of the selected edges</param>
        /// <returns></returns>
        ICollection<int> GetEdgesFromNode(int nodeID);

        /// <summary>
        /// Returns a collection of that nodes A (designated by their IDs) where there is an edge from the
        /// node designated by <c>nodeID</c> to A.
        /// </summary>
        /// <param name="nodeID">The node that is the target of the selected edges</param>
        /// <returns></returns>
        ICollection<int> GetEdgesToNode(int nodeID);

        /// <summary>
        /// This will return the data that is associated with the graph node of the provided ID.
        /// </summary>
        /// <param name="id">designates the graph node whose data will be returned.</param>
        /// <returns></returns>
        DataType GetDataOfNode(int id);
    }

    /// <summary>
    /// Represents a node in a graph.
    /// Please note, that instances can at most be part of exactly one graph.
    /// </summary>
    public class GraphNode<DataType> : ICanBeMadeReadonly
    {
        #region State
        static int _counter = 0;
        int _id;
        internal DirectedGraph<DataType> _graph = null;
        internal Dictionary<GraphEdge<DataType>, GraphEdge<DataType>> _edgesFromNode = new Dictionary<GraphEdge<DataType>, GraphEdge<DataType>>();
        internal Dictionary<GraphEdge<DataType>, GraphEdge<DataType>> _edgesToNode = new Dictionary<GraphEdge<DataType>, GraphEdge<DataType>>();
        /// <summary>
        /// This tag is for node oriented graph algorithms.
        /// </summary>
        internal object _tag = null;
        int _levelFromStart = -1;
        int _levelFromEnd = -1;

        bool _isReadonly = false;

        DataType _data = default(DataType);
        #endregion

        #region CTor
        public GraphNode()
        {
            this._id = _counter++;
        }

        /// <summary>
        /// Creates a new node of a unique ID associated with the provided data.
        /// </summary>
        /// <param name="data">The data of the new node.</param>
        public GraphNode(DataType data)
        {
            this._id = _counter++;
            this._data = data;
        }
        #endregion

        #region Properties
        /// <summary>
        /// A unique identifier of the node.
        /// </summary>
        public int Id { get { return this._id; } }

        /// <summary>
        /// This is exactly one more than the largest LevelFromStart of a predecessor node.
        /// </summary>
        public int LevelFromStart { get { return this._levelFromStart; } }

        /// <summary>
        /// This is exactly on more than the largest LevelFromEnd of a successor node.
        /// </summary>
        public int LevelFromEnd { get { return this._levelFromEnd; } }

        /// <summary>
        /// The data associated with this node.
        /// </summary>
        public DataType Data { get { return this._data; }
            set
            {
                if (this.IsReadonly)
                    throw new CannotChangeReadonly();
                this._data = value;
            }
        }
        #endregion

        #region Overrides
        public override string ToString()
        {
            return string.Format("Node({0:00})", this._id);
        }
        #endregion

        #region ICanBeMadeReadonly Member

        /// <summary>
        /// True iff this is readonly.
        /// </summary>
        public bool IsReadonly
        {
            get { return this._isReadonly; }
        }

        /// <summary>
        /// This will make this readonly.
        /// </summary>
        /// <returns></returns>
        public object MakeReadOnly()
        {
            this._isReadonly=true;
            if (this._data is ICanBeMadeReadonly)
                ((ICanBeMadeReadonly)this._data).MakeReadOnly();
            return this;
        }

        #endregion
    }

    /// <summary>
    /// Directed edge from one node to another.
    /// Please not that edges between the same nodes are equal.
    /// If edges bears data, two edges are usually equal if the from node, the to node, and the data are equal.
    /// </summary>
    public class GraphEdge<DataType> : ICanBeMadeReadonly
    {
        #region State
        GraphNode<DataType> _from;
        GraphNode<DataType> _to;

        /// <summary>
        /// This is for flow-oriented graph algorithms.
        /// </summary>
        internal object _tag = null;

        bool _isReadonly = false;
        #endregion

        #region CTor
        public GraphEdge(GraphNode<DataType> from, GraphNode<DataType> to)
        {
            this._from = from;
            this._to = to;
        }
        #endregion

        #region Properties
        public GraphNode<DataType> From { get { return this._from; } }
        public GraphNode<DataType> To { get { return this._to; } }
        #endregion

        #region Overrides
        public override string ToString()
        {
            return string.Format("({0:00}->{1:00})", this._from.Id, this._to.Id);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public override int GetHashCode()
        {
            return this._from.GetHashCode()^this._to.GetHashCode();
        }

        public override bool Equals(object obj)
        {
            if (obj.GetType() == typeof(GraphEdge<DataType>))
            {
                GraphEdge<DataType> e = (GraphEdge<DataType>)obj;
                return this.From.Equals(e.From) && this.To.Equals(e.To);
            }
            else
                return this.GetType().FullName.CompareTo(obj.GetType().FullName)==0;
        }
        #endregion

        #region ICanBeMadeReadonly Member

        /// <summary>
        /// True iff this is readonly.
        /// </summary>
        public bool IsReadonly
        {
            get { return this._isReadonly; }
        }

        /// <summary>
        /// This will make this readonly.
        /// </summary>
        /// <returns></returns>
        public object MakeReadOnly()
        {
            this._isReadonly = true;
            this._from.MakeReadOnly();
            this._to.MakeReadOnly();
            return this;
        }
        #endregion
    }

    /// <summary>
    /// Represents a graph, a collection of nodes and edges.
    /// 
    /// </summary>
    public class DirectedGraph<DataType> : ICanBeMadeReadonly, IGraph<DataType>
    {
        #region State
        Dictionary<int, GraphNode<DataType>> _nodes = new Dictionary<int, GraphNode<DataType>>();
        Dictionary<GraphEdge<DataType>, GraphEdge<DataType>> _edges = new Dictionary<GraphEdge<DataType>, GraphEdge<DataType>>();

        bool _isReadonly = false;
        #endregion

        #region CTor
        public DirectedGraph()
        {
        }
        #endregion

        #region ICanBeMadeReadonly Member

        /// <summary>
        /// True iff this is readonly.
        /// </summary>
        public bool IsReadonly
        {
            get { return this._isReadonly; }
        }

        /// <summary>
        /// This will make this readonly.
        /// </summary>
        /// <returns></returns>
        public object MakeReadOnly()
        {
            this._isReadonly = true;
            foreach (GraphNode<DataType> n in this._nodes.Values)
                n.MakeReadOnly();
            foreach (GraphEdge<DataType> e in this._edges.Values)
                e.MakeReadOnly();
            return this;
        }
        #endregion

        #region Modifiers
        /// <summary>
        /// Adds a new node to the graph.
        /// </summary>
        /// <param name="newNode">The new node.</param>
        /// <exception cref="CannotChangeReadonly">Will be thrown iff this is readonly.</exception>
        /// <exception cref="ApplicationException">Will be thrown iff the new node has already been added to another graph.</exception>
        public void Add(GraphNode<DataType> newNode)
        {
            if (this.IsReadonly)
                throw new CannotChangeReadonly();
            if (newNode._graph != null
                && newNode._graph != this)
                throw new ApplicationException("Cannot add already used node to a graph.");
            this._nodes.Add(newNode.Id, newNode);
        }

        /// <summary>
        /// Adds a new edge to the graph. The nodes will be added to the this graph of they are not already
        /// parts of the graph.
        /// </summary>
        /// <param name="edge">The new edge (between two nodes).</param>
        /// <exception cref="CannotChangeReadonly">Will be raised if this is readonly.</exception>
        /// <exception cref="ApplicationException">Will be raised if the nodes of the edge are already part of another
        /// graph.</exception>
        public void Add(GraphEdge<DataType> edge)
        {
            if (this.IsReadonly)
                throw new CannotChangeReadonly();
            if (edge.From._graph != null
                && edge.From._graph != this)
                throw new ApplicationException("Cannot add already used node to a graph.");
            if (edge.To._graph != null
                && edge.To._graph != this)
                throw new ApplicationException("Cannot add already used node to a graph.");
            edge.From._edgesFromNode[edge] = edge;
            edge.To._edgesToNode[edge] = edge;
            if (edge.From._graph == null)
            {
                this._nodes.Add(edge.From.Id, edge.From);
                edge.From._graph = this;
            }
            if (edge.To._graph == null)
            {
                this._nodes.Add(edge.To.Id, edge.To);
                edge.To._graph = this;
            }
        }
        #endregion

        #region IGraph Member

        /// <summary>
        /// Collection of node IDs.
        /// </summary>
        public ICollection<int> NodeIDs
        {
            get
            {
                List<int> result = new List<int>();
                foreach (GraphNode<DataType> n in this._nodes.Values)
                    result.Add(n.Id);
                return result;
            }
        }

        /// <summary>
        /// A collection of tuples of integers that represent the edges between the nodes.
        /// The integers are node IDs.
        /// </summary>
        public ICollection<int[]> Arcs
        {
            get 
            {
                List<int[]> result = new List<int[]>();
                foreach (GraphEdge<DataType> e in this._edges.Values)
                {
                    result.Add(new int[] { e.From.Id, e.To.Id });
                }
                return result;
            }
        }

        public ICollection<int> GetEdgesFromNode(int nodeID)
        {
            GraphNode<DataType> node = null;
            if (!this._nodes.TryGetValue(nodeID, out node))
                return null;
            List<int> result = new List<int>();
            foreach (GraphEdge<DataType> e in node._edgesFromNode.Values)
            {
                result.Add(e.To.Id);
            }
            return result;
        }

        public ICollection<int> GetEdgesToNode(int nodeID)
        {
            GraphNode<DataType> node = null;
            if (!this._nodes.TryGetValue(nodeID, out node))
                return null;
            List<int> result = new List<int>();
            foreach (GraphEdge<DataType> e in node._edgesToNode.Values)
                result.Add(e.From.Id);
            return result;
        }

        public DataType GetDataOfNode(int id)
        {
            GraphNode<DataType> n = null;

            if (this._nodes.TryGetValue(id, out n))
            {
                return n.Data;
            }
            else
                return default(DataType);
        }
        #endregion
    }

    public class TreeNode<DataType> : ICanBeMadeReadonly, ICloneable
    {
        #region State
        static int _counter = 0;
        int _id;

        TreeNode<DataType> _parent = null;
        Dictionary<int, TreeNode<DataType>> _children = new Dictionary<int, TreeNode<DataType>>();

        DataType _data = default(DataType);

        bool _readOnly = false;

        internal Tree<DataType> _tree = null;
        #endregion

        #region CTor
        public TreeNode()
        {
            this._id = _counter++;
        }

        /// <summary>
        /// Creates an instance with the provided data.
        /// </summary>
        /// <param name="data">The data that will be associated with the new node.</param>
        public TreeNode(DataType data)
        {
            this._id = _counter++;
            this._data = data;
        }

        /// <summary>
        /// Creates a deep copy of the argument and its children that is NOT readonly.
        /// </summary>
        /// <param name="src">A subtree.</param>
        public TreeNode(TreeNode<DataType> src)
        {
            this._id = _counter++;
            foreach (TreeNode<DataType> child in src._children.Values)
            {
                TreeNode<DataType> newChild = new TreeNode<DataType>(child);
                newChild._parent = this;
                this._children.Add(newChild.Id, newChild);
            }
        }
        #endregion

        #region Properties
        /// <summary>
        /// The ID of the node.
        /// </summary>
        public int Id { get { return this._id; } }

        /// <summary>
        /// The parent of this node. This is <c>null</c> if this is a root or this is not part of a tree.
        /// </summary>
        public TreeNode<DataType> Parent { get { return this._parent; } }

        /// <summary>
        /// Collection of children.
        /// </summary>
        public ICollection<TreeNode<DataType>> Children { get { return this._children.Values; } }

        /// <summary>
        /// Get or set the data that is associated with this node.
        /// </summary>
        public DataType Data { get { return this._data; }
            set
            {
                if (this.IsReadonly)
                    throw new CannotChangeReadonly();
                this._data = value;
            }
        }

        /// <summary>
        /// True iff this is the root node of a tree.
        /// </summary>
        public bool IsRoot { get { return this._tree != null && this._parent == null; } }

        /// <summary>
        /// True iff this is part of a tree.
        /// </summary>
        public bool IsInTree { get { return this._tree != null; } }
        #endregion

        #region Modifiers
        /// <summary>
        /// Adds a child to the node. Preconditions: This must not be read-only. Thsi must be a part of
        /// a tree. The new node must not be part of a tree.
        /// </summary>
        /// <param name="newChild">The new child node</param>
        /// <exception cref="ApplicationException">This is not part of a tree or the new node
        /// is already a part of a tree.</exception>
        /// <exception cref="CannotChangeReadonly">If this is read-only.</exception>
        public void Add(TreeNode<DataType> newChild)
        {
            if (this.IsReadonly)
                throw new CannotChangeReadonly();
            if (this._tree != null)
                throw new ApplicationException("Cannot add children to a node that is not part of a tree.");
            if (newChild._tree != null)
                throw new ApplicationException("Cannot add child that already is part of a tree.");

            this._children.Add(newChild.Id, newChild);
            newChild._tree = this._tree;
            newChild._parent = this;
        }

        /// <summary>
        /// Adds this tree node and all siblings to the argument.
        /// </summary>
        /// <param name="collector"></param>
        public void CollectNodes(ICollection<TreeNode<DataType>> collector)
        {
            collector.Add(this);
            foreach (TreeNode<DataType> child in this._children.Values)
                child.CollectNodes(collector);
        }

        /// <summary>
        /// Collects the arcs between tree nodes. Adds tuples of the form (parent ID, child ID) to the argument.
        /// </summary>
        /// <param name="collector">List that will be loaded.</param>
        public void CollectArcs(ICollection<int[]> collector)
        {
            if (this._parent != null)
                collector.Add(new int[] { this._parent.Id, this._id });
            foreach (TreeNode<DataType> child in this._children.Values)
                child.CollectArcs(collector);
        }

        /// <summary>
        /// Returns the tree node if the ID as defined by the argument.
        /// The result is <c>null</c> if neither this node nor one of its siblings
        /// bear this ID.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public TreeNode<DataType> Find(int id)
        {
            TreeNode<DataType> result = null;
            if (this._id == id)
                result = this;
            else
            {
                foreach (TreeNode<DataType> child in this._children.Values)
                {
                    result = child.Find(id);
                    if (result != null)
                        break;
                }
            }
            return result;
        }
        #endregion

        #region ICanBeMadeReadonly Member

        public bool IsReadonly
        {
            get { return this._readOnly; }
        }

        public object MakeReadOnly()
        {
            this._readOnly = true;
            foreach (TreeNode<DataType> n in this._children.Values)
                n.MakeReadOnly();
            return this;
        }

        #endregion

        #region Internal Helpers
        internal void SetTree(Tree<DataType> t)
        {
            this._tree = t;
            foreach (TreeNode<DataType> n in this._children.Values)
                n.SetTree(t);
        }
        #endregion

        #region ICloneable Member
        /// <summary>
        /// Returns a deep copy of this.
        /// </summary>
        /// <returns></returns>
        public object Clone()
        {
            return new TreeNode<DataType>(this);
        }

        #endregion
    }

    public class Tree<DataType> : ICanBeMadeReadonly, IGraph<DataType>
    {
        #region State
        TreeNode<DataType> _root = null;
        bool _readOnly = false;
        #endregion

        #region CTor
        public Tree()
        {
        }
        #endregion

        #region Tree Properties and Methods
        /// <summary>
        /// This is the root node of the tree. This is <c>null</c> if the tree is empty.
        /// </summary>
        public TreeNode<DataType> Root { get { return this._root; } }

        /// <summary>
        /// Sets the argument as a new root node.
        /// </summary>
        /// <param name="newRoot">The node that shall be the root node.</param>
        /// <exception cref="CannotChangeReadonly">Will be thrown if this is read-only.</exception>
        /// <exception cref="ApplicationException">If the argument is already part of a tree.</exception>
        public void SetRoot(TreeNode<DataType> newRoot)
        {
            if (this.IsReadonly)
                throw new CannotChangeReadonly();
            if (newRoot._tree != null)
                throw new ApplicationException();
            if (this._root != null)
            {
                this._root.SetTree(null);
                this._root = null;
            }
            this._root = newRoot;
            this._root.SetTree(this);
        }
        #endregion

        #region ICanBeMadeReadonly Member

        public bool IsReadonly
        {
            get { return this._readOnly; }
        }

        public object MakeReadOnly()
        {
            this._readOnly = true;
            if (this._root != null)
                this._root.MakeReadOnly();
            return this;
        }

        #endregion

        #region IGraph Member

        public ICollection<int> NodeIDs
        {
            get
            {
                List<TreeNode<DataType>> nodes = new List<TreeNode<DataType>>();
                if (this._root != null)
                    this._root.CollectNodes(nodes);
                List<int> result=new List<int>();
                foreach (TreeNode<DataType> n in nodes)
                    result.Add(n.Id);
                return result;
            }
        }

        public ICollection<int[]> Arcs
        {
            get
            {
                List<int[]> result = new List<int[]>();
                if (this._root != null)
                    this._root.CollectArcs(result);
                return result;
            }
        }

        public ICollection<int> GetEdgesFromNode(int nodeID)
        {
            List<int> result = new List<int>();
            if (this._root != null)
            {
                TreeNode<DataType> n = this._root.Find(nodeID);
                if (n != null)
                {
                    foreach (TreeNode<DataType> child in n.Children)
                        result.Add(child.Id);
                }
            }
            return result;
        }

        public ICollection<int> GetEdgesToNode(int nodeID)
        {
            List<int> result = new List<int>();
            if (this._root != null)
            {
                TreeNode<DataType> n = this._root.Find(nodeID);
                if (n.Parent != null)
                    result.Add(n.Parent.Id);
            }
            return result;
        }

        public DataType GetDataOfNode(int nodeId)
        {
            if (this._root == null)
                return default(DataType);
            TreeNode<DataType> n = this._root.Find(nodeId);
            if (n == null)
                return default(DataType);
            return n.Data;
        }
        #endregion
    }
}
