//-----------------------------------------------------------------------------
// wx.NET - PrintDialog.cs
//
// The wxPrintDialog wrapper classes.
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: PrintDialog.cs,v 1.10 2009/11/04 17:59:10 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Drawing;
using System.Runtime.InteropServices;

namespace wx
{
    public class PageSetupDialog : Object // HMaH: Fix - this is not a wx.Dialog
    {
        [DllImport("wx-c")] static extern IntPtr wxPageSetupDialog_ctor(IntPtr parent, IntPtr data);
        [DllImport("wx-c")] static extern IntPtr wxPageSetupDialog_GetPageSetupData(IntPtr self);
        // HMaH: Fix - This is not a wx.dialog. So, ShowModal has to be wrapped for this dialog again.
        [DllImport("wx-c")] static extern int wxPageSetupDialog_ShowModal(IntPtr self);

        //-----------------------------------------------------------------------------

        internal PageSetupDialog(IntPtr wxObject)
            : base(wxObject) { }

        public PageSetupDialog(Window parent)
            : this(parent, null) { }
        public PageSetupDialog(Window parent, PageSetupDialogData data)
            : this(wxPageSetupDialog_ctor(Object.SafePtr(parent), Object.SafePtr(data))) { }

        //-----------------------------------------------------------------------------

        public PageSetupDialogData PageSetupData
        {
            get { return (PageSetupDialogData)FindObject(wxPageSetupDialog_GetPageSetupData(wxObject), typeof(PageSetupDialogData)); }
        }

        /** <summary>Shows the dialog, returning wx.Window.wxID_OK if the user pressed OK, and wx.Window.wxID_CANCEL otherwise.
         * Please note, that this is not a wx.Dialog.</summary>*/
        public int ShowModal()
        {
            return wxPageSetupDialog_ShowModal(wxObject);
        }
    }

    /// <summary>
    /// The printer dialog.
    /// </summary>
    /// <remarks>
    /// \image html printpreview.png
    /// </remarks>
    public class PrintDialog : Object // HMaH: Fix - this is not a wx.Dialog
    {
        [DllImport("wx-c")] static extern IntPtr wxPrintDialog_ctor(IntPtr parent, IntPtr data);
        [DllImport("wx-c")] static extern IntPtr wxPrintDialog_ctorPrintData(IntPtr parent, IntPtr data);
        [DllImport("wx-c")] static extern IntPtr wxPrintDialog_GetPrintData(IntPtr self);
        [DllImport("wx-c")] static extern IntPtr wxPrintDialog_GetPrintDialogData(IntPtr self);
        [DllImport("wx-c")] static extern IntPtr wxPrintDialog_GetPrintDC(IntPtr self);
        // HMaH: Fix - This is not a wx.dialog. So, ShowModal has to be wrapped for this dialog again.
        [DllImport("wx-c")] static extern int wxPrintDialog_ShowModal(IntPtr self);

        //-----------------------------------------------------------------------------

        internal PrintDialog(IntPtr wxObject)
            : base(wxObject) { }

        public PrintDialog(Window parent)
            : this(parent, (PrintDialogData)null) { }
        public PrintDialog(Window parent, PrintDialogData data)
            : this(wxPrintDialog_ctor(Object.SafePtr(parent), Object.SafePtr(data))) { }

        public PrintDialog(Window parent, PrintData data)
            : this(wxPrintDialog_ctorPrintData(Object.SafePtr(parent), Object.SafePtr(data))) { }

        //-----------------------------------------------------------------------------

        public PrintData PrintData
        {
            get { return (PrintData)FindObject(wxPrintDialog_GetPrintData(wxObject), typeof(PrintData)); }
        }

        //-----------------------------------------------------------------------------

        public PrintDialogData PrintDialogData
        {
            get { return (PrintDialogData)FindObject(wxPrintDialog_GetPrintDialogData(wxObject), typeof(PrintDialogData)); }
        }

        //-----------------------------------------------------------------------------

        public DC PrintDC
        {
            get { return (DC)FindObject(wxPrintDialog_GetPrintDC(wxObject), typeof(DC)); }
        }

        //-----------------------------------------------------------------------------
        /** <summary>Shows the dialog, returning wx.Window.wxID_OK if the user pressed OK, and wx.Window.wxID_CANCEL otherwise.
         * Please note, that this is not a wx.Dialog.</summary>*/
        public int ShowModal()
        {
            return wxPrintDialog_ShowModal(wxObject);
        }
    }
}
