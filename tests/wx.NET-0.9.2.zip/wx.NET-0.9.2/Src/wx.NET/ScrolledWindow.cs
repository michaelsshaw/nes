//-----------------------------------------------------------------------------
// wx.NET - ScrolledWindow.cs
//
// The wxScrolledWindow wrapper class.
//
// Written by Jason Perkins (jason@379.com)
// (C) 2003 by 379, Inc.
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: ScrolledWindow.cs,v 1.26 2009/09/20 14:10:58 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Drawing;
using System.Runtime.InteropServices;

namespace wx
{
    /** <summary>The wx.ScrolledWindow class manages scrolling for its client area, transforming the coordinates according to the scrollbar positions, and setting the scroll positions, thumb sizes and ranges according to the area in view.
     * Starting from version 2.4 of wxWidgets, there are several ways to use a
     * wx.ScrolledWindow. In particular, there are now three ways to set the size of
     * the scrolling area:
     * One way is to set the scrollbars directly using a call to
     * wx.ScrolledWindow.SetScrollbars(). This is the way it used to be in any previous
     * version of  wxWidgets and it will be kept for backwards compatibility.
     *
     * An additional method of manual control, which requires a little less computation
     * of your own, is to set the total size of the scrolling area by calling either
     * wx.Window.VirtualSize, or wx.Window.FitInside(), and setting the scrolling
     * increments for it by calling wx.ScrolledWindow.SetScrollRate(). Scrolling in some
     * orientation is enabled by setting a non-zero increment for it.
     *
     * The most automatic and newest way is to simply let sizers determine the scrolling
     * area. This is now the default when you set an interior sizer into a
     * wx.ScrolledWindow with wx.Window.SetSizer. The scrolling area will be set to the
     * size requested by the sizer and the scrollbars will be assigned for each
     * orientation according to the need for them and the scrolling increment set by
     * wx.Scrolled.Window.SetScrollRate. As above, scrolling is only enabled in
     * orientations with a non-zero increment. You can influence the minimum size of the
     * scrolled area controlled by a sizer by calling wx.Window.SetVirtualSizeHints().
     *
     * Note: if Maximum size hints are still supported by SetVirtualSizeHints(), use
     * them at your own dire risk. They may or may not have been removed for 2.4, but it
     * really only makes sense to set minimum size hints here. We should probably replace
     * SetVirtualSizeHints() with SetMinVirtualSize() or similar and remove it entirely
     * in future.
     *
     * As with all windows, an application can draw onto a wx.ScrolledWindow using a
     * device context.
     *
     * You have the option of handling the OnPaint handler or overriding the <c>OnDraw()</c>
     * function, which is passed a pre-scrolled device context (prepared by <c>DoPrepareDC)</c>.
     *
     * If you don't wish to calculate your own scrolling, you must call <c>DoPrepareDC</c> when
     * not drawing from within <c>OnDraw</c>, to set the device origin for the device context
     * according to the current scroll position.
     *
     * A wx.ScrolledWindow will normally scroll itself and therefore its child windows as
     * well. It might however be desired to scroll a different window than itself: e.g.
     * when designing a spreadsheet, you will normally only have to scroll the
     * (usually white) cell area, whereas the (usually grey) label area will scroll very
     * differently. For this special purpose, you can call <c>SetTargetWindow</c> which means
     * that pressing the scrollbars will scroll a different window.
     *
     * Note that the underlying system knows nothing about scrolling coordinates, so that
     * all system functions (mouse events, expose events, refresh calls etc) as well as
     * the position of subwindows are relative to the "physical" origin of the scrolled
     * window. If the user insert a child window at position (10,10) and scrolls the
     * window down 100 pixels (moving the child window out of the visible area), the
     * child window will report a position of (10,-90).
     *
     * Remarks:
     * Use wx.ScrolledWindow for applications where the user scrolls by a fixed amount,
     * and where a 'page' can be interpreted to be the current visible portion of the
     * window. For more sophisticated applications, use the wx.ScrolledWindow
     * implementation as a guide to build your own scroll behaviour.
     *
     * See also wx.ScrollBar, wx.ClientDC, wx.PaintDC, and wx.VScrolledWindow.</summary>*/
	public class ScrolledWindow : Panel
	{
		[DllImport("wx-c")] static extern IntPtr wxScrollWnd_ctor(IntPtr parent, int id, int posX, int posY, int width, int height, uint style, IntPtr name);
		[DllImport("wx-c")] static extern void   wxScrollWnd_PrepareDC(IntPtr self, IntPtr dc);
		[DllImport("wx-c")] static extern void   wxScrollWnd_SetScrollbars(IntPtr self, int pixX, int pixY, int numX, int numY, int x, int y, bool noRefresh);
		[DllImport("wx-c")] static extern void   wxScrollWnd_GetViewStart(IntPtr self, ref int x, ref int y);
		[DllImport("wx-c")] static extern void   wxScrollWnd_GetScrollPixelsPerUnit(IntPtr self, ref int xUnit, ref int yUnit);
		
		[DllImport("wx-c")] static extern void   wxScrollWnd_CalcScrolledPosition(IntPtr self, int x, int y, ref int xx, ref int yy);
		[DllImport("wx-c")] static extern void   wxScrollWnd_CalcUnscrolledPosition(IntPtr self, int x, int y, ref int xx, ref int yy);
		[DllImport("wx-c")] static extern void   wxScrollWnd_GetVirtualSize(IntPtr self, ref int x, ref int y);
		[DllImport("wx-c")] static extern void   wxScrollWnd_Scroll(IntPtr self, int x, int y);
		[DllImport("wx-c")] static extern void   wxScrollWnd_SetScrollRate(IntPtr self, int xstep, int ystep);
		[DllImport("wx-c")] static extern void   wxScrollWnd_SetTargetWindow(IntPtr self, IntPtr window);

		//---------------------------------------------------------------------

		public ScrolledWindow(IntPtr wxObject) 
			: base(wxObject) { }

		public ScrolledWindow(Window parent)
            : this(parent, -1, wxDefaultPosition, wxDefaultSize, wx.WindowStyles.HSCROLL | wx.WindowStyles.VSCROLL) { }
			
		public ScrolledWindow(Window parent, int id)
            : this(parent, id, wxDefaultPosition, wxDefaultSize, wx.WindowStyles.HSCROLL | wx.WindowStyles.VSCROLL) { }
			
		public ScrolledWindow(Window parent, int id, Point pos)
            : this(parent, id, pos, wxDefaultSize, wx.WindowStyles.HSCROLL | wx.WindowStyles.VSCROLL) { }
			
		public ScrolledWindow(Window parent, int id, Point pos, Size size)
            : this(parent, id, pos, size, wx.WindowStyles.HSCROLL | wx.WindowStyles.VSCROLL) { }
			
		public ScrolledWindow(Window parent, int id, Point pos, Size size, wx.WindowStyles style)
			: base(wxScrollWnd_ctor(Object.SafePtr(parent), id, pos.X, pos.Y, size.Width, size.Height, (uint)style, IntPtr.Zero))
		{
			EVT_PAINT(new EventListener(OnPaint));
		}

		//---------------------------------------------------------------------

		public virtual void OnDraw(DC dc)
		{
		}

		//---------------------------------------------------------------------

		public override void PrepareDC(DC dc)
		{
			wxScrollWnd_PrepareDC(wxObject, dc.wxObject);
		}

		//---------------------------------------------------------------------

		public void SetScrollbars(int pixelsPerUnitX, int pixelsPerUnitY, int noUnitsX, int noUnitsY)
		{ 
			SetScrollbars(pixelsPerUnitY, pixelsPerUnitY, noUnitsY, noUnitsY, 0, 0, false); 
		}
		
		public void SetScrollbars(int pixelsPerUnitX, int pixelsPerUnitY, int noUnitsX, int noUnitsY, int x, int y)
		{ 
			SetScrollbars(pixelsPerUnitY, pixelsPerUnitY, noUnitsY, noUnitsY, x, y, false); 
		}
		
		public void SetScrollbars(int pixelsPerUnitX, int pixelsPerUnitY, int noUnitsX, int noUnitsY, int x, int y, bool noRefresh)
		{
			wxScrollWnd_SetScrollbars(wxObject, pixelsPerUnitX, pixelsPerUnitY, noUnitsX, noUnitsY, x, y, noRefresh);
		}

		//---------------------------------------------------------------------

		private void OnPaint(object sender, Event e)
		{
			PaintDC dc = new PaintDC(this);
			PrepareDC(dc);
			OnDraw(dc);
			dc.Dispose();
		}

		//---------------------------------------------------------------------

        /** <summary>Get the position at which the visible portion of the window starts.
         * If either of the scrollbars is not at the home position, x and/or y will be greater than zero.
         * Combined with wx.Window.ClientSize, the application can use this function to efficiently redraw only the
         * visible portion of the window. The positions are in logical pixels, so this is the result of GetViewStart()
         * multiplied by the number of pixels per scroll increment.
         * </summary>
         */
        public Point ViewStart
		{
			get
            {
                int x = -1; 
				int y = -1;
				this.GetViewStart(ref x, ref y);
                int xUnit = 1;
                int yUnit = 1;
                this.GetScrollPixelsPerUnit(ref xUnit, ref yUnit);
				return new Point(x*xUnit, y*yUnit);
			}
		}

        /** <summary>Get the position at which the visible portion of the window starts.
        * \params x Receives the first visible x position in scroll units.
        * \params y Receives the first visible y position in scroll units.
        *
        * If either of the scrollbars is not at the home position, x and/or y will be greater than zero.
        * Combined with wx.Window.ClientSize, the application can use this function to efficiently redraw only the
        * visible portion of the window. The positions are in logical scroll units, not pixels, so to convert to pixels
        * you will have to multiply by the number of pixels per scroll increment.
        * See also wx.ScrolledWindow.SetScrollbars()</summary>*/
		public void GetViewStart(ref int x, ref int y)
		{
			wxScrollWnd_GetViewStart(wxObject, ref x, ref y);
		}

		//---------------------------------------------------------------------

        /** <summary>Get the number of pixels per scroll unit (line), in each direction, as set by wx.ScrolledWindow.SetScrollbars().
         * A value of zero indicates no scrolling in that direction.
         * <list type="table">
         * <item><term>xUnit</term><description> Receives the number of pixels per horizontal unit.</description></item>
         * <item><term>yUnit</term><description> Receives the number of pixels per vertical unit.</description></item>
         * </list>
         * 
         * See also wx.ScrolledWindow.SetScrollbars(), wx.ScrolledWindow.GetVirtualSize()
         * </summary>
         */
        public void GetScrollPixelsPerUnit(ref int xUnit, ref int yUnit)
		{
			wxScrollWnd_GetScrollPixelsPerUnit(wxObject, ref xUnit, ref yUnit);
		}

        /** <summary>The result of GetScrollPixelsPerUnit() as size.
         * This returns the size of a square defining the scroll unit.
         * </summary>
         */
        public Size ScrollPixelsPerUnit
        {
            get
            {
                int x=-1;
                int y=-1;
                this.GetScrollPixelsPerUnit(ref x, ref y);
                return new Size(x, y);
            }
        }

		//---------------------------------------------------------------------

        /** <summary>Translates the logical coordinates to the device ones.
         * For example, if a window is scrolled 10 pixels to the bottom, the device coordinates of
         * the origin are (0, 0) (as always), but the logical coordinates are (0, 10) and so the call to
         * <c>CalcScrolledPosition(0, 10, &xx, &yy) will return 0 in yy.
         * See also CalcUnscrolledPosition().
         * </summary>
         */
		public void CalcScrolledPosition(int x, int y, ref int xx, ref int yy)
		{
			wxScrollWnd_CalcScrolledPosition(wxObject, x, y, ref xx, ref yy);
		}

        /** <summary>Translates the logical coordinates to the device ones.
         * For example, if a window is scrolled 10 pixels to the bottom, the device coordinates of
         * the origin are (0, 0) (as always), but the logical coordinates are (0, 10) and so the call to
         * CalcScrolledPosition(0,10,&xx,&yy) will return 0 in <c>yy</c>.
         * See also CalcUnscrolledPosition().
         * </summary>
         */
        public Point CalcScrolledPosition(Point unscrolledPosition)
        {
            int xx = -1;
            int yy = -1;
            CalcScrolledPosition(unscrolledPosition.X, unscrolledPosition.Y, ref xx, ref yy);
            return new Point(xx, yy);
        }

		//---------------------------------------------------------------------

        /** <summary>Translates the device coordinates to the logical ones.
         * For example, if a window is scrolled 10 pixels to the bottom, the device coordinates of the origin are
         * (0, 0) (as always), but the logical coordinates are (0, 10) and so the call to
         * CalcUnscrolledPosition(0,0,&xx,&yy) will return 10 in yy.
         * </summary>
         * <seealso cref="CalcScrolledPosition"/>
         */
        public void CalcUnscrolledPosition(int x, int y, ref int xx, ref int yy)
		{
			wxScrollWnd_CalcUnscrolledPosition(wxObject, x, y, ref xx, ref yy);
		}

        /** <summary>Translates the device coordinates to the logical ones.
         * For example, if a window is scrolled 10 pixels to the bottom, the device coordinates of the origin are
         * (0, 0) (as always), but the logical coordinates are (0, 10) and so the call to
         * CalcUnscrolledPosition(0,0,&xx,&yy) will return 10 in yy.
         * See also CalcScrolledPosition()
         * </summary>
         */
        public Point CalcUnscrolledPosition(Point scrolledPosition)
        {
            int xx = -1;
            int yy = -1;
            this.CalcUnscrolledPosition(scrolledPosition.X, scrolledPosition.Y, ref xx, ref yy);
            return new Point(xx, yy);
        }

		//---------------------------------------------------------------------

        /** <summary>Read the virtual size of the control here.
         * Gets the size in device units of the scrollable window area
         * (as opposed to the client size, which is the area of the window currently visible).
         * \param x Receives the length of the scrollable window, in pixels.
         * \param y Receives the height of the scrollable window, in pixels.
         *
         * Use wx.DC.DeviceToLogicalX() and wx.DC.DeviceToLogicalY() to translate these units to logical units.</summary>*/
        public Size GetVirtualSize()
        {
            int x = 0;
            int y = 0;
            wxScrollWnd_GetVirtualSize(wxObject, ref x, ref y);
            return new Size(x, y);
        }
		
		//---------------------------------------------------------------------
		
        /** <summary>Scrolls to the designated virtual position in scroll units.</summary>*/
		public void Scroll(int x, int y)
		{
			wxScrollWnd_Scroll(wxObject, x, y);
		}

        /** <summary>Scrolls to the designated virtual position in points.
         * This will do the translation via GetScrollPixelsPerUnit() for you.</summary>*/
        public void Scroll(Point pos)
        {
            int x = 0;
            int y = 0;
            this.GetScrollPixelsPerUnit(ref x, ref y);
            this.Scroll(pos.X/x, pos.Y/y);
        }

        //---------------------------------------------------------------------
		
		public void SetScrollRate(int xstep, int ystep)
		{
			wxScrollWnd_SetScrollRate(wxObject, xstep, ystep);
		}
		
		//---------------------------------------------------------------------
		
		public Window TargetWindow
		{
			set { wxScrollWnd_SetTargetWindow(wxObject, Object.SafePtr(value)); }
		}
	}
}
