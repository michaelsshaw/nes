//-----------------------------------------------------------------------------
// wx.NET - Image.cs
//
// The wxImage wrapper class.
//
// Written by Jason Perkins (jason@379.com)
// (C) 2003 by 379, Inc.
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: Image.cs,v 1.26 2010/05/08 19:54:35 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.IO;
using System.Drawing;
using System.Reflection;
using System.Collections;
using System.Runtime.InteropServices;

namespace wx
{
    /** <summary>This class encapsulates a platform-independent image.
     * An image can be created from data, or using wx.Bitmap.ConvertToImage. An image can be loaded from a
     * file in a variety of formats, and is extensible to new formats via image format handlers.
     * Functions are available to set and get image bits, so it can be used for basic image manipulation.
     * </summary>
     * <remarks>
     * A wxImage cannot (currently) be drawn directly to a wx.DC. Instead, a platform-specific wxBitmap object must be
     * created from it using the wxBitmap::wxBitmap(wxImage,int depth) constructor. This bitmap can then be drawn in a
     * device context, using wx.DC.DrawBitmap.
     * 
     * One colour value of the image may be used as a mask colour which will lead to the automatic creation of a wx.Mask
     * object associated to the bitmap object.
     *
     * \par Alpha channel support:
     * Starting from wxWidgets 2.5.0 wx.Image supports alpha channel data, that is in addition to a byte for the red,
     * green and blue colour components for each pixel it also stores a byte representing the pixel opacity. An alpha
     * value of 0 corresponds to a transparent pixel (null opacity) while a value of 255 means that the pixel is 100% opaque.
     *
     * Unlike RGB data, not all images have an alpha channel and before using GetAlpha you should check if this image contains
     * an alpha channel with HasAlpha. Note that currently only images loaded from PNG files with transparency information
     * will have an alpha channel but alpha support will be added to the other formats as well (as well as support for saving
     * images with alpha channel which also isn't implemented).
    */
    public class Image : Object
	{
	#region C API
		[DllImport("wx-c")] static extern IntPtr wxImage_ctor();
		[DllImport("wx-c")] static extern IntPtr wxImage_ctorByName(IntPtr name, BitmapType type);
		[DllImport("wx-c")] static extern IntPtr wxImage_ctorintintbool(int width, int height, bool clear);
		[DllImport("wx-c")] static extern IntPtr wxImage_ctorByImage(IntPtr image);
		[DllImport("wx-c")] static extern IntPtr wxImage_ctorByByteArray(IntPtr data, int length, BitmapType type);
		[DllImport("wx-c")] static extern void   wxImage_dtor(IntPtr self);
		
		[DllImport("wx-c")] static extern void   wxImage_Destroy(IntPtr self);
		
		[DllImport("wx-c")] static extern int    wxImage_GetHeight(IntPtr self);
		[DllImport("wx-c")] static extern int    wxImage_GetWidth(IntPtr self);
		[DllImport("wx-c")] static extern void   wxImage_InitAllHandlers();
		[DllImport("wx-c")] static extern void   wxImage_Rescale(IntPtr self, int width, int height);
		[DllImport("wx-c")] static extern IntPtr wxImage_Scale(IntPtr self, int width, int height);

		[DllImport("wx-c")] static extern void   wxImage_SetMask(IntPtr self, bool mask);
        [DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)]static extern bool wxImage_HasMask(IntPtr self);
		[DllImport("wx-c")] static extern void   wxImage_SetMaskColour(IntPtr self, byte r, byte g, byte b);

        [DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)]static extern bool wxImage_LoadFileByTypeId(IntPtr self, IntPtr name, BitmapType type, int index);
        [DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)]static extern bool wxImage_LoadFileByMimeTypeId(IntPtr self, IntPtr name, IntPtr mimetype, int index);
        [DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)]static extern bool wxImage_SaveFileByType(IntPtr self, IntPtr name, BitmapType type);
        [DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)]static extern bool wxImage_SaveFileByMimeType(IntPtr self, IntPtr name, IntPtr mimetype);
		
		[DllImport("wx-c")] static extern IntPtr wxImage_Copy(IntPtr self);
        [DllImport("wx-c")] static extern IntPtr wxImage_GetSubImage(IntPtr self, int x, int y, int w, int h);
		
		[DllImport("wx-c")] static extern void   wxImage_Paste(IntPtr self, IntPtr image, int x, int y);
		
		[DllImport("wx-c")] static extern IntPtr wxImage_ShrinkBy(IntPtr self, int xFactor, int yFactor);
		
		[DllImport("wx-c")] static extern IntPtr wxImage_Rotate(IntPtr self, double angle, ref Point centre_of_rotation, bool interpolating, ref Point offset_after_rotation);
		[DllImport("wx-c")] static extern IntPtr wxImage_Rotate90(IntPtr self, bool clockwise);
		[DllImport("wx-c")] static extern IntPtr wxImage_Mirror(IntPtr self, bool horizontally);
		
		[DllImport("wx-c")] static extern void   wxImage_Replace(IntPtr self, byte r1, byte g1, byte b1, byte r2, byte g2, byte b2);
		
		[DllImport("wx-c")] static extern IntPtr wxImage_ConvertToMono(IntPtr self, byte r, byte g, byte b);
		
		[DllImport("wx-c")] static extern void   wxImage_SetRGB(IntPtr self, int x, int y, byte r, byte g, byte b);
		
		[DllImport("wx-c")] static extern byte   wxImage_GetRed(IntPtr self, int x, int y);
		[DllImport("wx-c")] static extern byte   wxImage_GetGreen(IntPtr self, int x, int y);
		[DllImport("wx-c")] static extern byte   wxImage_GetBlue(IntPtr self, int x, int y);
		
		[DllImport("wx-c")] static extern void   wxImage_SetAlpha(IntPtr self, int x, int y, byte alpha);
		[DllImport("wx-c")] static extern byte   wxImage_GetAlpha(IntPtr self, int x, int y);

        [return: MarshalAs(UnmanagedType.U1)][DllImport("wx-c")]static extern bool wxImage_FindFirstUnusedColour(IntPtr self, ref byte r, ref byte g, ref byte b, byte startR, byte startG, byte startB);
        [return: MarshalAs(UnmanagedType.U1)][DllImport("wx-c")]static extern bool wxImage_SetMaskFromImage(IntPtr self, IntPtr mask, byte mr, byte mg, byte mb);

        [return: MarshalAs(UnmanagedType.U1)][DllImport("wx-c")]static extern bool wxImage_ConvertAlphaToMask(IntPtr self, byte threshold);

        [return: MarshalAs(UnmanagedType.U1)][DllImport("wx-c")]static extern bool wxImage_CanRead(IntPtr name);
		[DllImport("wx-c")] static extern int    wxImage_GetImageCount(IntPtr name, int type);

        [DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)]static extern bool wxImage_Ok(IntPtr self);
		//--Alex
		[DllImport("wx-c")] static extern byte   wxImage_GetMaskRed(IntPtr self);
		[DllImport("wx-c")] static extern byte   wxImage_GetMaskGreen(IntPtr self);
		[DllImport("wx-c")] static extern byte   wxImage_GetMaskBlue(IntPtr self);

        [return: MarshalAs(UnmanagedType.U1)][DllImport("wx-c")]static extern bool wxImage_HasPalette(IntPtr self);
		[DllImport("wx-c")] static extern IntPtr wxImage_GetPalette(IntPtr self);
		[DllImport("wx-c")] static extern void   wxImage_SetPalette(IntPtr self, IntPtr palette);
		
		[DllImport("wx-c")] static extern void   wxImage_SetOption(IntPtr self, IntPtr name, IntPtr value);
		[DllImport("wx-c")] static extern void   wxImage_SetOption2(IntPtr self, IntPtr name, int value);
		[DllImport("wx-c")] static extern IntPtr wxImage_GetOption(IntPtr self, IntPtr name);
		[DllImport("wx-c")] static extern int    wxImage_GetOptionInt(IntPtr self, IntPtr name);
        [return: MarshalAs(UnmanagedType.U1)][DllImport("wx-c")]static extern bool wxImage_HasOption(IntPtr self, IntPtr name);
		
		[DllImport("wx-c")] static extern ulong  wxImage_CountColours(IntPtr self, ulong stopafter);
		
		[DllImport("wx-c")] static extern ulong  wxImage_ComputeHistogram(IntPtr self, IntPtr h);
		
		[DllImport("wx-c")] static extern IntPtr wxImage_GetFirstHandlerNode();
		[DllImport("wx-c")] static extern void   wxImage_AddHandler(IntPtr handler);
		[DllImport("wx-c")] static extern void   wxImage_InsertHandler(IntPtr handler);
        [DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)]static extern bool wxImage_RemoveHandler(IntPtr name);
		[DllImport("wx-c")] static extern IntPtr wxImage_FindHandler(IntPtr name);
		[DllImport("wx-c")] static extern IntPtr wxImage_FindHandler2(IntPtr name, int imageType);
		[DllImport("wx-c")] static extern IntPtr wxImage_FindHandler3(int imageType);
		[DllImport("wx-c")] static extern IntPtr wxImage_FindHandlerMime(IntPtr mimetype);
		
		[DllImport("wx-c")] static extern IntPtr wxImage_GetImageExtWildcard();
		
		[DllImport("wx-c")] static extern void   wxImage_CleanUpHandlers();
		
		//[DllImport("wx-c")] static extern void   wxImage_InitStandardHandlers();

		[DllImport("wx-c")] public static extern IntPtr wxNode_GetData(IntPtr node);
		[DllImport("wx-c")] public static extern IntPtr wxNode_GetPrevious(IntPtr node);
		[DllImport("wx-c")] public static extern IntPtr wxNode_GetNext(IntPtr node);
		#endregion
		//---------------------------------------------------------------------

		#region Init, CTor, DTor
		private static bool handlersLoaded = false;
		
		public static void InitAllHandlers()
		{
			// We only want to load the image handlers once.
			if (!handlersLoaded) 
			{
				wxImage_InitAllHandlers();
				handlersLoaded = true;
			}
		}

		static Image()
		{
			InitAllHandlers();
		}
		
		public Image(IntPtr wxObject)
			: base(wxObject) {}

		public Image()
			: this(wxImage_ctor()) {}

		// Normally BITMAP_TYPE_ANY would be used, unless we want to read a resource
		public Image(string name, BitmapType type) : this(LoadPossibleResource(name, type, Assembly.GetCallingAssembly())) {}
		
		public Image(string name, Assembly ResourceAssembly) 
			: this(LoadImageResourceFromByteArray(name, ResourceAssembly)) {}

		public Image(string name)
            : this(wxString.SafeNew(name)) {}
        public Image(wxString name)
			: this(wxImage_ctorByName(Object.SafePtr(name), BitmapType.wxBITMAP_TYPE_ANY)) {}

		public Image(int width, int height)
			: this(width, height, true) {}

		public Image(byte[] data, BitmapType type) 
			: this(LoadImageFromByteArray(data, type)) {}

		public Image(int width, int height, bool clear)
			: this(wxImage_ctorintintbool(width, height, clear)) {}
			
		public Image(Image image)
			: this(wxImage_ctorByImage(Object.SafePtr(image))) {}
			
		protected override void CallDTor ()
		{
			wxImage_dtor(this.wxObject);
		}

		#endregion

        /** <summary>Helper reading a byte buffer from a zip resource.</summary>*/
        static byte[] BufferFromZipResource(string archiveName, string resourceName)
        {
            using (System.IO.Stream s = wx.Archive.ZipResource.FindResource(System.Reflection.Assembly.GetCallingAssembly(),
                                archiveName, resourceName))
            {
                if (s == null)
                    throw new ArgumentException(string.Format("file 'zrs:{0}//{1}' not found", archiveName, resourceName));
                int length = (int)s.Length;
                byte[] buffer = new byte[length];
                s.Read(buffer, 0, length);
                return buffer;
            }
        }

        /** <summary>CTor for ZipResource support.</summary>
         * <remarks>
         * This will load image <c>resourceName</c> from ZipResource file or directory <c>archiveName</c>.
         * \code
         wx.ZipResource.AddCatalogLookupPrefix(@"..\Utils\MemLogDisplay");
         wx.Image img=new wx.Image("archiveName.zrs", "iconname.png");
         \endcode
         * </remarks>
         */
        public Image(string archiveName, string resourceName)
            : this(BufferFromZipResource(archiveName, resourceName), BitmapType.wxBITMAP_TYPE_ANY)
        {
        }

		//---------------------------------------------------------------------

		private static IntPtr LoadPossibleResource(string name, BitmapType type, Assembly asm)
		{
            if (type == BitmapType.wxBITMAP_TYPE_RESOURCE)
                return Object.SafePtr(new Image(name, asm));
            else
            {
                wxString wxName = wxString.SafeNew(name);
                return wxImage_ctorByName(Object.SafePtr(wxName), type);
            }
		}

		//---------------------------------------------------------------------

		private static IntPtr LoadImageResourceFromByteArray(string ResourceName, Assembly ResourceAssembly)
		{
			byte[] ImageBytes;

			ManifestResourceInfo mri = ResourceAssembly.GetManifestResourceInfo(ResourceName);
			if (mri == null)
				throw new ArgumentException("No resource named \"" + ResourceName + "\" was found in the assembly.");

			Stream stm = ResourceAssembly.GetManifestResourceStream(ResourceName);

			BinaryReader binr = new BinaryReader(stm);
			ImageBytes = binr.ReadBytes(Convert.ToInt32(stm.Length));

			return Object.SafePtr(new Image(ImageBytes, BitmapType.wxBITMAP_TYPE_ANY));
		}

		//---------------------------------------------------------------------

		private static IntPtr LoadImageFromByteArray(byte[] data, BitmapType type)
		{
			IntPtr DataPtr = IntPtr.Zero;
			DataPtr = Marshal.AllocHGlobal(data.Length);

			Marshal.Copy(data, 0, DataPtr, data.Length);
			
			return wxImage_ctorByByteArray(DataPtr, data.Length, type);
		}

		//---------------------------------------------------------------------
		
		public void Destroy()
		{
			wxImage_Destroy(wxObject);
		}
		
		//---------------------------------------------------------------------

		public int Height
		{
			get { return wxImage_GetHeight(wxObject); }
		}

		//---------------------------------------------------------------------
		
		public bool LoadFile(string path)
		{
			return LoadFile(path, BitmapType.wxBITMAP_TYPE_ANY, -1);
		}
		
		public bool LoadFile(string path, BitmapType type)
		{
			return LoadFile(path, type, -1);
		}

        public bool LoadFile(string path, BitmapType type, int index)
        {
            return this.LoadFile(wxString.SafeNew(path), type, index);
        }
		public bool LoadFile(wxString path, BitmapType type, int index)
		{
			return wxImage_LoadFileByTypeId(wxObject, Object.SafePtr(path), type, -1);
		}
		
		//---------------------------------------------------------------------
		
		public bool LoadFile(string name, string mimetype)
		{
			return LoadFile(name, mimetype, -1);
		}

        public bool LoadFile(string name, string mimetype, int index)
        {
            return this.LoadFile(wxString.SafeNew(name), wxString.SafeNew(mimetype));
        }
		public bool LoadFile(wxString name, wxString mimetype, int index)
		{
			return wxImage_LoadFileByMimeTypeId(wxObject, Object.SafePtr(name), Object.SafePtr(mimetype), index);
		}
		
		//---------------------------------------------------------------------

        	public bool SaveFile(string path)
		{ 
			return SaveFile(path, BitmapType.wxBITMAP_TYPE_ANY); 
		}

        public bool SaveFile(string path, BitmapType type)
        {
            return this.SaveFile(wxString.SafeNew(path), type);
        }
		public bool SaveFile(wxString path, BitmapType type)
		{
			return wxImage_SaveFileByType(wxObject, Object.SafePtr(path), type);
		}
		
		//---------------------------------------------------------------------
		
		public bool SaveFile(string name, string mimetype)
        {
            return this.SaveFile(wxString.SafeNew(name), wxString.SafeNew(mimetype));
        }
		public bool SaveFile(wxString name, wxString mimetype)
		{
			return wxImage_SaveFileByMimeType(wxObject, Object.SafePtr(name), Object.SafePtr(mimetype));
		}

		//---------------------------------------------------------------------

		public Image Rescale(int width, int height)
		{
			wxImage_Rescale(wxObject, width, height);
			return this;
		}

		//---------------------------------------------------------------------

		public Image Scale(int width, int height)
		{
			return new Image(wxImage_Scale(wxObject, width, height));
		}

		//---------------------------------------------------------------------

		public int Width
		{
			get { return wxImage_GetWidth(wxObject); }
		}

		//---------------------------------------------------------------------

		public void SetMaskColour(byte r, byte g, byte b)
		{
			wxImage_SetMaskColour(wxObject, r, g, b);
		}
		
		//---------------------------------------------------------------------


        /// <summary>
        /// Get or set the colour defining the mask. The mask colour will be shown transparent.
        /// This will return <c>null</c> if not <c>this.Mask</c>.
        /// </summary>
		public Colour MaskColour
		{
			set { SetMaskColour(value.Red, value.Green, value.Blue); }
            get
            {
                if (this.Mask)
                    return new Colour(this.MaskRed, this.MaskGreen, this.MaskBlue);
                else
                    return null;
            }
		}
		
		//---------------------------------------------------------------------

		public bool Mask
		{
			set { wxImage_SetMask(wxObject, value); }
			get { return wxImage_HasMask(wxObject); }
		}
		
		//---------------------------------------------------------------------
		
		public Image Copy()
		{
			return new Image(wxImage_Copy(wxObject));
		}
		
		//---------------------------------------------------------------------
		
		public Image SubImage(Rectangle rect)
		{
			return (Image)FindObject(wxImage_GetSubImage(wxObject, rect.X, rect.Y, rect.Width, rect.Height), typeof(Image));
		}
		
		//---------------------------------------------------------------------
		
		public void Paste(Image image, int x, int y)
		{
			wxImage_Paste(wxObject, Object.SafePtr(image), x, y);
		}
		
		//---------------------------------------------------------------------
		
		public Image ShrinkBy(int xFactor, int yFactor)
		{
			return new Image(wxImage_ShrinkBy(wxObject, xFactor, yFactor));
		}
		
		//---------------------------------------------------------------------
		
		public Image Rotate(double angle, Point centre_of_rotation)
		{
			Point dummy = new Point();
			return Rotate(angle, centre_of_rotation, true, dummy);
		}
		
		public Image Rotate(double angle, Point centre_of_rotation, bool interpolating)
		{
			Point dummy = new Point();
			return Rotate(angle, centre_of_rotation, interpolating, dummy);
		}
		
		public Image Rotate(double angle, Point centre_of_rotation, bool interpolating, Point offset_after_rotation)
		{
			return new Image(wxImage_Rotate(wxObject, angle, ref centre_of_rotation, interpolating, ref offset_after_rotation));
		}
		
		//---------------------------------------------------------------------
		
		public Image Rotate90()
		{
			return Rotate90(true);
		}
		
		public Image Rotate90(bool clockwise)
		{
			return new Image(wxImage_Rotate90(wxObject, clockwise));
		}
		
		//---------------------------------------------------------------------
		
		public Image Mirror()
		{
			return Mirror(true);
		}
		
		public Image Mirror(bool horizontally)
		{
			return new Image(wxImage_Mirror(wxObject, horizontally));
		}
		
		//---------------------------------------------------------------------
		
		public void Replace(byte r1, byte g1, byte b1, byte r2, byte g2, byte b2)
		{
			wxImage_Replace(wxObject, r1, g1, b1, r2, g2, b2);
		}
		
		//---------------------------------------------------------------------
		
		public void ConvertToMono(byte r, byte g, byte b)
		{
			wxImage_ConvertToMono(wxObject, r, g, b);
		}
		
		//---------------------------------------------------------------------
		
		public void SetRGB(int x, int y, byte r, byte g, byte b)
		{
			wxImage_SetRGB(wxObject, x, y, r, g, b);
		}

        public void setColour(int x, int y, wx.Colour colour)
        {
            this.SetRGB(x, y, colour.Red, colour.Green, colour.Blue);
        }

		//---------------------------------------------------------------------
		
		public byte GetRed(int x, int y)
		{
			return wxImage_GetRed(wxObject, x, y);
		}
		
		//---------------------------------------------------------------------
		
		public byte GetGreen(int x, int y)
		{
			return wxImage_GetGreen(wxObject, x, y);
		}
		
		//---------------------------------------------------------------------
		
		public byte GetBlue(int x, int y)
		{
			return wxImage_GetBlue(wxObject, x, y);
		}


        public wx.Colour GetColour(int x, int y)
        {
            return new Colour(this.GetRed(x, y), this.GetRed(x, y), GetGreen(x, y), this.GetBlue(x, y));
        }

		//---------------------------------------------------------------------
		
		public void SetAlpha(int x, int y, byte alpha)
		{
			wxImage_SetAlpha(wxObject, x, y, alpha);
		}
		
		//---------------------------------------------------------------------
		
		public byte GetAlpha(int x, int y)
		{
			return wxImage_GetAlpha(wxObject, x, y);
		}
		
		//---------------------------------------------------------------------
		
		public bool FindFirstUnusedColour(ref byte r, ref byte g, ref byte b)
		{
			return FindFirstUnusedColour(ref r, ref g, ref b, 1, 0, 0);
		}
		
		public bool FindFirstUnusedColour(ref byte r, ref byte g, ref byte b, byte startR)
		{
			return FindFirstUnusedColour(ref r, ref g, ref b, startR, 0, 0);
		}
		
		public bool FindFirstUnusedColour(ref byte r, ref byte g, ref byte b, byte startR, byte startG)
		{
			return FindFirstUnusedColour(ref r, ref g, ref b, startR, startG, 0);
		}
		
		public bool FindFirstUnusedColour(ref byte r, ref byte g, ref byte b, byte startR, byte startG, byte startB)
		{
			return wxImage_FindFirstUnusedColour(wxObject, ref r, ref g, ref b, startR, startG, startB);
		}
		
		//---------------------------------------------------------------------
		
		public bool SetMaskFromImage(Image mask, byte mr, byte mg, byte mb)
		{
			return wxImage_SetMaskFromImage(wxObject, Object.SafePtr(mask), mr, mg, mb);
		}
		
		//---------------------------------------------------------------------
		
		public bool ConvertAlphaToMask()
		{
			return ConvertAlphaToMask(128);
		}
		
		public bool ConvertAlphaToMask(byte threshold)
		{
			return wxImage_ConvertAlphaToMask(wxObject, threshold);
		}
		
		//---------------------------------------------------------------------

        public static bool CanRead(string name)
        {
            return CanRead(wxString.SafeNew(name));
        }
		public static bool CanRead(wxString name)
		{
			return wxImage_CanRead(Object.SafePtr(name));
		}
		
		//---------------------------------------------------------------------
		
		public static int GetImageCount(string name)
		{
			return GetImageCount(name, BitmapType.wxBITMAP_TYPE_ANY);
		}

        public static int GetImageCount(string name, BitmapType type)
        {
            return GetImageCount(wxString.SafeNew(name), type);
        }
		public static int GetImageCount(wxString name, BitmapType type)
		{
			return wxImage_GetImageCount(Object.SafePtr(name), (int)type);
		}
		
		//---------------------------------------------------------------------
		
		public bool Ok
		{
			get { return wxImage_Ok(wxObject); }
		}
		
		//---------------------------------------------------------------------
		
		public byte MaskRed
		{
			get { return wxImage_GetMaskRed(wxObject); }
		}
		
		//---------------------------------------------------------------------
		
		public byte MaskGreen
		{
			get { return wxImage_GetMaskGreen(wxObject); }
		}
		
		//---------------------------------------------------------------------
		
		public byte MaskBlue
		{
			get { return wxImage_GetMaskBlue(wxObject); }
		}
		
		//---------------------------------------------------------------------
		
		public bool HasPalette()
		{
			return wxImage_HasPalette(wxObject);
		}
		
		//---------------------------------------------------------------------
		
		public Palette Palette
		{
			get { return (Palette)FindObject(wxImage_GetPalette(wxObject), typeof(Palette)); }
			set { wxImage_SetPalette(wxObject, Object.SafePtr(value)); }
		}
		
		//---------------------------------------------------------------------

        public void SetOption(string name, string value)
        {
            this.SetOption(wxString.SafeNew(name), wxString.SafeNew(value));
        }
		public void SetOption(wxString name, wxString value)
		{
			wxImage_SetOption(wxObject, Object.SafePtr(name), Object.SafePtr(value));
		}
		
		//---------------------------------------------------------------------

        public void SetOption(string name, int value)
        {
            this.SetOption(wxString.SafeNew(name), value);
        }
		public void SetOption(wxString name, int value)
		{
			wxImage_SetOption2(wxObject, Object.SafePtr(name), value);
		}
		
		//---------------------------------------------------------------------

        public string GetOption(string name)
        {
            return this.GetOption(wxString.SafeNew(name));
        }
		public string GetOption(wxString name)
		{
			return new wxString(wxImage_GetOption(wxObject, Object.SafePtr(name)), true);
		}
		
		//---------------------------------------------------------------------
		
		public int GetOptionInt(string name)
		{
            return this.GetOptionInt(wxString.SafeNew(name));
        }
        public int GetOptionInt(wxString name)
        {
			return wxImage_GetOptionInt(wxObject, Object.SafePtr(name));
		}
		
		//---------------------------------------------------------------------

        public bool HasOption(string name)
        {
            return this.HasOption(wxString.SafeNew(name));
        }
		public bool HasOption(wxString name)
		{
			return wxImage_HasOption(wxObject, Object.SafePtr(name));
		}
		
		//---------------------------------------------------------------------
		
		public ulong CountColours()
		{
			return CountColours(ulong.MaxValue-1);
		}
		
		//---------------------------------------------------------------------
		
		public ulong CountColours(ulong stopafter)
		{
			return wxImage_CountColours(wxObject, stopafter);
		}
		
		//---------------------------------------------------------------------
		
		public ulong ComputeHistogram(ImageHistogram h)
		{
			return wxImage_ComputeHistogram(wxObject, Object.SafePtr(h));
		}
		
		//---------------------------------------------------------------------

        public static ImageHandler[] Handlers
        {
            get
            {
                IntPtr wl = wxImage_GetFirstHandlerNode();
                ArrayList al = new ArrayList();
                while (wl != IntPtr.Zero)
                {
                    al.Add(Object.FindObject(wxNode_GetData(wl), typeof(ImageHandler)));
                    wl = wxNode_GetNext(wl);
                }
                ImageHandler[] result = new ImageHandler[al.Count];
                for (int i = 0; i < al.Count; i++)
                    result[i] = (ImageHandler)al[i];

                return result;
            }
        }
		
		
		//---------------------------------------------------------------------
		
		public static void AddHandler(ImageHandler handler)
		{
			wxImage_AddHandler(Object.SafePtr(handler));
		}
		
		//---------------------------------------------------------------------
		
		public static void InsertHandler(ImageHandler handler)
		{
			wxImage_InsertHandler(Object.SafePtr(handler));
		}
		
		//---------------------------------------------------------------------
		
        /** <summary>Removes the image handler of the provided name.
         * The handler is not deleted. So, please ensure that the designated
         * handler has a wx.NET wrapper for instancestoring a reference to
         * FindHandler().
         *</summary>*/
        public static bool RemoveHandler(string name)
		{
            wxString wxName = wxString.SafeNew(name);
			return wxImage_RemoveHandler(Object.SafePtr(wxName));
		}
        
		//---------------------------------------------------------------------
		
		public static ImageHandler FindHandler(string name)
		{
            wxString wxName = wxString.SafeNew(name);
            return (ImageHandler)FindObject(wxImage_FindHandler(Object.SafePtr(wxName)));
		}
		
		//---------------------------------------------------------------------
		
		public static ImageHandler FindHandler(string extension, int imageType)
		{
            wxString wxextension = wxString.SafeNew(extension);
            return (ImageHandler)FindObject(wxImage_FindHandler2(Object.SafePtr(wxextension), imageType));
		}
		
		//---------------------------------------------------------------------
		
		public static ImageHandler FindHandler(int imageType)
		{
			return (ImageHandler)FindObject(wxImage_FindHandler3(imageType));
		}
		
		//---------------------------------------------------------------------
		
		public static ImageHandler FindHandlerMime(string mimetype)
		{
			wxString wxMimeType=wxString.SafeNew(mimetype);
			return (ImageHandler)FindObject(wxImage_FindHandlerMime(Object.SafePtr(wxMimeType)));
		}
		
		//---------------------------------------------------------------------
		
		public static string ImageExtWildcard
		{
			get { return new wxString(wxImage_GetImageExtWildcard(), true); }
		}
		
		//---------------------------------------------------------------------
		
		public static void CleanUpHandlers()
		{
			wxImage_CleanUpHandlers();
		}
	}
	
	//---------------------------------------------------------------------
	
	public class ImageHandler : Object
	{
		[DllImport("wx-c")] static extern void   wxImageHandler_SetName(IntPtr self, IntPtr name);
        [DllImport("wx-c")] static extern void   wxImageHandler_SetExtension(IntPtr self, IntPtr ext);
		[DllImport("wx-c")] static extern void   wxImageHandler_SetType(IntPtr self, int type);
        [DllImport("wx-c")] static extern void   wxImageHandler_SetMimeType(IntPtr self, IntPtr type);
		[DllImport("wx-c")] static extern IntPtr wxImageHandler_GetName(IntPtr self);
		[DllImport("wx-c")] static extern IntPtr wxImageHandler_GetExtension(IntPtr self);
		[DllImport("wx-c")] static extern int   wxImageHandler_GetType(IntPtr self);
		[DllImport("wx-c")] static extern IntPtr wxImageHandler_GetMimeType(IntPtr self);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]static extern bool wxImageHandler_CanReadBuffer(IntPtr self, IntPtr data, int size);
        [DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)]static extern bool wxImageHandler_CanReadFilename(IntPtr self, IntPtr filename);
		
		//---------------------------------------------------------------------
	
		public ImageHandler(IntPtr wxObject)
			: base(wxObject) {}
		
		//---------------------------------------------------------------------
		
		public string Name
		{
			get { return new wxString(wxImageHandler_GetName(wxObject), true); }
			set
            {
                wxString wxValue = new wxString(value);
                wxImageHandler_SetName(wxObject, wxValue.wxObject);
            }
		}
		
		//---------------------------------------------------------------------
		
		public string Extension
		{
			get { return new wxString(wxImageHandler_GetExtension(wxObject), true); }
			set
            {
                wxString wxValue = new wxString(value);
                wxImageHandler_SetExtension(wxObject, wxValue.wxObject);
            }
		}
		
		//---------------------------------------------------------------------
		
		public int Type
		{
			get { return wxImageHandler_GetType(wxObject); }
			set { wxImageHandler_SetType(wxObject, value); }
		}
		
		//---------------------------------------------------------------------
		
		public string MimeType
		{
			get { return new wxString(wxImageHandler_GetMimeType(wxObject), true); }
			set
            {
                wxString wxValue = new wxString(value);
                wxImageHandler_SetMimeType(wxObject, wxValue.wxObject);
            }
		}

      // --------------------------------------------------------------------

      public override string ToString()
      {
         return string.Format("ImageHandler {0}({2}): ext:{1}, mime:{3}", Name, Extension, Type, MimeType);
      }

        /** <summary>Returns true iff this handler can read the provided stream.
         *</summary>*/
        public bool CanRead(byte[] buffer)
        {
            IntPtr DataPtr = IntPtr.Zero;
            DataPtr = Marshal.AllocHGlobal(buffer.Length);
            Marshal.Copy(buffer, 0, DataPtr, buffer.Length);
            bool erg = wxImageHandler_CanReadBuffer(this.wxObject, DataPtr, buffer.Length);
            return erg;
        }

        /** <summary>Returns true iff this handler can read the file of the provided name.
         *</summary>*/
        public bool CanRead(string filename)
        {
            return CanRead(new wxString(filename));
        }
        public bool CanRead(wxString filename)
        {
            return wxImageHandler_CanReadFilename(Object.SafePtr(this), Object.SafePtr(filename));
        }
    }
	
	//---------------------------------------------------------------------
	
	public class ImageHistogramEntry : Object
	{
		[DllImport("wx-c")] static extern IntPtr wxImageHistogramEntry_ctor();
		[DllImport("wx-c")] static extern void   wxImageHistogramEntry_dtor(IntPtr self);
		[DllImport("wx-c")] static extern ulong  wxImageHistogramEntry_index(IntPtr self);
		[DllImport("wx-c")] static extern void   wxImageHistogramEntry_Setindex(IntPtr self, ulong v);
		[DllImport("wx-c")] static extern ulong  wxImageHistogramEntry_value(IntPtr self);
		[DllImport("wx-c")] static extern void   wxImageHistogramEntry_Setvalue(IntPtr self, ulong v);
		
		//---------------------------------------------------------------------
		
		public ImageHistogramEntry(IntPtr wxObject)
			: base(wxObject) 
		{
			this.wxObject = wxObject;
		}
		
		internal ImageHistogramEntry(IntPtr wxObject, bool memOwn)
			: base(wxObject)
		{ 
			this.memOwn = memOwn;
			this.wxObject = wxObject;
		}
			
		public ImageHistogramEntry()
			: this(wxImageHistogramEntry_ctor(), true) {}
			
		//---------------------------------------------------------------------
				
		public override void Dispose()
		{
			if (!disposed)
			{
                if (wxObject != IntPtr.Zero)
				{
					if (memOwn)
					{
						wxImageHistogramEntry_dtor(wxObject);
						memOwn = false;
					}
				}
				RemoveObject(wxObject);
				wxObject = IntPtr.Zero;
                --validInstancesCount;
                disposed = true;
			}
			
			base.Dispose();
			GC.SuppressFinalize(this);
		}
		
		//---------------------------------------------------------------------
		
		~ImageHistogramEntry() 
		{
			Dispose();
		}
		
		//---------------------------------------------------------------------
		
		public ulong index
		{
			get { return wxImageHistogramEntry_index(wxObject); }
			set { wxImageHistogramEntry_Setindex(wxObject, value); }
		}
		
		//---------------------------------------------------------------------
		
		public ulong value
		{
			get { return wxImageHistogramEntry_value(wxObject); }
			set { wxImageHistogramEntry_Setvalue(wxObject, value); }
		}
	}
	
	//---------------------------------------------------------------------
	
	public class ImageHistogram : Object
	{
		[DllImport("wx-c")] static extern IntPtr wxImageHistogram_ctor();	
		[DllImport("wx-c")] static extern void   wxImageHistogram_dtor(IntPtr self);
		[DllImport("wx-c")] static extern ulong  wxImageHistogram_MakeKey(byte r, byte g, byte b);
        [DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)]static extern bool wxImageHistogram_FindFirstUnusedColour(IntPtr self, ref byte r, ref byte g, ref byte b, byte startR, byte startG, byte startB);
				
		//---------------------------------------------------------------------
		
		public ImageHistogram(IntPtr wxObject)
			: base(wxObject) {}
			
		public ImageHistogram()
			: this(wxImageHistogram_ctor()) {}
		
		protected override void CallDTor ()
		{
			wxImageHistogram_dtor(this.wxObject);
		}

		
		//---------------------------------------------------------------------
		
		public static ulong MakeKey(byte r, byte g, byte b)
		{
			return wxImageHistogram_MakeKey(r, g, b);
		}
		
		//---------------------------------------------------------------------
		
		public bool FindFirstUnusedColour(ref byte r, ref byte g, ref byte b)
		{
			return FindFirstUnusedColour(ref r, ref g, ref b, 1, 0, 0);
		}
		
		public bool FindFirstUnusedColour(ref byte r, ref byte g, ref byte b, byte startR)
		{
			return FindFirstUnusedColour(ref r, ref g, ref b, startR, 0, 0);
		}
		
		public bool FindFirstUnusedColour(ref byte r, ref byte g, ref byte b, byte startR, byte startG)
		{
			return FindFirstUnusedColour(ref r, ref g, ref b, startR, startG, 0);
		}
		
		public bool FindFirstUnusedColour(ref byte r, ref byte g, ref byte b, byte startR, byte startG, byte startB)
		{
			return wxImageHistogram_FindFirstUnusedColour(wxObject, ref r, ref g, ref b, startR, startG, startB);
		}
	}
}
