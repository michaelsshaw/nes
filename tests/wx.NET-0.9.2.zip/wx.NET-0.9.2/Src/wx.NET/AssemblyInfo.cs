//------------------------------------------------------------------------
// wx.NET - AssemblyInfo.cs
// 
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: AssemblyInfo.cs,v 1.42 2010/07/12 18:23:50 harald_meyer Exp $
//------------------------------------------------------------------------

using System;
using System.Reflection;
using System.Resources;
using System.Security;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// Manually maintained to release version. Example version:
// New versioning guidlines: 0 - Beta (major release), 8 - functional version, 1 - fix level, 0 - build number (0 for unpublished version from CVS)
// The development version always only refers to the functional revision. Fix level and build number shall only be set
// by the build system, because these version numbers identify a release.
[assembly: AssemblyVersion("0.9.0.0")]

[assembly: AssemblyTitle("wx.NET.dll")]
[assembly: AssemblyDescription(
    "wxWidgets for .NET Library; see http://wxnet.sf.net/."
 + " Extras:"
#if WXNET_INTERNAL_USE_UTF8
    + " Compiled for using UTF8 as string encoding of .NET strings."
#endif
#if WXNET_STYLEDTEXTCTRL
 + " Styled text controls (STC)."
#else
 + " Styled text controls are disabled."
#endif
#if WXNET_DISPLAY
 + " Multiple displays on screen."
#else
 + " wx.Display is disabled."
#endif
#if wxUSE_TAB_DIALOG
+ " Tabbed dialogs."
#endif
)]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("wx.NET Development Team")]
[assembly: AssemblyProduct("")]
[assembly: AssemblyCopyright("(C) 2004-2007 Various Authors, 2007-2010 Harald Meyer auf'm Hofe")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]	

[assembly: AllowPartiallyTrustedCallers()]

[assembly: wx.ReflectConfig()]

// These is the documentation for doxygen's mainpage.
/*! \mainpage
 * 
 * \image html logo2.png
 * 
 * This document describes the API to \c wx.NET. This is complete
 * referring to the synopsis of classes and methods since it is generated
 * directly from source code. Unfortunately, several classes and functions
 * are not yet described. In these cases, refer to the original \e wxWidgets documentation.
 * Usually, \c wx.NET provides the same entities as \b wxWidgets does, for
 * instance class \c wxWindow in \e wxWidgets is wrapped by a class \c wx.Window
 * in \c wx.NET and method \c wx.Window.Show() wrapps method \c wxWindow::Show().
 * 
 * Refer to \ref components_of_the_distribution for some remarks on the file distribution and
 * \ref building_from_source for desciption on how to build the binaries.
 * 
 * If you start working with \e wx.NET, please consult \ref sec_known_problems.
 * 
 * With functional release 0.9, several methods changed their signature, so you probably will have to adjust
 * existing code. These changes have been motivated by the goal to make \e wx.NET a real .NET library
 * rather than a more or less complete binding of \e wxWidgets. So, \e wx.NET will use enumerations
 * with attribute \c Flags like \c wx.WindowStyles instead of unsigned integers whereever possible in
 * order to represend flags and styles. This eases use of the library dramatically since developers
 * can use IntelliSense to list viable options on typing in methods.
 * 
 * The classes of \e wx.NET have been reorganized into several namespaces like \c wx.GridCtrl.
 * This eases use of IntelliSense and navigation through the classes using the object manager.
 * 
 * Some concepts of \e wxWidgets simply do not fit into the .NET world like e.g. validators.
 * Refer to \c wx.ComponentModel instead.
 * Run \c WXNET_TOP/Bin/helpview.exe to have a look at the available documentation and
 * \c WXNET_TOP/Bin/launcher.exe to run the samples.
 * 
 * Refer to \ref building_from_source for notes on how to build \e wx.NET.
 * 
 * \section sec_changes History
 *
 * \li 0.9.0.2: The Windows binary \c wx-c-0-9-0-1.dll of release 0.9.0.1 has
 *               unfortunately been built in debug mode. Additionally, I missed to copy 
 *               the .NET documentation \c wx.NET.XML into the release.
 *               Please apologize any inconvenience.
 *               This distribution also contains a fix to the wrapping of the accelerator
 *               table that caused access violations.
 * \li 0.9.0.1: The main objectives of this release have been a .NET appeal of the library
 *            and reliability.
 *            This is the first release that has been built with the wx.BuildSystem. The
 *            \c wx.NET.dll of this release refers to a native DLL \c wx-c-0-9-0-1.dll.
 *            From now on, many versions of wx.NET may be installed in GAC and System32
 *            or /usr/lib directories without any interferences.
 *            All memory allocation actions will now be entered through a monitor since
 *            memory management in Windows is not thread safe.
 *            Classes have been reorganized into several namespaces like e.g. wx.GridCtrl.
 *            Style flags for windows (refer to \c wx.WindowStyles) and sizers are now
 *            enumerations. So, you can use IntelliSense when using controls and sizers.
 *            \c wx.StyledText, \c wx.Globalization, and \c wx.MaskedEdit have been added.
 *            
 * \li 0.8.0: The main objectives of this release have been documentation and reliability.
 *            Utility \c helpview.exe has been added to the distribution in order to present
 *            platform independent HTB documentations on \e wx.NET, the samples and the original
 *            \e wxWidgets library. Unfortunately, programmers often have to consult the original
 *            documentation since the new \c wx.net.htb file is far from being complete. The text
 *            of this documentation is directly compiled from the C# source files. Additionally,
 *            a .NET XML documentation can be compiled from these remarks on the source code.
 *            Furthermore, this release introduces \c wx.Archive, the first pure .NET implementation
 *            of \e wx.NET. Many small changes on drawing, fonts, colours, and several controls increased 
 *            reliability of the system. 
 * 
 * The following mind map scetches the purposes for further enhancements of wx.NET.
 * 
 * \image html roadmap.png
 * 
 * \section sec_known_problems Known Problems And Pitfalls
 * 
 * All samples run fine. The status of the implementation is considered stable.
 * 
 * \li Always create the thread initializing a wx.NET application (class wx.NET) as STA thread (e.g. using the
 *     <c>STAThreadAttribute</c> on the entry point/ main function). wxWidgets as well as 
 *     .NET will conduct OLE initialization and these initializations must be done consistently.
 * \li Instances of wx.Object (or inheritors) shall only be generated within constructors
 *     or methods. I don't know why, but construction of instances of member variables
 *     directly with the declaration of that member variable caused access violations
 *     on subsequent constructor calls.
 * \li When using device contexts (e.g. wx.Object.PaintDC) you have to dispose the context
 *     explicitely immediately after using it. You may either use keyword \c using to inform
 *     .NET to dispose the object immediately after leaving the block (this is equivalent to
 *     the standard behavious in C++) or you may call wx.Object.Dispose() explicitely on the
 *     device context.
 * \li Applications often replace one control by another. For instance, one might have to
 *     add an editor into a static box depending on the type of the data to edit. In C++
 *     implementations of such controls rely on the implicit call of \c wxWindow::Destroy()
 *     by the destructor. In .NET, destruction of objects will usually be deferred. So, 
 *     wx.Window.Destroy() must be called explicitely to destroy a control that shall be replaced
 *     by another. As an examply refer to wx.HtmlWidgetCell that register themselves at the
 *     wx.HtmlWindow when they are inserted into that window. When a new page is loaded into
 *     that window, these widgets cells and the contained controls are no longer needed.
 *     The wx.HtmlWindow can destroy them automatically because they registered themselves.
 * \li By default, \e wx.NET collects all generated wrappers into a static list of
 *     instances (with the exception of strings). Thus, you will have to release all
 *     instances of \c wx.Object explicitely using \c wx.Object.Dispose() in order to avoid
 *     memory leaks, since the wrappers will live until the system is sure that \e wxWidgets
 *     will not need their letter in the further more. Refer to \c wx.Object.InstancesCount
 *     and wx.Object.SavedInstancesCount to test this.
 * \li Use \c wx.ColourDatabase.TheColourDatabase, \c wx.Pen.ThePenList, \c wx.Brush.TheBruchList,
 *     and \c wx.Font.TheFontList whenever possible. Get pens, brushes, and fonts from a window only
 *     once and cache them in a member variable.
 * \li Sometimes, destructors are used in \e wxWidgets samples to replace on control by another.
 *     Refer to the samples on list boxes \c wx.Samples.ListCtrlApp and \c wx.Samples.MyHtmlListBox.
 *     Since the .NET framework uses an automatic memory management, use method wx.Window.Destroy() to
 *     eliminate the old window before adding the new one.
 * \li Refer to wx.Config.
 * \li Another known problem may rise on using wx.TreeCtrl when changing the tree layout or selection
 *     while processing events. Refer to the comments on wx.TreeCtrl for details.
 * \li If you use the text control as target of the wxWidgets wxLog messages, keep care that you
 *     disable wx.Log before closing the text control. You may achieve this, using the wx.CloseEvent.
 *     At least wxGTK does not like logging on text windows that are about to close.
 * \li At least on Windows, the wx.TaskBarIcon might require the application to use wx.Utils.Exit
 *     to close down.
 * \li GTK does not like to close (wx.Window.Close()) a window that is currently not visible (wx.Window.Hide()
 *     and wx.Window.IsShown).
 * \li I dropped the support for the validator concept. The rudimentary support implemented by class wx.Window
 *     caused errors on my 64-Bit SuSe installation. I don't know why. However, I don't like the concept anyway.
 *     I hope to be able to replace the concept by a wx.NET component model.
 */

/** \page contributors wx.NET Developers
 * 
 * List is in chronological order of first contribution. 
 * SourceForge ID is in parenthesis.
 * <list type="table">
 * <item><term>Jason Perkins</term><description>(jason379) </description></item>
 * <item><term>Bryan Bulten</term><description>(malenfant) </description></item>
 * <item><term>Robert Roebling</term><description>(roebling) </description></item>
 * <item><term>Florian Fankhauser</term><description>(souflo) </description></item>
 * <item><term>Alexander Olk</term><description>(olkalex) </description></item>
 * <item><term>Gustavo Ramos</term><description>(eureko)</description></item>
 * <item><term>Michael S. Muegel</term><description>(t9mike)</description></item>
 * <item><term>Tim A. Stahlhut</term><description>(stahta01)</description></item>
 * <item><term>Harald Meyer auf'm Hofe</term><description>(harald_meyer)</description></item>
 * </list>
 */

/** \page license License
 * \verbatim
 
                wxWindows Library Licence, Version 3.1
                ======================================

  Copyright (c) 1998-2005 Julian Smart, Robert Roebling et al

  Everyone is permitted to copy and distribute verbatim copies
  of this licence document, but changing it is not allowed.

                       WXWINDOWS LIBRARY LICENCE
     TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
  
  This library is free software; you can redistribute it and/or modify it
  under the terms of the GNU Library General Public Licence as published by
  the Free Software Foundation; either version 2 of the Licence, or (at
  your option) any later version.
  
  This library is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Library
  General Public Licence for more details.

  You should have received a copy of the GNU Library General Public Licence
  along with this software, usually in a file named COPYING.LIB.  If not,
  write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330,
  Boston, MA 02111-1307 USA.

  EXCEPTION NOTICE

  1. As a special exception, the copyright holders of this library give
  permission for additional uses of the text contained in this release of
  the library as licenced under the wxWindows Library Licence, applying
  either version 3.1 of the Licence, or (at your option) any later version of
  the Licence as published by the copyright holders of version
  3.1 of the Licence document.

  2. The exception is that you may use, copy, link, modify and distribute
  under your own terms, binary object code versions of works based
  on the Library.

  3. If you copy code from files distributed under the terms of the GNU
  General Public Licence or the GNU Library General Public Licence into a
  copy of this library, as this licence permits, the exception does not
  apply to the code that you add in this way.  To avoid misleading anyone as
  to the status of such modified files, you must delete this exception
  notice from such code and/or adjust the licensing conditions notice
  accordingly.

  4. If you write modifications of your own for this library, it is your
  choice whether to permit this exception to apply to your modifications. 
  If you do not wish that, you must delete the exception notice from such
  code and/or adjust the licensing conditions notice accordingly.

\endverbatim
 */


/**
 * \page sec_notes_for_contributors Notes For Contributors
 * 
 * \e wx.NET sources fall into two parts: The C# implementation
 * of the wrapper and the implementation of the \c wx-c.dll. Allthough C# provides
 * a very convenient way to call native implementations compiled into a DLL, the
 * matching of the different object models and memory managements still provides several
 * difficulties. Refer to the documentation of wx.Object on this issue.
 * 
 * Also please note some guide lines that the current code base unfortunately ignores sometimes.
 * \li Do not use conditional compilation in the .NET part. Additionally, the \c wx-c shall always provide
 *     the same set of functions - without regard to defined or undefined symbols. If functions are only available
 *     for instance in \c __WXMSW__, provide dummy implementations in \c wx-c if \c __WXMSW__ is not defined and
 *     produce runtime errors (exceptions) in \c wx.NET.dll if only dummy implementations are available. 
 *     Use \c wx.ReflecConfig for this purpose.
 * \li Include \c wxnet_globals.h into all C++ wrapper files. This header defines e.g. the \c WXNET_EXPORT() macro. Use
 *     this macro as shown by the sample below to declare exported functions. Please note, that \e wx.NET uses \c __stdcall
 *     calling convention on Windows (as suggested by Microsoft), whereas \e wxWidgets uses \c __cdecl.
 * \li Use namespace \c wx for all C# implementations in \c wx.NET.dll.
 * \li Naming conventions for C wrapper functions: \e wxWidgets class name, underscore, method name.
 * \li Always provide a preferably public constructor receiving a C++ instance as \c System.IntPtr
 *     as argument for all inheritors of wx.Object. This is absolutely mandatory if using \c wx.Object.StorageMode.RegisteredObject.
 * \li \c wx.Object.memOwn defines whether the C++ object will be destroyed on disposing the .NET wrapper.
 *     Define this explicitely. The current default is \c false and I really don't know whether this
 *     is really necessary or not. This default changes on objects of storage mode
 *     \c wx.Object.StorageMode.VolatileObject. These objects are considered as data exchange objects without
 *     registration in \e wxWidgets. This is usually true but on implementing virtual callbacks,
 *     objects of this kind might have been generated in local scope in the C++ side. In such cases,
 *     memory ownership has to be on the C++ side. The .NET implementation has to reflect this.
 *     Another opportunity for such cases is the implentation of a particular boxing class
 *     according to wx.DisposableStringBox.
 * \li Do not reimplement destruction for specializations of wx.Object if wx.Object.Dispose() already
 *     does the job. This is for instance the case on \e wxWidgets objects providing virtual destructors.
 *     Instead of reimplementing wx.Object.Dispose() override wx.Object.CallDTor(). Refer to the code for examples.
 * \li Never pass \c const \c char* to C-functions. Use pointers to \c wxString instead. Use class
 *     \c wxString on the C# side. Reason: C# natively supports UTF. \c wxWidgets supports UTF
 *     if this support has been compiled in (I don't know any reason to use ANSI mode, but this is
 *     still supported). In both cases, \c wxString will convert if necessary and omit any conversion
 *     if possible. So, do not use C strings. Refer also to the remarks on wxString.
 * \li If you have to wrap virtual methods, define subclasses with callback functions as member
 *     variables and call them if necessary. Refer to file \c local_events.h for some support
 *     on this issue. But: Initialize callbacks with NULL on constructing C++ objects and call them
 *     only if they differ from NULL. This is vital to safely avoid access violations on using
 *     instances with callbacks before registration of the callback functions.
 * \li Another frequently used rule: Always consider the NULL pointer as legal.
 *     NULL-pointers simply cause awful exceptions on access violations. More reliable code also
 *     eases debugging of new wrappers.
 * \li Avoid \c bool and \c long. The size of \c bool is not defined (this datatype is missing in C)
 *     and the size of \c long varies from 32 bit to 64 bit architecture. So, with \c long you might
 *     have problems on \c wx-c DLLs built for the 64-bit architectures. You may use \c int for both
 *     (the standard marshalling of \c bool treats it like an integer number). You may also define
 *     the marshalling explicitely using the \c MarshalAs(UnmanagedType.U1) attribute and use \c char instead of \c bool.
 * \li Although .NET makes no difference between \c const and mutual objects, the declarations of the
 *     DLL functions should reflect this.
 * \li Distinguish clearly between data transfer objects and logical instances. Data transfer objects
 *     in C# typically implement System.ICloneable and System.IComparable or the method \c object.equals()
 *     and \c objects.GetHashcode(). When wrapping DTOs (like wx.wxString), use the \c wx.Object.StorageMode.VolatileObject
 *     mode and copy all return values from \e wxWidgets into newly generated instances.
 * \li Use the \c #region \c #endregion directives for the following categories if applicable:
 *     <ul>
 *     <li>"C API" for the declaration of functions implemented by \c wx-c.dll.
 *     <li>"State" for all member variables and static variables.
 *     <li>"Public Properties" for all publically accessable properties.
 *     <li>"Helper Properties" for all non-publically accessable properties.
 *     <li>"Public Methods" and "Helper Methods" for all publically accessable methods or
 *          non-publically accessable methods respectively.
 *     </ul>
 *     You may also use regions as pasted in by the MS VC# development system. These usually
 *     declare a region for all interfaces that you implement. Instead of using a region "C API"
 *     you may declare the C-functions where they are needed.
 * \li Provide doxygen complying comments wherever possible.
 * \li Follow .NET conventions whre possible: Declare appropriate interfaces and use properties,
 *     indexers, and enumerators.
 * \li Qualify member variables with \c this (e.g. \c this.wxObject). This enhances readability and
 *     does for sake of IntelliSence not require extra effort.
 * \li Never pass objects of C# standard type like \c string, \c System.DateTime, \c System.Drawing.Rectangle, \c System.Drawing.Point, or \c System.Drawing.Size to the \c wx-c.dll directly.
 *     Use instances of the classes \c wx.wxString, \c wx.wxDateTime, \c wx.wxRect, \c wx.wxPoint, or \c wx.wxSize instead.
 * \li Most difficulties wrapping object oriented programming languages like C# to something like C++ arise from
 *     the different object model and resulting problems in achieving a consistent memory management.
 *     Lately, the sources of \c wx-c.dll support the use of the \c _CRTDBG_MAP_ALLOC debug facilites of the Microsoft
 *     Visual Studio (R) compiler. If you define symbol \c WXNET_LOG_MEM when compiling \c wx-c.dll, this DLL will
 *     log each allocation and deallocation of memory and \e wx.NET objects in a file containing comma separated lists
 *     named \c wx_c_mem.csv. You may analyze this file using the \c MemLogDisplay.exe application,
 *     a browser for these log files that is a \e wx.NET utility (also implemented using \e wx.NET).
 *     \c WXNET_LOG_MEM can of course be defined using other compilers. However, the resulting log files
 *     will lack most information on memory deallocation.
 * \li Do not use datatyoe <c>bool</c> as result of DLL functions or result or argument of callbacks.
 *     At least VC 8 seems to use a memory model for this data that does not comply with the PINVOKE
 *     standard serialization of the .NET type <c>bool</c>. In callbacks use <c>int</c> instead.
 *     You can avoid problems with <c>bool</c> as the result of a native DLL function using <c>char</c>
 *     instead with an explicit configuration of the marshalled data as <c>UnmanagedType.U1</c>. Refer
 *     to <c>wxStringMap_HasValueFor</c> in the example below.
 * 
 * One example for the rules: Return a string mapped to a string in a C++ container (only an example).
 * \code
 class wxStringMap 
 {
   public:
   wxStringMap();
   virtual ~wxStringMap();
   bool HasValueFor(const wxString& key) const;
   const wxString& ValueFor(const wxString& key) const;
 };
 \endcode
 * The following wrapper ignores the rules as presented above whereever possible. The implementations
 * in \c wx-c.dll.
 * \code
 extern "C" __declspec(dllexport) wxStringMap* wxStringMap_CTor()
 {
    return new wxStringMap();
 }
 extern "C" __declspec(dllexport) void wxStringMap_DTor(wxStringMap* self)
 {
    delete self;
 }
 extern "C" __declspec(dllexport) bool wxStringMap_HasValueFor(wxStringMap* self, const char* key)
 {
    return self->HasValueFor(key);
 }
 extern "C" __declspec(dllexport) const wxString* ValueFor(wxStringMap* self, const char* key)
 {
    return &(self->ValueFor(key));
 }
 \endcode
 * The implementation in \c wx.NET.dll.
 \code
 namespace wx
 {
   class StringMap : Object
   {
        [DllImport("wx-c")] static extern IntPtr wxStringMap_CTor();
        public StringMap() : base(wxStringMap_CTor()) {}
        // but where is the cosntructor for IntPtr
 
        [DllImport("wx-c")] static extern void wxStringMap_DTor(IntPtr self)
		protected virtual void Dispose(bool disposing)
		{
            bool still_there = RemoveObject(wxObject);
			if (!disposed)
			{
                lock (Object.DllSync)
                {
					if (wxObject != IntPtr.Zero && memOwn && still_there)
					{
						wxStringMap_DTor(wxObject);
					}
				}
				
				virtual_Dispose = null;
				wxObject = IntPtr.Zero;
				memOwn = false;
                --validInstancesCount;
            }

			disposed = true;
        }
        // this is a lot of copy/paste stuff that is not necessary since C++
        // provides a virtual destructor.
 
        [DllImport("wx-c")] static extern bool wxStringMap_HasValueFor(IntPtr self, string key)
        public bool HasValueFor(string key)
        {
            return wxStringMap_HasValueFor(wxObject, key);
        }
        // no unicode support since standard marshalling for strings is: BSTR
        // bool will only work iff the C++ compiler uses full word width (4 bytes on 32 bit architectures) for bool.
 
        [DllImport("wx-c")] static extern IntPtr wxStringMap_ValueFor(IntPtr self, string key)
        public string ValueFor(string key)
        {
            return (wxString) Object.FindObject(wxStringMap_ValueFor(wxObject, key), typeof(wxString));
        }
        // correct but useless cal to wx.Object.FindObject(). This method is appropriate to reuse
        // previously generated wrappers. But strings will be newly generated when requested.
        // no unicode support.
   }
 }
 \endcode
 * 
 * The wrapper will look something like the following when observing the guiding rules. Make up
 * your mind on the effect!
 * \code
 #include "local_events.h"
 #include "wxnet_globals.h"
 
 class _StringMap : public wxStringMap
 {
    DECLARE_DISPOSABLE(_StringMap)
    public _StringMap() : wxStringMap(), m_onDispose(NULL) {}
 };
 
 WXNET_EXPORT(wxStringMap*) wxStringMap_CTor()
 {
    return new _StringMap();
 }
 
 // we do not need a method for destruction since the wrapped class supports virtual destruction.
 
 WXNET_EXPORT(void) wxStringMap_RegisterDispose(_StringMap* self, Virtual_Dispose onDispose)
 {
    if (self) self->RegisterDispose(onDispose);
 }
 
 WXNET_EXPORT(char) wxStringMap_HasValueFor(wxStringMap* self, const wxString* key)
 {
    if (self && key)
        return self->HasValueFor(*key);
    else
        return 0;
 }
 // this avoids access violations on NULL pointers and uses C standard type char instead of bool
 // unicode will be supported if wxWidgets has been compiled for unicode support
 
 WXNET_EXPORT(wxString*) ValueFor(wxStringMap* self, const wxString* key)
 {
    if (self && key)
       return new wxString(self->ValueFor(*key));
    else
        return NULL;
 }
 // unicode support and return of fresh strings only.
\endcode
 * And now the correlated C# implementation.
 * \code
 namespace wx
 {
   class StringMap : Object
   {
        #region CTor
        [DllImport("wx-c")] static extern IntPtr wxStringMap_CTor();
        [DllImport("wx-c")] static extern void wxStringMap_RegisterDispose(IntPtr self, Virtual_Dispose onDispose);
        static IntPtr LockedCTor()
        { // memory allocation at least on Windows is not thread safe.
          // so, we have to synchronize all C++-code allocating and deallocating
          // memory from 
            lock (wx.Object.DllSync)
            {
                return wxStringMap_CTor();
            }
        }
        public StringMap() : this(LockedCTor())
        {
            // the wrapper shall be deactivated on deleting the C++ instance
            this.virtual_Dispose = new Virtual_Dispose(VirtualDispose);
            this.memOwn = true;
            wxStringMap_RegisterDispose(this.wxObject, virtual_Dispose);
        }
        public StringMap(IntPtr wxObject) : base(wxObject) {}
        #endregion
 
        #region Public Methods
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)] // redefines marshalling of result type bool
        static extern bool wxStringMap_HasValueFor(IntPtr self, IntPtr key)
        public bool HasValueFor(string key)
        {
            wxString wxKey=wxString.SafeNew(key); // support of unicode if compiled in
            return wxStringMap_HasValueFor(this.wxObject, Object.SafePtr(wxKey));
        }

        [DllImport("wx-c")] static extern IntPtr wxStringMap_ValueFor(IntPtr self, IntPtr key)
        public string ValueFor(string key)
        {
            wxString wxKey=wxString.SafeNew(key);
            return new wxString(wxStringMap_ValueFor(this.wxObject, Object.SafePtr(wxKey)));
        }
        #endregion
        #region Public Properties, Indexers
        //! Minimal .NET support: Providing an indexer.
        public string this[string key]
        {
            get
            {
                return this.ValueFor(key);
            }
        }
        #endregion
   }
 }
 \endcode
*/

/** \page page_whatis What is wx.NET?

\e wx.NET is a .NET Common Language Infrastructure (CLI) wrapper for \e wxWidgets (formerly \e wxWindows).

It is composed of two parts:
\li \e wx-c is a C++ library which exposes the wxWidgets API as a collection of C# friendly functions. It is named \c libwx-c.so on Linux, \c wx-c.dylib on MacOS X, and \c wx-c.dll on Windows.
\li \e wx.NET is a .NET assembly written in C# which parallels the wxWidgets class hierarchy. It is named \c wx.NET.dll on all platforms.

Optionally, your platform may require \e wxWidgets shared libraries which \e wx-c makes calls
to. On Windows these are not necessary as we can include these in the \e wx-c library (i.e. statically linked to wxWidgets).
On Mac and Linux, however, we currently only support linking to \e wxWidgets shared libraries. Be sure to review Runtime Library Components to learn more.

\e wxWidgets, being written in C++, has a fairly nice object oriented design.
So this fits well with .NET. While the wx.NET library was written in C#, you should be able to
use it with any Common Language Specification (CLS) language, such as \e VB.NET. Several \e VB.NET
samples are included in the \e wx.NET distribution and \e wx.NET is continually tested against \e VB.NET.

In theory \e wx.NET should run on any platform that provides a .NET runtime (Microsoft.NET,
Mono, or DotGNU Portable.NET) and a \e wxWidgets port. At the present time, however, we have
limited our focus and testing to the following operating systems:
\li Microsoft Windows XP
\li Linux

If you want to help us test and make any changes necessary to support other platforms
please contact the development team.

\e wx.NET is hosted at SourceForge. The home page is at \c wxnet.sf.net.

*/


/** \page wx-c-notes Some notes on the native DLL wx-c.dll
 * 
 * The wx.NET system is composed of a .NET DLL wx.NET.dll and a native DLL wx-c.dll.
 * The latter provides C-functions providing a C interface to the wxWidgets C++ libraries.
 * The original wx-c.dll provided the initial code for some other wrappers of the wxWidgets
 * libraries. the following information is relevant for those using the wx-c.dll directly.
 * 
 * From release 0.9 on, the native DLL when built for MS Windows defines its function in
 * STDCALL convention. In this calling convention, the caller of the method is responsible for
 * the deallocation of the method arguments on the stack. This is especially useful when
 * dealing with C++ because deallocation here usually means that destructors have to run.
 * Since this is standard convention when using .NET on MS Windows machines, also the 
 * wx-c.dll now provides its functions in STDCALL convention ... with exceptions.
 * 
 * Those that require CDECL calling convention can modify the source at a single line
 * in file \c "wxnet_globals.h" since all functions shall be declared using the \c WXNET_EXPORT()
 * macro (refer to \ref sec_notes_for_contributors). 
 * 
 * Also users of the MinGW compiler and linker will obtain libraries exporting their functions
 * in CDECL convention. MinGW supports STDCALL but does not implement the MS convention for
 * symbols exporting code in STDCALL convention. The MS compiler prepends an underscore to these
 * symbols. Thus, tools like \c depends.exe will show a symbol like \c "_wxApp_ctor@0" for a function
 * named \c wxApp_ctor. This underscore is expected by the MS .NET PInvoke implementation.
 * Unfortunately, this underscore is missing when compiling with the GCC of the MinGW edition.
 * Thus, these compiler will compile wx-c.dll in CDECL edition.
 */

/** \page components_of_the_distribution Components Of The File Distribution
 * 
 * \e wx.NET always comes with all sources and all scripts that are necessary to build
 * the binaries following \ref building_from_source. Additionally, the distribution contains
 * binaries for the Windows and Linux operating system.
 * 
 * The .NET binaries wx.NET.dll and the sample programs run on both supported .NET runtime
 * environments: The MS .NET Framework and MONO. These files are portable anyway. 
 * The wx.NET assembly is signed with a non-public key - I have not used the key from the
 * CVS repository. This assembly also refers to the native code dynamic library \c wx-c-0-9-0-1.dll
 * on Windows or \c libwx-c-0-9-0-1.so.
 * Both characteristics shall ease the use of the shipped binary components in your own distributions.
 * You can add the wx.NET binary to the list of FULL_TRUSTED assemblies without the fear that anyone
 * can use the key from the CVS repository to create a Trojan Horse that mimics the wx.NET.dll.
 * Additionally, you can install various versions of the wx.NET native DLLs into the \c \Windows\System32
 * directory (or /usr/lib on Linux) without the risk of interferences, since native code libraries from
 * different releases will also have different names.
 * This fact enables you to install the wx.NET.dll into the Globale Assembly Cache (GAC).
 * 
 * The native code dynamic libraries have both been built on a i586 32-bit architecture. \c wx-c-0-9-0-1.dll
 * implements the native DLL wrapper of \e wxWidgets. This files has been built with the VC 9 Express Edition
 * and the platform SDK 6.1 tools of Microsoft. This DLL hs been statically linked with \e wxWidgets 2.8.11, the
 * latest stable version.
 * 
 * The Windows binary \c wx-c-0-9-0-1.dll requires the VC++ 2008 redistributable package X86. You can find a
 * version of this of this package in directory "Install". 
 * 
 * \c libwx-c-0-9-0-1.so provides the native code wrapper to \e wxWidgets on Linux. The ELF library has been
 * built on the SuSE 11.2 32 bit edition but with the latest \e wxGTK 2.8.11 stable release. The file distribution
 * contains also the \c libwxGTK-...so libraries of \e wxWidgets. These libraries link with the GTK+ 2.0 GUI
 * framework.
 * 
 * Run \c WXNET_TOP/Bin/helpview.exe to have a look at the available documentation and
 * \c WXNET_TOP/Bin/launcher.exe to run the samples.
 */

/** \page building_from_source Building From Source
 
\e wx.NET is available as a file distribution (cf. \ref components_of_the_distribution) or
via CVS from <a href="http://www.sourceforge.net/projects/wxnet">http://www.sourceforge.net/projects/wxnet</a>.
If you received a branch of the source code by CVS or you are not satidfied by the compiled
binaries in the file distribution, you will have to compile the project binaries from
source.

\section building_from_source_overview Overview

Building wx.NET is a four-step process: <ol>
<li> Install the .NET framework or the \e mono system (\ref installing_net).
<li> Install one of the supported C/C++ compilers and linkers (\ref installing_cpp).
<li> Configure, compile, and install core wxWidgets and any optional contrib libraries (\ref building_wxwidgets).
<li> Configure and compile wx.NET.
</ol> 

All of this can get a bit tedious if done by hand, especially since both \e wxWidgets and \e wx.NET
are fairly configurable and have multiple build steps themselves.

So we've developed this documentation and a "wrapper" build system to make life easier for newbies
and advanced users alike. The build system lives under the Build directory. This system is totally
optional: if you like you can
configure/compile/install \e wxWidgets on your own and also configure/compile \e wx.NET
directly using GnuMake programs.

This manual will focus on Windows platforms and Linux. \e wx.NET can run on MaxOs X but since I do
not have any experiences with this platform, I cannot support it. However, all version up to 0.8.0
have also been compiled for Macs.

\section installing_net Installing the .NET framework or equivalents

\subsection installing_net_windows Windows
On Windows you have the choice among two supported implementations of the .NET framework: Microsoft's
original implementation (<a href="http://msdn.microsoft.com/netframework/">"http://msdn.microsoft.com/netframework/"</a>)
and the mono project <a href="http://www.go-mono.com/">(http://www.go-mono.com/)</a>. Previous versions
also supported the PNET / DotGnu <a href="http://www.gnu.org/projects/dotgnu/">(http://www.gnu.org/projects/dotgnu/)</a> implementation. The 
use of this implementation is no longer supported. 

The Windows implementation is typically already a part of the operating system. However, installation packages are
available from the web. Please be sure to have at least version .NET 2.0 installed, since wx.NET uses generics.

Both systems are available as installation programs or MSI packages and you should use these packages since
the wx.Net.Build (\ref building_with_wx_net_buildsystem) system uses registry entries to determine the directories,
that contain the "mono" programs (the registry folder \c HKLM\Software\Novel\Mono should contain valid entries).

If you plan to use the solution files and VS project files, you should install either the free Visual Studio Express Edition
(<a href="http://msdn.microsoft.com/vstudio/express/default.aspx">http://msdn.microsoft.com/vstudio/express</a>),
or one of the Visual Studio products that you have to pay for, or \c monodevelop, the development environment of the mono
project.

\subsection installing_net_linux Linux
The number of alternatives for Linux is somehow limited: You have the opportunity to go
<a href="http://www.go-mono.com/">mono</a>. Most Linux distributions offer precompiled packages. However, these
packages usually do not provide the most current version.

Alternatively, you may get a source code release from the web site of the project and compile it.

In any case: The mono interpreter \c mono and the compiler \c gmcs shall be in the path of directly executable
programs (PATH variable).

\section installing_cpp Install one of the supported C/C++ development systems

\subsection installing_cpp_windows Windows
 
I tested two development frameworks for the C/C++ code of library \c wx-c.dll: Microsoft's platform SDK v6.1 (available
for free from <a href="http://www.microsoft.com/">http://www.microsoft.com/</a> and the MinGW port of the GCC compiler
on Windows (<a href="http://www.mingw.org/">http://www.mingw.org/</a>). If you plan to use the make files, you also have
to MSys package - the minimal make system - also from the MinGW site.
If you plan to use the \c wx-c.sln solution file, you have to get the VC Express Edition from
<a href="http://msdn.microsoft.com/vstudio/express/default.aspx">http://msdn.microsoft.com/vstudio/express</a>.

Please use the official installation packages. The \c wx.Net.Build system will use registry entries to find
out the place where Microsoft's platform SDK has been installed.
The \c wx.Net.Build system will expect MinGW to reside at \c C:\MinGW\bin. However, you can change this assumption assigning a
path to environment variable \c GCC_BINPATH (\ref building_with_wx_net_buildsystem).

\subsection installing_cpp_linux Linux

All means to build \e wx.NET that are part of this package referring to Linux use the GNU C/C++ compiler GCC.
GCC is part of all Linux distributions and must be in the path of executable programs (the PATH variabel).

\section building_wxwidgets Building wxWidgets

The current distribution of \e wx.NET uses the current productive version of \e wxWidgets: 2.8. You also have
to build the STC (styled text control) library in the \c contrib directory. The current code base does not compile
with version 2.9 - the future 3.0 release of wxWidgets that currently is under development.

Please do not forget to have a look at the \c wx/setup.h file. Make sure, that \c wxUSE_UNICODE
is defined if you use Unicode string encoding (which I strongly recommend).

\subsection building_wxwidgets_windows Windows

\e wxWidgets comes with several means to build the libraries. I use the make files \c makefile.vc (the Visual
Studio Compiler) and \c makefile.gcc (the MinGW GCC compiler and the MSys system) in the \c build\msw subdirectory
of the project. You have to edit the configuration files \c config.vc and \c config.gcc respectively.
However, you definitely should consult wxWidgets' documentation on building the system before you decide how
to do this.

In \c config.gcc, I only have to care about variable BUILD to choose among release and debug mode, since
I install MinGW in the standard directory \c C:\MinGW. Additionally, you should assign 1 to variable UNICODE.
Everything interfacing the .NET Framework should support unicode.
Then, you have to call a port of GNU make (e.g. the \c mingw32-make.exe program).
\code 
c:\wxWidgets-2.6.11\build\msw> \MinGW\mingw32-make.exe -f makefile.gcc
\endcode

In \c config.vc I acivate UNICODE and use of \c USE_GDIPLUS. Then, you have to start the "CMD shell" optimized for
using the platform edition.
Call Microsoft's make-tool \c nmake:
\code
c:\wxWidgets-2.6.11\build\msw> nmake.exe -f makefile.vc
\endcode

Please do not forget to execute also the Make-scripts in \c contrib\build\stc that build the 
STC library.

The \c wx.Net.Build system will expect \e wxWidgets to reside in the standard folders \c C:\wxWidgets-2.8.10
or \c C:\wxWidgets-2.8.11. You may override this assigning a path to environment variable \c WXWIN.

\subsection building_wxwidgets_linux Linux

Building \e wxWidgets under Linux is quite easy. Unzip the wxGTK source distribution, change directory to the 
root directory of this ditribution and call
\code
> ./configure --enable-unicode
> make
> sudo make install
\endcode
Change to \c contrib\src\stc. Again run
\code
> make
> sudo make install
\endcode
The commands introduced by \c sudo require root priviliges. If you are not a sudoer, you may also
use \c su to create a root shell and then call <c>make install</c>.

Finally, I only have to report problems using version 2.8.10 in release mode on a 64 bit architecture.
Version 2.8.11 works fine on my machines.
 
\section building_with_wx_net_buildsystem Use of the wx.BuildSystem system 

The \c wx.BuildSystem consists of .NET wrappers for build tools like compilers and linkers and of
project definitions that define the libraries and programs that shall be built. The programs and
libraries of the \e wx.NET project are defined in program \c wx.Net.Build.exe. This program uses
the generic part of the build system implemented in assembly \c wx.BuildSystem.dll. The program
works for Windows and Linux.

You have to use the command shell:
\verbatim
> wx.Net.Build.exe /log:wxnetbuild
\endverbatim

The build program will try to find all supported build tools that you have installed on your machine.
Then, the system will create a schedule based on the available build tools. Finally, this schedule will
be executed. The abovementioned command line tells the build system to produce a lig file \c wxnetbuild.log
in XML syntax. This is an option.
If more than one tool is available to build a particular target and the first tool fails,
the build program will automatically try the next available tool. The tools will be recognized
correctly if installed following the advices from the section \ref installing_cpp and \ref installing_net.

On Windows, the build program will try the VC Express and Microsoft Platform SDK tools first before
using the MinGW tools - if both tools are available. Analogously, the MS .NET framework will be used 
used before starting Mono. You can override this using options \c +MONO or \c +GNU to prefer the Mono
tools and/or the GNU tools. On Linux, the system supports only GNU GCC and Mono.

Further informtations on options are available with
\verbatim
> wx.Net.Build.exe /help
\endverbatim

The build program may fail to identify the available tools if you did not use the standard procedure
for installation or you use tool sets like Visual Standard Edition or Visual Professional Edition that
have not been tested. This description only covers tools that are available for free.
You may also want to build the system on a not directly supported OS. For instance, wxWidgets supports
native Mac OS X controls - however, I do not own a Mac, thus the build system does not support this platform.

If you experience any problems with the automatic build system, you have the option to use the BOO
scripts for build \e wx.NET following the instructions from \ref building_with_boo. Two scripts are part
of the file distribution: \c wx.Net.Build.Windows.boo
to build on Windows and \c wx.Net.Build.Linux.boo to build on Linux machines. 
However, you may create your own BOO script using the build system that refers to all tools that are
installed on your system.
\verbatim
> wx.Net.Build.exe /boo:MyBuildScript.boo
\endverbatim

A final remark on the support for building file releases: As pointed out in \ref components_of_the_distribution,
the native DLLs or ELF libraries contain version information in their file name. This means, that all references
to the DLLs in the .NET assembly wx.NET.dll must be changed - they have to load function from - let's say - 
\c wx-c-0-9-0-1.dll instead from \c wx-c.dll. The build program \c wx.Net.Build.exe supports these operations
since the program contains a build project for building file distributions. However, you have to provide a version
number in order to make this work. Assign a string like "0.9.0.1" to environment variable \c BUILD_VERSION before
starting the build program or start the build program in the following way to create a file distribution:
\verbatim
> wx.Net.Build.exe /set:BUILD_VERSION=0.9.0.1
\endverbatim
This will build all projects defined on the original sources and all libraries and programs on modified sources,
that are part of the file release 0.9.0.1. You can find the latter programs in sub directory WXNET_TOP/Bin/release-0-9-0-1.

\section building_with_boo Using BOO scripts to build 

\e wx.NET comes with 2 BOO scripts to build libraries, assembles, and sample programs: \c wx.Net.Build.Windows.boo
to build on Windows and \c wx.Net.Build.Linux.boo to build on Linux machines. As mentioned in \ref building_with_wx_net_buildsystem,
you can also create these files on your own.
The purpose of these scripts is to provide you with means to configure the build process at your will. Therefore, the
code is organized in a form that makes changes to the code as easy s possible.
The generated code falls into sections as follows (but you will have to edit most probably only the first section).

\subsection using_boo_exports_declarations The declaration section

This sections contains the declaration of BOO variables for options and file names.
This is the section that users of the build system will edit to adopt the build system to specific needs.
 
This section contains several subsections.
the first section will import some required namespaces and declare features of some projects. Features define symbols that
are used for conditional compilation. The features here define optional parts of the \e wx.NET system: The styled text control
(STC) and the interface to the display:
\code
# BOO script to build the wx.Buildsystem projects from assembly
# wx.Net.Build, Version=0.9.0.0, Culture=neutral, PublicKeyToken=c5f483f7e93d2714.
# This program has been generated automatically by the wx.BuildSystem
# (c) 2010 Harald Meyer auf'm Hofe.
#
# The following lines will declare variables to configure the tools
# that are used to build the system. You may change these declarations
# if you know what you are doing.
import System.Text
import System.IO
import System.Diagnostics
# Features of project wx.NET: The managed part of the wx.NET implementation.
Features_wx_NET=[]
Features_wx_NET.Add("WXNET_DISPLAY") # Display Access: Enables class wx.Display
Features_wx_NET.Add("WXNET_STYLEDTEXTCTRL") # Styled Text Control: Enables namespace wx.StyledText
\endcode

In the following, the base path will be defined, that will be used to complete all local paths in the build program. 
Additionally, the build mode (rebuild or reuse of existing build results) and the target directory containing all
internal build projects will be declared here.
\code
# This is the root path of the project.
wxNetBase='c:\\sf\\wx.NET\\Bin'
System.IO.Directory.SetCurrentDirectory(wxNetBase)
#
# If true, then any target will be rebuild. If false, many build actions
# will only rebuild targets if prerequisites are newer.
Rebuild=false
#
# This is the directory containing all non-target files that will be created on building the targets.
BuildDir='Build\\Debug'
\endcode

The following sections will provide definitions of files and options 
for each avaiable tool. The following listing presents the section defining options for the CSC.EXE C# compiler
of Microsoft's .NET framework.

\code
#################################################################
# These are the declarations of tool csc.exe of family MSNET:
# c:\WINDOWS\Microsoft.NET\Framework\v3.5\csc.exe: The C# compiler of the MS .NET framework.
# This variable is the path to the CSC compiler that will be used.
MS_CSC="c:\\WINDOWS\\Microsoft.NET\\Framework\\v3.5\\csc.exe"
# This option defines whether to compile with debug information or not
MS_CSC_OPTIONS='/debug'
# This option turns on optimization
#MS_CSC_OPTIONS+=' /optimize'
# This option defines the warning level
MS_CSC_OPTIONS+=' /warn:3'
MS_CSC_OPTIONS+=' /fullpaths'
#MS_CSC_OPTIONS+=' /warnaserror' # treats warnings as errors
MS_CSC_OPTIONS+=' /define:__MS_CSC__' # identifies the compiler
MS_CSC_OPTIONS+=' /define:TRACE' # enables trace log
#################################################################
\endcode

The final section defines so-called choice points. Since the build program uses all available build tools,
there may be alternative paths to achieve certain targets. The workstation that created this BOO program
has been fully equipped with VC Express and GNU MinGW to build C/C++ subsystems, VS Express and MONO to build
C# subsystems. Thus, the user of the build system has the choice. The following choice points enable the user
to make this choice.

\code
#########################################################
# This section contains choice points- BOO variables that
# control which tools will be used. Assign one of the
# listed values to the choice points in order to select
# a particular tool. If this tool is not available, the
# program will automatically use an alternative.
CppDevelopmentSystem = "MS VC" # "MS VC" "GNU"
CSHARP_COMPILER = "csc.exe" # "csc.exe" "gmcs" "CSharpCodeProvider"
\endcode

\subsection using_boo_exports_definitions The section defining the build programs

The next section implements the wrapper functions that will be called to run the build tools.
Users of the build system are not required to know them. However, the following sections shows
the function calling the CSC.EXE compiler for all those that like to know how things work.

\code
#########################################################
# The section containing declarations ends here.
# Please refrain from changing the code from this position on.
# The code below will provide definitions of build functions and
# will use this functions afterwards to produce the build targets.
# However, you may want to disable build tools here by replacing
# the body of the corrsponding function with "pass".
def TestForRebuild(targetFile as  string, *sourceFiles as (object)):
	if Rebuild: return true
	if not System.IO.File.Exists(targetFile): return true
	dTarget=System.IO.File.GetLastWriteTime(targetFile)
	inlinedSources=[]
	for sourceFile in sourceFiles:
		if sourceFile == null: continue
		if sourceFile isa System.Array:
			for containedSource in cast(System.Array, sourceFile):
				inlinedSources.Add(containedSource)
		else:
			inlinedSources.Add(sourceFile)
	for inlinedSource in inlinedSources:
		dSource=System.IO.File.GetLastWriteTime(inlinedSource)
		if dTarget < dSource: return true
	return false
#
# These are the definitions of tool csc.exe of family MSNET:
# c:\WINDOWS\Microsoft.NET\Framework\v3.5\csc.exe: The C# compiler of the MS .NET framework.
def RunMsCsc(targettype as string, target as string, w32icon as string, signature as string, mainclass as string, references as (string), sources as (string), features):
	if not TestForRebuild(target, w32icon, signature, references, sources):
		print target,"is up to date"
		return
	print "MS csc.exe creates", target
	args=StreamWriter("${BuildDir}\\plain\\csc.txt")
	args.Write("/out:${target} /target:${targettype}")
	for feature in features:
		if feature=="X32":
			args.Write(' /platform:x86')
		elif feature=="X64":
			args.Write(' /platform:x64')
		else:
			args.Write(' /define:')
			args.Write(feature)
	for reference in references:
		args.Write(" /reference:\"${reference}\"")
	if signature != null:
		args.Write(" /keyfile:\"${signature}\"")
	if w32icon != null:
		args.Write(" /win32icon:\"${w32icon}\"")
	if mainclass != null:
		args.Write(" /main:${mainclass}")
	args.Write(' ')
	args.Write(MS_CSC_OPTIONS)
	for source in sources:
		args.Write(" \"${source}\"")
	args.Close()
	startinfo=System.Diagnostics.ProcessStartInfo()
	startinfo.FileName=MS_CSC
	startinfo.Arguments="@${BuildDir}\\plain\\csc.txt"
	startinfo.UseShellExecute=false
	p=System.Diagnostics.Process.Start(startinfo)
	p.WaitForExit()
	if p.ExitCode!=0:
		raise System.Exception("Build action failed.")
\endcode

\subsection using_boo_exports_building The section actually building the desired targets

The final section uses the wrapper functions defined in the previous section to actually build the
build targets.

This is the code producing the \c controls.exe programm.
\code
if CSHARP_COMPILER == "gmcs":
	print 'Executing gmcs'
	RunMonoGmcs("winexe", "${wxNetBase}\\controls.exe", ("../Samples/Controls\\Controls.cs", ), ("System.dll", "System.Drawing.dll", "${wxNetBase}\\wx.NET.dll", ), "c:\\sf\\wx.NET\\Src\\wx.NET\\mondrian.ico", "c:\\sf\\wx.NET\\Src\\wx.NET\\keys.snk", null, [])
elif CSHARP_COMPILER == "CSharpCodeProvider":
	print 'Executing CSharpCodeProvider'
	print "Caught exception creating code for action CSharpCodeProvider."
	print "BOO code creation is not supported by action wx.Build.Net.CSharpCodeProvider."
else: # CSHARP_COMPILER == "csc.exe"
	print 'Executing csc.exe'
	RunMsCsc('winexe', "${wxNetBase}\\controls.exe", "c:\\sf\\wx.NET\\Src\\wx.NET\\mondrian.ico", "c:\\sf\\wx.NET\\Src\\wx.NET\\keys.snk", null, ("System.dll", "System.Drawing.dll", "${wxNetBase}\\wx.NET.dll"), ("../Samples/Controls\\Controls.cs",), [])
\endcode

 
\section building_with_solution_files Using Solution Files To Build wx.NET

wx.NET comes with 2 solution files \c wx-c.sln and \c wx.NET.sln in directory \c WXNET_TOP\Build\VCProject. The first
one builds the wx-c.dll using the MS VC Express Edition (or Standard or Professional Editions). The latter builds
the \c wx.NET.dll assembly and all sample programs and can eb used with either VS Net Express Edition or MonoDevelop.
These files are also useful to run debuggers - in order to have a look inside.

\section building_from_source_premake_overview Premake Overview

Previous releases suggested the use of the <a href="http://premake.sf.net">premake</a> meta-make
system. wx.NET is still shipped with the \c premake program files but these files are no longer maintained
and may not be up to date. 

\c Premake is a program to create configuration files for multiple build systems from a single
platform-independent configuration file. In our case, Makefiles for systems with a UN*X-like
shell environment (Linux, MacOS X) and Visual Studio.NET 2005 (VS.NET) solution/project files
for Microsoft Windows.

Premake configuration files are named \c premake.lua and can be found throughout the source tree.
We've included pre-built premake binaries for Linux, Mac, and Windows in the build system.
You don't have to compile Premake or even know how it works unless you want to bypass the
build system.

More information about wx.NET's Premake configuration files can be found in the Premake appendix.
Detailed Build Instructions

\subsection premake_appendix Premake Appendix

<a href="http://premake.sf.net">Premake</a> configuration files are written in the Lua scripting language,
hence the \c .lua extension on each file. Under the top of the source tree you'll find the
following:
<list type="table">
<item><term> premake.lua </term><description>Builds the wx-c C++ wrapper library and the wx.NET.dll assembly</description></item>
<item><term> Src/wx-c/premake.lua, Src/wx-c/premake-funcs.lua  </term><description>Builds the wx-c wrapper</description></item>
<item><term> Src/wx.NET/premake.lua  </term><description>Builds wx.NET.dll</description></item>
<item><term> Utils/premake.lua  </term><description>Builds all utilities</description></item>
<item><term> Utils/ * /Src/premake.lua  </term><description>There are premake files for each utility</description></item>
<item><term> Samples/premake.lua  </term><description>Builds all samples</description></item>
<item><term> Samples/ * /premake.lua  </term><description>There are premake files for each sample</description></item>
</dl>

\subsection manual_use_of_premake Manual Use of Premake

If you need to edit the Premake configuration files or experiment with Premake, you'll probably
want to make sure the premake binary is in your PATH. Using the pre-built premake binaries
bundled with the wx.NET source is a safe option:
\li Build/Linux/premake
\li Build/MacOSX/premake
\li Build/Windows/premake.exe

On my Linux build system I've created a symlink in \c /usr/local/bin:

\verbatim
$ ln -s /usr/local/src/wx.NET-CVS/wx.NET/Build/Linux/premake /usr/local/bin
\endverbatim

Remember that this is not necessary to use the build system.

Premake has a number of options which control what type of build file(s) are created, what compiler
to use, etc. In addition, Premake configuration files can accept their own custom options.
This is used extensively by the wx.NET.dll and wx-c premake files. To see a list of both standard
and custom options just type:
\verbatim
$ premake --help
\endverbatim

The most important options are --target, which is used to specify the type of project build files to create:

\verbatim
$ premake [ options ] --target xxx
\endverbatim

The standard set of options for Premake 2.0 Beta 6 follow:
\verbatim
Premake 3.2, a build script generator
Copyright (C) 2002-2006 Jason Perkins and the Premake Project
Lua 5.0.3 Copyright (C) 1994-2006 Tecgraf, PUC-Rio

 --file name       Process the specified premake script file

 --clean           Remove all binaries and build scripts
 --verbose       Generate verbose makefiles (where applicable)

 --cc name         Choose a C/C++ compiler, if supported by target; one of:
      gcc       GNU gcc compiler
      dmc       Digital Mars C/C+ compiler (experimental)

 --dotnet name     Choose a .NET compiler set, if supported by target; one of:
      ms        Microsoft (csc)
      mono      Mono (mcs)
      mono2     Mono .NET 2.0 (gmcs)
      pnet      Portable.NET (cscc)

 --os name         Generate files for different operating system; one of:
      bsd       OpenBSD, NetBSD, or FreeBSD
      linux     Linux
      macosx    MacOS X
      windows   Microsoft Windows

 --target name     Generate input files for the specified toolset; one of:
      cb-gcc    Code::Blocks Studio with GCC
      gnu       GNU Makefile for POSIX, MinGW, and Cygwin
      monodev   MonoDevelop
      sharpdev  ICSharpCode SharpDevelop
      vs6       Microsoft Visual Studio 6
      vs2002    Microsoft Visual Studio 2002
      vs2003    Microsoft Visual Studio 2003
      vs2005    Microsoft Visual Studio 2005 (includes Express editions)

 --help            Display this information
 --version         Display version information
\endverbatim
 */


// the code switched to Versione 3.1
/* \page licence Licence
\verbatim

                wxWidgets Library Licence, Version 3

                ====================================





  Copyright (c) 1998 Julian Smart, Robert Roebling et al

  Everyone is permitted to copy and distribute verbatim copies
  of this licence document, but changing it is not allowed.


                       WXWINDOWS LIBRARY LICENCE

     TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION

  This library is free software; you can redistribute it and/or modify it
  under the terms of the GNU Library General Public Licence as published by
  the Free Software Foundation; either version 2 of the Licence, or (at
  your option) any later version.

  This library is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Library
  General Public Licence for more details.

  You should have received a copy of the GNU Library General Public Licence
  along with this software, usually in a file named COPYING.LIB.  If not,
  write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330,
  Boston, MA 02111-1307 USA.

  EXCEPTION NOTICE

  1. As a special exception, the copyright holders of this library give
  permission for additional uses of the text contained in this release of
  the library as licenced under the wxWidgets Library Licence, applying
  either version 3 of the Licence, or (at your option) any later version of
  the Licence as published by the copyright holders of version 3 of the
  Licence document.

  2. The exception is that you may use, copy, link, modify and distribute
  under the user's own terms, binary object code versions of works based
  on the Library.

  3. If you copy code from files distributed under the terms of the GNU
  General Public Licence or the GNU Library General Public Licence into a
  copy of this library, as this licence permits, the exception does not
  apply to the code that you add in this way.  To avoid misleading anyone as
  to the status of such modified files, you must delete this exception
  notice from such code and/or adjust the licensing conditions notice
  accordingly.

  4. If you write modifications of your own for this library, it is your
  choice whether to permit this exception to apply to your modifications. 
  If you do not wish that, you must delete the exception notice from such
  code and/or adjust the licensing conditions notice accordingly.
\endverbatim
*/