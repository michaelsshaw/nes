//-----------------------------------------------------------------------------
// wx.NET - DirDialog.cs
// 
// The wxDirDialog wrapper class.
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: DirDialog.cs,v 1.13 2010/04/23 16:57:11 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Drawing;
using System.Runtime.InteropServices;

namespace wx
{
    /// <summary>A dialog to ask for either one or many directories.</summary>
    /// <remarks>
    /// If appropriate, you may use the DirSelector instead.
    /// Available styles:
    /// <list type="table">
    /// <item><term>wx.WindowStyles.DD_DEFAULT_STYLE</term><description>Equivalent to a combination of wxDEFAULT_DIALOG_STYLE and wxRESIZE_BORDER (the last one is not used under wxWinCE).</description></item>
    /// <item><term>wx.WindowStyles.DD_DIR_MUST_EXIST</term><description>The dialog will allow the user to choose only an existing folder. When this style is not given, a "Create new directory" button is added to the dialog (on Windows) or some other way is provided to the user to type the name of a new folder.</description></item>
    /// <item><term>wx.WindowStyles.DD_CHANGE_DIR</term><description>Change the current working directory to the directory chosen by the user.</description></item>
    /// </list>
    /// NB: on Windows the new directory button is only available with recent versions of the common dialogs.
    /// </remarks>
    public class DirDialog : Dialog
    {
        [DllImport("wx-c")] static extern IntPtr wxDirDialog_ctor(IntPtr parent, IntPtr message, IntPtr defaultPath, uint style, int posX, int posY, int width, int height, IntPtr name);

        [DllImport("wx-c")] static extern void   wxDirDialog_SetPath(IntPtr self, IntPtr path);
        [DllImport("wx-c")] static extern IntPtr wxDirDialog_GetPath(IntPtr self);

        [DllImport("wx-c")] static extern uint   wxDirDialog_GetStyle(IntPtr self);
        [DllImport("wx-c")] static extern void   wxDirDialog_SetStyle(IntPtr self, uint style);

        [DllImport("wx-c")] static extern void   wxDirDialog_SetMessage(IntPtr self, IntPtr message);
        [DllImport("wx-c")] static extern IntPtr wxDirDialog_GetMessage(IntPtr self);

        [DllImport("wx-c")] static extern int    wxDirDialog_ShowModal(IntPtr self);

        //-----------------------------------------------------------------------------

        public DirDialog(IntPtr wxObject) 
            : base(wxObject) { }

        public DirDialog(Window parent)
            : this(parent, "Choose a directory", "", wx.WindowStyles.NO_STYLE, wxDefaultPosition, wxDefaultSize, "DirDialog") { }

        public DirDialog(Window parent, string message)
            : this(parent, message, "", wx.WindowStyles.NO_STYLE, wxDefaultPosition, wxDefaultSize, "DirDialog") { }

        public DirDialog(Window parent, string message, string defaultPath)
            : this(parent, message, defaultPath, wx.WindowStyles.NO_STYLE, wxDefaultPosition, wxDefaultSize, "DirDialog") { }

        public DirDialog(Window parent, string message, string defaultPath, wx.WindowStyles style)
            : this(parent, message, defaultPath, style, wxDefaultPosition, wxDefaultSize, "DirDialog") { }

        public DirDialog(Window parent, string message, string defaultPath, wx.WindowStyles style, Point pos)
            : this(parent, message, defaultPath, style, pos, wxDefaultSize, "DirDialog") { }

        public DirDialog(Window parent, string message, string defaultPath, wx.WindowStyles style, Point pos, Size size)
            : this(parent, message, defaultPath, style, pos, size, "DirDialog") { }

        public DirDialog(Window parent, string message, string defaultPath, wx.WindowStyles style, Point pos, Size size, string name)
            : this(parent, wxString.SafeNew(message), wxString.SafeNew(defaultPath), style, pos.X, pos.Y, size.Width, size.Height, wxString.SafeNew(name))
        {
        }

        static IntPtr LockedCTor(Window parent, wxString message, wxString defaultPath, wx.WindowStyles style, int posX, int posY, int width, int height, wxString name)
        {
            lock (DllSync)
            {
                return wxDirDialog_ctor(Object.SafePtr(parent), Object.SafePtr(message), Object.SafePtr(defaultPath), (uint)style, posX, posY, width, height, Object.SafePtr(name));
            }
        }

        public DirDialog(Window parent, wxString message, wxString defaultPath, wx.WindowStyles style, int posX, int posY, int width, int height, wxString name)
            : this(LockedCTor(parent, message, defaultPath, style, posX, posY, width, height, name))
        {
        }

        //-----------------------------------------------------------------------------

        /// <summary>
        /// The path that has been selected.
        /// </summary>
        public string Path
        {
            set
            {
                wxString wxValue = wxString.SafeNew(value);
                wxDirDialog_SetPath(wxObject, Object.SafePtr(wxValue));
            }
            get { return new wxString(wxDirDialog_GetPath(wxObject), true); }
        }

        //-----------------------------------------------------------------------------

        public string Message
        {
            set
            {
                wxString wxMessage = wxString.SafeNew(value);
                wxDirDialog_SetMessage(wxObject, Object.SafePtr(wxMessage));
            }
            get { return new wxString(wxDirDialog_GetMessage(wxObject), true); }
        }

        //-----------------------------------------------------------------------------

        public override ShowModalResult ShowModal()
        {
            int result = wxDirDialog_ShowModal(wxObject);
            switch (result)
            {
                case 5100 /* wxID_OK */: return ShowModalResult.OK;
                case 5103 /* wxID_YES */: return ShowModalResult.YES;
                case 5104 /* wxID_NO */: return ShowModalResult.NO;
                default:
                    return ShowModalResult.CANCEL;
            }
        }

        //-----------------------------------------------------------------------------

        public wx.WindowStyles Style
        {
            set { wxDirDialog_SetStyle(wxObject, (uint)value); }
            get { return (wx.WindowStyles)wxDirDialog_GetStyle(wxObject); }
        }

        //-----------------------------------------------------------------------------
    }
}

