//-----------------------------------------------------------------------------
// wx.NET - ComboBox.cs
//
// The wxComboBox wrapper class.
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 Bryan Bulten
//
// Complete revision: 2007 Harald Meyer auf'm Hofe
//
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: ComboBox.cs,v 1.26 2010/05/08 19:51:26 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Drawing;
using System.Runtime.InteropServices;

namespace wx
{
    public class ComboBox : ControlWithItems
	{
		[DllImport("wx-c")] static extern IntPtr wxComboBox_ctor();
        [DllImport("wx-c")] static extern bool wxComboBox_Create(IntPtr self, IntPtr window, int id, IntPtr value, ref Point pos, ref Size size, IntPtr choices, uint style, IntPtr validator, IntPtr name);
		
		//[DllImport("wx-c")] static extern int    wxComboBox_GetSelection(IntPtr self);		
		[DllImport("wx-c")] static extern IntPtr wxComboBox_GetValue(IntPtr self);
        [DllImport("wx-c")] static extern void wxComboBox_SetValue(IntPtr self, IntPtr text);
		
		[DllImport("wx-c")] static extern void   wxComboBox_Copy(IntPtr self);
		[DllImport("wx-c")] static extern void   wxComboBox_Cut(IntPtr self);
		[DllImport("wx-c")] static extern void   wxComboBox_Paste(IntPtr self);
		
		[DllImport("wx-c")] static extern void   wxComboBox_SetInsertionPoint(IntPtr self, int pos);
		[DllImport("wx-c")] static extern int    wxComboBox_GetInsertionPoint(IntPtr self);
		[DllImport("wx-c")] static extern void   wxComboBox_SetInsertionPointEnd(IntPtr self);
		[DllImport("wx-c")] static extern int    wxComboBox_GetLastPosition(IntPtr self);

        [DllImport("wx-c")] static extern void   wxComboBox_Replace(IntPtr self, int from, int to, IntPtr value);
		[DllImport("wx-c")] static extern void   wxComboBox_SetSelection(IntPtr self, int from, int to);
		[DllImport("wx-c")] static extern void   wxComboBox_SetEditable(IntPtr self, bool editable);
		[DllImport("wx-c")] static extern void   wxComboBox_Remove(IntPtr self, int from, int to);
		
		//[DllImport("wx-c")] static extern void wxComboBox_SetSelection(IntPtr self, int n);
		
		[DllImport("wx-c")] static extern void wxComboBox_Select(IntPtr self, int n);
		
		//---------------------------------------------------------------------
	
		public ComboBox(IntPtr wxObject) 
			: base(wxObject) { }

        static IntPtr LockedCTor()
        {
            lock (DllSync)
            {
                return wxComboBox_ctor();
            }
        }

		public ComboBox()
			: base(LockedCTor()) { }

		public ComboBox(Window parent, int id)
			: this(parent, id, "", wxDefaultPosition, wxDefaultSize, (string[])null, wx.WindowStyles.NO_STYLE, null) { }

        public ComboBox(Window parent, int id, string value, Point pos, Size size, string[] choices)
            : this(parent, id, new wxString(value), pos, size, ArrayString.SafeNewFrom(choices), wx.WindowStyles.NO_STYLE, null) { }

        /** <summary>Refer to prefix <c>CB_</c> for especially applicable style flags.</summary>*/
        public ComboBox(Window parent, int id, string value, Point pos, Size size, string[] choices, wx.WindowStyles style)
            : this(parent, id, new wxString(value), pos, size, ArrayString.SafeNewFrom(choices), style, null) { }

        /** <summary>Refer to prefix <c>CB_</c> for especially applicable style flags.</summary>*/
        public ComboBox(Window parent, int id, string value, Point pos, Size size, string[] choices, wx.WindowStyles style, string name)
            : this(parent, id, new wxString(value), pos, size, ArrayString.SafeNewFrom(choices), style, new wxString(name))
        {
        }

        internal ComboBox(Window parent, int id, wxString value, Point pos, Size size, ArrayString choices, wx.WindowStyles style, wxString name)
			: base(LockedCTor())
		{
			if(!wxComboBox_Create(wxObject, Object.SafePtr(parent), id, 
						Object.SafePtr(value), ref pos, ref size, 
						Object.SafePtr(choices), (uint)style, 
						IntPtr.Zero, Object.SafePtr(name))) 
			{
				throw new InvalidOperationException("Failed to create ListBox");
			}
		}
		
		//---------------------------------------------------------------------
		// ctors with self created id
		
		public ComboBox(Window parent)
			: this(parent, Window.UniqueID, "", wxDefaultPosition, wxDefaultSize, (string[]) null, wx.WindowStyles.NO_STYLE, null) { }

		public ComboBox(Window parent, string value, Point pos, Size size, string[] choices)
            : this(parent, Window.UniqueID, new wxString(value), pos, size, ArrayString.SafeNewFrom(choices), wx.WindowStyles.NO_STYLE, null) { }

		public ComboBox(Window parent, string value, Point pos, Size size, string[] choices, wx.WindowStyles style)
            : this(parent, Window.UniqueID, new wxString(value), pos, size, ArrayString.SafeNewFrom(choices), style, null) { }

		public ComboBox(Window parent, string value, Point pos, Size size, string[] choices, wx.WindowStyles style, string name)
            : this(parent, Window.UniqueID, new wxString(value), pos, size, ArrayString.SafeNewFrom(choices), style, new wxString(name)) { }
		
		//---------------------------------------------------------------------

		public bool Create(Window parent, int id, string value, Point pos, Size size, string[] choices, wx.WindowStyles style, string name)
		{
            return this.Create(parent, id,
					            new wxString(value), pos, size, 
					            ArrayString.SafeNewFrom(choices), 
					            style, new wxString(name));
		}
        internal bool Create(Window parent, int id, wxString value, Point pos, Size size, ArrayString choices, wx.WindowStyles style, wxString name)
        {
            return wxComboBox_Create(wxObject, Object.SafePtr(parent), id,
                                    Object.SafePtr(value), ref pos, ref size,
                                    Object.SafePtr(choices),
                                    (uint)style, IntPtr.Zero, Object.SafePtr(name));
        }


		public void Copy()
		{
			wxComboBox_Copy(this.wxObject);
		}
		
		//---------------------------------------------------------------------

		public void Cut()
		{
			wxComboBox_Cut(this.wxObject);
		}
		
		//---------------------------------------------------------------------

		public void Paste()
		{
			wxComboBox_Paste(this.wxObject);
		}

		//---------------------------------------------------------------------
        
		public int InsertionPoint
		{
			get { return wxComboBox_GetInsertionPoint(this.wxObject); }
			set { wxComboBox_SetInsertionPoint(this.wxObject, value); }
		}
		
		//---------------------------------------------------------------------

		public void SetInsertionPointEnd()
		{
			wxComboBox_SetInsertionPointEnd(this.wxObject);
		}
		
		//---------------------------------------------------------------------

		public int GetLastPosition()
		{
			return wxComboBox_GetLastPosition(this.wxObject);
		}

		//---------------------------------------------------------------------

		public void Replace(int from, int to, string value)
		{
            wxString wxValue = new wxString(value);
			wxComboBox_Replace(wxObject, from, to, wxValue.wxObject);
		}

		//---------------------------------------------------------------------

        /** <summary>Refer to ControlWithItems for the method receiving only one index.
         *</summary>*/
		public void SetSelection(int from, int to)
		{
			wxComboBox_SetSelection(this.wxObject, from, to);
		}
		
		//---------------------------------------------------------------------

		public bool Editable
		{
            set { wxComboBox_SetEditable(this.wxObject, value); }
		}

		//---------------------------------------------------------------------
        
		public void Remove(int from, int to)
		{
			wxComboBox_Remove(wxObject, from, to);
		}

		//---------------------------------------------------------------------
        
		public string Value
		{
			get { return new wxString(wxComboBox_GetValue(wxObject)); }
			set
            {
                wxString wxValue = new wxString(value);
                wxComboBox_SetValue(this.wxObject, wxValue.wxObject);
            }
		}
		
		public void Select(int n)
		{
			wxComboBox_Select(this.wxObject, n);
		}

		//---------------------------------------------------------------------

		public event EventListener Selected
		{
			add { AddCommandListener(Event.wxEVT_COMMAND_COMBOBOX_SELECTED, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}
	}
}

