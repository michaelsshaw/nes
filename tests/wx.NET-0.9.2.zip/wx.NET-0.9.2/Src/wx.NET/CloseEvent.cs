//-----------------------------------------------------------------------------
// wx.NET - CloseEvent.cs
//
// The wxCloseEvent wrapper class.
//
// Written by Alexander Olk (xenomorph2@onlinehome.de)
// (C) 2004 by Alexander Olk
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// CloseEvent.cs,v 1.2 2004/02/25 12:08:28 olkalex Exp
//-----------------------------------------------------------------------------

using System;
using System.Collections;
using System.Runtime.InteropServices;

namespace wx
{
    /// <summary>
    /// This event class contains information about window and session close events.
    /// 
    /// The handler function for EVT_CLOSE is called when the user has tried to close a a frame or dialog box using the
    /// window manager (X) or system menu (Windows). It can also be invoked by the application itself programmatically,
    /// for example by calling the wx.Window.Close() function.
    /// 
    /// You should check whether the application is forcing the deletion of the window using wx.CloseEvent.CanVeto.
    /// If this is false, you must destroy the window using wx.Window.Destroy. If the return value is true, it is up to
    /// you whether you respond by destroying the window.
    /// 
    /// If you don't destroy the window, you should call wx.CloseEvent.Veto to let the calling code know that you did
    /// not destroy the window. This allows the wx.Window.Close() function to return true or false depending on whether the
    /// close instruction was honoured or not.
    /// 
    /// Please do not forget to skip the event after processing. wxWidgets may stop closig down the application
    /// if the event has not been skipped.
    /// </summary>
	public class CloseEvent : Event
	{
		[DllImport("wx-c")] static extern IntPtr wxCloseEvent_ctor(int type);
		[DllImport("wx-c")] static extern void wxCloseEvent_SetLoggingOff(IntPtr self, bool logOff);
		[DllImport("wx-c")][return:MarshalAs(UnmanagedType.U1)] static extern bool wxCloseEvent_GetLoggingOff(IntPtr self);
		[DllImport("wx-c")] static extern void wxCloseEvent_Veto(IntPtr self, bool veto);
		[DllImport("wx-c")] static extern void wxCloseEvent_SetCanVeto(IntPtr self, bool canVeto);
		[DllImport("wx-c")][return:MarshalAs(UnmanagedType.U1)] static extern bool wxCloseEvent_CanVeto(IntPtr self);
		[DllImport("wx-c")][return:MarshalAs(UnmanagedType.U1)] static extern bool wxCloseEvent_GetVeto(IntPtr self);
		
		//-----------------------------------------------------------------------------

		public CloseEvent(IntPtr wxObject) 
			: base(wxObject) { }

        static IntPtr LockedCPtr(int type)
        {
            lock (DllSync)
            {
                return wxCloseEvent_ctor(type);
            }
        }

		public CloseEvent(int type)
			: this(LockedCPtr(type)) { }

		//-----------------------------------------------------------------------------
		
        /// <summary>
        /// Returns true if the user is just logging off or false if the system is shutting down.
        /// This method can only be called for end session and query end session events, it doesn't make sense for
        /// close window event.
        /// </summary>
		public bool LoggingOff
		{
			get { return wxCloseEvent_GetLoggingOff(wxObject); }
			set { wxCloseEvent_SetLoggingOff(wxObject, value); } 
		}

        /** <summary>Listeners of this event may veto the closing sequence if they are not ready for closing.
         * Do not forget to skip of not vetoed.
         * </summary>*/
        public void Veto()
		{
			Veto(true);
		}

        /** <summary>Listeners of this event may veto the closing sequence if they are not ready for closing.
         * Do not forget to skip of not vetoed.
         * </summary>
         * <param name="veto">True if you want to vetoe, false otherwise.</param>
         */
        public void Veto(bool veto)
		{
			wxCloseEvent_Veto(wxObject, veto);
		}
		
        /// <summary>
        /// Returns true if you can veto a system shutdown or a window close event. Vetoing a window close event is not possible
        /// if the calling code wishes to force the application to exit, and so this function must be called to check this.
        /// </summary>
		public bool CanVeto
		{
			set { wxCloseEvent_SetCanVeto(wxObject, value); }
			get { return wxCloseEvent_CanVeto(wxObject); }
		}
		
		public bool GetVeto
		{
			get { return wxCloseEvent_GetVeto(wxObject); }
		}
	}
}