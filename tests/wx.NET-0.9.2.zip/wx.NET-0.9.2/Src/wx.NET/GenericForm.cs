/**
 * wx.NET Project
 * 
 * \file 
 * 
 * A form that will be build automatically edit arbitrary .NET instances using reflection.
 * 
 * Written by Dr. Harald Meyer auf'm Hofe (C) 2008 
 * Licensed under the wxWidgets license, see LICENSE.txt for details.
 *
 * $Id: GenericForm.cs,v 1.7 2010/05/08 19:52:40 harald_meyer Exp $
 */

using System;
using System.Collections.Generic;
using System.Reflection;

using wx;
using wx.Globalization;
using wx.ComponentModel;

/** Yet another generic form.
 * Annotate a view model of the form with attributes and create a form panel providing the instance of a view model: done!
 * Refer to the STC sample program for an example implementation.
 * 
 * the main class in this namespace is the GenericFormPanel. This panel is able to display
 */
namespace wx.GenericForm
{
    /** <summary>This panel will present data</summary>*/
    public class GenericFormPanel : ScrolledWindow
    {

        #region State
        object _model;
        bool _readOnly = false;

        /** <summary>Data of days that have been declared as holidays or special days.</summary>*/
        Dictionary<DateTime, CalendarDateAttr> _specialDays = new Dictionary<DateTime, CalendarDateAttr>();


        #endregion

        #region CTor
        void CreatePanelItems()
        {
            foreach (System.Reflection.PropertyInfo property in this._model.GetType().GetProperties())
            {
                object[] formStyleAttrs=property.GetCustomAttributes(typeof(FormItemAttribute), true);
                FormItemAttribute formStyleAttr=null;
                if (formStyleAttrs != null && formStyleAttrs.Length > 0)
                    formStyleAttr=(FormItemAttribute)formStyleAttrs[0];

                if (formStyleAttr==null)
                    continue;

                bool readOnly = this._readOnly;
                if (!readOnly && property.GetSetMethod() == null)
                    readOnly = true;
                if (!readOnly && formStyleAttr != null && formStyleAttr.IsReadOnly)
                    readOnly = true;

                
            }
        }

        /** <summary>This will create a form presenting the data in <c>dataModel</c>.
         * This will show all properties that exhibit a FormStylePropertyAttribute or a FormJoinGroupAttribute.
         * Properties providing a modifier will be presented in active controls. Properties without a modifer will be
         * presented in disabled controls. You may specify a read-only presentation with WindowStyles.GENERICFORM_READONLY.
         *</summary>
         */
        public GenericFormPanel(object dataModel,
            Window parent, int id, System.Drawing.Point position, System.Drawing.Size size, WindowStyles style)
            : base(parent, id, position, size, style)
        {
            this._readOnly = (style & WindowStyles.GENERICFORM_READONLY) != WindowStyles.GENERICFORM_READONLY;
            this._model = dataModel;
            this.CreatePanelItems();
        }

        public GenericFormPanel(object dataModel,
            Window parent, System.Drawing.Point position, System.Drawing.Size size, WindowStyles style)
            : this(dataModel, parent, -1, position, size, style)
        {
        }

        public GenericFormPanel(object dataModel, Window parent)
            : this(dataModel, parent, -1, wxDefaultPosition, wxDefaultSize, WindowStyles.NO_STYLE)
        {
        }
        #endregion

        #region Configuration
        /** <summary>The designated date is a holiday.</summary>*/
        public void SetHoliday(DateTime day)
        {
            this._specialDays[day.Date] = null;
        }

        /** <summary>Defines the manner in which the designated day will be presented in a calendar ctrl.</summary>*/
        public void SetAttributesOfDay(DateTime day, CalendarDateAttr attr)
        {
            this._specialDays[day.Date] = attr;
        }

        /** <summary>Resets the properties associated with the designated day.</summary>*/
        public void resetAttributesOfDay(DateTime day)
        {
            if (this._specialDays.ContainsKey(day.Date))
                this._specialDays.Remove(day.Date);
        }
        #endregion
    }
}
