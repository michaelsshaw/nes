//-----------------------------------------------------------------------------
// wx.NET - CalendarCtrl.cs
// 
// The wxCalendarCtrl wrapper class.
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: CalendarCtrl.cs,v 1.18 2009/10/11 16:23:18 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System.Runtime.InteropServices;
using System.Drawing;
using System;

namespace wx
{
    public enum CalendarHitTestResult
    {
        wxCAL_HITTEST_NOWHERE,
        wxCAL_HITTEST_HEADER,
        wxCAL_HITTEST_DAY,
        wxCAL_HITTEST_INCMONTH,
        wxCAL_HITTEST_DECMONTH,
        wxCAL_HITTEST_SURROUNDING_WEEK
    }

    public enum CalendarDateBorder
    {
        wxCAL_BORDER_NONE,
        wxCAL_BORDER_SQUARE,
        wxCAL_BORDER_ROUND
    }

    /** <summary>An enumeration representing periods within a calendar.
     * Refer to Calendar.DaysInPeriod().</summary>*/
    public enum CalendarPeriod
    {
        Once,
        Weekly,
        Monthly,
        Yearly,
    }

    /** <summary>Assigns name and attributes to special days.
     * These will be displayed in calendar controls if set to the appropriate property.
     * 
     * Add styles to the calendar and asign them to days.
     * 
     * You may either extend this by subclassing or providing event handlers.</summary>*/
    public class Calendar
    {
        /** <summary>This returns a list of days with a distance referring to <c>repreat</c> to day \ reference within a period of days.
         * Example 1: Reference 1st of July 2008 and <c>repeat</c> <c>CalendarPeriod.Monthly</c> within the period starting with the 2nd
         * May 2008 ranging to the 2nd Aug. 2008 will return the following <c>DateTime</c> instances: 1st of June, 1st of July,
         * 1st of August. 
         * 
         * Example 2: The parameters from example 1 but with reference 1st of Jan. 2008 will result into the same result.
         * 
         * Example 3: The parameters from example 1 but with period 2nd of July to 31th of July will result into an empty list.</summary>*/
        public static System.Collections.Generic.IList<DateTime> DaysInPeriod(DateTime reference, CalendarPeriod repeat, DateTime periodStart, DateTime periodEnd)
        {
            System.Collections.Generic.List<DateTime> result=new System.Collections.Generic.List<DateTime>();
            if (periodStart.Year < 3000 && periodEnd.Year < 3000)
            {
                switch (repeat)
                {
                    case CalendarPeriod.Once:
                        if (reference >= periodStart && reference <= periodEnd)
                            result.Add(reference);
                        break;
                    case CalendarPeriod.Monthly:
                        {
                            for (DateTime it = periodStart; it <= periodEnd; it = it.AddMonths(1))
                            {
                                int maxDay = DateTime.DaysInMonth(it.Year, it.Month);
                                DateTime newDay = new DateTime(it.Year, it.Month, maxDay);
                                if (reference.Day < maxDay)
                                    newDay = new DateTime(it.Year, it.Month, reference.Day);
                                if (newDay >= periodStart && newDay <= periodEnd)
                                    result.Add(newDay);
                            }
                        }
                        break;
                    case CalendarPeriod.Weekly:
                        {
                            int offset = (int)reference.DayOfWeek - (int)periodStart.DayOfWeek;
                            if (offset < 0) offset += 7;
                            periodStart = periodStart.AddDays(offset);
                            for (DateTime it = periodStart; it <= periodEnd; it = it.AddDays(7))
                            {
                                result.Add(it);
                            }
                        }
                        break;
                    case CalendarPeriod.Yearly:
                        {
                            for (DateTime it = periodStart; it <= periodEnd; it = it.AddYears(1))
                            {
                                int day = DateTime.DaysInMonth(it.Year, it.Month);
                                if (reference.Day < day)
                                    day = reference.Day;
                                DateTime newResult = new DateTime(it.Year, reference.Month, day);
                                if (newResult >= periodStart && newResult <= periodEnd)
                                    result.Add(newResult);
                            }
                        }
                        break;
                }
            }
            return result;
        }

        /** <summary>Argument of a <c>OnRequestFormat</c> event.
         * This provides the <c>Day</c> whose presentation format is requested.
         * Implementors may set <c>Name</c> and/or <c>Attr</c> that shall be used for presentation.</summary>*/
        public class RequestFormatEventArgs : EventArgs
        {
            DateTime _day;

            public CalendarDateAttr Attr = null;
            public string Name = null;
            public DateTime Day { get { return this._day; } }

            public RequestFormatEventArgs(DateTime day)
            {
                this._day = day;
            }
        }

        public delegate void RequestFormatEventHandler(object sender, RequestFormatEventArgs args);
        /** <summary>Called on requesting the format of a particular day.</summary>*/
        public event RequestFormatEventHandler OnRequestFormat;

        struct FormatDescr
        {
            public CalendarDateAttr Attr;
            public string           Name;

            public FormatDescr(CalendarDateAttr attr, string name)
            {
                this.Attr=attr;
                this.Name=name;
            }
            public FormatDescr(bool isHoliday, string name)
            {
                this.Name=name;
                this.Attr = new CalendarDateAttr();
                this.Attr.IsHoliday = isHoliday;
            }

            public bool IsEmpty { get { return this.Attr == null && this.Name == null; } }
        }

        struct DescrPeriodicalDay
        {
            public FormatDescr Format;
            public CalendarPeriod Period;
            public DateTime Day;

            public DescrPeriodicalDay(DateTime day, FormatDescr format, CalendarPeriod period)
            {
                this.Day = day;
                this.Format = format;
                this.Period = period;
            }
        }

        System.Collections.Generic.Dictionary<DateTime, FormatDescr> _specialDays = new System.Collections.Generic.Dictionary<DateTime, FormatDescr>();
        System.Collections.Generic.List<DescrPeriodicalDay> _specialDaysPeriodical = null;
        System.Collections.Generic.Dictionary<DateTime, bool> _expandedMonths = null;

        /** <summary>Creates an empty calendar info.
         * You may assign this to a calendar control.</summary>*/
        public Calendar()
        {
        }


        EventListener _handlerSelChanged = null;
        CalendarCtrl.DateEventHandler _handlerSetValue = null;
        /** <summary>Adds new listener on selecitons to the argument and returns the used event listener.</summary>*/
        internal void LinkToControl(CalendarCtrl ctrl)
        {
            this.OnNewMonth(ctrl);
            if (this._handlerSelChanged==null)
                this._handlerSelChanged = new EventListener(OnNewSelection);
            ctrl.EVT_CALENDAR_SEL_CHANGED(-1, this._handlerSelChanged);
            if (this._handlerSetValue == null)
                this._handlerSetValue = new CalendarCtrl.DateEventHandler(this.OnSetValueCalCtrl);
            ctrl.OnChangedDate += this._handlerSetValue;
        }

        void OnSetValueCalCtrl(CalendarCtrl ctrl, CalendarCtrl.DateEventArgs args)
        {
            if (args.OldDate.Year != args.NewDate.Year
                || args.OldDate.Month != args.NewDate.Month)
                this.OnNewMonth(ctrl);
        }

        internal void UnlinkControl(CalendarCtrl ctrl)
        {
            if (this._handlerSelChanged != null)
                ctrl.RemoveListener(this._handlerSelChanged);
            if (this._handlerSetValue != null)
                ctrl.OnChangedDate -= this._handlerSetValue;
        }

        internal void OnNewMonth(CalendarCtrl calendarCtrl)
        {
            DateTime selectedDay = calendarCtrl.Date.Date;
            DateTime monthStart = selectedDay.AddDays(1 - selectedDay.Day);
            DateTime monthEnd = monthStart.AddMonths(1).AddDays(-1);

            if (this._specialDaysPeriodical != null && this._expandedMonths != null && !this._expandedMonths.ContainsKey(monthStart))
            {
                // we have to expand this month, i.e. all days that may be derived from periodical special
                // days have to be determined and added to _specialDays.
                foreach (DescrPeriodicalDay descr in this._specialDaysPeriodical)
                {
                    System.Collections.Generic.IList<DateTime> days = DaysInPeriod(descr.Day, descr.Period, monthStart, monthEnd);
                    foreach (DateTime specialDay in days)
                        this._specialDays[specialDay] = descr.Format;
                }
                if (this.OnRequestFormat != null)
                {
                    for (DateTime day = monthStart; day <= monthEnd; day = day.AddDays(1))
                    {
                        if (!this._specialDays.ContainsKey(day))
                        {
                            RequestFormatEventArgs args = new RequestFormatEventArgs(day);
                            this.OnRequestFormat(this, args);
                            FormatDescr newFormatDescr = new FormatDescr();
                            newFormatDescr.Attr = args.Attr;
                            newFormatDescr.Name = args.Name;
                            if (!newFormatDescr.IsEmpty)
                                this._specialDays.Add(day, newFormatDescr);
                        }
                    }

                }
                this._expandedMonths.Add(monthStart, true);
            }

            // Now we have to loop over all days of the month and set resp. reset the current attributes.
            for (DateTime day = monthStart; day <= monthEnd; day=day.AddDays(1))
            {
                CalendarDateAttr attr = null;
                if (this._specialDays.ContainsKey(day))
                {
                    attr = this._specialDays[day].Attr;
                }

                if (attr == null)
                {
                    if (day == DateTime.Today)
                        calendarCtrl.SetAttr(day.Day, new CalendarDateAttr(CalendarDateBorder.wxCAL_BORDER_ROUND, wx.Colour.wxRED));
                    else
                        calendarCtrl.ResetAttr(day.Day);
                }
                else
                {
                    if (day == DateTime.Today)
                    {
                        attr = new CalendarDateAttr(attr);
                        attr.Border = CalendarDateBorder.wxCAL_BORDER_ROUND;
                        attr.BorderColour = wx.Colour.wxRED;
                    }
                    calendarCtrl.SetAttr(day.Day, attr);
                }
            }
        }

        void OnNewSelection(object sender, Event evt)
        {
            CalendarEvent cevt = evt as CalendarEvent;
            CalendarCtrl senderWindow = sender as CalendarCtrl;
            if (cevt != null && senderWindow != null)
            {
                string tooltip = "";
                DateTime newDate=cevt.Date;
                if (this._specialDays.ContainsKey(newDate))
                {
                    FormatDescr descr = this._specialDays[cevt.Date];
                    if (descr.Name != null && descr.Name.Length > 0)
                        tooltip = descr.Name;
                }
                this.OnNewMonth(senderWindow);
                senderWindow.ToolTip = tooltip;
            }
        }

        /** <summary>Defines <c>day</c> to be a holiday of the provided <c>name</c>.
         * </summary>
         */
        public void AddHoliday(DateTime day, string name)
        {
            this.AddHoliday(day, CalendarPeriod.Once, name);
        }
        /** <summary>Defines <c>day</c> to be a holiday.</summary>*/
        public void AddHoliday(DateTime day)
        {
            this.AddHoliday(day, CalendarPeriod.Once, null);
        }
        /** <summary>Defines <c>day</c> to be a holiday that will automatically be repeated periodically.</summary>*/
        public void AddHoliday(DateTime day, CalendarPeriod period)
        {
            this.AddHoliday(day, period, null);
        }
        /** <summary>Defines <c>day</c> to be a holiday of the provided name that will automatically be repeated periodically.</summary>*/
        public void AddHoliday(DateTime day, CalendarPeriod period, string name)
        {
            if (period == CalendarPeriod.Once)
            {
                this._specialDays[day] = new FormatDescr(true, name);
            }
            else
            {
                if (this._specialDaysPeriodical == null)
                {
                    this._specialDaysPeriodical = new System.Collections.Generic.List<DescrPeriodicalDay>();
                    this._expandedMonths = new System.Collections.Generic.Dictionary<DateTime, bool>();
                }
                this._specialDaysPeriodical.Add(new DescrPeriodicalDay(day, new FormatDescr(true, name), period));
                this._expandedMonths.Clear();
            }
        }

        public void AddSpecialDay(DateTime day, CalendarDateAttr attr)
        {
            this.AddSpecialDay(day, CalendarPeriod.Once, attr, null);
        }
        public void AddSpecialDay(DateTime day, CalendarDateAttr attr, string name)
        {
            this.AddSpecialDay(day, CalendarPeriod.Once, attr, name);
        }
        public void AddSpecialDay(DateTime day, CalendarPeriod period, CalendarDateAttr attr)
        {
            this.AddSpecialDay(day, period, attr, null);
        }
        public void AddSpecialDay(DateTime day, CalendarPeriod period, CalendarDateAttr attr, string name)
        {
            if (period == CalendarPeriod.Once)
            {
                this._specialDays[day] = new FormatDescr(attr, name);
            }
            else
            {
                if (this._specialDaysPeriodical == null)
                {
                    this._specialDaysPeriodical = new System.Collections.Generic.List<DescrPeriodicalDay>();
                    this._expandedMonths = new System.Collections.Generic.Dictionary<DateTime, bool>();
                }
                this._specialDaysPeriodical.Add(new DescrPeriodicalDay(day, new FormatDescr(attr, name), period));
                this._expandedMonths.Clear();
            }
        }
    }

    /** <summary>The calendar control allows the user to pick a date.
     * <remarks>
     * For this, it displays a window containing several parts: a control at the top to pick the month and the year
     * (either or both of them may be disabled), and a month area below them which shows all the days in the month.
     * The user can move the current selection using the keyboard and select the date (generating <c>EVT_CALENDAR</c> event)
     * by pressing "Return" or double clicking it.
     *
     * It has advanced possibilities for the customization of its display. All global settings (such as colours and fonts used) can,
     * of course, be changed. But also, the display style for each day in the month can be set independently using wx.CalendarDateAttr
     * class.
     *
     * An item without custom attributes is drawn with the default colours and font and without border, but setting custom
     * attributes with <c>SetAttr</c> allows to modify its appearance. Just create a custom attribute object and set it for the day you want
     * to be displayed specially (note that the control will take ownership of the pointer, i.e. it will delete it itself). A day may
     * be marked as being a holiday, even if it is not recognized as one by <c>DateTime</c> using <c>SetHoliday</c> method.
     *
     * As the attributes are specified for each day, they may change when the month is changed, so you will often want to update them in
     * <c>EVT_CALENDAR_MONTH</c> event handler.
     *
     * \image html calendar.png "The calendar control in the controls.exe sample application."
     * </remarks>
     */
    public class CalendarCtrl : Control
    {
        [DllImport("wx-c")]
        static extern IntPtr wxCalendarCtrl_ctor();
        [DllImport("wx-c")]
        static extern bool wxCalendarCtrl_Create(IntPtr self, IntPtr parent, int id, IntPtr date, int x, int y, int w, int h, uint style, IntPtr name);
        [DllImport("wx-c")]
        static extern bool wxCalendarCtrl_SetDate(IntPtr self, IntPtr date);
        [DllImport("wx-c")]
        static extern IntPtr wxCalendarCtrl_GetDate(IntPtr self);
        [DllImport("wx-c")]
        static extern bool wxCalendarCtrl_SetLowerDateLimit(IntPtr self, IntPtr date);
        [DllImport("wx-c")]
        static extern IntPtr wxCalendarCtrl_GetLowerDateLimit(IntPtr self);
        [DllImport("wx-c")]
        static extern bool wxCalendarCtrl_SetUpperDateLimit(IntPtr self, IntPtr date);
        [DllImport("wx-c")]
        static extern IntPtr wxCalendarCtrl_GetUpperDateLimit(IntPtr self);
        [DllImport("wx-c")]
        static extern bool wxCalendarCtrl_SetDateRange(IntPtr self, IntPtr lowerdate, IntPtr upperdate);
        [DllImport("wx-c")]
        static extern void wxCalendarCtrl_EnableYearChange(IntPtr self, bool enable);
        [DllImport("wx-c")]
        static extern void wxCalendarCtrl_EnableMonthChange(IntPtr self, bool enable);
        [DllImport("wx-c")]
        static extern void wxCalendarCtrl_EnableHolidayDisplay(IntPtr self, bool display);
        [DllImport("wx-c")]
        static extern void wxCalendarCtrl_SetHeaderColours(IntPtr self, IntPtr colFg, IntPtr colBg);
        [DllImport("wx-c")]
        static extern IntPtr wxCalendarCtrl_GetHeaderColourFg(IntPtr self);
        [DllImport("wx-c")]
        static extern IntPtr wxCalendarCtrl_GetHeaderColourBg(IntPtr self);
        [DllImport("wx-c")]
        static extern void wxCalendarCtrl_SetHighlightColours(IntPtr self, IntPtr colFg, IntPtr colBg);
        [DllImport("wx-c")]
        static extern IntPtr wxCalendarCtrl_GetHighlightColourFg(IntPtr self);
        [DllImport("wx-c")]
        static extern IntPtr wxCalendarCtrl_GetHighlightColourBg(IntPtr self);
        [DllImport("wx-c")]
        static extern void wxCalendarCtrl_SetHolidayColours(IntPtr self, IntPtr colFg, IntPtr colBg);
        [DllImport("wx-c")]
        static extern IntPtr wxCalendarCtrl_GetHolidayColourFg(IntPtr self);
        [DllImport("wx-c")]
        static extern IntPtr wxCalendarCtrl_GetHolidayColourBg(IntPtr self);
        [DllImport("wx-c")]
        static extern IntPtr wxCalendarCtrl_GetAttr(IntPtr self, int day);
        [DllImport("wx-c")]
        static extern void wxCalendarCtrl_SetAttr(IntPtr self, int day, IntPtr attr);
        [DllImport("wx-c")]
        static extern void wxCalendarCtrl_SetHoliday(IntPtr self, int day);
        [DllImport("wx-c")]
        static extern void wxCalendarCtrl_ResetAttr(IntPtr self, int day);
        [DllImport("wx-c")]
        static extern int wxCalendarCtrl_HitTest(IntPtr self, int x, int y, IntPtr date, ref int wd);

        //-----------------------------------------------------------------------------

        public CalendarCtrl(IntPtr wxObject)
            : base(wxObject) { }

        static IntPtr LockedCTor()
        {
            lock (DllSync)
            {
                return wxCalendarCtrl_ctor();
            }
        }

        public CalendarCtrl()
            : this(LockedCTor()) { }

        public CalendarCtrl(Window parent, int id)
            : this(parent, id, DateTime.Now, wxDefaultPosition, wxDefaultSize, wx.WindowStyles.CAL_SHOW_HOLIDAYS, "calendarCtrl") { }

        public CalendarCtrl(Window parent, int id, DateTime date)
            : this(parent, id, date, wxDefaultPosition, wxDefaultSize, wx.WindowStyles.CAL_SHOW_HOLIDAYS, "calendarCtrl") { }

        public CalendarCtrl(Window parent, int id, DateTime date, Point pos)
            : this(parent, id, date, pos, wxDefaultSize, wx.WindowStyles.CAL_SHOW_HOLIDAYS, "calendarCtrl") { }

        public CalendarCtrl(Window parent, int id, DateTime date, Point pos, Size size)
            : this(parent, id, date, pos, size, wx.WindowStyles.CAL_SHOW_HOLIDAYS, "calendarCtrl") { }

        public CalendarCtrl(Window parent, int id, DateTime date, Point pos, Size size, wx.WindowStyles style)
            : this(parent, id, date, pos, size, style, "calendarCtrl") { }

        public CalendarCtrl(Window parent, int id, DateTime date, Point pos, Size size, wx.WindowStyles style, string name)
            : this(LockedCTor())
        {
            if (!Create(parent, id, date, pos, size, style, name))
            {
                throw new InvalidOperationException("Failed to create CalendarCtrl");
            }
        }

        //-----------------------------------------------------------------------------
        // ctors with self created id

        public CalendarCtrl(Window parent)
            : this(parent, Window.UniqueID, DateTime.Now, wxDefaultPosition, wxDefaultSize, wx.WindowStyles.CAL_SHOW_HOLIDAYS, "calendarCtrl") { }

        public CalendarCtrl(Window parent, DateTime date)
            : this(parent, Window.UniqueID, date, wxDefaultPosition, wxDefaultSize, wx.WindowStyles.CAL_SHOW_HOLIDAYS, "calendarCtrl") { }

        public CalendarCtrl(Window parent, DateTime date, Point pos)
            : this(parent, Window.UniqueID, date, pos, wxDefaultSize, wx.WindowStyles.CAL_SHOW_HOLIDAYS, "calendarCtrl") { }

        public CalendarCtrl(Window parent, DateTime date, Point pos, Size size)
            : this(parent, Window.UniqueID, date, pos, size, wx.WindowStyles.CAL_SHOW_HOLIDAYS, "calendarCtrl") { }

        public CalendarCtrl(Window parent, DateTime date, Point pos, Size size, wx.WindowStyles style)
            : this(parent, Window.UniqueID, date, pos, size, style, "calendarCtrl") { }

        public CalendarCtrl(Window parent, DateTime date, Point pos, Size size, wx.WindowStyles style, string name)
            : this(parent, Window.UniqueID, date, pos, size, style, name) { }

        //-----------------------------------------------------------------------------

        public bool Create(Window parent, int id, DateTime date, Point pos, Size size, wx.WindowStyles style, string name)
        {
            wxString wxname = wxString.SafeNew(name);
            return wxCalendarCtrl_Create(wxObject, Object.SafePtr(parent), id, Object.SafePtr((wxDateTime)date), pos.X, pos.Y, size.Width, size.Height, (uint)style, Object.SafePtr(wxname));
        }

        Calendar _specialDays=null;
        /** <summary>Returns the current definition of special days and holidays if present.
         * Assigning a new calendar to this control will immediately highlight the specified special days
         * like holidays etc. So, fill the Calendar first and then assign it to the control.</summary>*/
        public Calendar SpecialDays
        {
            get { return this._specialDays; }
            set
            {
                if (!object.ReferenceEquals(this._specialDays, value))
                {
                    if (this._specialDays != null)
                    {
                        this._specialDays.UnlinkControl(this);
                        this._specialDays = null;
                    }
                    if (value != null)
                    {
                        this._specialDays = value;
                        this._specialDays.LinkToControl(this);
                    }
                }
            }
        }

        protected override void Dispose(bool disposing)
        {
            this.SpecialDays = null;
            base.Dispose(disposing);
        }

        //-----------------------------------------------------------------------------

        public class DateEventArgs
        {
            public DateTime NewDate, OldDate;
            internal DateEventArgs(DateTime newDate, DateTime oldDate)
            {
                this.NewDate = newDate;
                this.OldDate = oldDate;
            }
        }

        public delegate void DateEventHandler(CalendarCtrl sender, DateEventArgs args);

        /** <summary>This will be called on setting <c>Date</c>.
         * </summary>
         */
        public event DateEventHandler OnChangedDate;

        /** <summary>Get or set the currently selected date.
         * You may use <c>OnSetDate</c> to be informed of changing this value,</summary>*/
        public DateTime Date
        {
            set
            { 
                DateTime oldDate=new wxDateTime(wxCalendarCtrl_GetDate(wxObject));
                wxCalendarCtrl_SetDate(wxObject, Object.SafePtr((wxDateTime)value.Date));
                if (this.OnChangedDate != null)
                    this.OnChangedDate(this, new DateEventArgs(value.Date, oldDate));
            }
            get
            {
                DateTime result = new wxDateTime(wxCalendarCtrl_GetDate(wxObject));
                return result.Date;
            }
        }

        //-----------------------------------------------------------------------------

        public DateTime LowerDateLimit
        {
            set { wxCalendarCtrl_SetLowerDateLimit(wxObject, Object.SafePtr((wxDateTime)value)); }
            get { return new wxDateTime(wxCalendarCtrl_GetLowerDateLimit(wxObject)); }
        }

        public DateTime UpperDateLimit
        {
            set { wxCalendarCtrl_SetUpperDateLimit(wxObject, Object.SafePtr((wxDateTime)value)); }
            get { return new wxDateTime(wxCalendarCtrl_GetUpperDateLimit(wxObject)); }
        }

        //-----------------------------------------------------------------------------

        public bool SetDateRange(DateTime lowerdate, DateTime upperdate)
        {
            return wxCalendarCtrl_SetDateRange(wxObject, Object.SafePtr((wxDateTime)lowerdate), Object.SafePtr((wxDateTime)upperdate));
        }

        //-----------------------------------------------------------------------------

        public bool EnableYearChange
        {
            set { wxCalendarCtrl_EnableYearChange(wxObject, value); }
        }

        public bool EnableMonthChange
        {
            set { wxCalendarCtrl_EnableMonthChange(wxObject, value); }
        }

        public bool EnableHolidayDisplay
        {
            set { wxCalendarCtrl_EnableHolidayDisplay(wxObject, value); }
        }

        //-----------------------------------------------------------------------------

        public void SetHeaderColours(Colour colFg, Colour colBg)
        {
            wxCalendarCtrl_SetHeaderColours(wxObject, Object.SafePtr(colFg), Object.SafePtr(colBg));
        }

        public Colour HeaderColourFg
        {
            get { return new Colour(wxCalendarCtrl_GetHeaderColourFg(wxObject), true); }
        }

        public Colour HeaderColourBg
        {
            get { return new Colour(wxCalendarCtrl_GetHeaderColourBg(wxObject), true); }
        }

        //-----------------------------------------------------------------------------

        public void SetHighlightColours(Colour colFg, Colour colBg)
        {
            wxCalendarCtrl_SetHighlightColours(wxObject, Object.SafePtr(colFg), Object.SafePtr(colBg));
        }

        public Colour HighlightColourFg
        {
            get { return new Colour(wxCalendarCtrl_GetHighlightColourFg(wxObject)); }
        }

        public Colour HighlightColourBg
        {
            get { return new Colour(wxCalendarCtrl_GetHighlightColourBg(wxObject)); }
        }

        //-----------------------------------------------------------------------------

        public void SetHolidayColours(Colour colFg, Colour colBg)
        {
            wxCalendarCtrl_SetHolidayColours(wxObject, Object.SafePtr(colFg), Object.SafePtr(colBg));
        }

        public Colour HolidayColourFg
        {
            get { return new Colour(wxCalendarCtrl_GetHolidayColourFg(wxObject)); }
        }

        public Colour HolidayColourBg
        {
            get { return new Colour(wxCalendarCtrl_GetHolidayColourBg(wxObject)); }
        }

        //-----------------------------------------------------------------------------

        /** <summary>Gets the attributes of the provided day in month (1..31).</summary>*/
        public CalendarDateAttr GetAttr(int day)
        {
            return (CalendarDateAttr)Object.FindObject(wxCalendarCtrl_GetAttr(wxObject, day), typeof(CalendarDateAttr));
        }

        /** <summary>Sets the attributes of the provided day in month (1..31).</summary>*/
        public void SetAttr(int day, CalendarDateAttr attr)
        {
            attr = new CalendarDateAttr(attr);
            attr=attr.SwitchedToMemoryNotOwned();
            wxCalendarCtrl_SetAttr(wxObject, day, Object.SafePtr(attr));
        }

        //-----------------------------------------------------------------------------

        /** <summary>Declares the designated day in month (1..31) to be a holiday.</summary>*/
        public void SetHoliday(int day)
        {
            wxCalendarCtrl_SetHoliday(wxObject, day);
        }

        //-----------------------------------------------------------------------------

        /** <summary>Resets the attributes of the designated day in month (1..31) to be a holiday.</summary>*/
        public void ResetAttr(int day)
        {
            wxCalendarCtrl_ResetAttr(wxObject, day);
        }

        //-----------------------------------------------------------------------------

        public CalendarHitTestResult HitTest(Point pos, ref DateTime date, ref DayOfWeek wd)
        {
            wxDateTime dt = date;
            int iwd = 0;
            CalendarHitTestResult res = (CalendarHitTestResult)wxCalendarCtrl_HitTest(wxObject, pos.X, pos.Y, Object.SafePtr(dt), ref iwd);
            date = dt;
            wd = wxDateTime.FromWxWeekDay(iwd);

            return res;
        }
        public CalendarHitTestResult HitTest(Point pos, ref DateTime date)
        {
            int iwd = 0;
            wxDateTime dt = date;
            CalendarHitTestResult res = (CalendarHitTestResult)wxCalendarCtrl_HitTest(wxObject, pos.X, pos.Y, Object.SafePtr(dt), ref iwd);
            date = dt;

            return res;
        }
        public CalendarHitTestResult HitTest(Point pos)
        {
            int iwd = 0;
            CalendarHitTestResult res = (CalendarHitTestResult)wxCalendarCtrl_HitTest(wxObject, pos.X, pos.Y, IntPtr.Zero, ref iwd);
            return res;
        }

        //-----------------------------------------------------------------------------

        public event EventListener SelectionChange
        {
            add { AddCommandListener(Event.wxEVT_CALENDAR_SEL_CHANGED, ID, value, this); }
            remove { RemoveHandler(value, this); }
        }

        public event EventListener DayChange
        {
            add { AddCommandListener(Event.wxEVT_CALENDAR_DAY_CHANGED, ID, value, this); }
            remove { RemoveHandler(value, this); }
        }

        public event EventListener MonthChange
        {
            add { AddCommandListener(Event.wxEVT_CALENDAR_MONTH_CHANGED, ID, value, this); }
            remove { RemoveHandler(value, this); }
        }

        public event EventListener YearChange
        {
            add { AddCommandListener(Event.wxEVT_CALENDAR_YEAR_CHANGED, ID, value, this); }
            remove { RemoveHandler(value, this); }
        }

        public event EventListener DoubleClick
        {
            add { AddCommandListener(Event.wxEVT_CALENDAR_DOUBLECLICKED, ID, value, this); }
            remove { RemoveHandler(value, this); }
        }

        public event EventListener WeekdayClick
        {
            add { AddCommandListener(Event.wxEVT_CALENDAR_WEEKDAY_CLICKED, ID, value, this); }
            remove { RemoveHandler(value, this); }
        }
    }

    /** <summary>Defines the manner that particular days will be presented in CalendarCtrl.</summary>*/
    public class CalendarDateAttr : Object, ICloneable
    {
        [DllImport("wx-c")]
        static extern IntPtr wxCalendarDateAttr_ctor();
        [DllImport("wx-c")]
        static extern IntPtr wxCalendarDateAttr_ctor2(IntPtr colText, IntPtr colBack, IntPtr colBorder, IntPtr font, int border);
        [DllImport("wx-c")]
        static extern IntPtr wxCalendarDateAttr_ctor3(int border, IntPtr colBorder);
        [DllImport("wx-c")]
        static extern void wxCalendarDateAttr_dtor(IntPtr self);
        [DllImport("wx-c")]
        static extern void wxCalendarDateAttr_SetTextColour(IntPtr self, IntPtr colText);
        [DllImport("wx-c")]
        static extern void wxCalendarDateAttr_SetBackgroundColour(IntPtr self, IntPtr colBack);
        [DllImport("wx-c")]
        static extern void wxCalendarDateAttr_SetBorderColour(IntPtr self, IntPtr col);
        [DllImport("wx-c")]
        static extern void wxCalendarDateAttr_SetFont(IntPtr self, IntPtr font);
        [DllImport("wx-c")]
        static extern void wxCalendarDateAttr_SetBorder(IntPtr self, int border);
        [DllImport("wx-c")]
        static extern void wxCalendarDateAttr_SetHoliday(IntPtr self, bool holiday);
        [DllImport("wx-c")][return:MarshalAs(UnmanagedType.U1)]
        static extern bool wxCalendarDateAttr_HasTextColour(IntPtr self);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxCalendarDateAttr_HasBackgroundColour(IntPtr self);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxCalendarDateAttr_HasBorderColour(IntPtr self);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxCalendarDateAttr_HasFont(IntPtr self);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxCalendarDateAttr_HasBorder(IntPtr self);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxCalendarDateAttr_IsHoliday(IntPtr self);
        [DllImport("wx-c")]
        static extern IntPtr wxCalendarDateAttr_GetTextColour(IntPtr self);
        [DllImport("wx-c")]
        static extern IntPtr wxCalendarDateAttr_GetBackgroundColour(IntPtr self);
        [DllImport("wx-c")]
        static extern IntPtr wxCalendarDateAttr_GetBorderColour(IntPtr self);
        [DllImport("wx-c")]
        static extern IntPtr wxCalendarDateAttr_GetFont(IntPtr self);
        [DllImport("wx-c")]
        static extern int wxCalendarDateAttr_GetBorder(IntPtr self);

        //-----------------------------------------------------------------------------

        public CalendarDateAttr(IntPtr wxObject)
            : base(wxObject)
        {
            this.wxObject = wxObject;
        }

        internal CalendarDateAttr(IntPtr wxObject, bool memOwn)
            : base(wxObject)
        {
            this.memOwn = memOwn;
            this.wxObject = wxObject;
        }

        static IntPtr LockedCTor()
        {
            lock (DllSync)
            {
                return wxCalendarDateAttr_ctor();
            }
        }

        public CalendarDateAttr()
            : this(LockedCTor(), true)
        {
        }

        internal CalendarDateAttr SwitchedToMemoryNotOwned()
        {
            CalendarDateAttr result = this;
            if (!result.memOwn)
                result = new CalendarDateAttr(this);
            result.memOwn = false;
            result.virtual_Dispose = null;
            return result;
        }

        static IntPtr LockedCTor2(Colour colText, Colour colBack, Colour colBorder, Font font, CalendarDateBorder border)
        {
            lock (DllSync)
            {
                return wxCalendarDateAttr_ctor2(Object.SafePtr(colText), Object.SafePtr(colBack), Object.SafePtr(colBorder), Object.SafePtr(font), (int)border);
            }
        }

        public CalendarDateAttr(Colour colText, Colour colBack, Colour colBorder, Font font, CalendarDateBorder border)
            : base(LockedCTor2(colText, colBack, colBorder, font, border)) { }

        static IntPtr LockedCTor3(CalendarDateBorder border, Colour colBorder)
        {
            lock (DllSync)
            {
                return wxCalendarDateAttr_ctor3((int)border, Object.SafePtr(colBorder));
            }
        }

        public  CalendarDateAttr(CalendarDateBorder border, Colour colBorder)
            : base(LockedCTor3(border, colBorder)) { }

        public CalendarDateAttr(CalendarDateAttr src)
            : this()
        {
            this.TextColour = src.TextColour;
            this.BackgroundColour = src.BackgroundColour;
            this.Border = src.Border;
            this.BorderColour = src.BorderColour;
            this.Font = src.Font;
            this.IsHoliday = src.IsHoliday;
        }

        //---------------------------------------------------------------------

        protected override void CallDTor()
        {
            wxCalendarDateAttr_dtor(wxObject);
        }

        //---------------------------------------------------------------------

        ~CalendarDateAttr()
        {
            Dispose();
        }

        //-----------------------------------------------------------------------------

        public Colour TextColour
        {
            set { wxCalendarDateAttr_SetTextColour(wxObject, Object.SafePtr(value)); }
            get { return new Colour(wxCalendarDateAttr_GetTextColour(wxObject)); }
        }

        //-----------------------------------------------------------------------------

        public Colour BackgroundColour
        {
            set { wxCalendarDateAttr_SetBackgroundColour(wxObject, Object.SafePtr(value)); }
            get { return new Colour(wxCalendarDateAttr_GetBackgroundColour(wxObject)); }
        }

        //-----------------------------------------------------------------------------

        public Colour BorderColour
        {
            set { wxCalendarDateAttr_SetBorderColour(wxObject, Object.SafePtr(value)); }
            get { return new Colour(wxCalendarDateAttr_GetBorderColour(wxObject)); }
        }

        //-----------------------------------------------------------------------------

        public Font Font
        {
            set { wxCalendarDateAttr_SetFont(wxObject, Object.SafePtr(value)); }
            get { return new Font(wxCalendarDateAttr_GetFont(wxObject)); }
        }

        //-----------------------------------------------------------------------------

        public CalendarDateBorder Border
        {
            set { wxCalendarDateAttr_SetBorder(wxObject, (int)value); }
            get { return (CalendarDateBorder)wxCalendarDateAttr_GetBorder(wxObject); }
        }

        //-----------------------------------------------------------------------------

        public bool IsHoliday
        {
            set { wxCalendarDateAttr_SetHoliday(wxObject, value); }
            get { return wxCalendarDateAttr_IsHoliday(wxObject); }
        }

        //-----------------------------------------------------------------------------

        public bool HasTextColour
        {
            get { return wxCalendarDateAttr_HasTextColour(wxObject); }
        }

        public bool HasBackgroundColour
        {
            get { return wxCalendarDateAttr_HasBackgroundColour(wxObject); }
        }

        public bool HasBorderColour
        {
            get { return wxCalendarDateAttr_HasBorderColour(wxObject); }
        }

        public bool HasFont
        {
            get { return wxCalendarDateAttr_HasFont(wxObject); }
        }

        public bool HasBorder
        {
            get { return wxCalendarDateAttr_HasBorder(wxObject); }
        }

        //-----------------------------------------------------------------------------

        #region ICloneable Member

        public object Clone()
        {
            throw new Exception("The method or operation is not implemented.");
        }

        #endregion
    }

    /** <summary>The wx.CalendarEvent class is used together with wx.CalendarCtrl.
     * \image html calendar.png "The improved calender control."</summary>*/
    public class CalendarEvent : DateEvent
    {
        #region C API
        [DllImport("wx-c")]
        static extern IntPtr wxCalendarEvent_ctor();
        #endregion

        #region CTor
        public CalendarEvent(IntPtr wxObject)
            : base(wxObject) { }

        static IntPtr LockedCTor()
        {
            lock (DllSync)
            {
                return wxCalendarEvent_ctor();
            }
        }

        public CalendarEvent()
            : this(LockedCTor()) { }
        #endregion
    }
}

