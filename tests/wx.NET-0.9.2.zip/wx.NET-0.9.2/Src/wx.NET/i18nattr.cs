/**
 * wx.NET Project
 * 
 * \file 
 * 
 * Attributes allowing for translations in attributes.
 * 
 * Written by Dr. Harald Meyer auf'm Hofe (C) 2008 
 * Licensed under the wxWidgets license, see LICENSE.txt for details.
 *
 * $Id: i18nattr.cs,v 1.6 2010/06/28 16:30:44 harald_meyer Exp $
 */

using System;
using System.Collections.Generic;

/** \page globalization I18N in wx.NET 
 * 
 * As \e wxWidgets, \e wx.NET uses the GNU GetText standard to provide translations for text strings in
 * the source code. Use wx.Object._() or wx.Object.__() to mark text strings for translations. Method
 * wx.Object._() will return a translation.
 * \code
 * string result__ = wx.Object.__("A text string that shall be translated.");
 * // result__ is "A text string that shall be translated.".
 * string result_ = wx.Object._("A text string that shall be translated.");
 * // result_ is the translation of "A text string that shall be translated.".
 * \endcode
 * Use <c>xgettext</c> to extract strings to be translated directly from the source code.
 * \verbatim
 * xgettext -o aPotFile.pot -k_ -k__ -C aSourceFile.cs aSecondSourceFile.cs ...
 * \endverbatim
 * Then, you may use text editors or <c>poEdit</c> to type in translations.
 * 
 * Additionally, \e wx.NET offers additional capabilites to attach translations to enumeration
 * values and classes using EnumValueTranslationsAttribute or TypeNameTranslationsAttribute respectively.
 * You can use these attributes to provide translations directly in the code. Translations provided 
 * by these attributes will also be returned by wx.Object._().
 * 
 * What is the motivation for providing translations to classes and enumeration values?
 * Well, the purpose of many object-oriented system is to represent a small portion of the
 * real world as program code in such a way, that classes or enumeration values refer directly
 * to an entity of the real world - software engineers call something like this cohesion. In such systems, a way to provide
 * human readable names for cohesive portions of code - and humans read things in many different languages.
 * \code
 * [TypeNameTranslationsAttribute("human", "de", "Mensch")]
 * public class Human
 * {
 *    ...
 *    public string Name { get; }
 * }
 * 
 * [TypeNameTranslationsAttribute("driver", "de", "Fahrer")]
 * public class Driver : Human
 * {
 *    ...
 * }
 * \endcode
 * 
 * [TypeNameTranslationsAttribute("car", "de", "Auto")]
 * public class Car
 * {
 *    ...
 *    
 *    public Driver TheDriver { get; }
 *    
 *    public override string ToString() { return _("A {0} drives this {1}.", _(this.Driver.GetType()), _(this.GetType())); } 
 * }
 * \endcode
 * Calling <c>ToString()</c> of a car will return something like this in the US or  Britain:
 * \code
 * A driver drives this car.
 * \endcode
 * In Germany, the print out will look like the following (if the program does not load additional translations
 * from a MO repository):
 * \code
 * A Fahrer drives this Auto.
 * \endcode
 * 
 * Thus, you can have translation of class names and enumeration values in the code and translations of string constants
 * in MO archives created by GNU GetText tools. GetText has the advantage that this tool allows the provision of translations
 * independently from the program code. Specialist can be employed to translate texts.
 * 
 * As a consequence, this namespace provides class ExtractTranslationsOfTypesAndEnumValues to produce
 * GetText POT files to translate class names and enumeration values. This class is used by
 * <c>getwxtext</c>. 
 * The following line in the command shell
 * \verbatim
 * > getwxtext Assembly.dll
 * \endverbatim
 * will produce a file <c>Assembly.pot</c> containing Gettext entries for any class name or enumeration value
 * that has been marked by a EnumValueTranslationsAttribute or TypeNameTranslationsAttribute.
 */

/** This namespace provides some infrastructure for adding human readable names to classes, enumerations etc.
 * Refer to \ref globalization.
 */
namespace wx.Globalization
{
    /** <summary>This class represent a normalized name of a culture like de-DE or en-GB.
     * The name is composed of at most three components: Language, country, and special.
     *</summary>*/
    public class CultureName : System.IComparable
    {
        #region State
        string _lang;
        string _country;
        string _special;
        #endregion 

        #region CTor
        static string CanonicalNameFromLanguage(Language lang)
        {
            LanguageInfo info=Locale.GetLanguageInfo(lang);
            if (info == null)
            {
                if (lang == Locale.SystemLanguage)
                    return "en";
                else
                    return CanonicalNameFromLanguage(Locale.SystemLanguage);
            }
            else
                return info.CanonicalName;
        }

        public CultureName(Language lang)
            : this(CanonicalNameFromLanguage(lang))
        {
        }

        public CultureName(LanguageInfo lang)
            : this(lang.CanonicalName)
        {
        }

        public CultureName(string lang)
            : this(lang, "", "")
        {
            string[] splits = lang.Split('_', '-');
            if (splits != null && splits.Length > 0)
            {
                this._lang = splits[0];
                if (splits.Length > 1)
                    this._country = splits[1];
                if (splits.Length > 2)
                    this._country = splits[2];
            }
        }
        public CultureName(string lang, string country)
            : this(lang, country, "")
        {
        }
        /** <summary>A culture name specifying all three levels.
         * \param lang defines the language in canonical form, e.g. "en" or "de".
         * \param country define the country like "GB" or "US". Use "" as indifferent input.
         * \param special is another additional specifiyer. Use "" as indifferent input.</summary>*/
        public CultureName(string lang, string country, string special)
        {
            this._lang = lang.Trim().ToLower();
            this._country = country.Trim().ToUpper();
            this._special = special.Trim();
        }

        /** <summary>Creates an instance from a canonical name like "de-DE" or "de_DE".</summary>*/
        public static CultureName FromString(string canonicalName)
        {
            string country="";
            string special="";
            string[] splits = canonicalName.Split('_', '-');
            if (splits.Length > 3)
                throw new System.ArgumentException(Object._("A CultureName can only composed of at most three components."));
            string lang=splits[0];
            if (splits.Length > 1)
                country = splits[1];
            if (splits.Length > 2)
                special = splits[2];
            return new CultureName(lang, country, special);
        }
        #endregion

        #region IComparable Member
        public int CompareTo(object obj)
        {
            CultureName arg=(CultureName) obj;
            int cmp = 0;
            if (cmp == 0)
                cmp = this._lang.CompareTo(arg._lang);
            if (cmp == 0)
                cmp = this._country.CompareTo(arg._country);
            if (cmp == 0)
                cmp = this._special.CompareTo(arg._special);
            return cmp;
        }

        #endregion

        #region Public Methods
        public override string ToString()
        {
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            sb.Append(this._lang);
            if (this._country.Length > 0)
                sb.AppendFormat("-{0}", this._country);
            if (this._special.Length > 0)
                sb.AppendFormat("-{0}", this._special);
            return sb.ToString();
        }

        public override int GetHashCode()
        {
            return this._lang.GetHashCode() ^ this._country.GetHashCode() ^ this._special.GetHashCode();
        }

        public override bool Equals(object obj)
        {
            if (obj is CultureName)
                return this.CompareTo(obj) == 0;
            else
                return false;
        }

        public static bool operator ==(CultureName c1, CultureName c2)
        {
            if (c1 == null || c2 == null)
                return c1 == null && c2 == null;
            else
                return c1.Equals(c2);
        }

        public static bool operator !=(CultureName c1, CultureName c2)
        {
            return !(c1 == c2);
        }
        #endregion

        #region Public Properties
        public string Lang { get { return this._lang; } }
        public bool HasCountry { get { return this._country.Length > 0; } }
        public string Country { get { return this._country; } }
        public bool HasSpecial { get { return this._special.Length > 0; } }
        public string Special { get { return this._special; } }
        #endregion
    }

    /** <summary>An interface for entities allwoing to translate a string.</summary>*/
    public interface IDictionary
    {
        /** <summary>This will return a translation for <c>original</c> in the designated <c>culture</c>.
         * </summary>
         */
        string GetTranslation(CultureName culture, string original);
    }

    /** <summary>A dictionary might hold translations into several languages.
     *</summary>
     */
    public class Dictionary : IDictionary
    {
        #region State
        System.Collections.Generic.Dictionary<CultureName, System.Collections.Generic.Dictionary<string, string> > _data
            = new System.Collections.Generic.Dictionary<CultureName, System.Collections.Generic.Dictionary<string, string> >();
        #endregion

        #region CTor
        public Dictionary()
        {
        }

        /** <summary>This is a dictionary containing translation into <c>culture</c>.
         * </summary>
         * <param name="original">provides the original that shall be translated.</param>
         * <param name="translation">is the translation into the specified culture.</param>
         * <param name="pairs"> is an optional sequence of an even number of strings. The first one is an original term, the second
         *        is the translation of the first, the third is an original term, the forth is the translation of the forth,
         *        and so on. If this is an odd number of arugments, the last string will be silently ignored.</param>
         */
        public Dictionary(CultureName culture, string original, string translation, params string[] pairs)
        {
            this.Add(culture, original, translation);
            if (pairs != null && pairs.Length > 0)
            {
                for (int i = 0; i < pairs.Length; ++i)
                {
                    string o = pairs[i];
                    ++i;
                    if (i < pairs.Length)
                    {
                        string t = pairs[i];
                        this.Add(culture, o, t);
                    }
                }
            }
        }
        #endregion

        #region Public Methods
        /** <summary>This will add <c>translation</c> as translation of <c>original</c> into <c>culture</c>.
         * This will raise an argument exception, or <c>original</c> already is translated into <c>culture</c>.
         * </summary>
         */
        public void Add(CultureName culture, string original, string translation)
        {
            if (this[culture, original] == null)
                this[culture, original] = translation;
            else
                throw new System.ArgumentException(Object._("wx.Globalization.Dictionary.Add cannot overload preexisting translation."));
        }

        /** <summary>This will add all translation of <c>alternativeTranslations</c> into this.</summary>*/
        public void AddRange(Dictionary alternativeTranslations)
        {
            foreach (System.Collections.Generic.KeyValuePair<CultureName, System.Collections.Generic.Dictionary<string, string> > pair in alternativeTranslations._data)
            {
                foreach (System.Collections.Generic.KeyValuePair<string, string> translation in pair.Value)
                    this.Add(pair.Key, translation.Key, translation.Value);
            }
        }

        /** <summary>Get or set a translation into the current (referring to <c>System.Globalization)</c> culture.</summary>*/
        public string this[string original]
        {
            get
            {
                return this.GetTranslation(original);
            }
            set
            {
                this[CultureName.FromString(System.Globalization.CultureInfo.CurrentCulture.Name), original] = value;
            }
        }

        /** <summary>Get or set a translation into the provided culture.</summary><remarks>
         * Gets a translation that is specific to the provided culture  or <c>null</c> if this translation does not exist for the specified culture.
         * Example: "reden" is "de" translation of "talk". "snacken" is a more specific translation into "de-DE-KUESTE".
         * <code>
         * this[CultureName.FromString("de"), "talk"]
         * </code>
         * will return "reden",
         * <code>
         * this[CultureName.FromString("de-DE-KUESTE"], "talk")
         * </code>
         * will return "snacken", and
         * <code>
         * this[CultureName.FromString("de-DE"), "talk"]
         * </code>
         * will return <c>null</c>.
         * </remarks>
         */
        public string this[CultureName culture, string original]
        {
            get
            {
                if (this._data.ContainsKey(culture))
                {
                    if (this._data[culture].ContainsKey(original))
                        return this._data[culture][original];
                    else
                        return null;
                }
                else
                    return null;
            }
            set
            {
                if (!this._data.ContainsKey(culture))
                    this._data[culture] = new System.Collections.Generic.Dictionary<string, string>();
                this._data[culture][original] = value;
            }
        }

        /** <summary>This will translate <c>original</c> into the current culture according to <c>System.Globalization.CultureInfo.CurrentCulture </c>.
         * </summary>
         */
        public string GetTranslation(string original)
        {
            return this.GetTranslation(CultureName.FromString(System.Globalization.CultureInfo.CurrentCulture.Name), original);
        }
        #endregion

        #region IDictionary Member
        /** <summary>Tries to translate into <c>culture</c>.
         * If special culture name component is set, try to find a translation referring to the full culture name.
         * If otherwise or not successful country name component is known, try to find a translation referring to language and culture.
         * If failed, try to find a translation into the language as named by <c>culture</c>.
         * If even this failed, return <c>null</c>.
         * </summary>
         */
        public string GetTranslation(CultureName culture, string original)
        {
            string result = this[culture, original];
            if (result != null)
                return result;
            if (culture.HasSpecial)
            {
                result = this[new CultureName(culture.Lang, culture.Country), original];
                if (result != null)
                    return result;
            }
            if (culture.HasCountry)
            {
                result = this[new CultureName(culture.Lang), original];
                if (result != null)
                    return result;
            }
            return null;
        }

        #endregion
    }

    /** <summary>Instances of this classhold translations of one string.</summary>
     */
    public class StringInCultures
    {
        #region CTor
        string _original;
        System.Collections.Generic.Dictionary<CultureName, string> _translations = new System.Collections.Generic.Dictionary<CultureName, string>();
        #endregion

        #region CTor
        /** <summary>Creates an instance comprising several translations.</summary><remarks>
         * \param original is the original string.
         * \param pairs is a sequence of an even number of strings. The first is the canonical name, the second is the
         *    translation of <c>original</c> into the locale according to the first string. The third is the canonical name, the forth is the
         *    translation of <c>original</c> into the locale according to the third string, and so on.
         * 
         * Example:
         * \code
         StringInCultures("talk", "de", "reden")
         \endcode
         * </remarks>*/
        public StringInCultures(string original, params string[] pairs)
        {
            this._original = original;
            if (pairs != null)
            {
                for (int i = 0; i < pairs.Length; ++i)
                {
                    CultureName culture = CultureName.FromString(pairs[i]);
                    ++i;
                    if (i < pairs.Length)
                    {
                        this.Add(culture, pairs[i]);
                    }
                }
            }
        }
        #endregion

        #region Public Properties
        /** <summary>Returns the translation of the original term into the provided culture if this exists and <c>null</c> otherwise.</summary>*/
        public string this[CultureName culture]
        {
            get
            {
                if (this._translations.ContainsKey(culture))
                    return this._translations[culture];
                else
                    return null;
            }
            set
            {
                this[culture] = value;
            }
        }

        /** <summary>This instance holds the default translation of this string.</summary>*/
        public string DefaultTranslation
        {
            get { return this._original; }
        }

        /** <summary>This instance holds translations into this cultures.</summary>*/
        public System.Collections.Generic.ICollection<CultureName> Cultures
        {
            get
            {
                return this._translations.Keys;
            }
        }
        #endregion

        #region Public Methods
        public void Add(CultureName culture, string translation)
        {
            this._translations.Add(culture, translation);
        }

        /** <summary>Translate into the language as specified by the provided canonical language.
         * If the original cannot be translated into the specified culture, this will try to translate into language and country
         * of culture. If this is also not possible, this will try to translate into the language of culture. If even this
         * fails, this method will return <c>null</c>.
         * </summary>
         */
        public string GetTranslation(Language lang)
        {
            return this.GetTranslation(new CultureName(lang));
        }

        /** <summary>Translate into the language as specified by the provided canonical name.
         * If the original cannot be translated into the specified culture, this will try to translate into language and country
         * of culture. If this is also not possible, this will try to translate into the language of culture. If even this
         * fails, this method will return <c>null</c>.
         * </summary>
         */
        public string GetTranslation(string canonicalName)
        {
            return this.GetTranslation(new CultureName(canonicalName));
        }

        /** <summary>This returns the translation of the original string into <c>culture</c>.
         * If the original cannot be translated into <c>culture</c>, this will try to translate into language and country
         * of culture. If this is also not possible, this will try to translate into the language of culture. If even this
         * fails, this method will return <c>null</c>.
         * </summary>
         */
        public string GetTranslation(CultureName culture)
        {
            string t = this[culture];
            if (t != null)
                return t;
            if (culture.HasSpecial)
            {
                t = this[new CultureName(culture.Lang, culture.Country)];
                if (t != null)
                    return t;
            }
            if (culture.HasCountry)
            {
                t = this[new CultureName(culture.Lang)];
                if (t != null)
                    return t;
            }
            return this.DefaultTranslation;
        }

        /** <summary>This will translate into the current culture according to <c>System.Globalization.CultureInfo.CurrentCulture</c>.
         * </summary>
         */
        public string GetTranslation()
        {
            return this.GetTranslation(CultureName.FromString(System.Globalization.CultureInfo.CurrentCulture.Name));
        }
        #endregion
    }

    /** <summary>Use this attribute to provide translations of a class or type name using reflection.
     * These names will for instance be used by <c>wx.Object._(Type)</c>.
     * </summary>
     */
    [System.AttributeUsage(System.AttributeTargets.Class|System.AttributeTargets.Enum|System.AttributeTargets.Struct)]
    public class TypeNameTranslationsAttribute : System.Attribute
    {
        #region State
        StringInCultures _name;
        #endregion

        #region CTor
        /** <summary>Argument is the name of the type in neutral representation and arbitrary translations.</summary>*/
        public TypeNameTranslationsAttribute(StringInCultures name)
        {
            this._name = name;
        }

        /** <summary>Creates an instance comprising several translations.</summary><remarks>
         * \param neutralName is the name in the neutral locale.
         * \param sequenceOfLocaleTranslationPairs is a sequence of an even number of strings. The first is the canonical name, the second is the
         *    translation of <c>original</c> into the locale according to the first string. The third is the canonical name, the forth is the
         *    translation of <c>original</c> into the locale according to the third string, and so on.
         * 
         * Example:
         * \code
         [TypeNameTranslationsAttribute("Employee", "de", "Mitarbeiter")]
         class EmployeeDate
         {
            ...
         }
         \endcode
         * </remarks>*/
        public TypeNameTranslationsAttribute(string neutralName, params string[] sequenceOfLocaleTranslationPairs)
        {
            this._name = new StringInCultures(neutralName, sequenceOfLocaleTranslationPairs);
        }
        #endregion

        #region Public Properties
        /** <summary>Readonly access to the human readable name of the class or type and its translations.</summary>*/
        public StringInCultures Name { get { return this._name; } }
        #endregion
    }

    /** <summary>Use this class to amend enumerations with translations of their value.</summary>
     * <remarks>
     * These translations will for instance be used by <c>wx.Object._(Enum)</c>.
     * Example:
     \code
     [EnumValueTranslations(80, "Times")]
     [EnumValueTranslations(81, "Sans Serif")]
     [EnumValueTranslations(90, "True Type", "de", "Schreibmaschine")]
     [EnumValueTranslations(91, "Courier", "de", "Kurier")]
     enum FontFamily
     {
        Times=80,
        SansSerif,
        TrueType=90,
        Courier,
     }
     \endcode
     * The translation refers to the enumeration using the value. This class assumes <c>int</c>
     * values.
     * </remarks>
     */
    [System.AttributeUsage(System.AttributeTargets.Enum, AllowMultiple=true)]
    public class EnumValueTranslationsAttribute : System.Attribute
    {
        #region State
        StringInCultures _name;
        int _value;
        #endregion

        #region CTor
        /** <summary>Defines a neutral name and translations for an enumeration value.</summary>
         * <param name="enumIntValue"> designates the enumeration value providing its cast to <c>int</c>. </param>
         * <param name="neutral"> is a neutral name that will be used when translating into unknown languages.</param>
         * <param name="sequenceOfLocaleTranslationPairs"> is a sequence of pairs of canonical locale names and translations.</param>
         */
        public EnumValueTranslationsAttribute(int enumIntValue, string neutral, params string[] sequenceOfLocaleTranslationPairs)
        {
            this._name = new StringInCultures(neutral, sequenceOfLocaleTranslationPairs);
            this._value = enumIntValue;
        }
        #endregion

        #region Public Properties
        /** <summary>Readonly access to the human readable name of the class or type and its translations.</summary>*/
        public StringInCultures Name { get { return this._name; } }

        public int EnumIntValue { get { return this._value; } }

        public System.Enum GetEnumValue(System.Type enumType)
        {
            System.Array enumValues = System.Enum.GetValues(enumType);
            foreach (System.Enum enumValue in enumValues)
            {
                if (System.Convert.ToInt32(enumValues) == this._value)
                {
                    return enumValue;
                }
            }
            throw new System.ArgumentException(string.Format("Cannot find value {0} in type {1}.", this._value, enumType.Name));
        }
        #endregion
    }

    /// <summary>
    /// Class to write POT entries. This class provides a text writer like interface to write 
    /// POT entries. You may create a file providing a file name to the ctor. This file will be created
    /// including a POT header in UTF-8 character coding. All internal streams will be closed on
    /// dispose.
    /// </summary>
    public class POTWriter : IDisposable
    {
        #region State
        System.IO.TextWriter _writer;
        Dictionary<string, object> _usedEntries=new Dictionary<string, object>();
        #endregion

        /// <summary>
        /// Creates an instance that will open a file of the provided name.
        /// If the extension of the provided name is neither .po nor .pot, this will
        /// add esxtension .pot.
        /// </summary>
        /// <param name="potFileName"></param>
        public POTWriter(string potFileName)
        {
            if (!potFileName.EndsWith(".po") && !potFileName.EndsWith(".pot"))
                potFileName+=".pot";
            this._writer = new System.IO.StreamWriter(potFileName, false, System.Text.Encoding.UTF8);
            this.WriteHeader();
        }

        ~POTWriter()
        {
            this.Dispose();
        }

        /// <summary>
        /// This will write the header information.
        /// </summary>
        void WriteHeader()
        {
            this._writer.WriteLine(@"msgid """);
            this._writer.WriteLine(@"msgstr """);
            this._writer.WriteLine("\"Last-Translator: {0}\\n\"", System.Environment.UserName);
            this._writer.WriteLine("\"MIME-Version: 1.0\\n\"");
            this._writer.WriteLine("\"Content-Type: text/plain; charset=utf-8\\n\"");
            this._writer.WriteLine("\"Content-Transfer-Encoding: 8bit\\n\"");
            this._writer.WriteLine("\"X-Poedit-SourceCharset: utf-8\\n\"");
            this._writer.WriteLine("\"Report-Msgid-Bugs-To: \\n\"");
            this._writer.WriteLine("\"POT-Creation-Date: {0:YYYY-MM-DD hh:mm}+0000\\n\"", DateTime.Now.ToUniversalTime());
            this._writer.WriteLine("\"PO-Revision-Date: YEAR-MO-DA HO:MI+ZONE\\n\"");
            this._writer.WriteLine("\"MIME-Version: 1.0\\n\"");
            this._writer.WriteLine("\"Content-Type: text/plain; charset=UTF-8\\n\"");
            this._writer.WriteLine("\"Content-Transfer-Encoding: 8bit\\n\"");
            this._writer.Flush();
        }

        /// <summary>
        /// Creates a new entry. If the provided key has already been used, this will return false.
        /// </summary>
        /// <param name="key">The key that will be used to identify the translation.</param>
        /// <param name="translation">The translation.</param>
        /// <param name="remark">An optional remark (use empty string if not needed). Provide a text that
        /// can help translator. This text will be visible in poEdit.</param>
        /// <returns></returns>
        public bool WriteEntry(string key, string translation, string remark)
        {
            if (this._usedEntries.ContainsKey(key))
            {
                System.Diagnostics.Trace.WriteLine(key, "POTWriter already added this key");
                System.Diagnostics.Trace.WriteLine(translation, "POTWriter will skip this translation");
                return false;
            }
            else
            {
                this._usedEntries.Add(key, translation);
                this._writer.WriteLine();
                this._writer.WriteLine("# {0}", remark.Replace("\n", "\n #"));
                this._writer.WriteLine("#, fuzzy");
                this._writer.WriteLine("msgid \"{0}\"", key.Replace("\"", "\\\""));
                this._writer.WriteLine("msgstr \"{0}\"", translation.Replace("\"", "\\\""));
                this._writer.Flush();
                return true;
            }
        }

        public void Close()
        {
            if (this._writer != null)
            {
                try
                {
                    this._writer.Close();
                }
                catch
                {
                }
                this._writer = null;
            }
        }

        #region IDisposable Member

        public void Dispose()
        {
            this.Close();
        }

        #endregion
    }


    /// <summary>
    /// Looks for the attributes EnumValueTranslationsAttribute in TypeNameTranslationsAttribute in one
    /// or more assemblies and creates GetText entries in a POTWriter that can be used to provide translations
    /// for marked classes and enumeration constants.
    /// </summary>
    public class ExtractTranslationsOfTypesAndEnumValues
    {
        public ExtractTranslationsOfTypesAndEnumValues()
        {
        }

        public void ExtractTranslationsOfType(POTWriter writer, System.Reflection.Assembly a)
        {
            Type[] types=a.GetTypes();
            foreach (Type t in types)
            {
                Dictionary<int, EnumValueTranslationsAttribute> enumTranslations=new Dictionary<int,EnumValueTranslationsAttribute>();

                object[] attributes=t.GetCustomAttributes(false);
                foreach (object attribute in attributes)
                {
                    EnumValueTranslationsAttribute enumTranslation = attribute as EnumValueTranslationsAttribute;
                    TypeNameTranslationsAttribute typeTranslations = attribute as TypeNameTranslationsAttribute;

                    if (typeTranslations != null)
                    {
                        string key = t.Namespace + "." + t.Name;
                        string translation = typeTranslations.Name.DefaultTranslation;
                        System.Text.StringBuilder comment = new System.Text.StringBuilder();
                        comment.AppendFormat("Translation of type {0}.{1} in assembly {2} extracted on {3}.", 
                            t.Namespace, t.Name, a.FullName, DateTime.Now);
                        writer.WriteEntry(key, translation, comment.ToString());
                    }
                    if (enumTranslation != null)
                        enumTranslations[enumTranslation.EnumIntValue]=enumTranslation;
                }
                if (t.IsEnum && enumTranslations.Count > 0)
                {
                    string typekey = t.Namespace + "." + t.Name;
                    foreach (Enum enumConst in Enum.GetValues(t))
                    {
                        string key = typekey + "." + enumConst.ToString();
                        string value = enumConst.ToString();
                        int intConst = Convert.ToInt32(enumConst);
                        if (enumTranslations.ContainsKey(intConst))
                        {
                            EnumValueTranslationsAttribute translation = enumTranslations[intConst];
                            value = translation.Name.DefaultTranslation;
                        }
                        System.Text.StringBuilder comment = new System.Text.StringBuilder();
                        comment.AppendFormat("Translation of enumeration value {0} of enumeration {1} in assembly {2} extracted on {3}.",
                            enumConst, typekey, a.FullName, DateTime.Now);
                        writer.WriteEntry(key, value, comment.ToString());
                    }
                }
            }
        }

        /// <summary>
        /// This method will create a POT file using the base name of the code base file of the assembly.
        /// Thus, translations of wx.PackageBuilder.exe will be stored in ex.PackageBuilder.pot.
        /// </summary>
        /// <param name="a"></param>
        public void ExtractTranslationsOfType(System.Reflection.Assembly a)
        {
            Uri codeBase = new Uri(a.CodeBase);
            string potPath = System.IO.Path.ChangeExtension(codeBase.LocalPath, ".pot");
            using (POTWriter writer = new POTWriter(potPath))
            {
                this.ExtractTranslationsOfType(writer, a);
            }
        }
    }
}