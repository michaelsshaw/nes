//-----------------------------------------------------------------------------
// wx.NET - Config.cs
//
// The wxConfig wrapper class.
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: Config.cs,v 1.22 2010/02/13 17:23:52 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Drawing;
using System.Runtime.InteropServices;

namespace wx
{
    /** <summary>Style flags for the wx.Config class.
     * </summary>
     */
    [Flags]
    public enum ConfigStyle
    {
        /** <summary>This will read and store the configuration from and to the default location.
         * If  wxWidgets has been compiled with <c>wxUSE_CONFIG_NATIVE</c>, this is usually
         * the registry (using <c>wxRegConfig</c>).</summary>
         */
        USE_DEFAULT_STYLE =0,
        /// <summary>
        /// Use this to use a local file (within the home of the user) rather than a global file or HKCU rather than HKLM 
        /// in the registry base of Windows. This may be specified in conjunction with USE_GLOBAL_FILE. In that case,
        /// the configuration class will search for locally defined values first and consider the global file or HKLM if
        /// the local configuration does not define the value.
        /// </summary>
        USE_LOCAL_FILE=1,
        /// <summary>
        /// Use this to use a global file rather than a local file (within the home of the user) or HKLM rather than HKCU 
        /// in the registry base of Windows. This may be specified in conjunction with USE_LOCAL_FILE. In that case,
        /// the configuration class will search for locally defined values first and consider the global file or HKLM if
        /// the local configuration does not define the value. However, the configuration will always be saved locally.
        /// This implementation does not provide any means to write global configurations.
        /// </summary>
        USE_GLOBAL_FILE=2,
        /** <summary>Only relevant if using a file for reading/writing the configuration.
         * </summary>
         */
        USE_RELATIVE_PATH=4,
        /** <summary>This will turn off character escaping for the values of entries stored in the config file.
         * For example a foo key with some backslash characters will be stored as <c>foo=C:\mydir</c> instead
         * of the usual storage of <c>foo=C:\\mydir</c>. For <c>wxRegConfig</c>, this flag refers to HKLM,
         * and provides read-only access.
         * The <c>USE_NO_ESCAPE_CHARACTERS</c> style can be helpful if your config file must be read or
         * written to by a non-wxWidgets program (which might not understand the escape characters).
         * Note, however, that if <c>USE_NO_ESCAPE_CHARACTERS</c> style is used, it is is now your
         * application's responsibility to ensure that there is no newline or other illegal
         * characters in a value, before writing that value to the file.
         * </summary>
         */
        USE_NO_ESCAPE_CHARACTERS =8,

    }

    /** <summary>Service class that implements serialization of colours and fonts into XML.</summary><remarks>
     * Create an instance encapsulating a font or a colour to serialize or call ReadXml()
     * to deserialize. Example:
     * \code
     // This writes a font before writing a colour into an xmlWriter.
     XmlSerializer serializer=new XmlSerializer(font);
     serializer.WriteXml(xmlWriter);
     serializer.Colour=colour;
     serializer.WriteXml(xmlWriter);
     
     // this reads a colour after a font from an xmlReader.
     serializer.ReadXml(xmlReader);
     font=serializer.Font;
     serializer.ReadXml(xmlReader);
     colour=serializer.Colour;
     \endcode
     * </remarks>*/
    public class XmlSerializer : System.Xml.Serialization.IXmlSerializable
    {
        #region State
        object _data = null;
        #endregion

        #region CTor
        /** <summary>Creates an instance without data.
         * Serialization will be a NOP.</summary>*/
        public XmlSerializer()
        {
        }

        /** <summary>Creates an instance referring to a font for serialization.</summary>*/
        public XmlSerializer(Font font)
        {
            this._data = font;
        }

        /** <summary>Creates an instance referring to a colour for serialization.</summary>*/
        public XmlSerializer(Colour colour)
        {
            this._data = colour;
        }
        #endregion

        #region Properties
        /** <summary>Gets or sets a font as data.
         * Use this property to retrieve a font that has been read by ReadXml()
         * or to set a font to be written by WriteXml().</summary>*/
        public Font Font
        {
            get { return this._data as Font; }
            set { this._data = value; }
        }

        /** <summary>Gets or sets a colour as data.
         * Use this property to retrieve a Colour that has been read by ReadXml()
         * or to set a font to be written by WriteXml().</summary>*/
        public Colour Colour
        {
            get { return this._data as Colour; }
            set { this._data = value; }
        }
        #endregion

        #region IXmlSerializable Member
        /** <summary>Not yet implemented.</summary>*/
        public System.Xml.Schema.XmlSchema GetSchema()
        {
            throw new Exception("The method or operation is not implemented.");
        }

        /** <summary>This will either read a colour or a font from <c>reader</c> and provide the result as <c>Colour</c> or <c>Font</c>.
         * If <c>reader</c> does not provide an appropriate serialization, then <c>Colour</c> and <c>Font</c> will be <c>null</c>.
         * </summary>
         */
        public void ReadXml(System.Xml.XmlReader reader)
        {
            if (reader.IsStartElement("colour"))
            {
                string redString = reader.GetAttribute("red");
                string greenString = reader.GetAttribute("green");
                string blueString = reader.GetAttribute("blue");
                reader.ReadStartElement();
                this._data=new Colour(Convert.ToByte(redString), Convert.ToByte(greenString), Convert.ToByte(blueString));
            }
            else if (reader.IsStartElement("font"))
            {
                this._data=new Font();
                string attr = reader.GetAttribute("pointsize");
                if (attr != null)
                    this.Font.PointSize = Convert.ToInt32(attr);
                attr = reader.GetAttribute("family");
                if (attr != null)
                    this.Font.Family = (FontFamily)Enum.Parse(typeof(FontFamily), attr);
                attr = reader.GetAttribute("style");
                if (attr != null)
                    this.Font.Style = (FontStyle)Enum.Parse(typeof(FontStyle), attr);
                attr = reader.GetAttribute("weight");
                if (attr != null)
                    this.Font.Weight = (FontWeight)Enum.Parse(typeof(FontWeight), attr);
                attr=reader.GetAttribute("underline");
                if (attr != null && Convert.ToInt32(attr) > 0)
                    this.Font.Underlined=true;
                else
                    this.Font.Underlined=false;
                attr=reader.GetAttribute("facename");
                if (attr != null)
                    this.Font.FaceName=attr;
                attr = reader.GetAttribute("encoding");
                if (attr != null)
                    this.Font.Encoding = (FontEncoding)Enum.Parse(typeof(FontEncoding), attr);
                reader.ReadStartElement();
            }
            else
            {
                this._data = null;
            }
        }


        /** <summary>Writes the data to <c>writer</c>.
         * The data may either be a colour or a font that has been set by the CTor
         * or assignment to an appropriate property. Data <c>null</c> will cause this to be
         * a NOP.
         * </summary>
         */
        public void WriteXml(System.Xml.XmlWriter writer)
        {
            if (this._data != null)
            {
                if (this._data is Colour)
                {
                    writer.WriteStartElement("colour");
                    writer.WriteAttributeString("red", this.Colour.Red.ToString());
                    writer.WriteAttributeString("green", this.Colour.Green.ToString());
                    writer.WriteAttributeString("blue", this.Colour.Blue.ToString());
                    writer.WriteEndElement();
                }
                else if (this._data is Font)
                {
                    writer.WriteStartElement("font");
                    writer.WriteAttributeString("pointsize", this.Font.PointSize.ToString());
                    writer.WriteAttributeString("family", this.Font.Family.ToString());
                    writer.WriteAttributeString("style", this.Font.Style.ToString());
                    writer.WriteAttributeString("weight", this.Font.Weight.ToString());
                    writer.WriteAttributeString("underline", this.Font.Underlined ? "1" : "0");
                    writer.WriteAttributeString("facename", this.Font.FaceName);
                    writer.WriteAttributeString("encoding", this.Font.Encoding.ToString());
                    writer.WriteEndElement();
                }
            }
        }

        #endregion
    }


    /** <summary>This is the class for writing and reading configuration parameters via wxWidgets <c>wxConfigBase</c> implementations.
     *
     * The idea of  wxWidgets configuration class is to provide an interface that allows
     * applications to manage configuration data without regard to the method of storing the
     * information. Configurations may either be stored in a global or local file, or into the
     * registry database. The syntax of the files is according to the good old Ini-files as
     * common to 16-Bit Windows.
     * 
     * This class only maintains (writes to) user specific configurations.
     * </summary>
     * <remarks>
     * This interface might be extended in the future to provide some additional styles that
     * implement the standard way of configuring .NET applications (XML file <c>myApp.exe.config</c> for
     * application <c>myApp.exe</c> read by class System.Configuration.Configuration).
     * 
     * Although <c>wxConfig</c> is not derived from <c>wxObject</c>, this class is derived from wx.Object since
     * the main concern of wx.Object is to manage pointers to C++ objects.
     * Use Config.Get() to get an instance.
     * 
     * The original C++ implementation uses Method <c>Read</c> with many, many signatures. Since this may lead to
     * some confusion (at least I have been confused on using this class), this class implements <c>Read</c>
     * functionality in two flavours: Returning the value or a default as method result and loading a
     * reference with the value from the configuration if this has been found. Methods of the first flavour
     * still are called <c>Read</c> whereas methods of the second flavour contain the data type as part of their name
     * like wx.Config.ReadInt(). 
     * 
     * In the past, both flavours were named simply <c>Read</c>. Hence, programmers that missed to use the small
     * C# keyword <c>ref</c> accidentally turned an intended call of flavour 2 into one of flavour 1.
     * 
     * A few things have been added to this class going beyond the functions in  wxWidgets: WriteProperties()
     * and ReadProperties() will write and read public properties and fields using reflection.
     * 
     * \b Problems:
     * There is some evidence that reading strings for non-existing keys using a default value
     * might lead to memory corruption at least in some cases.
     *</remarks>
     */
    public class Config : Object
    {
        #region Nested Types And Enumerations
        /** <summary>An enumeration representing the data type of an atomic field.
         * </summary>
         */
        public enum EntryType
        {
            Unknown,
            String,
            Boolean,
            Integer,
            Float
        }
        #endregion

        #region C API
        [DllImport("wx-c")] static extern IntPtr wxConfigBase_Set(IntPtr pConfig);
        [DllImport("wx-c")] static extern IntPtr wxConfigBase_Get(bool createOnDemand);
        [DllImport("wx-c")] static extern IntPtr wxConfigBase_Create();
        [DllImport("wx-c")] static extern IntPtr wxConfigBase_Delete(IntPtr self);
        [DllImport("wx-c")] static extern IntPtr wxConfigBase_CTor1(IntPtr appName, IntPtr vendorName, IntPtr localFilename, IntPtr globalFilename, int style);
        [DllImport("wx-c")] static extern void   wxConfigBase_DontCreateOnDemand();
        [DllImport("wx-c")] static extern void   wxConfigBase_SetPath(IntPtr self, IntPtr strPath);
        [DllImport("wx-c")] static extern IntPtr wxConfigBase_GetPath(IntPtr self);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxConfigBase_GetFirstGroup(IntPtr self, IntPtr str, ref int lIndex);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxConfigBase_GetNextGroup(IntPtr self, IntPtr str, ref int lIndex);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxConfigBase_GetFirstEntry(IntPtr self, IntPtr str, ref int lIndex);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxConfigBase_GetNextEntry(IntPtr self, IntPtr str, ref int lIndex);
        [DllImport("wx-c")] static extern int    wxConfigBase_GetNumberOfEntries(IntPtr self, bool bRecursive);
        [DllImport("wx-c")] static extern int    wxConfigBase_GetNumberOfGroups(IntPtr self, bool bRecursive);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxConfigBase_HasGroup(IntPtr self, IntPtr strName);
        [DllImport("wx-c")][return:MarshalAs(UnmanagedType.U1)]
        static extern bool   wxConfigBase_HasEntry(IntPtr self, IntPtr strName);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxConfigBase_Exists(IntPtr self, IntPtr strName);
        [DllImport("wx-c")] static extern int    wxConfigBase_GetEntryType(IntPtr self, IntPtr name);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxConfigBase_ReadStr(IntPtr self, IntPtr key, IntPtr pStr);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxConfigBase_ReadStrDef(IntPtr self, IntPtr key, IntPtr pStr, IntPtr defVal);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxConfigBase_ReadInt(IntPtr self, IntPtr key, ref int pl);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxConfigBase_ReadIntDef(IntPtr self, IntPtr key, ref int pl, int defVal);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxConfigBase_ReadDbl(IntPtr self, IntPtr key, ref double val);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxConfigBase_ReadDblDef(IntPtr self, IntPtr key, ref double val, double defVal);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxConfigBase_ReadBool(IntPtr self, IntPtr key, ref bool val);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxConfigBase_ReadBoolDef(IntPtr self, IntPtr key, ref bool val, bool defVal);
        [DllImport("wx-c")] static extern IntPtr wxConfigBase_ReadStrRet(IntPtr self, IntPtr key, IntPtr defVal);
        [DllImport("wx-c")] static extern int wxConfigBase_ReadIntRet(IntPtr self, IntPtr key, int defVal);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxConfigBase_WriteStr(IntPtr self, IntPtr key, IntPtr val);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxConfigBase_WriteInt(IntPtr self, IntPtr key, int val);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxConfigBase_WriteDbl(IntPtr self, IntPtr key, double val);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxConfigBase_WriteBool(IntPtr self, IntPtr key, bool val);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxConfigBase_Flush(IntPtr self, bool bCurrentOnly);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxConfigBase_RenameEntry(IntPtr self, IntPtr oldName, IntPtr newName);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxConfigBase_RenameGroup(IntPtr self, IntPtr oldName, IntPtr newName);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxConfigBase_DeleteEntry(IntPtr self, IntPtr key, bool bDeleteGroupIfEmpty);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxConfigBase_DeleteGroup(IntPtr self, IntPtr key);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxConfigBase_DeleteAll(IntPtr self);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxConfigBase_IsExpandingEnvVars(IntPtr self);
        [DllImport("wx-c")] static extern void   wxConfigBase_SetExpandEnvVars(IntPtr self, bool bDoIt);
        [DllImport("wx-c")] static extern IntPtr wxConfigBase_ExpandEnvVars(IntPtr self, IntPtr str);
        [DllImport("wx-c")] static extern void   wxConfigBase_SetRecordDefaults(IntPtr self, bool bDoIt);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxConfigBase_IsRecordingDefaults(IntPtr self);
        [DllImport("wx-c")] static extern IntPtr wxConfigBase_GetAppName(IntPtr self);
        [DllImport("wx-c")] static extern void wxConfigBase_SetAppName(IntPtr self, IntPtr appName);
        [DllImport("wx-c")] static extern IntPtr wxConfigBase_GetVendorName(IntPtr self);
        [DllImport("wx-c")] static extern void wxConfigBase_SetVendorName(IntPtr self, IntPtr vendorName);
        [DllImport("wx-c")] static extern void   wxConfigBase_SetStyle(IntPtr self, uint style);
        [DllImport("wx-c")] static extern uint   wxConfigBase_GetStyle(IntPtr self);
        #endregion

        #region CTor
        public Config(IntPtr wxObject)
            : base(wxObject) { }

        /** <summary>Use this CTor and call Set() to create a configuration of a particular style.</summary>
         * <param name="appName"> The application name. If this is empty, the class will normally use
         *        wx.App.GetAppName to set it. The application name is used in the registry key on
         *        Windows, and can be used to deduce the local filename parameter if that is missing.
         *        </param>
         * <param name="vendorName"> The vendor name. If this is empty, it is assumed that no vendor name is
         *        wanted, if this is optional for the current config class. The vendor name is
         *        appended to the application name for <c>wxRegConfig</c>.
         *        </param>
         * <param name="localName"> Some config classes require a local filename. If this is not
         *        present, but required, the application's name will be used instead.
         *        </param>
         * <param name="globalName"> Some config classes require a global filename. If this is not
         *        present, but required, the application's name will be used instead.
         *        </param>
         * <param name="style"> Can be one of <c>USE_LOCAL_FILE</c> and <c>USE_GLOBAL_FILE</c>. The style interpretation
         *        depends on the config class and is ignored by some. For <c>wxFileConfig</c>, these
         *        styles determine whether a local or global config file is created or used. If
         *        the flag is present but the parameter is empty, the parameter will be set to a
         *        default. If the parameter is present but the style flag not, the relevant flag
         *        will be added to the style. For wxFileConfig you can also add <c>USE_RELATIVE_PATH</c>
         *        by logically or'ing it to either of the _FILE options to tell <c>wxFileConfig</c> to
         *        use relative instead of absolute paths. For <c>wxFileConfig</c>, you can also add
         *        USE_NO_ESCAPE_CHARACTERS which will turn off character escaping for the values
         *        of entries stored in the config file.</param>
         */
        public Config(string appName, string vendorName, string localName, string globalName, ConfigStyle style)
            : this(wxString.SafeNew(appName), wxString.SafeNew(vendorName), wxString.SafeNew(localName), wxString.SafeNew(globalName), style)
        {
        }

        static IntPtr LockedCTor(wxString appName, wxString vendorName, wxString localName, wxString globalName, ConfigStyle style)
        {
            lock (DllSync)
            {
                return wxConfigBase_CTor1(Object.SafePtr(appName), Object.SafePtr(vendorName), Object.SafePtr(localName), Object.SafePtr(globalName), (int)style);
            }
        }

        public Config(wxString appName, wxString vendorName, wxString localName, wxString globalName, ConfigStyle style)
            : this(LockedCTor(appName, vendorName, localName, globalName, style))
        {
            this.memOwn = true;
        }

        protected override void CallDTor()
        {
            wxConfigBase_Delete(this.wxObject);
        }
        #endregion

        #region Singleton
        /** <summary>This method will set the argument as the current configuration returning the old instance of Config that has been the current configuration before calling this.</summary>*/
        public static Config Set(Config config)
        {
            config.memOwn = false;
            return (Config)FindObject(wxConfigBase_Set(Object.SafePtr(config)), typeof(Config));
        }

        /// <summary>
        /// Creates a new configuration using the provided style and returns the result. The new configuration
        /// will be the default instance returned by Get().
        /// </summary>
        /// <param name="style">A style describing the new instance.</param>
        /// <returns></returns>
        public static Config Set(ConfigStyle style)
        {
            Config newConfig = new Config(App.TheApp.AppName, App.TheApp.VendorName,
                App.TheApp.VendorName + "_" + App.TheApp.AppName,
                App.TheApp.VendorName + "_" + App.TheApp.AppName,
                style);
            return Set(newConfig);
        }

        /** <summary>This will get the current configuration of the application.
         * If the argument is <c>true</c>, this method will wx.Config.Create() a new configuration
         * is required.</summary>*/
        public static Config Get(bool createOnDemand)
        {
            return (Config)FindObject(wxConfigBase_Get(createOnDemand), typeof(Config));
        }
	
        /** <summary>Equivalent to wx.Config.Get(true).</summary>*/
	    public static Config Get()
        {
            return (Config)FindObject(wxConfigBase_Get(true), typeof(Config));
        }

        /** <summary>Create a new configuration according to properties of the application.
         * On Windows, the configuration will preferably recorded in the registry database
         * within the <c>HKEY_CURRENT_USER</c> section using the vendor's name and the application's name
         * to create subkeys. However, this depends on whether <c>wxUSE_CONFIG_NATIVE</c> has been defined
         * on compiling  wxWidgets or not. In most other cases, this will use a file of the application
         * name in the current working directory. Refer also to wx.App.AppName and wx.App.VendorName.</summary>*/
        public static Config Create()
        {
            return new Config(wxConfigBase_Create());
        }


        public static Config Default
        {
            get
            {
                return Get();
            }
            set
            {
                Set(value);
            }
        }
        #endregion

        #region Iterate Groups
        /// <summary>
        /// Gets the first group in the configuration.
        /// </summary>
        /// <param name="str">Will be assigned with the name of the first group.</param>
        /// <param name="lIndex">This is an identifier for the enumeration.</param>
        /// <returns>True on success.</returns>
        /// <seealso cref="GetEnumeratorOfGroups"/>
        public bool GetFirstGroup(ref string str, ref int lIndex)
        {
            bool ret;
            wxString wstr = new wxString(str);

            ret = wxConfigBase_GetFirstGroup(wxObject, wxString.SafePtr(wstr), ref lIndex);
            str = wstr;

            return ret;
        }

        /// <summary>
        /// Gets the next group in the configuration.
        /// </summary>
        /// <param name="str">Will be assigned with the name of the next group.</param>
        /// <param name="lIndex">This is an identifier for the enumeration.</param>
        /// <returns>True on success.</returns>
        /// <seealso cref="GetEnumeratorOfGroups"/>
        public bool GetNextGroup(ref string str, ref int lIndex)
        {
            bool ret;
            wxString wstr = new wxString(str);

            ret = wxConfigBase_GetNextGroup(wxObject, wxString.SafePtr(wstr), ref lIndex);
            str = wstr;

            return ret;
        }

        class GroupEnumerator : System.Collections.Generic.IEnumerator<string>, System.Collections.Generic.IEnumerable<string>
        {
            int _index = 0;
            string _current = null;
            Config _config;

            public GroupEnumerator(Config c)
            {
                this._config = c;
            }

            #region IEnumerator<string> Member
            public string Current
            {
                get { return this._current; }
            }
            #endregion

            #region IDisposable Member
            public void Dispose()
            {
            }
            #endregion

            #region IEnumerator Member

            object System.Collections.IEnumerator.Current
            {
                get { return this._current; }
            }

            public bool MoveNext()
            {
                bool result = false;
                if (this._current == null)
                    result= this._config.GetFirstGroup(ref this._current, ref this._index);
                else
                    result= this._config.GetNextGroup(ref this._current, ref this._index);
                if (!result)
                    this._config = null;
                return result;
            }

            public void Reset()
            {
                this._current = null;
            }

            #endregion

            #region IEnumerable<string> Member

            public System.Collections.Generic.IEnumerator<string> GetEnumerator()
            {
                return new GroupEnumerator(this._config);
            }

            #endregion

            #region IEnumerable Member

            System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
            {
                return new GroupEnumerator(this._config);
            }

            #endregion
        }

        /// <summary>
        /// Returns an enumerator of all groups.
        /// </summary>
        /// <seealso cref="GetFirstGroup"/>
        /// <seealso cref="GetNextGroup"/>
        public System.Collections.Generic.IEnumerator<string> GetEnumeratorOfGroups()
        {
            return new GroupEnumerator(this);
        }

        /// <summary>
        /// Returns an enumerable collection of all contained groups.
        /// You may use this in <c>foreach</c> loops.
        /// Please keep care on the <c>Path</c>. The path shall always be the same
        /// on moving to the next entry.
        /// </summary>
        public System.Collections.Generic.IEnumerable<string> GetEnumerableGroups()
        {
            return new GroupEnumerator(this);
        }
        #endregion

        #region Iterate Entries
        /// <summary>
        /// Gets the first entry in the configuration.
        /// </summary>
        /// <param name="str">Will be assigned with the name of the first entry.</param>
        /// <param name="lIndex">This is an identifier for the enumeration.</param>
        /// <returns>True on success.</returns>
        /// <seealso cref="GetEnumeratorOfEntries"/>
        public bool GetFirstEntry(ref string str, ref int lIndex)
        {
            bool ret;
            wxString wstr = new wxString(str);

            ret = wxConfigBase_GetFirstEntry(wxObject, wxString.SafePtr(wstr), ref lIndex);
            str = wstr;

            return ret;
        }

        /// <summary>
        /// Gets the next entry in the configuration.
        /// </summary>
        /// <param name="str">Will be assigned with the name of the first entry.</param>
        /// <param name="lIndex">This is an identifier for the enumeration.</param>
        /// <returns>True on success.</returns>
        /// <seealso cref="GetEnumeratorOfEntries"/>
        public bool GetNextEntry(ref string str, ref int lIndex)
        {
            bool ret;
            wxString wstr = new wxString(str);

            ret = wxConfigBase_GetNextEntry(wxObject, wxString.SafePtr(wstr), ref lIndex);
            str = wstr;

            return ret;
        }

        class EntryEnumerator : System.Collections.Generic.IEnumerator<string>, System.Collections.Generic.IEnumerable<string>
        {
            int _index = 0;
            string _current = null;
            Config _config;

            public EntryEnumerator(Config c)
            {
                this._config = c;
            }

            #region IEnumerator<string> Member
            public string Current
            {
                get { return this._current; }
            }
            #endregion

            #region IDisposable Member
            public void Dispose()
            {
            }
            #endregion

            #region IEnumerator Member

            object System.Collections.IEnumerator.Current
            {
                get { return this._current; }
            }

            public bool MoveNext()
            {
                bool result = false;
                if (this._current == null)
                    result=this._config.GetFirstEntry(ref this._current, ref this._index);
                else
                    result=this._config.GetNextEntry(ref this._current, ref this._index);
                if (!result)
                    this._current = null;
                return result;
            }

            public void Reset()
            {
                this._current = null;
            }

            #endregion

            #region IEnumerable<string> Member

            public System.Collections.Generic.IEnumerator<string> GetEnumerator()
            {
                return new EntryEnumerator(this._config);
            }

            #endregion

            #region IEnumerable Member

            System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
            {
                return new EntryEnumerator(this._config);
            }

            #endregion
        }

        /// <summary>
        /// Returns an enumerator of all entries.
        /// </summary>
        /// <seealso cref="GetFirstEntry"/>
        /// <seealso cref="GetNextEntry"/>
        public System.Collections.Generic.IEnumerator<string> GetEnumeratorOfEntries()
        {
            return new EntryEnumerator(this);
        }

        /// <summary>
        /// Returns an enumerable collection of all contained groups.
        /// You may use this in <c>foreach</c> loops.
        /// Please keep care on the <c>Path</c>. The path shall always be the same
        /// on moving to the next entry.
        /// </summary>
        public System.Collections.Generic.IEnumerable<string> GetEnumerableEntries()
        {
            return new EntryEnumerator(this);
        }
        #endregion

        #region Public Methods
        public void DontCreateOnDemand()
        {
            wxConfigBase_DontCreateOnDemand();
        }

        public int GetNumberOfEntries(bool bRecursive)
        {
            return wxConfigBase_GetNumberOfEntries(wxObject, bRecursive);
        }

        public int GetNumberOfGroups(bool bRecursive)
        {
            return wxConfigBase_GetNumberOfGroups(wxObject, bRecursive);
        }

        public bool HasGroup(string strName)
        {
            wxString wStr = new wxString(strName);
            return wxConfigBase_HasGroup(wxObject, wStr.wxObject);
        }

        public bool HasEntry(string strName)
        {
            wxString wStr = new wxString(strName);
            return wxConfigBase_HasEntry(wxObject, wStr.wxObject);
        }

        /// <summary>
        /// returns true if either a group or an entry with a given name exists
        /// </summary>
        /// <param name="strName">name of an entry or a group</param>
        public bool Exists(string strName)
        {
            wxString wStr = new wxString(strName);
            return wxConfigBase_Exists(this.wxObject, wStr.wxObject);
        }

        public EntryType GetEntryType(string name)
        {
            wxString wStr = new wxString(name);
            return (EntryType)wxConfigBase_GetEntryType(this.wxObject, wStr.wxObject);
        }

        /// <summary>
        /// Read a value from the key, returning true if the value was read. If the key was not found, the value will not be changed.
        /// </summary>
        /// <param name="key">the key</param>
        /// <param name="str">the value to be read</param>
        /// <returns>true if value has been found and set</returns>
        public bool ReadString(string key, ref string str)
        {
            bool ret;
            wxString wstr = new wxString(str);
            wxString wKey = new wxString(key);
            ret = wxConfigBase_ReadStr(this.wxObject, wKey.wxObject, wxString.SafePtr(wstr));
            str = wstr;

            return ret;
        }

        /// <summary>
        /// Read a value from the key, returning true if the value was read. Assigns a default value if the key was not found.
        /// </summary>
        /// <param name="key">the key</param>
        /// <param name="str">the value to be read</param>
        /// <param name="defVal">this will be assigned if the key has not been found</param>
        /// <returns>true if value has been found and set</returns>
        public bool ReadString(string key, ref string str, string defVal)
        {
            bool ret;
            wxString wstr = new wxString(str);
            wxString wkey = new wxString(key);
            wxString wdefVal=new wxString(defVal);
            ret = wxConfigBase_ReadStrDef(this.wxObject, wkey.wxObject, wxString.SafePtr(wstr), wdefVal.wxObject);
            str = wstr;

            return ret;
        }

        /// <summary>
        /// Read a value from the key, returning true if the value was read. If the key was not found, the value will not be changed.
        /// </summary>
        /// <param name="key">the key</param>
        /// <param name="pl">the value to be read</param>
        /// <returns>true if value has been found and set</returns>
        public bool ReadInt(string key, ref int pl)
        {
            wxString wkey = new wxString(key);
            return wxConfigBase_ReadInt(this.wxObject, wkey.wxObject, ref pl);
        }

        /// <summary>
        /// Read a value from the key, returning true if the value was read. Assigns a default value if the key was not found.
        /// </summary>
        /// <param name="key">the key</param>
        /// <param name="pl">the value to be read</param>
        /// <param name="defVal">this will be assigned if the key has not been found</param>
        /// <returns>true if value has been found and set</returns>
        public bool ReadInt(string key, ref int pl, int defVal)
        {
            wxString wkey = new wxString(key);
            return wxConfigBase_ReadIntDef(this.wxObject, wkey.wxObject, ref pl, defVal);
        }

        /// <summary>
        /// Read a value from the key, returning true if the value was read. If the key was not found, the value will not be changed.
        /// </summary>
        /// <param name="key">the key</param>
        /// <param name="val">the value to be read</param>
        /// <returns>true if value has been found and set</returns>
        public bool ReadDouble(string key, ref double val)
        {
            wxString wkey = new wxString(key);
            return wxConfigBase_ReadDbl(this.wxObject, wkey.wxObject, ref val);
        }

        /// <summary>
        /// Read a value from the key, returning true if the value was read. Assigns a default value if the key was not found.
        /// </summary>
        /// <param name="key">the key</param>
        /// <param name="val">the value to be read</param>
        /// <param name="defVal">this will be assigned if the key has not been found</param>
        /// <returns>true if value has been found and set</returns>
        public bool ReadDouble(string key, ref double val, double defVal)
        {
            wxString wkey = new wxString(key);
            return wxConfigBase_ReadDblDef(this.wxObject, wkey.wxObject, ref val, defVal);
        }

        /// <summary>
        /// Read a value from the key, returning true if the value was read. If the key was not found, the value will not be changed.
        /// </summary>
        /// <param name="key">the key</param>
        /// <param name="val">the value to be read</param>
        /// <returns>true if value has been found and set</returns>
        public bool ReadBool(string key, ref bool val)
        {
            wxString wkey = new wxString(key);
            return wxConfigBase_ReadBool(this.wxObject, wkey.wxObject, ref val);
        }

        /// <summary>
        /// Read a value from the key, returning true if the value was read. Assigns a default value if the key was not found.
        /// </summary>
        /// <param name="key">the key</param>
        /// <param name="val">the value to be read</param>
        /// <param name="defVal">this will be assigned if the key has not been found</param>
        /// <returns>true if value has been found and set</returns>
        public bool ReadBool(string key, ref bool val, bool defVal)
        {
            wxString wkey = new wxString(key);
            return wxConfigBase_ReadBoolDef(this.wxObject, wkey.wxObject, ref val, defVal);
        }

        /// <summary>
        /// Read a value from the key, returning true if the value was read. If the key was not found, the value will not be changed.
        /// </summary>
        /// <param name="key">the key</param>
        /// <param name="val">the value to be read</param>
        /// <returns>true if value has been found and set</returns>
        public bool ReadFont(string key, ref Font val)
        {
            return ReadFont(key, ref val, Font.wxNORMAL_FONT);
        }

        /// <summary>
        /// Read a value from the key, returning true if the value was read. Assigns a default value if the key was not found.
        /// </summary>
        /// <param name="key">the key</param>
        /// <param name="val">the value to be read</param>
        /// <param name="defVal">this will be assigned if the key has not been found</param>
        /// <returns>true if value has been found and set</returns>
        public bool ReadFont(string key, ref Font val, Font defVal)
        {
            try
            {
                XmlSerializer serializer = new XmlSerializer();
                using(System.IO.StringReader s=new System.IO.StringReader(this.Read(key, "")))
                using(System.Xml.XmlTextReader reader=new System.Xml.XmlTextReader(s))
                {
                    serializer.ReadXml(reader);
                    if (serializer.Font != null)
                        val = serializer.Font;
                }
                return true;
            }
            catch (Exception exc)
            {
                Log.LogError(_("Error on reading a font from configuration: {0}", exc.Message));
                val=defVal;
                return false;
            }
        }

        /// <summary>
        /// Read a value from the key, returning true if the value was read. Assigns a default value if the key was not found.
        /// </summary>
        /// <param name="key">the key</param>
        /// <param name="val">the value to be read</param>
        /// <param name="defVal">this will be assigned if the key has not been found</param>
        /// <returns>true if value has been found and set</returns>
        public bool ReadColour(string key, ref Colour val, Colour defVal)
        {
            try
            {
                XmlSerializer serializer = new XmlSerializer();
                using(System.IO.StringReader s=new System.IO.StringReader(this.Read(key, "")))
                using(System.Xml.XmlTextReader reader=new System.Xml.XmlTextReader(s))
                {
                    serializer.ReadXml(reader);
                    if (serializer.Colour != null)
                        val = serializer.Colour;
                }
                return true;
            }
            catch (Exception exc)
            {
                Log.LogError(_("Error on reading a colour from configuration: {0}", exc.Message));
                val=defVal;
                return false;
            }
        }

        public bool Read(string key, System.Xml.Serialization.IXmlSerializable readThis)
        {
            string xmlString="";
            if (this.ReadString(key, ref xmlString))
            {
                try
                {
                    using (System.IO.StringReader s = new System.IO.StringReader(xmlString))
                    using (System.Xml.XmlReader reader = new System.Xml.XmlTextReader(s))
                    {
                        readThis.ReadXml(reader);
                    }
                    return true;
                }
                catch (Exception exc)
                {
                    Log.LogError(_("Error reading xml configuration attribute: {0}.", exc.Message));
                    return false;
                }
            }
            else
                return false;
        }


        public string Read(string key, string defVal)
        {
            wxString wkey = new wxString(key);
            wxString wdefVal = new wxString(defVal);
            return new wxString(wxConfigBase_ReadStrRet(this.wxObject, wkey.wxObject, wdefVal.wxObject), true);
        }

        public int Read(string key, int defVal)
        {
            wxString wkey = new wxString(key);
            return wxConfigBase_ReadIntRet(this.wxObject, wkey.wxObject, defVal);
        }

        public bool Read(string key, bool defVal)
        {
            bool val = false;
            ReadBool(key, ref val, defVal);
            return val;
        }

        public Colour Read(string key, Colour defVal)
        {
            Colour col = new Colour();
            ReadColour(key, ref col, defVal);
            return col;
        }

        public Font Read(string key, Font defVal)
        {
            Font fnt = new Font();
            ReadFont(key, ref fnt, defVal);
            return fnt;
        }

        public bool Write(string key, string val)
        {
            wxString wkey = new wxString(key);
            wxString wval = new wxString(val);
            return wxConfigBase_WriteStr(this.wxObject, wkey.wxObject, wval.wxObject);
        }

        public bool Write(string key, int val)
        {
            wxString wkey = new wxString(key);
            return wxConfigBase_WriteInt(this.wxObject, wkey.wxObject, val);
        }

        public bool Write(string key, uint val)
        {
            return this.Write(key, (int) val);
        }

        public bool Write(string key, double val)
        {
            wxString wkey = new wxString(key);
            return wxConfigBase_WriteDbl(this.wxObject, wkey.wxObject, val);
        }

        public bool Write(string key, bool val)
        {
            wxString wkey = new wxString(key);
            return wxConfigBase_WriteBool(this.wxObject, wkey.wxObject, val);
        }

        public bool Write(string key, Font val)
        {
            XmlSerializer serializer = new XmlSerializer(val);
            return this.Write(key, serializer);
        }

        public bool Write(string key, Colour val)
        {
            XmlSerializer serializer = new XmlSerializer(val);
            return this.Write(key, serializer);
        }

        /** <summary>This will write a serializable object identified by <c>key</c>.
         * </summary>
         */
        public bool Write(string key, System.Xml.Serialization.IXmlSerializable val)
        {
            try
            {
                using (System.IO.StringWriter s = new System.IO.StringWriter())
                {
                    using (System.Xml.XmlTextWriter writer = new System.Xml.XmlTextWriter(s))
                    {
                        val.WriteXml(writer);
                    }
                    this.Write(key, s.ToString());
                }
            }
            catch (Exception exc)
            {
                Log.LogError(_("Error on writing xml serialization into configuration: {0}.", exc.Message));
                return false;
            }
            return true;
        }

        /// <summary>
        /// permanently writes all changes (otherwise, they're only written from object's destructor)
        /// </summary>
        public bool Flush()
        {
            return this.Flush(false);
        }

        /// <summary>
        /// permanently writes all changes (otherwise, they're only written from object's destructor)
        /// </summary>
        public bool Flush(bool bCurrentOnly)
        {
            return wxConfigBase_Flush(wxObject, bCurrentOnly);
        }

        public bool RenameEntry(string oldName, string newName)
        {
            using (wxString woldName = new wxString(oldName))
            using (wxString wnewName = new wxString(newName))
            {
                return wxConfigBase_RenameEntry(this.wxObject, woldName.wxObject, wnewName.wxObject);
            }
        }

        public bool RenameGroup(string oldName, string newName)
        {
            using (wxString woldName = new wxString(oldName))
            using (wxString wnewName = new wxString(newName))
            {
                return wxConfigBase_RenameGroup(this.wxObject, woldName.wxObject, wnewName.wxObject);
            }
        }

        /// <summary>
        /// Deletes the specified entry and the group it
        /// belongs to if it was the last key in it.
        /// </summary>
        /// <param name="key">The key of the entry to delete</param>
        public bool DeleteEntry(string key)
        {
            return this.DeleteEntry(key, true);
        }

        /// <summary>
        /// Deletes the specified entry and the group it
        /// belongs to if it was the last key in it and the second parameter is true.
        /// </summary>
        /// <param name="key">The key of the entry to delete</param>
        /// <param name="bDeleteGroupIfEmpty">If true the whole group will be deleted if this deleted the last entry</param>
        public bool DeleteEntry(string key, bool bDeleteGroupIfEmpty)
        {
            using (wxString wkey = new wxString(key))
            {
                return wxConfigBase_DeleteEntry(this.wxObject, wkey.wxObject, bDeleteGroupIfEmpty);
            }
        }

        /// <summary>
        /// Delete the group (with all subgroups). If the current path is under the group being deleted it is changed to
        /// its deepest still existing component. E.g. if the current path is /A/B/C/D and the group C is deleted the
        /// path becomes /A/B.
        /// </summary>
        /// <param name="key">Designator of the group to be deleted</param>
        public bool DeleteGroup(string key)
        {
            wxString wkey = new wxString(key);
            return wxConfigBase_DeleteGroup(this.wxObject, wkey.wxObject);
        }

        /// <summary>
        /// Delete the whole underlying object (disk file, registry key, ...). Primarly for use by uninstallation routine.
        /// </summary>
        public bool DeleteAll()
        {
            return wxConfigBase_DeleteAll(this.wxObject);
        }
        #endregion

        #region Environment Variables
        /** <summary>This read/write property defines automatic expansion of environment variables.
         * Use WithEnvVarsExpanded() to read a string with expanded environment variables.
         *</summary>*/
        public bool ExpandEnvVars
        {
            get { return wxConfigBase_IsExpandingEnvVars(this.wxObject); }
            set { wxConfigBase_SetExpandEnvVars(this.wxObject, value); }
        }

        /** <summary>This is the equivalent to <c>wxConfig</c>::EnvVarsExpanded().
         * This has to be renamed since <c>EnvVarsExpanded</c> is required as name of the property
         * for automatic expansion.
         *</summary>*/
        public string WithEnvVarsExpanded(string str)
        {
            wxString wstr = new wxString(str);
            return new wxString(wxConfigBase_ExpandEnvVars(this.wxObject, wstr.wxObject));
        }
        #endregion

        #region Public Properties
        /// <summary>
        /// If true, all default values provided with Read() actions will be recorded.
        /// </summary>
        public bool RecordDefaults
        {
            set { wxConfigBase_SetRecordDefaults(wxObject, value); }
            get { return wxConfigBase_IsRecordingDefaults(wxObject); }
        }

        /// <summary>
        /// The name of the application.
        /// </summary>
        public string AppName
        {
            get { return new wxString(wxConfigBase_GetAppName(wxObject), true); }
            set
            {
                wxString wvalue = new wxString(value);
                wxConfigBase_SetAppName(this.wxObject, wvalue.wxObject);
            }
        }

        /// <summary>
        /// The name of the vendor.
        /// </summary>
        public string VendorName
        {
            get { return new wxString(wxConfigBase_GetVendorName(wxObject), true); }
            set
            {
                wxString wvalue = new wxString(value);
                wxConfigBase_SetVendorName(this.wxObject, wvalue.wxObject);
            }
        }

        /// <summary>
        /// The style that has been used. You may also change this.
        /// </summary>
        public ConfigStyle Style
        {
            set { wxConfigBase_SetStyle(wxObject, (uint)value); }
            get { return (ConfigStyle)wxConfigBase_GetStyle(wxObject); }
        }

        /// <summary>
        /// Get or set the current path in the configuration:
        /// On reading the path: Path information is always absolute on reading.
        /// On setting the path:
        /// if the first character is '/', it is the absolute path, otherwise it is a relative path. '..' is supported. If strPath doesn't exist it is created.
        /// </summary>
        public string Path
        {
            set
            {
                wxString wStr = new wxString(value);
                wxConfigBase_SetPath(wxObject, wStr.wxObject);
            }
            get { return new wxString(wxConfigBase_GetPath(wxObject), true); }
        }
        #endregion
    }
}

