//-----------------------------------------------------------------------------
// wx.NET - ListCtrl.cs
//
// The wxListCtrl wrapper class
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 by Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: ListCtrl.cs,v 1.47 2010/05/08 19:54:35 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Drawing;
using System.Runtime.InteropServices;

namespace wx
{
    /** <summary>Indicates relevant members of a wx.ListItem.
     * Instances of wx.ListItem may be masked, i.e. only some of their
     * properties may be valid. These flags define which properties
     * of the item are valid and shall be used and which properties
     * are irrelevant and shall be ignored.</summary>*/
    [Flags]
    public enum ListItemMask
    {
        /** <summary>Nothing is valid.</summary>*/
        NONE = 0x00,
        /** <summary>wx.ListItem.State</summary>*/
        STATE = 0x0001,
        /** <summary>wx.ListItem.Text</summary>*/
        TEXT = 0x0002,
        /** <summary>wx.ListItem.Image</summary>*/
        IMAGE = 0x0004,
        /** <summary>wx.ListItem.Data</summary>*/
        DATA = 0x0008,
        /** <summary>wx.ListItem.Item</summary>*/
        ITEM = 0x0010,
        /** <summary>wx.ListItem.Width</summary>*/
        WIDTH = 0x0020,
        /** <summary>wx.ListItem.Format</summary>*/
        FORMAT = 0x0040,

        /** <summary>Denotes all properties of list items.</summary>*/
        ALL = STATE | TEXT | IMAGE | DATA | ITEM | WIDTH | FORMAT,
    }

    /** <summary>Flags for wx.ListCtrl.GetNextItem()</summary>*/
    [Flags]
    public enum ListItemState
    {
        DONTCARE = 0x0000,
        DROPHILITED = 0x0001,
        FOCUSED = 0x0002,
        SELECTED = 0x0004,
        CUT = 0x0008
    }

    /** <summary>Representation of an item in wx.ListCtrl or wx.ListView.</summary>*/
	public class ListItem : Object
    {
        #region C API
        [DllImport("wx-c")] static extern IntPtr wxListItem_ctor();
		[DllImport("wx-c")] static extern void   wxListItem_Clear(IntPtr self);
		[DllImport("wx-c")] static extern void   wxListItem_ClearAttributes(IntPtr self);
		[DllImport("wx-c")] static extern int    wxListItem_GetAlign(IntPtr self);
		[DllImport("wx-c")] static extern IntPtr wxListItem_GetBackgroundColour(IntPtr self);
		[DllImport("wx-c")] static extern int    wxListItem_GetColumn(IntPtr self);
		[DllImport("wx-c")] static extern IntPtr wxListItem_GetData(IntPtr self);
		[DllImport("wx-c")] static extern IntPtr wxListItem_GetFont(IntPtr self);
		[DllImport("wx-c")] static extern int    wxListItem_GetId(IntPtr self);
		[DllImport("wx-c")] static extern int    wxListItem_GetImage(IntPtr self);
		[DllImport("wx-c")] static extern int    wxListItem_GetMask(IntPtr self);
		[DllImport("wx-c")] static extern int    wxListItem_GetState(IntPtr self);
		[DllImport("wx-c")] static extern IntPtr wxListItem_GetText(IntPtr self);
		[DllImport("wx-c")] static extern IntPtr wxListItem_GetTextColour(IntPtr self);
		[DllImport("wx-c")] static extern int    wxListItem_GetWidth(IntPtr self);
		[DllImport("wx-c")] static extern void   wxListItem_SetAlign(IntPtr self, int align);
		[DllImport("wx-c")] static extern void   wxListItem_SetBackgroundColour(IntPtr self, IntPtr col);
		[DllImport("wx-c")] static extern void   wxListItem_SetColumn(IntPtr self, int col);
		[DllImport("wx-c")] static extern void   wxListItem_SetData(IntPtr self, IntPtr data);
		[DllImport("wx-c")] static extern void   wxListItem_SetFont(IntPtr self, IntPtr font);
		[DllImport("wx-c")] static extern void   wxListItem_SetId(IntPtr self, int id);
		[DllImport("wx-c")] static extern void   wxListItem_SetImage(IntPtr self, int image);
		[DllImport("wx-c")] static extern void   wxListItem_SetMask(IntPtr self, int mask);
		[DllImport("wx-c")] static extern void   wxListItem_SetState(IntPtr self, int state);
		[DllImport("wx-c")] static extern void   wxListItem_SetStateMask(IntPtr self, int stateMask);
		[DllImport("wx-c")] static extern void   wxListItem_SetText(IntPtr self, IntPtr text);
		[DllImport("wx-c")] static extern void   wxListItem_SetTextColour(IntPtr self, IntPtr col);
		[DllImport("wx-c")] static extern void   wxListItem_SetWidth(IntPtr self, int width);
		
		[DllImport("wx-c")] static extern IntPtr wxListItem_GetAttributes(IntPtr self);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxListItem_HasAttributes(IntPtr self);
        #endregion

        //---------------------------------------------------------------------

		public ListItem(IntPtr wxObject) 
			: base(wxObject)
        {
        }

		public ListItem() 
			: base(wxListItem_ctor())
        {
        }

        /** <summary>Generating an item representing the following text.
         * </summary>
         */
        public ListItem(string text)
            : this()
        {
            this.Text = text;
        }

        /** <summary>Generating an item of the provided text and the specified alignment.</summary>
         * <param name="align"> is a constant like wx.ListCtrl.wxLIST_FORMAT_CENTRE
         * </param>
         */
        public ListItem(string text, ListColumnFormat align)
            : this()
        {
            this.Text = text;
            this.Align = align;
        }

        //---------------------------------------------------------------------
        
		public void Clear()
		{
			wxListItem_Clear(wxObject);
		}
		
		//---------------------------------------------------------------------
        
		public void ClearAttributes()
		{
			wxListItem_ClearAttributes(wxObject);
		}

		//---------------------------------------------------------------------

        /** <summary>A constant like wx.ListColumnFormat.CENTRE.</summary>*/
		public ListColumnFormat Align
		{
			get { return (ListColumnFormat)wxListItem_GetAlign(wxObject); }
			set { wxListItem_SetAlign(wxObject, (int)value); }
		}
        
		//---------------------------------------------------------------------
        
		public Colour BackgroundColour
		{
			get { return new Colour(wxListItem_GetBackgroundColour(wxObject), true); }
			set {  wxListItem_SetBackgroundColour(wxObject, Object.SafePtr(value)); } 
		}

		//---------------------------------------------------------------------
        
		public int Column
		{
			get { return wxListItem_GetColumn(wxObject); }
			set { wxListItem_SetColumn(wxObject, value); }
		}

		//---------------------------------------------------------------------
        
        /** <summary>Get or set the client data that is associated with this list item.
        * Please note, that the list item will take ownership of the C++ instance of the client data.
        * So, this will raise an exception, if the client data is already in use elsewhere.</summary>*/
		public ClientData Data
		{
			get { return (ClientData)Object.FindObject(wxListItem_GetData(wxObject)); }
			set
            {
                if (!value.memOwn)
                    throw new Exception("Cannot attach client data to a list item if the client data instance is already in use.");
                value.memOwn = false;
                wxListItem_SetData(wxObject, Object.SafePtr(value));
            }
		}
		
		//---------------------------------------------------------------------
        
		public Font Font
		{
			get { return new Font(wxListItem_GetFont(wxObject)); }
			set { wxListItem_SetFont(wxObject, Object.SafePtr(value)); }
		}

		//---------------------------------------------------------------------
        
		public int Id
		{
			get { return wxListItem_GetId(wxObject); }
			set { wxListItem_SetId(wxObject, value); }
		}

		//---------------------------------------------------------------------
        
		public int Image
		{
			get { return wxListItem_GetImage(wxObject); }
			set { wxListItem_SetImage(wxObject, value); }
		}

		//---------------------------------------------------------------------
        
		public ListItemMask Mask
		{
			get { return (ListItemMask)wxListItem_GetMask(wxObject); }
			set { wxListItem_SetMask(wxObject, (int)value); }
		}

		//---------------------------------------------------------------------
        
		public ListItemState State
		{
			get { return (ListItemState) wxListItem_GetState(wxObject); }
			set { wxListItem_SetState(wxObject, (int)value); }
		}

		public ListItemState StateMask
		{
			set { wxListItem_SetStateMask(wxObject, (int)value); }
		}

		//---------------------------------------------------------------------
        
		public string Text
		{
			get { return new wxString(wxListItem_GetText(wxObject), true); }
			set
            {
                wxString wxValue = new wxString(value);
                wxListItem_SetText(wxObject, wxValue.wxObject);
            }
		}

		//---------------------------------------------------------------------
        
		public Colour TextColour
		{
			get { return new Colour(wxListItem_GetTextColour(wxObject), true); }
			set { wxListItem_SetTextColour(wxObject, Object.SafePtr(value)); } 
		}

		//---------------------------------------------------------------------
        
		public int Width
		{
			get { return wxListItem_GetWidth(wxObject); }
			set { wxListItem_SetWidth(wxObject, value); }
		}
		
		//---------------------------------------------------------------------
		
		public ListItemAttr Attributes
		{
			get
            {
                return (ListItemAttr) Object.FindObject(wxListItem_GetAttributes(this.wxObject), typeof(ListItemAttr), true);
            }
		}
		
		//---------------------------------------------------------------------
		
		public bool HasAttributes()
		{
			return wxListItem_HasAttributes(wxObject);
		}
	}
	
	//-----------------------------------------------------------------------------
	
	public class ListItemAttr : Object
	{
		[DllImport("wx-c")] static extern IntPtr wxListItemAttr_ctor();
		[DllImport("wx-c")] static extern IntPtr wxListItemAttr_ctor2(IntPtr colText, IntPtr colBack, IntPtr font);
        [DllImport("wx-c")] static extern void wxListItemAttr_dtor(IntPtr self);
		[DllImport("wx-c")] static extern void   wxListItemAttr_RegisterDisposable(IntPtr self, Virtual_Dispose onDispose);
		[DllImport("wx-c")] static extern void   wxListItemAttr_SetTextColour(IntPtr self, IntPtr colText);
		[DllImport("wx-c")] static extern void   wxListItemAttr_SetBackgroundColour(IntPtr self, IntPtr colBack);
		[DllImport("wx-c")] static extern void   wxListItemAttr_SetFont(IntPtr self, IntPtr font);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxListItemAttr_HasTextColour(IntPtr self);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxListItemAttr_HasBackgroundColour(IntPtr self);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxListItemAttr_HasFont(IntPtr self);
		[DllImport("wx-c")] static extern IntPtr wxListItemAttr_GetTextColour(IntPtr self);
		[DllImport("wx-c")] static extern IntPtr wxListItemAttr_GetBackgroundColour(IntPtr self);
		[DllImport("wx-c")] static extern IntPtr wxListItemAttr_GetFont(IntPtr self);
		
		//-----------------------------------------------------------------------------

		public ListItemAttr(IntPtr wxObject)
            : base(wxObject, StorageMode.RegisteredObject, true) 
		{
            virtual_Dispose = new Virtual_Dispose(VirtualDispose);
            wxListItemAttr_RegisterDisposable(wxObject, virtual_Dispose);
        }
			
		public ListItemAttr()
            : this(wxListItemAttr_ctor()) 
		{
		}
		
		public ListItemAttr(Colour colText, Colour colBack, Font font)
			: this(wxListItemAttr_ctor2(Object.SafePtr(colText), Object.SafePtr(colBack), Object.SafePtr(font))) 
		{
		}
		
		//---------------------------------------------------------------------
				
		public override void Dispose()
		{
			if (!disposed)
			{
                if (wxObject != IntPtr.Zero)
				{
					if (memOwn)
					{
						wxListItemAttr_dtor(wxObject);
						memOwn = false;
					}
				}
				RemoveObject(wxObject);
				wxObject = IntPtr.Zero;
                --validInstancesCount;
                disposed = true;
			}
			
			base.Dispose();
			GC.SuppressFinalize(this);
		}
		
		//---------------------------------------------------------------------
		
		~ListItemAttr() 
		{
			Dispose();
		}
		
		//---------------------------------------------------------------------
		
		public Colour TextColour
		{
			get { return new Colour(wxListItemAttr_GetTextColour(wxObject), true); }
			set { wxListItemAttr_SetTextColour(wxObject, Object.SafePtr(value)); }
		}
		
		//---------------------------------------------------------------------
		
		public Colour BackgroundColour
		{
			get { return new Colour(wxListItemAttr_GetBackgroundColour(wxObject), true); }
			set { wxListItemAttr_SetBackgroundColour(wxObject, Object.SafePtr(value)); }
		}
		
		//---------------------------------------------------------------------
		
		public Font Font
		{
			get { return new Font(wxListItemAttr_GetFont(wxObject), true); }
			set { wxListItemAttr_SetFont(wxObject, Object.SafePtr(value)); }
		}
		
		//---------------------------------------------------------------------
		
		public bool HasTextColour
		{
			get { return wxListItemAttr_HasTextColour(wxObject); }
		}
		
		//---------------------------------------------------------------------
		
		public bool HasBackgroundColour
		{
			get { return wxListItemAttr_HasBackgroundColour(wxObject); }
		}
		
		//---------------------------------------------------------------------
		
		public bool HasFont
		{
			get { return wxListItemAttr_HasFont(wxObject); }
		}
	}
	
	//---------------------------------------------------------------------

    /** <summary>Format for list columns.
     * This will be used in wx.ListCtrl.Arrange() and wx.ListItem.Align</summary>*/
    [Flags]
    public enum ListColumnFormat
    {
		LEFT     = 0,
		RIGHT    = 1,
		CENTRE   = 2,
		CENTER   = CENTRE,
    }

    /** <summary>Flags that may result from wx.ListCtrl.HitTest().</summary>*/
    [Flags]
    public enum ListHitTest
    {
		ABOVE          = 0x0001,
		BELOW          = 0x0002,
		NOWHERE        = 0x0004,
		ONITEMICON     = 0x0020,
		ONITEMLABEL    = 0x0080,
		ONITEMRIGHT    = 0x0100,
		ONITEMSTATEICON= 0x0200,
		TOLEFT         = 0x0400,
		TORIGHT        = 0x0800,
    }

    /** <summary>The list control.
     * This is appropriate to display also large lists of data.
     * \image html listctrlsmall.png "The list control in report mode."</summary>*/
    public class ListCtrl : Control
        , System.Collections.IEnumerable
        , System.Collections.Generic.IEnumerable<ListItem>
    {
        #region Enumerations
        /** <summary>Flags for GetNextItem()</summary>*/
        public enum NEXT
        {
            ABOVE,
            ALL,
            BELOW,
            LEFT,
            RIGHT
        }

        /** <summary>These are optional symbolic specifications of the column width.
         * Refer to wx.ListCtrl.SetColumnWidth().</summary>*/
        public enum SymbolicColumnWidth
        {
            /** <summary>This will resize the column to the length of its longest item.</summary>*/
		    AUTOSIZE			= -1,
            /** <summary>This will resize the column to the length of the header (Win32) or 80 pixels (other platforms).</summary>*/
		    AUTOSIZE_USEHEADER	= -2,
        }
        #endregion

        #region Delegates
        public delegate IntPtr Callback_OnGetItemText(int item, int col);
        public delegate int Callback_OnGetItemImage(int item);
        public delegate int Callback_OnGetItemColumnImage(int item, int col);
        public delegate IntPtr Callback_OnGetItemAttr(int item);

        /** <summary>The corresponding  wxWidgets function type uses <c>int</c> data to designate items and sort data.
         * However, C typically identifies <c>int</c> and <c>long</c> on 32 bit architectures. Apparently, C# does not so.
         * It is apparently unwise to use <c>long</c> in native C interfaces since this data type does not have
         * a standard size_t.
         *</summary>*/
        public delegate int wxListCtrlCompare(ClientData item1, ClientData item2, int sortData);
	
        Callback_OnGetItemText _onGetItemText = null;
        Callback_OnGetItemImage _onGetItemImage = null;
        Callback_OnGetItemColumnImage _onGetItemColumnImage = null;
        Callback_OnGetItemAttr _onGetItemAttr = null;
        #endregion

        #region C API
        [DllImport("wx-c")] static extern IntPtr wxListCtrl_ctor();
		[DllImport("wx-c")] static extern void   wxListCtrl_dtor(IntPtr self);
        [DllImport("wx-c")] static extern void wxListCtrl_RegisterVirtual(IntPtr self, Callback_OnGetItemText onGetItemText, Callback_OnGetItemImage onGetItemImage, Callback_OnGetItemColumnImage onGetItemColumnImage, Callback_OnGetItemAttr onGetItemAttr);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxListCtrl_Create(IntPtr self, IntPtr parent, int id, int posX, int posY, int width, int height, uint style, IntPtr validator, IntPtr name);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxListCtrl_GetColumn(IntPtr self, int col, ref IntPtr item);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxListCtrl_SetColumn(IntPtr self, int col, IntPtr item);
		[DllImport("wx-c")] static extern int    wxListCtrl_GetColumnWidth(IntPtr self, int col);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxListCtrl_SetColumnWidth(IntPtr self, int col, int width);
		[DllImport("wx-c")] static extern int    wxListCtrl_GetCountPerPage(IntPtr self);
		[DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxListCtrl_GetItem(IntPtr self, IntPtr info);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxListCtrl_SetItem(IntPtr self, IntPtr info);
		[DllImport("wx-c")] static extern int    wxListCtrl_SetItem_By_Row_Col(IntPtr self, int index, int col, IntPtr label, int imageId);
		[DllImport("wx-c")] static extern int    wxListCtrl_GetItemState(IntPtr self, int item, int stateMask);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxListCtrl_SetItemState(IntPtr self, int item, int state, int stateMask);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxListCtrl_SetItemImage(IntPtr self, int item, int image, int selImage);
		[DllImport("wx-c")] static extern IntPtr wxListCtrl_GetItemText(IntPtr self, int item);
		[DllImport("wx-c")] static extern void   wxListCtrl_SetItemText(IntPtr self, int item, IntPtr str);
		[DllImport("wx-c")] static extern IntPtr wxListCtrl_GetItemData(IntPtr self, int item);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxListCtrl_SetItemData(IntPtr self, int item, IntPtr data);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxListCtrl_GetItemRect(IntPtr self, int item, out Rectangle rect, int code);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxListCtrl_GetItemPosition(IntPtr self, int item, out Point pos);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxListCtrl_SetItemPosition(IntPtr self, int item, ref Point pos);
		[DllImport("wx-c")] static extern int    wxListCtrl_GetItemCount(IntPtr self);
		[DllImport("wx-c")] static extern int    wxListCtrl_GetColumnCount(IntPtr self);
		[DllImport("wx-c")] static extern void   wxListCtrl_SetItemTextColour(IntPtr self, int item, IntPtr col);
		[DllImport("wx-c")] static extern IntPtr wxListCtrl_GetItemTextColour(IntPtr self, int item);
		[DllImport("wx-c")] static extern void   wxListCtrl_SetItemBackgroundColour(IntPtr self, int item, IntPtr col);
		[DllImport("wx-c")] static extern IntPtr wxListCtrl_GetItemBackgroundColour(IntPtr self, int item);
		[DllImport("wx-c")] static extern int    wxListCtrl_GetSelectedItemCount(IntPtr self);
		[DllImport("wx-c")] static extern IntPtr wxListCtrl_GetTextColour(IntPtr self);
		[DllImport("wx-c")] static extern void   wxListCtrl_SetTextColour(IntPtr self, IntPtr col);
		[DllImport("wx-c")] static extern int    wxListCtrl_GetTopItem(IntPtr self);
		[DllImport("wx-c")] static extern void   wxListCtrl_SetSingleStyle(IntPtr self, uint style, bool add);
		[DllImport("wx-c")] static extern int    wxListCtrl_GetNextItem(IntPtr self, int item, int geometry, int state);
		[DllImport("wx-c")] static extern IntPtr wxListCtrl_GetImageList(IntPtr self, int which);
		[DllImport("wx-c")] static extern void   wxListCtrl_SetImageList(IntPtr self, IntPtr imageList, int which);
		//[DllImport("wx-c")] static extern void   wxListCtrl_AssignImageList(IntPtr self, IntPtr imageList, int which);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxListCtrl_Arrange(IntPtr self, int flag);
		[DllImport("wx-c")] static extern void   wxListCtrl_ClearAll(IntPtr self);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxListCtrl_DeleteItem(IntPtr self, int item);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxListCtrl_DeleteAllItems(IntPtr self);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxListCtrl_DeleteAllColumns(IntPtr self);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxListCtrl_DeleteColumn(IntPtr self, int col);
		[DllImport("wx-c")] static extern void   wxListCtrl_SetItemCount(IntPtr self, int count);
		[DllImport("wx-c")] static extern void   wxListCtrl_EditLabel(IntPtr self, int item);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxListCtrl_EnsureVisible(IntPtr self, int item);
		[DllImport("wx-c")] static extern int    wxListCtrl_FindItem(IntPtr self, int start, IntPtr str, bool partial);
		[DllImport("wx-c")] static extern int    wxListCtrl_FindItemData(IntPtr self, int start, IntPtr data);
		[DllImport("wx-c")] static extern int    wxListCtrl_FindItemPoint(IntPtr self, int start, ref Point pt, int direction);
		[DllImport("wx-c")] static extern int    wxListCtrl_HitTest(IntPtr self, ref Point point, int flags);
		[DllImport("wx-c")] static extern int    wxListCtrl_InsertItem(IntPtr self, IntPtr info);
		[DllImport("wx-c")] static extern int    wxListCtrl_InsertTextItem(IntPtr self, int index, IntPtr label);
		[DllImport("wx-c")] static extern int    wxListCtrl_InsertImageItem(IntPtr self, int index, int imageIndex);
		[DllImport("wx-c")] static extern int    wxListCtrl_InsertTextImageItem(IntPtr self, int index, IntPtr label, int imageIndex);
		[DllImport("wx-c")] static extern int    wxListCtrl_InsertColumn(IntPtr self, int col, IntPtr info);
		[DllImport("wx-c")] static extern int    wxListCtrl_InsertTextColumn(IntPtr self, int col, IntPtr heading, int format, int width);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxListCtrl_ScrollList(IntPtr self, int dx, int dy);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxListCtrl_SortItems(IntPtr self, SortCallback.cbSortItems fn, int data);
		
		[DllImport("wx-c")] static extern void   wxListCtrl_GetViewRect(IntPtr self, ref Rectangle rect);
		
		[DllImport("wx-c")] static extern void   wxListCtrl_RefreshItem(IntPtr self, int item);
		[DllImport("wx-c")] static extern void   wxListCtrl_RefreshItems(IntPtr self, int itemFrom, int itemTo);
        #endregion

        #region CTor
        void RegisterVirtual()
        {
            this._onGetItemText = new Callback_OnGetItemText(OnDoGetItemText);
            this._onGetItemImage = new Callback_OnGetItemImage(OnDoGetItemImage);
            this._onGetItemColumnImage = new Callback_OnGetItemColumnImage(OnDoGetItemColumnImage);
            this._onGetItemAttr = new Callback_OnGetItemAttr(OnDoGetItemAttr);
            wxListCtrl_RegisterVirtual(this.wxObject, this._onGetItemText, this._onGetItemImage, this._onGetItemColumnImage, this._onGetItemAttr);
        }

        public ListCtrl(IntPtr wxObject)
			: base(wxObject) { }

		public ListCtrl()
			: base(wxListCtrl_ctor())
        {
            RegisterVirtual();
        }

		public ListCtrl(Window parent)
			: this(parent, Window.UniqueID, wxDefaultPosition, wxDefaultSize, wx.WindowStyles.LC_ICON, null) { }

		public ListCtrl(Window parent, int id)
            : this(parent, id, wxDefaultPosition, wxDefaultSize, wx.WindowStyles.LC_ICON, null) { }

		public ListCtrl(Window parent, int id, Point pos)
            : this(parent, id, pos, wxDefaultSize, wx.WindowStyles.LC_ICON, null) { }

		public ListCtrl(Window parent, int id, Point pos, Size size)
            : this(parent, id, pos, size, wx.WindowStyles.LC_ICON, null) { }

		public ListCtrl(Window parent, int id, Point pos, Size size, wx.WindowStyles style)
			: this(parent, id, pos, size, style, null) { }

		public ListCtrl(Window parent, int id, Point pos, Size size, wx.WindowStyles style, string name)
			: base(wxListCtrl_ctor())
		{
            RegisterVirtual();
            if (!Create(parent, id, pos, size, style, name))
			{
				throw new InvalidOperationException("Failed to create ListCtrl");
			}
		}
	
		//---------------------------------------------------------------------
		// ctors with self created id
	
		public ListCtrl(Window parent, Point pos)
            : this(parent, Window.UniqueID, pos, wxDefaultSize, wx.WindowStyles.LC_ICON, null) { }

		public ListCtrl(Window parent, Point pos, Size size)
            : this(parent, Window.UniqueID, pos, size, wx.WindowStyles.LC_ICON, null) { }

		public ListCtrl(Window parent, Point pos, Size size, wx.WindowStyles style)
			: this(parent, Window.UniqueID, pos, size, style, null) { }

		public ListCtrl(Window parent, Point pos, Size size, wx.WindowStyles style, string name)
			: this(parent, Window.UniqueID, pos, size, style, name) {}
	
		//---------------------------------------------------------------------

		public bool Create(Window parent, int id, Point pos, Size size, wx.WindowStyles style, string name)
		{
            wxString wxName = new wxString(name);
			return wxListCtrl_Create(wxObject, Object.SafePtr(parent), id, pos.X, pos.Y, size.Width, size.Height, (uint)style, IntPtr.Zero, wxName.wxObject);
        }
        
        protected override void CallDTor ()
        {
        	wxListCtrl_dtor(this.wxObject);
        }

        #endregion

        #region Virtual Functions / Virtual List
        /** <summary>Overload this to provide the name of a virtually represented item.
         * The default implementation returns an empty string. So, don't be surprised if
         * you get an empty list because you didn't implement this.</summary>*/
        public virtual string OnGetItemText(int item, int col)
        {
            return "";
        }

        IntPtr OnDoGetItemText(int item, int col)
        {
            wxString itemText = wxString.SafeNew(this.OnGetItemText(item, col));
            DisposableStringBox result = new DisposableStringBox(itemText);
            return result.wxObject;
        }

        /** <summary>Return the index of the icon of the designated item in the used image list.
         * Overload this for virtual lists.
         * 
         * This standard implementation will return an undefined index (-1)
         * for "do no show any item image".</summary>*/
        public virtual int OnGetItemImage(int item)
        {
            return -1;
        }
        int OnDoGetItemImage(int item)
        {
            return this.OnGetItemImage(item);
        }

        /** <summary>Return the index of the icon of the designated item and the designated column in the used image list.
         * Overload this for virtual lists.
         * 
         * This standard implementation will return an undefined index (-1)
         * for "do no show any item image".</summary>*/
        public virtual int OnGetItemColumnImage(int item, int col)
        {
            return -1;
        }
        int OnDoGetItemColumnImage(int item, int col)
        {
            return this.OnGetItemColumnImage(item, col);
        }

        public virtual ListItemAttr OnGetItemAttr(int item)
        {
            return null;
        }

        IntPtr OnDoGetItemAttr(int item)
        {
            ListItemAttr attr = this.OnGetItemAttr(item);
            return Object.SafePtr(attr);
        }
        #endregion

		//---------------------------------------------------------------------

		public bool GetColumn(int col, out ListItem item)
		{
			item = new ListItem();
			return wxListCtrl_GetColumn(wxObject, col, ref item.wxObject);
		}
		
		//---------------------------------------------------------------------

		public bool SetColumn(int col, ListItem item)
		{
			return wxListCtrl_SetColumn(wxObject, col, Object.SafePtr(item));
		}

		//---------------------------------------------------------------------

		public int GetColumnWidth(int col)
		{
			return wxListCtrl_GetColumnWidth(wxObject, col);
		}
		
		//---------------------------------------------------------------------

		public bool SetColumnWidth(int col, int width)
		{
			return wxListCtrl_SetColumnWidth(wxObject, col, width);
		}

        public bool SetColumnWidth(int col, SymbolicColumnWidth width)
        {
            return this.SetColumnWidth(col, (int)width);
        }

		//---------------------------------------------------------------------

		public int CountPerPage
		{
			get { return wxListCtrl_GetCountPerPage(wxObject); }
		}

		//---------------------------------------------------------------------

        /** <summary>Assigns the item corresponding to the ID, column, and property mask of <c>info</c> to <c>info</c>.
         * This is for compatibility to  wxWidgets only. Use the indexer if you prefer
         * a more convenient and more standard way to ask for items.
         * 
         * <c>info</c> will be loaded with all properties of item sharing ID and column
         * with <c>info</c> as designated by <c>info.Mask</c>.
         * </summary>
         */
		public bool GetItem(ListItem info)
		{
			return wxListCtrl_GetItem(wxObject, Object.SafePtr(info));
		}
		

        /** <summary>Assigns item <c>info</c> to the control.
         * This will change the properties of the item of this control sharing the ID
         * with <c>info</c>. The method will select those properties of <c>info</c> that are
         * compatible with the property mask of <c>info</c>.
         * This is for compatibility to  wxWidgets only. Use the indexer if you prefer
         * the standard way to set for items.
         * </summary>
         */
		public bool SetItem(ListItem info)
		{
			return wxListCtrl_SetItem(wxObject, Object.SafePtr(info));
		}

		public int SetItem(int index, int col, string label)
		{
			return SetItem(index, col, label, -1);
		}

        public int SetItem(int index, int col, string label, int imageId)
        {
            return this.SetItem(index, col, wxString.SafeNew(label), imageId);
        }
		public int SetItem(int index, int col, wxString label, int imageId)
		{
			return wxListCtrl_SetItem_By_Row_Col(wxObject, index, col, Object.SafePtr(label), imageId);
		}


		//---------------------------------------------------------------------

		public void SetItemText(int index, string label)
		{
            wxString wxLabel = new wxString(label);
			wxListCtrl_SetItemText(wxObject, index, wxLabel.wxObject);
		}
		
		//---------------------------------------------------------------------

		public string GetItemText(int item)
		{
			return new wxString(wxListCtrl_GetItemText(wxObject, item), true);
		}

		//---------------------------------------------------------------------

        /** <summary>Item state. Only the bits of the mask will be queried.</summary><remarks>
         * \verbatim
         if (listCtrl.GetItemState(3, ListItemState.SELECTED)==ListItemState.SELECTED)
            System.Diagnostics.Trace.WriteLine("Item 3 has been selected.");
         \endverbatim
         * </remarks>*/
        public ListItemState GetItemState(int item, ListItemState stateMask)
		{
			return (ListItemState)wxListCtrl_GetItemState(wxObject, item , (int)stateMask);
		}

        /** <summary>True iff all <c>flags</c> have been set for item <c>item</c>.
         * </summary>
         * <remarks>
         * Is equivalent to 
         * \verbatim
         this.GetItemState(item, flags)==flags
         \endverbatim
         * </remarks>
         */
        public bool IsSetItemStateFlag(int item, ListItemState flags)
        {
            return this.GetItemState(item, flags) == flags;
        }

        public bool SetItemState(int item, ListItemState state, ListItemState stateMask)
		{
			return wxListCtrl_SetItemState(wxObject, item, (int)state, (int)stateMask);
		}

		//---------------------------------------------------------------------

		public bool SetItemImage(int item, int image, int selImage)
		{
			return wxListCtrl_SetItemImage(wxObject, item, image, selImage);
		}

		//---------------------------------------------------------------------

		public ClientData GetItemData(int item)
		{
			return (ClientData)Object.FindObject(wxListCtrl_GetItemData(wxObject, item));
		}
		
		//---------------------------------------------------------------------

		public bool SetItemData(int item, ClientData data)
		{
            data.memOwn = false;
			return wxListCtrl_SetItemData(wxObject, item, Object.SafePtr(data));
		}
		
		//---------------------------------------------------------------------

		public bool SetItemData(int item, int data)
		{
			return this.SetItemData(item, new SystemObjectClientData(data));
		}

		//---------------------------------------------------------------------

		public bool GetItemRect(int item, out Rectangle rect, int code)
		{
			return wxListCtrl_GetItemRect(wxObject, item, out rect, code);
		}

		//---------------------------------------------------------------------

		public bool GetItemPosition(int item, out Point pos)
		{
			return wxListCtrl_GetItemPosition(wxObject, item, out pos);
		}
		
		//---------------------------------------------------------------------

		public bool SetItemPosition(int item, Point pos)
		{
			return wxListCtrl_SetItemPosition(wxObject, item, ref pos);
		}

		//---------------------------------------------------------------------

		public int ItemCount
		{
			get { return wxListCtrl_GetItemCount(wxObject); }
			set { wxListCtrl_SetItemCount(wxObject, value); }
		}
		
		//---------------------------------------------------------------------

		public int ColumnCount
		{
			get { return wxListCtrl_GetColumnCount(wxObject); }
		}
		
		//---------------------------------------------------------------------

		public void SetItemTextColour(int item, Colour col)
		{
			wxListCtrl_SetItemTextColour(wxObject, item, Object.SafePtr(col));
		}
		
		//---------------------------------------------------------------------

		public Colour GetItemTextColour(int item)
		{
			return new Colour(wxListCtrl_GetItemTextColour(wxObject, item), true);
		}

		//---------------------------------------------------------------------

		public void SetItemBackgroundColour(int item, Colour col)
		{
			wxListCtrl_SetItemBackgroundColour(wxObject, item, Object.SafePtr(col));
		}
		
		//---------------------------------------------------------------------

		public Colour GetItemBackgroundColour(int item)
		{
			return new Colour(wxListCtrl_GetItemBackgroundColour(wxObject, item), true);
		}

		//---------------------------------------------------------------------

		public int SelectedItemCount
		{
			get { return wxListCtrl_GetSelectedItemCount(wxObject); }
		}

        /** <summary>Returns a list of selected items.</summary>*/
        public System.Collections.Generic.ICollection<ListItem> SelectedItems
        {
            get
            {
                System.Collections.Generic.List<ListItem> result = new System.Collections.Generic.List<ListItem>();
                if (SelectedItemCount > 0)
                {
                    foreach (ListItem item in this)
                    {
                        if ((item.State & ListItemState.SELECTED) != ListItemState.DONTCARE)
                        {
                            result.Add(item);
                        }
                    }
                    return result;
                }
                else
                    return null;
            }
        }

		//---------------------------------------------------------------------

		public Colour TextColour
		{
			get { return new Colour(wxListCtrl_GetTextColour(wxObject), true); }
			set { wxListCtrl_SetTextColour(wxObject, Object.SafePtr(value)); }
		}

		//---------------------------------------------------------------------

		public int TopItem
		{
			get { return wxListCtrl_GetTopItem(wxObject); }
		}

		//---------------------------------------------------------------------

		public void SetSingleStyle(wx.WindowStyles style, bool add)
		{
			wxListCtrl_SetSingleStyle(wxObject, (uint)style, add);
		}
		
		//---------------------------------------------------------------------

		public int GetNextItem(int item, NEXT geometry, ListItemState state)
		{
			return wxListCtrl_GetNextItem(wxObject, item, (int)geometry, (int)state);
		}

		//---------------------------------------------------------------------

		public ImageList GetImageList(wxImageList which)
		{
			return (ImageList)FindObject(wxListCtrl_GetImageList(wxObject, (int)which), typeof(ImageList));
		}
		
		//---------------------------------------------------------------------

        /** <summary>Defines the image list to be used by instances of wx.ImageItem added to this list.</summary>
         * <param name="which"> defines which of the internal image lists will be set, e.g. by wx.wxImageList.wxIMAGE_LIST_SMALL.
         * </param>
         */
        public void SetImageList(ImageList imageList, wxImageList which)
		{
			wxListCtrl_SetImageList(wxObject, Object.SafePtr(imageList), (int)which);
		}
		
		//---------------------------------------------------------------------

		public bool Arrange(ListColumnFormat flag)
		{
			return wxListCtrl_Arrange(wxObject, (int)flag);
		}

		//---------------------------------------------------------------------

		public void ClearAll()
		{
			wxListCtrl_ClearAll(wxObject);
		}
		
		//---------------------------------------------------------------------

		public bool DeleteItem(int item)
		{
			return wxListCtrl_DeleteItem(wxObject, item);
		}
		
		//---------------------------------------------------------------------

		public bool DeleteAllItems()
		{
			return wxListCtrl_DeleteAllItems(wxObject);
		}
		
		//---------------------------------------------------------------------

		public bool DeleteAllColumns()
		{
			return wxListCtrl_DeleteAllColumns(wxObject);
		}
		
		//---------------------------------------------------------------------

		public bool DeleteColumn(int col)
		{
			return wxListCtrl_DeleteColumn(wxObject, col);
		}

		//---------------------------------------------------------------------

		public void EditLabel(int item)
		{
			wxListCtrl_EditLabel(wxObject, item);
		}

		//---------------------------------------------------------------------

        /** <summary>Ensures visibility of the designated item.</summary>*/
		public bool EnsureVisible(int item)
		{
			return wxListCtrl_EnsureVisible(wxObject, item);
		}

		//---------------------------------------------------------------------

        /** <summary>Gets and sets the item at the designated position.
         * If you assign an item using this indexer, the ID of this item
         * will change to <c>index</c>. The mask will also be set to wx.ListItemMask.ALL.
         * </summary>
         */
        public wx.ListItem this[int index]
        {
            get
            {
                ListItem result=new ListItem();
                result.Id=index;
                result.Mask = ListItemMask.ALL;
                this.GetItem(result);
                return result;
            }
            set
            {
                value.Id=index;
                value.Mask = ListItemMask.ALL;
                this.SetItem(value);
            }
        }

		public int FindItem(int start, string str, bool partial)
		{
            wxString wxStr = new wxString(str);
			return wxListCtrl_FindItem(wxObject, start, wxStr.wxObject, partial);
		}

		// TODO: Verify data
		public int FindItem(int start, ClientData data)
		{
			return wxListCtrl_FindItemData(wxObject, start, Object.SafePtr(data));
		}

		public int FindItem(int start, Point pt, int direction)
		{
			return wxListCtrl_FindItemPoint(wxObject, start, ref pt, direction);
		}

		//---------------------------------------------------------------------

		public ListHitTest HitTest(Point point, int flags)
		{
			return (ListHitTest)wxListCtrl_HitTest(wxObject, ref point, flags);
		}

		//---------------------------------------------------------------------

        /** <summary>This will change the Id of the provided items to the number of known items and then insert them.
         * This is a convenience method to append items at the end of the current item list without regarding
         * the ID of the items.</summary>*/
        public int AppendItemRow(params ListItem[] colItems)
        {
            foreach (ListItem colItem in colItems)
                colItem.Id = this.ItemCount;
            return this.InsertItemRow(colItems);
        }

        /** <summary>This will insert a new item assuming each of the arguments to represent a column value.
         * The first column item will be used for column 0, the second for column 1, and so forth.
         * The method will adjust the column attribute of the arguments.</summary>*/
        public int InsertItemRow(params ListItem[] colItems)
        {
            if (colItems != null && colItems.Length > 0)
            {
                colItems[0].Column = 0;
                int newIndex = this.InsertItem(colItems[0]);
                if (newIndex >= 0)
                {
                    int colIndex = 0;
                    foreach (ListItem colItem in colItems)
                    {
                        if (colIndex >= 1)
                        {
                            colItem.Column = colIndex;
                            this.SetItem(colItem);
                        }
                        ++colIndex;
                    }
                }
                return newIndex;
            }
            return -1;
        }

        /** <summary>Inserts an item and returns the index of the new item or -1 if insertion failed.</summary>*/
		public int InsertItem(ListItem info)
		{
            ClientData clientData = info.Data;
            if (clientData!= null)
                clientData.memOwn = false;
			return wxListCtrl_InsertItem(wxObject, Object.SafePtr(info));
		}

        /** <summary>Inserts an item and returns the index of the new item or -1 if insertion failed.</summary>*/
        public int InsertItem(int index, string label)
		{
            wxString wxLabel = new wxString(label);
			return wxListCtrl_InsertTextItem(wxObject, index, wxLabel.wxObject);
		}

        /** <summary>Inserts an item presenting an image and returns the index of the new item or -1 if insertion failed.</summary>*/
        public int InsertItem(int index, int imageIndex)
		{
			return wxListCtrl_InsertImageItem(wxObject, index, imageIndex);
		}

        /** <summary>Inserts an item presenting image and text label and returns the index of the new item or -1 if insertion failed.</summary>*/
        public int InsertItem(int index, string label, int imageIndex)
		{
            wxString wxLabel = new wxString(label);
			return wxListCtrl_InsertTextImageItem(wxObject, index, wxLabel.wxObject, imageIndex);
		}

		//---------------------------------------------------------------------
        
		public int InsertColumn(int col, ListItem info)
		{
			return wxListCtrl_InsertColumn(wxObject, col, Object.SafePtr(info));
		}

		public int InsertColumn(int col, string heading)
		{ 
			return InsertColumn(col, heading, wx.ListColumnFormat.LEFT, -1); 
		}
			
		public int InsertColumn(int col, string heading, wx.ListColumnFormat format, int width)
		{
            wxString wxHeading = new wxString(heading);
			return wxListCtrl_InsertTextColumn(wxObject, col, wxHeading.wxObject, (int)format, width);
		}

		//---------------------------------------------------------------------

        /** <summary>Scrolls the list control.
         * If in icon, small icon or report view mode, <c>dx</c> specifies the number of
         * pixels to scroll. If in list view mode, <c>dx</c> specifies the number of columns
         * to scroll. <c>dy</c> always specifies the number of pixels to scroll vertically.
         *
         * \b NB: This method is currently only implemented in the Windows version.
         * 
         * Try EnsureVisible().</summary>*/
		public bool ScrollList(int dx, int dy)
		{
			return wxListCtrl_ScrollList(wxObject, dx, dy);
		}

		//---------------------------------------------------------------------
		
        /** <summary>This only works in icon mode and returns an unspecific reactangle otherwise.</summary>*/
		public Rectangle ViewRect
		{
            get
            {
                Rectangle rect = new Rectangle();
                if ((this.StyleFlags & WindowStyles.LC_ICON) == WindowStyles.LC_ICON)
                {
                    wxListCtrl_GetViewRect(wxObject, ref rect);
                }
                return rect;
            }
		}
		
		//---------------------------------------------------------------------
		
		public void RefreshItem(int item)
		{
			wxListCtrl_RefreshItem(wxObject, item);
		}
		
		//---------------------------------------------------------------------
		
		public void RefreshItems(int itemFrom, int itemTo)
		{
			wxListCtrl_RefreshItems(wxObject, itemFrom, itemTo);
		}
		
		//-----------------------------------------------------------------------------

        /** <summary>This internal class converts from <c>cbSortItems</c> to <c>wxListCtrlCompare</c>.
         * </summary>
         */
        class SortCallback
        {
            public delegate int cbSortItems(IntPtr item1, IntPtr item2, int data);
            public cbSortItems CbSortItems;
            wxListCtrlCompare _fn;

            public SortCallback(wxListCtrlCompare fn)
            {
                this._fn = fn;
                this.CbSortItems = new cbSortItems(this.OnSortItems);
            }

            int OnSortItems(IntPtr item1, IntPtr item2, int data)
            {
                ClientData dataItem1 = (ClientData)Object.FindObject(item1, typeof(ClientData));
                ClientData dataItem2 = (ClientData)Object.FindObject(item2, typeof(ClientData));
                return _fn(dataItem1, dataItem2, data);
            }
        }
        

        /** <summary>Sort the contained list items with respect to <c>fn</c>.
         * Refer to remarks on <c>wxListCtrlCompare</c>.
         * </summary>
         */
		public bool SortItems(wxListCtrlCompare fn, int data)
		{
            SortCallback cb = new SortCallback(fn);
			bool retval = wxListCtrl_SortItems(wxObject, cb.CbSortItems, data);
			return retval;
		}

        /** <summary>A class comparing the client data of items.</summary>*/
        class ItemDataComparer : System.Collections.IComparer
        {
            System.Collections.IComparer _comparer;
            public ItemDataComparer(ListCtrl listCtrl, System.Collections.IComparer comparer)
            {
                this._comparer = comparer;
            }


            #region IComparer Member
            /** <summary>Expects the objects to be indices of items in the control and compares associated client data using the comparer.</summary>*/
            public int Compare(ClientData clientData1, ClientData clientData2, int sortData)
            {
                IComparable cmp1=null;
                if (clientData1 == null && clientData2 != null)
                    return -1;
                if (clientData1 == null && clientData2 == null)
                    return 0;
                if (clientData1 != null && clientData2 == null)
                    return 1;
                if (clientData1 is StringClientData)
                    cmp1 = ((StringClientData)clientData1).Data;
                else if (clientData1 is SystemObjectClientData && ((SystemObjectClientData)clientData1).Data is IComparable)
                    cmp1 = (IComparable)((SystemObjectClientData)clientData1).Data;
                object cmp2=null;
                if (clientData2 is StringClientData)
                    cmp2 = ((StringClientData)clientData2).Data;
                else if (clientData2 is SystemObjectClientData && ((SystemObjectClientData)clientData2).Data is IComparable)
                    cmp2 = (IComparable)((SystemObjectClientData)clientData2).Data;

                if (cmp1 == null && cmp2 != null)
                    return -1;
                if (cmp1 == null && cmp2 == null)
                    return 0;
                if (cmp1 != null && cmp2 == null)
                    return 1;
                return this._comparer.Compare(cmp1, cmp2);
            }

            /** <summary>Expects the objects to be instances of ClientData.</summary>*/
            public int Compare(object x, object y)
            {
                return this.Compare((ClientData) x, (ClientData) y, 0);
            }
            #endregion
        }

        /** <summary>Sort according to the order of client data as specified by the comparer.
         * This assumes that all items have assigned client data assigned and that this
         * data implements System.IComparable. Missing or non-comparable client data 
         * will be replaced by the item's name.</summary>*/
        public bool SortItemsAccordingToClientData(System.Collections.IComparer clientDataComparer)
        {
            ItemDataComparer itemComparer = new ItemDataComparer(this, clientDataComparer);
            return this.SortItems(new wxListCtrlCompare(itemComparer.Compare), 0);
        }

        //-----------------------------------------------------------------------------

		public event EventListener BeginDrag
		{
			add { AddCommandListener(Event.wxEVT_COMMAND_LIST_BEGIN_DRAG, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}
		
		//-----------------------------------------------------------------------------

		public event EventListener BeginRightDrag
		{
			add { AddCommandListener(Event.wxEVT_COMMAND_LIST_BEGIN_RDRAG, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}
		
		//-----------------------------------------------------------------------------

		public event EventListener BeginLabelEdit
		{
			add { AddCommandListener(Event.wxEVT_COMMAND_LIST_BEGIN_LABEL_EDIT, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}
		
		//-----------------------------------------------------------------------------

		public event EventListener EndLabelEdit
		{
			add { AddCommandListener(Event.wxEVT_COMMAND_LIST_END_LABEL_EDIT, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}
		
		//-----------------------------------------------------------------------------

		public event EventListener ItemDelete
		{
			add { AddCommandListener(Event.wxEVT_COMMAND_LIST_DELETE_ITEM, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}
		
		//-----------------------------------------------------------------------------

		public event EventListener ItemDeleteAll
		{
			add { AddCommandListener(Event.wxEVT_COMMAND_LIST_DELETE_ALL_ITEMS, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

        //-----------------------------------------------------------------------------

		public event EventListener ItemSelect
		{
			add { AddCommandListener(Event.wxEVT_COMMAND_LIST_ITEM_SELECTED, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}
		
		//-----------------------------------------------------------------------------

		public event EventListener ItemDeselect
		{
			add { AddCommandListener(Event.wxEVT_COMMAND_LIST_ITEM_DESELECTED, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}
		
		//-----------------------------------------------------------------------------

		public event EventListener ItemActivate
		{
			add { AddCommandListener(Event.wxEVT_COMMAND_LIST_ITEM_ACTIVATED, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}
		
		//-----------------------------------------------------------------------------

		public event EventListener ItemFocus
		{
			add { AddCommandListener(Event.wxEVT_COMMAND_LIST_ITEM_FOCUSED, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}
		
		//-----------------------------------------------------------------------------

		public event EventListener ItemMiddleClick
		{
			add { AddCommandListener(Event.wxEVT_COMMAND_LIST_ITEM_MIDDLE_CLICK, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}
		
		//-----------------------------------------------------------------------------

		public event EventListener ItemRightClick
		{
			add { AddCommandListener(Event.wxEVT_COMMAND_LIST_ITEM_RIGHT_CLICK, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}
		
		//-----------------------------------------------------------------------------

		public override event EventListener KeyDown
		{
			add { AddCommandListener(Event.wxEVT_COMMAND_LIST_KEY_DOWN, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}
		
		//-----------------------------------------------------------------------------

		public event EventListener Insert
		{
			add { AddCommandListener(Event.wxEVT_COMMAND_LIST_INSERT_ITEM, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}
		
		//-----------------------------------------------------------------------------

		public event EventListener ColumnClick
		{
			add { AddCommandListener(Event.wxEVT_COMMAND_LIST_COL_CLICK, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}
		
		//-----------------------------------------------------------------------------

		public event EventListener ColumnRightClick
		{
			add { AddCommandListener(Event.wxEVT_COMMAND_LIST_COL_RIGHT_CLICK, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}
		
		//-----------------------------------------------------------------------------

		public event EventListener ColumnBeginDrag
		{
			add { AddCommandListener(Event.wxEVT_COMMAND_LIST_COL_BEGIN_DRAG, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}
		
		//-----------------------------------------------------------------------------

		public event EventListener ColumnDragging
		{
			add { AddCommandListener(Event.wxEVT_COMMAND_LIST_COL_DRAGGING, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}
		
		//-----------------------------------------------------------------------------

		public event EventListener ColumnEndDrag
		{
			add { AddCommandListener(Event.wxEVT_COMMAND_LIST_COL_END_DRAG, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}
		
		//-----------------------------------------------------------------------------

		public event EventListener CacheHint
		{
			add { AddCommandListener(Event.wxEVT_COMMAND_LIST_CACHE_HINT, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

        #region IEnumerable<ListItem> Member
        /** <summary>Enumerator on list items.
         * This is an alternative, more C# like interface to wx.ListCtrl.GetNextItem().
         * </summary>
         */
        public class ItemEnumerator : System.Collections.Generic.IEnumerator<ListItem>
        {
            #region State
            int _pos=-1;
            wx.ListCtrl _ctrl;
            wx.ListItemState _stateFilter = wx.ListItemState.DONTCARE;
            wx.ListCtrl.NEXT _direction = wx.ListCtrl.NEXT.ALL;
            #endregion

            #region CTor
            /** <summary>Iterates all nodes.
             * </summary>
             */
            public ItemEnumerator(wx.ListCtrl ctrl)
            {
                this._ctrl = ctrl;
            }

            /** <summary>Iterates all nodes complying with <c>stateFilter</c>.
             * </summary>
             */
            public ItemEnumerator(wx.ListCtrl ctrl, wx.ListItemState stateFilter)
            {
                this._ctrl = ctrl;
                this._stateFilter = stateFilter;
            }

            public ItemEnumerator(wx.ListCtrl ctrl, wx.ListItemState stateFilter, wx.ListCtrl.NEXT direction)
            {
                this._ctrl = ctrl;
                this._stateFilter = stateFilter;
                this._direction = direction;
            }
            #endregion

            #region IEnumerator<ListItem> Member
            public ListItemState StateFilter { get { return this._stateFilter; } }
            public ListCtrl.NEXT Direction { get { return this._direction; } }

            public ListItem  Current
                {
	                get 
                    {
                        if (this._pos >= 0)
                        {
                            return this._ctrl[this._pos];
                        }
                        return null;
                    }
                }

            #endregion

            #region IDisposable Member
            public void  Dispose()
            {
            }
            #endregion

            #region IEnumerator Member
            object  System.Collections.IEnumerator.Current
            {
	            get { return this.Current; }
            }

            public bool  MoveNext()
            {
                this._pos = this._ctrl.GetNextItem(this._pos, this._direction, this._stateFilter);
                return this._pos!=-1;
            }

            public void  Reset()
            {
                this._pos = -1; ;
            }
            #endregion
        }

        /** <summary>Returns an enumeration of all nodes.
         * Refer to ListCtrlEnumerator.</summary>*/
        public System.Collections.Generic.IEnumerator<ListItem> GetEnumerator()
        {
            return new ItemEnumerator(this);            
        }
        #endregion

        #region IEnumerable Member

        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            throw new Exception("The method or operation is not implemented.");
        }

        #endregion
    }
	
	//---------------------------------------------------------------------

	public class ListEvent : Event 
	{
		[DllImport("wx-c")] static extern IntPtr wxListEvent_ctor(int commandType, int id);
		[DllImport("wx-c")] static extern IntPtr wxListEvent_GetItem(IntPtr self);
		[DllImport("wx-c")] static extern IntPtr wxListEvent_GetLabel(IntPtr self);
		[DllImport("wx-c")] static extern int   wxListEvent_GetIndex(IntPtr self);
		[DllImport("wx-c")] static extern int    wxListEvent_GetKeyCode(IntPtr self);
		[DllImport("wx-c")] static extern int    wxListEvent_GetColumn(IntPtr self);
		[DllImport("wx-c")] static extern void   wxListEvent_GetPoint(IntPtr self, ref Point pt);
		[DllImport("wx-c")] static extern IntPtr wxListEvent_GetText(IntPtr self);
		[DllImport("wx-c")] static extern int wxListEvent_GetImage(IntPtr self);
		[DllImport("wx-c")] static extern IntPtr wxListEvent_GetData(IntPtr self);
		[DllImport("wx-c")] static extern int wxListEvent_GetMask(IntPtr self);
		[DllImport("wx-c")] static extern int wxListEvent_GetCacheFrom(IntPtr self);
		[DllImport("wx-c")] static extern int wxListEvent_GetCacheTo(IntPtr self);
		[DllImport("wx-c")] static extern bool wxListEvent_IsEditCancelled(IntPtr self);
		[DllImport("wx-c")] static extern void wxListEvent_SetEditCanceled(IntPtr self, bool editCancelled);
		[DllImport("wx-c")] static extern void wxListEvent_Veto(IntPtr self);
		[DllImport("wx-c")] static extern void wxListEvent_Allow(IntPtr self);
		[DllImport("wx-c")] static extern bool wxListEvent_IsAllowed(IntPtr self);			
		
		//---------------------------------------------------------------------
       
		public ListEvent(IntPtr wxObject)
			: base(wxObject) { }
			
		public ListEvent(int commandType, int id)
			: base(wxListEvent_ctor(commandType, id)) { }

		//-----------------------------------------------------------------------------

		public string Label
		{
			get { return new wxString(wxListEvent_GetLabel(wxObject), true); }
		}

		//-----------------------------------------------------------------------------
       
		public int KeyCode
		{
			get { return wxListEvent_GetKeyCode(wxObject); }
		}
		
		//---------------------------------------------------------------------
	
		public int Index
		{
			get { return wxListEvent_GetIndex(wxObject); }
		}
		
		//---------------------------------------------------------------------
       
		public ListItem Item
		{
			get { return new ListItem(wxListEvent_GetItem(wxObject)); }
		}
		
		//---------------------------------------------------------------------
    
		public int Column
		{
			get { return wxListEvent_GetColumn(wxObject); }
		}
		
		//---------------------------------------------------------------------
    
		public Point Point
		{
			get { 
				Point pt = new Point();
				wxListEvent_GetPoint(wxObject, ref pt);
				return pt;
			}
		}
		
		//---------------------------------------------------------------------
    
		public string Text
		{
			get { return new wxString(wxListEvent_GetText(wxObject), true); }
		}
		
		//---------------------------------------------------------------------
	
		public int Image
		{
			get { return wxListEvent_GetImage(wxObject); }
		}
		
		//---------------------------------------------------------------------
	
        /** <summary>Returns the client data that has been associated with the item.</summary>*/
		public ClientData Data
		{
			get { return (ClientData)Object.FindObject(wxListEvent_GetData(wxObject)); }
		}
		
		//---------------------------------------------------------------------
	
		public ListItemMask Mask
		{
			get { return (ListItemMask)wxListEvent_GetMask(wxObject); }
		}
		
		//---------------------------------------------------------------------
	
		public int CacheFrom
		{
			get { return wxListEvent_GetCacheFrom(wxObject); }
		}
		
		//---------------------------------------------------------------------
	
		public int CacheTo
		{
			get { return wxListEvent_GetCacheTo(wxObject); }
		}
		
		//---------------------------------------------------------------------
	
		public bool EditCancelled
		{
			get { return wxListEvent_IsEditCancelled(wxObject); }
			set { wxListEvent_SetEditCanceled(wxObject, value); }
		}
		
		//-----------------------------------------------------------------------------		
		
		public void Veto()
		{
			wxListEvent_Veto(wxObject);
		}
		
		//-----------------------------------------------------------------------------
		
		public void Allow()
		{
			wxListEvent_Allow(wxObject);
		}
		
		//-----------------------------------------------------------------------------
		
		public bool Allowed
		{
			get { return wxListEvent_IsAllowed(wxObject); }
		}								
	}

	//-----------------------------------------------------------------------------

	public class ListView : ListCtrl
	{
		[DllImport("wx-c")] static extern IntPtr wxListView_ctor();
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxListView_Create(IntPtr self, IntPtr parent, int id, int posX, int posY, int width, int height, uint style, IntPtr validator, IntPtr name);
		[DllImport("wx-c")] static extern void wxListView_Select(IntPtr self, int n, bool on);
		[DllImport("wx-c")] static extern void wxListView_Focus(IntPtr self, int index);
		[DllImport("wx-c")] static extern int  wxListView_GetFocusedItem(IntPtr self);
		[DllImport("wx-c")] static extern int  wxListView_GetNextSelected(IntPtr self, int item);
		[DllImport("wx-c")] static extern int  wxListView_GetFirstSelected(IntPtr self);
        [return: MarshalAs(UnmanagedType.U1)]
        [DllImport("wx-c")]
        static extern bool wxListView_IsSelected(IntPtr self, int index);
		[DllImport("wx-c")] static extern void wxListView_SetColumnImage(IntPtr self, int col, int image);
		[DllImport("wx-c")] static extern void wxListView_ClearColumnImage(IntPtr self, int col);

		//-----------------------------------------------------------------------------

		public ListView(IntPtr wxObject)
			: base(wxObject) { }

		public ListView()
			: base(wxListView_ctor()) { }

		public ListView(Window parent)
            : this(parent, Window.UniqueID, wxDefaultPosition, wxDefaultSize, wx.WindowStyles.LC_REPORT, null) { }

		public ListView(Window parent, int id)
            : this(parent, id, wxDefaultPosition, wxDefaultSize, wx.WindowStyles.LC_REPORT, null) { }

		public ListView(Window parent, int id, Point pos)
            : this(parent, id, pos, wxDefaultSize, wx.WindowStyles.LC_REPORT, null) { }

		public ListView(Window parent, int id, Point pos, Size size)
            : this(parent, id, pos, size, wx.WindowStyles.LC_REPORT, null) { }

		public ListView(Window parent, int id, Point pos, Size size, wx.WindowStyles style)
			: this(parent, id, pos, size, style, null) { }

		public ListView(Window parent, int id, Point pos, Size size, wx.WindowStyles style, string name)
			: base(wxListView_ctor())
		{
			if (!Create(parent, id, pos, size, style, name))
			{
				throw new InvalidOperationException("Failed to create ListView");
			}
		}
		
		//---------------------------------------------------------------------
		// ctors with self created id
		
		public ListView(Window parent, Point pos)
            : this(parent, Window.UniqueID, pos, wxDefaultSize, wx.WindowStyles.LC_REPORT, null) { }

		public ListView(Window parent, Point pos, Size size)
            : this(parent, Window.UniqueID, pos, size, wx.WindowStyles.LC_REPORT, null) { }

		public ListView(Window parent, Point pos, Size size, wx.WindowStyles style)
			: this(parent, Window.UniqueID, pos, size, style, null) { }

		public ListView(Window parent, Point pos, Size size, wx.WindowStyles style, string name)
			: this(parent, Window.UniqueID, pos, size, style, name) {}

		//-----------------------------------------------------------------------------

		public new bool Create(Window parent, int id, Point pos, Size size, wx.WindowStyles style, string name)
		{
            wxString wxName = new wxString(name);
			return wxListView_Create(wxObject, Object.SafePtr(parent), id, pos.X, pos.Y, size.Width, size.Height, (uint)style, IntPtr.Zero, wxName.wxObject);
		}

		//-----------------------------------------------------------------------------

		public void Select(int n)
		{
			Select(n, true);
		}

		public void Select(int n, bool on)
		{
			wxListView_Select(wxObject, n, on);
		}

		//-----------------------------------------------------------------------------

		public void Focus(int index)
		{
			wxListView_Focus(wxObject, index);
		}

		//-----------------------------------------------------------------------------

		public int FocusedItem
		{
			get { return wxListView_GetFocusedItem(wxObject); }
		}

		//-----------------------------------------------------------------------------

		public int GetNextSelected(int item)
		{
			return wxListView_GetNextSelected(this.wxObject, item);
		}

		//-----------------------------------------------------------------------------

		public int FirstSelected
		{
			get { return wxListView_GetFirstSelected(this.wxObject); }
		}

		//-----------------------------------------------------------------------------

		public bool IsSelected(int index)
		{
			return wxListView_IsSelected(wxObject, index);
		}

		//-----------------------------------------------------------------------------

		public void SetColumnImage(int col, int image)
		{
			wxListView_SetColumnImage(wxObject, col, image);
		}

		//-----------------------------------------------------------------------------

		public void ClearColumnImage(int col)
		{
			wxListView_ClearColumnImage(wxObject, col);
		}
	}
}
