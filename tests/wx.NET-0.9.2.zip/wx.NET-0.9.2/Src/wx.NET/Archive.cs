//-----------------------------------------------------------------------------
// wx.NET - Archive.cs
//
// Wrapper for wxArchiveInputStream and wxArchiveOutputStream.
//
// Written by Harald Meyer auf'm Hofe
// (C) 2006 by Harald Meyer auf'm Hofe
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: Archive.cs,v 1.24 2010/05/08 19:51:26 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Runtime.InteropServices;
using System.Text;
using System.IO;
using System.Reflection;
using System.Collections;
using System.Diagnostics;
using wx;
using wx.FileSys;

/** This namespace contains classes to deal with  wxWidgets ZIP packer.</summary><remarks>
 * Refer to \ref archive_formats_such_as_zip.*/
namespace wx.Archive
{
        /** <summary>Internal base class for writing or reading into a ZIP stream.
         *</summary>*/
    internal class ZipStream : Stream
    {
        #region C API
        #endregion
        #region CTor
        internal ZipStream()
        {
        }
        #endregion

        #region Enumerations
        protected enum wxSeekMode
        {
            wxFromStart,
            wxFromCurrent,
            wxFromEnd
        }
        #endregion

        #region Public Properties
        public override bool CanSeek { get { return false; } }
        public override bool CanWrite { get { return false; } }
        public override bool CanRead { get { return false; } }
        /** <summary>This is not supported.
         *</summary>*/
        public override long Length { get { throw new NotSupportedException(); } }
        /** <summary>This is not supported.
         *</summary>*/
        public override long Position
        {
            get { throw new NotSupportedException(); }
            set { throw new NotSupportedException(); }
        }
        #endregion

        #region Public Methods
        /** <summary>This is not supported.
         *</summary>*/
        public override long Seek(long offset, SeekOrigin origin)
        {
            throw new NotSupportedException();
        }
        /** <summary>This is not supported.
         *</summary>*/
        public override void SetLength(long value)
        {
            throw new NotSupportedException();
        }
        public override int Read(byte[] buffer, int offset, int count)
        {
            throw new Exception("The method or operation is not implemented.");
        }
        public override void Write(byte[] buffer, int offset, int count)
        {
            throw new Exception("The method or operation is not implemented.");
        }
        public override void Flush()
        {
        }
        #endregion
    }

    /** <summary>Describes an entry of an archive.</summary><remarks>
     * An entry is a file included into an archive. Instances of this class
     * are used as a key to denote particular files for reading and on the
     * other hand provide meta information on the file as far as this
     * information has been accessable.
     * 
     * Generate instances by wx.ArchiveInput.
     * 
     * \ref archive_formats_such_as_zip</remarks>*/
    public class ArchiveEntry : wx.Object
    {
        #region C API
        [DllImport("wx-c")]
        static extern void wxArchiveEntry_SetDatetime(IntPtr self, IntPtr dateTime);
        [DllImport("wx-c")]
        static extern IntPtr wxArchiveEntry_GetDatetime(IntPtr self);
        [DllImport("wx-c")]
        static extern IntPtr wxArchiveEntry_GetInternalName(IntPtr self);
        [DllImport("wx-c")]
        static extern IntPtr wxArchiveEntry_GetName(IntPtr self);
        [DllImport("wx-c")]
        static extern void wxArchiveEntry_SetName(IntPtr self, IntPtr name);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxArchiveEntry_IsDir(IntPtr self);
        [DllImport("wx-c")]
        static extern void wxArchiveEntry_SetIsDir(IntPtr self, bool value);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxArchiveEntry_IsReadOnly(IntPtr self);
        [DllImport("wx-c")]
        static extern void wxArchiveEntry_SetIsReadOnly(IntPtr self, bool value);
        [DllImport("wx-c")]
        static extern int wxArchiveEntry_Offset(IntPtr self);
        [DllImport("wx-c")]
        static extern int wxArchiveEntry_GetSize(IntPtr self);
        [DllImport("wx-c")]
        static extern void wxArchiveEntry_SetSize(IntPtr self, int size);
        #endregion

        #region Types, Enumerations
        /// <summary>
        /// The type of the archive - compression mode.
        /// </summary>
        public enum ArchiveType
        {
            /// <summary>
            /// Uses Zip compression
            /// </summary>
            Zip
        };
        #endregion
        #region Internal Helpers
        /** <summary>Conludes the archive type from the file name.
         * Uses Zip by default.
         *</summary>*/
        internal static ArchiveType TypeFromName(string filename)
        {
            return ArchiveType.Zip;
        }

        /** <summary>Conludes the archive type from the file name.
         * Uses Zip by default.
         *</summary>*/
        internal static ArchiveType TypeFromName(Uri filename)
        {
            return ArchiveType.Zip;
        }
        #endregion
        #region Public Properties
        /** <summary>Modifcation time.
         *</summary>*/
        public DateTime DateTime
        {
            get
            {
                return new wxDateTime(wxArchiveEntry_GetDatetime(wxObject));
            }
            set
            {
                wxArchiveEntry_SetDatetime(wxObject, Object.SafePtr((wxDateTime)value));
            }
        }

        /** <summary>The internal representation of the file name of this entry.
         * Use this to implement portable comparisons.
         *</summary>*/
        public string InternalName
        {
            get
            {
                return new wxString(wxArchiveEntry_GetInternalName(wxObject));
            }
        }

        /** <summary>The file name of this entry in native format.
         * This can be read and set.
         * 
         * If this is a directory entry, (i.e. if IsDir() is true) then
         * Name() returns the name with a trailing path separator.
         * Similarly, setting a name with a trailing path separator
         * sets IsDir().
         *</summary>*/
        public string Name
        {
            get
            {
                return new wxString(wxArchiveEntry_GetName(wxObject));
            }
            set
            {
                wxArchiveEntry_SetName(wxObject, (new wxString(value)).wxObject);
            }
        }

        /** <summary>True iff this represents a directory.
         *</summary>*/
        public bool IsDir
        {
            get
            {
                return wxArchiveEntry_IsDir(wxObject);
            }
            set
            {
                wxArchiveEntry_SetIsDir(wxObject, value);
            }
        }

        public bool IsReadOnly
        {
            get
            {
                return wxArchiveEntry_IsReadOnly(wxObject);
            }
            set
            {
                wxArchiveEntry_SetIsReadOnly(wxObject, value);
            }
        }

        /** <summary>Returns a numeric value unique to the entry within the archive.
       *</summary>*/
        public int Offset
        {
            get
            {
                return wxArchiveEntry_Offset(wxObject);
            }
        }

        /** <summary>The size of the entry's data in bytes.
         *</summary>*/
        public int Size
        {
            get
            {
                return wxArchiveEntry_GetSize(wxObject);
            }
            set
            {
                wxArchiveEntry_SetSize(wxObject, value);
            }
        }
        #endregion
        #region CTor
        public ArchiveEntry(IntPtr wxObject)
            : base(wxObject)
        {
        }
        #endregion
    }

    /** <summary>Writing into an archive file type supported by  wxWidgets.</summary><remarks>
     *  wxWidgets supports reading, analyzing, and writing archive files. Currently
     * only ZIP archives are supported. Corresponding features are only partially
     * supported by the standard .NET framework since 2.0.
     * 
     * The interface of this class differs strongly from the  wxWidgets API since
     * this API shall be extendable to use standard .NET framework classes where
     * possible. Additionally, we cannot inherit from both, wx.Object and Stream.
     * 
     * \ref archive_formats_such_as_zip
     *</remarks>*/
    public class ArchiveOutput : wx.Object, IDisposable
    {
        /** <summary>Internal class for writing into a ZIP stream on an entry in the archive.
         *</summary>*/
        internal class ZipOutStream : ZipStream
        {
            #region C API
            [DllImport("wx-c")]
            static extern int wxArchiveOutputStream_Write(IntPtr self, byte[] buffer, int offset, int count);
            [DllImport("wx-c")]
            static extern void wxArchiveOutputStream_WriteByte(IntPtr self, byte value);
            [DllImport("wx-c")]
            static extern void wxArchiveOutputStream_CloseEntry(IntPtr self);
            #endregion
            #region State
            ArchiveOutput _output;
            #endregion
            #region CTor
            internal ZipOutStream(ArchiveOutput output)
            {
                _output = output;
            }
            #endregion

            #region Public Properties
            public override bool CanWrite { get { return true; } }
            #endregion

            #region Public Methods
            public override void WriteByte(byte value)
            {
                wxArchiveOutputStream_WriteByte(_output.wxObject, value);
            }
            public override void Write(byte[] buffer, int offset, int count)
            {
                wxArchiveOutputStream_Write(_output.wxObject, buffer, offset, count);
            }
            public override void Close()
            {
                wxArchiveOutputStream_CloseEntry(_output.wxObject);
                _output._streamOnEntry = null;
                base.Close();
            }
            #endregion
        }

        #region C API
        [DllImport("wx-c")]
        static extern IntPtr wxArchiveOutputStream_CTor(IntPtr filename, int type);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxArchiveOutputStream_PutNextEntryNow(IntPtr self, IntPtr name);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxArchiveOutputStream_PutNextEntry(IntPtr self, IntPtr name, IntPtr time);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxArchiveOutputStream_PutNextDirEntryNow(IntPtr self, IntPtr name);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxArchiveOutputStream_PutNextDirEntry(IntPtr self, IntPtr name, IntPtr time);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxArchiveOutputStream_Close(IntPtr self);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxArchiveOutput_CopyEntry(IntPtr self, IntPtr entry, IntPtr input);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxArchiveOutput_CopyArchiveMetaData(IntPtr self, IntPtr input);
        [DllImport("wx-c")]
        static extern int wxArchiveOutputStream_GetType(IntPtr self);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxArchiveOutputStream_IsOk(IntPtr self);
        #endregion
        #region State
        /** <summary>Stream for writing into an entry.
         * This is <c>null</c> if entry is closed.
         *</summary>*/
        ZipOutStream _streamOnEntry=null;
        #endregion
        #region CTOR / DTOR
        internal static string UriToFilename(Uri fileUri)
        {
            if (!fileUri.IsFile)
                throw new System.ArgumentException(string.Format(_("Expecting a URI describing a local file but got {0}."), fileUri));
            return fileUri.LocalPath;
        }

        internal ArchiveOutput(IntPtr objPtr)
            : base(objPtr)
        {
        }

        public ArchiveOutput(string filename)
            : this(filename, ArchiveEntry.TypeFromName(filename))
        {
        }

        public ArchiveOutput(string filename, ArchiveEntry.ArchiveType type)
            : this(new wxString(filename), type)
        {
        }

        static IntPtr SyncCTor(IntPtr filename, int type)
        {
            lock (DllSync)
            {
                return wxArchiveOutputStream_CTor(filename, type);
            }
        }
        public ArchiveOutput(wxString filename, ArchiveEntry.ArchiveType type)
            : this(SyncCTor(filename.wxObject, (int)type))
        {
        }

        /** <summary>This consumes an URI pointing at a local file.
         * Raises currently an <c>ArgumentException</c> if the argument is not a local file name.
         *</summary>*/
        public ArchiveOutput(Uri fileUri)
            : this(UriToFilename(fileUri), ArchiveEntry.TypeFromName(fileUri))
        {
        }
        /** <summary>This consumes an URI pointing at a local file.
         * Raises currently an <c>ArgumentException</c> if the argument is not a local file name.
         *</summary>*/
        public ArchiveOutput(Uri fileUri, ArchiveEntry.ArchiveType type)
            : this(UriToFilename(fileUri), type)
        {
        }

        override public void Dispose()
        {
            Close();
            base.Dispose();
        }
        #endregion

        #region Public Properties
        /** <summary>This is the stream to write into the current entry of the archive.
         * This is <c>null</c> if we do not have an opened entry.
         * Entries can be opened by PutNextEntry().
         *</summary>*/
        public Stream Out { get { return _streamOnEntry; } }
        public ArchiveEntry.ArchiveType Type { get { return (ArchiveEntry.ArchiveType)wxArchiveOutputStream_GetType(wxObject); } }
        public bool IsOk { get { return (bool)wxArchiveOutputStream_IsOk(wxObject); } }
        #endregion
        #region Public Methods
        /** <summary>Sets Out() to a fill a new entry of the provided name.
         * If Out() has been already non-null before, the previous stream
         * on the entry will be closed.
         *</summary>*/
        public bool PutNextEntry(string name)
        {
            if (_streamOnEntry != null) _streamOnEntry.Close();
            wxString nameWx=new wxString(name);
            bool result=wxArchiveOutputStream_PutNextEntryNow(wxObject, nameWx.wxObject);
            _streamOnEntry = new ZipOutStream(this);
            return result;
        }
        public bool PutNextEntry(string name, DateTime timestamp)
        {
            if (_streamOnEntry != null) _streamOnEntry.Close();
            bool result = wxArchiveOutputStream_PutNextEntry(wxObject, (new wxString(name)).wxObject, Object.SafePtr((wxDateTime)timestamp));
            _streamOnEntry = new ZipOutStream(this);
            return result;
        }

        public bool PutNextDirEntry(string name)
        {
            _streamOnEntry = null;
            return wxArchiveOutputStream_PutNextDirEntryNow(wxObject, (new wxString(name)).wxObject);
        }

        public bool PutNextDirEntry(string name, DateTime timestamp)
        {
            _streamOnEntry = null;
            wxString nameWx=new wxString(name);
            return wxArchiveOutputStream_PutNextDirEntry(wxObject, nameWx.wxObject, Object.SafePtr((wxDateTime)timestamp));
        }

        /** <summary>* Takes ownership of entry and uses it to create a new entry in the archive. Entry is then opened in the input stream stream and its contents copied to this stream.
         * For archive types which compress entry data, CopyEntry() is likely to be much more efficient than transferring the data using Read() and Write() since it will copy them without decompressing and recompressing them.
         * entry must be from the same archive file that stream is accessing. For non-seekable streams, entry must also be the last thing read from stream.
         *</summary>*/
        public bool CopyEntry(ArchiveEntry entry, ArchiveInput input)
        {
            return wxArchiveOutput_CopyEntry(wxObject, entry.wxObject, input.wxObject);
        }

        /** <summary>* Some archive formats have additional meta-data that applies to the
         * archive as a whole. For example in the case of zip there is a
         * comment, which is stored at the end of the zip file.
         * CopyArchiveMetaData() can be used to transfer such information
         * when writing a modified copy of an archive.
         *
         * Since the position of the meta-data can vary between the various
         * archive formats, it is best to call CopyArchiveMetaData() before
         * transferring the entries. The wx.ArchiveOutput will then
         * hold on to the meta-data and write it at the correct point in the
         * output file.
         *
         * When the input archive is being read from a non-seekable stream,
         * the meta-data may not be available when CopyArchiveMetaData()
         * is called, in which case the two streams set up a link and 
         * transfer the data when it becomes available.
         *</summary>*/
        public bool CopyArchiveMetaData(ArchiveInput input)
        {
            return wxArchiveOutput_CopyArchiveMetaData(wxObject, input.wxObject);
        }

        /** <summary>This closes the whole archive and returns true in case of success.
         *</summary>*/
        public bool Close()
        {
            return wxArchiveOutputStream_Close(wxObject);
        }
        #endregion    
}

/** \page archive_formats_such_as_zip Archive formats such as zip

The archive classes handle archive formats such as zip, tar, rar
and cab. Currently only the zip classes are included.
There are the following classes:
\li ArchiveInput: Providing input streams.
\li ArchiveOutput: Providing ouput streams.
\li ArchiveEntry: Holds meta-data for an entry (e.g. filename, timestamp, etc.)  

The classes are designed to handle archives on both seekable streams such as disk files, or non-seekable streams such as pipes and sockets (see \ref archives_on_non-seekable_streams).

\section creating_an_archive Creating an archive

Call ArchiveOutput.PutNextEntry() to create each new entry in the archive, then write the entry's data. Another call to PutNextEntry() closes the current entry and begins the next.
For example:
 \code
    wx.ArchiveOutput out = new wx.ArchiveOutput("test.zip");
    StreamWriter txt=new StreamWriter(out.Out);
    out.PutNextEntry("entry1.txt");
    txt.WriteLine("Some text for entry1");
    out.PutNextEntry(new Uri("subdir/entry2.txt").LocalPath);
    txt.WriteLine("Some text for subdir/entry2.txt");
\endcode

The name of each entry can be a full path, which makes it possible to
store entries in subdirectories.

\section extracting_an_archive Extracting an archive

\c wx.ArchiveInput.GetNextEntry() returns a pointer to entry object containing the
meta-data for the next entry in the archive (and gives away ownership).
Reading from the input stream \c wx.ArchiveInput. In then returns the entry's
data.

When there are no more entries, \c wx.ArchiveInput.GetNextEntry() returns
\c null \c wx.ArchiveInput.In also gets \c null.

\code
wx.ArchiveEntry entry;
wx.ArchiveInput in=new wx.ArchiveInput("test.zip");
for(entry = in.GetNextEntry();
    entry != null;
    entry = in.GetNextEntry())
{
   Console.Out.WriteLine(string.format("{0}\t{1}", entry.Name, entry.DateTime);
}
\endcode

\section modifying_an_archive Modifying an archive

To modify an existing archive, write a new copy of the archive to a new
file, making any necessary changes along the way and transferring any
unchanged entries using \c wx.ArchiveOutput.CopyEntry().
For archive types which compress entry data, CopyEntry() is likely to be
much more efficient than transferring the data using Stream.Read() and Stream.Write()
since it will copy them without decompressing and recompressing them.

In general modifications are not possible without rewriting the archive,
though it may be possible in some limited cases. Even then, rewriting the
archive is usually a better choice since a failure can be handled without
losing the whole archive.

For example to delete all entries matching the pattern "*.txt":
\code
wx.ArchiveInput in=new wx.ArchiveInput("test.zip");
wx.ArchiveOutput out=new wx.ArchiveOutput("test-txt.zip");
out.CopyArchiveMetaData(in);
for(wx.ArchiveEntry entry=in.GetNextEntry();
    entry != null;
    entry=in.GetNextEntry)
{
    if (!entry.Name.EndsWith("*.txt"))
       if (!out.CopyEntry(entry, in))
            break;
}
// close the input stream by releasing the pointer to it, do this
// before closing the output stream so that the file can be replaced
in.Close();

// you can check for success as follows
bool success = out.Close();
\endcode

\section looking_up_an_archive_entry_by_name Looking up an archive entry by name

To open just one entry in an archive, the most efficient way is to simply
search for it linearly by calling \c wx.ArchiveInput.GetNextEntry() until the
required entry is found. This works both for archives on seekable and
non-seekable streams.

The format of filenames in the archive is likely to be different from the
local filename format. For example zips and tars use unix style names,
with forward slashes as the path separator, and absolute paths are not
allowed. So if on Windows the file "C:\MYDIR\MYFILE.TXT" is stored,
then when reading the entry back \c wx.ArchiveEntry.Name will return "MYDIR\MYFILE.TXT".
The conversion into the internal format and back has lost some information.

So to avoid ambiguity when searching for an entry matching a local name,
it is better to convert the local name to the archive's internal format
and search for that:

\code
    // open the zip
    wx.ArchiveInput in("test.zip");

    // convert the local name we are looking for into the internal format
    wxString name = in.GetInternalName(localname);

    // call GetNextEntry() until the required internal name is found
    for(wx.ArchiveEntry entry=in.GetNextEntry();
        entry != null && entry.InternalName != name;
        entry=in.GetNextEntry())
    {
    }

    if (entry != null)
    {
        // read the entry's data...
    }
\endcode

To access several entries randomly, it is most efficient to transfer the
entire catalogue of entries to a container such as a Hashtable
then entries looked up by name can be opened using the
\c wx.ArchiveInput.OpenEntry() method.

\code
Hashtable catalogue=new Hashtable();
// open the zip
wx.ArchiveInput in("test.zip");
// load the zip catalog
for(wx.ArchiveEntry entry=in.GetNextEntry();
    entry != null;
    entry=in.GetNextEntry())
{
   catalogue.Add(entry.InternalName, entry);
}

// open an entry by name
if (catalogue.ContainsKey(in.GetInternalName(localname)))
{
    in.OpenEntry(catalogue[in.GetInternalName(localname)]);
    StreamReader reader=new StreamReader(in.In);
    // ... now read entry's data
}
\endcode

To open more than one entry simultaneously you need more than one underlying stream on the same archive:
\code
// opening another entry without closing the first requires another
// input stream for the same file
wxArchiveInput in2(_T("test.zip"));
if (catalogue.ContainsKey(in2.GetInternalName(localname)))
  zip2.OpenEntry(catalogue[in2.GetInternalName(localname))]);
\endcode


\section archives_on_non-seekable_streams Archives on non-seekable streams

In general, handling archives on non-seekable streams is done in the same way as for seekable streams, with a few caveats.
The main limitation is that accessing entries randomly using OpenEntry() is not possible, the entries can only be accessed sequentially in the order they are stored within the archive.
For each archive type, there will also be other limitations which will depend on the order the entries' meta-data is stored within the archive. These are not too difficult to deal with,
and are outlined below.

\subsection putnextentry_and_the_entry_size PutNextEntry and the entry size

When writing archives, some archive formats store the entry size before the entry's data (tar has this limitation, zip doesn't). In this case the entry's size must be passed to wx.ArchiveOutput.PutNextEntry() or an error occurs.
This is only an issue on non-seekable streams, since otherwise the archive output stream can seek back and fix up the header once the size of the entry is known.
For generic programming, one way to handle this is to supply the size whenever it is known, and rely on the error message from the output stream when the operation is not supported.

\section getnextentry_and_the_weak_reference_mechanism GetNextEntry and the weak reference mechanism

Some archive formats do not store all an entry's meta-data before the entry's data (zip is an example). In this case, when reading from a non-seekable stream, GetNextEntry() can only return a partially populated wxArchiveEntry object - not all the fields are set.
The input stream then keeps a weak reference to the entry object and updates it when more meta-data becomes available. A weak reference being one that does not prevent you from deleting the wxArchiveEntry object - the input stream only attempts to update it if it is still around.
The documentation for each archive entry type gives the details of what meta-data becomes available and when. For generic programming, when the worst case must be assumed, you can rely on all the fields of wxArchiveEntry being fully populated when
wx.ArchiveInput.GetNextEntry() returns, with the the following
exceptions:
\li wx.ArchiveEntry.GetSize():  Guaranteed to be available after the entry has been read to Eof(), or CloseEntry() has been called  
\li wx.ArchiveEntry.IsReadOnly():  Guaranteed to be available after the end of the archive has been reached, i.e. after GetNextEntry() returns NULL and Eof() is true  

This mechanism allows wx.ArchiveOutput.CopyEntry() to always fully preserve entries' meta-data. No matter what order order the meta-data occurs within the archive, the input stream will always have read it before the output stream must write it.

\section zip_archives_as_resource_container ZIP archives as resource container

You may use ZIP archives as a resource system using class ZipResource.

*/


/** <summary>Reading from an archive file type supported by  wxWidgets.
 *  wxWidgets supports reading, analyzing, and writing archive files. Currently
 * only ZIP archives are supported. Corresponding features are only partially
 * supported by the standard .NET framework since 2.0.
 * 
 * The interface of this class differs strongly from the  wxWidgets API since
 * this API shall be extendable to use standard .NET framework classes where
 * possible.
 *</summary>*/
    public class ArchiveInput : wx.Object, IDisposable
    {
        /** <summary>Internal class for writing into a ZIP stream on an entry in the archive.
         *</summary>*/
        internal class ZipInStream : ZipStream
        {
            #region C API
            [DllImport("wx-c")]
            static extern void wxArchiveInputStream_CloseEntry(IntPtr self);
            [DllImport("wx-c")]
            static extern int wxArchiveInputStream_Read(IntPtr self, byte[] buffer, int offset, int count);
            [DllImport("wx-c")]
            static extern int wxArchiveInputStream_ReadChar(IntPtr self);
            [DllImport("wx-c")]
            static extern int wxArchiveInputStream_GetSize(IntPtr self);
            [DllImport("wx-c")]
            static extern int wxArchiveInputStream_Tell(IntPtr self);
            [DllImport("wx-c")]
            [return:MarshalAs(UnmanagedType.U1)]
            static extern bool wxArchiveInputStream_IsSeekable(IntPtr self);
            [DllImport("wx-c")]
            static extern int wxArchiveInputStream_Seek(IntPtr self, int pos, wxSeekMode mode);
            #endregion
            #region State
            ArchiveInput _input;
            #endregion
            #region CTor
            internal ZipInStream(ArchiveInput input)
            {
                _input = input;
            }
            #endregion

            #region Public Properties
            public override bool CanRead { get { return true; } }
            #endregion

            #region Public Methods
            public override long Length
            {
                get
                {
                    int result=wxArchiveInputStream_GetSize(_input.wxObject);
                    return result;
                }
            }

            /** <summary>Returns <c>true</c> iff you may seek this stream.
             * This method currently relies on <c>IsSeekable()</c> if the archive
             * stream. Apparently, the ZIP streams do not implement this method
             * although they implement <c>Seek()</c>. Anyway, this will return <c>false</c>
             * to enable particular heuristics in the IOStreamFSHandler.
             * 
             * Image handlers of  wxWidgets want to seek.</summary>*/
            public override bool CanSeek
            {
                get
                {
                    return wxArchiveInputStream_IsSeekable(this._input.wxObject);
                }
            }

            public override long Seek(long offset, SeekOrigin origin)
            {
                wxSeekMode mode = wxSeekMode.wxFromCurrent;
                if (origin == SeekOrigin.Begin)
                    mode = wxSeekMode.wxFromStart;
                else if (origin == SeekOrigin.End)
                    mode = wxSeekMode.wxFromEnd;
                return wxArchiveInputStream_Seek(_input.wxObject, (int)offset, mode);
            }

            public override long Position
            {
                get
                {
                    int result = wxArchiveInputStream_Tell(_input.wxObject);
                    return result;
                }
                set
                {
                    throw new NotSupportedException();
                }
            }

            public override int  Read(byte[] buffer, int offset, int count)
            {
                return wxArchiveInputStream_Read(_input.wxObject, buffer, offset, count);
            }
            public override int ReadByte()
            {
                return wxArchiveInputStream_ReadChar(_input.wxObject);
            }
            public override void Close()
            {
                wxArchiveInputStream_CloseEntry(_input.wxObject);
                _input._streamOnEntry = null;
                base.Close();
            }
            #endregion
        }

        #region C API
        [DllImport("wx-c")]
        static extern IntPtr wxArchiveInputStream_CTorFromStream(IntPtr inputStream, int archiveType);
        [DllImport("wx-c")]
        static extern IntPtr wxArchiveInputStream_CTor(IntPtr filename, int archiveType);
        [DllImport("wx-c")]
        static extern IntPtr wxArchiveInputStream_GetNextEntry(IntPtr self);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxArchiveInputStream_OpenEntry(IntPtr self, IntPtr entry);
        [DllImport("wx-c")]
        static extern IntPtr wxArchiveEntry_ConvertIntoInternalName(IntPtr self, IntPtr localFilename);
        [DllImport("wx-c")]
        static extern int wxArchiveInputStream_GetType(IntPtr self);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxArchiveInputStream_IsOk(IntPtr self);
        #endregion
        #region State
        /** <summary>Stream for writing into an entry.
         * This is <c>null</c> if entry is closed.
         *</summary>*/
        ZipInStream _streamOnEntry=null;
        #endregion
        #region CTOR / DTOR
        internal static string UriToFilename(Uri fileUri)
        {
            if (!fileUri.IsFile)
                throw new System.ArgumentException(string.Format(_("Expecting a URI describing a local file but got {0}."), fileUri));
            return fileUri.LocalPath;
        }

        internal ArchiveInput(IntPtr objPtr)
            : base(objPtr)
        {
        }

        static IntPtr SyncCTorFromStream(IntPtr stream, int type)
        {
            lock (DllSync)
            {
                return wxArchiveInputStream_CTorFromStream(stream, type);
            }
        }

        /** <summary>Creates an archive input representation reading compressed data from the provided stream.
         * Please note, that this instance will take ownership of the native code instance wrapped by
         * the <c>wxInputStreamWrapper</c>.
         * </summary>*/
        internal ArchiveInput(wxInputStreamWrapper inputStream, ArchiveEntry.ArchiveType type)
            : this(SyncCTorFromStream(inputStream.wxObject, (int)type))
        {
            if (!inputStream.memOwn)
                throw new Exception("Cannot take ownership of already shared instance of input stream wrapper.");
            inputStream.memOwn=false; // wxObject takes ownership of the input stream.
        }

        /** <summary>Generate an instance reading compressed data from the provided stream.
         *</summary>*/
        public ArchiveInput(Stream inputStream, ArchiveEntry.ArchiveType type)
            : this(new wxInputStreamWrapper(inputStream), type)
        {
        }

        /** <summary>Generate an instance reading compressed data from the provided stream.
         * By default this will interpret the data as a ZIP archive.
         *</summary>*/
        public ArchiveInput(Stream inputStream)
            : this(new wxInputStreamWrapper(inputStream), ArchiveEntry.ArchiveType.Zip)
        {
        }

        public ArchiveInput(string filename)
            : this(filename, ArchiveEntry.TypeFromName(filename))
        {
        }

        public ArchiveInput(string filename, ArchiveEntry.ArchiveType type)
            : this(new wxString(filename), type)
        {
        }

        static IntPtr SyncCTor(IntPtr filename, int type)
        {
            lock (DllSync)
            {
                return wxArchiveInputStream_CTor(filename, type);
            }
        }
        public ArchiveInput(wxString filename, ArchiveEntry.ArchiveType type)
            : this(SyncCTor(filename.wxObject, (int)type))
          {
          }
        
        /** <summary>This consumes an URI pointing at a local file.
         * Raises currently an <c>ArgumentException</c> if the argument is not a local file name.
         *</summary>*/
        public ArchiveInput(Uri fileUri)
            : this(UriToFilename(fileUri), ArchiveEntry.TypeFromName(fileUri))
        {
        }
        /** <summary>This consumes an URI pointing at a local file.
         * Raises currently an <c>ArgumentException</c> if the argument is not a local file name.
         *</summary>*/
        public ArchiveInput(Uri fileUri, ArchiveEntry.ArchiveType type)
            : this(UriToFilename(fileUri), type)
        {
        }

        public override void Dispose()
        {
            Close();
            base.Dispose();
        }
        #endregion
        #region Public Properties
        /** <summary>This is the stream to read the current entry from.
         * This is <c>null</c> if all entries are closed (none has been opened).
         *</summary>*/
        public Stream In
        {
            get { return this._streamOnEntry; }
        }
        public ArchiveEntry.ArchiveType Type
        {
            get { return (ArchiveEntry.ArchiveType)wxArchiveInputStream_GetType(wxObject); } 
        }
        public bool IsOk { get { return wxArchiveInputStream_IsOk(wxObject); } }
        #endregion
        #region Public Methods
        /** <summary>* Closes the current entry if one is open, then reads the meta-data for
         * the next entry and returns it in a wxArchiveEntry object, giving away
         * ownership. Reading this wx.ArchiveInput.In then returns the entry's
         * data.
        *</summary>*/
        public ArchiveEntry GetNextEntry()
        {
            IntPtr result=wxArchiveInputStream_GetNextEntry(wxObject);
            if (result==IntPtr.Zero)
            {
                if (this._streamOnEntry!= null) this._streamOnEntry.Close();
                return null;
            }
            else
            {
                this._streamOnEntry=new ZipInStream(this);
                return (ArchiveEntry)FindObject(result, typeof(ArchiveEntry));
            }
        }

        /** <summary>* Closes the current entry if one is open, then opens the entry specified</summary><remarks>
         * by the wxArchiveEntry object.
         *
         * <c>entry</c> must be from the same archive file that this wx.ArchiveInput is reading,
         * and it must be reading it from a seekable stream.
         *
         * \ref looking_up_an_archive_entry_by_name</remarks>*/
        public bool OpenEntry(ArchiveEntry entry)
        {
            bool result = wxArchiveInputStream_OpenEntry(wxObject, entry.wxObject);
            if (result)
            {
                this._streamOnEntry = new ZipInStream(this);
            }
            else
            {
                this._streamOnEntry = null;
            }
            return result;
        }

        /** <summary>This closes In() if we have an open entry.
         *</summary>*/
        public void Close()
        {
            if (In != null) In.Close();
        }
        #endregion

        #region Static Public
        /** <summary>Returns the internal representation of <c>localFilename</c> in the current type of archive.
         * Note, that instances of this class may wrap archives of different type, so the internal
         * representation depends on the archive type.
         *</summary>*/
        public string GetInternalName(string localFilename)
        {
          wxString localFilenameWx=new wxString(localFilename);
          IntPtr result = wxArchiveEntry_ConvertIntoInternalName(this.wxObject, localFilenameWx.wxObject);
          //Trace.WriteLine(string.Format("GetInternalName: {0} in {1}", result, wxObject));
          return new wxString(result);
        }
        #endregion
    }

    /** \page page_ziprc_as_help_file_compiler ZipRC as help file compiler
     * \c ZipRC is the \e wx.NET tool for zipping files and use them as resources
     * accessed by class ZipResource. Additionally, this tool has also another important
     * area of application: Compilation of help files.
     * 
     * As many projects, \e wx.NET uses the \c doxygen tool to compile HTML help
     * files from source code. This tool already provides the declaration files
     * necessary to compile the result with Microsoft's help file compiler into
     * a CHM file. However, CHM has several drawbacks. On the one hand, it's not
     * portable since it heavily relies on Microsoft's Internet Explorer. On the
     * other hand, it is inherently unsafe, since pages may contain arbitrary 
     * internet accesses, browser scripts and Active X controls.
     * 
     * \e wxWidgets provides its own help file viewer based on its simple HTML
     * presentation facilities. This help file viewer already uses index and
     * content files that also fit Microsoft's help file compiler. These files
     * may be compiled with the HTML pages into a zip file that is usually called
     * HTB for "hyper text book". However,
     * \e wxWidgets' HTML presenter completely lacks CSS support. So, \c doxygen
     * output will only partially presented.
     * 
     * \c ZipRC.exe now is able to replace the style sheets as used by doxygen by
     * plain HTML presentation elements that also look fine in HTB browsers like
     * \e wx.NET's \c helpview.exe. Consider as an example the following CMD command
     * line starting ZipRC to compile the \e wx.NET manual.
     * 
     * \verbatim
     ..\Bin\ziprc.exe c wx.net.htb -n=y -d=Doxygen\Manual\html 
     \endverbatim
     * Letter \c c specifies the overall task to compile content into a ZIP archive.
     * \c wx.net.htb is the name of this archive.
     * \c -n=y specifies, that all HTML files shall be transformed into plain HTML
     * as fas as this is possible. \c -d=... specifies a directory name. All files
     * in this directory will be compiled into the archive. The result is the
     * \e wx.NET manual as shipped with the file releases.
     */

    /** <summary>An ArchiveInput used as a resource provider.</summary><remarks>
     * 
     * Refer also to \ref page_ziprc_as_help_file_compiler.
     * 
     * C# has a nice native resource system that only has two drawbacks:
     * Support for internationalization is less productive than the classical
     * gettext procedure and the visual development environment supports things
     * like images as resources only within Forms.
     * 
     * This class is meant as a very simple alternative. It cannot be used to retrieve
     * resources that have been linked into the application itself  but it can
     * serve as a replacement for satellite assemblies.
     * 
     * Call FindResource() or FindResourceFile() to get a stream
     * or a FSFile descriptor for accessing the content of a resource. These resource may either
     * be simply files within a certain directory, zipped directories, or resources embedded
     * into the manufest. 
     * 
     * Resources may be stored in different types of streams, either ZIP files, System.IO file streams,
     * or memory streams. Unfortunately, these types of streams differ with respect to some characteristics
     * that are used within  wxWidgets. Namely, especially the image handler presuppose streams
     * as data source that can seek. ZipResource is prepared to deal with this if you use the
     * methods ResourceFileCanSeek() and ResourceFileAppropriateType(). Refer to the remarks on
     * these methods for details. ResourceFileAppropriateType() forms the basis of the <c>zrs</c>://
     * file system protocol according to IOStreamFSHandler.
     * 
     * This class maintains a collection of archive files resp. instances of ArchiveEntry
     * that will be used for loading resources. Users of the class provide a resource name
     * an archive name. If not already analysed, the archive will be loaded and a stream
     * on the resource contents will be returned. Refer to FindResource() for details.
     * The main service of this class is to amend names of resources and archives with
     * the canonical name of the current locale. So, this class enables locale specific provision
     * of resources.
     * 
     * Resource archives will be found in the codebase path of the calling assembly, subdirectory
     * "zrs" or a subdirectory named with the canonical name of the current locale.
     * 
     * You may also use directories instead of archives.
     * 
     * Whenever a resource cannot be found in files, the manifest will be searched.
     * 
     * <em>What is loaded:</em>
     * A resource will be loaded on <tt>FindResource(archiveName, resourceName)</tt> or
     * <tt>FindResource(archiveName, resourceName, canonicalLocaleName)</tt>, where
     * \li <c>archiveName</c> is a filename of the archive
     * \li <c>resourceName</c> is the (local/native, not internal) filename of the resource, and
     * \li <c>canonicalLocateName</c> is something like "en", "en_UK", or "de_DE".
     * 
     * Resources will be preferably loaded from the resource system (a zipped resource file
     * added to the assembly by <c>csc.exe</c> option <c>/resource)</c> and then from the local file
     * system.
     * 
     * A missing locale name will be loaded from wx.Locale.
     * 
     * The method does not directly search for provided filenames for archive and resource but
     * produce derivated filenames for both using the canonical name of the locale as a parameter.
     * Possible locations of the archive also reflect prefixes as added by method AddCatalogLookupPrefix().
     * The code base directory of the calling assembly will also be considered as a prefix path.
     * 
     * For each prefix, a file <tt>directory/archive.zrs</tt> for locale "de_DE" will be loaded as one of the following
     * files (referring to the order as given below):
     * \li <tt>/prefix/zrs/de_DE/directory/archive_de_DE.zrs</tt>
     * \li <tt>/prefix/zrs/directory/archive_de_DE.zrs</tt>
     * \li <tt>/prefix/zrs/de_DE/directory/archive.zrs</tt>
     * \li <tt>/prefix/de_DE/directory/archive_de_DE.zrs</tt>
     * \li <tt>/prefix/directory/archive_de_DE.zrs</tt>
     * \li <tt>/prefix/de_DE/directory/archive.zrs</tt>
     * \li <tt>/prefix/zrs/de/directory/archive_de.zrs</tt>
     * \li <tt>/prefix/zrs/directory/archive_de.zrs</tt>
     * \li <tt>/prefix/zrs/de/directory/archive.zrs</tt>
     * \li <tt>/prefix/de/directory/archive_de.zrs</tt>
     * \li <tt>/prefix/directory/archive_de.zrs</tt>
     * \li <tt>/prefix/de/directory/archive.zrs</tt>
     * \li <tt>/prefix/directory/archive.zrs</tt>
     * \li <tt>/prefix/zrs/directory/archive.zrs</tt>
     *
     * Motivation: All path names including the name of a locale will be searched first. So,
     * systems can overload a neutrally localized resources by localized resources. The two final
     * paths the neutral paths (with respect to localization). When asking for the neutral resource
     * (example: <tt>FindResource(archiveName, resourceName, "")</tt>) only these two path names
     * will be searched.
     * 
     * The locale can ne specified within the path as well as within the filename. The latter
     * form may be used to avoid the effect that the usage of a particular file (as a localized
     * resource) depends only on its position in the directory tree.
     * 
     * Directory name <tt>zrs</tt> is used as a standard amendment to the prefix. Reason: Usually,
     * the code base of the calling assembly will be the only prefix. This is typically a <c>Bin</c>
     * directory already crowded with lots of files required on running the program. A system
     * designer may use a sub-directory <tt>zrs</tt> without any changes to the code to prevent
     * the files on resources to additionally appear directly in this directory.
     * 
     * Note, that each resource archive may also contain the same resource in several localizations,
     * because also a <c>resourceName</c> like "rdirectory/resource" is used to produce derivations.
     * \li <tt>de_DE/rdirectory/resource</tt>
     * \li <tt>rdirectory/de_DE/resource</tt>
     * \li <tt>de_DE/rdirectory/resource_de_DE</tt>
     * \li <tt>rdirectory/de_DE/resource_de_DE</tt>
     * \li <tt>de/rdirectory/resource</tt>
     * \li <tt>rdirectory/de/resource</tt>
     * \li <tt>de/rdirectory/resource_de</tt>
     * \li <tt>rdirectory/de_DE/resource_de</tt>
     * \li <tt>rdirectory/resource</tt>
     * 
     * The used derivation scheme may change from locale to locale. Lets assume for instance, that
     * locale "en" has been found in archive <tt>directory/archive.zrs</tt> in file entry
     * <tt>rdirectory/en/resource</tt>. The Germen localization may be shipped as another
     * file <tt>resource_de.zrs</tt> containing entry <tt>rdirectory/resource</tt>. Both
     * resources will be found although the English version of the resource has been added
     * to the neutral archive whereas the German version is in a perticularly localized archive.
     * 
     * A ZipResource file may be compiled and analyzed by program <c>ZipRC.exe</c> (refer to
     * directory <c>Utils)</c>. Call <c>ZipRC.exe</c> <c>-h</c> on a CMD.exe console to get 
     * information on using this program.
     * \verbatim
    C:\\wx.NET\\Bin> ZipRC.exe -h
    ZipRC 0.7.3 (c) 2006 wx.NET Team
    Generate ZIP archived resources .zrs.
    Synopsis: ZipRC.exe (compile | c | extract | e | verify | v) ARCHIVE_FILE {--help | -h | --CANONICAL_NAME | FILE | RCNAME=FILE}*
    compile/c: Compile archive file ARCHIVE_FILE
    extract/e: Extract files from ARCHIVE_FILE
    info/i: Information ARCHIVE_FILE and the specified files (search paths, comparison)
    --help/-h: PrintData this information.
    --CANONCAL_NAME e.g. --en|--de_DE: switch to the specified locale.
    FILE: compile or extract this file.
    RCFILE=FILE: compile FILE as RCFILE or extract RCFILE to FILE.
    \endverbatim
     *
     * Example: The current working directory contains the files <c>logo2.png</c>, <c>editDocGroups.html</c>, 
     * and <c>editDocGroups_de.html</c> where the last file is a German translation of the second one whereas
     * the icon <c>logo2.png</c> is neutral (with repsect to localization).
     * \verbatim
     ZipRC c test.zip wxnetlogo.png=logo2.png editDocGroups.html --de editDocGroups_de.html
     \endverbatim
     * generates a ZIP archive <c>test.zip</c>.
     * This archive contains <c>wxnetlogo.png</c> (a copy of the original file <c>logo2.png)</c> and <c>editDocGroups.html</c> in its root and <c>editDocGroups_de.html</c>
     * in sub-directory <c>de</c>. This is to indicate that the latter HTML file is a German translation whereas
     * the other files are considered neutral with respect to localization.
     *
     * The more interesting thing about ZipResource is of course reading the resource.
     * The application knows command <c>extract</c> to decompress the content. However, the application
     * also knows command <c>verify</c> to investigate the structure of a compiled archive and compare
     * the content with uncompressed files (for instance the original sources).
     * Back to the example:
     * \verbatim
     ZipRC v test.zip wxnetlogo.png=logo2.png editDocGroups.html --de editDocGroups_de.html
     \endverbatim
     * produces the following output:
     \verbatim
ZipRC 0.7.3 (c) 2006 wx.NET Team
1/4: Candidate test.zip existing as file containing:
   1: "wxnetlogo.png"<=>"wxnetlogo.png"
        28.10.2006 19:18:54 size 5215
   2: "editDocGroups.html"<=>"editDocGroups.html"
        28.10.2006 19:18:54 size 548
   3: "de/editDocGroups_de.html"<=>"deditDocGroups_de.html"
        28.10.2006 19:18:54 size 727
2/4: Candidate zrs\test.zip is unknown.
3/4: Candidate file:\C:\sf\wx.NET\Bin\test.zip is unknown.
4/4: Candidate file:\C:\sf\wx.NET\Bin\zrs\test.zip is unknown.
    \endverbatim
    The specified filename <c>test.zip</c> matches with archive file <c>test.zip</c> containing the listed
    files (with their local and internal names). The program has not been able to find archives
    corresponding to the rest of the derivated file names.
    \verbatim
Looking for resource wxnetlogo.png <=> file logo2.png, locale neutral in test.zip.
Derivations of the resource name:
1. wxnetlogo.png
Found in test.zip as wxnetlogo.png
Both files share the same content.
    \endverbatim
    File <c>logo2.png</c> has been found on the file system and has been successfully compared
    to <c>wxnetlogo.png</c> from the archive.
    \verbatim
Looking for resource editDocGroups.html <=> file editDocGroups.html, locale neutral in test.zip.
Derivations of the resource name:
1. editDocGroups.html
Found in test.zip as editDocGroups.html
Both files share the same content.
    \endverbatim
    <c>editDocGroups.html</c> has also been found and compared.
    \verbatim
Archive test.zip will be searched with locale <de> as:
1/16: 1. file:\C:\sf\wx.NET\Bin\de\test.zip has not been found.
2/16: 2. file:\C:\sf\wx.NET\Bin\zrs\test_de.zip has not been found.
3/16: 3. file:\C:\sf\wx.NET\Bin\zrs\de\test.zip has not been found.
4/16: 4. file:\C:\sf\wx.NET\Bin\zrs\de\test_de.zip has not been found.
5/16: 5. zrs\test_de.zip has not been found.
6/16: 6. test_de.zip has not been found.
7/16: 7. de\test_de.zip has not been found.
8/16: 8. zrs\de\test_de.zip has not been found.
9/16: 9. file:\C:\sf\wx.NET\Bin\test_de.zip has not been found.
10/16: 10. zrs\de\test.zip has not been found.
11/16: 11. de\test.zip has not been found.
12/16: 12. file:\C:\sf\wx.NET\Bin\de\test_de.zip has not been found.
13/16: 13. test.zip is an existing file containing:
   1: "wxnetlogo.png"<=>"wxnetlogo.png"
        28.10.2006 19:18:54 size 5215
   2: "editDocGroups.html"<=>"editDocGroups.html"
        28.10.2006 19:18:54 size 548
   3: "de/editDocGroups_de.html"<=>"deditDocGroups_de.html"
        28.10.2006 19:18:54 size 727
14/16: 14. zrs\test.zip has not been found.
15/16: 15. file:\C:\sf\wx.NET\Bin\test.zip has not been found.
16/16: 16. file:\C:\sf\wx.NET\Bin\zrs\test.zip has not been found.
    \endverbatim
    Switch to locale <c>de</c>. The program lists all derivated file names of <c>test.zip</c>
    and the contents of the archives found on the file system.
    \verbatim
Looking for resource editDocGroups_de.html <=> file editDocGroups_de.html, local
e de in test.zip.
Derivations of the resource name:
1. editDocGroups_de.html
2. \deditDocGroups_de.html
Found in test.zip as \deditDocGroups_de.html
Both files share the same content.
    \endverbatim
    Finally, the derivated resource names of <c>editDocGroups_de.html</c> are listed.
    One of these derivations
    <pre> \de\ditDocGroups_de.html </pre> can be found in <c>test.zip</c>.
    Both files have the same content.
    
    <em> Note, that also directories can be treated as resources.</em>
    Compiled resources are important for deployment, not development. So, class <c>ZipResource</c>
    treats directories the same way as archive files. Reconsider the verifier of program <c>ZipRC</c>.
    This time we will call this directly with the working directory as archived source.
    <code>
    ZipRC v . wxnetlogo.png=logo2.png editDocGroups.html --de editDocGroups_de.html
    </code>
    This produces the following output:
    \verbatim
ZipRC 0.7.3 (c) 2006 wx.NET Team
1/8: Candidate . exists as directory.
2/8: Candidate zrs\.zrs is unknown.
3/8: Candidate .zrs is unknown.
4/8: Candidate file:\C:\sf\wx.NET\Bin\ is unknown.
5/8: Candidate zrs\ is unknown.
6/8: Candidate file:\C:\sf\wx.NET\Bin\.zrs is unknown.
7/8: Candidate file:\C:\sf\wx.NET\Bin\zrs\.zrs is unknown.
8/8: Candidate file:\C:\sf\wx.NET\Bin\zrs\ is unknown.

Looking for resource wxnetlogo.png <=> file <logo2.png>, locale neutral in <.>.
Derivations of the resource name:
1. wxnetlogo.png
Cannot open resource <wxnetlogo.png> in <.>.
    \endverbatim
     * The program searches derivated archive names and recognizes \c "." to denote a directory.
     * The command line specified that source <c>logo2.png</c> has been renamed to <c>wxnetlogo.png</c>
     * in the resource file. However, since \c "." is exactly the directory of the sources,
     * <c>logo2.png</c> appears here with its original name so <c>wxnetlogo.png</c> cannot be found.
     * \verbatim
Looking for resource editDocGroups.html <=> file <editDocGroups.html>, locale neutral in <.>.
Derivations of the resource name:
1. editDocGroups.html
Found in <.> as <editDocGroups.html>
Directory as resource and reference refer to the same file C:\sf\wx.NET\Utils\Zi
pRCditDocGroups.html.
    \endverbatim
     * In contrast, the program has been able to find <c>editdocGroups.html</c> since the command
     * line didn't specify a renaming scheme here.
     * \verbatim
Archive . will be searched with locale <de> as:
1/32: 1. file:\C:\sf\wx.NET\Bin\de\.zrs has not been found.
2/32: 2. zrs\de\_de.zrs has not been found.
3/32: 3. file:\C:\sf\wx.NET\Bin\zrs\de\.zrs has not been found.
4/32: 4. file:\C:\sf\wx.NET\Bin\de\_de has not been found.
5/32: 5. file:\C:\sf\wx.NET\Bin\zrs\_de.zrs has not been found.
6/32: 6. zrs\_de.zrs has not been found.
7/32: 7. file:\C:\sf\wx.NET\Bin\zrs\_de has not been found.
8/32: 8. de\_de has not been found.
9/32: 9. zrs\de\.zrs has not been found.
10/32: 10. zrs\_de has not been found.
11/32: 11. zrs\de\_de has not been found.
12/32: 12. file:\C:\sf\wx.NET\Bin\de\_de.zrs has not been found.
13/32: 13. file:\C:\sf\wx.NET\Bin\_de.zrs has not been found.
14/32: 14. file:\C:\sf\wx.NET\Bin\zrs\de\ has not been found.
15/32: 15. file:\C:\sf\wx.NET\Bin\de\ has not been found.
16/32: 16. de\.zrs has not been found.
17/32: 17. zrs\de\ has not been found.
18/32: 18. file:\C:\sf\wx.NET\Bin\zrs\de\_de has not been found.
19/32: 19. _de has not been found.
20/32: 20. de\_de.zrs has not been found.
21/32: 21. _de.zrs has not been found.
22/32: 22. file:\C:\sf\wx.NET\Bin\_de has not been found.
23/32: 23. de\ has not been found.
24/32: 24. file:\C:\sf\wx.NET\Bin\zrs\de\_de.zrs has not been found.
25/32: 25. . is an existing directory.
26/32: 26. zrs\.zrs has not been found.
27/32: 27. .zrs has not been found.
28/32: 28. file:\C:\sf\wx.NET\Bin\ has not been found.
29/32: 29. zrs\ has not been found.
30/32: 30. file:\C:\sf\wx.NET\Bin\.zrs has not been found.
31/32: 31. file:\C:\sf\wx.NET\Bin\zrs\.zrs has not been found.
32/32: 32. file:\C:\sf\wx.NET\Bin\zrs\ has not been found.

Looking for resource editDocGroups_de.html <=> file <editDocGroups_de.html>, loc
ale de in <.>.
Derivations of the resource name:
1. editDocGroups_de.html
2. editDocGroups_de.html
Found in <.> as <editDocGroups_de.html>
Directory as resource and reference refer to the same file C:\sf\wx.NET\Utils\Zi
pRCditDocGroups_de.html.
     \endverbatim
     * Finally, also the localized HTML-text has been found. Please note, that
     * the compressed archive booked this file in a subdirectory directory for
     * locale <c>de</c> whereas \c "." is of a flat structure.
     * 
     * \b Motivation: Assume you develop an application \c "app.exe" involving several resource.
     * During development you want direct access to these resources in order to modify them.
     * So, you will probably check in a subdirectory <c>app</c> (or another name) containing all resources.
     * However, you will use <c>ZipRC</c> to compile file \c "app.zrs" containing all resources.
     * This file will be shiped with the executable code. The interesting thing is, that both
     * configurations of resources can be accessd by the same program code using ZipResource.
     *</remarks>*/
    public class ZipResource
    {
        #region State
        //! This will be used if the archive is in fact a directory.
        string _dirName = null;
        //! The name of the loaded archive.
        string _archiveName = null;
        //! This will be used instead if the archive is indeed an archive.
        ArchiveInput _src=null;
        IDictionary _internalNameToEntry=new Hashtable();
        class KeyArchiveName
        {
            string m_archiveName=".";
            string m_canonicalName="";
            string m_mainPrefix = "";

            /** <summary>Generates a key for the archive and the neutral locale.
             *</summary>*/
            public KeyArchiveName(string archiveName, string mainPrefix)
            {
                m_archiveName = archiveName;
                if (m_archiveName.Length == 0) m_archiveName = ".";
                m_canonicalName = "";
                m_mainPrefix = mainPrefix;
            }

            /** <summary>Generates a key for the derivatives of <c>archiveName</c> with the specified locale.
             *</summary>*/
            public KeyArchiveName(string archiveName, string canonicalName, string mainPrefix)
            {
                m_archiveName = archiveName;
                if (m_archiveName.Length==0) m_archiveName = ".";
                m_canonicalName = canonicalName;
                m_mainPrefix = mainPrefix;
            }

            public override bool Equals(object obj)
            {
                if (obj is KeyArchiveName)
                {
                    KeyArchiveName arg = (KeyArchiveName)obj;
                    bool result=m_mainPrefix== arg.m_mainPrefix
                        && m_archiveName == arg.m_archiveName
                        && m_canonicalName == arg.m_canonicalName;
                    //Trace.WriteLine(string.Format("Equals {0}=={1} is {2}", this, arg, result));
                    return result;
                }
                return false;
            }
            public override int GetHashCode()
            {
                int result=3*m_mainPrefix.GetHashCode()+2*m_archiveName.GetHashCode()+m_canonicalName.GetHashCode();
                //Trace.WriteLine(string.Format("HashCode {0} is {1}", this, result));
                return result;
            }
            public override string ToString()
            {
                return string.Format("KeyArchiveName({0}, {1}, {2})", m_archiveName, m_canonicalName, m_mainPrefix);
            }
        };
        /** <summary>This maps a KeyArchiveName to a list of derived archive names on the mentioned locale.
         *</summary>*/
        static IDictionary _archiveNameToDerivates = new Hashtable();
        /** <summary>This maps the local file name to the resource archive.
         *</summary>*/
        static IDictionary _archives = new Hashtable();
        static ArrayList _prefixes=new ArrayList();
        const string _stdSubdir = "zrs";
        #endregion
        #region Helpers
        /** <summary>Searches all derivates of <c>archiveName</c> whether they are an archive or a directory.
         * Returns the name of the first existing derivate.
         * \param archiveName is a filename of an archive. On missing extension, _stdSubdir() will be
         * added. Note, that tis filename will be extended, so existance of this file is not required.
         * \param additionalPrefix is a directory name that is additionally used as a prefix for resource archives.
         * (In addition to AddCatalogLookupPrefix()).
         * \param canonicalName is the canonical name of a locale. This method will search the resource
         * for this locale.
         * 
         * Extends _archiveNameToDerivates() in such a way that it containes all derivates if the provided <c>archiveName</c>.
         *</summary>*/
        internal static void ComputeDerivates(string archiveName, string additionalPrefix, string canonicalName)
        {
            string archiveSuffix = Path.GetExtension(archiveName);
            if (archiveSuffix == null)
                archiveSuffix = "";
            string archivePath = Path.GetDirectoryName(archiveName);
            if (archivePath.Length == 0) archivePath = ".";
            string archiveBaseName = Path.GetFileNameWithoutExtension(archiveName);

            // generate the two keys for _archiveNameToDerivates to fill
            KeyArchiveName keyNeutral = new KeyArchiveName(archiveName, additionalPrefix);
            KeyArchiveName keyLocalized = null;
            KeyArchiveName keyLocalized2 = null;
            string subLocaleName = null;
            if (canonicalName != null && canonicalName.Length > 0)
            {
                keyLocalized = new KeyArchiveName(archiveName, canonicalName, additionalPrefix);
                int pos = canonicalName.IndexOf('_');
                if (pos > 0)
                {
                    subLocaleName = canonicalName.Substring(0, pos);
                    keyLocalized2 = new KeyArchiveName(archiveName, subLocaleName, additionalPrefix);
                }
            }

            //Trace.WriteLine(string.Format("KeyArchiveNames: neutral: {0}, localized: {1}, localized2: {2}", keyNeutral, keyLocalized, keyLocalized2));

            // enumerate the prefixes and derive relevant pathnames.
            Hashtable derivatesLocalized2 = null;
            Hashtable derivatesLocalized = null;
            Hashtable derivatesNeutral = null;
            if (!_archiveNameToDerivates.Contains(keyNeutral))
                derivatesNeutral = new Hashtable();
            if (keyLocalized != null && !_archiveNameToDerivates.Contains(keyLocalized))
                derivatesLocalized = new Hashtable();
            if (keyLocalized2 != null && !_archiveNameToDerivates.Contains(keyLocalized2))
                derivatesLocalized2 = new Hashtable();

            if (derivatesLocalized == null && derivatesNeutral == null) return;

            string emptyDir="."+new string(Path.DirectorySeparatorChar,1);
            string filename = null;
            if (Path.IsPathRooted(archivePath))
            {
                if (derivatesLocalized != null
                    && canonicalName != null
                    && canonicalName.Length > 0)
                {
                    filename = archivePath + Path.DirectorySeparatorChar + archiveBaseName + "_" + canonicalName + archiveSuffix;
                    filename = filename.Replace(emptyDir, "");
                    if (filename.Length == 0) filename = ".";
                    //Trace.WriteLine(string.Format("new derivate to key/id {0} for <{1}> is <{2}>, prefix <{3}>, archive path <{4}>", keyLocalized, archiveBaseName, filename, prefix, archivePath));
                    if (!derivatesLocalized.Contains(filename)) derivatesLocalized.Add(filename, null);
                    if (archiveSuffix.Length == 0)
                    {
                        filename = archivePath + Path.DirectorySeparatorChar + archiveBaseName + "_" + canonicalName + "." + _stdSubdir;
                        filename = filename.Replace(".\\", "");
                        if (filename.Length == 0) filename = ".";
                        //Trace.WriteLine(string.Format("new derivate to key/id {0} for <{1}> is <{2}>, prefix <{3}>, archive path <{4}>", keyLocalized, archiveBaseName, filename, prefix, archivePath));
                        if (!derivatesLocalized.Contains(filename)) derivatesLocalized.Add(filename, null);
                    }
                    filename = archivePath + Path.DirectorySeparatorChar + archiveBaseName + "_" + canonicalName + archiveSuffix;
                    filename = filename.Replace(emptyDir, "");
                    if (filename.Length == 0) filename = ".";
                    //Trace.WriteLine(string.Format("new derivate to key/id {0} for <{1}> is <{2}>", keyLocalized, archiveBaseName, filename));
                    if (!derivatesLocalized.Contains(filename)) derivatesLocalized.Add(filename, null);
                    if (archiveSuffix.Length == 0)
                    {
                        filename = archivePath + Path.DirectorySeparatorChar + archiveBaseName + "_" + canonicalName + "." + _stdSubdir;
                        filename = filename.Replace(emptyDir, "");
                        if (filename.Length == 0) filename = ".";
                        //Trace.WriteLine(string.Format("new derivate to key/id {0} for <{1}> is <{2}>, prefix <{3}>, archive path <{4}>", keyLocalized, archiveBaseName, filename, prefix, archivePath));
                        if (!derivatesLocalized.Contains(filename)) derivatesLocalized.Add(filename, null);
                    }
                    filename = archivePath + Path.DirectorySeparatorChar + archiveBaseName + archiveSuffix;
                    filename = filename.Replace(emptyDir, "");
                    if (filename.Length == 0) filename = ".";
                    //Trace.WriteLine(string.Format("new derivate to key/id {0} for <{1}> is <{2}>", keyLocalized, archiveBaseName, filename));
                    if (!derivatesLocalized.Contains(filename)) derivatesLocalized.Add(filename, null);
                    if (archiveSuffix.Length == 0)
                    {
                        filename = archivePath + Path.DirectorySeparatorChar + archiveBaseName + "." + _stdSubdir;
                        filename = filename.Replace(emptyDir, "");
                        if (filename.Length == 0) filename = ".";
                        //Trace.WriteLine(string.Format("new derivate to key/id {0} for <{1}> is <{2}>, prefix <{3}>, archive path <{4}>", keyLocalized, archiveBaseName, filename, prefix, archivePath));
                        if (!derivatesLocalized.Contains(filename)) derivatesLocalized.Add(filename, null);
                    }
                    filename = archivePath + Path.DirectorySeparatorChar + archiveBaseName + "_" + canonicalName + archiveSuffix;
                    filename = filename.Replace(emptyDir, "");
                    if (filename.Length == 0) filename = ".";
                    //Trace.WriteLine(string.Format("new derivate to key/id {0} for <{1}> is <{2}>", keyLocalized, archiveBaseName, filename));
                    if (!derivatesLocalized.Contains(filename)) derivatesLocalized.Add(filename, null);
                    if (archiveSuffix.Length == 0)
                    {
                        filename = archivePath + Path.DirectorySeparatorChar + archiveBaseName + "_" + canonicalName + "." + _stdSubdir;
                        filename = filename.Replace(emptyDir, "");
                        if (filename.Length == 0) filename = ".";
                        //Trace.WriteLine(string.Format("new derivate to key/id {0} for <{1}> is <{2}>, prefix <{3}>, archive path <{4}>", keyLocalized, archiveBaseName, filename, prefix, archivePath));
                        if (!derivatesLocalized.Contains(filename)) derivatesLocalized.Add(filename, null);
                    }
                    filename = archivePath + Path.DirectorySeparatorChar + archiveBaseName + "_" + canonicalName + archiveSuffix;
                    filename = filename.Replace(emptyDir, "");
                    if (filename.Length == 0) filename = ".";
                    //Trace.WriteLine(string.Format("new derivate to key/id {0} for <{1}> is <{2}>", keyLocalized, archiveBaseName, filename));
                    if (!derivatesLocalized.Contains(filename)) derivatesLocalized.Add(filename, null);
                    if (archiveSuffix.Length == 0)
                    {
                        filename = archivePath + Path.DirectorySeparatorChar + archiveBaseName + "_" + canonicalName + "." + _stdSubdir;
                        filename = filename.Replace(emptyDir, "");
                        if (filename.Length == 0) filename = ".";
                        //Trace.WriteLine(string.Format("new derivate to key/id {0} for <{1}> is <{2}>, prefix <{3}>, archive path <{4}>", keyLocalized, archiveBaseName, filename, prefix, archivePath));
                        if (!derivatesLocalized.Contains(filename)) derivatesLocalized.Add(filename, null);
                    }
                    filename = archivePath + Path.DirectorySeparatorChar + archiveBaseName + archiveSuffix;
                    filename = filename.Replace(emptyDir, "");
                    if (filename.Length == 0) filename = ".";
                    //Trace.WriteLine(string.Format("new derivate to key/id {0} for <{1}> is <{2}>", keyLocalized, archiveBaseName, filename));
                    if (!derivatesLocalized.Contains(filename)) derivatesLocalized.Add(filename, null);
                    if (archiveSuffix.Length == 0)
                    {
                        filename = archivePath + Path.DirectorySeparatorChar + archiveBaseName + "." + _stdSubdir;
                        filename = filename.Replace(emptyDir, "");
                        if (filename.Length == 0) filename = ".";
                        //Trace.WriteLine(string.Format("new derivate to key/id {0} for <{1}> is <{2}>, prefix <{3}>, archive path <{4}>", keyLocalized, archiveBaseName, filename, prefix, archivePath));
                        if (!derivatesLocalized.Contains(filename)) derivatesLocalized.Add(filename, null);
                    }
                }
                if (derivatesLocalized2 != null
                    && subLocaleName != null
                    && subLocaleName.Length > 0)
                {
                    filename = archivePath + Path.DirectorySeparatorChar + archiveBaseName + "_" + subLocaleName + archiveSuffix;
                    filename = filename.Replace(emptyDir, "");
                    if (filename.Length == 0) filename = ".";
                    //Trace.WriteLine(string.Format("new derivate to key/id {0} for <{1}> is <{2}>", keyLocalized2, archiveBaseName, filename));
                    if (!derivatesLocalized.Contains(filename)) derivatesLocalized.Add(filename, null);
                    if (archiveSuffix.Length == 0)
                    {
                        filename = archivePath + Path.DirectorySeparatorChar + archiveBaseName + "_" + subLocaleName + "." + _stdSubdir;
                        filename = filename.Replace(emptyDir, "");
                        if (filename.Length == 0) filename = ".";
                        //Trace.WriteLine(string.Format("new derivate to key/id {0} for <{1}> is <{2}>, prefix <{3}>, archive path <{4}>", keyLocalized, archiveBaseName, filename, prefix, archivePath));
                        if (!derivatesLocalized.Contains(filename)) derivatesLocalized.Add(filename, null);
                    }
                    filename = archivePath + Path.DirectorySeparatorChar + archiveBaseName + "_" + subLocaleName + archiveSuffix;
                    filename = filename.Replace(emptyDir, "");
                    if (filename.Length == 0) filename = ".";
                    //Trace.WriteLine(string.Format("new derivate to key/id {0} for <{1}> is <{2}>", keyLocalized2, archiveBaseName, filename));
                    if (!derivatesLocalized.Contains(filename)) derivatesLocalized.Add(filename, null);
                    if (archiveSuffix.Length == 0)
                    {
                        filename = archivePath + Path.DirectorySeparatorChar + archiveBaseName + "_" + subLocaleName + "." + _stdSubdir;
                        filename = filename.Replace(emptyDir, "");
                        if (filename.Length == 0) filename = ".";
                        //Trace.WriteLine(string.Format("new derivate to key/id {0} for <{1}> is <{2}>, prefix <{3}>, archive path <{4}>", keyLocalized, archiveBaseName, filename, prefix, archivePath));
                        if (!derivatesLocalized.Contains(filename)) derivatesLocalized.Add(filename, null);
                    }
                    filename = archivePath + Path.DirectorySeparatorChar + archiveBaseName + archiveSuffix;
                    filename = filename.Replace(emptyDir, "");
                    if (filename.Length == 0) filename = ".";
                    //Trace.WriteLine(string.Format("new derivate to key/id {0} for <{1}> is <{2}>", keyLocalized2, archiveBaseName, filename));
                    if (!derivatesLocalized.Contains(filename)) derivatesLocalized.Add(filename, null);
                    if (archiveSuffix.Length == 0)
                    {
                        filename = archivePath + Path.DirectorySeparatorChar + archiveBaseName + "." + _stdSubdir;
                        filename = filename.Replace(emptyDir, "");
                        if (filename.Length == 0) filename = ".";
                        //Trace.WriteLine(string.Format("new derivate to key/id {0} for <{1}> is <{2}>, prefix <{3}>, archive path <{4}>", keyLocalized, archiveBaseName, filename, prefix, archivePath));
                        if (!derivatesLocalized.Contains(filename)) derivatesLocalized.Add(filename, null);
                    }
                    filename = archivePath + Path.DirectorySeparatorChar + archiveBaseName + "_" + subLocaleName + archiveSuffix;
                    filename = filename.Replace(emptyDir, "");
                    if (filename.Length == 0) filename = ".";
                    //Trace.WriteLine(string.Format("new derivate to key/id {0} for <{1}> is <{2}>", keyLocalized2, archiveBaseName, filename));
                    if (!derivatesLocalized2.Contains(filename)) derivatesLocalized2.Add(filename, null);
                    if (archiveSuffix.Length == 0)
                    {
                        filename = archivePath + Path.DirectorySeparatorChar + archiveBaseName + "_" + subLocaleName + "." + _stdSubdir;
                        filename = filename.Replace(emptyDir, "");
                        if (filename.Length == 0) filename = ".";
                        //Trace.WriteLine(string.Format("new derivate to key/id {0} for <{1}> is <{2}>, prefix <{3}>, archive path <{4}>", keyLocalized, archiveBaseName, filename, prefix, archivePath));
                        if (!derivatesLocalized2.Contains(filename)) derivatesLocalized2.Add(filename, null);
                    }
                    filename = archivePath + Path.DirectorySeparatorChar + archiveBaseName + "_" + subLocaleName + archiveSuffix;
                    filename = filename.Replace(emptyDir, "");
                    if (filename.Length == 0) filename = ".";
                    //Trace.WriteLine(string.Format("new derivate to key/id {0} for <{1}> is <{2}>", keyLocalized2, archiveBaseName, filename));
                    if (!derivatesLocalized2.Contains(filename)) derivatesLocalized2.Add(filename, null);
                    if (archiveSuffix.Length == 0)
                    {
                        filename = archivePath + Path.DirectorySeparatorChar + archiveBaseName + "_" + subLocaleName + "." + _stdSubdir;
                        filename = filename.Replace(emptyDir, "");
                        if (filename.Length == 0) filename = ".";
                        //Trace.WriteLine(string.Format("new derivate to key/id {0} for <{1}> is <{2}>, prefix <{3}>, archive path <{4}>", keyLocalized, archiveBaseName, filename, prefix, archivePath));
                        if (!derivatesLocalized2.Contains(filename)) derivatesLocalized2.Add(filename, null);
                    }
                    filename = archivePath + Path.DirectorySeparatorChar + archiveBaseName + archiveSuffix;
                    filename = filename.Replace(emptyDir, "");
                    if (filename.Length == 0) filename = ".";
                    //Trace.WriteLine(string.Format("new derivate to key/id {0} for <{1}> is <{2}>", keyLocalized2, archiveBaseName, filename));
                    if (!derivatesLocalized2.Contains(filename)) derivatesLocalized2.Add(filename, null);
                    if (archiveSuffix.Length == 0)
                    {
                        filename = archivePath + Path.DirectorySeparatorChar + archiveBaseName + "." + _stdSubdir;
                        filename = filename.Replace(emptyDir, "");
                        if (filename.Length == 0) filename = ".";
                        //Trace.WriteLine(string.Format("new derivate to key/id {0} for <{1}> is <{2}>, prefix <{3}>, archive path <{4}>", keyLocalized, archiveBaseName, filename, prefix, archivePath));
                        if (!derivatesLocalized2.Contains(filename)) derivatesLocalized2.Add(filename, null);
                    }
                }
                if (derivatesNeutral != null)
                {
                    filename = archivePath + Path.DirectorySeparatorChar + archiveBaseName + archiveSuffix;
                    filename = filename.Replace(emptyDir, "");
                    if (filename.Length == 0) filename = ".";
                    //Trace.WriteLine(string.Format("new derivate to key/id {0} for <{1}> is <{2}> from {3} combined with {4}...", keyNeutral, archiveName, filename, prefix, archivePath));
                    if (!derivatesNeutral.Contains(filename)) derivatesNeutral.Add(filename, null);
                    if (archiveSuffix.Length == 0)
                    {
                        filename = archivePath + Path.DirectorySeparatorChar + archiveBaseName + "." + _stdSubdir;
                        filename = filename.Replace(emptyDir, "");
                        if (filename.Length == 0) filename = ".";
                        //Trace.WriteLine(string.Format("new derivate to key/id {0} for <{1}> is <{2}>, prefix <{3}>, archive path <{4}>", keyLocalized, archiveBaseName, filename, prefix, archivePath));
                        if (!derivatesNeutral.Contains(filename)) derivatesNeutral.Add(filename, null);
                    }
                    filename = archivePath + Path.DirectorySeparatorChar + archiveBaseName + archiveSuffix;
                    filename = filename.Replace(emptyDir, "");
                    if (filename.Length == 0) filename = ".";
                    //Trace.WriteLine(string.Format("new derivate to key/id {0} for <{1}> is <{2}>", keyNeutral, archiveBaseName, filename));
                    if (!derivatesNeutral.Contains(filename)) derivatesNeutral.Add(filename, null);
                    if (archiveSuffix.Length == 0)
                    {
                        filename = archivePath + Path.DirectorySeparatorChar + archiveBaseName + "." + _stdSubdir;
                        filename = filename.Replace(emptyDir, "");
                        if (filename.Length == 0) filename = ".";
                        //Trace.WriteLine(string.Format("new derivate to key/id {0} for <{1}> is <{2}>, prefix <{3}>, archive path <{4}>", keyLocalized, archiveBaseName, filename, prefix, archivePath));
                        if (!derivatesNeutral.Contains(filename)) derivatesNeutral.Add(filename, null);
                    }
                }
            }
            else
            {
                ArrayList prefixes = _prefixes;
                prefixes.Insert(0, ".");
                if (additionalPrefix != null)
                {
                    prefixes = new ArrayList();
                    prefixes.Add(additionalPrefix);
                    prefixes.AddRange(_prefixes);
                }

                foreach (string prefix in prefixes)
                {
                    //Trace.WriteLine(string.Format("Derivates for prefix {0}.", prefix));
                    if (derivatesLocalized != null
                        && canonicalName != null
                        && canonicalName.Length > 0)
                    {
                        filename = Path.Combine(prefix + Path.DirectorySeparatorChar + _stdSubdir + Path.DirectorySeparatorChar + canonicalName, archivePath + Path.DirectorySeparatorChar + archiveBaseName + "_" + canonicalName + archiveSuffix);
                        filename = filename.Replace(emptyDir, "");
                        if (filename.Length == 0) filename = ".";
                        //Trace.WriteLine(string.Format("new derivate to key/id {0} for <{1}> is <{2}>, prefix <{3}>, archive path <{4}>", keyLocalized, archiveBaseName, filename, prefix, archivePath));
                        if (!derivatesLocalized.Contains(filename)) derivatesLocalized.Add(filename, null);
                        if (archiveSuffix.Length == 0)
                        {
                            filename = Path.Combine(prefix + Path.DirectorySeparatorChar + _stdSubdir + Path.DirectorySeparatorChar + canonicalName, archivePath + Path.DirectorySeparatorChar + archiveBaseName + "_" + canonicalName + "." + _stdSubdir);
                            filename = filename.Replace(emptyDir, "");
                            if (filename.Length == 0) filename = ".";
                            //Trace.WriteLine(string.Format("new derivate to key/id {0} for <{1}> is <{2}>, prefix <{3}>, archive path <{4}>", keyLocalized, archiveBaseName, filename, prefix, archivePath));
                            if (!derivatesLocalized.Contains(filename)) derivatesLocalized.Add(filename, null);
                        }
                        filename = Path.Combine(prefix + Path.DirectorySeparatorChar + _stdSubdir, archivePath + Path.DirectorySeparatorChar + archiveBaseName + "_" + canonicalName + archiveSuffix);
                        filename = filename.Replace(emptyDir, "");
                        if (filename.Length == 0) filename = ".";
                        //Trace.WriteLine(string.Format("new derivate to key/id {0} for <{1}> is <{2}>", keyLocalized, archiveBaseName, filename));
                        if (!derivatesLocalized.Contains(filename)) derivatesLocalized.Add(filename, null);
                        if (archiveSuffix.Length == 0)
                        {
                            filename = Path.Combine(prefix + Path.DirectorySeparatorChar + _stdSubdir, archivePath + Path.DirectorySeparatorChar + archiveBaseName + "_" + canonicalName + "." + _stdSubdir);
                            filename = filename.Replace(emptyDir, "");
                            if (filename.Length == 0) filename = ".";
                            //Trace.WriteLine(string.Format("new derivate to key/id {0} for <{1}> is <{2}>, prefix <{3}>, archive path <{4}>", keyLocalized, archiveBaseName, filename, prefix, archivePath));
                            if (!derivatesLocalized.Contains(filename)) derivatesLocalized.Add(filename, null);
                        }
                        filename = Path.Combine(prefix + Path.DirectorySeparatorChar + _stdSubdir + Path.DirectorySeparatorChar + canonicalName, archivePath + Path.DirectorySeparatorChar + archiveBaseName + archiveSuffix);
                        filename = filename.Replace(emptyDir, "");
                        if (filename.Length == 0) filename = ".";
                        //Trace.WriteLine(string.Format("new derivate to key/id {0} for <{1}> is <{2}>", keyLocalized, archiveBaseName, filename));
                        if (!derivatesLocalized.Contains(filename)) derivatesLocalized.Add(filename, null);
                        if (archiveSuffix.Length == 0)
                        {
                            filename = Path.Combine(prefix + Path.DirectorySeparatorChar + _stdSubdir + Path.DirectorySeparatorChar + canonicalName, archivePath + Path.DirectorySeparatorChar + archiveBaseName + "." + _stdSubdir);
                            filename = filename.Replace(emptyDir, "");
                            if (filename.Length == 0) filename = ".";
                            //Trace.WriteLine(string.Format("new derivate to key/id {0} for <{1}> is <{2}>, prefix <{3}>, archive path <{4}>", keyLocalized, archiveBaseName, filename, prefix, archivePath));
                            if (!derivatesLocalized.Contains(filename)) derivatesLocalized.Add(filename, null);
                        }
                        filename = Path.Combine(prefix + Path.DirectorySeparatorChar + canonicalName, archivePath + Path.DirectorySeparatorChar + archiveBaseName + "_" + canonicalName + archiveSuffix);
                        filename = filename.Replace(emptyDir, "");
                        if (filename.Length == 0) filename = ".";
                        //Trace.WriteLine(string.Format("new derivate to key/id {0} for <{1}> is <{2}>", keyLocalized, archiveBaseName, filename));
                        if (!derivatesLocalized.Contains(filename)) derivatesLocalized.Add(filename, null);
                        if (archiveSuffix.Length == 0)
                        {
                            filename = Path.Combine(prefix + Path.DirectorySeparatorChar + canonicalName, archivePath + Path.DirectorySeparatorChar + archiveBaseName + "_" + canonicalName + "." + _stdSubdir);
                            filename = filename.Replace(emptyDir, "");
                            if (filename.Length == 0) filename = ".";
                            //Trace.WriteLine(string.Format("new derivate to key/id {0} for <{1}> is <{2}>, prefix <{3}>, archive path <{4}>", keyLocalized, archiveBaseName, filename, prefix, archivePath));
                            if (!derivatesLocalized.Contains(filename)) derivatesLocalized.Add(filename, null);
                        }
                        filename = Path.Combine(prefix, archivePath + Path.DirectorySeparatorChar + archiveBaseName + "_" + canonicalName + archiveSuffix);
                        filename = filename.Replace(emptyDir, "");
                        if (filename.Length == 0) filename = ".";
                        //Trace.WriteLine(string.Format("new derivate to key/id {0} for <{1}> is <{2}>", keyLocalized, archiveBaseName, filename));
                        if (!derivatesLocalized.Contains(filename)) derivatesLocalized.Add(filename, null);
                        if (archiveSuffix.Length == 0)
                        {
                            filename = Path.Combine(prefix, archivePath + Path.DirectorySeparatorChar + archiveBaseName + "_" + canonicalName + "." + _stdSubdir);
                            filename = filename.Replace(emptyDir, "");
                            if (filename.Length == 0) filename = ".";
                            //Trace.WriteLine(string.Format("new derivate to key/id {0} for <{1}> is <{2}>, prefix <{3}>, archive path <{4}>", keyLocalized, archiveBaseName, filename, prefix, archivePath));
                            if (!derivatesLocalized.Contains(filename)) derivatesLocalized.Add(filename, null);
                        }
                        filename = Path.Combine(prefix + Path.DirectorySeparatorChar + canonicalName, archivePath + Path.DirectorySeparatorChar + archiveBaseName + archiveSuffix);
                        filename = filename.Replace(emptyDir, "");
                        if (filename.Length == 0) filename = ".";
                        //Trace.WriteLine(string.Format("new derivate to key/id {0} for <{1}> is <{2}>", keyLocalized, archiveBaseName, filename));
                        if (!derivatesLocalized.Contains(filename)) derivatesLocalized.Add(filename, null);
                        if (archiveSuffix.Length == 0)
                        {
                            filename = Path.Combine(prefix + Path.DirectorySeparatorChar + canonicalName, archivePath + Path.DirectorySeparatorChar + archiveBaseName + "." + _stdSubdir);
                            filename = filename.Replace(emptyDir, "");
                            if (filename.Length == 0) filename = ".";
                            //Trace.WriteLine(string.Format("new derivate to key/id {0} for <{1}> is <{2}>, prefix <{3}>, archive path <{4}>", keyLocalized, archiveBaseName, filename, prefix, archivePath));
                            if (!derivatesLocalized.Contains(filename)) derivatesLocalized.Add(filename, null);
                        }
                    }
                    if (derivatesLocalized2 != null
                        && subLocaleName != null
                        && subLocaleName.Length > 0)
                    {
                        filename = Path.Combine(prefix + Path.DirectorySeparatorChar + _stdSubdir + Path.DirectorySeparatorChar + subLocaleName, archivePath + Path.DirectorySeparatorChar + archiveBaseName + "_" + subLocaleName + archiveSuffix);
                        filename = filename.Replace(emptyDir, "");
                        if (filename.Length == 0) filename = ".";
                        //Trace.WriteLine(string.Format("new derivate to key/id {0} for <{1}> is <{2}>", keyLocalized2, archiveBaseName, filename));
                        if (!derivatesLocalized.Contains(filename)) derivatesLocalized.Add(filename, null);
                        if (archiveSuffix.Length == 0)
                        {
                            filename = Path.Combine(prefix + Path.DirectorySeparatorChar + _stdSubdir + Path.DirectorySeparatorChar + canonicalName, archivePath + Path.DirectorySeparatorChar + archiveBaseName + "_" + subLocaleName + "." + _stdSubdir);
                            filename = filename.Replace(emptyDir, "");
                            if (filename.Length == 0) filename = ".";
                            //Trace.WriteLine(string.Format("new derivate to key/id {0} for <{1}> is <{2}>, prefix <{3}>, archive path <{4}>", keyLocalized, archiveBaseName, filename, prefix, archivePath));
                            if (!derivatesLocalized.Contains(filename)) derivatesLocalized.Add(filename, null);
                        }
                        filename = Path.Combine(prefix + Path.DirectorySeparatorChar + _stdSubdir, archivePath + Path.DirectorySeparatorChar + archiveBaseName + "_" + subLocaleName + archiveSuffix);
                        filename = filename.Replace(emptyDir, "");
                        if (filename.Length == 0) filename = ".";
                        //Trace.WriteLine(string.Format("new derivate to key/id {0} for <{1}> is <{2}>", keyLocalized2, archiveBaseName, filename));
                        if (!derivatesLocalized.Contains(filename)) derivatesLocalized.Add(filename, null);
                        if (archiveSuffix.Length == 0)
                        {
                            filename = Path.Combine(prefix + Path.DirectorySeparatorChar + _stdSubdir, archivePath + Path.DirectorySeparatorChar + archiveBaseName + "_" + subLocaleName + "." + _stdSubdir);
                            filename = filename.Replace(emptyDir, "");
                            if (filename.Length == 0) filename = ".";
                            //Trace.WriteLine(string.Format("new derivate to key/id {0} for <{1}> is <{2}>, prefix <{3}>, archive path <{4}>", keyLocalized, archiveBaseName, filename, prefix, archivePath));
                            if (!derivatesLocalized.Contains(filename)) derivatesLocalized.Add(filename, null);
                        }
                        filename = Path.Combine(prefix + Path.DirectorySeparatorChar + _stdSubdir + Path.DirectorySeparatorChar + subLocaleName, archivePath + Path.DirectorySeparatorChar + archiveBaseName + archiveSuffix);
                        filename = filename.Replace(emptyDir, "");
                        if (filename.Length == 0) filename = ".";
                        //Trace.WriteLine(string.Format("new derivate to key/id {0} for <{1}> is <{2}>", keyLocalized2, archiveBaseName, filename));
                        if (!derivatesLocalized.Contains(filename)) derivatesLocalized.Add(filename, null);
                        if (archiveSuffix.Length == 0)
                        {
                            filename = Path.Combine(prefix + Path.DirectorySeparatorChar + _stdSubdir + Path.DirectorySeparatorChar + subLocaleName, archivePath + Path.DirectorySeparatorChar + archiveBaseName + "." + _stdSubdir);
                            filename = filename.Replace(emptyDir, "");
                            if (filename.Length == 0) filename = ".";
                            //Trace.WriteLine(string.Format("new derivate to key/id {0} for <{1}> is <{2}>, prefix <{3}>, archive path <{4}>", keyLocalized, archiveBaseName, filename, prefix, archivePath));
                            if (!derivatesLocalized.Contains(filename)) derivatesLocalized.Add(filename, null);
                        }
                        filename = Path.Combine(prefix + Path.DirectorySeparatorChar + subLocaleName, archivePath + Path.DirectorySeparatorChar + archiveBaseName + "_" + subLocaleName + archiveSuffix);
                        filename = filename.Replace(emptyDir, "");
                        if (filename.Length == 0) filename = ".";
                        //Trace.WriteLine(string.Format("new derivate to key/id {0} for <{1}> is <{2}>", keyLocalized2, archiveBaseName, filename));
                        if (!derivatesLocalized2.Contains(filename)) derivatesLocalized2.Add(filename, null);
                        if (archiveSuffix.Length == 0)
                        {
                            filename = Path.Combine(prefix + Path.DirectorySeparatorChar + subLocaleName, archivePath + Path.DirectorySeparatorChar + archiveBaseName + "_" + subLocaleName + "." + _stdSubdir);
                            filename = filename.Replace(".\\", "");
                            if (filename.Length == 0) filename = ".";
                            //Trace.WriteLine(string.Format("new derivate to key/id {0} for <{1}> is <{2}>, prefix <{3}>, archive path <{4}>", keyLocalized, archiveBaseName, filename, prefix, archivePath));
                            if (!derivatesLocalized2.Contains(filename)) derivatesLocalized2.Add(filename, null);
                        }
                        filename = Path.Combine(prefix, archivePath + Path.DirectorySeparatorChar + archiveBaseName + "_" + subLocaleName + archiveSuffix);
                        filename = filename.Replace(@".\", "");
                        if (filename.Length == 0) filename = ".";
                        //Trace.WriteLine(string.Format("new derivate to key/id {0} for <{1}> is <{2}>", keyLocalized2, archiveBaseName, filename));
                        if (!derivatesLocalized2.Contains(filename)) derivatesLocalized2.Add(filename, null);
                        if (archiveSuffix.Length == 0)
                        {
                            filename = Path.Combine(prefix, archivePath + Path.DirectorySeparatorChar + archiveBaseName + "_" + subLocaleName + "." + _stdSubdir);
                            filename = filename.Replace(emptyDir, "");
                            if (filename.Length == 0) filename = ".";
                            //Trace.WriteLine(string.Format("new derivate to key/id {0} for <{1}> is <{2}>, prefix <{3}>, archive path <{4}>", keyLocalized, archiveBaseName, filename, prefix, archivePath));
                            if (!derivatesLocalized2.Contains(filename)) derivatesLocalized2.Add(filename, null);
                        }
                        filename = Path.Combine(prefix + Path.DirectorySeparatorChar + subLocaleName, archivePath + Path.DirectorySeparatorChar + archiveBaseName + archiveSuffix);
                        filename = filename.Replace(emptyDir, "");
                        if (filename.Length == 0) filename = ".";
                        //Trace.WriteLine(string.Format("new derivate to key/id {0} for <{1}> is <{2}>", keyLocalized2, archiveBaseName, filename));
                        if (!derivatesLocalized2.Contains(filename)) derivatesLocalized2.Add(filename, null);
                        if (archiveSuffix.Length == 0)
                        {
                            filename = Path.Combine(prefix + Path.DirectorySeparatorChar + subLocaleName, archivePath + Path.DirectorySeparatorChar + archiveBaseName + "." + _stdSubdir);
                            filename = filename.Replace(emptyDir, "");
                            if (filename.Length == 0) filename = ".";
                            //Trace.WriteLine(string.Format("new derivate to key/id {0} for <{1}> is <{2}>, prefix <{3}>, archive path <{4}>", keyLocalized, archiveBaseName, filename, prefix, archivePath));
                            if (!derivatesLocalized2.Contains(filename)) derivatesLocalized2.Add(filename, null);
                        }
                    }
                    if (derivatesNeutral != null)
                    {
                        filename = Path.Combine(prefix + Path.DirectorySeparatorChar + _stdSubdir, archivePath + Path.DirectorySeparatorChar + archiveBaseName + archiveSuffix);
                        filename = filename.Replace(emptyDir, "");
                        if (filename.Length == 0) filename = ".";
                        //Trace.WriteLine(string.Format("new derivate to key/id {0} for <{1}> is <{2}> from {3} combined with {4}...", keyNeutral, archiveName, filename, prefix, archivePath));
                        if (!derivatesNeutral.Contains(filename)) derivatesNeutral.Add(filename, null);
                        if (archiveSuffix.Length == 0)
                        {
                            filename = Path.Combine(prefix + Path.DirectorySeparatorChar + _stdSubdir, archivePath + Path.DirectorySeparatorChar + archiveBaseName + "." + _stdSubdir);
                            filename = filename.Replace(emptyDir, "");
                            if (filename.Length == 0) filename = ".";
                            //Trace.WriteLine(string.Format("new derivate to key/id {0} for <{1}> is <{2}>, prefix <{3}>, archive path <{4}>", keyLocalized, archiveBaseName, filename, prefix, archivePath));
                            if (!derivatesNeutral.Contains(filename)) derivatesNeutral.Add(filename, null);
                        }
                        filename = Path.Combine(prefix, archivePath + Path.DirectorySeparatorChar + archiveBaseName + archiveSuffix);
                        filename = filename.Replace(emptyDir, "");
                        if (filename.Length == 0) filename = ".";
                        //Trace.WriteLine(string.Format("new derivate to key/id {0} for <{1}> is <{2}>", keyNeutral, archiveBaseName, filename));
                        if (!derivatesNeutral.Contains(filename)) derivatesNeutral.Add(filename, null);
                        if (archiveSuffix.Length == 0)
                        {
                            filename = Path.Combine(prefix, archivePath + Path.DirectorySeparatorChar + archiveBaseName + "." + _stdSubdir);
                            filename = filename.Replace(emptyDir, "");
                            if (filename.Length == 0) filename = ".";
                            //Trace.WriteLine(string.Format("new derivate to key/id {0} for <{1}> is <{2}>, prefix <{3}>, archive path <{4}>", keyLocalized, archiveBaseName, filename, prefix, archivePath));
                            if (!derivatesNeutral.Contains(filename)) derivatesNeutral.Add(filename, null);
                        }
                    }
                }
            }
            if (derivatesNeutral != null)
            {
                //Trace.WriteLine(string.Format("Add new keys derivatesNeutral to {0}.", keyNeutral));
                _archiveNameToDerivates.Add(keyNeutral, new ArrayList(derivatesNeutral.Keys));
            }
            if (derivatesLocalized != null)
            {
                //Trace.WriteLine(string.Format("Add new keys derivatesLocalized to {0}.", keyLocalized));
                _archiveNameToDerivates.Add(keyLocalized, new ArrayList(derivatesLocalized.Keys));
            }
            if (derivatesLocalized2 != null)
            {
                //Trace.WriteLine(string.Format("Add new keys derivatesLocalized2 to {0}.", keyLocalized2));
                _archiveNameToDerivates.Add(keyLocalized2, new ArrayList(derivatesLocalized2.Keys));
            }
        }

        /** <summary>Initializes _dirName or _src and _internalNameToEntry from the archive returned by FindArchive().
         * Main purpose: Cache archive entries if required. Possibly, resources cannot be loaded because
         * the archive has not been found. In this case, do not throw an exception put set all
         * possible sources <c>_dirName</c> and <c>_src</c> to <c>null</c>.
         * srcStream may be <c>null</c>. Then it will be generated from the name that will
         * be interpreted as a file name.
         *</summary>*/
        internal void InitFromArchive(string archiveName, Stream srcStream)
        {
            archiveName = NormalizedPath(archiveName);
            if (srcStream == null && Directory.Exists(archiveName))
            {
                _dirName = archiveName;
                //Trace.WriteLine(string.Format("InitFromArchive: Init directory <{0}>.", _dirName));
            }
            else
            {
                _archiveName = archiveName;
                //Trace.WriteLine(string.Format("InitFromArchive: Investigate archive {0}", archiveName));
                try
                {
                    if (srcStream == null)
                        _src = new ArchiveInput(archiveName);
                    else
                        _src = new ArchiveInput(srcStream, ArchiveEntry.TypeFromName(archiveName));
                    for (ArchiveEntry entry = _src.GetNextEntry();
                        entry != null;
                        entry = _src.GetNextEntry())
                    {
                        _internalNameToEntry.Add(entry.InternalName, entry);
                        //Trace.WriteLine(string.Format("Found {0}, {1}", entry.InternalName, entry));
                    }
                }
                catch (Exception /*exc*/)
                {
                    _src = null;
                    //Trace.WriteLine(string.Format("Exception on loading {0} is {1}", archiveName, exc));
                }
            }
        }
        #endregion
        #region CTor
        /** <summary>Loads an archive.
         * This will call InitFromArchive(). All entries will be read and cached.
         * srcStream may be <c>null</c>. Then it will be generated from the <c>archiveName</c> that will
         * be interpreted as a file name. If read from the local file system (with <c>srcStream</c> equals
         * <c>null)</c>, <c>archiveName</c> may either be a filename of a directory.
         *</summary>*/
        internal ZipResource(string archiveName, Stream srcStream)
        {
            InitFromArchive(archiveName, srcStream);
        }
        #endregion

        #region Public Properties And Methods Of Instances
        //! Archive has not been found.
        public bool IsEmpty { get { return _src == null && _dirName == null; } }
        //! If this is a directory.
        public bool IsDir { get { return _dirName != null; } }
        //! If this is an archive.
        public bool IsArchive { get { return _src != null; } }

        //! This is the main service of instances: Return a stream on the resource described
        //! by a local path name representation.
        /*! Result is \c null if nothing has been found.
         * */
        public FSFile FindResourceFile(string resourceName)
        {
            //Trace.WriteLine(string.Format("Find resource {0}.", resourceName));
            FSFile result = null;
            if (IsDir)
            {
                string filename = Path.Combine(_dirName, resourceName);
                filename = NormalizedPath(filename);
                //Trace.WriteLine(string.Format("Find {0} + {1} = {2}", _dirName, resourceName, filename));
                if (File.Exists(filename))
                {
                    Stream stream = new FileInfo(filename).OpenRead();
                    result = new FSFile(stream, filename, FileSystemHandler.MimeTypeFromExt(filename), "", File.GetLastWriteTime(filename));
                }
            }
            else if (IsArchive)
            {
                //Trace.WriteLine(string.Format("Find resource {0} in archive instance {1}", resourceName, _src.wxObject));
                resourceName = _src.GetInternalName(resourceName);
                wx.Archive.ArchiveEntry entry=(wx.Archive.ArchiveEntry)_internalNameToEntry[resourceName];
                if (entry != null)
                {
                    _src.OpenEntry(entry);
                    result = new FSFile(_src.In, "zrs:"+_archiveName+"//"+resourceName, FileSystemHandler.MimeTypeFromExt(resourceName), "", entry.DateTime);
                }
                else
                {
                    //Trace.WriteLine(string.Format("Cannot find archive entry {0}\n{1}", resourceName, this._internalNameToEntry.Keys));
                }
            }
            return result;
        }

        public override string ToString()
        {
            if (IsDir)
            {
                return string.Format("Directory {0} as ZipResource.", _dirName);
            }
            else if (IsArchive)
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("Archive {0} as ZipResource:\n", _archiveName);
                int index = 0;
                foreach (string internalName in _internalNameToEntry.Keys)
                {
                    ArchiveEntry entry = (ArchiveEntry) _internalNameToEntry[internalName];
                    sb.AppendFormat("{6}/{7}: \"{0}\"/\"{1}\"\n  {2} {3} {4} {5}\n", internalName, entry.Name, entry.Size, entry.DateTime, entry.IsDir ? "dir" : "", entry.IsReadOnly ? "ro" : "",
                        index+1, _internalNameToEntry.Count);
                    ++index;
                }
                return sb.ToString();
            }
            else
            {
                return "Unknown ZipResource.";
            }
        }
        #endregion

        #region Static
        static string _lastFoundResourceName = null;
        /** <summary>The last name of a resource that has been found by FindResource(). 
         * This may be <c>null</c>.
         *</summary>
         */
        public static string LastFoundResourceName { get { return _lastFoundResourceName; } }
        static string _lastSearchedArchiveName = null;
        /** <summary>The last name of a resource that has been tried to be loaded by FindResource(). 
         * This may be <c>null</c>.
         *</summary>
         */
        public static string LastSearchedArchiveName { get { return _lastSearchedArchiveName; } }
        static string _lastFoundArchiveName = null;
        /** <summary>The last name of a resource that has been found by FindResource(). 
         * This may be <c>null</c>.
         *</summary>
         */
        public static string LastFoundArchiveName { get { return _lastFoundArchiveName; } }
        static ZipResource _lastFoundArchive;

        internal static string NormalizedPath(string path)
        {
            string result = null;
            if (path.StartsWith("file:\\"))
                result = path.Substring(6);
            if (result == null)
                return path;
            else
            {
                return result;
            }
        }

        /** <summary>The last ZipResource found by FindResource().
         *</summary>*/
        public static ZipResource LastFoundArchive { get { return _lastFoundArchive; } }
        /** <summary>Add a prefix to be lookup path for loading archives with resources.
         * Similar to wx.Locale.AddCatalogLookupPrefix().
         * The message catalog files will be looked up under
         * <c>prefix/LANG/zrs</c>,
         * <c>prefix/LANG</c>, and <c>prefix</c>
         * (in this order) where LANG is the canonical name of a locale.
         *
         * <c>prefix</c> will be expanded using the code base path of the calling assembly
         * if necessary. So, the meaning of <c>prefix</c> never relies on the CWD but always
         * on the position of the assemblies.
         *
         * This only applies to subsequent instance creations.
         *</summary>*/
        public static void AddCatalogLookupPrefix(string prefix)
        {
            if (!Path.IsPathRooted(prefix))
            {
                Uri rootUri=new Uri(System.Reflection.Assembly.GetCallingAssembly().CodeBase);
                string rootDir = rootUri.LocalPath;
                rootDir = Path.GetDirectoryName(rootDir);
                prefix = Path.Combine(rootDir, prefix);
                prefix = Path.GetFullPath(prefix);
            }
            _prefixes.Add(prefix);
            // recompute derivates.
            _archiveNameToDerivates = new Hashtable();
        }

        /** <summary>Returns the file names derivated from <c>archiveName</c> of the current <c>wx.Locale</c>.
         *</summary>
         */
        public static string[] GetDerivatedArchiveNames(string archiveName)
        {
            using (wx.Locale locale = new Locale())
            {
                string canonicalName = locale.CanonicalName;
                return GetDerivatedArchiveNames(archiveName, canonicalName);
            }
        }

        /** <summary>Returns the file names derivated from <c>archiveName</c> assuming the locale <c>canonicalName</c>.
         * Use the empty string to denote the neutral locale.
         *</summary>
         */
        public static string[] GetDerivatedArchiveNames(string archiveName, string canonicalName)
        {
            Uri codeBaseUri = new Uri(Assembly.GetCallingAssembly().CodeBase);
            string mainPrefix = Path.GetDirectoryName(codeBaseUri.LocalPath);
            mainPrefix = Path.GetFullPath(mainPrefix);
            ComputeDerivates(archiveName, mainPrefix, canonicalName);
            KeyArchiveName key = new KeyArchiveName(archiveName, canonicalName, mainPrefix);
            //Trace.WriteLine(string.Format("GetDerivatedArchiveNames({0}, {1}) read key {2}", archiveName, canonicalName, key));
            ArrayList derivates = (ArrayList)_archiveNameToDerivates[key];
            if (canonicalName != null && canonicalName != "")
            {
                key = new KeyArchiveName(archiveName, mainPrefix);
                derivates.AddRange((ArrayList)_archiveNameToDerivates[key]);
            }
            //Trace.WriteLine(string.Format("Found derivates {0}", derivates == null ? "NULL" : derivates.ToString()));
            if (derivates == null)
            {
              /*
                foreach (KeyArchiveName archiveNameKey in _archiveNameToDerivates.Keys)
                {
                    //Trace.WriteLine(string.Format("Known for key {0} is {1}.", archiveNameKey, _archiveNameToDerivates[archiveNameKey] == null ? "NULL" : _archiveNameToDerivates[archiveNameKey]));
                }
                */
            }
            string[] result = null;
            if (derivates != null && derivates.Count > 0)
            {
                result = new string[derivates.Count];
                for (int i = 0; i < derivates.Count; ++i)
                {
                    result[i] = (string)derivates[i];
                }
            }
            return result;
        }

        /** <summary>Returns the resource names derivated from <c>resourceName</c> of the current <c>wx.Locale</c>.
         *</summary>
         */
        public static string[] GetDerivatedResourceNames(string archiveName)
        {
            using (wx.Locale locale = new Locale())
            {
                string canonicalName = locale.CanonicalName;
                return GetDerivatedResourceNames(archiveName, canonicalName);
            }
        }

        /** <summary>Returns the resource names derivated from <c>resourceName</c> assuming locale <c>canonicalName</c>.
         * Use the empty string to denote the neutral locale.
         *</summary>
         */
        public static string[] GetDerivatedResourceNames(string resourceName, string canonicalName)
        {
            ArrayList resourceNameDerivates = new ArrayList();
            if (canonicalName != null && canonicalName.Length > 0)
            {
                // complete the list of derivates of the resource name first.
                string resourceFileWithoutExt=Path.GetFileNameWithoutExtension(resourceName);
                bool addLocNameToFileName=!resourceFileWithoutExt.EndsWith("_"+canonicalName);
                if (addLocNameToFileName)
                {
                    resourceNameDerivates.Add(Path.Combine(canonicalName
                        + Path.DirectorySeparatorChar,
                        resourceFileWithoutExt
                        + "_" + canonicalName + Path.GetExtension(resourceName)));
                    resourceNameDerivates.Add(resourceFileWithoutExt
                        + "_" + canonicalName + Path.GetExtension(resourceName));
                }
                string resourceDirectory = Path.GetDirectoryName(resourceName);
                if (resourceDirectory.Length > 1)
                {
                    resourceNameDerivates.Add(resourceDirectory
                        + Path.DirectorySeparatorChar
                        + canonicalName
                        + Path.DirectorySeparatorChar
                        + Path.GetFileName(resourceName));
                    if (addLocNameToFileName)
                    {
                        resourceNameDerivates.Add(resourceDirectory
                            + Path.DirectorySeparatorChar
                            + canonicalName
                            + Path.DirectorySeparatorChar
                            + resourceFileWithoutExt
                            + "_" + canonicalName + Path.GetExtension(resourceName));
                    }
                }
                resourceNameDerivates.Add(Path.Combine(canonicalName
                    + Path.DirectorySeparatorChar,
                    resourceName));

                int posInCanonicalName = canonicalName.IndexOf('_');
                if (posInCanonicalName > 0)
                {
                    string canonicalName2 = canonicalName.Substring(0, posInCanonicalName);
                    resourceNameDerivates.Add(Path.Combine(canonicalName2
                        + Path.DirectorySeparatorChar,
                        resourceName));
                    if (addLocNameToFileName)
                    {
                        resourceNameDerivates.Add(Path.Combine(canonicalName2
                            + Path.DirectorySeparatorChar,
                            resourceFileWithoutExt
                            + "_" + canonicalName + Path.GetExtension(resourceName)));
                        resourceNameDerivates.Add(Path.Combine(canonicalName2
                            + Path.DirectorySeparatorChar,
                            resourceFileWithoutExt
                            + "_" + canonicalName2 + Path.GetExtension(resourceName)));
                        resourceNameDerivates.Add(resourceFileWithoutExt
                            + "_" + canonicalName2 + Path.GetExtension(resourceName));
                    }
                    if (resourceDirectory.Length > 1)
                    {
                        resourceNameDerivates.Add(resourceDirectory
                            + Path.DirectorySeparatorChar
                            + canonicalName2
                            + Path.DirectorySeparatorChar
                            + Path.GetFileName(resourceName));
                        if (addLocNameToFileName)
                        {
                            resourceNameDerivates.Add(resourceDirectory
                                + Path.DirectorySeparatorChar
                                + canonicalName2
                                + Path.DirectorySeparatorChar
                                + resourceFileWithoutExt
                                + "_" + canonicalName + Path.GetExtension(resourceName));
                            resourceNameDerivates.Add(resourceDirectory
                                + Path.DirectorySeparatorChar
                                + canonicalName2
                                + Path.DirectorySeparatorChar
                                + resourceFileWithoutExt
                                + "_" + canonicalName2 + Path.GetExtension(resourceName));
                            resourceNameDerivates.Add(resourceDirectory
                                + Path.DirectorySeparatorChar
                                + resourceFileWithoutExt
                                + "_" + canonicalName2 + Path.GetExtension(resourceName));
                        }
                    }
                }
            }
            // this is the neutral resource. This should be the last name to be searched.
            // localized forms shall be preferred.
            resourceNameDerivates.Add(resourceName); 
            string[] result = new string[resourceNameDerivates.Count];
            for (int i = 0; i < resourceNameDerivates.Count; ++i) result[i] = (string)resourceNameDerivates[i];
            return result;
        }

        /** <summary>Finds a stream containing a resource of the provided name from the provided archive.
         * Refer to FindResource(string, string, string) for details.
         *
         * Non-rooted paths will be rooted with reference to the code base of <c>callingAssembly</c>.
         * </summary>
         */
        public static Stream FindResource(Assembly callingAssembly, string archiveName, string resourceName)
        {
            //Trace.WriteLine(string.Format("Find resource {0}, {1}.", archiveName, resourceName));
            string canonicalName = Locale.GetLanguageInfo(Language.wxLANGUAGE_DEFAULT).CanonicalName;
            FSFile resultFile = FindResourceFile(callingAssembly, archiveName, resourceName, canonicalName);
            if (resultFile == null)
                return null;
            else
                return resultFile.Stream;
        }


        /** <summary>Finds a stream containing a resource of the provided name from the provided archive.
         * Refer to FindResource(string, string, string) for details.
         *
         * Non-rooted paths will be rooted with reference to the code base of the calling assembly.
         *</summary>*/
        public static Stream FindResource(string archiveName, string resourceName)
        {
            return FindResource(Assembly.GetCallingAssembly(), archiveName, resourceName);
        }


        /** <summary>Some kinds of data, especially images, require data sources that can seek positions in the stream.
         * This will call ResourceFile() and then, if the result cannot seek, load the source directly into
         * a memory stream.</summary>*/
        public static FSFile ResourceFileCanSeek(string archiveName, string resourceName)
        {
            FSFile original = FindResourceFile(archiveName, resourceName);
            if (original.Stream.CanSeek)
                return original;
            else
            {
                int length=(int)original.Stream.Length;
                byte[] buffer=new byte[length];
                original.Stream.Read(buffer, 0, length);
                MemoryStream newStream = new MemoryStream(buffer);
                return new FSFile(newStream, original.Location, original.MimeType, original.Anchor, original.ModificationTime);
            }
        }


        /** <summary>This method will produce a stream that can seek (cf. ResourceFileCanSeek) if this seems to be appropriate referring to the mime type.
         * At least images need streams as data source that can seek. This method will call ResourceFile() and analyze
         * the mime type of the result. If considered to be appropriate, the content of the resource stream will
         * be copied into a System.IO.MemoryStream in order to get a stream that can seek positions.
         * Refer also to ResourceFileCanSeek().</summary>*/
        public static FSFile ResourceFileAppropriateType(string archiveName, string resourceName)
        {
            FSFile original = FindResourceFile(archiveName, resourceName);
            if (original == null)
                return null;
            bool requireCanSeek = false;
            if (original.MimeType.StartsWith("image"))
                requireCanSeek = true;
            if (!requireCanSeek || original.Stream.CanSeek)
                return original;
            else
            {
                int length = (int)original.Stream.Length;
                byte[] buffer = new byte[length];
                original.Stream.Read(buffer, 0, length);
                MemoryStream newStream = new MemoryStream(buffer);
                return new FSFile(newStream, original.Location, original.MimeType, original.Anchor, original.ModificationTime);
            }
        }

        /** <summary>Finds a FSFile instance containing a resource of the provided name from the provided archive.
         * Refer to FindResource(string, string, string) for details.
         *</summary>*/
        public static FSFile FindResourceFile(string archiveName, string resourceName)
        {
            //Trace.WriteLine(string.Format("Find resource {0}, {1}.", archiveName, resourceName));
            string canonicalName = Locale.GetLanguageInfo(Language.wxLANGUAGE_DEFAULT).CanonicalName;
            return FindResourceFile(Assembly.GetCallingAssembly(), archiveName, resourceName, canonicalName);
        }

        /** <summary>Finds a stream containing a resource of the provided name suitable for the specified locale from the provided archive.
         * \param archiveName is a filename describing the archive where the resource has been compiled in. This may also be the name of a resource.
         * This method will generate derivates from this name as described below.
         * \param resourceName is a native filename (according to the conventions of class Path) describing
         * the resource. This method will generate derivates from this name as described below.
         * \param canonicalName is the canonical name of the locale that the required resource has to comply with.
         * If a locale specific resource cannot be found, the method will load a neutral version. If this is <c>null</c>
         * or empty, this method will immediately search for a neutral resource.
         * 
         * If the resources cannot be found, the manifest of the calling assembly will be searched.
         * 
         * This method will return a <c>null</c> if the desired resource cannot be find.</summary>*/
        public static Stream FindResource(string archiveName, string resourceName, string canonicalName)
        {
            //Trace.WriteLine(string.Format("Find resource {0}, {1}, {2}.", archiveName, resourceName, canonicalName));
            return FindResourceFile(Assembly.GetCallingAssembly(), archiveName, resourceName, canonicalName).Stream;
        }

        /** <summary>Finds a FSFile instance containing a resource of the provided name from the provided archive of a provided locale (culture).
         * Refer to FindResource(string, string, string) for details.
         *</summary>*/
        public static FSFile FindResourceFile(string archiveName, string resourceName, string canonicalName)
        {
            return FindResourceFile(Assembly.GetCallingAssembly(), archiveName, resourceName, canonicalName);
        }

        internal static FSFile FindResourceFile(Assembly callingAssembly, string archiveName, string resourceName, string canonicalName)
        {
            //Trace.WriteLine(string.Format("Find resource {0}, {1}, {2}, {3}.", callingAssembly.FullName, archiveName, resourceName, canonicalName));
            _lastFoundArchiveName = null;
            _lastFoundResourceName = null;
            _lastSearchedArchiveName = archiveName;
            _lastSearchedArchiveName = resourceName;

            Uri codeBaseUri = new Uri(Assembly.GetCallingAssembly().CodeBase);
            string mainPrefix = Path.GetDirectoryName(codeBaseUri.LocalPath);
            mainPrefix = Path.GetFullPath(mainPrefix);
            FSFile result = null;
            ComputeDerivates(archiveName, mainPrefix, canonicalName);
            string[] resourceNameDerivates = GetDerivatedResourceNames(resourceName, canonicalName);

            if (canonicalName != null && canonicalName.Length > 0)
            {
                KeyArchiveName key = new KeyArchiveName(archiveName, canonicalName, mainPrefix);
                ArrayList derivates = (ArrayList)_archiveNameToDerivates[key];
                if (canonicalName.Contains("_"))
                {
                    string canonicalLangName = canonicalName.Substring(0, canonicalName.IndexOf("_"));
                    key = new KeyArchiveName(archiveName, canonicalLangName, mainPrefix);
                    derivates.AddRange((ArrayList)_archiveNameToDerivates[key]);
                }
                key = new KeyArchiveName(archiveName, mainPrefix);
                derivates.AddRange((ArrayList)_archiveNameToDerivates[key]);

                //Trace.WriteLine(string.Format("FindResource: found {0} derivates of archive name for key {1}.", derivates.Count, key));
                if (derivates != null)
                {
                    foreach (string derivateOrig in derivates)
                    {
                        string derivate = NormalizedPath(derivateOrig);
                        //Trace.WriteLine(string.Format("Find Resource: Looking for derivated archive name {0}.", derivate));
                        ZipResource archive=(ZipResource)_archives[derivate];

                        if (archive==null)
                        {
                            try
                            {
                                ManifestResourceInfo rsInfo = callingAssembly.GetManifestResourceInfo(derivate);
                                if (rsInfo != null)
                                {
                                    archive = new ZipResource(derivate, callingAssembly.GetManifestResourceStream(derivate));
                                    _archives[derivate] = archive;
                                }
                            }
                            catch (Exception exc)
                            {
                                Trace.WriteLine(exc);
                            }
                        }
                        if (archive==null && File.Exists(derivate))
                        {
                            //Trace.WriteLine(string.Format("Find Resource: Open archive file {0}.", derivate));
                            archive = new ZipResource(derivate, null);
                            _archives[derivate] = archive;
                        }
                        else if (Directory.Exists(derivate))
                        {
                            //Trace.WriteLine(string.Format("Found derivate as directory {0}.", derivate));
                            foreach (string rsDerivate in resourceNameDerivates)
                            {
                                string combinedFileName = Path.Combine(derivate, rsDerivate);
                                //Trace.WriteLine(string.Format("Looking for resource file {0} combined from derivated rsname {1}", combinedFileName, rsDerivate));
                                if (File.Exists(combinedFileName))
                                {
                                    try
                                    {
                                        Stream stream = new FileStream(combinedFileName, FileMode.Open);
                                        result = new FSFile(stream, combinedFileName, FileSystemHandler.MimeTypeFromExt(combinedFileName), "", File.GetLastWriteTime(combinedFileName));
                                    }
                                    catch
                                    {
                                        return null;
                                    }
                                    _lastFoundArchiveName = derivate;
                                    _lastFoundResourceName = rsDerivate;
                                    break;
                                }
                            }
                            //Trace.WriteLine(string.Format("Find Resource: Found directory file {0}.", derivate));
                        }

                        if (archive!= null)
                        {
                            //Trace.WriteLine(string.Format("Find Resource: Found archive file {0}.", derivate));
                            foreach (string rsDerivate in resourceNameDerivates)
                            {
                                result = archive.FindResourceFile(rsDerivate);
                                if (result != null)
                                {
                                    _lastFoundArchiveName = derivate;
                                    _lastFoundResourceName = rsDerivate;
                                    break;
                                }
                                if (result != null) break;
                            }
                            _lastFoundArchive = archive;
                        }
                        if (result != null) break;
                    }
                }
            }
            if (result == null)
            {
                KeyArchiveName key = new KeyArchiveName(archiveName, mainPrefix);
                ICollection derivates = (ICollection)_archiveNameToDerivates[key];
                //Trace.WriteLine(string.Format("FindResource: found {0} derivates of archive name for key {1}.", derivates.Count, key));
                if (derivates != null)
                {
                    foreach (string derivateOrig in derivates)
                    {
                        string derivate = NormalizedPath(derivateOrig);
                        //Trace.WriteLine(string.Format("FindResource in {0}.", derivate));
                        if (File.Exists(derivate))
                        {
                            ZipResource archive = (ZipResource)_archives[derivate];
                            //Trace.WriteLine(string.Format("File exists and archive {0}", archive));
                            if (archive==null)
                            {
                                try
                                {
                                    ManifestResourceInfo rsInfo = callingAssembly.GetManifestResourceInfo(derivate);
                                    if (rsInfo != null)
                                    {
                                        archive = new ZipResource(derivate, callingAssembly.GetManifestResourceStream(derivate));
                                        _archives[derivate] = archive;
                                    }
                                }
                                catch (Exception exc)
                                {
                                    Trace.WriteLine(exc);
                                }
                            }
                            if (archive == null)
                            {
                                archive = new ZipResource(derivate, null);
                                _archives[derivate] = archive;
                            }
                            foreach (string rsDerivate in resourceNameDerivates)
                            {
                                result = archive.FindResourceFile(rsDerivate);
                                if (result != null)
                                {
                                    _lastFoundArchiveName = derivate;
                                    _lastFoundResourceName = rsDerivate;
                                    break;
                                }
                            }
                        }
                        else if (Directory.Exists(derivate))
                        {
                            //Trace.WriteLine(string.Format("Found derivate as directory {0}.", derivate));
                            foreach (string rsDerivate in resourceNameDerivates)
                            {
                                string combinedFileName = Path.Combine(derivate, rsDerivate);
                                //Trace.WriteLine(string.Format("Looking for resource file {0} combined from derivated rsname {1}", combinedFileName, rsDerivate));
                                if (File.Exists(combinedFileName))
                                {
                                    try
                                    {
                                        Stream stream = new FileStream(combinedFileName, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
                                        result = new FSFile(stream, combinedFileName, FileSystemHandler.MimeTypeFromExt(combinedFileName), "", File.GetLastWriteTime(combinedFileName));
                                    }
                                    catch
                                    {
                                        return null;
                                    }
                                    _lastFoundArchiveName = derivate;
                                    _lastFoundResourceName = rsDerivate;
                                    //Trace.WriteLine("Found result.");
                                    break;
                                }
                            }
                            //Trace.WriteLine(string.Format("Find Resource: Found directory file {0}.", derivate));
                        }
                        if (result != null) break;
                    }
                }
            }
            if (result==null)
            {
                ManifestResourceInfo mri = callingAssembly.GetManifestResourceInfo(resourceName);
                if (mri != null)
                {
                    Stream stream = callingAssembly.GetManifestResourceStream(resourceName);
                    result = new FSFile(stream, "rs:" + resourceName, FileSystemHandler.MimeTypeFromExt(resourceName), "", new DateTime());
                }
            }
            return result;
        }
        #endregion
    }

}
