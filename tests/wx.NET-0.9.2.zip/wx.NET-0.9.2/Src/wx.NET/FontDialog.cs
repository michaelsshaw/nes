//-----------------------------------------------------------------------------
// wx.NET - Fontdlg.cs
// 
// The wxFontDialog wrapper class.
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: FontDialog.cs,v 1.10 2010/05/08 19:52:40 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Runtime.InteropServices;

namespace wx
{
    public class FontData : Object
    {
    	#region C API
        [DllImport("wx-c")] static extern IntPtr wxFontData_ctor();
		[DllImport("wx-c")] static extern void   wxFontData_dtor(IntPtr self);

		[DllImport("wx-c")] static extern void   wxFontData_SetAllowSymbols(IntPtr self, bool flag);
		[DllImport("wx-c")] static extern bool   wxFontData_GetAllowSymbols(IntPtr self);

		[DllImport("wx-c")] static extern void   wxFontData_SetColour(IntPtr self, IntPtr colour);
		[DllImport("wx-c")] static extern IntPtr wxFontData_GetColour(IntPtr self);

		[DllImport("wx-c")] static extern void   wxFontData_SetShowHelp(IntPtr self, bool flag);
		[DllImport("wx-c")] static extern bool   wxFontData_GetShowHelp(IntPtr self);

		[DllImport("wx-c")] static extern void   wxFontData_EnableEffects(IntPtr self, bool flag);
		[DllImport("wx-c")] static extern bool   wxFontData_GetEnableEffects(IntPtr self);

		[DllImport("wx-c")] static extern void   wxFontData_SetInitialFont(IntPtr self, IntPtr font);
		[DllImport("wx-c")] static extern IntPtr wxFontData_GetInitialFont(IntPtr self);

		[DllImport("wx-c")] static extern void   wxFontData_SetChosenFont(IntPtr self, IntPtr font);
		[DllImport("wx-c")] static extern IntPtr wxFontData_GetChosenFont(IntPtr self);

		[DllImport("wx-c")] static extern void   wxFontData_SetRange(IntPtr self, int minRange, int maxRange);
		#endregion
        //---------------------------------------------------------------------

		#region CTor / DTor
        public FontData(IntPtr wxObject) 
            : base(wxObject) { }

        static IntPtr LockedCTor()
        {
            lock (DllSync)
            {
                return wxFontData_ctor();
            }
        }

        public FontData()
            : base(LockedCTor()) { }

        public FontData(Font font)
            : this()
        {
            this.ChosenFont = font;
        }

        public FontData(Font font, Colour colour)
            : this()
        {
            this.ChosenFont = font;
            this.Colour = colour;
        }
        
        protected override void CallDTor ()
        {
        	wxFontData_dtor(this.wxObject);
        }

        #endregion

        //---------------------------------------------------------------------

        public bool AllowSymbols
        {
            get { return wxFontData_GetAllowSymbols(wxObject); }
            set { wxFontData_SetAllowSymbols(wxObject, value); }
        }

        //---------------------------------------------------------------------

        public bool EffectsEnabled
        {
            get { return wxFontData_GetEnableEffects(wxObject); }
            set { wxFontData_EnableEffects(wxObject, value); }
        }

        //---------------------------------------------------------------------

        public bool ShowHelp
        {
            get { return wxFontData_GetShowHelp(wxObject); }
            set { wxFontData_SetShowHelp(wxObject, value); }
        }

        //---------------------------------------------------------------------

        public Colour Colour
        {
            get 
            {
                return new Colour(wxFontData_GetColour(wxObject), true);
            }
            set 
            {
                wxFontData_SetColour(wxObject, Object.SafePtr(value)); 
            }
        }

        //---------------------------------------------------------------------
        
        public Font InitialFont
        {
            get
            {
                return new Font(wxFontData_GetInitialFont(wxObject));
            }
            set
            {
                wxFontData_SetInitialFont(wxObject, Object.SafePtr(value));
            }
        }

        //---------------------------------------------------------------------

        public Font ChosenFont
        {
            get
            {
                return new Font(wxFontData_GetChosenFont(wxObject));
            }
            set
            {
                wxFontData_SetChosenFont(wxObject, Object.SafePtr(value));
            }
        }

        //---------------------------------------------------------------------

        public void SetRange(int min, int max)
        {
            wxFontData_SetRange(wxObject, min, max);
        }

        //---------------------------------------------------------------------
    }

	public class FontDialog : Dialog
	{
		#region CTor
		[DllImport("wx-c")] static extern IntPtr wxFontDialog_ctor();
		[DllImport("wx-c")] static extern bool   wxFontDialog_Create(IntPtr self, IntPtr parent, IntPtr data);
		[DllImport("wx-c")] static extern void   wxFontDialog_dtor(IntPtr self);

		[DllImport("wx-c")] static extern int    wxFontDialog_ShowModal(IntPtr self);
		[DllImport("wx-c")] static extern IntPtr wxFontDialog_GetFontData(IntPtr self);
		#endregion
        //---------------------------------------------------------------------

		#region CTor
        public FontDialog(IntPtr wxObject)
            : base(wxObject) { }

        static IntPtr LockedCTor()
        {
            lock (DllSync)
            {
                return wxFontDialog_ctor();
            }
        }

        public FontDialog()
            : base(LockedCTor()) { }

        public FontDialog(Window parent)
            : this(parent, null) { }

        public FontDialog(Window parent, FontData data)
            : this()
        {
            if (!Create(parent, data)) 
            {
                throw new InvalidOperationException("Failed to create FontDialog");
            }
        }

        /// <summary>
        /// Create the dialog.
        /// </summary>
        /// <param name="parent">The parent window of the dialog. This may be <c>null</c>.</param>
        /// <param name="data">The initially selected font.</param>
        /// <returns></returns>
        public bool Create(Window parent, FontData data)
        {
            return wxFontDialog_Create(wxObject, Object.SafePtr(parent), Object.SafePtr(data));
        }
        
        protected override void CallDTor ()
        {
        	wxFontDialog_dtor(this.wxObject);
        }

        #endregion

        //---------------------------------------------------------------------

        /// <summary>
        /// The font that has been selected by the user.
        /// </summary>
        public FontData FontData
        {
            get
            {
                IntPtr ptr = wxFontDialog_GetFontData(wxObject);
                return (FontData)FindObject(ptr, typeof(FontData));
            }
        }

        //---------------------------------------------------------------------

        /** <summary>Modal display of the dialog. Returns whether input has been confirmed or cancelled.
         * </summary>
         */
        public override ShowModalResult ShowModal()
        {
            int result=wxFontDialog_ShowModal(wxObject);
            return result==5100?ShowModalResult.OK:ShowModalResult.CANCEL;
        }

        //---------------------------------------------------------------------
	}

}
