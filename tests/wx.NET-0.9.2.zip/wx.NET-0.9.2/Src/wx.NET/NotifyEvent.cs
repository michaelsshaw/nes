/**
* \file
* 
* wx.NET - NotifyEvent.cs
*
* The \c wxNotifyEvent wrapper class.
*
* Written by Harald Meyer auf'm Hofe
* (C) 2009
* Licensed under the wxWidgets license, see LICENSE.txt for details.
*
* $Id: NotifyEvent.cs,v 1.2 2009/09/20 14:10:58 harald_meyer Exp $
*/

using System;
using System.Collections;
using System.Runtime.InteropServices;

namespace wx
{
    /** <summary>This class is not used by the event handlers by itself, but is a base class for other event classes (such as wx.NotebookEvent).
     *
     * It (or an object of a derived class) is sent when the controls state is being changed and allows the program to <c>Veto()</c>
     * this change if it wants to prevent it from happening.</summary>*/
    public class NotifyEvent : Event
    {
        #region C API
        [DllImport("wx-c")]
        static extern void wxNotifyEvent_Veto(IntPtr self);
        [DllImport("wx-c")]
        static extern void wxNotifyEvent_Allow(IntPtr self);
        [DllImport("wx-c")][return:MarshalAs(UnmanagedType.U1)]
        static extern bool wxNotifyEvent_IsAllowed(IntPtr self);
        #endregion

        /** <summary>For internal use only.</summary>*/
        public NotifyEvent(IntPtr wxObject)
			: base(wxObject) { }

        /** <summary>Prevents the change announced by this event from happening.
         *
         * It is in general a good idea to notify the user about the reasons for vetoing the change because otherwise the
         * applications behaviour (which just refuses to do what the user wants) might be quite surprising.</summary>*/
        public void Veto()
        {
            wxNotifyEvent_Veto(wxObject);
        }

        /** <summary>Call this to explicitely allow processing of this event.
         * This is the opposite of <c>Veto()</c>: it explicitly allows the event to be processed.
         * For most events it is not necessary to call this method as the events are allowed anyhow 
         * but some are forbidden by default (this will be mentioned in the corresponding event description).</summary>*/
        public void Allow()
        {
            wxNotifyEvent_Allow(wxObject);
        }

        /** <summary>This is <c>true</c> if processing this event is allowed (has not been vetoed).
         * You may also set a value. This will either call Veto() or Allow().</summary>*/
        public bool Allowed
        {
            get { return wxNotifyEvent_IsAllowed(wxObject); }
            set
            {
                if (value)
                    this.Allow();
                else
                    this.Veto();
            }
        }		
    }
}
