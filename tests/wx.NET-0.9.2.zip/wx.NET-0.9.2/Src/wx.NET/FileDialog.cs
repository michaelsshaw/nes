//-----------------------------------------------------------------------------
// wx.NET - FileDialog.cs
//
// The wxFileDialog wrapper class.
//
// Written by Achim Breunig (achim.breunig@web.de)
// (C) 2003 Achim Breunig
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: FileDialog.cs,v 1.17 2010/05/08 19:52:40 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Drawing;
using System.Runtime.InteropServices;

namespace wx
{
    public class FileDialog : Dialog
    {
    	#region C API
        [DllImport("wx-c")] static extern IntPtr wxFileDialog_ctor(IntPtr parent, IntPtr message, IntPtr defaultDir, IntPtr defaultFile, IntPtr wildcard, uint style, int posX, int posY);
        [DllImport("wx-c")] static extern void   wxFileDialog_dtor(IntPtr self);

        [DllImport("wx-c")] static extern IntPtr wxFileDialog_GetDirectory(IntPtr self);
        [DllImport("wx-c")] static extern void   wxFileDialog_SetDirectory(IntPtr self, IntPtr dir);

        [DllImport("wx-c")] static extern IntPtr wxFileDialog_GetFilename(IntPtr self);
        [DllImport("wx-c")] static extern void   wxFileDialog_SetFilename(IntPtr self, IntPtr filename);

        [DllImport("wx-c")] static extern IntPtr wxFileDialog_GetPath(IntPtr self);
        [DllImport("wx-c")] static extern void   wxFileDialog_SetPath(IntPtr self, IntPtr path);

        [DllImport("wx-c")] static extern void   wxFileDialog_SetFilterIndex(IntPtr self, int filterIndex);
        [DllImport("wx-c")] static extern int    wxFileDialog_GetFilterIndex(IntPtr self);

        [DllImport("wx-c")] static extern IntPtr wxFileDialog_GetWildcard(IntPtr self);
        [DllImport("wx-c")] static extern void   wxFileDialog_SetWildcard(IntPtr self, IntPtr wildcard);

        [DllImport("wx-c")] static extern void   wxFileDialog_SetMessage(IntPtr self, IntPtr message);
        [DllImport("wx-c")] static extern IntPtr wxFileDialog_GetMessage(IntPtr self);

        [DllImport("wx-c")] static extern int    wxFileDialog_ShowModal(IntPtr self);

        [DllImport("wx-c")] static extern uint   wxFileDialog_GetStyle(IntPtr self);
        [DllImport("wx-c")] static extern void   wxFileDialog_SetStyle(IntPtr self, uint style);

        [DllImport("wx-c")] static extern IntPtr wxFileDialog_GetPaths(IntPtr self);
        [DllImport("wx-c")] static extern IntPtr wxFileDialog_GetFilenames(IntPtr self);
		#endregion
        //---------------------------------------------------------------------

		#region CTor / DTor
        public FileDialog(IntPtr wxObject)
            : base(wxObject) { }

        /// <summary>Use this CTor with dialog style. 
        /// Specific style flags start with prefix FD_.
        /// Will ask you to <c>_("Choose a file")</c>.
        /// </summary>
        /// <param name="parent">The parent window</param>
        public FileDialog(Window parent)
            : this(parent, _("Choose a file"), "", "", "*.*", wx.WindowStyles.NO_STYLE, wxDefaultPosition) { }

        /// <summary>Use this CTor with dialog style. 
        /// Specific style flags start with prefix FD_.
        /// </summary>
        /// <param name="message">Message string</param>
        /// <param name="parent">The parent window</param>
        public FileDialog(Window parent, string message)
            : this(parent, message, "", "", "*.*", wx.WindowStyles.NO_STYLE, wxDefaultPosition) { }

        /// <summary>Use this CTor with dialog style. 
        /// Specific style flags start with prefix FD_.
        /// </summary>
        /// <param name="message">Message string</param>
        /// <param name="defaultDir">Displays files in this path first</param>
        /// <param name="parent">The parent window</param>
        public FileDialog(Window parent, string message, string defaultDir)
            : this(parent, message, defaultDir, "", "*.*", wx.WindowStyles.NO_STYLE, wxDefaultPosition) { }

        /// <summary>Use this CTor with dialog style. 
        /// Specific style flags start with prefix FD_.
        /// </summary>
        /// <param name="message">Message string</param>
        /// <param name="defaultDir">Displays files in this path first</param>
        /// <param name="defaultFile">The default filename</param>
        /// <param name="parent">The parent window</param>
        public FileDialog(Window parent, string message, string defaultDir, string defaultFile)
            : this(parent, message, defaultDir, defaultFile, "*.*", wx.WindowStyles.NO_STYLE, wxDefaultPosition) { }

        /// <summary>Use this CTor with dialog style. 
        /// Specific style flags start with prefix FD_.
        /// </summary>
        /// <param name="message">Message string</param>
        /// <param name="defaultDir">Displays files in this path first</param>
        /// <param name="defaultFile">The default filename</param>
        /// <param name="wildcard">Determines which files will be displayed. Example: <c>"BMP files (*.bmp)|*.bmp|GIF files (*.gif)|*.gif"</c>.</param>
        /// <param name="parent">The parent window</param>
        public FileDialog(Window parent, string message, string defaultDir, string defaultFile, string wildcard)
            : this(parent, message, defaultDir, defaultFile, wildcard, wx.WindowStyles.NO_STYLE, wxDefaultPosition) { }

        /// <summary>Use this CTor with dialog style. 
        /// Specific style flags start with prefix FD_.
        /// </summary>
        /// <param name="message">Message string</param>
        /// <param name="defaultDir">Displays files in this path first</param>
        /// <param name="defaultFile">The default filename</param>
        /// <param name="wildcard">Determines which files will be displayed. Example: <c>"BMP files (*.bmp)|*.bmp|GIF files (*.gif)|*.gif"</c>.</param>
        /// <param name="flags">The window styles</param>
        /// <param name="parent">The parent window</param>
        public FileDialog(Window parent, string message, string defaultDir, string defaultFile, string wildcard, wx.WindowStyles style)
            : this(parent, message, defaultDir, defaultFile, wildcard, style, wxDefaultPosition) { }

        /// <summary>Use this CTor with dialog style. 
        /// Specific style flags start with prefix FD_.
        /// </summary>
        /// <param name="message">Message string</param>
        /// <param name="defaultDir">Displays files in this path first</param>
        /// <param name="defaultFile">The default filename</param>
        /// <param name="wildcard">Determines which files will be displayed. Example: <c>"BMP files (*.bmp)|*.bmp|GIF files (*.gif)|*.gif"</c>.</param>
        /// <param name="flags">The window styles</param>
        /// <param name="parent">The parent window</param>
        /// <param name="pos">The position of this dialog</param>
        public FileDialog(Window parent, string message, string defaultDir, string defaultFile, string wildcard, wx.WindowStyles style, Point pos)
            : this(parent, wxString.SafeNew(message), wxString.SafeNew(defaultDir), wxString.SafeNew(defaultFile), wxString.SafeNew(wildcard), style, pos.X, pos.Y) { }

        static IntPtr LockedCTor(Window parent, wxString message, wxString defaultDir, wxString defaultFile, wxString wildcard, wx.WindowStyles style, int posX, int posY)
        {
            lock (DllSync)
            {
                return wxFileDialog_ctor(Object.SafePtr(parent), Object.SafePtr(message), Object.SafePtr(defaultDir), Object.SafePtr(defaultFile), Object.SafePtr(wildcard), (uint)style, posX, posY);
            }
        }

        /** <summary>Use this CTor with dialog style. 
         * Specific style flags start with prefix FD_.</summary>*/
        public FileDialog(Window parent, wxString message, wxString defaultDir, wxString defaultFile, wxString wildcard, wx.WindowStyles style, int posX, int posY)
            : this(LockedCTor(parent, message, defaultDir, defaultFile, wildcard, style, posX, posY)) { }
            
        protected override void CallDTor ()
        {
            wxFileDialog_dtor(this.wxObject);
        }

		#endregion
        //---------------------------------------------------------------------

        /// <summary>
        /// The directory where the files have been selected.
        /// </summary>
        public string Directory
        {
            get { return new wxString(wxFileDialog_GetDirectory(wxObject), true); }
            set
            {
                wxString wxValue = wxString.SafeNew(value);
                wxFileDialog_SetDirectory(wxObject, Object.SafePtr(wxValue));
            }
        }

        /// <summary>
        /// Returns the file that has been selected without directory.
        /// </summary>
        public string Filename
        {
            get { return new wxString(wxFileDialog_GetFilename(wxObject), true); }
            set
            {
                wxString wxValue = wxString.SafeNew(value);
                wxFileDialog_SetFilename(wxObject, Object.SafePtr(wxValue));
            }
        }

        /// <summary>
        /// Returns the path that has been selected - directory and filename.
        /// </summary>
        public string Path
        {
            get { return new wxString(wxFileDialog_GetPath(wxObject), true); }
            set
            {
                wxString wxValue = wxString.SafeNew(value);
                wxFileDialog_SetPath(wxObject, Object.SafePtr(wxValue));
            }
        }

        public int FilterIndex
        {
            set
            {
                wxFileDialog_SetFilterIndex(wxObject, value);
            }
            get { return wxFileDialog_GetFilterIndex(wxObject); }
        }

        public string Message
        {
            set
            {
                wxString wxValue = wxString.SafeNew(value);
                wxFileDialog_SetMessage(wxObject, Object.SafePtr(wxValue));
            }
            get { return new wxString(wxFileDialog_GetMessage(wxObject), true); }
        }

        //---------------------------------------------------------------------

        /// <summary>
        /// This will show the dialog, wait for an input and return ShowModalResult.OK on successful userinput.
        /// On cancelled input, the result will be ShowModalResult.CANCEL.
        /// Read <c>Filename</c> or <c>Filenames</c> for the results.
        /// </summary>
        public override ShowModalResult ShowModal()
        {
            int result=wxFileDialog_ShowModal(wxObject);
            return result == 5100 ? ShowModalResult.OK : ShowModalResult.CANCEL;
        }

        //---------------------------------------------------------------------

        public string Wildcard
        {
            get { return new wxString(wxFileDialog_GetWildcard(wxObject), true); }
            set
            {
                wxString wxValue = wxString.SafeNew(value);
                wxFileDialog_SetWildcard(wxObject, Object.SafePtr(wxValue));
            }
        }

        public wx.WindowStyles style
        {
            get { return (wx.WindowStyles)wxFileDialog_GetStyle(this.wxObject); }
            set { wxFileDialog_SetStyle(wxObject, (uint)value); }
        }

        //---------------------------------------------------------------------

        /// <summary>
        /// Returns the paths that have been selected - directory and filename.
        /// </summary>
        public string[] Paths
        {
            get { return new ArrayString(wxFileDialog_GetPaths(this.wxObject), true); }
        }

        /// <summary>
        /// Returns an array of the selected filenames (without directory).
        /// </summary>
        public string[] Filenames
        {
            get { return new ArrayString(wxFileDialog_GetFilenames(this.wxObject), true); }
        }
    }
}

