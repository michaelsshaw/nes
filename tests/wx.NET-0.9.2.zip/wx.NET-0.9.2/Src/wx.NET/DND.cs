//-----------------------------------------------------------------------------
// wx.NET - Dnd.cs
//
// The wxDND wrapper classes.
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 by Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
// 
// $Id: DND.cs,v 1.19 2009/11/04 18:15:40 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Runtime.InteropServices;

namespace wx 
{

    /** \page drag-and-drop Drag and drop overview
     * It may be noted that data transfer to and from the clipboard is quite similar to data transfer with drag and drop and
     * the code to implement these two types is almost the same. In particular, both data transfer mechanisms store data in
     * some kind of wxDataObject and identify its format(s) using the wxDataFormat class.
     *
     * To be a drag source, i.e. to provide the data which may be dragged by the user elsewhere, you should implement the
     * following steps:
     *
     * <ol>
     * <li>Preparation: First of all, a data object must be created and initialized with the data you wish to drag. For example:
     * <code>
	 * wx.TextDataObject my_data=new wx.TextDataObject("This text will be dragged.");
     * </code>
     * Drag start: To start the dragging process (typically in response to a mouse click) you must call wx.DropSource.DoDragDrop
     * like this:
     * <code>
	 * wx.DropSource dragSource=new wx.DropSource( this );
	 * dragSource.SetData( my_data );
	 * wx.DragResult result = dragSource.DoDragDrop( true );
     * </code>
     * </li>
     * <li>Dragging: The call to wx.DropSource.DoDragDrop() blocks the program until the user releases the mouse button (unless you override 
     * the GiveFeedback function to do something special). When the mouse moves in a window of a program which understands
     * the same drag-and-drop protocol (any program under Windows or any program supporting the XDnD protocol under X Windows),
     * the corresponding wxDropTarget methods are called - see below. 
     * </li>
     * <li>Processing the result: wx.DropSource.DoDragDrop() returns an effect code which is one of the values of wx.DragResult enum (explained here):
     * <code>
	 * switch (result)
     * {
     *    case wx.DragResult.DragCopy: copy the data; break;
     *    case wx.DragResult.DragMove: move the data; break;
     *    default:                     do nothing; break;
     * }
     * </code>
     * </ol>
     * To be a drop target, i.e. to receive the data dropped by the user you should follow the instructions below:
     * <ol>
     * <li>Initialization: For a window to be a drop target, it needs to have an associated wx.DropTarget object.
     * Normally, you will call wxWindow::SetDropTarget during window creation associating your drop target with it.
     * You must derive a class from wxDropTarget and override its pure virtual methods. Alternatively, you may derive
     * from wx.TextDropTarget or wx.FileDropTarget and override their OnDropText() or OnDropFiles() method. 
     * </li>
     * <li>Drop: When the user releases the mouse over a window, wxWidgets asks the associated wx.DropTarget
     * object if it accepts
     * the data. For this, a wx.DataObject must be associated with the drop target and this data object will be responsible
     * for the format negotiation between the drag source and the drop target. If all goes well, then wx.DropTarget.OnData will get called
     * and the wx.DataObject belonging to the drop target can get filled with data. 
     * The end: After processing the data, DoDragDrop() returns either wx.DragResult.DragCopy or wx.DragResult.DragMove
     * depending on the state of the keys [Ctrl], [Shift] and [Alt] at the moment of the drop. There is currently no way
     * for the drop target to change this return code.
     * </li>
     * </ol>
     */

    /// <summary> Flags to define the drag operation in wx.DragSource.DoDragDrop().</summary>
    /// <remarks>Cf. \ref drag-and-drop.</remarks>
    public enum Drag
	{
		wxDrag_CopyOnly    = 0,
		wxDrag_AllowMove   = 1,
		wxDrag_DefaultMove = 3
	}
	
	//---------------------------------------------------------------------

	public enum DragResult
	{
    		wxDragError,
    		wxDragNone,
    		wxDragCopy,
    		wxDragMove,
    		wxDragLink,
    		wxDragCancel
	}
	
	//---------------------------------------------------------------------

    /// <summary>
    /// This class represents a source for a drag and drop operation.
    /// </summary>
    /// <remarks>Cf. \ref drag-and-drop</remarks>
	public class DropSource : Object
	{
		private delegate int Virtual_DoDragDrop(int flags);

		private Virtual_DoDragDrop virtual_DoDragDrop;
		
		protected DataObject m_dataObject = null;
		
		[DllImport("wx-c")] static extern IntPtr wxDropSource_Win_ctor(IntPtr win);
		[DllImport("wx-c")] static extern IntPtr wxDropSource_DataObject_ctor(IntPtr dataObject, IntPtr win);
		[DllImport("wx-c")] static extern void wxDropSource_dtor(IntPtr self);
		[DllImport("wx-c")] static extern void wxDropSource_RegisterVirtual(IntPtr self, Virtual_DoDragDrop doDragDrop);
		[DllImport("wx-c")] static extern int wxDropSource_DoDragDrop(IntPtr self, int flags);
		[DllImport("wx-c")] static extern void wxDropSource_SetData(IntPtr self, IntPtr dataObject);
		
		//---------------------------------------------------------------------

        /// <summary>
        /// For internal use only
        /// </summary>
        /// <param name="wxObject">Pointer to a native C++ instance</param>
		public DropSource(IntPtr wxObject)
			: base(wxObject) 
		{
			this.wxObject = wxObject;
		}		
			
		internal DropSource(IntPtr wxObject, bool memOwn)
			: base(wxObject)
		{ 
			this.memOwn = memOwn;
			this.wxObject = wxObject;
		}

        static IntPtr LockedCTor(Window win)
        {
            lock (DllSync)
            {
                return wxDropSource_Win_ctor(Object.SafePtr(win));
            }
        }

        /// <summary>
        /// Creates a drop source referring to the provided window as data source.
        /// </summary>
        /// <param name="win">The source of the dropped data.</param>
		public DropSource(Window win)
			: this(LockedCTor(win), true) 
		{ 
			m_dataObject = null;
			
			virtual_DoDragDrop = new Virtual_DoDragDrop(DoDoDragDrop);

			wxDropSource_RegisterVirtual( wxObject, virtual_DoDragDrop );
		}

        static IntPtr LockedCTor(DataObject dataObject, Window win)
        {
            lock (DllSync)
            {
                return wxDropSource_DataObject_ctor(Object.SafePtr(dataObject), Object.SafePtr(win));
            }
        }

        /// <summary>
        /// Creates a drop source referring to a window provising the data and the dragged data.
        /// </summary>
        /// <param name="dataObject">The dragged data.</param>
        /// <param name="win">The source of the dropped data.</param>
        public DropSource(DataObject dataObject, Window win)
			: this(LockedCTor(dataObject, win), true) 
		{
			m_dataObject = dataObject;

			virtual_DoDragDrop = new Virtual_DoDragDrop(DoDoDragDrop);
			
			wxDropSource_RegisterVirtual( wxObject, virtual_DoDragDrop );
		}
		
		//---------------------------------------------------------------------
				
		public override void Dispose()
		{
			if (!disposed)
			{
                if (wxObject != IntPtr.Zero)
				{
					if (memOwn)
					{
						wxDropSource_dtor(wxObject);
						memOwn = false;
					}
				}
				RemoveObject(wxObject);
				wxObject = IntPtr.Zero;
                --validInstancesCount;
                disposed = true;
			}
			
			base.Dispose();
			GC.SuppressFinalize(this);
		}
		
		//---------------------------------------------------------------------
		
		~DropSource() 
		{
			Dispose();
		}

		//---------------------------------------------------------------------

        /// <summary>
        /// Do it (call this in response to a mouse button press, for example).
        /// This starts the drag-and-drop operation which will terminate when the user releases the mouse.
        /// </summary>
        /// <param name="flags">Describes the drag operation.
        /// If wx.Drag.wxDrag_AllowMove is included in the flags, data may be moved and not only copied (default).
        /// If wx.Drag.wxDrag_DefaultMove is specified (which includes the previous flag), this is even the default 
        /// operation.</param>
        /// <returns>Returns the operation requested by the user, may be wx.Drag.wxDragCopy, wx.Drag.wxDragMove,
        /// wx.Drag.wxDragLink, wx.Drag.wxDragCancel, or wx.Drag.wxDragNone if an error occurred.</returns>
        public virtual DragResult DoDragDrop(Drag flags)
		{
			return (DragResult)wxDropSource_DoDragDrop(wxObject, (int)flags);
		}

        private int DoDoDragDrop(int flags)
		{
			return (int)DoDragDrop((Drag)flags);
		}
		
		//---------------------------------------------------------------------
		
		public DataObject DataObject
		{
			get { return m_dataObject; }
			set { m_dataObject = value; wxDropSource_SetData(wxObject, Object.SafePtr(value)); }
		}
	}
	
	//---------------------------------------------------------------------

    /// <summary>
    /// This class represents a target for a drag and drop operation. A wx.DataObject can be associated with it and by default,
    /// this object will be filled with the data from the drag source, if the data formats supported by the data object match
    /// the drag source data format.
    ///
    /// There are various virtual handler functions defined in this class which may be overridden to give visual feedback or
    /// react in a more fine-tuned way, e.g. by not accepting data on the whole window area, but only a small portion of it.
    /// The normal sequence of calls is OnEnter(), possibly many times OnDragOver(), OnDrop() and finally OnData().
    /// </summary>
    /// <remarks>
    /// Cf. \ref drag-and-drop.
    /// </remarks>
	public abstract class DropTarget : Object
	{
		private delegate int Virtual_OnDragOver(int x, int y, int def);
		private delegate bool Virtual_OnDrop(int x, int y);
		private delegate int Virtual_OnData3(int x, int y, int def);
		private delegate bool Virtual_GetData();
		private delegate void Virtual_OnLeave();
		private delegate int Virtual_OnEnter(int x, int y, int def);

		private Virtual_OnDragOver virtual_OnDragOver;
		private Virtual_OnDrop virtual_OnDrop;
		private Virtual_OnData3 virtual_OnData3;
		private Virtual_GetData virtual_GetData;
		private Virtual_OnLeave virtual_OnLeave;
		private Virtual_OnEnter virtual_OnEnter;
		
		//---------------------------------------------------------------------
		
		protected DataObject m_dataObject = null;
		
		//---------------------------------------------------------------------
		
		[DllImport("wx-c")] static extern IntPtr wxDropTarget_ctor(IntPtr dataObject);
		[DllImport("wx-c")] static extern void wxDropTarget_dtor(IntPtr self);
		[DllImport("wx-c")] static extern void wxDropTarget_RegisterVirtual(IntPtr self, Virtual_OnDragOver onDragOver, Virtual_OnDrop onDrop, Virtual_OnData3 onData, Virtual_GetData getData, Virtual_OnLeave onLeave, Virtual_OnEnter onEnter);  
		[DllImport("wx-c")] static extern void   wxDropTarget_RegisterDisposable(IntPtr self, Virtual_Dispose onDispose);
		[DllImport("wx-c")] static extern void   wxDropTarget_SetDataObject(IntPtr self, IntPtr dataObject);
		[DllImport("wx-c")] static extern int wxDropTarget_OnEnter(IntPtr self, int x, int y, int def);
		[DllImport("wx-c")] static extern int wxDropTarget_OnDragOver(IntPtr self, int x, int y, int def);
		[DllImport("wx-c")] static extern void   wxDropTarget_OnLeave(IntPtr self);
		[DllImport("wx-c")] static extern bool wxDropTarget_OnDrop(IntPtr self, int x, int y);
		[DllImport("wx-c")] static extern bool wxDropTarget_GetData(IntPtr self);
		
		//---------------------------------------------------------------------

		public DropTarget()
			: this(null) { }

        static IntPtr LockedCTor(DataObject dataObject)
        {
            lock (DllSync)
            {
                return wxDropTarget_ctor(Object.SafePtr(dataObject));
            }
        }
		
		public DropTarget(DataObject dataObject)
			: this(LockedCTor(dataObject), true) 
		{ 
			m_dataObject = dataObject;

			virtual_OnDragOver = new Virtual_OnDragOver(DoOnDragOver);
			virtual_OnDrop = new Virtual_OnDrop(OnDrop);
			virtual_OnData3 = new Virtual_OnData3(DoOnData);
			virtual_GetData = new Virtual_GetData(GetData);
			virtual_OnLeave = new Virtual_OnLeave(OnLeave);
			virtual_OnEnter = new Virtual_OnEnter(DoOnEnter);
			
			wxDropTarget_RegisterVirtual( wxObject, virtual_OnDragOver,
				virtual_OnDrop,
				virtual_OnData3,
				virtual_GetData,
				virtual_OnLeave,
				virtual_OnEnter);
				
			virtual_Dispose = new Virtual_Dispose(VirtualDispose);
			wxDropTarget_RegisterDisposable(wxObject, virtual_Dispose);
		}

		public DropTarget(IntPtr wxObject)
			: base(wxObject) 
		{
			this.wxObject = wxObject;
		}			
		
		internal DropTarget(IntPtr wxObject, bool memOwn)
			: base(wxObject)
		{ 
			this.memOwn = memOwn;
			this.wxObject = wxObject;
		}
		
		//---------------------------------------------------------------------
				
		public override void Dispose()
		{
			if (!disposed)
			{
                if (wxObject != IntPtr.Zero)
				{
					if (memOwn)
					{
						wxDropTarget_dtor(wxObject);
						memOwn = false;
					}
				}
				RemoveObject(wxObject);
				wxObject = IntPtr.Zero;
                --validInstancesCount;
                disposed = true;
			}
			
			base.Dispose();
			GC.SuppressFinalize(this);
		}
		
		//---------------------------------------------------------------------
		
		~DropTarget() 
		{
			Dispose();
		}

		//---------------------------------------------------------------------

        /// <summary>
        /// Called when the mouse is being dragged over the drop target.
        /// By default, this calls functions return the suggested return value "def".
        /// </summary>
        /// <param name="x">The x coordinate of the mouse.</param>
        /// <param name="y">The y coordinate of the mouse.</param>
        /// <param name="def">Suggested default for return value. Determined by SHIFT or CONTROL key states.</param>
        public virtual DragResult OnDragOver(int x, int y, DragResult def)
		{
			return (DragResult)wxDropTarget_OnDragOver(wxObject, x, y, (int)def);
		}
		
		private int DoOnDragOver(int x, int y, int def)
		{
			return (int)OnDragOver(x, y, (DragResult)def);
		}
		
		//---------------------------------------------------------------------

        /// <summary>
        /// Called when the user drops a data object on the target. Return false to veto the operation.
        /// </summary>
        /// <param name="x">The x coordinate of the mouse.</param>
        /// <param name="y">The y coordinate of the mouse.</param>
        /// <returns>Return true to accept the data, false to veto the operation.</returns>
		public virtual bool OnDrop(int x, int y)
		{
			return wxDropTarget_OnDrop(wxObject, x, y);
		}
		
		//---------------------------------------------------------------------

        /// <summary>
        /// Called after OnDrop() returns true. By default this will usually GetData() and will return the suggested default
        /// value def.
        /// </summary>
        /// <param name="x">The x coordinate of the mouse.</param>
        /// <param name="y">The y coordinate of the mouse.</param>
        /// <param name="def">Suggested default for return value. Determined by SHIFT or CONTROL key states.</param>
        public abstract DragResult OnData(int x, int y, DragResult def);
		
		private int DoOnData(int x, int y, int def)
		{
			return (int)OnData(x, y, (DragResult) def);
		}

		//---------------------------------------------------------------------

        /// <summary>
        /// This method may only be called from within wx.DropTarget.OnData.
        /// By default, this method copies the data from the drop source to the wx.DataObject associated
        /// with this drop target, calling its wx.DataObject.SetData method.
        /// </summary>
        public virtual bool GetData()
		{
			return wxDropTarget_GetData(wxObject);
		}
		
		//---------------------------------------------------------------------

        /// <summary>
        /// Called when the mouse enters the drop target. By default, this calls OnDragOver().
        /// </summary>
        /// <param name="x">The x coordinate of the mouse.</param>
        /// <param name="y">The y coordinate of the mouse.</param>
        /// <param name="def">Suggested default for return value. Determined by SHIFT or CONTROL key states.</param>
        /// <returns>Returns the desired operation or wxDragNone. This is used for optical feedback from the
        /// side of the drop source, typically in form of changing the icon.</returns>
		public virtual DragResult OnEnter(int x, int y, DragResult def)
		{
			return (DragResult)wxDropTarget_OnEnter(wxObject, x, y, (int)def);
		}
		
		private int DoOnEnter(int x, int y, int def)
		{
			return (int)OnEnter(x, y, (DragResult) def);
		}
		
		//---------------------------------------------------------------------

        /// <summary>
        /// Called when the mouse leaves the drop target.
        /// </summary>
		public virtual void OnLeave()
		{
			wxDropTarget_OnLeave(wxObject);
		}
		
		//---------------------------------------------------------------------

        /// <summary>
        /// Sets the data wxDataObject associated with the drop target and deletes any previously associated data object.
        /// </summary>
		public DataObject DataObject
		{
			get { return m_dataObject; }
			set { m_dataObject = value; wxDropTarget_SetDataObject(wxObject, Object.SafePtr(value)); }
		}
	}
	
	//---------------------------------------------------------------------

    /// <summary>
    /// A predefined drop target for dealing with text data.
    /// </summary>
    /// <remarks>
    /// Cf. \ref drag-and-drop.
    /// </remarks>
	public abstract class TextDropTarget : DropTarget
	{
		[DllImport("wx-c")] static extern bool wxTextDropTarget_OnDrop(IntPtr self, int x, int y);
		[DllImport("wx-c")] static extern bool wxTextDropTarget_GetData(IntPtr self);

		//---------------------------------------------------------------------

		public TextDropTarget()
			: base(new TextDataObject()) {}
			

        /// <summary>
        /// Override this function to receive dropped text.
        /// </summary>
        /// <param name="x">The x coordinate of the mouse.</param>
        /// <param name="y">The y coordinate of the mouse.</param>
        /// <param name="text">The data being dropped: a string.</param>
        /// <returns>Return true to accept the data, false to veto the operation.</returns>
		public abstract bool OnDropText(int x, int y, string text);

		//---------------------------------------------------------------------

		public override DragResult OnData(int x, int y, DragResult def)
		{
			if (!GetData())
				return DragResult.wxDragNone;
				
			TextDataObject dobj = (TextDataObject)m_dataObject;
		
			return OnDropText(x, y, dobj.Text) ? def : DragResult.wxDragNone;
		}

		//---------------------------------------------------------------------
        
		public override bool OnDrop(int x, int y)
		{
			return wxTextDropTarget_OnDrop(wxObject, x, y);
		}
		
		//---------------------------------------------------------------------

		public override bool GetData()
		{
			return wxTextDropTarget_GetData(wxObject);
		}
	}
	
	//---------------------------------------------------------------------

    /// <summary>
    /// This is a drop target which accepts files e.g. dragged from File Manager or Explorer
    /// (\ref drag-and-drop).
    /// </summary>
	public abstract class FileDropTarget : DropTarget
	{
		[DllImport("wx-c")] static extern bool wxFileDropTarget_OnDrop(IntPtr self, int x, int y);
		[DllImport("wx-c")] static extern bool wxFileDropTarget_GetData(IntPtr self);

		//---------------------------------------------------------------------

		public FileDropTarget()
			: base(new FileDataObject()) {}

        /// <summary>Called if files are dropped on this target.</summary>
        /// <param name="x">The x coordinate of the mouse.</param>
        /// <param name="y">The y coordinate of the mouse.</param>
        /// <param name="filenames">Names of the files to be dropped</param>
        /// <returns>Return true to accept the data, false to veto the operation.</returns>
        public abstract bool OnDropFiles(int x, int y, string[] filenames);
		
		//---------------------------------------------------------------------

		public override DragResult OnData(int x, int y, DragResult def)
		{
			if ( !GetData() )
				return DragResult.wxDragNone;
				
			FileDataObject dobj = (FileDataObject)m_dataObject;
			
			return OnDropFiles(x, y, dobj.Filenames) ? def : DragResult.wxDragNone;
		}

		//---------------------------------------------------------------------
        
        /// <summary>
        /// See wx.DropTarget.OnDrop. This function is implemented appropriately for files, and calls wx.FileDropTarget.OnDropFiles().
        /// </summary>
        /// <param name="x">The x coordinate of the mouse.</param>
        /// <param name="y">The y coordinate of the mouse.</param>
        /// <returns>Return true to accept the data, false to veto the operation.</returns>
		public override bool OnDrop(int x, int y)
		{
			return wxFileDropTarget_OnDrop(wxObject, x, y);
		}
		
		//---------------------------------------------------------------------

		public override bool GetData()
		{
			return wxFileDropTarget_GetData(wxObject);
		}
	}
}

