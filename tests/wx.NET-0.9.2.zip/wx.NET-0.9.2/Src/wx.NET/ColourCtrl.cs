//-----------------------------------------------------------------------------
// wx.NET - DateTimeCtrl.cs
// 
// A colour chooser based on MaskedEdit.
//
// Written by Harald Meyer auf'm Hofe
// (C) 2008 Harald Meyer auf'm Hofe
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: ColourCtrl.cs,v 1.5 2009/10/11 16:23:18 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System.Drawing;
using System;

namespace wx
{
    /** <summary>This is a control to put in colours that may be used within forms or tables.
     * This is a panel composed of a masked edit control allowing for the input of RGB and Alpha values and
     * a button, that will rise a colour dialog if pressed. The button will be coloured in the specified
     * colour.</summary>*/
    public class ColourCtrl : Panel
    {
        #region State
        Button _dialogStarter;
        MaskedEdit.MaskedEdit _edit;
        Colour _value;
        #endregion

        #region CTor
        public ColourCtrl(Window parent, int id, Point position, Size size, WindowStyles style, Colour initialValue)
            : base(parent, id, position, size, style | WindowStyles.TAB_TRAVERSAL)
        {
            BoxSizer sizer = new StaticBoxSizer(Orientation.wxHORIZONTAL, this);
            this._edit = new wx.MaskedEdit.MaskedEdit(this, "{0}x{1}x{2}:{3}", new MaskedEdit.EditField[]
                {
                    MaskedEdit.EditIntField.New("red").SetWidth(3).SetIn(0, 255).SetEmptyChar('0').SetTextAttributes(new TextAttr(wx.Colour.wxRED)),
                    MaskedEdit.EditIntField.New("green").SetWidth(3).SetIn(0, 255).SetEmptyChar('0').SetTextAttributes(new TextAttr(new wx.Colour(0, 192, 0))),
                    MaskedEdit.EditIntField.New("blue").SetWidth(3).SetIn(0, 255).SetEmptyChar('0').SetTextAttributes(new TextAttr(wx.Colour.wxBLUE)),
                    MaskedEdit.EditIntField.New("alpha").SetWidth(3).SetIn(0, 255).SetEmptyChar('0'),
                });
            this._edit.BackgroundColour = Colour.wxWHITE;

            this._dialogStarter = new Button(this, " ", wxDefaultPosition, new Size(16, 16), WindowStyles.BORDER_RAISED);
            this._dialogStarter.BackgroundColour = initialValue;

            sizer.Add(this._edit, 0, SizerFlag.wxEXPAND | SizerFlag.wxALIGN_CENTER);
            sizer.Add(this._dialogStarter, 0, SizerFlag.wxALIGN_CENTER);
            this.Sizer = sizer;

            this._value=new Colour(initialValue);

            this._edit[0].Object = this._value.Red;
            this._edit[1].Object = this._value.Green;
            this._edit[2].Object = this._value.Blue;
            this._edit[3].Object = this._value.Alpha;

            this._edit[0].OnChanged += new wx.MaskedEdit.MaskedEditFieldValueChangedHandler(this.OnChangedColourField);
            this._edit[1].OnChanged += new wx.MaskedEdit.MaskedEditFieldValueChangedHandler(this.OnChangedColourField);
            this._edit[2].OnChanged += new wx.MaskedEdit.MaskedEditFieldValueChangedHandler(this.OnChangedColourField);
            this._edit[3].OnChanged += new wx.MaskedEdit.MaskedEditFieldValueChangedHandler(this.OnChangedColourField);

            this._dialogStarter.EVT_BUTTON(-1, new EventListener(this.OnPressedColourCtrl));
        }

        public ColourCtrl(Window parent, Point position, Size size, WindowStyles style, Colour initialValue)
            : this(parent, -1, position, size, style, initialValue)
        {
        }
        #endregion

        #region Events
        /** <summary>Argument of change event handlers.</summary>*/
        public class OnChangedEvent : EventArgs
        {
            #region State
            wx.Colour _newColour;
            #endregion

            #region CTor
            public OnChangedEvent(Colour newColour)
            {
                this._newColour=newColour;
            }
            #endregion

            #region Public Properties
            public Colour NewColour { get { return this._newColour; } }
            #endregion
        }

        /** <summary>Handler of the "value changed" event.</summary>*/
        public delegate void OnChangedHandler(object sender, OnChangedEvent evt);

        /** <summary>This will be called immediately after a value has been changed.</summary>*/
        public event OnChangedHandler OnChanged;

        bool _changeEventLock = false;
        void OnChangedColourField(object sender, MaskedEdit.MaskedEditFieldValueChangedEvent evt)
        {
            if (evt.Field.Name.Equals("red"))
                this._value.Red = (byte)(int)evt.Field.Object;
            else if (evt.Field.Name.Equals("green"))
                this._value.Green = (byte)(int)evt.Field.Object;
            else if (evt.Field.Name.Equals("blue"))
                this._value.Blue = (byte)(int)evt.Field.Object;
            else if (evt.Field.Name.Equals("alpha"))
                this._value.Alpha = (byte)(int)evt.Field.Object;

            this._dialogStarter.BackgroundColour = this._value;

            if (!this._changeEventLock && this.OnChanged != null)
            {
                try
                {
                    this._changeEventLock = true;
                    this.OnChanged(this, new OnChangedEvent(this._value));
                }
                finally
                {
                    this._changeEventLock = false;
                }
            }
        }

        void OnPressedColourCtrl(object sender, Event evt)
        {
            ColourData colourData = new ColourData(this._value);
            colourData.ChooseFull = true;
            ColourDialog dialog = new ColourDialog(this, colourData);
            ShowModalResult result=dialog.ShowModal();
            if (result == ShowModalResult.OK || result == ShowModalResult.YES)
            {
                bool changeEventLockOrig = this._changeEventLock;
                try
                {
                    this._changeEventLock = true;

                    this._value = dialog.ColourData.Colour;
                    this._edit[0].Object = (int)this._value.Red;
                    this._edit[1].Object = (int)this._value.Green;
                    this._edit[2].Object = (int)this._value.Blue;
                    this._edit[3].Object = (int)this._value.Alpha;

                    if (!changeEventLockOrig && this.OnChanged != null)
                    {
                        this.OnChanged(this, new OnChangedEvent(this._value));
                    }
                }
                finally
                {
                    this._changeEventLock = changeEventLockOrig;
                }
            }
        }
        #endregion

        #region Public Properties
        /** <summary>This is for reading the colour input.</summary>*/
        public Colour Colour { get { return this._value; } }
        #endregion
    }
}
