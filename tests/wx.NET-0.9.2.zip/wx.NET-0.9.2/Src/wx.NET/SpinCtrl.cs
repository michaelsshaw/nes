//-----------------------------------------------------------------------------
// wx.NET - SpinCtrl.cs
//
// The wxSpinCtrl wrapper class.
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: SpinCtrl.cs,v 1.16 2010/06/06 08:57:25 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Drawing;
using System.Runtime.InteropServices;

namespace wx
{
    /** <summary>wx.SpinCtrl combines wx.TextCtrl and wx.SpinButton in one control.</summary>*/
	public class SpinCtrl : Control 
	{
		[DllImport("wx-c")] static extern IntPtr wxSpinCtrl_ctor();
		[DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)] static extern bool   wxSpinCtrl_Create(IntPtr self, IntPtr parent, int id, IntPtr value, int posX, int posY, int width, int height, uint style, int min, int max, int initial, IntPtr name);
		[DllImport("wx-c")] static extern int    wxSpinCtrl_GetValue(IntPtr self);
		[DllImport("wx-c")] static extern int    wxSpinCtrl_GetMin(IntPtr self);
		[DllImport("wx-c")] static extern int    wxSpinCtrl_GetMax(IntPtr self);
		[DllImport("wx-c")] static extern void   wxSpinCtrl_SetValueStr(IntPtr self, IntPtr value);
		[DllImport("wx-c")] static extern void   wxSpinCtrl_SetValue(IntPtr self, int val);
		[DllImport("wx-c")] static extern void   wxSpinCtrl_SetRange(IntPtr self, int min, int max);
        [DllImport("wx-c")]
        static extern void wxSpinCtrl_SetSelection(IntPtr self, int from, int to);
	
		//---------------------------------------------------------------------
		
		public SpinCtrl(IntPtr wxObject) 
			: base(wxObject) {}

		public SpinCtrl()
			: base(wxSpinCtrl_ctor()) { }

		public SpinCtrl(Window parent, int id)
			: this(parent, id, "", wxDefaultPosition, wxDefaultSize, wx.WindowStyles.SP_ARROW_KEYS, 0, 100, 0, null ) { }

		public SpinCtrl(Window parent, int id, string value)
            : this(parent, id, value, wxDefaultPosition, wxDefaultSize, wx.WindowStyles.SP_ARROW_KEYS, 0, 100, 0, null) { }

		public SpinCtrl(Window parent, int id, string value, Point pos, Size size)
            : this(parent, id, value, pos, size, wx.WindowStyles.SP_ARROW_KEYS, 0, 100, 0, null) { }

		public SpinCtrl(Window parent, int id, string value, Point pos, Size size, wx.WindowStyles style)
			: this(parent, id, value, pos, size, style, 0, 100, 0, null ) { }

		public SpinCtrl(Window parent, int id, string value, Point pos, Size size, wx.WindowStyles style, int min, int max, int initial)
			: this(parent, id, value, pos, size, style, min, max, initial, null ) { }

		public SpinCtrl(Window parent, int id, string value, Point pos, Size size, wx.WindowStyles style, int min, int max, int initial, string name)
			: base(wxSpinCtrl_ctor())
		{
			if(!Create(parent, id, value, pos, size, style, min, max, initial, name))
			{
				throw new InvalidOperationException("Failed to create SpinCtrl");
			}
		}
		
		//---------------------------------------------------------------------
		// ctors with self created id
		
		public SpinCtrl(Window parent)
            : this(parent, Window.UniqueID, "", wxDefaultPosition, wxDefaultSize, wx.WindowStyles.SP_ARROW_KEYS, 0, 100, 0, null) { }

		public SpinCtrl(Window parent, string value)
            : this(parent, Window.UniqueID, value, wxDefaultPosition, wxDefaultSize, wx.WindowStyles.SP_ARROW_KEYS, 0, 100, 0, null) { }

		public SpinCtrl(Window parent, string value, Point pos, Size size)
            : this(parent, Window.UniqueID, value, pos, size, wx.WindowStyles.SP_ARROW_KEYS, 0, 100, 0, null) { }

		public SpinCtrl(Window parent, string value, Point pos, Size size, wx.WindowStyles style)
			: this(parent, Window.UniqueID, value, pos, size, style, 0, 100, 0, null ) { }

		public SpinCtrl(Window parent, string value, Point pos, Size size, wx.WindowStyles style, int min, int max, int initial)
			: this(parent, Window.UniqueID, value, pos, size, style, min, max, initial, null ) { }

		public SpinCtrl(Window parent, string value, Point pos, Size size, wx.WindowStyles style, int min, int max, int initial, string name)
			: this(parent, Window.UniqueID, value, pos, size, style, min, max, initial, name) {}
		
		//---------------------------------------------------------------------

        public bool Create(Window parent, int id, string value, Point pos, Size size, wx.WindowStyles style, int min, int max, int initial, string name)
        {
            return this.Create(parent, id, wxString.SafeNew(value), pos, size, style, min, max, initial, wxString.SafeNew(name));
        }
		public bool Create(Window parent, int id, wxString value, Point pos, Size size, wx.WindowStyles style, int min, int max, int initial, wxString name)
		{
			return wxSpinCtrl_Create(wxObject, Object.SafePtr(parent), id, 
					Object.SafePtr(value), pos.X, pos.Y, size.Width, size.Height, (uint)style, min,
					max, initial, Object.SafePtr(name));
		}

		//---------------------------------------------------------------------

		public int Value
		{
			get { return wxSpinCtrl_GetValue(wxObject); }
			set
            {
                wxSpinCtrl_SetValue(wxObject, value);
            }
		}

		public void SetValue(string val)
		{
            wxString wxvalue = wxString.SafeNew(val);
            wxSpinCtrl_SetValueStr(wxObject, Object.SafePtr(wxvalue));
		}

		//---------------------------------------------------------------------
        
		public int Max
		{
			get { return wxSpinCtrl_GetMax(wxObject); }
		}

		public int Min
		{
			get { return wxSpinCtrl_GetMin(wxObject); }
		}

		public void SetRange(int min, int max)
		{
			wxSpinCtrl_SetRange(wxObject, min, max);
		}

        public void SetSelection(int from, int to)
        {
            wxSpinCtrl_SetSelection(this.wxObject, from, to);
        }

		//---------------------------------------------------------------------

		public override event EventListener UpdateUI
		{
			add { AddCommandListener(Event.wxEVT_COMMAND_SPINCTRL_UPDATED, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}
	}
}

