/** wx.NET - ChoiceDialog.cs
* \file
* 
* The wxChoiceDialog wrapper classes.
*
* Written by Alexander Olk (xenomorph2@onlinehome.de)
* (C) 2003 Alexander Olk
* Licensed under the wxWidgets license, see LICENSE.txt for details.
*
* $Id: ChoiceDialog.cs,v 1.17 2009/07/03 18:49:29 harald_meyer Exp $
*/

using System;
using System.Drawing;
using System.Runtime.InteropServices;

namespace wx
{
    public class SingleChoiceDialog : Dialog
    {
        [DllImport("wx-c")] static extern IntPtr wxSingleChoiceDialog_ctor(IntPtr parent, IntPtr message, IntPtr caption, IntPtr choices, IntPtr clientData, uint style, int posX, int posY);
        [DllImport("wx-c")] static extern void wxSingleChoiceDialog_SetSelection(IntPtr self, int sel);
        [DllImport("wx-c")] static extern int wxSingleChoiceDialog_GetSelection(IntPtr self);
        [DllImport("wx-c")] static extern IntPtr wxSingleChoiceDialog_GetStringSelection(IntPtr self);
        [DllImport("wx-c")] static extern IntPtr wxSingleChoiceDialog_GetSelectionClientData(IntPtr self);

        //-----------------------------------------------------------------------------

        // TODO: ClientData... !?!

        public SingleChoiceDialog(IntPtr wxObject)
            : base(wxObject) {}

        public SingleChoiceDialog(Window parent, string message, string caption, string[] choices)
            : this(parent, message, caption, choices, null, wx.WindowStyles.CHOICEDLG_STYLE, wxDefaultPosition) {}

        public SingleChoiceDialog(Window parent, string message, string caption, string[] choices, ClientData[] clientData)
            : this(parent, message, caption, choices, clientData, wx.WindowStyles.CHOICEDLG_STYLE, wxDefaultPosition) { }

        public SingleChoiceDialog(Window parent, string message, string caption, string[] choices, ClientData[] clientData, wx.WindowStyles style)
            : this(parent, message, caption, choices, clientData, style, wxDefaultPosition) {}

        public  SingleChoiceDialog(Window parent, string message, string caption, string[] choices, ClientData[] clientData, wx.WindowStyles style, Point pos)
            : this(parent, wxString.SafeNew(message), wxString.SafeNew(caption), ArrayString.SafeNewFrom(choices), ArrayIntPtr.SafeNewFrom(clientData), style, pos)
        {
        }

        static IntPtr LockedCTor(Window parent, wxString message, wxString caption, ArrayString choices, ArrayIntPtr clientData, wx.WindowStyles style, Point pos)
        {
            lock (DllSync)
            {
                return wxSingleChoiceDialog_ctor(Object.SafePtr(parent), Object.SafePtr(message), Object.SafePtr(caption), Object.SafePtr(choices), ArrayIntPtr.SafePtr(clientData), (uint)style, pos.X, pos.Y);
            }
        }

        internal SingleChoiceDialog(Window parent, wxString message, wxString caption, ArrayString choices, ArrayIntPtr clientData, wx.WindowStyles style, Point pos)
            : base(LockedCTor(parent, message, caption, choices, clientData, style, pos))
        {
        }

        //-----------------------------------------------------------------------------

        public void SetSelection(int sel)
        {
            wxSingleChoiceDialog_SetSelection(wxObject, sel);
        }

        //-----------------------------------------------------------------------------

        public int GetSelection()
        {
            return wxSingleChoiceDialog_GetSelection(wxObject);
        }

        //-----------------------------------------------------------------------------

        public string GetStringSelection()
        {
            return new wxString(wxSingleChoiceDialog_GetStringSelection(wxObject), true);
        }

        //-----------------------------------------------------------------------------

        public ClientData GetSelectionClientData()
        {
            return (ClientData)Object.FindObject(wxSingleChoiceDialog_GetSelectionClientData(wxObject));
        }
    }

	//-----------------------------------------------------------------------------

    public class MultiChoiceDialog : Dialog
    {
        [DllImport("wx-c")] static extern IntPtr wxMultiChoiceDialog_ctor(IntPtr parent, IntPtr message, IntPtr caption, IntPtr choices, uint style, int posX, int posY);
        [DllImport("wx-c")] static extern void wxMultiChoiceDialog_SetSelections(IntPtr self, int[] sel, int numsel);
        [DllImport("wx-c")] static extern IntPtr wxMultiChoiceDialog_GetSelections(IntPtr self);

        //-----------------------------------------------------------------------------

        public MultiChoiceDialog(IntPtr wxObject)
            : base(wxObject) {}

        public MultiChoiceDialog(Window parent, string message, string caption, string[] choices)
            : this(parent, message, caption, choices, wx.WindowStyles.CHOICEDLG_STYLE, wxDefaultPosition) {}

        public MultiChoiceDialog(Window parent, string message, string caption, string[] choices, wx.WindowStyles style)
            : this(parent, message, caption, choices, style, wxDefaultPosition) {}

        public MultiChoiceDialog(Window parent, string message, string caption, string[] choices, wx.WindowStyles style, Point pos)
            : this(parent, wxString.SafeNew(message), wxString.SafeNew(caption), ArrayString.SafeNewFrom(choices), style, pos.X, pos.Y)
        { }

        static IntPtr LockedCTor(Window parent, wxString message, wxString caption, ArrayString choices, wx.WindowStyles style, int posX, int posY)
        {
            lock (DllSync)
            {
                return wxMultiChoiceDialog_ctor(Object.SafePtr(parent), Object.SafePtr(message), Object.SafePtr(caption), Object.SafePtr(choices), (uint)style, posX, posY);
            }
        }

        public MultiChoiceDialog(Window parent, wxString message, wxString caption, ArrayString choices, wx.WindowStyles style, int posX, int posY)
            : base(LockedCTor(parent, message, caption, choices, style, posX, posY)) {}

        //-----------------------------------------------------------------------------

        public void SetSelections(int[] sel)
        {
            wxMultiChoiceDialog_SetSelections(wxObject, sel, sel.Length);
        }

        //-----------------------------------------------------------------------------

        public int[] GetSelections()
        {
            return new ArrayInt(wxMultiChoiceDialog_GetSelections(wxObject), true);
        }
    }

	//-----------------------------------------------------------------------------

	public class GetSingleChoice
	{
		public const int wxCHOICE_HEIGHT = 150;
		public const int wxCHOICE_WIDTH  = 200;
		public string value = "";

		//-----------------------------------------------------------------------------

        [DllImport("wx-c")] static extern IntPtr wxGetSingleChoice_func(IntPtr message, IntPtr caption, IntPtr choices, IntPtr parent, int x, int y, bool centre, int width, int height);

        	//-----------------------------------------------------------------------------

		public GetSingleChoice(string message, string caption, string[] choices)
		{
            wxString wxMessage = wxString.SafeNew(message);
            wxString wxCaption = wxString.SafeNew(caption);
            ArrayString wxChoices = ArrayString.SafeNewFrom(choices);
			value = new wxString(wxGetSingleChoice_func(Object.SafePtr(wxMessage), Object.SafePtr(wxCaption), Object.SafePtr(wxChoices), IntPtr.Zero, -1, -1, true, wxCHOICE_WIDTH, wxCHOICE_HEIGHT), true);
		}

        	//-----------------------------------------------------------------------------

		public GetSingleChoice(string message, string caption, string[] choices, Window parent, int x, int y, bool centre, int width, int height)
		{
            wxString wxMessage = wxString.SafeNew(message);
            wxString wxCaption = wxString.SafeNew(caption);
            ArrayString wxChoices = ArrayString.SafeNewFrom(choices);
            value = new wxString(wxGetSingleChoice_func(Object.SafePtr(wxMessage), Object.SafePtr(wxCaption), Object.SafePtr(wxChoices), Object.SafePtr(parent), x, y, centre, width, height), true);
		}

		//-----------------------------------------------------------------------------

		public static implicit operator string(GetSingleChoice g)
		{
			return g.value;
		}
	}
}

