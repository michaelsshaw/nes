//-----------------------------------------------------------------------------
// wx.NET - Panel.cs
//
// The wxPanel wrapper class.
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: Panel.cs,v 1.22 2010/05/08 19:54:35 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Drawing;
using System.Runtime.InteropServices;

namespace wx
{
    /** <summary>A panel is a window on which controls are placed.
     * It is usually placed within a frame. It contains minimal extra functionality over and above its parent
     * class wx.Window; its main purpose is to be similar in appearance and functionality to a dialog, but with
     * the flexibility of having any window as a parent.
     *
     * Note: if not all characters are being intercepted by your OnKeyDown or OnChar handler, it may be because you are
     * using the wx.WindowStyles.TAB_TRAVERSAL style, which grabs some keypresses for use by child controls.</summary>*/
    public class Panel : Window
    {
        delegate void OverloadedAction();
        #region C API
        [DllImport("wx-c")] static extern IntPtr wxPanel_ctor();
		[DllImport("wx-c")] static extern IntPtr wxPanel_ctor2(IntPtr parent, int id, int posX, int posY, int width, int height, uint style, IntPtr name);
		[DllImport("wx-c")][return:MarshalAs(UnmanagedType.U1)] static extern bool wxPanel_Create(IntPtr self, IntPtr parent, int id, int posX, int posY, int width, int height, uint style, IntPtr name);
		//[DllImport("wx-c")] static extern void wxPanel_InitDialog(IntPtr self);

        [DllImport("wx-c")]
        static extern void wxPanel_SetFocus(IntPtr self);
        [DllImport("wx-c")]
        static extern void wxPanel_SetFocusVirtuals(IntPtr self, OverloadedAction cbSetFocus, OverloadedAction cbSetFocusFromKbd);
        #endregion

        #region State
        OverloadedAction _cbSetFocus=null;
        OverloadedAction _cbSetFocusFromKbd=null;
        #endregion

        //---------------------------------------------------------------------
		
		public Panel(IntPtr wxObject) 
			: base(wxObject)
        {
        }
		
		public Panel()
			: base(wxPanel_ctor())
        {
            this._cbSetFocus = new OverloadedAction(this.SetFocus);
            this._cbSetFocusFromKbd = new OverloadedAction(this.SetFocusFromKbd);
            wxPanel_SetFocusVirtuals(this.wxObject, this._cbSetFocus, this._cbSetFocusFromKbd);
        }

		public Panel(Window parent)
			: this(parent, Window.UniqueID, wxDefaultPosition, wxDefaultSize, wx.WindowStyles.TAB_TRAVERSAL|wx.WindowStyles.BORDER_NONE, "panel") { }

		public Panel(Window parent, int id)
            : this(parent, id, wxDefaultPosition, wxDefaultSize, wx.WindowStyles.TAB_TRAVERSAL | wx.WindowStyles.BORDER_NONE, "panel") { }

		public Panel(Window parent, int id, Point pos, Size size)
            : this(parent, id, pos, size, wx.WindowStyles.TAB_TRAVERSAL | wx.WindowStyles.BORDER_NONE, "panel") { }

        /** <summary>Do not forget to use style wx.WindowStyles.TAB_TRAVERSAL if you want this panel to be traversal.</summary>*/
        public Panel(Window parent, int id, Point pos, Size size, wx.WindowStyles style)
			: this(parent, id, pos, size, style, "panel") { }

        /** <summary>Do not forget to use style wx.WindowStyles.TAB_TRAVERSAL if you want this panel to be traversal.</summary>*/
        public Panel(Window parent, int id, Point pos, Size size, wx.WindowStyles style, string name)
            : this(parent, id, pos, size, style, wxString.SafeNew(name)) { }

        /** <summary>Do not forget to use style wx.WindowStyles.TAB_TRAVERSAL if you want this panel to be traversal.</summary>*/
        public Panel(Window parent, int id, Point pos, Size size, wx.WindowStyles style, wxString name)
            : base(wxPanel_ctor2(Object.SafePtr(parent), id, pos.X, pos.Y, size.Width, size.Height, (uint)style, Object.SafePtr(name)))
        {
            this._cbSetFocus = new OverloadedAction(this.SetFocus);
            this._cbSetFocusFromKbd = new OverloadedAction(this.SetFocusFromKbd);
            wxPanel_SetFocusVirtuals(this.wxObject, this._cbSetFocus, this._cbSetFocusFromKbd);
        }
			
		//---------------------------------------------------------------------
		// ctors with self created id
		
		public Panel(Window parent, Point pos, Size size)
            : this(parent, Window.UniqueID, pos, size, wx.WindowStyles.TAB_TRAVERSAL | wx.WindowStyles.BORDER_NONE, "panel") { }

        /** <summary>Do not forget to use style wx.WindowStyles.TAB_TRAVERSAL if you want this panel to be traversal.</summary>*/
        public Panel(Window parent, Point pos, Size size, wx.WindowStyles style)
			: this(parent, Window.UniqueID, pos, size, style, "panel") { }

        /** <summary>Do not forget to use style wx.WindowStyles.TAB_TRAVERSAL if you want this panel to be traversal.</summary>*/
        public Panel(Window parent, Point pos, Size size, wx.WindowStyles style, string name)
			: this(parent, Window.UniqueID, pos, size, style, name) {}
		
		//---------------------------------------------------------------------

        /** <summary>Do not forget to use style wx.WindowStyles.TAB_TRAVERSAL if you want this panel to be traversal.</summary>*/
        public bool Create(Window parent, int id, Point pos, Size size, wx.WindowStyles style, string name)
        {
            wxString wxname = wxString.SafeNew(name);
            return this.Create(parent, id, pos, size, style, wxname);
        }
        /** <summary>Do not forget to use style wx.WindowStyles.TAB_TRAVERSAL if you want this panel to be traversal.</summary>*/
        public bool Create(Window parent, int id, Point pos, Size size, wx.WindowStyles style, wxString name)
		{
			return wxPanel_Create(wxObject, Object.SafePtr(parent), id, pos.X, pos.Y, size.Width, size.Height, (uint)style, Object.SafePtr(name));
		}

		//---------------------------------------------------------------------

        public override void SetFocus()
        {
            wxPanel_SetFocus(this.wxObject);
        }
        public override void SetFocusFromKbd()
        {
            wxPanel_SetFocus(this.wxObject);
        }
	}
}
