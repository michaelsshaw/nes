//-----------------------------------------------------------------------------
// wx.NET - KeyEvent.cs
// 
// The wxKeyEvent wrapper class.
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: KeyEvent.cs,v 1.10 2009/09/20 14:10:58 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Drawing;
using System.Runtime.InteropServices;

namespace wx
{
    public class KeyEvent : Event
    {
        [DllImport("wx-c")] static extern IntPtr wxKeyEvent_ctor(int type);

        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxKeyEvent_ControlDown(IntPtr self);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxKeyEvent_ShiftDown(IntPtr self);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxKeyEvent_AltDown(IntPtr self);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxKeyEvent_MetaDown(IntPtr self);

        [DllImport("wx-c")] static extern int    wxKeyEvent_GetRawKeyCode(IntPtr self);
        [DllImport("wx-c")] static extern int    wxKeyEvent_GetKeyCode(IntPtr self);

        [DllImport("wx-c")] static extern int    wxKeyEvent_GetRawKeyFlags(IntPtr self);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxKeyEvent_HasModifiers(IntPtr self);

        [DllImport("wx-c")] static extern void   wxKeyEvent_GetPosition(IntPtr self, ref Point pt);
        [DllImport("wx-c")] static extern int    wxKeyEvent_GetX(IntPtr self);
        [DllImport("wx-c")] static extern int    wxKeyEvent_GetY(IntPtr self);
	
	    [DllImport("wx-c")][return:MarshalAs(UnmanagedType.U1)] static extern bool   wxKeyEvent_CmdDown(IntPtr self);

        [DllImport("wx-c")] static extern int wxKeyEvent_GetUnicodeChar(IntPtr self);


        //-----------------------------------------------------------------------------

        public KeyEvent(IntPtr wxObject) 
            : base(wxObject) { }

        public KeyEvent(int type)
            : this(wxKeyEvent_ctor(type)) { }

        //-----------------------------------------------------------------------------

        public bool ControlDown
        {
            get { return wxKeyEvent_ControlDown(wxObject); }
        }

        public bool MetaDown
        {
            get { return wxKeyEvent_MetaDown(wxObject); }
        }

        public bool ShiftDown
        {
            get { return wxKeyEvent_ShiftDown(wxObject); }
        }

        public bool AltDown
        {
            get { return wxKeyEvent_AltDown(wxObject); }
        }

        //-----------------------------------------------------------------------------

        public KeyCode KeyCodeSymbol
        {
            get { return (KeyCode)wxKeyEvent_GetKeyCode(wxObject); }
        }

        /** <summary>The keycode with values from Enumeration KeyCode. Refer also to KeyCodeSymbol.</summary>*/
        public int KeyCode
        {
            get { return wxKeyEvent_GetKeyCode(wxObject); }
        }
	
        /** <summary>Returns the raw, uninterpreted, platform dependent key code.
         *</summary>*/
        public int RawKeyCode
        {
            get { return wxKeyEvent_GetRawKeyCode(wxObject); }
        }

        /** <summary>Returns the low level key flags for this event.
         * The flags are platform-dependent and should only be used in advanced applications.</summary>*/
        public int RawKeyFlags
        {
            get { return wxKeyEvent_GetRawKeyFlags(wxObject); }
        }

        /** <summary>Returns the wide character equivalent to the pressed key.
         * This only works correctly if either  wxWidgets has been built with Unicode support or if an ASCII key
         * has been pressed. Otherwise, the result will be a 0.</summary>*/
        public char UnicodeChar
        {
            get { return (char)wxKeyEvent_GetUnicodeChar(wxObject); }
        }

        //-----------------------------------------------------------------------------

        public bool HasModifiers
        {
            get { return wxKeyEvent_HasModifiers(wxObject); }
        }

        //-----------------------------------------------------------------------------

        public Point Position
        {
            get {
                Point pt = new Point();
                wxKeyEvent_GetPosition(wxObject, ref pt);
                return pt;
            }
        }

        //-----------------------------------------------------------------------------

        public int X
        {
            get { return wxKeyEvent_GetX(wxObject); }
        }

        public int Y
        {
            get { return wxKeyEvent_GetY(wxObject); }
        }

        //-----------------------------------------------------------------------------
	
	public bool CmdDown
	{
		get { return wxKeyEvent_CmdDown(wxObject); }
	}
    }
}
