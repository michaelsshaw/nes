/**
 * wx.NET Project
 * 
 * \file 
 * 
 * A wrapper for the \e wxCombobox control.
 * 
 * Written by Dr. Harald Meyer auf'm Hofe (C) 2008 
 * Licensed under the wxWidgets license, see LICENSE.txt for details.
 *
 * $Id: ComboCtrl.cs,v 1.8 2010/05/08 19:51:26 harald_meyer Exp $
 */

using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;

namespace wx
{
    /** <summary>This interface declares those methods which are required by popups of a <c>ComboCtrl</c>.
     * Please note, that in contrast to the original  wxWidgets class hierarchy, this is  not intended as
     * a base class that shall be inherited together with <c>wx.Control</c>. In contrast, the control shall be
     * a member of this. Refer to wx.DatePicker for an example.
     * </summary>
     */
    public abstract class ComboPopup : Object
    {
        #region Delegates
        delegate void CallInit();
        delegate bool CallCreate(Window parent);
        delegate void CallOnPopup();
        delegate void CallOnDismiss();

        void DoSetStringValue(IntPtr stringValue)
        {
            using (wxString wxstr = wxString.SafeNew(stringValue))
            {
                wxstr.memOwn = false;
                this.SetStringValue(wxstr.ToString());
            }
        }
        delegate void CallSetStringValue(IntPtr stringValue);

        IntPtr DoGetStringValue()
        {
            string netstr=this.GetStringValue();
            using (wxString wxstr = wxString.SafeNew(netstr))
            {
                wxstr.memOwn = false;
                return Object.SafePtr(wxstr);
            }
        }
        delegate IntPtr CallGetStringValue();

        void DoPaintComboControl(IntPtr dcPtr, int x, int y, int w, int h)
        {
            DC dc = (DC)Object.FindObject(dcPtr, typeof(DC), false);
            this.PaintComboControl(dc, new System.Drawing.Rectangle(x, y, w, h));
        }
        delegate void CallPaintComboControl(IntPtr dc, int x, int y, int w, int h);
        void DoOnComboKeyEvent(IntPtr kevtPtr)
        {
            using (KeyEvent kevt = Event.CreateFrom(kevtPtr) as KeyEvent)
            {
                this.OnComboKeyEvent(kevt);
            }
        }
        delegate void CallOnComboKeyEvent( IntPtr kevt );
        delegate void CallOnComboDoubleClick();
        void DoGetAdjustedSize(out int w, out int h, int minWidth, int prefHeight, int maxHeight)
        {
            System.Drawing.Size s = this.GetAdjustedSize(minWidth, prefHeight, maxHeight);
            w = s.Width;
            h = s.Height;
        }
        delegate void CallGetAdjustedSize( out int w, out int h, int minWidth, int prefHeight, int maxHeight );
        delegate bool CallLazyCreate();
        delegate IntPtr CallGetControl();
        #endregion

        #region C API
        [DllImport("wx-c")]
        static extern IntPtr wxComboPopup_ctor();
        [DllImport("wx-c")]
        static extern void wxComboPopup_dtor(IntPtr self);
        [DllImport("wx-c")]
        static extern IntPtr wxComboPopup_ComboControl(IntPtr self);
        [DllImport("wx-c")]
        static extern void wxComboPopup_PaintComboControl(IntPtr self, IntPtr dc, int x, int y, int w, int h);
        [DllImport("wx-c")]
        static extern void wxComboPopup_GetAdjustedSize(IntPtr self, out int w, out int height, int minWidth, int prefHeight, int maxHeight);
        [DllImport("wx-c")]
        static extern void wxComboPopup_Dismiss(IntPtr self);
        [DllImport("wx-c")][return:MarshalAs(UnmanagedType.U1)]
        static extern bool wxComboPopup_IsCreated(IntPtr self);
        [DllImport("wx-c")]
        static extern void wxComboPopup_RegisterVirtual(IntPtr self, Virtual_Dispose virtualDispose, CallInit callInit,
            CallCreate callCreate, CallOnPopup callOnPopup, CallOnDismiss callOnDismiss, CallSetStringValue setStringValue,
            CallGetStringValue getStringValue, CallPaintComboControl paintCombo, CallOnComboKeyEvent onKeyEvent,
            CallOnComboDoubleClick comboDoubleClick, CallGetAdjustedSize getAdjustedSize, CallLazyCreate lazyCreate, CallGetControl getControl);
        #endregion

        #region State
        /** <summary>Load this with the popup control that will be shown on popup.
         * This may either be set by a CTor or by an implementation of Create().</summary>*/
        protected Window _control;

        CallInit _callInit;
        CallCreate _callCreate;
        CallOnPopup _callOnPopup;
        CallOnDismiss _callOnDismiss;
        CallSetStringValue _callSetStringValue;
        CallGetStringValue _callGetStringValue;
        CallPaintComboControl _callPaintCombo;
        CallOnComboKeyEvent _callOnComboKeyEvent;
        CallOnComboDoubleClick _callComboDoubleClick;
        CallGetAdjustedSize _callGetAdjustedSize;
        CallLazyCreate _callLazyCreate;
        CallGetControl _callGetControl;
        #endregion

        #region CTor, DTor
        /** <summary>CTor already defining a control that will be poped up.
         * \param control is the control that will be shown on popup. Please note, that this is required to implement 2 step contruction
         *        since that parent will be delivered calling Create(), not earlier.</summary>*/
        public ComboPopup(Window control)
            : this()
        {
            this._control = control;
        }

        static IntPtr LockedCTor()
        {
            lock (DllSync)
            {
                return wxComboPopup_ctor();
            }
        }

        /** <summary>CTor creating a sceleton without defining an instance for the popup window.
         * If you use this, use Create() to create the <c>PopupControl</c>.
         * </summary>
         */
        public ComboPopup()
            : base(LockedCTor(), StorageMode.RegisteredObject, true)
        {
            ReflectConfig.AssertWxWinVersion28();

            this._control = null;

            this.virtual_Dispose=new Virtual_Dispose(this.VirtualDispose);
            this._callCreate = new CallCreate(this.Create);
            this._callInit = new CallInit(this.Init);
            this._callOnPopup = new CallOnPopup(this.OnPopup);
            this._callOnDismiss = new CallOnDismiss(this.OnDismiss);
            this._callGetStringValue = new CallGetStringValue(this.DoGetStringValue);
            this._callSetStringValue = new CallSetStringValue(this.DoSetStringValue);
            this._callPaintCombo = new CallPaintComboControl(this.DoPaintComboControl);
            this._callOnComboKeyEvent = new CallOnComboKeyEvent(this.DoOnComboKeyEvent);
            this._callComboDoubleClick = new CallOnComboDoubleClick(this.OnComboDoubleClick);
            this._callGetAdjustedSize = new CallGetAdjustedSize(this.DoGetAdjustedSize);
            this._callLazyCreate = new CallLazyCreate(this.LazyCreate);
            this._callGetControl = new CallGetControl(this.DoGetControl);

            wxComboPopup_RegisterVirtual(this.wxObject, this.virtual_Dispose, this._callInit, this._callCreate,
                this._callOnPopup, this._callOnDismiss, this._callSetStringValue, this._callGetStringValue,
                this._callPaintCombo, this._callOnComboKeyEvent, this._callComboDoubleClick,
                this._callGetAdjustedSize, this._callLazyCreate, this._callGetControl);
        }

        protected override void CallDTor()
        {
            wxComboPopup_dtor(Object.SafePtr(this));
            this._control = null;
        }
        #endregion

        #region Public Properties
        IntPtr DoGetControl() { return wx.Object.SafePtr(this._control); }

        /** <summary>The control that will be shown on popup.
         * </summary>
         */
        public Window PopupControl { get { return this._control; } }

        /** <summary>This is the combo box that will popup this.
         * </summary>
         */
        public ComboCtrl ComboControl { get { return wx.Object.FindObject(wxComboPopup_ComboControl(this.wxObject)) as ComboCtrl; } }

        /** <summary>Synonym for <c>GetStringValue() </c> and <c>SetStringValue() </c>. </summary>
         */
        public string StringValue
        {
            get { return this.GetStringValue(); }
            set { this.SetStringValue(value); }
        }
        #endregion

        #region Overloads
        /** <summary>This is called immediately after construction finishes. m_combo member
          * variable has been initialized before the call.</summary>*/
        public virtual void Init()
        {
        }

        /** <summary>Create the popup child control.
         * Implementors shall set <c>_control</c>.
         * Return true for success.
         * </summary>
         */
        protected abstract bool Create(Window parent);

        /** <summary>Called immediately after the popup is shown.
         * </summary>
         */
        protected virtual void OnPopup()
        {
        }

        /** <summary>Called when popup is dismissed.
         * </summary>
         */
        protected virtual void OnDismiss()
        {
        }

        /** <summary>Called just prior to displaying popup.
         * Default implementation does nothing.
         * </summary>
         */
        public virtual void SetStringValue(string value)
        {
        }

        /** <summary>Gets displayed string representation of the value.</summary>*/
        public abstract string GetStringValue();

        /** <summary>This is called to custom paint in the combo control itself (ie. not the popup).
         * Default implementation draws value as string.</summary>*/
        public virtual void PaintComboControl( DC dc, System.Drawing.Rectangle rect )
        {
            wxComboPopup_PaintComboControl(this.wxObject, dc.wxObject, rect.X, rect.Y, rect.Width, rect.Height);
        }

        /** <summary>Receives key events from the parent wxComboCtrl.
         * Events not handled should be skipped, as usual.
         * </summary>
         */
        public virtual void OnComboKeyEvent( KeyEvent evt )
        {
            evt.Skip();
        }

        /** <summary>Implement if you need to support special action when user double-clicks on the parent wx.ComboCtrl.
         * </summary>
         */
        public virtual void OnComboDoubleClick()
        {
        }

        /** <summary>Return final size of popup.
         * Called on every popup, just prior to <c>OnShow</c>.
         * </summary>
         * <param name="minWidth"> is the preferred minimum width for window</param>
         * <param name="prefHeight">is the preferred height. Only applies if larger than 0,</param>
         * <param name="maxHeight"> is the max. height for window, as limited by screen size and should only be rounded down, if necessary.
         * </param>
         */
        public virtual System.Drawing.Size GetAdjustedSize( int minWidth, int prefHeight, int maxHeight )
        {
            int h, w;
            wxComboPopup_GetAdjustedSize(this.wxObject, out w, out h, minWidth, prefHeight, maxHeight);
            return new System.Drawing.Size(w, h);
        }

        /** <summary>Return true if you want delay call to Create until the popup is shown for the first time.
         * It is more efficient, but note that it is often
         * more convenient to have the control created immediately.
         * Default returns false.
         * </summary>
         */
        public virtual bool LazyCreate()
        {
            return false;
        }
        #endregion

        #region Utilities
        /** <summary>Hides the popup.</summary>
         */
        public void Dismiss()
        {
            wxComboPopup_Dismiss(this.wxObject);
        }

        /** <summary>Returns true if Create() has been called.</summary>
         */
        public bool IsCreated()
        {
            return wxComboPopup_IsCreated(this.wxObject);
        }
        #endregion
    }

    /** <summary>The generic combo control available since wxWidgets 2.8.
     * A combo control is a generic combobox that allows totally custom popup.
     * In addition it has other customization features. For instance, position and size of the dropdown button can be changed.
     * 
     * <c>ComboCtrl</c> needs to be told somehow which control to use and this is done by <c>SetPopupControl() </c>.
     * However, we need something more than just a <c>Control</c> in this method as, for example, we need to call
     * <c> SetStringValue("initial text value") </c> and <c>Control</c> doesn't have such a method.
     * So we also need a <c>ComboPopup</c>
     * which is an interface that must be implemented by a control to be usable as a popup.
     * 
     * Refer to wx.DatePicker for an example.
     * </summary>
     */
    public class ComboCtrl : Control
    {
        #region Delegates, Method Handles
        delegate void CallOnButtonClick();
        #endregion

        #region C API
        [DllImport("wx-c")]
        static extern IntPtr wxComboCtrl_ctor();
        [DllImport("wx-c")]
        static extern void wxComboCtrl_Create(IntPtr self, IntPtr parent, int id, IntPtr valueStr, int x, int y, int w, int h, int styles, IntPtr name);
        [DllImport("wx-c")]
        static extern void wxComboCtrl_ShowPopup(IntPtr self);
        [DllImport("wx-c")]
        static extern void wxComboCtrl_HidePopup(IntPtr self);
        [DllImport("wx-c")]
        static extern void wxComboCtrl_OnButtonClick(IntPtr self);
        [DllImport("wx-c")][return:MarshalAs(UnmanagedType.U1)]
        static extern bool wxComboCtrl_IsPopupShown(IntPtr self);
        [DllImport("wx-c")]
        static extern IntPtr wxComboCtrl_GetPopupControl(IntPtr self);
        [DllImport("wx-c")]
        static extern IntPtr wxComboCtrl_GetPopupWindow(IntPtr self);
        [DllImport("wx-c")]
        static extern IntPtr wxComboCtrl_GetTextCtrl(IntPtr self);
        [DllImport("wx-c")]
        static extern IntPtr wxComboCtrl_GetButton(IntPtr self);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxComboCtrl_Enable(IntPtr self, bool enable);
        //[DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)]static extern bool wxComboCtrl_Show(IntPtr self, bool enable);
        [DllImport("wx-c")]
        static extern void wxComboCtrl_SetFont(IntPtr self, IntPtr font);
        [DllImport("wx-c")]
        static extern void wxComboCtrl_SetPopupControl(IntPtr self, IntPtr ctrl);
        [DllImport("wx-c")]
        static extern IntPtr wxComboCtrl_GetValue(IntPtr self);
        [DllImport("wx-c")]
        static extern void wxComboCtrl_SetValue(IntPtr self, IntPtr stringValue);
        [DllImport("wx-c")]
        static extern void wxComboCtrl_RegisterVirtual(IntPtr self, CallOnButtonClick onButtonClick);
        [DllImport("wx-c")]
        static extern void wxComboCtrl_Copy(IntPtr self);
        [DllImport("wx-c")]
        static extern void wxComboCtrl_Cut(IntPtr self);
        [DllImport("wx-c")]
        static extern void wxComboCtrl_Paste(IntPtr self);
        [DllImport("wx-c")]
        static extern void wxComboCtrl_SetInsertionPoint(IntPtr self, int position);
        [DllImport("wx-c")]
        static extern void wxComboCtrl_SetInsertionPointEnd(IntPtr self);
        [DllImport("wx-c")]
        static extern int wxComboCtrl_GetInsertionPoint(IntPtr self);
        [DllImport("wx-c")]
        static extern int wxComboCtrl_GetLastPosition(IntPtr self);
        [DllImport("wx-c")]
        static extern void wxComboCtrl_Replace(IntPtr self, int from, int to, IntPtr value);
        [DllImport("wx-c")]
        static extern void wxComboCtrl_Remove(IntPtr self, int from, int to);
        [DllImport("wx-c")]
        static extern void wxComboCtrl_SetSelection(IntPtr self, int from, int to);
        [DllImport("wx-c")]
        static extern void wxComboCtrl_Undo(IntPtr self);

        #endregion

        #region State
        CallOnButtonClick _onButtonClick;
        #endregion

        #region CTor
        static IntPtr LockedCTor()
        {
            lock (DllSync)
            {
                return wxComboCtrl_ctor();
            }
        }

        /** <summary>2-step construction: Step one before Create().</summary>*/
        public ComboCtrl()
            : base(LockedCTor())
        {
            ReflectConfig.AssertWxWinVersion28();

            this._onButtonClick = new CallOnButtonClick(this.OnButtonClick);
            wxComboCtrl_RegisterVirtual(this.wxObject, this._onButtonClick);
        }

        public ComboCtrl(Window parent, int id, string value, System.Drawing.Point position, System.Drawing.Size size, WindowStyles style, string name)
            : this()
        {
            this.Create(parent, id, value, position, size, style, name);
        }

        public ComboCtrl(Window parent, int id, string value, System.Drawing.Point position, System.Drawing.Size size, WindowStyles style)
            : this(parent, id, value, position, size, style, "ComboCtrl")
        {
        }
        public ComboCtrl(Window parent, string value, System.Drawing.Point position, System.Drawing.Size size, WindowStyles style)
            : this(parent, -1, value, position, size, style, "ComboCtrl")
        {
        }
        public ComboCtrl(Window parent, string value)
            : this(parent, -1, value, wxDefaultPosition, wxDefaultSize, WindowStyles.NO_STYLE, "ComboCtrl")
        {
        }

        /** <summary>2-step construction: Step two after calling default CTor.
         * Define the properties of this window.</summary>*/
        public void Create(Window parent, int id, string value, System.Drawing.Point position, System.Drawing.Size size, WindowStyles style, string name)
        {
            using (wxString wxValue=wxString.SafeNew(value))
            using (wxString wxName = wxString.SafeNew(name))
            {
                this.Create(parent, id, wxValue, position, size, style, wxName);
            }
        }

        /** <summary>2-step construction: Step two after calling default CTor.
         * Define the properties of this window.
         * </summary>
         */
        public void Create(Window parent, int id, wxString value, System.Drawing.Point position, System.Drawing.Size size, WindowStyles style, wxString name)
        {
            wxComboCtrl_Create(this.wxObject, Object.SafePtr(parent), id, Object.SafePtr(value), position.X, position.Y, size.Width, size.Height, (int)style, Object.SafePtr(name));
        }
        #endregion

        #region Public Virtuals
        /** <summary>Override for totally custom combo action.
         * </summary>
         */
        public virtual void OnButtonClick()
        {
            wxComboCtrl_OnButtonClick(this.wxObject);
        }
        #endregion

        #region Public Properties
        /** <summary>This is <c>true</c> iff the popup is shown.
         * Read only.</summary>*/
        public bool IsPopupShown
        {
            get
            {
                return wxComboCtrl_IsPopupShown(this.wxObject);
            }
        }

        /** <summary>Get or set the popup control.</summary>*/
        public ComboPopup PopupControl
        {
            get
            {
                return Object.FindObject(wxComboCtrl_GetPopupControl(this.wxObject)) as ComboPopup;
            }
            set
            {
                wxComboCtrl_SetPopupControl(this.wxObject, Object.SafePtr(value));
            }
        }

        /** <summary>Reads the window displaying the popup control.</summary>*/
        public Window PopupWindow
        {
            get
            {
                return Object.FindObject(wxComboCtrl_GetPopupWindow(this.wxObject)) as Window;
            }
        }

        /** <summary>Reads the text control that is used to display the combo box value.</summary>*/
        public TextCtrl TextControl
        {
            get
            {
                return Object.FindObject(wxComboCtrl_GetTextCtrl(this.wxObject)) as TextCtrl;
            }
        }

        /** <summary>Reads the button that opend the popup control.
         * Please note, that this is not necessarily a Button or a BitmapButton.
         * </summary>
         */
        public Window Button
        {
            get
            {
                return Object.FindObject(wxComboCtrl_GetButton(this.wxObject)) as Window;
            }
        }

        public override bool Enabled
        {
            set
            {
                wxComboCtrl_Enable(wxObject, value);
            }
            get
            {
                return this.IsEnabled();
            }
        }

        public override Font Font
        {
	        get 
	        { 
		        return base.Font;
	        }
	        set 
	        { 
		        wxComboCtrl_SetFont(this.wxObject, Object.SafePtr(value));
            }
        }
        #endregion

        #region Public Methods
        /** <summary>Shows the popup.
         * </summary>
         */
        public virtual void ShowPopup()
        {
            wxComboCtrl_ShowPopup(this.wxObject);
        }

        /** <summary>Hides the popup.
         * </summary>*/
        public virtual void HidePopup()
        {
            wxComboCtrl_HidePopup(this.wxObject);
        }
        #endregion

        #region TextCtrl Methods
        public string Value
        {
            get
            {
                wxString sb=wxString.SafeNew(wxComboCtrl_GetValue(this.wxObject));
                return sb.ToString();
            }
            set
            {
                wxString wxValue=wxString.SafeNew(value);
                wxComboCtrl_SetValue(this.wxObject, Object.SafePtr(wxValue));
            }
        }

        /** <summary>Calls wx.TextCtrl.Copy() of the associaed text control.
         * </summary>
         */
        public virtual void Copy()
        {
            wxComboCtrl_Copy(this.wxObject);
        }

        /** <summary>Calls wx.TextCtrl.Cut() of the associaed text control.
         * </summary>
         */
        public virtual void Cut()
        {
            wxComboCtrl_Cut(this.wxObject);
        }

        /** <summary>Calls wx.TextCtrl.Cut() of the associaed text control.
         * </summary>
         */
        public virtual void Paste()
        {
            wxComboCtrl_Paste(this.wxObject);
        }

        public virtual void SetInsertionPoint(int pos)
        {
            wxComboCtrl_SetInsertionPoint(this.wxObject, pos);
        }

        public virtual void SetInsertionPointEnd()
        {
            wxComboCtrl_SetInsertionPointEnd(this.wxObject);
        }

        public virtual int GetInsertionPoint()
        {
            return wxComboCtrl_GetInsertionPoint(this.wxObject);
        }

        public virtual long GetLastPosition()
        {
            return wxComboCtrl_GetLastPosition(this.wxObject);
        }

        public virtual void Replace(int from, int to, string value)
        {
            wxString wxValue = wxString.SafeNew(value);
            this.Replace(from, to, wxValue);
        }
        public virtual void Replace(int from, int to, wxString value)
        {
            wxComboCtrl_Replace(this.wxObject, from, to, Object.SafePtr(value));
        }

        public virtual void Remove(int from, int to)
        {
            wxComboCtrl_Remove(this.wxObject, from, to);
        }

        public virtual void SetSelection(int from, int to)
        {
            wxComboCtrl_SetSelection(this.wxObject, from, to);
        }

        public virtual void Undo()
        {
            wxComboCtrl_Undo(this.wxObject);
        }
        #endregion
    }
}

