//-----------------------------------------------------------------------------
// wx.NET - DirectAcyclGraph.cs
//
// Wrapper for wxArchiveInputStream and wxArchiveOutputStream.
//
// Written by Harald Meyer auf'm Hofe
// (C) 2010 by Harald Meyer auf'm Hofe
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: GraphViewModel.cs,v 1.2 2010/06/06 08:55:35 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Drawing;

/** Classes to represent and display graphs.
 */
namespace wx.Graph.View
{
    /// <summary>
    /// Implementors of this interface provide the data that will be used to display graph nodes.
    /// </summary>
    public interface INodeAppearance
    {
        /// <summary>
        /// Call this if something changed. The graph views will update
        /// the display of this node.
        /// </summary>
        event ComponentModel.PropertyChangedHandler OnChange;

        /// <summary>
        /// The size of the node. 
        /// Layout algorithms will reserve free space of this size.
        /// </summary>
        /// <param name="dc">The device context that shall display the node. Use this context to determine
        /// text sizes.</param>
        /// <param name="images">The list of images that is available to display nodes. This can be <c>null</c> if not available.</param>
        /// <returns></returns>
        Size GetSize(DC dc, ImageList images);

        /// <summary>
        /// This will be called to draw the node.
        /// </summary>
        /// <param name="dc">The device context that shall display the node</param>
        /// <param name="pos">The upper left position of the free space that has been reserved by the layout algorithm.</param>
        /// <param name="images">The list of images that is available to display nodes. This can be <c>null</c> if not available.</param>
        void Draw(DC dc, ImageList images, Point pos);

        /// <summary>
        /// If drawn by Draw() at the provided position, this returns a collection of positions that can be used
        /// as start or end of drawn edges.
        /// </summary>
        /// <param name="pos"></param>
        /// <returns></returns>
        ICollection<Point> GetDockingPoints(Point pos);
    }

    /// <summary>
    /// Use In
    /// </summary>
    public class LabelledNode : INodeAppearance
    {
        #region State
        string _label = "";
        int _imageIndex=-1;
        Direction _direction = Direction.wxBOTTOM;
        int _padding=1;
        bool _drawBorderBox=true;
        Colour _bgColour = null;
        Colour _fgColour = Colour.wxBLACK;
        #endregion

        #region CTor
        /// <summary>
        /// Creates a new instance that will display the provided text label.
        /// </summary>
        /// <param name="label">The text label that shall be displayed</param>
        public LabelledNode(string label, int padding)
        {
            this._label=label;
        }

        /// <summary>
        /// Creates a new instance that will display a text label and an image from an image list.
        /// </summary>
        /// <param name="label">The text label. If this is empty, the node will be </param>
        /// <param name="imageIndex">The index of the image that shall be displayed.</param>
        /// <param name="direction">The direction defines, whether the label shall be displayd above, below, on the left, or on the right side of the image.</param>
        public LabelledNode(string label, int imageIndex, Direction direction)
        {
            this._label=label;
            this._imageIndex = imageIndex;
            this._direction = direction;
            this._drawBorderBox = false;
        }
        #endregion

        public event ComponentModel.PropertyChangedHandler OnChange;

        #region Properties
        /// <summary>
        /// Get or set the label.
        /// </summary>
        public string Label
        {
            get { return this._label; }
            set
            {
                string oldValue = this._label;
                this._label = value;
                if (this.OnChange != null)
                    this.OnChange(this, new ComponentModel.PropertyChangedEvent("Label", this._label, oldValue));
            }
        }

        /// <summary>
        /// Get or set the index of the image that shall be displayed. If this is -1, no image will be displayed.
        /// </summary>
        public int ImageIndex
        {
            get { return this._imageIndex; }
            set
            {
                int oldIndex = this._imageIndex;
                this._imageIndex = value;
                if (this.OnChange != null)
                    this.OnChange(this, new ComponentModel.PropertyChangedEvent("ImageIndex", this._imageIndex, oldIndex));
            }
        }

        /// <summary>
        /// Set or get a Boolean flag that is true iff the graph node shall be surrounded by a box.
        /// </summary>
        public bool DrawBorderBox
        {
            get { return this._drawBorderBox; }
            set
            {
                bool oldValue = this._drawBorderBox;
                this._drawBorderBox = value;
                if (this.OnChange != null)
                    this.OnChange(this, new wx.ComponentModel.PropertyChangedEvent("DrawBorderBox", this._drawBorderBox, oldValue));
            }
        }

        /// <summary>
        /// Defines a number of pixels that shall be left blank between image and label (if both are given) and between
        /// image and label and the surrounding box (if one shall be drawn),
        /// </summary>
        public int Padding
        {
            get { return this._padding; }
            set
            {
                int oldValue = this._padding;
                this._padding = value;
                if (this.OnChange != null)
                    this.OnChange(this, new wx.ComponentModel.PropertyChangedEvent("Padding", this._padding, oldValue));
            }
        }

        /// <summary>
        /// This direction defines the position of the text label relatively to the image.
        /// If this is Direction.wxUP, the text label will be directly above the image.
        /// If this is Direction.wxDOWN, the text label will be directly below the image.
        /// If the direction is Direction.wxLEFT or Direction.wxRIGHT, the text label will
        /// be on the left side of the image, or right side respectively. If the label is
        /// left and up, the label will be positioned relatively to the upper left corner of
        /// the image. The other directions are accordingly. In case of Direction.wxALL, 
        /// the text will be positioned in the center of the image.
        /// </summary>
        public Direction Direction
        {
            get { return this._direction; }
            set
            {
                Direction oldValue = this._direction;
                this._direction = value;
                if (this.OnChange != null)
                    this.OnChange(this, new wx.ComponentModel.PropertyChangedEvent("Direction", this._direction, oldValue));
            }
        }

        /// <summary>
        /// The foreground/text colour that will be used to draw the node label.
        /// If you assign a colour to this, please note: The assigned instance will get readonly.
        /// </summary>
        public Colour Foreground
        {
            get { return this._fgColour; }
            set
            {
                value.MakeReadOnly();
                Colour oldValue = this._fgColour;
                this._fgColour = value;
                if (this.OnChange != null)
                    this.OnChange(this, new wx.ComponentModel.PropertyChangedEvent("Foreground", this._fgColour, oldValue));
            }
        }

        /// <summary>
        /// The background colour that will be used to draw the node. this can be <c>null</c>.
        /// In that case, the background will be filly transparent.
        /// If you assign a colour to this, please note: The assigned instance will get readonly.
        /// </summary>
        public Colour Background
        {
            get { return this._bgColour; }
            set
            {
                if (value != null)
                    value.MakeReadOnly();
                Colour oldValue = this._fgColour;
                this._fgColour = value;
                if (this.OnChange != null)
                    this.OnChange(this, new wx.ComponentModel.PropertyChangedEvent("Background", this._fgColour, oldValue));
            }
        }
        #endregion

        #region INodeAppearance Member
        public Size GetSize(DC dc, ImageList images)
        {
            Size labelSize=new Size(0,0);
            if (this._label != null && this._label.Length > 0)
            {
                labelSize = dc.GetTextExtent(this._label);
            }
            Size imageSize = new Size(0, 0);
            if (this._imageIndex >= 0 && images != null && this._imageIndex < images.ImageCount)
            {
                Bitmap img = images[this._imageIndex];
                imageSize = img.Size;
            }
            Size result = labelSize;
            if (!imageSize.IsEmpty)
            {
                if (((this._direction&Direction.wxUP) == Direction.wxUP && ((this._direction&Direction.wxDOWN) != Direction.wxDOWN))
                    || ((this._direction & Direction.wxUP) != Direction.wxUP && ((this._direction & Direction.wxDOWN) == Direction.wxDOWN)))
                {
                    result.Height += this._padding + imageSize.Height;
                }
                else if (((this._direction & Direction.wxLEFT) == Direction.wxLEFT && ((this._direction & Direction.wxRIGHT) != Direction.wxRIGHT))
                    || ((this._direction & Direction.wxLEFT) != Direction.wxLEFT && ((this._direction & Direction.wxRIGHT) == Direction.wxRIGHT)))
                {
                    result.Width += this._padding + imageSize.Width;
                }
                else
                {
                    if (imageSize.Width > result.Width)
                        result.Width = imageSize.Width;
                    if (imageSize.Height > result.Height)
                        result.Height = imageSize.Height;
                }
            }
            if (this._drawBorderBox)
            {
                result.Height += 2 + 2*this._padding;
                result.Width += 2 + 2*this._padding;
            }
            return result;
        }

        public void Draw(DC dc, ImageList images, Point pos)
        {
            Size s = this.GetSize(dc, images);
            if (this._drawBorderBox)
            {
                dc.DrawRectangle(pos, s);
                pos.X += 1 + this._padding;
                pos.Y += 1 + this._padding;
            }
        }

        /// <summary>
        /// If drawn by Draw() at the provided position, this returns a collection of positions that can be used
        /// as start or end of drawn edges.
        /// </summary>
        /// <param name="pos"></param>
        /// <returns></returns>
        public ICollection<Point> GetDockingPoints(Point pos)
        {
            return null;
        }

        #endregion
    }

    /// <summary>
    /// Associates a node appearance with a position.
    /// Instances of this class implement the data of the nodes of the
    /// classes LayoutedDAG and LayoutedTree.
    /// </summary>
    public class LayoutedNode
    {
    }

    /// <summary>
    /// This class implements a tree layout.
    /// </summary>
    public class LayoutedTree : Tree<LayoutedNode>
    {
    }

    /// <summary>
    /// This class implements a layout for directed acyclic graphs.
    /// The layout is specialized on acyclic graphs but will also display
    /// graphs with cycles. However, there should not be too many cycles to
    /// make this algorithm work.
    /// </summary>
    public class LayoutedDAG : DirectedGraph<LayoutedNode>
    {
    }
}
