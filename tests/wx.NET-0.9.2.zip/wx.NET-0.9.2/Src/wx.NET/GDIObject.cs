//-----------------------------------------------------------------------------
// wx.NET - GDIObject.cs
//
// The wxGDIObject wrapper class.
//
// Written by Jason Perkins (jason@379.com)
// (C) 2003 by 379, Inc.
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: GDIObject.cs,v 1.12 2010/05/08 19:52:40 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Runtime.InteropServices;

namespace wx
{
	public class GDIObject : Object, ICanBeMadeReadonly
	{
		#region CTor
		[DllImport("wx-c")] static extern void wxGDIObj_dtor(IntPtr self);
        bool _isReadonly = false;
        #endregion

		//---------------------------------------------------------------------

		#region CTor/DTor
		public GDIObject(IntPtr wxObject) 
			: base(wxObject) {}

		protected override void CallDTor ()
		{
			wxGDIObj_dtor(this.wxObject);
		}

		#endregion

		//---------------------------------------------------------------------


        #region ICanBeMadeReadonly Member
        /// <summary>
        /// True iff this is readonly.
        /// </summary>
        public bool IsReadonly
        {
            get { return this._isReadonly; }
        }

        /// <summary>
        /// This will make this readonly.
        /// </summary>
        /// <returns>Returns <c>this</c>.</returns>
        public object MakeReadOnly()
        {
            this._isReadonly = true;
            return this;
        }

        #endregion
    }
}
