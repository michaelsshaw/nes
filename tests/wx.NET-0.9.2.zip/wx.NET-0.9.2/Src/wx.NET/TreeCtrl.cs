//-----------------------------------------------------------------------------
// wx.NET - TreeCtrl.cs
//
// The wxTreeCtrl wrapper class.
//
// Written by Jason Perkins (jason@379.com)
// (C) 2003 by 379, Inc.
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: TreeCtrl.cs,v 1.50 2010/05/08 19:54:35 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Collections;
using System.Collections.Generic;

namespace wx
{
	public enum TreeItemIcon
	{
		wxTreeItemIcon_Normal,
		wxTreeItemIcon_Selected,
		wxTreeItemIcon_Expanded,
		wxTreeItemIcon_SelectedExpanded,
		wxTreeItemIcon_Max
	}
	
	//-----------------------------------------------------------------------------

    /** <summary>Analogously to SystemObjectClientData this holds a reference to an object that represents the client data.
     * Use instance of this class to wrapp .NET data that shall be used as client data of a tree node in a wx.TreeCtrl.
     *</summary>
     */
	public class TreeItemData : ClientData
    {
        #region C API
        [DllImport("wx-c")] static extern IntPtr wxTreeItemData_ctor();
		[DllImport("wx-c")] static extern void   wxTreeItemData_RegisterDisposable(IntPtr self, Virtual_Dispose onDispose);
		[DllImport("wx-c")] static extern void   wxTreeItemData_dtor(IntPtr self);
		[DllImport("wx-c")] static extern IntPtr wxTreeItemData_GetId(IntPtr self);
		[DllImport("wx-c")] static extern void   wxTreeItemData_SetId(IntPtr self, IntPtr param);
        #endregion

        #region State
        object _data = null;
        #endregion

        #region CTor / DTor
        /// <summary>
        /// For internal use only: Creates a registered wrapper of the provided native tree node instance.
        /// </summary>
        /// <param name="wxObject">Pointer to the tree node isntance that shall be wrapped.</param>
        public TreeItemData(IntPtr wxObject)
			: base(wxObject) 
		{ 
			this.wxObject = wxObject;
		}
			
        /// <summary>
        /// For insternal use only.
        /// </summary>
        /// <param name="wxObject">Pointer to a native tree item data instance</param>
        /// <param name="memOwn">requires with <c>true</c> that the native tree node data instance shall be deleted on finaliation.</param>
		internal TreeItemData(IntPtr wxObject, bool memOwn)
			: base(wxObject)
		{ 
			this.memOwn = memOwn;
			this.wxObject = wxObject;
		}

        /// <summary>
        /// Creates an instance encapsulating the <c>null</c> reference.
        /// </summary>
        public TreeItemData()
            : this(null)
        {
        }

        /** Creates an instance encapsulating the provided index that shall annotate a tree node.
         * <param name="clientData">The index that shall be associated with a tree node.</param>
         */
        public TreeItemData(int clientData)
            : this((object) clientData)
        {
        }

        /** Creates an instance encapsulating the provided object as client data.
         * <param name="clientData">The data that shall be associated with a tree node.</param>
         */
		public TreeItemData(object clientData)
			: this(wxTreeItemData_ctor(), true) 
		{
			virtual_Dispose = new Virtual_Dispose(VirtualDispose);
			wxTreeItemData_RegisterDisposable(wxObject, virtual_Dispose);

            this._data = clientData;
		}
						
		public override void Dispose()
		{
			if (!disposed)
			{
				if (wxObject != IntPtr.Zero)
				{
					if (memOwn)
					{
                        lock (DllSync)
                        {
                            wxTreeItemData_dtor(wxObject);
                            memOwn = false;
                        }
					}
				}
				RemoveObject(wxObject);
				wxObject = IntPtr.Zero;
                --validInstancesCount;
                disposed = true;
			}
			
			base.Dispose();
			GC.SuppressFinalize(this);
		}
				
		~TreeItemData() 
		{
			Dispose();
        }
        #endregion 

        #region Public Properties
        public TreeItemId Id 
		{
			get { return new TreeItemId(wxTreeItemData_GetId(wxObject), true); }
			set { wxTreeItemData_SetId(wxObject, Object.SafePtr(value)); }
        }


        /** <summary>Returns or sets the data that has been attached to the node.</summary>*/
        public object Data
        {
            get { return this._data; }
            set { this._data = value; }
        }
        #endregion
    }
	
	//-----------------------------------------------------------------------------
	
	public class TreeItemAttr : Object
	{
		[DllImport("wx-c")] static extern IntPtr wxTreeItemAttr_ctor();
		[DllImport("wx-c")] static extern IntPtr wxTreeItemAttr_ctor2(IntPtr colText, IntPtr colBack, IntPtr font);
		[DllImport("wx-c")] static extern void   wxTreeItemAttr_dtor(IntPtr self);
		[DllImport("wx-c")] static extern void   wxTreeItemAttr_RegisterDisposable(IntPtr self, Virtual_Dispose onDispose);
		[DllImport("wx-c")] static extern void   wxTreeItemAttr_SetTextColour(IntPtr self, IntPtr colText);
		[DllImport("wx-c")] static extern void   wxTreeItemAttr_SetBackgroundColour(IntPtr self, IntPtr colBack);
		[DllImport("wx-c")] static extern void   wxTreeItemAttr_SetFont(IntPtr self, IntPtr font);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxTreeItemAttr_HasTextColour(IntPtr self);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxTreeItemAttr_HasBackgroundColour(IntPtr self);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxTreeItemAttr_HasFont(IntPtr self);
		[DllImport("wx-c")] static extern IntPtr wxTreeItemAttr_GetTextColour(IntPtr self);
		[DllImport("wx-c")] static extern IntPtr wxTreeItemAttr_GetBackgroundColour(IntPtr self);
		[DllImport("wx-c")] static extern IntPtr wxTreeItemAttr_GetFont(IntPtr self);
		
		//-----------------------------------------------------------------------------

		public TreeItemAttr(IntPtr wxObject)
			: base(wxObject) 
		{ 
			this.wxObject = wxObject;
		}
			
		internal TreeItemAttr(IntPtr wxObject, bool memOwn)
			: base(wxObject)
		{ 
			this.memOwn = memOwn;
			this.wxObject = wxObject;
		}

		public TreeItemAttr()
			: this(wxTreeItemAttr_ctor(), true) 
		{
			virtual_Dispose = new Virtual_Dispose(VirtualDispose);
			wxTreeItemAttr_RegisterDisposable(wxObject, virtual_Dispose);
		}
		
		public TreeItemAttr(Colour colText, Colour colBack, Font font)
			: this(wxTreeItemAttr_ctor2(Object.SafePtr(colText), Object.SafePtr(colBack), Object.SafePtr(font)), true) 
		{
			virtual_Dispose = new Virtual_Dispose(VirtualDispose);
			wxTreeItemAttr_RegisterDisposable(wxObject, virtual_Dispose);
		}
		
		//---------------------------------------------------------------------
				
		public override void Dispose()
		{
			if (!disposed)
			{
				if (wxObject != IntPtr.Zero)
				{
					if (memOwn)
					{
                        lock (DllSync)
                        {
                            wxTreeItemAttr_dtor(wxObject);
                            memOwn = false;
                        }
					}
				}
				RemoveObject(wxObject);
				wxObject = IntPtr.Zero;
                --validInstancesCount;
                disposed = true;
			}
			
			base.Dispose();
			GC.SuppressFinalize(this);
		}
		
		//---------------------------------------------------------------------
		
		~TreeItemAttr() 
		{
			Dispose();
		}
		
		//---------------------------------------------------------------------
		
		public Colour TextColour
		{
			get { return new Colour(wxTreeItemAttr_GetTextColour(wxObject), true); }
			set { wxTreeItemAttr_SetTextColour(wxObject, Object.SafePtr(value)); }
		}
		
		//---------------------------------------------------------------------
		
		public Colour BackgroundColour
		{
			get { return new Colour(wxTreeItemAttr_GetBackgroundColour(wxObject), true); }
			set { wxTreeItemAttr_SetBackgroundColour(wxObject, Object.SafePtr(value)); }
		}
		
		//---------------------------------------------------------------------
		
		public Font Font
		{
			get { return new Font(wxTreeItemAttr_GetFont(wxObject), true); }
			set { wxTreeItemAttr_SetFont(wxObject, Object.SafePtr(value)); }
		}
		
		//---------------------------------------------------------------------
		
		public bool HasTextColour
		{
			get { return wxTreeItemAttr_HasTextColour(wxObject); }
		}
		
		//---------------------------------------------------------------------
		
		public bool HasBackgroundColour
		{
			get { return wxTreeItemAttr_HasBackgroundColour(wxObject); }
		}
		
		//---------------------------------------------------------------------
		
		public bool HasFont
		{
			get { return wxTreeItemAttr_HasFont(wxObject); }
		}
	}
	
	//-----------------------------------------------------------------------------

	//[StructLayout(LayoutKind.Sequential)]
	public class TreeItemId : Object
	{
		[DllImport("wx-c")] static extern IntPtr wxTreeItemId_ctor();
		[DllImport("wx-c")] static extern IntPtr wxTreeItemId_ctor2(IntPtr pItem);
		[DllImport("wx-c")] static extern void   wxTreeItemId_dtor(IntPtr self);
		//[DllImport("wx-c")] static extern void   wxTreeItem_RegisterDisposable(IntPtr self, Virtual_Dispose onDispose);
		[DllImport("wx-c")] [return:MarshalAs(UnmanagedType.U1)]static extern bool   wxTreeItemId_Equal(IntPtr item1, IntPtr item2);
        [DllImport("wx-c")] [return: MarshalAs(UnmanagedType.U1)] static extern bool wxTreeItemId_IsOk(IntPtr self);
        [DllImport("wx-c")] static extern long   wxTreeItemId_AsLong(IntPtr self);
		
		//---------------------------------------------------------------------

		public TreeItemId(IntPtr wxObject)
			: base(wxObject)
		{
			this.wxObject = wxObject;
		}
			
		internal TreeItemId(IntPtr wxObject, bool memOwn)
			: base(wxObject)
		{
			this.memOwn = memOwn;
			this.wxObject = wxObject;
		}

		public TreeItemId()
			: this(wxTreeItemId_ctor(), true) 
		{
			//virtual_Dispose = new Virtual_Dispose(VirtualDispose);
			//wxTreeItem_RegisterDisposable(wxObject, virtual_Dispose);
		}
		
        /** <summary>Creates an instance encapsulating the provided client data.
        * Please note, that this will take ownership of the C++ instance wrapped by <c>pItem</c>.
        * So, do not provide instances for <c>pItem</c> that have already been used.
        * This will raise an exception in that case.</summary>*/
		public TreeItemId(ClientData pItem)
			: this(wxTreeItemId_ctor2(Object.SafePtr(pItem)), true) 
		{
            if (pItem != null)
            {
                if (!pItem.memOwn)
                    throw new Exception("Cannot create instance with already used client data.");
                pItem.memOwn = false;
            }
			//virtual_Dispose = new Virtual_Dispose(VirtualDispose);
			//wxTreeItem_RegisterDisposable(wxObject, virtual_Dispose);
		}
		
		//---------------------------------------------------------------------

		public override void Dispose()
		{
			if (!disposed)
			{
				if (wxObject != IntPtr.Zero)
				{
					if (memOwn)
					{
                        lock (DllSync)
                        {
                            wxTreeItemId_dtor(wxObject);
                            memOwn = false;
                        }
					}
				}
				RemoveObject(wxObject);
				wxObject = IntPtr.Zero;
                --validInstancesCount;
                disposed = true;
			}
			
			virtual_Dispose = null;
			base.Dispose();
			GC.SuppressFinalize(this);
		}
		
		//---------------------------------------------------------------------
		
		~TreeItemId() 
		{
			Dispose();
		}
		
		//---------------------------------------------------------------------
		
		public static bool operator == (TreeItemId id1, TreeItemId id2)
		{
            if (((object)id1) == null && ((object)id2) == null)
                return true;
            if (((object)id1) == null || ((object)id2) == null)
                return false;
            return id1.Equals(id2);
        }

		//-----------------------------------------------------------------------------

		public override bool Equals(object o)
		{
            if (o is TreeItemId)
                return wxTreeItemId_Equal(Object.SafePtr(this), Object.SafePtr((TreeItemId)o));
            else
                return false;
		}
        //-----------------------------------------------------------------------------

        public override string ToString()
        {
            if (this.wxObject==IntPtr.Zero)
                return "TreeItemId()";
            long internalID = wxTreeItemId_AsLong(this.wxObject);
            return string.Format("TreeItemId({0})", internalID);
        }
		
		//-----------------------------------------------------------------------------

		public override int GetHashCode()
		{
			return wxObject.GetHashCode();
		}
		
		//-----------------------------------------------------------------------------

		public static bool operator != (TreeItemId i1, TreeItemId i2)
		{
			return !(i1 == i2);
		}
		
		//-----------------------------------------------------------------------------

		/*public bool IsValid
		{
			get { return id != IntPtr.Zero; }
		}*/
		
		//-----------------------------------------------------------------------------
		
		public bool IsOk()
		{
			return wxTreeItemId_IsOk(wxObject);
		}
	}
	
	//-----------------------------------------------------------------------------

    /** <summary>This is the wrapper of the tree control <c>wxTreeCtrl</c>.
     * </summary>
     * <remarks>
     * \image html treectrlsmall.png
     * 
     * The tree control displays its items in a tree like structure. Each item has its own (optional) icon and
     * a label. An item may be either collapsed (meaning that its children are not visible) or expanded
     * (meaning that its children are shown). Each item in the tree is identified by its itemId which is of 
     * opaque data type wxTreeItemId. You can test whether an item is valid by calling wx.TreeItemId.IsOk.
     *
     * The items text and image may be retrieved and changed with GetItemText/SetItemText and GetItemImage/SetItemImage.
     * In fact, an item may even have two images associated with it: the normal one and another one for selected state
     * which is set/retrieved with SetItemSelectedImage/GetItemSelectedImage functions, but this functionality might be
     * unavailable on some platforms.
     *
     * Tree items have several attributes: an item may be selected or not, visible or not, bold or not. It may also be
     * expanded or collapsed. All these attributes may be retrieved with the corresponding functions: IsSelected, IsVisible,
     * IsBold and IsExpanded. Only one item at a time may be selected, selecting another one (with SelectItem) automatically
     * unselects the previously selected one.
     *
     * In addition to its icon and label, a user-specific data structure may be associated with all tree items.
     * If you wish to do it, you should derive a class from wxTreeItemData which is a very simple class having only one
     * function GetId() which returns the id of the item this data is associated with. This data will be freed by the
     * control itself when the associated item is deleted (all items are deleted when the control is destroyed), so you
     * shouldn't delete it yourself (if you do it, you should call SetItemData(NULL) to prevent the tree from deleting
     * the pointer second time). The associated data may be retrieved with GetItemData() function.
     *
     * Working with trees is relatively straightforward if all the items are added to the tree at the moment of its creation.
     * However, for large trees it may be very inefficient. To improve the performance you may want to delay adding the items
     * to the tree until the branch containing the items is expanded: so, in the beginning, only the root item is created
     * (with AddRoot). Other items are added when EVT_TREE_ITEM_EXPANDING event is received: then all items lying immediately
     * under the item being expanded should be added, but, of course, only when this event is received for the first time for
     * this item - otherwise, the items would be added twice if the user expands/collapses/re-expands the branch.
     * 
     * The tree control provides functions for enumerating its items. There are 3 groups of enumeration functions: for the
     * children of a given item, for the sibling of the given item and for the visible items (those which are currently shown
     * to the user: an item may be invisible either because its branch is collapsed or because it is scrolled out of view).
     * Child enumeration functions require the caller to give them a cookie parameter: it is a number which is opaque to the
     * caller but is used by the tree control itself to allow multiple enumerations to run simultaneously (this is explicitly
     * allowed). The only thing to remember is that the cookie passed to GetFirstChild and to GetNextChild should be the same
     * variable (and that nothing should be done with it by the user code).
     *
     * Among other features of the tree control are: item sorting with SortChildren which uses the user-defined comparison
     * function OnCompareItems (by default the comparison is the alphabetic comparison of tree labels), hit testing 
     * (determining to which portion of the control the given point belongs, useful for implementing drag-and-drop in the tree)
     * with HitTest and editing of the tree item labels in place (see EditLabel).
     * Finally, the tree control has a keyboard interface: the cursor navigation (arrow) keys may be used to change the current
     * selection. "HOME" and "END" are used to go to the first/last sibling of the current item. '+', '-' and '*' expand,
     * collapse and toggle the current branch. Note, however, that "DEL" and "INS" keys do nothing by default, but it is
     * common to associate them with deleting an item from a tree and inserting a new one into it.
     * 
     * Please note a serious problem with the tree control: The control does not like changes in its layout or selections
     * on processing events. In such cases, I sometimes encountered access violations. The reason is unknown.
     * Consider, that you want to react on leaving a text in a window in such a way, that a tree control changes the
     * selected node or the tree has to be rebuilt. You leave the text control moving the mouse, the desired actions
     * are conducted but suddenly the runtime environment reports a severe C++ exception.
     * Fortunately, such problems can apparently be avoided using pending events as described in \ref custom_events.
     * Use a custom command event type to conduct your actions after processing the mouse events.
     * </remarks>
     */
    public class TreeCtrl : Control
	{
        /** <summary>This is the default style for tree controls.
         * </summary>
         */
        public static readonly wx.WindowStyles wxTR_DEFAULT_STYLE = (wx.WindowStyles)wxTreeCtrl_GetDefaultStyle();

		//-----------------------------------------------------------------------------

        /** <summary>Flags representing possible classifications of wx.TreeCtrl.HitTest().</summary>*/
        [Flags]
        public enum HitTestFlags
        {
            /** <summary>This simply indicates nothing.
             * Useful to initialize. This is the 0.
             * </summary>
             */
            NONE            = 0,
		    ABOVE           = 0x0001,
		    BELOW           = 0x0002,
		    NOWHERE         = 0x0004,
		    ONITEMBUTTON    = 0x0008,
		    ONITEMICON      = 0x0010,
		    ONITEMINDENT    = 0x0020,
		    ONITEMLABEL     = 0x0040,
		    ONITEMRIGHT     = 0x0080,
		    ONITEMSTATEICON = 0x0100,
		    TOLEFT          = 0x0200,
		    TORIGHT         = 0x0400,
		    ONITEMUPPERPART = 0x0800,
		    ONITEMLOWERPART = 0x1000,

		    ONITEM = ONITEMICON | ONITEMLABEL,
        }
		
		//-----------------------------------------------------------------------------
		
		private delegate int Virtual_OnCompareItems(IntPtr item1, IntPtr item2);
		private Virtual_OnCompareItems virtual_OnCompareItems;
		
		//-----------------------------------------------------------------------------

		[DllImport("wx-c")] static extern uint   wxTreeCtrl_GetDefaultStyle();
		[DllImport("wx-c")] static extern IntPtr wxTreeCtrl_ctor();
		[DllImport("wx-c")] static extern void   wxTreeCtrl_RegisterVirtual(IntPtr self, Virtual_OnCompareItems onCompareItems);
		[DllImport("wx-c")] static extern int    wxTreeCtrl_OnCompareItems(IntPtr self, IntPtr item1, IntPtr item2);
		[DllImport("wx-c")] static extern IntPtr wxTreeCtrl_AddRoot(IntPtr self, IntPtr text, int image, int selImage, IntPtr data);
		[DllImport("wx-c")] static extern IntPtr wxTreeCtrl_AppendItem(IntPtr self, IntPtr parent, IntPtr text, int image, int selImage, IntPtr data);
		[DllImport("wx-c")] static extern void   wxTreeCtrl_AssignImageList(IntPtr self, IntPtr imageList);
		[DllImport("wx-c")] static extern void   wxTreeCtrl_AssignStateImageList(IntPtr self, IntPtr imageList);
		//[DllImport("wx-c")] static extern void   wxTreeCtrl_AssignButtonsImageList(IntPtr self, IntPtr imageList);
		[DllImport("wx-c")] static extern bool   wxTreeCtrl_Create(IntPtr self, IntPtr parent, int id, ref Point pos, ref Size size, uint style, IntPtr val, IntPtr name);
		[DllImport("wx-c")] static extern IntPtr wxTreeCtrl_GetImageList(IntPtr self);
		[DllImport("wx-c")] static extern IntPtr wxTreeCtrl_GetStateImageList(IntPtr self);
		//[DllImport("wx-c")] static extern IntPtr wxTreeCtrl_GetButtonsImageList(IntPtr self);
		[DllImport("wx-c")] static extern void   wxTreeCtrl_SetImageList(IntPtr self, IntPtr imageList);
		[DllImport("wx-c")] static extern void   wxTreeCtrl_SetStateImageList(IntPtr self, IntPtr imageList);
		//[DllImport("wx-c")] static extern void   wxTreeCtrl_SetButtonsImageList(IntPtr self, IntPtr imageList);
		[DllImport("wx-c")] static extern void   wxTreeCtrl_SetItemImage(IntPtr self, IntPtr item, int image, TreeItemIcon which);
		[DllImport("wx-c")] static extern int    wxTreeCtrl_GetItemImage(IntPtr self, IntPtr item, TreeItemIcon which);

		[DllImport("wx-c")] static extern void   wxTreeCtrl_DeleteAllItems(IntPtr self);
		[DllImport("wx-c")] static extern void   wxTreeCtrl_Delete(IntPtr self, IntPtr item);
		[DllImport("wx-c")] static extern void   wxTreeCtrl_DeleteChildren(IntPtr self, IntPtr item);

		[DllImport("wx-c")] static extern void   wxTreeCtrl_Unselect(IntPtr self);
		[DllImport("wx-c")] static extern void   wxTreeCtrl_UnselectAll(IntPtr self);

		[DllImport("wx-c")] static extern bool   wxTreeCtrl_IsSelected(IntPtr self, IntPtr item);
		[DllImport("wx-c")] static extern IntPtr wxTreeCtrl_GetSelection(IntPtr self);
		[DllImport("wx-c")] static extern void   wxTreeCtrl_SelectItem(IntPtr self, IntPtr item);

		[DllImport("wx-c")] static extern IntPtr wxTreeCtrl_GetItemText(IntPtr self, IntPtr item);
		[DllImport("wx-c")] static extern void   wxTreeCtrl_SetItemText(IntPtr self, IntPtr item, IntPtr text);

		[DllImport("wx-c")] static extern IntPtr wxTreeCtrl_HitTest(IntPtr self, ref Point pt, ref int flags);

		[DllImport("wx-c")] static extern void   wxTreeCtrl_SetItemData(IntPtr self, IntPtr item, IntPtr data);
		[DllImport("wx-c")] static extern IntPtr wxTreeCtrl_GetItemData(IntPtr self, IntPtr item);

		[DllImport("wx-c")] static extern IntPtr wxTreeCtrl_GetRootItem(IntPtr self);
		[DllImport("wx-c")] static extern IntPtr wxTreeCtrl_GetItemParent(IntPtr self, IntPtr item);

		[DllImport("wx-c")] static extern IntPtr wxTreeCtrl_GetFirstChild(IntPtr self, IntPtr item);
		[DllImport("wx-c")] static extern IntPtr wxTreeCtrl_GetNextChild(IntPtr self, IntPtr item);
		[DllImport("wx-c")] static extern IntPtr wxTreeCtrl_GetLastChild(IntPtr self, IntPtr item);

		[DllImport("wx-c")] static extern IntPtr wxTreeCtrl_GetNextSibling(IntPtr self, IntPtr item);
		[DllImport("wx-c")] static extern IntPtr wxTreeCtrl_GetPrevSibling(IntPtr self, IntPtr item);

		[DllImport("wx-c")] static extern IntPtr wxTreeCtrl_GetFirstVisibleItem(IntPtr self);
		[DllImport("wx-c")] static extern IntPtr wxTreeCtrl_GetNextVisible(IntPtr self, IntPtr item);
		[DllImport("wx-c")] static extern IntPtr wxTreeCtrl_GetPrevVisible(IntPtr self, IntPtr item);

		[DllImport("wx-c")] static extern void   wxTreeCtrl_Expand(IntPtr self, IntPtr item);

		[DllImport("wx-c")] static extern void   wxTreeCtrl_Collapse(IntPtr self, IntPtr item);
		[DllImport("wx-c")] static extern void   wxTreeCtrl_CollapseAndReset(IntPtr self, IntPtr item);

		[DllImport("wx-c")] static extern void   wxTreeCtrl_Toggle(IntPtr self, IntPtr item);

		[DllImport("wx-c")] static extern void   wxTreeCtrl_EnsureVisible(IntPtr self, IntPtr item);
		[DllImport("wx-c")] static extern void   wxTreeCtrl_ScrollTo(IntPtr self, IntPtr item);

		[DllImport("wx-c")] static extern int    wxTreeCtrl_GetChildrenCount(IntPtr self, IntPtr item, bool recursively);
		[DllImport("wx-c")] static extern int    wxTreeCtrl_GetCount(IntPtr self);

		[DllImport("wx-c")] static extern bool   wxTreeCtrl_IsVisible(IntPtr self, IntPtr item);

		[DllImport("wx-c")] static extern bool   wxTreeCtrl_ItemHasChildren(IntPtr self, IntPtr item);

		[DllImport("wx-c")] static extern bool   wxTreeCtrl_IsExpanded(IntPtr self, IntPtr item);
		
		[DllImport("wx-c")] static extern uint   wxTreeCtrl_GetIndent(IntPtr self);
		[DllImport("wx-c")] static extern void   wxTreeCtrl_SetIndent(IntPtr self, uint indent);
		
		[DllImport("wx-c")] static extern uint   wxTreeCtrl_GetSpacing(IntPtr self);
		[DllImport("wx-c")] static extern void   wxTreeCtrl_SetSpacing(IntPtr self, uint indent);
		
		[DllImport("wx-c")] static extern IntPtr wxTreeCtrl_GetItemTextColour(IntPtr self, IntPtr item);
		[DllImport("wx-c")] static extern IntPtr wxTreeCtrl_GetItemBackgroundColour(IntPtr self, IntPtr item);
		[DllImport("wx-c")] static extern IntPtr wxTreeCtrl_GetItemFont(IntPtr self, IntPtr item);
		
		[DllImport("wx-c")] static extern void   wxTreeCtrl_SetItemHasChildren(IntPtr self, IntPtr item, bool has);
		[DllImport("wx-c")] static extern void   wxTreeCtrl_SetItemBold(IntPtr self, IntPtr item, bool bold);
		[DllImport("wx-c")] static extern void   wxTreeCtrl_SetItemTextColour(IntPtr self, IntPtr item, IntPtr col);
		[DllImport("wx-c")] static extern void   wxTreeCtrl_SetItemBackgroundColour(IntPtr self, IntPtr item, IntPtr col);
		
		[DllImport("wx-c")] static extern void   wxTreeCtrl_EditLabel(IntPtr self, IntPtr item);
		
		[DllImport("wx-c")] static extern bool   wxTreeCtrl_GetBoundingRect(IntPtr self, IntPtr item, ref Rectangle rect, bool textOnly);
		
		[DllImport("wx-c")] static extern IntPtr wxTreeCtrl_InsertItem(IntPtr self, IntPtr parent, IntPtr idPrevious, IntPtr text, int image, int selectedImage, IntPtr data);
        [DllImport("wx-c")] static extern IntPtr wxTreeCtrl_InsertItem2(IntPtr self, IntPtr parent, int before, IntPtr text, int image, int selectedImage, IntPtr data);
		
		[DllImport("wx-c")] static extern bool   wxTreeCtrl_IsBold(IntPtr self, IntPtr item);
		
		[DllImport("wx-c")] static extern IntPtr wxTreeCtrl_PrependItem(IntPtr self, IntPtr parent, IntPtr text, int image, int selectedImage, IntPtr data);
		
		[DllImport("wx-c")] static extern void   wxTreeCtrl_SetItemSelectedImage(IntPtr self, IntPtr item, int selImage);
		
		[DllImport("wx-c")] static extern void   wxTreeCtrl_ToggleItemSelection(IntPtr self, IntPtr item);
		
		[DllImport("wx-c")] static extern void   wxTreeCtrl_UnselectItem(IntPtr self, IntPtr item);
		
		[DllImport("wx-c")] static extern IntPtr wxTreeCtrl_GetMyCookie(IntPtr self);
		[DllImport("wx-c")] static extern void   wxTreeCtrl_SetMyCookie(IntPtr self, IntPtr newval);
		
		[DllImport("wx-c")] static extern IntPtr wxTreeCtrl_GetSelections(IntPtr self);
		
		[DllImport("wx-c")] static extern void   wxTreeCtrl_SetItemFont(IntPtr self, IntPtr item, IntPtr font);
		[DllImport("wx-c")] static extern void   wxTreeCtrl_SortChildren(IntPtr self, IntPtr item);

		//---------------------------------------------------------------------

		public TreeCtrl(IntPtr wxObject)
			: base(wxObject) { }
			
		public TreeCtrl()
			: this(wxTreeCtrl_ctor()) 
		{ 
			virtual_OnCompareItems = new Virtual_OnCompareItems(DoOnCompareItems);
			wxTreeCtrl_RegisterVirtual(wxObject, virtual_OnCompareItems);
		}

		public TreeCtrl(Window parent, int id)
			: this(parent, id, wxDefaultPosition, wxDefaultSize, wx.WindowStyles.TR_HAS_BUTTONS, null) { }
			
		public TreeCtrl(Window parent, int id, Point pos)
			: this(parent, id, pos, wxDefaultSize, wx.WindowStyles.TR_HAS_BUTTONS, null) { }
			
		public TreeCtrl(Window parent, int id, Point pos, Size size)
			: this(parent, id, pos, size, wx.WindowStyles.TR_HAS_BUTTONS, null) { }
			
		public TreeCtrl(Window parent, int id, Point pos, Size size, wx.WindowStyles style)
			: this(parent, id, pos, size, style, null) { }
	
		public TreeCtrl(Window parent, int id, Point pos, Size size, wx.WindowStyles style, string name)
			: this()
		{
			if (!Create(parent, id, pos, size, style, name)) 
			{
				throw new InvalidOperationException("Could not create TreeCtrl");
			}
		}
		
		//---------------------------------------------------------------------
		// ctors with self created id
		
		public TreeCtrl(Window parent)
			: this(parent, Window.UniqueID, wxDefaultPosition, wxDefaultSize, wx.WindowStyles.TR_HAS_BUTTONS, null) { }
			
		public TreeCtrl(Window parent, Point pos)
			: this(parent, Window.UniqueID, pos, wxDefaultSize, wx.WindowStyles.TR_HAS_BUTTONS, null) { }
			
		public TreeCtrl(Window parent, Point pos, Size size)
			: this(parent, Window.UniqueID, pos, size, wx.WindowStyles.TR_HAS_BUTTONS, null) { }
			
		public TreeCtrl(Window parent, Point pos, Size size, wx.WindowStyles style)
			: this(parent, Window.UniqueID, pos, size, style, null) { }
			
		public TreeCtrl(Window parent, Point pos, Size size, wx.WindowStyles style, string name)
			: this(parent, Window.UniqueID, pos, size, style, name) {}
		
		//---------------------------------------------------------------------

		public bool Create(Window parent, int id, Point pos, Size size, wx.WindowStyles style, string name)
		{
            wxString wxName = new wxString(name);
			return wxTreeCtrl_Create(wxObject, Object.SafePtr(parent), id, ref pos, ref size, (uint)style, IntPtr.Zero, wxName.wxObject);
		}

		//---------------------------------------------------------------------
		
        private int DoOnCompareItems(IntPtr item1, IntPtr item2)
        {
           // both arguments are owned by the C-API. So, generate wrapper that do NOT own their
           // wxObjects
           return OnCompareItems(new TreeItemId(item1, false), new TreeItemId(item2, false));
        }
		
		public virtual int OnCompareItems(TreeItemId item1, TreeItemId item2)
		{
			return wxTreeCtrl_OnCompareItems(wxObject, Object.SafePtr(item1), Object.SafePtr(item2));
		}
		
		//---------------------------------------------------------------------

        /** <summary>
         * Adds the root node to the tree, returning the new item.
         * </summary>
         * <param name="text">The name of the root node</param>
         */
        public TreeItemId AddRoot(string text)
		{ 
			return AddRoot(text, -1, -1, null); 
		}

        /** <summary>
         * Adds the root node to the tree, returning the new item.
         * </summary>
         * <param name="text">The name of the root node</param>
         * <param name="image">The index of the image that shall be presented with the node.</param>
         */
        public TreeItemId AddRoot(string text, int image)
		{ 
			return AddRoot(text, image, -1, null); 
		}

        /** <summary>
         * Adds the root node to the tree, returning the new item.
         *
         * The <c>image</c> and <c>selImage</c> parameters are an index within the normal image list specifying the image to
         * use for unselected and selected items, respectively. If <c>image > -1</c> and <c>selImage is -1</c>, the same image is
         * used for both selected and unselected items.
         * </summary>
         * <param name="text">The name of the root node</param>
         * <param name="image">The index of the image that shall be presented with the node.</param>
         * <param name="selImage">The index of the image that shall be presented with the node if the node is selected.</param>
         */
        public TreeItemId AddRoot(string text, int image, int selImage)
		{ 
			return AddRoot(text, image, selImage, null); 
		}

        /** <summary>
         * Adds the root node to the tree, returning the new item.
         *
         * The <c>image</c> and <c>selImage</c> parameters are an index within the normal image list specifying the image to
         * use for unselected and selected items, respectively. If <c>image > -1</c> and <c>selImage is -1</c>, the same image is
         * used for both selected and unselected items.
         * 
         * This method reflects the  wxWidgets 2.6 requirement that <c>data</c> must not be <c>null</c> on hidden roots.
         * Do not provide already used instances for <c>data</c>. This method will raise exceptions in that cases.
         * </summary>
         * <param name="text">The name of the root node</param>
         * <param name="image">The index of the image that shall be presented with the node.</param>
         * <param name="selImage">The index of the image that shall be presented with the node if the node is selected.</param>
         */
        public TreeItemId AddRoot(string text, int image, int selImage, TreeItemData data)
		{
            if (data != null)
            {
                if (!data.memOwn)
                    throw new Exception("Cannot add root on already used instances of client data.");
                data.memOwn = false;
            }
            wxString wxText = wxString.SafeNew(text);
            if (data == null)
                data = new TreeItemData(null);
			return new TreeItemId(wxTreeCtrl_AddRoot(wxObject, Object.SafePtr(wxText), image, selImage, Object.SafePtr(data)), true);
		}

		//---------------------------------------------------------------------

        /// <summary>
        /// Appends an item to the end of the branch identified by parent, return a new item id.
        /// 
        /// Please note, that an appended item may not be visible because the parent is not expanded.
        /// </summary>
        /// <param name="parentId">The parent node that will get a new child.</param>
        /// <param name="text">The label text of the new node.</param>
        /// <returns>The identifier of the new node.</returns>
        public TreeItemId AppendItem(TreeItemId parentId, string text)
		{ 
			return AppendItem(parentId, text, -1, -1, null); 
		}

        /// <summary>
        /// Appends an item to the end of the branch identified by parent, return a new item id.
        /// 
        /// The specified image will be used to display the node if selected or unselected.
        /// 
        /// Please note, that an appended item may not be visible because the parent is not expanded.
        /// </summary>
        /// <param name="parentId">The parent node that will get a new child.</param>
        /// <param name="text">The label text of the new node.</param>
        /// <param name="image">An index in the image list of the control representing the icon of the node or -1.</param>
        /// <returns>The identifier of the new node.</returns>
        public TreeItemId AppendItem(TreeItemId parentId, string text, int image)
		{ 
			return AppendItem(parentId, text, image, -1, null); 
		}

        /// <summary>
        /// Appends an item to the end of the branch identified by parent, return a new item id.
        ///
        /// The <c>image</c> and <c>selImage</c> parameters are an index within the normal image list specifying the image to use for
        /// unselected and selected items, respectively. If image > -1 and selImage is -1, the same image is used for both
        /// selected and unselected items.
        /// 
        /// Please note, that an appended item may not be visible because the parent is not expanded.
        /// </summary>
        /// <param name="parentId">The parent node that will get a new child.</param>
        /// <param name="text">The label text of the new node.</param>
        /// <param name="image">An index in the image list of the control representing the icon of the node or -1.</param>
        /// <param name="selImage">An index in the image list of the control representing the icon of the node if selected or -1.
        /// </param>
        /// <returns>The identifier of the new node.</returns>
        public TreeItemId AppendItem(TreeItemId parentId, string text, int image, int selImage)
		{ 
			return AppendItem(parentId, text, image, selImage, null); 
		}
		
        /// <summary>
        /// Appends an item to the end of the branch identified by parent, return a new item id.
        ///
        /// The <c>image</c> and <c>selImage</c> parameters are an index within the normal image list specifying the image to use for
        /// unselected and selected items, respectively. If image > -1 and selImage is -1, the same image is used for both
        /// selected and unselected items.
        /// 
        /// Please note, that an appended item may not be visible because the parent is not expanded.
        /// </summary>
        /// <param name="parentId">The parent node that will get a new child.</param>
        /// <param name="text">The label text of the new node.</param>
        /// <param name="image">An index in the image list of the control representing the icon of the node or -1.</param>
        /// <param name="selImage">An index in the image list of the control representing the icon of the node if selected or -1.
        /// </param>
        /// <param name="data">Additional data that is associated with the node or <c>null</c>.</param>
        /// <returns>The identifier of the new node.</returns>
		public TreeItemId AppendItem(TreeItemId parentId, string text, int image, int selImage, TreeItemData data)
		{
            if (data != null)
            {
                if (!data.memOwn)
                    throw new Exception("Cannot add root on already used instances of client data.");
                data.memOwn = false;
            }

            wxString wxText = new wxString(text);
			return new TreeItemId(wxTreeCtrl_AppendItem(this.wxObject, Object.SafePtr(parentId), wxText.wxObject, image, selImage, Object.SafePtr(data)), true);
		}

		//---------------------------------------------------------------------

        /// <summary>
        /// Assigns an image list to the control containing the icons of the nodes.
        /// </summary>
        /// <param name="imageList">The image list containing the icons.</param>
		public void AssignImageList(ImageList imageList)
		{
			wxTreeCtrl_AssignImageList(wxObject, Object.SafePtr(imageList));
		}
		
		//---------------------------------------------------------------------

		public void AssignStateImageList(ImageList imageList)
		{
			wxTreeCtrl_AssignStateImageList(wxObject, Object.SafePtr(imageList));
		}
		
		//---------------------------------------------------------------------

		/*public void AssignButtonsImageList(ImageList imageList)
		{
			wxTreeCtrl_AssignButtonsImageList(wxObject, Object.SafePtr(imageList));
		}*/

		//---------------------------------------------------------------------

		public ImageList ImageList
		{
			get { return (ImageList)FindObject(wxTreeCtrl_GetImageList(wxObject), typeof(ImageList)); }
			
			set { wxTreeCtrl_SetImageList(wxObject, Object.SafePtr(value)); }
		}

		//---------------------------------------------------------------------

		public void SetImageList(ImageList imageList)
		{
			wxTreeCtrl_SetImageList(wxObject, Object.SafePtr(imageList));
		}
		
		//---------------------------------------------------------------------
		
		public ImageList StateImageList
		{
			get { return (ImageList)FindObject(wxTreeCtrl_GetStateImageList(wxObject), typeof(ImageList)); }
			
			set { wxTreeCtrl_SetStateImageList(wxObject, Object.SafePtr(value)); }
		}
		
		//---------------------------------------------------------------------
		
		/*public ImageList ButtonsImageList
		{
			get { return (ImageList)FindObject(wxTreeCtrl_GetButtonsImageList(wxObject), typeof(ImageList)); }
			
			set { wxTreeCtrl_SetButtonsImageList(wxObject, Object.SafePtr(value)); }
		}*/

		//---------------------------------------------------------------------
		
		public void SetItemImage(TreeItemId item, int image)
		{
			SetItemImage(item, image, TreeItemIcon.wxTreeItemIcon_Normal);
		}

		public void SetItemImage(TreeItemId item, int image, TreeItemIcon which)
		{
			wxTreeCtrl_SetItemImage(wxObject, Object.SafePtr(item), image, which);
		}

		//---------------------------------------------------------------------
		
		public int GetItemImage(TreeItemId item)
		{
			return GetItemImage(item, TreeItemIcon.wxTreeItemIcon_Normal);
		}

		public int GetItemImage(TreeItemId item, TreeItemIcon which)
		{
			return wxTreeCtrl_GetItemImage(wxObject, Object.SafePtr(item), which);
		}

		//---------------------------------------------------------------------

        /// <summary>
        /// Deletes all items in the control.
        /// Note that this may not generate EVT_TREE_DELETE_ITEM events under some Windows versions although
        /// normally such event is generated for each removed item.
        /// </summary>
		public void DeleteAllItems()
		{
            lock (wx.Object.DllSync)
            {
                wxTreeCtrl_DeleteAllItems(wxObject);
            }
		}

		public void Delete(TreeItemId item)
		{
            if (this.Selection == item && item != this.RootItem)
                this.Selection = this.GetItemParent(item);
            lock (wx.Object.DllSync)
            {
                wxTreeCtrl_Delete(wxObject, Object.SafePtr(item));
            }
		}

		public void DeleteChildren(TreeItemId item)
		{
            lock (wx.Object.DllSync)
            {
                wxTreeCtrl_DeleteChildren(wxObject, Object.SafePtr(item));
            }
		}

		//---------------------------------------------------------------------

		public void Unselect()
		{
			wxTreeCtrl_Unselect(wxObject);
		}

		public void UnselectAll()
		{
			wxTreeCtrl_UnselectAll(wxObject);
		}

		//---------------------------------------------------------------------

        /// <summary>
        /// True if the argument is a selected item.
        /// </summary>
        /// <param name="item">The item of interest.</param>
        /// <returns>True iff the provided item is selected.</returns>
		public bool IsSelected(TreeItemId item)
		{
			return wxTreeCtrl_IsSelected(wxObject, Object.SafePtr(item));
		}

        /// <summary>
        /// SWets the selected item.
        /// </summary>
        /// <param name="item">The item that will be selected.</param>
		public void SelectItem(TreeItemId item)
		{
			wxTreeCtrl_SelectItem(wxObject, Object.SafePtr(item));
		}

        /** <summary>Get or set the selection.
         * The result will not be OK if nothing is selected.
         * </summary>
         */
		public TreeItemId Selection
		{
            get { return new TreeItemId(wxTreeCtrl_GetSelection(wxObject), true); }
			set { SelectItem(value); }
		}

		//---------------------------------------------------------------------

        /// <summary>
        /// Set the text associated with the tree item.
        /// </summary>
        /// <param name="item">designator of the tree item.</param>
        /// <param name="text">Text that will be associated with the tree item.</param>
		public void SetItemText(TreeItemId item, string text)
		{
            wxString wxText = new wxString(text);
			wxTreeCtrl_SetItemText(this.wxObject, Object.SafePtr(item), wxText.wxObject);
		}

        /// <summary>
        /// Returns the text that has been associated with this tree item.
        /// </summary>
        /// <param name="item">Designator of the tree item.</param>
		public string GetItemText(TreeItemId item)
		{
			return new wxString(wxTreeCtrl_GetItemText(wxObject, Object.SafePtr(item)), true);
		}

		//---------------------------------------------------------------------

        /** <summary>Sets the client data for the provided item.
         * This will raise an exception if <c>data</c> is already in use with other tree items.
         * </summary>
         * <param name="item">Designates the tree item that will be associated with data.</param>
         * <param name="data">Is the data that will be associated with the designated tree item.</param>
         */
		public void SetItemData(TreeItemId item, TreeItemData data)
		{
            if (data != null)
            {
                if (!data.memOwn)
                    throw new Exception("Cannot add root on already used instances of client data.");
                data.memOwn = false;
            }
            wxTreeCtrl_SetItemData(wxObject, Object.SafePtr(item), Object.SafePtr(data));
		}

        /// <summary>
        /// Returns the item data that has been stored for the designated tree item.
        /// </summary>
        /// <param name="item">Designates  the tree node whose data is requested.</param>
        /// <returns>The tree item data instance of <c>null</c>.</returns>
		public TreeItemData GetItemData(TreeItemId item)
		{
			return (TreeItemData)Object.FindObject(wxTreeCtrl_GetItemData(wxObject, Object.SafePtr(item)));
		}

		//---------------------------------------------------------------------
        
		public TreeItemId HitTest(Point pt, out HitTestFlags flags)
		{
			int native_flags = new int();
			TreeItemId result=new TreeItemId(wxTreeCtrl_HitTest(wxObject, ref pt, ref native_flags), true);
            flags=(HitTestFlags)native_flags;
            return result;
		}

        /// <summary>
        /// Method to detect matching labels in FindLabels().
        /// </summary>
        public enum LabelMatch
        {
            /// <summary>
            /// Exact match. Only equal labels match.
            /// </summary>
            Exact,
            /// <summary>
            /// All labels containing the request string match.
            /// </summary>
            Contains,
            /// <summary>
            /// All labels match that are equal to the request string ignoring the difference between upper and lower case letters.
            /// </summary>
            EqualsIgnoreCase,
            /// <summary>
            /// All labels containing the request string ignoring the case match.
            /// </summary>
            ContainsIgnoreCase,
        }

        /// <summary>
        /// Returns an array of tree item identifiers designating those tree items with labels matching the provided string. 
        /// </summary>
        /// <param name="requestString">The string that shall be searched in item labels.</param>
        /// <param name="labelMatch">The method for comparing labels and request string.</param>
        public ICollection<TreeItemId> FindLabels(string requestString, LabelMatch labelMatch)
        {
            List<TreeItemId> result = new List<TreeItemId>();
            foreach (TreeItemId nodeid in this.AllItems())
            {
                string itemlabel = this.GetItemText(nodeid);
                bool match=false;
                switch (labelMatch)
                {
                    case LabelMatch.Exact: match = itemlabel.Equals(requestString); break;
                    case LabelMatch.Contains: match = itemlabel.Contains(requestString); break;
                    case LabelMatch.EqualsIgnoreCase: match = itemlabel.ToLower().Equals(requestString.ToLower()); break;
                    case LabelMatch.ContainsIgnoreCase: match = itemlabel.ToLower().Contains(requestString.ToLower()); break;
                }
                if (match)
                    result.Add(nodeid);
            }
            return result.ToArray();
        }

        /// <summary>
        /// Finds the first tree item whose label matches the provided request string.
        /// </summary>
        /// <param name="requestString">The string that shall be searched in item labels.</param>
        /// <param name="labelMatch">The method for comparing labels and request string.</param>
        /// <returns>The id of a matching tree item or <c>null</c> if nothing matches.</returns>
        public TreeItemId FindFirstWithLabel(string requestString, LabelMatch labelMatch)
        {
            foreach (TreeItemId nodeid in this.AllItems())
            {
                string itemlabel = this.GetItemText(nodeid);
                bool match = false;
                switch (labelMatch)
                {
                    case LabelMatch.Exact: match = itemlabel.Equals(requestString); break;
                    case LabelMatch.Contains: match = itemlabel.Contains(requestString); break;
                    case LabelMatch.EqualsIgnoreCase: match = itemlabel.ToLower().Equals(requestString.ToLower()); break;
                    case LabelMatch.ContainsIgnoreCase: match = itemlabel.ToLower().Contains(requestString.ToLower()); break;
                }
                if (match)
                    return nodeid;
            }
            return null;
        }

		//---------------------------------------------------------------------

        /// <summary>
        /// The root node of the presented tree.
        /// </summary>
		public TreeItemId RootItem
		{
			get { return new TreeItemId(wxTreeCtrl_GetRootItem(wxObject), true); }
		}

        /// <summary>
        /// The parent of the designated tree node. The result may be invalid of the argument is the root.
        /// </summary>
        /// <param name="item">The tree node.</param>
        /// <returns></returns>
		public TreeItemId GetItemParent(TreeItemId item)
		{
			return new TreeItemId(wxTreeCtrl_GetItemParent(wxObject, Object.SafePtr(item)), true);
		}

		//---------------------------------------------------------------------

        /// <summary>
        /// Returns the first child of the designated tree node. Creates a cookie representing this enumeration.
        /// </summary>
        /// <param name="item">This method will collect children of this tree node.</param>
        /// <param name="cookie">This designates the enumeration. The cookie represents a state of enumeration.</param>
        /// <see cref="GetChildren"/>
        public TreeItemId GetFirstChild(TreeItemId item, ref IntPtr cookie)
		{
			TreeItemId id = new TreeItemId(wxTreeCtrl_GetFirstChild(wxObject, Object.SafePtr(item)), true);
			
			cookie = wxTreeCtrl_GetMyCookie(wxObject);
			
			return id;
		}

        /// <summary>
        /// Returns the next child of the designated tree node..
        /// </summary>
        /// <param name="item">This method will collect children of this tree node.</param>
        /// <param name="cookie">This designates the enumeration. The cookie represents a state of enumeration.</param>
        /// <see cref="GetChildren"/>
        public TreeItemId GetNextChild(TreeItemId item, ref IntPtr cookie)
		{
			wxTreeCtrl_SetMyCookie(wxObject, cookie);
			
			TreeItemId id = new TreeItemId(wxTreeCtrl_GetNextChild(wxObject, Object.SafePtr(item)), true);
			
			cookie =  wxTreeCtrl_GetMyCookie(wxObject);
			
			return id;
		}

        /// <summary>
        /// Returns the last child of the designated tree node.
        /// </summary>
        /// <param name="item">This method will collect children of this tree node.</param>
        /// <see cref="GetChildren"/>
        public TreeItemId GetLastChild(TreeItemId item)
		{
			return new TreeItemId(wxTreeCtrl_GetLastChild(wxObject, Object.SafePtr(item)), true);
		}

        /** <summary>An array comprising all direct children of the argument or <c>null</c> if argument designates a
         * leaf node.</summary>
         * <param name="item">This method will collect the children of this tree node.</param>
         */
        public TreeItemId[] GetChildren(TreeItemId item)
        {
            IntPtr cookie = IntPtr.Zero;
            int numOfChildren = this.GetChildrenCount(item, false);
            if (numOfChildren == 0)
                return new TreeItemId[0];
            TreeItemId[] result = new TreeItemId[numOfChildren];
            result[0] = this.GetFirstChild(item, ref cookie);
            for (int i = 1; i < numOfChildren; ++i)
                result[i] = this.GetNextChild(item, ref cookie);
            return result;
        }

        //---------------------------------------------------------------------

        /// <summary>
        /// Returns the next sibling of the specified item; call wx.TreeCtrl.GetPrevSibling() for the next sibling.
        ///
        /// Returns an invalid tree item if there are no further children.
        /// </summary>
        public TreeItemId GetNextSibling(TreeItemId item)
		{
			return new TreeItemId(wxTreeCtrl_GetNextSibling(wxObject, Object.SafePtr(item)), true);
		}

        /// <summary>
        /// Returns the previous sibling of the specified item; call wx.TreeCtrl.GetNextSibling() for the next sibling.
        ///
        /// Returns an invalid tree item if there are no further children.
        /// </summary>
        public TreeItemId GetPrevSibling(TreeItemId item)
		{
			return new TreeItemId(wxTreeCtrl_GetPrevSibling(wxObject, Object.SafePtr(item)), true);
		}

		//---------------------------------------------------------------------

        /// <summary>
        /// Returns the first visible item.
        /// </summary>
        /// <seealso cref="GetNextVisible"/>
        /// <seealso cref="GetPrevVisible"/>
        /// <seealso cref="GetVisibleItems"/>
        public TreeItemId GetFirstVisibleItem()
		{
			return new TreeItemId(wxTreeCtrl_GetFirstVisibleItem(wxObject), true);
		}

        /// <summary>
        /// Returns the next visible item following the argument.
        /// </summary>
        /// <param name="item">This will return the next item following this one.</param>
        /// <seealso cref="GetFirstVisible"/>
        /// <seealso cref="GetPrevVisible"/>
        /// <seealso cref="GetVisibleItems"/>
        public TreeItemId GetNextVisible(TreeItemId item)
		{
			return new TreeItemId(wxTreeCtrl_GetNextVisible(wxObject, Object.SafePtr(item)), true);
		}

        /// <summary>
        /// Returns the previsous visible item.
        /// </summary>
        /// <param name="item">This will return the next item following this one.</param>
        /// <seealso cref="GetFirstVisible"/>
        /// <seealso cref="GetNextVisible"/>
        /// <seealso cref="GetVisibleItems"/>
        public TreeItemId GetPrevVisible(TreeItemId item)
		{
			return new TreeItemId(wxTreeCtrl_GetPrevVisible(wxObject, Object.SafePtr(item)), true);
		}

        /** <summary>An array comprising all visible tree node items or <c>null</c> if nothing is visible.</summary>
         * <param name="item">This method will collect the children of this tree node.</param>
         */
        public TreeItemId[] GetVisibleItems()
        {
            System.Collections.Generic.List<TreeItemId> result = new System.Collections.Generic.List<TreeItemId>();
            TreeItemId current = this.GetFirstVisibleItem();
            while (current.IsOk())
            {
                result.Add(current);
                current = this.GetNextVisible(current);
            }
            if (result.Count > 0)
                return result.ToArray();
            else
                return null;
        }

        /// <summary>
        /// Returns the IDs of all nodes that have been added to the control beginning with the root node.
        /// The result will be <c>null</c> iff this is empty.
        /// </summary>
        public TreeItemId[] GetAllItems()
        {
            if (this.Count == 0)
                return null;
            System.Collections.Generic.List<TreeItemId> result = new System.Collections.Generic.List<TreeItemId>();
            System.Collections.Generic.Stack<TreeItemId> agenda = new System.Collections.Generic.Stack<TreeItemId>();
            agenda.Push(this.RootItem);
            while (agenda.Count > 0)
            {
                TreeItemId current = agenda.Pop();
                result.Add(current);
                if (this.GetChildrenCount(current) > 0)
                {
                    foreach (TreeItemId c in this.GetChildren(current))
                    {
                        agenda.Push(c);
                    }
                }
            }
            return result.ToArray();
        }

		//---------------------------------------------------------------------

        /// <summary>
        /// Expands the designated tree node.
        /// </summary>
        /// <param name="item">The node to be expanded.</param>
		public void Expand(TreeItemId item)
		{
			wxTreeCtrl_Expand(wxObject, Object.SafePtr(item));
		}

		//---------------------------------------------------------------------

        /// <summary>
        /// Collapses the designated tree node.
        /// </summary>
        /// <param name="item">The node to be collapsed.</param>
        public void Collapse(TreeItemId item)
		{
			wxTreeCtrl_Collapse(wxObject, Object.SafePtr(item));
		}

		public void CollapseAndReset(TreeItemId item)
		{
			wxTreeCtrl_CollapseAndReset(wxObject, Object.SafePtr(item));
		}

		//---------------------------------------------------------------------

		public void Toggle(TreeItemId item)
		{
			wxTreeCtrl_Toggle(wxObject, Object.SafePtr(item));
		}

		//---------------------------------------------------------------------

        /// <summary>
        /// Ensures by node expansion and scrolling that the designated item is visible.
        /// </summary>
        /// <param name="item">The item that shall be visible.</param>
		public void EnsureVisible(TreeItemId item)
		{
			wxTreeCtrl_EnsureVisible(wxObject, Object.SafePtr(item));
		}

		public void ScrollTo(TreeItemId item)
		{
			wxTreeCtrl_ScrollTo(wxObject, Object.SafePtr(item));
		}

		//---------------------------------------------------------------------

        /** <summary>Get number of direct and indirect (recursively found) children.
         * </summary>
         * <param name="item">Designator of the root node. This method will return 0 if this is not OK.</param>
         */
        public int GetChildrenCount(TreeItemId item)
		{
			return GetChildrenCount(item, true);
		}


        /** <summary>Get the number of direct (<c>recursively</c> is false) or also of children of children etc.
         * </summary>
         * <param name="item">Designator of the root node. This method will return 0 if this is not OK.</param>
         * <param name="recursively">This will also count children of children of <c>item</c> iff true.</param>
         */
        public int GetChildrenCount(TreeItemId item, bool recursively)
		{
            if (!item.IsOk())
                return 0;
			return wxTreeCtrl_GetChildrenCount(wxObject, Object.SafePtr(item), recursively);
		}

        /// <summary>
        /// The number of the contained nodes.
        /// </summary>
		public int Count
		{
			get { return wxTreeCtrl_GetCount(wxObject); }
		}

		//---------------------------------------------------------------------

		public bool IsVisible(TreeItemId item)
		{
			return wxTreeCtrl_IsVisible(wxObject, Object.SafePtr(item));
		}

		//---------------------------------------------------------------------

		public bool ItemHasChildren(TreeItemId item)
		{
			return wxTreeCtrl_ItemHasChildren(wxObject, Object.SafePtr(item));
		}

		//---------------------------------------------------------------------

		public bool IsExpanded(TreeItemId item)
		{
			return wxTreeCtrl_IsExpanded(wxObject, Object.SafePtr(item));
		}

		//---------------------------------------------------------------------

		public bool HasChildren(TreeItemId item)
		{
			return GetChildrenCount(item, false) > 0;
		}

		// A brute force way to get list of selections (if wxTR_MULTIPLE has been
		// enabled) by inspecting each item. May want to replace with Interop
		// invocation of GetSelections() if it is implemented more efficiently
		// (such as the TreeCtrl has a built-in list of currect selections).
		public TreeItemId[] SelectionsOld()
		{
			return Get_Items(GetItemsMode.Selections, this.RootItem, true);
		}
		
		// This is now interop...
		public TreeItemId[] Selections()
		{
			return new ArrayTreeItemIds(wxTreeCtrl_GetSelections(wxObject), true);
		}

		// This is an addition to the standard API. Limits the selection
		// search to parent_item and below.
		public TreeItemId[] SelectionsAtOrBelow(TreeItemId parent_item)
		{
			return Get_Items(GetItemsMode.Selections, parent_item, false);
		}

		// This is an addition to the standard API. Limits the selection
		// search to those items below parent_item.
		public TreeItemId[] SelectionsBelow(TreeItemId parent_item)
		{
			return Get_Items(GetItemsMode.Selections, parent_item, true);
		}

		// This is an addition to the standard API. Returns all items
		// except for the root node.
		public TreeItemId[] AllItems()
		{
			return Get_Items(GetItemsMode.All, this.RootItem, true);
		}

		// This is an addition to the standard API. Only returns items
		// that are at or below parent_item (i.e. returns parent_item).
		public TreeItemId[] AllItemsAtOrBelow(TreeItemId parent_item)
		{
			return Get_Items(GetItemsMode.All, parent_item, false);
		}

		// This is an addition to the standard API. Only returns items
		// that are below parent_item.
		public TreeItemId[] AllItemsBelow(TreeItemId parent_item)
		{
			return Get_Items(GetItemsMode.All, parent_item, true);
		}

		private enum GetItemsMode
		{
			Selections,
			All,
		}

		private TreeItemId[] Get_Items(GetItemsMode mode, TreeItemId parent_item, 
			bool skip_parent)
		{
			// Console.WriteLine("---");
			ArrayList list = new ArrayList();
			Add_Items(mode, parent_item, list, IntPtr.Zero, skip_parent);
			TreeItemId[] array = new TreeItemId[list.Count];
			list.CopyTo(array);
			return array;
		}

		private void Add_Items(GetItemsMode mode, TreeItemId parent, 
			ArrayList list, IntPtr cookie, bool skip_parent)
		{
			TreeItemId id;

			if ( cookie == IntPtr.Zero)
			{
				if ( (! skip_parent) && 
					((mode == GetItemsMode.All) || (this.IsSelected(parent))))
				{
					// Console.WriteLine(this.GetItemText(parent));
					list.Add(parent);
				}
				id = GetFirstChild(parent, ref cookie);
			}
			else
			{
				id = GetNextChild(parent, ref cookie);
			}

			if ( ! id.IsOk() )
				return;

			if ((mode == GetItemsMode.All) || (this.IsSelected(id)))
			{
				// Console.WriteLine(this.GetItemText(id));
				list.Add(id);
			}

			if (ItemHasChildren(id))
			{
				Add_Items(mode, id, list, IntPtr.Zero, false);
			}

			Add_Items(mode, parent, list, cookie, false);
		}
		
		//---------------------------------------------------------------------
		
		public uint Indent
		{
			get { return wxTreeCtrl_GetIndent(wxObject); }
			set { wxTreeCtrl_SetIndent(wxObject, value); }
		}
		
		//---------------------------------------------------------------------
		
		public uint Spacing
		{
			get { return wxTreeCtrl_GetSpacing(wxObject); }
			set { wxTreeCtrl_SetSpacing(wxObject, value); }
		}
		
		//---------------------------------------------------------------------
		
		public Colour GetItemTextColour(TreeItemId item)
		{
			return new Colour(wxTreeCtrl_GetItemTextColour(wxObject, Object.SafePtr(item)), true);
		}
		
		//---------------------------------------------------------------------
		
		public Colour GetItemBackgroundColour(TreeItemId item)
		{
			return new Colour(wxTreeCtrl_GetItemBackgroundColour(wxObject, Object.SafePtr(item)), true);
		}
		
		//---------------------------------------------------------------------
		
		public Font GetItemFont(TreeItemId item)
		{
			return new Font(wxTreeCtrl_GetItemFont(wxObject, Object.SafePtr(item)), true);
		}
		
		public void SetItemFont(TreeItemId item, Font font)
		{
			wxTreeCtrl_SetItemFont(wxObject, Object.SafePtr(item), Object.SafePtr(font));
		}

		//---------------------------------------------------------------------
		
		public void SetItemHasChildren(TreeItemId item)
		{
			SetItemHasChildren(item, true);
		}
		
		public void SetItemHasChildren(TreeItemId item, bool has)
		{
			wxTreeCtrl_SetItemHasChildren(wxObject, Object.SafePtr(item), has);
		}
		
		//---------------------------------------------------------------------
		
		public void SetItemBold(TreeItemId item)
		{
			SetItemBold(item, true);
		}
		
		public void SetItemBold(TreeItemId item, bool bold)
		{
			wxTreeCtrl_SetItemBold(wxObject, Object.SafePtr(item), bold);
		}
		
		//---------------------------------------------------------------------
		
		public void SetItemTextColour(TreeItemId item, Colour col)
		{
			wxTreeCtrl_SetItemTextColour(wxObject, Object.SafePtr(item), Object.SafePtr(col));
		}
		
		//---------------------------------------------------------------------
		
		public void SetItemBackgroundColour(TreeItemId item, Colour col)
		{
			wxTreeCtrl_SetItemBackgroundColour(wxObject, Object.SafePtr(item), Object.SafePtr(col));
		}
		
		//---------------------------------------------------------------------
		
		public void EditLabel(TreeItemId item)
		{
			wxTreeCtrl_EditLabel(wxObject, Object.SafePtr(item));
		}
		
		//---------------------------------------------------------------------
		
		public bool GetBoundingRect(TreeItemId item, ref Rectangle rect)
		{
			return GetBoundingRect(item, ref rect, false);
		}
		
		public bool GetBoundingRect(TreeItemId item, ref Rectangle rect, bool textOnly)
		{
			return wxTreeCtrl_GetBoundingRect(wxObject, Object.SafePtr(item), ref rect, textOnly);
		}
		
		//---------------------------------------------------------------------
		
		public TreeItemId InsertItem(TreeItemId parent, TreeItemId previous, string text)
		{
			return InsertItem(parent, previous, text, -1, -1, null);
		}
		
		public TreeItemId InsertItem(TreeItemId parent, TreeItemId previous, string text, int image)
		{
			return InsertItem(parent, previous, text, image, -1, null);
		}
		
		public TreeItemId InsertItem(TreeItemId parent, TreeItemId previous, string text, int image, int sellimage)
		{
			return InsertItem(parent, previous, text, image, sellimage, null);
		}
		
        /** <summary>Inserts a new item into the tree.
        * Please note, that the tree control will take ownership of the C++ instance wrapped by <c>data</c>.
        * So, do not use an instance for <c>data</c> that has already been used.</summary>*/
		public TreeItemId InsertItem(TreeItemId parent, TreeItemId previous, string text, int image, int sellimage, TreeItemData data)
		{
            if (data != null)
            {
                if (!data.memOwn)
                    throw new Exception("Cannot insert item with already used tree data instance.");
                data.memOwn = false;
            }
            wxString wxText = new wxString(text);
			return new TreeItemId(wxTreeCtrl_InsertItem(this.wxObject, Object.SafePtr(parent), Object.SafePtr(previous), wxText.wxObject, image, sellimage, Object.SafePtr(data)), true);
		}
		
		//---------------------------------------------------------------------
		
		public TreeItemId InsertItem(TreeItemId parent, int before, string text)
		{
			return InsertItem(parent, before, text, -1, -1, null);
		}
		
		public TreeItemId InsertItem(TreeItemId parent, int before, string text, int image)
		{
			return InsertItem(parent, before, text, image, -1, null);
		}
		
		public TreeItemId InsertItem(TreeItemId parent, int before, string text, int image, int sellimage)
		{
			return InsertItem(parent, before, text, image, sellimage, null);
		}
		
		public TreeItemId InsertItem(TreeItemId parent, int before, string text, int image, int sellimage, TreeItemData data)
		{
            if (data != null)
            {
                if (!data.memOwn)
                    throw new Exception("Cannot insert item with already used tree data instance.");
                data.memOwn = false;
            }
            wxString wxText = new wxString(text);
			return new TreeItemId(wxTreeCtrl_InsertItem2(this.wxObject, Object.SafePtr(parent), before, wxText.wxObject, image, sellimage, Object.SafePtr(data)), true);
		}
		
		//---------------------------------------------------------------------
		
		public bool IsBold(TreeItemId item)
		{
			return wxTreeCtrl_IsBold(wxObject, Object.SafePtr(item));
		}
		
		//---------------------------------------------------------------------
		
		public TreeItemId PrependItem(TreeItemId parent, string text)
		{
			return PrependItem(parent, text, -1, -1, null);
		}
		
		public TreeItemId PrependItem(TreeItemId parent, string text, int image)
		{
			return PrependItem(parent, text, image, -1, null);
		}
		
		public TreeItemId PrependItem(TreeItemId parent, string text, int image, int sellimage)
		{
			return PrependItem(parent, text, image, sellimage, null);
		}
		
		public TreeItemId PrependItem(TreeItemId parent, string text, int image, int sellimage, TreeItemData data)
		{
            wxString wxText = new wxString(text);
			return new TreeItemId(wxTreeCtrl_PrependItem(this.wxObject, Object.SafePtr(parent), wxText.wxObject, image, sellimage, Object.SafePtr(data)), true);
		}
		
		//---------------------------------------------------------------------
		
		public void SetItemSelectedImage(TreeItemId item, int selImage)
		{
			wxTreeCtrl_SetItemSelectedImage(wxObject, Object.SafePtr(item), selImage);
		}
		
		//---------------------------------------------------------------------
		
		public void ToggleItemSelection(TreeItemId item)
		{
			wxTreeCtrl_ToggleItemSelection(wxObject, Object.SafePtr(item));
		}
		
		//---------------------------------------------------------------------
		
		public void UnselectItem(TreeItemId item)
		{
			wxTreeCtrl_UnselectItem(wxObject, Object.SafePtr(item));
		}
		
		//---------------------------------------------------------------------
		
		public void SortChildren(TreeItemId item)
		{
			wxTreeCtrl_SortChildren(wxObject, Object.SafePtr(item));
		}
		
		//---------------------------------------------------------------------

		public event EventListener BeginDrag
		{
			add { AddCommandListener(Event.wxEVT_COMMAND_TREE_BEGIN_DRAG, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

		public event EventListener BeginRightDrag
		{
			add { AddCommandListener(Event.wxEVT_COMMAND_TREE_BEGIN_RDRAG, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

		public event EventListener BeginLabelEdit
		{
			add { AddCommandListener(Event.wxEVT_COMMAND_TREE_BEGIN_LABEL_EDIT, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

		public event EventListener EndLabelEdit
		{
			add { AddCommandListener(Event.wxEVT_COMMAND_TREE_END_LABEL_EDIT, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

		public event EventListener DeleteItem
		{
			add { AddCommandListener(Event.wxEVT_COMMAND_TREE_DELETE_ITEM, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

		public event EventListener GetInfo
		{
			add { AddCommandListener(Event.wxEVT_COMMAND_TREE_GET_INFO, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

		public event EventListener SetInfo
		{
			add { AddCommandListener(Event.wxEVT_COMMAND_TREE_SET_INFO, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

		public event EventListener ItemExpand
		{
			add { AddCommandListener(Event.wxEVT_COMMAND_TREE_ITEM_EXPANDED, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

		public event EventListener ItemExpanding
		{
			add { AddCommandListener(Event.wxEVT_COMMAND_TREE_ITEM_EXPANDING, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

		public event EventListener ItemCollapse
		{
			add { AddCommandListener(Event.wxEVT_COMMAND_TREE_ITEM_COLLAPSED, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

		public event EventListener ItemCollapsing
		{
			add { AddCommandListener(Event.wxEVT_COMMAND_TREE_ITEM_COLLAPSING, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

		public event EventListener SelectionChange
		{
			add { AddCommandListener(Event.wxEVT_COMMAND_TREE_SEL_CHANGED, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

		public event EventListener SelectionChanging
		{
			add { AddCommandListener(Event.wxEVT_COMMAND_TREE_SEL_CHANGING, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

		public override event EventListener KeyDown
		{
			add { AddCommandListener(Event.wxEVT_COMMAND_TREE_KEY_DOWN, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

		public event EventListener ItemActivate
		{
			add { AddCommandListener(Event.wxEVT_COMMAND_TREE_ITEM_ACTIVATED, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

		public event EventListener ItemRightClick
		{
			add { AddCommandListener(Event.wxEVT_COMMAND_TREE_ITEM_RIGHT_CLICK, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

		public event EventListener ItemMiddleClick
		{
			add { AddCommandListener(Event.wxEVT_COMMAND_TREE_ITEM_MIDDLE_CLICK, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

		public event EventListener EndDrag
		{
			add { AddCommandListener(Event.wxEVT_COMMAND_TREE_END_DRAG, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}
	}
	
	//-----------------------------------------------------------------------------

	public class TreeEvent : Event
	{
		[DllImport("wx-c")] static extern IntPtr wxTreeEvent_ctor(int commandType, int id);
		[DllImport("wx-c")] static extern IntPtr wxTreeEvent_GetItem(IntPtr self);
		[DllImport("wx-c")] static extern void   wxTreeEvent_SetItem(IntPtr self, IntPtr item);
		[DllImport("wx-c")] static extern IntPtr wxTreeEvent_GetOldItem(IntPtr self);
		[DllImport("wx-c")] static extern void   wxTreeEvent_SetOldItem(IntPtr self, IntPtr item);
		[DllImport("wx-c")] static extern void   wxTreeEvent_GetPoint(IntPtr self, ref Point pt);
		[DllImport("wx-c")] static extern void   wxTreeEvent_SetPoint(IntPtr self, ref Point pt);
		[DllImport("wx-c")] static extern IntPtr wxTreeEvent_GetKeyEvent(IntPtr self);
		[DllImport("wx-c")] static extern int    wxTreeEvent_GetKeyCode(IntPtr self);
		[DllImport("wx-c")] static extern void   wxTreeEvent_SetKeyEvent(IntPtr self, IntPtr evt);
		[DllImport("wx-c")] static extern IntPtr wxTreeEvent_GetLabel(IntPtr self);
		[DllImport("wx-c")] static extern void   wxTreeEvent_SetLabel(IntPtr self, IntPtr label);
		[DllImport("wx-c")] static extern bool   wxTreeEvent_IsEditCancelled(IntPtr self);
		[DllImport("wx-c")] static extern void   wxTreeEvent_SetEditCanceled(IntPtr self, bool editCancelled);
		//[DllImport("wx-c")] static extern int    wxTreeEvent_GetCode(IntPtr self);
		[DllImport("wx-c")] static extern void   wxTreeEvent_Veto(IntPtr self);
		[DllImport("wx-c")] static extern void   wxTreeEvent_Allow(IntPtr self);
		[DllImport("wx-c")] static extern bool   wxTreeEvent_IsAllowed(IntPtr self);       
		
		[DllImport("wx-c")] static extern void   wxTreeEvent_SetToolTip(IntPtr self, IntPtr toolTip);

		//-----------------------------------------------------------------------------

		public TreeEvent(IntPtr wxObject)
			: base(wxObject) { }
		public TreeEvent(int commandType, int id)
			: base(wxTreeEvent_ctor(commandType, id)) { }

		//-----------------------------------------------------------------------------

		public TreeItemId Item
		{
			get { return new TreeItemId(wxTreeEvent_GetItem(wxObject), true); }
			set { wxTreeEvent_SetItem(wxObject, Object.SafePtr(value)); }
		}

		public TreeItemId OldItem
		{
			get { return new TreeItemId(wxTreeEvent_GetOldItem(wxObject), true); }
			set { wxTreeEvent_SetOldItem(wxObject, Object.SafePtr(value)); }
		}

		//-----------------------------------------------------------------------------

		public Point Point
		{
			get 
			{ 
				Point pt = new Point();
				wxTreeEvent_GetPoint(wxObject, ref pt);
				return pt;
			}
			set { wxTreeEvent_SetPoint(wxObject, ref value); }
		}

		//-----------------------------------------------------------------------------

		public KeyEvent KeyEvent
		{
			get { return (KeyEvent)FindObject(wxTreeEvent_GetKeyEvent(wxObject), typeof(KeyEvent)); }
			set { wxTreeEvent_SetKeyEvent(wxObject, Object.SafePtr(value)); }
		}

		//-----------------------------------------------------------------------------

		public int KeyCode
		{
			get { return wxTreeEvent_GetKeyCode(wxObject); }
		}

		//-----------------------------------------------------------------------------

		public string Label
		{
			get { return new wxString(wxTreeEvent_GetLabel(wxObject), true); }
			set
            {
                wxString wxValue = new wxString(value);
                wxTreeEvent_SetLabel(this.wxObject, wxValue.wxObject);
            }
		}

		//-----------------------------------------------------------------------------

		public bool IsEditCancelled
		{
			get { return wxTreeEvent_IsEditCancelled(wxObject); } 
			set { wxTreeEvent_SetEditCanceled(wxObject, value); }
		}
		
		public string ToolTip
		{
			set
            {
                wxString wxValue = new wxString(value);
                wxTreeEvent_SetToolTip(wxObject, wxValue.wxObject);
            }
		}
		
		//-----------------------------------------------------------------------------        
        
		public void Veto()
		{
			wxTreeEvent_Veto(wxObject);
		}
        
		//-----------------------------------------------------------------------------
        
		public void Allow()
		{
			wxTreeEvent_Allow(wxObject);
		}
        
		//-----------------------------------------------------------------------------
        
		public bool Allowed
		{
			get { return  wxTreeEvent_IsAllowed(wxObject); }
		}
	}
	
	//---------------------------------------------------------------------

	public class ArrayTreeItemIds : Object
	{
		[DllImport("wx-c")] static extern IntPtr wxArrayTreeItemIds_ctor();
		[DllImport("wx-c")] static extern void   wxArrayTreeItemIds_dtor(IntPtr self);
		[DllImport("wx-c")] static extern void   wxArrayTreeItemIds_RegisterDisposable(IntPtr self, Virtual_Dispose onDispose);
		[DllImport("wx-c")] static extern void   wxArrayTreeItemIds_Add(IntPtr self, IntPtr toadd);
		[DllImport("wx-c")] static extern IntPtr wxArrayTreeItemIds_Item(IntPtr self, int num);
		[DllImport("wx-c")] static extern int    wxArrayTreeItemIds_GetCount(IntPtr self);
		
		//---------------------------------------------------------------------

		public ArrayTreeItemIds(IntPtr wxObject)
			: base(wxObject)
		{
			this.wxObject = wxObject;
		}
			
		internal ArrayTreeItemIds(IntPtr wxObject, bool memOwn)
			: base(wxObject)
		{
			this.memOwn = memOwn;
			this.wxObject = wxObject;
		}

		public ArrayTreeItemIds()
			: this(wxArrayTreeItemIds_ctor(), true) 
		{
			virtual_Dispose = new Virtual_Dispose(VirtualDispose);
			wxArrayTreeItemIds_RegisterDisposable(wxObject, virtual_Dispose);
		}
		
		//---------------------------------------------------------------------

		public static implicit operator TreeItemId[] (ArrayTreeItemIds ars)
		{
			TreeItemId[] tmps = new TreeItemId[ars.Count];
			for (int i = 0; i < ars.Count; i++)
				tmps[i] = ars.Item(i);
			return tmps;
		}
	
		public TreeItemId Item(int num)
		{
			return new TreeItemId(wxArrayTreeItemIds_Item(wxObject, num), true);
		}	
	
		public void Add(TreeItemId toadd)
		{
			wxArrayTreeItemIds_Add(wxObject, Object.SafePtr(toadd));
		}

		public int Count
		{
			get { return wxArrayTreeItemIds_GetCount(wxObject); }
		}
        
		//---------------------------------------------------------------------

		public override void Dispose()
		{
			if (!disposed)
			{
				if (wxObject != IntPtr.Zero)
				{
					if (memOwn)
					{
                        lock (DllSync)
                        {
                            wxArrayTreeItemIds_dtor(wxObject);
                            memOwn = false;
                        }
					}
				}
				RemoveObject(wxObject);
				wxObject = IntPtr.Zero;
                --validInstancesCount;
                disposed = true;
			}
			
			base.Dispose();
			GC.SuppressFinalize(this);
		}
		
		//---------------------------------------------------------------------
		
		~ArrayTreeItemIds() 
		{
			Dispose();
		}
	}
}
