//-----------------------------------------------------------------------------
// wx.NET - Bitmap.cs
//
// The wxBitmap wrapper class.
//
// Written by Jason Perkins (jason@379.com)
// (C) 2003 by 379, Inc.
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: Bitmap.cs,v 1.34 2010/04/11 16:14:27 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Reflection;

namespace wx
{
	public enum BitmapType
	{
		wxBITMAP_TYPE_INVALID               = 0,
		wxBITMAP_TYPE_BMP,
		wxBITMAP_TYPE_BMP_RESOURCE,
		wxBITMAP_TYPE_RESOURCE              = wxBITMAP_TYPE_BMP_RESOURCE,
		wxBITMAP_TYPE_ICO,
		wxBITMAP_TYPE_ICO_RESOURCE,
		wxBITMAP_TYPE_CUR,
		wxBITMAP_TYPE_CUR_RESOURCE,
		wxBITMAP_TYPE_XBM,
		wxBITMAP_TYPE_XBM_DATA,
		wxBITMAP_TYPE_XPM,
		wxBITMAP_TYPE_XPM_DATA,
		wxBITMAP_TYPE_TIF,
		wxBITMAP_TYPE_TIF_RESOURCE,
		wxBITMAP_TYPE_GIF,
		wxBITMAP_TYPE_GIF_RESOURCE,
		wxBITMAP_TYPE_PNG,
		wxBITMAP_TYPE_PNG_RESOURCE,
		wxBITMAP_TYPE_JPEG,
		wxBITMAP_TYPE_JPEG_RESOURCE,
		wxBITMAP_TYPE_PNM,
		wxBITMAP_TYPE_PNM_RESOURCE,
		wxBITMAP_TYPE_PCX,
		wxBITMAP_TYPE_PCX_RESOURCE,
		wxBITMAP_TYPE_PICT,
		wxBITMAP_TYPE_PICT_RESOURCE,
		wxBITMAP_TYPE_ICON,
		wxBITMAP_TYPE_ICON_RESOURCE,
		wxBITMAP_TYPE_ANI,
		wxBITMAP_TYPE_IFF,
		wxBITMAP_TYPE_MACCURSOR,
		wxBITMAP_TYPE_MACCURSOR_RESOURCE,
		wxBITMAP_TYPE_ANY                   = 50
	}

    /// <summary>
    /// Represents a bitmap.
    /// </summary>
	public class Bitmap : GDIObject
	{
        #region C API
		[DllImport("wx-c")] static extern IntPtr wxBitmap_NullBitmap();
		[DllImport("wx-c")] static extern IntPtr wxBitmap_ctor();
		[DllImport("wx-c")] static extern IntPtr wxBitmap_ctorByImage(IntPtr image, int depth);
		[DllImport("wx-c")] static extern IntPtr wxBitmap_ctorByName(IntPtr name, BitmapType type);
		[DllImport("wx-c")] static extern IntPtr wxBitmap_ctorBySize(int width, int height, int depth);
		[DllImport("wx-c")] static extern IntPtr wxBitmap_ctorByBitmap(IntPtr bitmap);
		//[DllImport("wx-c")] static extern void   wxBitmap_RegisterDisposable(IntPtr self, Virtual_Dispose onDispose);
		
		[DllImport("wx-c")] static extern IntPtr wxBitmap_ConvertToImage(IntPtr self);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxBitmap_LoadFile(IntPtr self, IntPtr name, BitmapType type);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxBitmap_SaveFile(IntPtr self, IntPtr name, BitmapType type, IntPtr palette);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxBitmap_Ok(IntPtr self);
	
		[DllImport("wx-c")] static extern int    wxBitmap_GetHeight(IntPtr self);
		[DllImport("wx-c")] static extern void   wxBitmap_SetHeight(IntPtr self, int height);
	
		[DllImport("wx-c")] static extern int    wxBitmap_GetWidth(IntPtr self);
		[DllImport("wx-c")] static extern void   wxBitmap_SetWidth(IntPtr self, int width);
		
		[DllImport("wx-c")] static extern int    wxBitmap_GetDepth(IntPtr self);
		[DllImport("wx-c")] static extern void   wxBitmap_SetDepth(IntPtr self, int depth);
		
		[DllImport("wx-c")] static extern IntPtr wxBitmap_GetSubBitmap(IntPtr self, IntPtr rect);
		
		[DllImport("wx-c")] static extern IntPtr wxBitmap_GetMask(IntPtr self);
		[DllImport("wx-c")] static extern IntPtr wxBitmap_SetMask(IntPtr self, IntPtr mask);
		
		[DllImport("wx-c")] static extern IntPtr wxBitmap_GetPalette(IntPtr self);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxBitmap_CopyFromIcon(IntPtr self, IntPtr icon);
		
		[DllImport("wx-c")] static extern IntPtr wxBitmap_GetColourMap(IntPtr self);

        [DllImport("wx-c")]
        static extern IntPtr wxBitmap_ctorFromBits(IntPtr bits, int width, int height);
        #endregion

        #region CTor
		static Bitmap()
		{
			Image.InitAllHandlers();
		}

        static IntPtr LockedCTor()
        {
            lock (DllSync)
            {
                return wxBitmap_ctor();
            }
        }

		public Bitmap()
			: this(LockedCTor()) { }

		public Bitmap(Image image)
			: this(image, -1) { }

        static IntPtr LockedCTorByImage(Image image, int depth)
        {
            lock (DllSync)
            {
                return wxBitmap_ctorByImage(Object.SafePtr(image), depth);
            }
        }

		public Bitmap(Image image, int depth)
			: this(LockedCTorByImage(image, depth)) { }

        /** <summary>Be careful: Create an wx.Image first before creating a bitmap from a file.
         * In fact I don't know why, but this works better for <c>wxGTK</c>.
         * </summary>
         */
        public Bitmap(string name)
			: this(name, BitmapType.wxBITMAP_TYPE_ANY) { }

		public Bitmap(string name, BitmapType type)
			: this(new wxString(name), type) { }

        static IntPtr LockedCTorByName(wxString name, BitmapType type)
        {
            lock (DllSync)
            {
                return wxBitmap_ctorByName(Object.SafePtr(name), type);
            }
        }

        public Bitmap(wxString name, BitmapType type)
            : this(LockedCTorByName(name, type)) { }

        public Bitmap(int width, int height)
			: this(width, height, -1) { }

        static IntPtr LockedCTorBySize(int width, int height, int depth)
        {
            lock (DllSync)
            {
                return wxBitmap_ctorBySize(width, height, depth);
            }
        }

		public Bitmap(int width, int height, int depth)
			: this(LockedCTorBySize(width, height, depth)) {}

        static IntPtr LockedCTorByBitmap(Bitmap bitmap)
        {
            lock (DllSync)
            {
                return wxBitmap_ctorByBitmap(Object.SafePtr(bitmap));
            }
        }

		public Bitmap(Bitmap bitmap)
			: this(LockedCTorByBitmap(bitmap))
        {
        }

		/** <summary>Convenience CTor for reading the resource of the provided name from the provided assembly.</summary>
         */
		public Bitmap(string resourceName, Assembly resourceAssembly)
			: this(new Image(resourceName, resourceAssembly))
		{
		}

        static Image GetImageFromResource(string archiveName, string resourceName)
        {
            try
            {
                return new Image(archiveName, resourceName);
            }
            catch (Exception exc)
            {
                Log.LogError(exc.Message);
                Bitmap emptyImage = wx.ArtProvider.GetBitmap(ArtID.wxART_MISSING_IMAGE);
                return emptyImage.ConvertToImage();
            }
        }

        /** <summary>CTor for ZipResource support.</summary><remarks>
         * This will load a bitmap <c>resourceName</c> from ZipResource file or directory <c>archiveName</c>.
         * <code>
         * wx.ZipResource.AddCatalogLookupPrefix(@"..\Utils\MemLogDisplay");
         * wx.Bitmap bmp=new wx.Bitmap("archiveName.zrs", "iconname.png");
         * </code>
         * </remarks>*/
        public Bitmap(string archiveName, string resourceName)
            : this(GetImageFromResource(archiveName, resourceName))
        {
        }

		public Bitmap(IntPtr wxObject) 
			: base(wxObject) { }

        /** <summary>This will create a monochrome bitmaps with data from <c>bits</c>.</summary>
         * <remarks>
         * Sample:
         * <code>
         wx.Bitmap monochromeCross=new wx.Bitmap(new bool[]
           {false, false,  true,  true,  true,  true, false, false,
            false, false, false,  true,  true, false, false, false,
             true, false, false,  true,  true, false, false,  true,
             true,  true,  true,  true,  true,  true,  true,  true,
             true,  true,  true,  true,  true,  true,  true,  true,
             true, false, false,  true,  true, false, false,  true,
            false, false, false,  true,  true, false, false, false,
            false, false,  true,  true,  true,  true, false, false},
            8);
         </code>
         * </remarks>*/
        public static Bitmap FromBits(bool[] bits, int width)
        {
            int numBytes = bits.Length / 8;
            ByteBuffer bytes = new ByteBuffer(numBytes);
            for (int i = 0; i < bits.Length; i+=8)
            {
                int byteIndex=i/8;
                bytes[byteIndex] = (byte)(0
                    + ((bits[i])?128:0)
                    + ((bits[i + 1]) ? 64 : 0)
                    + ((bits[i + 2]) ? 32 : 0)
                    + ((bits[i + 3]) ? 16 : 0)
                    + ((bits[i + 4]) ? 8 : 0)
                    + ((bits[i + 5]) ? 4 : 0)
                    + ((bits[i + 6]) ? 2 : 0)
                    + ((bits[i + 7]) ? 1 : 0))
                    ;
            }
            return new Bitmap(wxBitmap_ctorFromBits(bytes.PtrToBuffer, width, numBytes*8 / width));
        }

        /** <summary>This will create a monochrome bitmaps with data from <c>bytes</c>.
         * </summary>*/
        public static Bitmap FromBits(byte[] byteArray, int width)
        {
            ByteBuffer byteBuffer=ByteBuffer.SafeNew(byteArray);
            if (byteArray==null)
                return null;

            return new Bitmap(wxBitmap_ctorFromBits(byteBuffer.PtrToBuffer, width, byteBuffer.SizeFilled * 8 / width));
        }
        #endregion	

		public Image ConvertToImage()
		{
			Image result = new Image(wxBitmap_ConvertToImage(wxObject));
			return result;
		}

		//---------------------------------------------------------------------

		public int Height
		{
			get { return wxBitmap_GetHeight(wxObject); }
			set
            {
                if (this.IsReadonly)
                    throw new CannotChangeReadonly();
                wxBitmap_SetHeight(wxObject, value);
            }
		}

		//---------------------------------------------------------------------

		public bool LoadFile(string name, BitmapType type)
		{
            if (this.IsReadonly)
                throw new CannotChangeReadonly();

            wxString wxName = new wxString(name);
			return wxBitmap_LoadFile(this.wxObject, wxName.wxObject, type);
		}
	
		//---------------------------------------------------------------------
	
		public bool SaveFile(string name, BitmapType type)
		{
			return SaveFile(name, type, null);
		}
	
		public bool SaveFile(string name, BitmapType type, Palette palette)
		{
            wxString wxName = new wxString(name);
            return wxBitmap_SaveFile(this.wxObject, wxName.wxObject, type, Object.SafePtr(palette));
		}

		//---------------------------------------------------------------------

		public int Width
		{
			get { return wxBitmap_GetWidth(wxObject); }
			set
            {
                if (this.IsReadonly)
                    throw new CannotChangeReadonly();
                wxBitmap_SetWidth(wxObject, value);
            }
		}

        /** <summary>Get or set the size of the bitmap.
         * Equivalent to sequential use of Width() and Height().
         * </summary>
         */
        public Size Size
        {
            get { return new Size(this.Width, this.Height); }
            set
            {
                if (this.IsReadonly)
                    throw new CannotChangeReadonly();
                this.Width = value.Width; this.Height = value.Height;
            }
        }

		//---------------------------------------------------------------------

		public virtual bool Ok()
		{
			return wxBitmap_Ok(wxObject);
		}

		//---------------------------------------------------------------------
	
		public int Depth
		{
			get { return wxBitmap_GetDepth(wxObject); }
			set
            {
                if (this.IsReadonly)
                    throw new CannotChangeReadonly();
                wxBitmap_SetDepth(wxObject, value);
            }
		}
	
		//---------------------------------------------------------------------
	
		public Bitmap GetSubBitmap(Rectangle rect)
		{
            wxRect wxrect = new wxRect(rect);
			return new Bitmap(wxBitmap_GetSubBitmap(this.wxObject, wxrect.wxObject));
		}
	
		//---------------------------------------------------------------------
	
		public Mask Mask
		{
			get { return new Mask(wxBitmap_GetMask(wxObject)); }
			set 
            {
                if (this.IsReadonly)
                    throw new CannotChangeReadonly();
                wxBitmap_SetMask(wxObject, Object.SafePtr(value));
            }
		}
	
		//---------------------------------------------------------------------
	
		public Palette Palette
		{
			get { return new Palette(wxBitmap_GetPalette(wxObject)); }
		}
	
		//---------------------------------------------------------------------
	
		public Palette ColourMap
		{
			get { return new Palette(wxBitmap_GetColourMap(wxObject)); }
		}
	
		//---------------------------------------------------------------------
		
		public bool CopyFromIcon(Icon icon)
		{
			return wxBitmap_CopyFromIcon(wxObject, Object.SafePtr(icon));
		}

        static Bitmap _nullBitmap=null;
        /** <summary>This is a static instance of an empty bitmap.
         * This instance may be of use as default argument to several methods,
         * e.g. wx.ToolBar. Don't copy or draw into this.
         * </summary>
         */
        public static Bitmap NullBitmap
        {
            get
            {
                if (_nullBitmap == null)
                {
                    _nullBitmap = new Bitmap(wxBitmap_NullBitmap());
                    _nullBitmap.memOwn = false;
                }
                return _nullBitmap;
            }
        }
	}
    
	//---------------------------------------------------------------------
    
	public class Mask : Object
	{
		[DllImport("wx-c")] static extern IntPtr wxMask_ctor();
		[DllImport("wx-c")] static extern IntPtr wxMask_ctorByBitmapColour(IntPtr bitmap, IntPtr colour);
		[DllImport("wx-c")] static extern IntPtr wxMask_ctorByBitmapIndex(IntPtr bitmap, int paletteIndex);
		[DllImport("wx-c")] static extern IntPtr wxMask_ctorByBitmap(IntPtr bitmap);

        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxMask_CreateByBitmapColour(IntPtr self, IntPtr bitmap, IntPtr colour);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxMask_CreateByBitmapIndex(IntPtr self, IntPtr bitmap, int paletteIndex);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxMask_CreateByBitmap(IntPtr self, IntPtr bitmap);
		
		//---------------------------------------------------------------------

        static IntPtr LockedCTor()
        {
            lock (DllSync)
            {
                return wxMask_ctor();
            }
        }

		public Mask()
			: this(LockedCTor()) {}

        static IntPtr LockedCTorBitmapColour(Bitmap bitmap, Colour colour)
        {
            lock (DllSync)
            {
                return wxMask_ctorByBitmapColour(Object.SafePtr(bitmap), Object.SafePtr(colour));
            }
        }

		public Mask(Bitmap bitmap, Colour colour)
			: this(LockedCTorBitmapColour(bitmap, colour)) {}

        static IntPtr LockedCTorByBitmapIndex(Bitmap bitmap, int paletteIndex)
        {
            lock (DllSync)
            {
                return wxMask_ctorByBitmapIndex(Object.SafePtr(bitmap), paletteIndex);
            }
        }

		public Mask(Bitmap bitmap, int paletteIndex)
			: this(LockedCTorByBitmapIndex(bitmap, paletteIndex)) {}

        static IntPtr LockedCTorByBitmap(Bitmap bitmap)
        {
            lock (DllSync)
            {
                return wxMask_ctorByBitmap(Object.SafePtr(bitmap));
            }
        }

		public Mask(Bitmap bitmap)
			: this(LockedCTorByBitmap(bitmap)) {}
		
		public Mask(IntPtr wxObject)
			: base(wxObject) {}
			
		//---------------------------------------------------------------------
			
		public bool Create(Bitmap bitmap, Colour colour)
		{
			return wxMask_CreateByBitmapColour(wxObject, Object.SafePtr(bitmap), Object.SafePtr(colour));
		}
		
		public bool Create(Bitmap bitmap, int paletteIndex)
		{
			return wxMask_CreateByBitmapIndex(wxObject, Object.SafePtr(bitmap), paletteIndex);
		}
		
		public bool Create(Bitmap bitmap)
		{
			return wxMask_CreateByBitmap(wxObject, Object.SafePtr(bitmap));
		}
	}
}
