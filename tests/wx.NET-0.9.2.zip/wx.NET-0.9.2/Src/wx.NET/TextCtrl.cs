//-----------------------------------------------------------------------------
// wx.NET - TextCtrl.cs
//
// The wxTextCtrl wrapper class.
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
// $Id: TextCtrl.cs,v 1.39 2010/05/08 19:54:35 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Drawing;
using System.Runtime.InteropServices;

namespace wx
{
	public enum TextAttrAlignment
	{
		wxTEXT_ALIGNMENT_DEFAULT,
		wxTEXT_ALIGNMENT_LEFT,
		wxTEXT_ALIGNMENT_CENTRE,
		wxTEXT_ALIGNMENT_CENTER = wxTEXT_ALIGNMENT_CENTRE,
		wxTEXT_ALIGNMENT_RIGHT,
		wxTEXT_ALIGNMENT_JUSTIFIED
	}
	
	//---------------------------------------------------------------------
	
	public enum TextCtrlHitTestResult
	{
		wxTE_HT_UNKNOWN = -2,
		wxTE_HT_BEFORE,      
		wxTE_HT_ON_TEXT,     
		wxTE_HT_BELOW,       
		wxTE_HT_BEYOND       
	}
	
	//---------------------------------------------------------------------

	public class TextAttr : Object
	{
        /** <summary>These are the bits used in property Flags.</summary>*/
        [Flags]
        public enum Attr
        {
            TextColour = 0x0001,
            BackgroundColour = 0x0002,
            FontFace = 0x0004,
            FontSize = 0x0008,
            FontWeight = 0x0010,
            FontItalic = 0x0020,
            FontUnderline = 0x0040,
            Font = FontFace+FontSize+FontWeight+FontItalic+FontUnderline,
            Alignment = 0x0080,
            LeftIndent = 0x0100,
            RightIndent = 0x0200,
            Tabs = 0x0400
        }

	
		//---------------------------------------------------------------------
	
		[DllImport("wx-c")] static extern IntPtr wxTextAttr_ctor(IntPtr colText, IntPtr colBack, IntPtr font, int alignment);
		[DllImport("wx-c")] static extern IntPtr wxTextAttr_ctor2();
		[DllImport("wx-c")] static extern void   wxTextAttr_dtor(IntPtr self);
		//[DllImport("wx-c")] static extern void   wxTextAttr_Init(IntPtr self);
		[DllImport("wx-c")] static extern void   wxTextAttr_SetTextColour(IntPtr self, IntPtr colText);
		[DllImport("wx-c")] static extern IntPtr wxTextAttr_GetTextColour(IntPtr self);
		[DllImport("wx-c")] static extern void   wxTextAttr_SetBackgroundColour(IntPtr self, IntPtr colBack);
		[DllImport("wx-c")] static extern IntPtr wxTextAttr_GetBackgroundColour(IntPtr self);
		[DllImport("wx-c")] static extern void   wxTextAttr_SetFont(IntPtr self, IntPtr font);
		[DllImport("wx-c")] static extern IntPtr wxTextAttr_GetFont(IntPtr self);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxTextAttr_HasTextColour(IntPtr self);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxTextAttr_HasBackgroundColour(IntPtr self);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxTextAttr_HasFont(IntPtr self);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxTextAttr_IsDefault(IntPtr self);
		
		[DllImport("wx-c")] static extern void   wxTextAttr_SetAlignment(IntPtr self, int alignment);
		[DllImport("wx-c")] static extern int    wxTextAttr_GetAlignment(IntPtr self);
		[DllImport("wx-c")] static extern void   wxTextAttr_SetTabs(IntPtr self, IntPtr tabs);
		[DllImport("wx-c")] static extern IntPtr wxTextAttr_GetTabs(IntPtr self);
		[DllImport("wx-c")] static extern void   wxTextAttr_SetLeftIndent(IntPtr self, int indent, int subIndent);
		[DllImport("wx-c")] static extern int    wxTextAttr_GetLeftIndent(IntPtr self);
		[DllImport("wx-c")] static extern int    wxTextAttr_GetLeftSubIndent(IntPtr self);
		[DllImport("wx-c")] static extern void   wxTextAttr_SetRightIndent(IntPtr self, int indent);
		[DllImport("wx-c")] static extern int    wxTextAttr_GetRightIndent(IntPtr self);
		[DllImport("wx-c")] static extern void   wxTextAttr_SetFlags(IntPtr self, int flags);
		[DllImport("wx-c")] static extern int    wxTextAttr_GetFlags(IntPtr self);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxTextAttr_HasAlignment(IntPtr self);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxTextAttr_HasTabs(IntPtr self);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxTextAttr_HasLeftIndent(IntPtr self);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxTextAttr_HasRightIndent(IntPtr self);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxTextAttr_HasFlag(IntPtr self, uint flag);
		
		//---------------------------------------------------------------------
		
		public TextAttr(IntPtr wxObject)
			: base(wxObject) 
		{
			this.wxObject = wxObject;
		}
		
		internal TextAttr(IntPtr wxObject, bool memOwn)
			: base(wxObject)
		{ 
			this.memOwn = memOwn;
			this.wxObject = wxObject;
		}

		public TextAttr()
			: this(wxTextAttr_ctor2(), true) { }

		public TextAttr(Colour colText)
			: this(colText, null, null, TextAttrAlignment.wxTEXT_ALIGNMENT_DEFAULT) {}
			
        /** <summary>Text attributes defining text and background colour.
         * Use <c>null</c> for the <c>colText</c> if you only want to specify the background colour.</summary>*/
		public TextAttr(Colour colText, Colour colBack)
			: this(colText, colBack, null, TextAttrAlignment.wxTEXT_ALIGNMENT_DEFAULT) {}

        /** <summary>Text attributes defining text and background colour.
         * Use <c>null</c> for unspecific properties.</summary>*/
        public TextAttr(Colour colText, Colour colBack, Font font)
			: this(colText, colBack, font, TextAttrAlignment.wxTEXT_ALIGNMENT_DEFAULT) {}

        /** <summary>Text attributes defining text and background colour.
         * Use <c>null</c> for unspecific properties.</summary>*/
        public TextAttr(Colour colText, Colour colBack, Font font, TextAttrAlignment alignment)
        		: this(wxTextAttr_ctor(Object.SafePtr(colText), Object.SafePtr(colBack), Object.SafePtr(font), (int)alignment), true) { }
			
		//---------------------------------------------------------------------
				
		public override void Dispose()
		{
			if (!disposed)
			{
				if (wxObject != IntPtr.Zero)
				{
					if (memOwn)
					{
						wxTextAttr_dtor(wxObject);
						memOwn = false;
					}
				}
				RemoveObject(wxObject);
				wxObject = IntPtr.Zero;
                --validInstancesCount;
                disposed = true;
			}
			
			base.Dispose();
			GC.SuppressFinalize(this);
		}
		
		//---------------------------------------------------------------------
		
		~TextAttr() 
		{
			Dispose();
		}
			    
		//---------------------------------------------------------------------
		
		public Colour TextColour
		{
			set { wxTextAttr_SetTextColour(wxObject, Object.SafePtr(value)); }
			get { return new Colour(wxTextAttr_GetTextColour(wxObject), true); }
		}
		
		//---------------------------------------------------------------------
		
		public Colour BackgroundColour
		{
			set { wxTextAttr_SetBackgroundColour(wxObject, Object.SafePtr(value)); }
			get { return new Colour(wxTextAttr_GetBackgroundColour(wxObject), true); }
		}
		
		//---------------------------------------------------------------------
		
		public Font Font 
		{
			set { wxTextAttr_SetFont(wxObject, Object.SafePtr(value)); }
			get { return new Font(wxTextAttr_GetFont(wxObject)); }
		}
		
		//---------------------------------------------------------------------
		
		public TextAttrAlignment Alignment
		{
			set { wxTextAttr_SetAlignment(wxObject, (int)value); }
			get { return (TextAttrAlignment)wxTextAttr_GetAlignment(wxObject); }
		}
		
		//---------------------------------------------------------------------
		
		public int[] Tabs
		{
			set {
				ArrayInt ai = new ArrayInt();
			
				for(int i = 0; i < value.Length; ++i)
					ai.Add(value[i]);
				
				wxTextAttr_SetTabs(wxObject, ArrayInt.SafePtr(ai));
			}
			get {
				return new ArrayInt(wxTextAttr_GetTabs(wxObject), true);
			}
		}
		
		//---------------------------------------------------------------------
		
		public void SetLeftIndent(int indent)
		{
			SetLeftIndent(indent, 0);
		}
		
		public void SetLeftIndent(int indent, int subIndent)
		{
			wxTextAttr_SetLeftIndent(wxObject, indent, subIndent);
		}
		
		public int LeftIndent
		{
			get { return wxTextAttr_GetLeftIndent(wxObject); }
		}
		
		public int LeftSubIndent
		{
			get { return wxTextAttr_GetLeftSubIndent(wxObject); }
		}
		
		//---------------------------------------------------------------------
		
		public int RightIndent
		{
			set { wxTextAttr_SetRightIndent(wxObject, value); }
			get { return wxTextAttr_GetRightIndent(wxObject); }
		}
		
		//---------------------------------------------------------------------

        /** <summary>Returns or sets a bitlist indicating which attributes will be set.</summary>*/
		public Attr Flags
		{
			set { wxTextAttr_SetFlags(wxObject, (int)value); }
			get { return (Attr)wxTextAttr_GetFlags(wxObject); }
		}
		
		//---------------------------------------------------------------------
		
		public bool HasTextColour
		{
			get { return wxTextAttr_HasTextColour(wxObject); }
		}
		
		//---------------------------------------------------------------------
		
		public bool HasBackgroundColour
		{
			get { return wxTextAttr_HasBackgroundColour(wxObject); }
		}
		
		//---------------------------------------------------------------------
		
		public bool HasFont
		{
			get { return wxTextAttr_HasFont(wxObject); }
		}
		
		//---------------------------------------------------------------------
		
		public bool HasAlignment
		{
			get { return wxTextAttr_HasAlignment(wxObject); }
		}
		
		//---------------------------------------------------------------------
		
		public bool HasTabs
		{
			get { return wxTextAttr_HasTabs(wxObject); }
		}
		
		//---------------------------------------------------------------------
		
		public bool HasLeftIndent
		{
			get { return wxTextAttr_HasLeftIndent(wxObject); }
		}
		
		//---------------------------------------------------------------------
		
		public bool HasRightIndent
		{
			get { return wxTextAttr_HasRightIndent(wxObject); }
		}
		
		//---------------------------------------------------------------------
		
		public bool HasFlag(Attr flag)
		{
			return wxTextAttr_HasFlag(wxObject, (uint)flag); 
		}
		
		//---------------------------------------------------------------------
		
		public bool IsDefault
		{
			get { return wxTextAttr_IsDefault(wxObject); }
		}
	}
	
	//---------------------------------------------------------------------

    /// <summary>Control to display and edit text.</summary>
    /// <remarks>
    /// <list type="table">
    /// <item><term>wxTE_PROCESS_ENTER</term><description>The control will generate the event wxEVT_COMMAND_TEXT_ENTER (otherwise pressing Enter key is either processed internally by the control or used for navigation between dialog controls).</description></item>
    /// <item><term>wxTE_PROCESS_TAB</term><description>  The control will receive wxEVT_CHAR events for TAB pressed - normally, TAB is used for passing to the next control in a dialog instead. For the control created with this style, you can still use Ctrl-Enter to pass to the next control from the keyboard.  </description></item>
    /// <item><term>wxTE_MULTILINE</term><description>  The text control allows multiple lines.  </description></item>
    /// <item><term>wxTE_PASSWORD</term><description>  The text will be echoed as asterisks.  </description></item>
    /// <item><term>wxTE_READONLY</term><description>  The text will not be user-editable.  </description></item>
    /// <item><term>wxTE_RICH</term><description>  Use rich text control under Win32, this allows to have more than 64KB of text in the control even under Win9x. This style is ignored under other platforms.  </description></item>
    /// <item><term>wxTE_RICH2</term><description>  Use rich text control version 2.0 or 3.0 under Win32, this style is ignored under other platforms  </description></item>
    /// <item><term>wxTE_AUTO_URL</term><description>  Highlight the URLs and generate the wxTextUrlEvents when mouse events occur over them. This style is only supported for wxTE_RICH Win32 and multi-line wxGTK2 text controls.  </description></item>
    /// <item><term>wxTE_NOHIDESEL</term><description>  By default, the Windows text control doesn't show the selection when it doesn't have focus - use this style to force it to always show it. It doesn't do anything under other platforms.  </description></item>
    /// <item><term>wxHSCROLL</term><description>  A horizontal scrollbar will be created and used, so that text won't be wrapped. No effect under wxGTK1.  </description></item>
    /// <item><term>wxTE_LEFT</term><description>  The text in the control will be left-justified (default).  </description></item>
    /// <item><term>wxTE_CENTRE</term><description>  The text in the control will be centered (currently wxMSW and wxGTK2 only).  </description></item>
    /// <item><term>wxTE_RIGHT</term><description>  The text in the control will be right-justified (currently wxMSW and wxGTK2 only).  </description></item>
    /// <item><term>wxTE_DONTWRAP</term><description>  Same as wxHSCROLL style: don't wrap at all, show horizontal scrollbar instead.  </description></item>
    /// <item><term>wxTE_CHARWRAP</term><description>  Wrap the lines too long to be shown entirely at any position (wxUniv and wxGTK2 only).  </description></item>
    /// <item><term>wxTE_WORDWRAP </term><description> Wrap the lines too long to be shown entirely at word boundaries (wxUniv and wxGTK2 only).  </description></item>
    /// <item><term>wxTE_BESTWRAP </term><description> Wrap the lines at word boundaries or at any other character if there are words longer than the window width (this is the default).  </description></item>
    /// <item><term>wxTE_CAPITALIZE </term><description> On PocketPC and Smartphone, causes the first letter to be capitalized.  </description></item>
    /// </list>
    /// 
    /// Note that alignment styles (wxTE_LEFT, wxTE_CENTRE and wxTE_RIGHT) can be changed dynamically after control creation
    /// on wxMSW and wxGTK. wxTE_READONLY, wxTE_PASSWORD and wrapping styles can be dynamically changed under wxGTK but
    /// not wxMSW. The other styles can be only set during control creation.
    ///
    /// wx.TextCtrl text format
    ///
    /// The multiline text controls always store the text as a sequence of lines separated by \n characters, i.e. in the
    /// Unix text format even on non-Unix platforms. This allows the user code to ignore the differences between the 
    /// platforms but at a price: the indices in the control such as those returned by GetInsertionPoint or GetSelection
    /// can not be used as indices into the string returned by GetValue as they're going to be slightly off for platforms
    /// using "\r\n" as separator (as Windows does), for example.
    ///
    /// Instead, if you need to obtain a substring between the 2 indices obtained from the control with the help of the
    /// functions mentioned above, you should use GetRange. And the indices themselves can only be passed to other methods,
    /// for example SetInsertionPoint or SetSelection.
    ///
    /// To summarize: never use the indices returned by (multiline) wxTextCtrl as indices into the string it contains, but
    /// only as arguments to be passed back to the other wx.TextCtrl methods.
    ///
    /// wx.TextCtrl styles
    ///
    /// Multi-line text controls support the styles, i.e. provide a possibility to set colours and font for individual
    /// characters in it (note that under Windows wxTE_RICH style is required for style support). To use the styles you
    /// can either call SetDefaultStyle before inserting the text or call SetStyle later to change the style of the text
    /// already in the control (the first solution is much more efficient).
    ///
    /// In either case, if the style doesn't specify some of the attributes (for example you only want to set the text
    /// colour but without changing the font nor the text background), the values of the default style will be used for
    /// them. If there is no default style, the attributes of the text control itself are used.
    ///
    /// So the following code correctly describes what it does: the second call to SetDefaultStyle doesn't change the 
    /// text foreground colour (which stays red) while the last one doesn't change the background colour (which stays grey):
    ///
    /// <code>
    /// text.SetDefaultStyle(wxTextAttr(wx.Colour.wxRED));
    /// text.AppendText("Red text\n");
    /// text.SetDefaultStyle(wx.TextAttr(null, wx.Colour.wxLIGHT_GREY));
    /// text.AppendText("Red on grey text\n");
    /// text.SetDefaultStyle(wxTextAttr(wx.Colour.wxBLUE);
    /// text.AppendText("Blue on grey text\n");
    /// </code>
    /// 
    /// Event handling
    ///
    /// The following commands are processed by default event handlers in wxTextCtrl: wxID_CUT, wxID_COPY, wxID_PASTE,
    /// wxID_UNDO, wxID_REDO. The associated UI update events are also processed automatically, when the control has
    /// the focus.
    ///
    /// To process input from a text control, use these event handler macros to direct input to member functions
    /// that take a wxCommandEvent argument.
    /// <list type="table">
    /// <item><term>EVT_TEXT(id, func)</term><description>Respond to a wxEVT_COMMAND_TEXT_UPDATED event, generated when the text changes. Notice that this event will be sent when the text controls contents changes - whether this is due to user input or comes from the program itself (for example, if SetValue() is called); see ChangeValue() for a function which does not send this event.</description></item>
    /// <item><term>EVT_TEXT_ENTER(id, func)</term><description>Respond to a wxEVT_COMMAND_TEXT_ENTER event, generated when enter is pressed in a text control (which must have wxTE_PROCESS_ENTER style for this event to be generated).</description></item>
    /// <item><term>EVT_TEXT_URL(id, func)</term><description>A mouse event occurred over an URL in the text control (wxMSW and wxGTK2 only) </description></item> 
    /// <item><term>EVT_TEXT_MAXLEN(id, func)</term><description>User tried to enter more text into the control than the limit set by SetMaxLength.  </description></item>
    /// </list>
    /// </remarks>
	public class TextCtrl : Control
	{
		[DllImport("wx-c")] static extern IntPtr wxTextCtrl_GetValue(IntPtr self);
		[DllImport("wx-c")] static extern void   wxTextCtrl_SetValue(IntPtr self, IntPtr value);
		[DllImport("wx-c")] static extern IntPtr wxTextCtrl_GetRange(IntPtr self, int from, int to);
		[DllImport("wx-c")] static extern int    wxTextCtrl_GetLineLength(IntPtr self, int lineNo);
		[DllImport("wx-c")] static extern IntPtr wxTextCtrl_GetLineText(IntPtr self, int lineNo);
		[DllImport("wx-c")] static extern int    wxTextCtrl_GetNumberOfLines(IntPtr self);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxTextCtrl_IsModified(IntPtr self);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxTextCtrl_IsEditable(IntPtr self);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxTextCtrl_IsSingleLine(IntPtr self);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxTextCtrl_IsMultiLine(IntPtr self);
		[DllImport("wx-c")] static extern void   wxTextCtrl_GetSelection(IntPtr self, out int from, out int to);
		//[DllImport("wx-c")] static extern IntPtr wxTextCtrl_GetStringSelection(IntPtr self);
		[DllImport("wx-c")] static extern void   wxTextCtrl_Clear(IntPtr self);
		[DllImport("wx-c")] static extern void   wxTextCtrl_Replace(IntPtr self, int from, int to, IntPtr value);
		[DllImport("wx-c")] static extern void   wxTextCtrl_Remove(IntPtr self, int from, int to);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxTextCtrl_LoadFile(IntPtr self, IntPtr file);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxTextCtrl_SaveFile(IntPtr self, IntPtr file);
		[DllImport("wx-c")] static extern void   wxTextCtrl_MarkDirty(IntPtr self);
		[DllImport("wx-c")] static extern void   wxTextCtrl_DiscardEdits(IntPtr self);
		[DllImport("wx-c")] static extern void   wxTextCtrl_SetMaxLength(IntPtr self, int len);
		[DllImport("wx-c")] static extern void   wxTextCtrl_WriteText(IntPtr self, IntPtr text);
		[DllImport("wx-c")] static extern void   wxTextCtrl_AppendText(IntPtr self, IntPtr text);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxTextCtrl_EmulateKeyPress(IntPtr self, IntPtr evt);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxTextCtrl_SetStyle(IntPtr self, int start, int end, IntPtr style);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxTextCtrl_GetStyle(IntPtr self, int position, ref IntPtr style);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxTextCtrl_SetDefaultStyle(IntPtr self, IntPtr style);
		[DllImport("wx-c")] static extern IntPtr wxTextCtrl_GetDefaultStyle(IntPtr self);
		[DllImport("wx-c")] static extern int    wxTextCtrl_XYToPosition(IntPtr self, int x, int y);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxTextCtrl_PositionToXY(IntPtr self, int pos, out int x, out int y);
		[DllImport("wx-c")] static extern void   wxTextCtrl_ShowPosition(IntPtr self, int pos);
		[DllImport("wx-c")] static extern int    wxTextCtrl_HitTest(IntPtr self, ref Point pt, out int pos);
		[DllImport("wx-c")] static extern int    wxTextCtrl_HitTest2(IntPtr self, ref Point pt, out int col, out int row);
		[DllImport("wx-c")] static extern void   wxTextCtrl_Copy(IntPtr self);
		[DllImport("wx-c")] static extern void   wxTextCtrl_Cut(IntPtr self);
		[DllImport("wx-c")] static extern void   wxTextCtrl_Paste(IntPtr self);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxTextCtrl_CanCopy(IntPtr self);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxTextCtrl_CanCut(IntPtr self);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxTextCtrl_CanPaste(IntPtr self);
		[DllImport("wx-c")] static extern void   wxTextCtrl_Undo(IntPtr self);
		[DllImport("wx-c")] static extern void   wxTextCtrl_Redo(IntPtr self);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxTextCtrl_CanUndo(IntPtr self);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxTextCtrl_CanRedo(IntPtr self);
		[DllImport("wx-c")] static extern void   wxTextCtrl_SetInsertionPoint(IntPtr self, int pos);
		[DllImport("wx-c")] static extern void   wxTextCtrl_SetInsertionPointEnd(IntPtr self);
		[DllImport("wx-c")] static extern int    wxTextCtrl_GetInsertionPoint(IntPtr self);
		[DllImport("wx-c")] static extern int    wxTextCtrl_GetLastPosition(IntPtr self);
		[DllImport("wx-c")] static extern void   wxTextCtrl_SetSelection(IntPtr self, int from, int to);
		[DllImport("wx-c")] static extern void   wxTextCtrl_SelectAll(IntPtr self);
		[DllImport("wx-c")] static extern void   wxTextCtrl_SetEditable(IntPtr self, bool editable);
		[DllImport("wx-c")] static extern        IntPtr wxTextCtrl_ctor();
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxTextCtrl_Create(IntPtr self, IntPtr parent, int id, IntPtr value, int posX, int posY, int width, int height, uint style, IntPtr validator, IntPtr name);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxTextCtrl_Enable(IntPtr self, bool enable);
		[DllImport("wx-c")] static extern void   wxTextCtrl_OnDropFiles(IntPtr self, IntPtr evt);
        [DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)] static extern bool wxTextCtrl_SetFont(IntPtr self, IntPtr font);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxTextCtrl_SetForegroundColour(IntPtr self, IntPtr colour);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxTextCtrl_SetBackgroundColour(IntPtr self, IntPtr colour);
		[DllImport("wx-c")] static extern void   wxTextCtrl_Freeze(IntPtr self);
		[DllImport("wx-c")] static extern void   wxTextCtrl_Thaw(IntPtr self);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxTextCtrl_ScrollLines(IntPtr self, int lines);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxTextCtrl_ScrollPages(IntPtr self, int pages);

		//---------------------------------------------------------------------
        
		public TextCtrl(IntPtr wxObject)
			: base(wxObject) { }

		public TextCtrl(Window parent)
			: this(parent, Window.UniqueID, "", wxDefaultPosition, wxDefaultSize, WindowStyles.NO_STYLE, null) { }

		public TextCtrl(Window parent, int id)
            : this(parent, id, "", wxDefaultPosition, wxDefaultSize, WindowStyles.NO_STYLE, null) { }

		public TextCtrl(Window parent, int id, string value)
            : this(parent, id, value, wxDefaultPosition, wxDefaultSize, WindowStyles.NO_STYLE, null) { }

		public TextCtrl(Window parent, int id, string value, Point pos, Size size, WindowStyles style)
			: this(parent, id, value, pos, size, style, null) { }

		public TextCtrl(Window parent, int id, string value, Point pos, Size size)
			: this(parent, id, value, pos, size, 0, null) { }

        public TextCtrl(Window parent, int id, string value, Point pos, Size size, WindowStyles style, string name)
            : this(parent, id, wxString.SafeNew(value), pos, size, style, wxString.SafeNew(name))
        {
        }
        public TextCtrl(Window parent, int id, wxString value, Point pos, Size size, WindowStyles style, wxString name)
			: this(wxTextCtrl_ctor())
		{
			if (!wxTextCtrl_Create(wxObject, Object.SafePtr(parent), id, Object.SafePtr(value), pos.X, pos.Y, size.Width, size.Height, (uint)style, IntPtr.Zero, Object.SafePtr(name)))
			{
				throw new InvalidOperationException("Failed to create TextCtrl");
			}
		}
	
		//---------------------------------------------------------------------
		// ctors with self created id
		
		public TextCtrl(Window parent, string value)
            : this(parent, Window.UniqueID, value, wxDefaultPosition, wxDefaultSize, WindowStyles.NO_STYLE, null) { }

        public TextCtrl(Window parent, string value, Point pos, Size size, WindowStyles style)
			: this(parent, Window.UniqueID, value, pos, size, style, null) { }
	
		public TextCtrl(Window parent, string value, Point pos, Size size)
            : this(parent, Window.UniqueID, value, pos, size, WindowStyles.NO_STYLE, null) { }
	
		public TextCtrl(Window parent, string value, Point pos, Size size, uint style, string name)
            : this(parent, Window.UniqueID, value, pos, size, WindowStyles.NO_STYLE, name) { }
	
		//---------------------------------------------------------------------

		public void Clear()
		{
			wxTextCtrl_Clear(wxObject);
		}
	
		//---------------------------------------------------------------------
	
		public override Colour BackgroundColour
		{
			set
			{
				wxTextCtrl_SetBackgroundColour(wxObject, Object.SafePtr(value));
			}
			get
			{
				return base.BackgroundColour;
			}
		}
	
		public override Colour ForegroundColour
		{
			set
			{
				wxTextCtrl_SetForegroundColour(wxObject, Object.SafePtr(value));
			}
			get
			{
				return base.ForegroundColour;
			}
		}
	
		public override Font Font
		{
			set
			{
				wxTextCtrl_SetFont(this.wxObject, Object.SafePtr(value));
			}
			get
			{
				return base.Font;
			}
		}
	
		//---------------------------------------------------------------------
	
		public string Value
		{
			get
			{
				return new wxString(wxTextCtrl_GetValue(wxObject), true);
			}
			set
			{
                using (wxString wxvalue = wxString.SafeNew(value))
                {
                    wxTextCtrl_SetValue(wxObject, Object.SafePtr(wxvalue));
                }
			}
		}
	
		//---------------------------------------------------------------------
	
		public string GetRange(int from, int to)
		{
			return new wxString(wxTextCtrl_GetRange(wxObject, from, to), true);
		}
	
		//---------------------------------------------------------------------
	
		public int LineLength(int lineNo)
		{
			return wxTextCtrl_GetLineLength(wxObject, lineNo);
		}
	
		public string GetLineText(int lineNo)
		{
			return new wxString(wxTextCtrl_GetLineText(wxObject, lineNo), true);
		}
	
		public int GetNumberOfLines()
		{
			return wxTextCtrl_GetNumberOfLines(wxObject);
		}
	
		//---------------------------------------------------------------------
	
		public bool IsModified
		{
			get { return wxTextCtrl_IsModified(wxObject); }
		}
	
		public bool IsEditable
		{
			get { return wxTextCtrl_IsEditable(wxObject); }
		}
	
		public bool IsSingleLine
		{
			get { return wxTextCtrl_IsSingleLine(wxObject); }
		}
	
		public bool IsMultiLine
		{
			get { return wxTextCtrl_IsMultiLine(wxObject); }
		}
	
		//---------------------------------------------------------------------
	
		public void GetSelection(out int from, out int to)
		{
			wxTextCtrl_GetSelection(wxObject, out from, out to);
		}
	
		//---------------------------------------------------------------------

        public void Replace(int from, int to, string value)
        {
            this.Replace(from, to, wxString.SafeNew(value));
        }
		public void Replace(int from, int to, wxString value)
		{
			wxTextCtrl_Replace(wxObject, from, to, Object.SafePtr(value));
		}
	
		public void Remove(int from, int to)
		{
			wxTextCtrl_Remove(wxObject, from, to);
		}
	
		//---------------------------------------------------------------------

        public bool LoadFile(string file)
        {
            return this.LoadFile(wxString.SafeNew(file));
        }
		public bool LoadFile(wxString file)
		{
			return wxTextCtrl_LoadFile(wxObject, Object.SafePtr( file));
		}
		
		// using wx.NET with wxGTK wxTextCtrl_LoadFile didn't work
		// LoadFileNET uses StreamReader
		// this should also handle encoding problems...
		public bool LoadFileNET(string file)
		{
			try
			{
				System.IO.StreamReader sr = new System.IO.StreamReader(file);
				string s = sr.ReadToEnd();
				sr.Close();
				AppendText(s);
				
				return true;
				
			} catch ( Exception)
			{
				return false;
			}
		}

        public bool SaveFile(string file)
        {
            return this.SaveFile(wxString.SafeNew(file));
        }
        public bool SaveFile(wxString file)
		{
			return wxTextCtrl_SaveFile(wxObject, Object.SafePtr(file));
		}
		
		// counterpart of LoadFileNET
		public bool SaveFileNET(string file)
		{
			try
			{
				System.IO.StreamWriter sw = new System.IO.StreamWriter(file);
				sw.Write(Value);
				sw.Close();
				
				return true;
			} catch ( Exception)
			{
				return false;
			}
		}
	
		//---------------------------------------------------------------------
	
		public void DiscardEdits()
		{
			wxTextCtrl_DiscardEdits(wxObject);
		}
		
		//---------------------------------------------------------------------
		
		public void MarkDirty()
		{
			wxTextCtrl_MarkDirty(wxObject);
		}
	
		//---------------------------------------------------------------------
	
		public int MaxLength
		{
			set { wxTextCtrl_SetMaxLength(wxObject, value); }
		}
	
		//---------------------------------------------------------------------

        public void WriteText(string text)
        {
            using (wxString wxtext = wxString.SafeNew(text))
            {
                this.WriteText(wxtext);
            }
        }
        public void WriteText(wxString text)
		{
			wxTextCtrl_WriteText(wxObject, Object.SafePtr(text));
		}
		
		//---------------------------------------------------------------------

        /** <summary>This appends the expanded <c>format</c> to the text as presented by this control.
         * The format string is due to <c>string.Format()</c>.</summary>*/
        public void AppendFormat(string format, params object[] args)
        {
            this.AppendText(string.Format(format, args));
        }

        /** <summary>This appends <c>text</c> to the text presented in the control.
         * Cf. AppendFormat().</summary>*/
        public void AppendText(string text)
        {
            using (wxString wxtext=wxString.SafeNew(text))
            {
                this.AppendText(wxtext);
            }
        }
        /** <summary>This appends <c>text</c> to the text presented in the control.</summary>*/
        public void AppendText(wxString text)
		{
			wxTextCtrl_AppendText(wxObject, Object.SafePtr(text));
		}
		
		//---------------------------------------------------------------------
		
		public bool EmulateKeyPress(KeyEvent evt)
		{
			return wxTextCtrl_EmulateKeyPress(wxObject, Object.SafePtr(evt));
		}
	
		//---------------------------------------------------------------------
	
		public bool SetStyle(int start, int end, TextAttr style)
		{
			return wxTextCtrl_SetStyle(wxObject, start, end, Object.SafePtr(style));
		}
		
		public bool GetStyle(int position, ref TextAttr style)
		{
			IntPtr tmp = Object.SafePtr(style);
			bool retval = wxTextCtrl_GetStyle(wxObject, position, ref tmp);
			style.wxObject = tmp;
			return retval;
		}
		
		//---------------------------------------------------------------------
	
		public bool SetDefaultStyle(TextAttr style)
		{
			return wxTextCtrl_SetDefaultStyle(wxObject, Object.SafePtr(style));
		}
		
		public TextAttr GetDefaultStyle()
		{
			return (TextAttr)Object.FindObject(wxTextCtrl_GetDefaultStyle(wxObject));
		}
	
		//---------------------------------------------------------------------
	
		public int XYToPosition(int x, int y)
		{
			return wxTextCtrl_XYToPosition(wxObject, x, y);
		}
        public int XYToPosition(System.Drawing.Point position)
        {
            return this.XYToPosition(position.X, position.Y);
        }
	
		public bool PositionToXY(int pos, out int x, out int y)
		{
			return wxTextCtrl_PositionToXY(wxObject, pos, out x, out y);
		}
        public System.Drawing.Point PositionToXY(int pos)
        {
            int x, y;
            if (PositionToXY(pos, out x, out y))
                return new Point(x, y);
            else
                return wxDefaultPosition;
        }
	
		public void ShowPosition(int pos)
		{
			wxTextCtrl_ShowPosition(wxObject, pos);
		}
	
		//---------------------------------------------------------------------
		
		public TextCtrlHitTestResult HitTest(Point pt, out int pos)
		{
			return (TextCtrlHitTestResult)wxTextCtrl_HitTest(wxObject, ref pt, out pos);
		}
		
		public TextCtrlHitTestResult HitTest(Point pt, out int col, out int row)
		{
			return (TextCtrlHitTestResult)wxTextCtrl_HitTest2(wxObject, ref pt, out col, out row);
		}
		
		//---------------------------------------------------------------------
	
		public void Copy()
		{
			wxTextCtrl_Copy(wxObject);
		}
	
		public void Cut()
		{
			wxTextCtrl_Cut(wxObject);
		}
	
		public void Paste()
		{
			wxTextCtrl_Paste(wxObject);
		}
	
		//---------------------------------------------------------------------
	
		public bool CanCopy()
		{
			return wxTextCtrl_CanCopy(wxObject);
		}
	
		public bool CanCut()
		{
			return wxTextCtrl_CanCut(wxObject);
		}
	
		public bool CanPaste()
		{
			return wxTextCtrl_CanPaste(wxObject);
		}
	
		//---------------------------------------------------------------------
	
		public void Undo()
		{
			wxTextCtrl_Undo(wxObject);
		}
	
		public void Redo()
		{
			wxTextCtrl_Redo(wxObject);
		}
	
		//---------------------------------------------------------------------
	
		public bool CanUndo()
		{
			return wxTextCtrl_CanUndo(wxObject);
		}
	
		public bool CanRedo()
		{
			return wxTextCtrl_CanRedo(wxObject);
		}
	
		//---------------------------------------------------------------------
	
		public int InsertionPoint
		{
			set
			{
				wxTextCtrl_SetInsertionPoint(wxObject, value);
			}
			get
			{
				return wxTextCtrl_GetInsertionPoint(this.wxObject);
			}
		}
	
		public void SetInsertionPointEnd()
		{
			wxTextCtrl_SetInsertionPointEnd(wxObject);
		}
	
		public int GetLastPosition()
		{
			return wxTextCtrl_GetLastPosition(wxObject);
		}
	
		//---------------------------------------------------------------------
	
		public void SetSelection(int from, int to)
		{
			wxTextCtrl_SetSelection(wxObject, from, to);
		}
	
		public void SelectAll()
		{
			wxTextCtrl_SelectAll(wxObject);
		}
	
		//---------------------------------------------------------------------
	
		public void SetEditable(bool editable)
		{
			wxTextCtrl_SetEditable(wxObject, editable);
		}
	
		//---------------------------------------------------------------------
	
		public bool Enable(bool enable)
		{
			return wxTextCtrl_Enable(wxObject, enable);
		}
	
		//---------------------------------------------------------------------
	
		public virtual void OnDropFiles(Event evt)
		{
			wxTextCtrl_OnDropFiles(wxObject, Object.SafePtr(evt));
		}
	
		//---------------------------------------------------------------------
	
		public override void Freeze()
		{
			wxTextCtrl_Freeze(wxObject);
		}
	
		public override void Thaw()
		{
			wxTextCtrl_Thaw(wxObject);
		}
	
		//---------------------------------------------------------------------
	
		public override bool ScrollLines(int lines)
		{
			return wxTextCtrl_ScrollLines(wxObject, lines);
		}
	
		public override bool ScrollPages(int pages)
		{
			return wxTextCtrl_ScrollPages(wxObject, pages);
		}
	
		//---------------------------------------------------------------------
	
		public override event EventListener UpdateUI
		{
			add { AddCommandListener(Event.wxEVT_COMMAND_TEXT_UPDATED, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

		public event EventListener Enter
		{
			add { AddCommandListener(Event.wxEVT_COMMAND_TEXT_ENTER, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}
	}
	
	//---------------------------------------------------------------------

	public class TextUrlEvent : CommandEvent
    	{
		[DllImport("wx-c")] static extern IntPtr wxTextUrlEvent_ctor(int id, IntPtr evtMouse, int start, int end);
		[DllImport("wx-c")] static extern int   wxTextUrlEvent_GetURLStart(IntPtr self);
		[DllImport("wx-c")] static extern int   wxTextUrlEvent_GetURLEnd(IntPtr self);
	
		// TODO: Replace Event with EventMouse
		public TextUrlEvent(int id, Event evtMouse, int start, int end)
		: base(wxTextUrlEvent_ctor(id, Object.SafePtr(evtMouse), start, end)) {}
		
		public int UrlStart
		{
			get { return wxTextUrlEvent_GetURLStart(this.wxObject); }
		}
		
		public int UrlEnd
		{
			get { return wxTextUrlEvent_GetURLEnd(this.wxObject); }
		}
	}
}
