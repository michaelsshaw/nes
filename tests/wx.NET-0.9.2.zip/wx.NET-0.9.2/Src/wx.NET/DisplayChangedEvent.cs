//-----------------------------------------------------------------------------
// wx.NET - DisplayChangedEvent.cs
//
// The wxDisplayChangedEvent wrapper class.
//
// Written by Alexander Olk (xenomorph2@onlinehome.de)
// (C) 2004 by Alexander Olk
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: DisplayChangedEvent.cs,v 1.3 2009/07/03 18:49:48 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Runtime.InteropServices;

namespace wx
{
	public class DisplayChangedEvent : Event
	{
		[DllImport("wx-c")] static extern IntPtr wxDisplayChangedEvent_ctor();
		
		//-----------------------------------------------------------------------------

		public DisplayChangedEvent(IntPtr wxObject) 
			: base(wxObject) { }

        static IntPtr LockedCTor()
        {
            lock (DllSync)
            {
                return wxDisplayChangedEvent_ctor();
            }
        }

		public DisplayChangedEvent()
			: this(LockedCTor()) { }
	}
}
