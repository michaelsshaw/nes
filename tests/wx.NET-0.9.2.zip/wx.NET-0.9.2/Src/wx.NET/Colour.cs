//-----------------------------------------------------------------------------
// wx.NET - Colour.cs
//
// The wxColour wrapper class.
//
// Written by Jason Perkins (jason@379.com)
// (C) 2003 by 379, Inc.
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: Colour.cs,v 1.24 2010/05/08 19:51:26 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Runtime.InteropServices;

namespace wx
{
    /** <summary>This class represents colours.
     * </summary>
     */
    [wx.Globalization.TypeNameTranslations("Colour", "en-US", "Color", "de", "Farbe")]
    public class Colour : Object, ICanBeMadeReadonly
    {
        #region Nested Types And Constants
        /** <summary>Options for wx.Colour.GetAsString()
         * </summary>
         */
        [Flags]
        public enum C2S
        {
            /** <summary>return colour name, when possible
             * </summary>
             */
            NAME=1,
            /** <summary>return colour in rgb(r,g,b) syntax
             * </summary>
             */
            CSS_SYNTAX=2,
            /** <summary> return colour in #rrggbb syntax.
             * </summary>
             */
            HTML_SYNTAX=4,
        }

        /** <summary>This is the APLPHA value indicating transparency.
         * </summary>
         */
        const byte wxALPHA_TRANSPARENT = 0;
        /** <summary>This is the APLPHA value indicating opaque colour.
         * </summary>
         */
        const byte wxALPHA_OPAQUE = 0xff;
        #endregion

        #region C API
        [DllImport("wx-c")]
        static extern IntPtr wxColour_ctor();
        [DllImport("wx-c")]
        static extern IntPtr wxColour_ctorByName(IntPtr name);
        [DllImport("wx-c")]
        static extern IntPtr wxColour_ctorByParts(byte red, byte green, byte blue);
        [DllImport("wx-c")]
        static extern IntPtr wxColour_ctorByPartsWithAlpha(byte red, byte green, byte blue, byte alpha);
        [DllImport("wx-c")]
        static extern void wxColour_dtor(IntPtr self);
        //[DllImport("wx-c")] static extern void   wxColour_RegisterDisposable(IntPtr self, Virtual_Dispose onDispose);

        [DllImport("wx-c")]
        static extern byte wxColour_Red(IntPtr self);
        [DllImport("wx-c")]
        static extern byte wxColour_Blue(IntPtr self);
        [DllImport("wx-c")]
        static extern byte wxColour_Green(IntPtr self);
        [DllImport("wx-c")]
        static extern byte wxColour_Alpha(IntPtr self);
        [DllImport("wx-c")]
        static extern IntPtr wxColour_GetAsString(IntPtr self, int flags);

        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxColour_Ok(IntPtr self);
        [DllImport("wx-c")]
        static extern void wxColour_Set(IntPtr self, byte red, byte green, byte blue, byte alpha);
        [DllImport("wx-c")]
        static extern void wxColour_SetFromColour(IntPtr self, IntPtr srcColour);
        [DllImport("wx-c")]
        static extern void wxColour_SetFromString(IntPtr self, IntPtr srcString);
        #endregion

        #region State
        bool _isReadonly = false;
        #endregion

        #region Static Constants
        public static readonly Colour wxBLACK = (Colour)((Colour)new Colour("Black")).MakeReadOnly();
        public static readonly Colour wxWHITE = (Colour)((Colour)new Colour("White")).MakeReadOnly();
        public static readonly Colour wxRED = (Colour)((Colour)new Colour("Red")).MakeReadOnly();
        public static readonly Colour wxBLUE = (Colour)((Colour)new Colour("Blue")).MakeReadOnly();
        public static readonly Colour wxGREEN = (Colour)((Colour)new Colour("Green")).MakeReadOnly();
        public static readonly Colour wxCYAN = (Colour)((Colour)new Colour("Cyan")).MakeReadOnly();
        public static readonly Colour wxLIGHT_GREY = (Colour)((Colour)new Colour("Light Gray")).MakeReadOnly();
        #endregion

        #region CTor / DTor
        public Colour(IntPtr wxObject)
            : base(wxObject)
        {
        }

        internal Colour(IntPtr wxObject, bool memOwn)
            : base(wxObject)
        {
            this.memOwn = memOwn;
        }

        static IntPtr LockedCTor()
        {
            lock (DllSync)
            {
                return wxColour_ctor();
            }
        }

        public Colour()
            : this(LockedCTor(), true)
        {
        }

        public Colour(string name)
            : this(wxString.SafeNew(name.ToUpper()))
        {
        }

        static IntPtr LockedCTorByName(wxString name)
        {
            lock (DllSync)
            {
                return wxColour_ctorByName(Object.SafePtr(name));
            }
        }
        
        protected override void CallDTor ()
        {
        	wxColour_dtor(this.wxObject);
        }


        public Colour(wxString name)
            : this(LockedCTorByName(name), true)
        {
        }

        static IntPtr LockedCTorByParts(byte red, byte green, byte blue)
        {
            lock (DllSync)
            {
                return wxColour_ctorByParts(red, green, blue);
            }
        }

        public Colour(byte red, byte green, byte blue)
            : this(LockedCTorByParts(red, green, blue), true)
        {
        }

        static IntPtr LockedCTorByPartsWithAlpha(byte red, byte green, byte blue, byte alpha)
        {
            lock (DllSync)
            {
                return wxColour_ctorByPartsWithAlpha(red, green, blue, alpha);
            }
        }

        public Colour(byte red, byte green, byte blue, byte alpha)
            : this(LockedCTorByPartsWithAlpha(red, green, blue, alpha), true)
        {
        }

        public Colour(Colour colour)
            : this(colour.Red, colour.Green, colour.Blue, colour.Alpha)
        {
        }

        ~Colour()
        {
            Dispose();
        }

        public override void Dispose()
        {
            if ((this != Colour.wxBLACK) && (this != Colour.wxWHITE) &&
                    (this != Colour.wxRED) && (this != Colour.wxBLUE) &&
                            (this != Colour.wxGREEN) && (this != Colour.wxCYAN) &&
                                    (this != Colour.wxLIGHT_GREY))
            {
                Dispose(true);
            }
        }
        #endregion

        #region Properties
        public byte Red
        {
            get { return wxColour_Red(wxObject); }
            set {
                if (this.IsReadonly)
                    throw new CannotChangeReadonly();
                this.Set(value, this.Green, this.Blue);
            }
        }

        public byte Green
        {
            get { return wxColour_Green(wxObject); }
            set {
                if (this.IsReadonly)
                    throw new CannotChangeReadonly();
                this.Set(this.Red, value, this.Blue);
            }
        }

        public byte Blue
        {
            get { return wxColour_Blue(wxObject); }
            set {
                if (this.IsReadonly)
                    throw new CannotChangeReadonly();
                this.Set(this.Red, this.Green, value);
            }
        }

        public byte Alpha
        {
            get { return wxColour_Alpha(this.wxObject); }
            set
            {
                if (this.IsReadonly)
                    throw new CannotChangeReadonly();
                this.Set(this.Red, this.Green, this.Blue, value);
            }
        }

        public bool Ok()
        {
            return wxColour_Ok(wxObject);
        }
        #endregion

        #region Modifiers
        /** <summary>Assign RGB values.</summary>*/
        public void Set(byte red, byte green, byte blue)
        {
            if (this.IsReadonly)
                throw new CannotChangeReadonly();

            wxColour_Set(wxObject, red, green, blue, 255);
        }
        /** <summary>Assign RGB and Alpha values.</summary>*/
        public void Set(byte red, byte green, byte blue, byte alpha)
        {
            if (this.IsReadonly)
                throw new CannotChangeReadonly();

            wxColour_Set(wxObject, red, green, blue, alpha);
        }

        public void Set(Colour src)
        {
            if (this.IsReadonly)
                throw new CannotChangeReadonly();

            wxColour_SetFromColour(wxObject, Object.SafePtr(src));
        }

        /// <summary>
        /// Set RGB values from the provided string.
        /// Set() accepts: colour names (those listed in wxTheColourDatabase), the CSS-like "RGB(r,g,b)" syntax
        /// (case insensitive) and the HTML-like syntax (i.e. "#" followed by 6 hexadecimal digits for red, green,
        /// blue components).
        /// </summary>
        /// <param name="str">Colour name, RGB-syntax string or HTML-like colour notation</param>
        public void Set(wxString str)
        {
            if (this.IsReadonly)
                throw new CannotChangeReadonly();

            wxColour_SetFromString(this.wxObject, Object.SafePtr(str));
        }

        /// <summary>
        /// Set RGB values from the provided string.
        /// Set() accepts: colour names (those listed in wxTheColourDatabase), the CSS-like "RGB(r,g,b)" syntax
        /// (case insensitive) and the HTML-like syntax (i.e. "#" followed by 6 hexadecimal digits for red, green,
        /// blue components).
        /// </summary>
        /// <param name="str">Colour name, RGB-syntax string or HTML-like colour notation</param>
        public void Set(string str)
        {
            if (this.IsReadonly)
                throw new CannotChangeReadonly();

            using (wxString wxStr = wxString.SafeNew(str))
            {
                this.Set(wxStr);
            }
        }

        /** <summary>Returns the colour in string form according to the provided flags.</summary>*/
        public string GetAsString(C2S flags)
        {
            wxString str=wxString.SafeNew(wxColour_GetAsString(this.wxObject, (int) flags));
            return str;
        }

        /** <summary>Returns a string form representing the colour.
         * Implemented by GetAsString().</summary>*/
        public override string ToString()
        {
            return GetAsString(C2S.NAME | C2S.CSS_SYNTAX);
        }
        #endregion

        #region Database
        /** <summary>Returns ColourDatabase.TheColourDatabase.
         * 
         * The standard database contains at least the following colours:
         * AQUAMARINE, BLACK, BLUE, BLUE VIOLET, BROWN, CADET BLUE, CORAL, CORNFLOWER BLUE, CYAN, DARK GREY,
         * DARK GREEN, DARK OLIVE GREEN, DARK ORCHID, DARK SLATE BLUE, DARK SLATE GREY DARK TURQUOISE,
         * DIM GREY, FIREBRICK, FOREST GREEN, GOLD, GOLDENROD, GREY, GREEN, GREEN YELLOW, INDIAN RED, KHAKI,
         * LIGHT BLUE, LIGHT GREY, LIGHT STEEL BLUE, LIME GREEN, MAGENTA, MAROON, MEDIUM AQUAMARINE, MEDIUM BLUE,
         * MEDIUM FOREST GREEN, MEDIUM GOLDENROD, MEDIUM ORCHID, MEDIUM SEA GREEN, MEDIUM SLATE BLUE,
         * MEDIUM SPRING GREEN, MEDIUM TURQUOISE, MEDIUM VIOLET RED, MIDNIGHT BLUE, NAVY, ORANGE, ORANGE RED,
         * ORCHID, PALE GREEN, PINK, PLUM, PURPLE, RED, SALMON, SEA GREEN, SIENNA, SKY BLUE, SLATE BLUE,
         * SPRING GREEN, STEEL BLUE, TAN, THISTLE, TURQUOISE, VIOLET, VIOLET RED, WHEAT, WHITE, YELLOW,
         * YELLOW GREEN.</summary>*/
        public static ColourDatabase TheColourDatabase
        {
            get { return ColourDatabase.TheColourDatabase; }
        }
        #endregion

        #region ICanBeMadeReadonly Member

        public bool IsReadonly
        {
            get { return this._isReadonly; }
        }

        public object MakeReadOnly()
        {
            this._isReadonly=true;
            return this;
        }

        #endregion
    }
}
