/**
* wx.NET - ReflectConfig.cs
* \file
* 
* Some static methods to check compatibility of defines and availability of
* conditional code.
*
* (C) 2007 Harald Meyer auf'm Hofe
* Licensed under the wxWidgets license, see LICENSE.txt for details.
*
* $Id: ReflectConfig.cs,v 1.14 2010/05/08 19:54:35 harald_meyer Exp $
*/

using System;
using System.Text;
using System.Runtime.InteropServices;
using System.Reflection;

/** \page page_ReflectConfig Runtime queries on the available configuration.
 * \c wx.NET as well as the underlying \e wxWidgets library are highly configurable.
 * The current configuration of the \e wxWidgets is specified by the used \c config.XX
 * file in the \c build subdirectory. Additionally, \c wx.NET uses some defines to turn
 * off certain wrappers. Usually, these defines have to be compatible  with the configuration
 * of the used compilation of the \e wxWidgets library.
 * 
 * Class ReflectConfig provides some static methods for queries on the defines that have
 * been used on compilation. These methods may be of some use in systems that load and unload
 * assemblies dynamically. Additionally, this class provides method ReflectConfig.CheckCompatibility() to test
 * whether \c wx.NET and \c wx-c.dll are compatible or not. An instance of this class is
 * also added as an attribute of the assembly. so, users of \c wx.NET may analyse the 
 * assembly before use.
 * 
 * Please note, that preprocessor symbols as defined for \c wx.NET have to fit those in \e wxWidgets.
 * For instance, \c wxUSE_TAB_DIALOG shall rarely be used in \c wx.NET since this is an unrecommended
 * setting in \e wxWidgets.
 * */

namespace wx
{
    /** <summary>Class providing some methods to check availability of conditional code and compatiblity of <c>wx.NET.dll</c> and <c>wx-c.dll</c>.
     * 
     * This class provides some static methods but is also an attribute of the assembly.
     * So, laoders of this assembly may analyse this before use.
     * </summary>
     */
    [AttributeUsage(AttributeTargets.Assembly)]
    public class ReflectConfig : Attribute
    {
        #region CAPI
        [DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)]
        static extern bool ReflectConfig_CheckWxMSW();
        #if wxUSE_TAB_DIALOG
        [DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)]static extern bool ReflectConfig_CheckUseTabDialog();
        #endif
        [DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)]
        static extern bool ReflectConfig_CheckUseUnicode();
        [DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)]
        static extern bool ReflectConfig_CheckWxMAC();
        [DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)] static extern bool ReflectConfig_CheckWxGTK();
        
        //[DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)] static extern bool ReflectConfig_CheckWxWinCompatibility26();
        //[DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)] static extern bool ReflectConfig_CheckWxWinCompatibility24();
        [DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)] static extern bool ReflectConfig_CheckWxWinVersion28();
        #endregion
        //---------------------------------------------------------------------

        #region CTor
        /** <summary>This generates an attribute where the provided text is followed by a description of the conditional compilation.
         *</summary>*/
        public ReflectConfig()
        {
        }
        #endregion

        #region Public Properties
        /** \name These are the properties that one can read from the attribute.
         * Instances of this class provide possibles attributes of this assembly.
         * These properties define the information rovided by this attribute.
         * Additionally, we have a ToString() method here that returns the
         * ConfigurationString().
         */
        //@{
        //! Returns CheckWxWinVersion28().
        public bool Version28 { get { return CheckWxWinVersion28(); } }
        //! Returns CheckWxGTK().
        public bool WxGTK { get { return CheckWxGTK(); } }
        //! Returns CheckWxMSW().
        public bool WxMSW { get { return CheckWxMSW(); } }
        //! Returns CheckWxMAC().
        public bool WxMAC { get { return CheckWxMAC(); } }
        //! Returns CheckUseUnicode().
        /*! This is true iff this is linked with a \e wxWidgets library with Unicode support.
        */
        public bool UseUnicode { get { return CheckUseUnicode(); } }
        //! Returns CheckUseTabDialog().
        public bool UseTabCtrl { get { return CheckUseTabDialog(); } }
        //! CheckWxNetDisplay().
        public bool UseDisplay { get { return CheckWxNetDisplay(); } }
        //! CheckStyledTextCtrl().
        public bool UseStyledTextCtrl { get { return CheckStyledTextCtrl(); } }

        public override string ToString()
        {
            return ConfigurationString();
        }
        //@}
        #endregion

        #region Static Public Methods
        /** <summary>These static methods provide the information on the used configuration.
         * These methods return information on the configuration of this assembly
         * concerning conditional code. Several methods here will also query <c>wx-c.dll</c>.
         *</summary>*/
        //@{

        /** <summary>Raises an exception of those features introduced with  wxWidgets 2.8.0 are not available.
         * Cf. CheckWxWinVersion28().</summary>*/
        public static void AssertWxWinVersion28()
        {
            if (!CheckWxWinVersion28())
                throw new SystemException(Window._("wx.NET application demands features of wxWidgets 2.8 but these are not available."));
        }

        /** <summary>Tests whether the features introduced with  wxWidgets 2.8.0 are available.
         *</summary>*/
        public static bool CheckWxWinVersion28()
        {
            return ReflectConfig_CheckWxWinVersion28();
        }

        /** <summary>Test for availability of code particular for <c>__WXGTK__</c>.
         *</summary>
         */
        public static bool CheckWxGTK()
        {
            return ReflectConfig_CheckWxGTK();
        }

        /** <summary>Test for availability of code particular for <c>__WXMSW__</c>.
         *</summary>
         */
        public static bool CheckWxMSW()
        {
            return ReflectConfig_CheckWxMSW();
        }

        /** <summary>Test for availability of code particular for <c>__WXMAC__</c>.
         * This is in fact rather a query whether code shall be avoided that cannot be provided
         * for Apple Macintosh computers.
         *</summary>
         */
        public static bool CheckWxMAC()
        {
            return ReflectConfig_CheckWxMAC();
        }

        /** <summary>Test for availability of <c>WXNET_DISPLAY</c> code.
         *</summary>
         */
        public static bool CheckWxNetDisplay()
        {
#if WXNET_DISPLAY
            return true;
#else
            return false;
#endif
        }

        /** <summary>This tests for the availability of STC ( define <c>WXNET_STYLEDTEXTCTRL</c> ).
         * This shows availability of StyledTextCtrl.
         *</summary>
         */
        public static bool CheckStyledTextCtrl()
        {
#if WXNET_STYLEDTEXTCTRL
            return true;
#else
            return false;
#endif
        }
        
        /** <summary>Checks for the availability of the TabCtrl class.
         * This class is currently only available with CheckWxMSW().
         * </summary>
         */
        public static bool CheckUseTabDialog()
        {
#if wxUSE_TAB_DIALOG
            return ReflectConfig_CheckUseTabDialog();
#else
            return false;
#endif
        }

        /** <summary>Checks for the availability of Unicode support in the linked  wxWidgets library.
         * Currently, native Unicode support in <c>wxString</c> will not be used for conditional
         * compilation but might be interest for if-then conditions in some code.
         * </summary>
         */
        public static bool CheckUseUnicode()
        {
          return ReflectConfig_CheckUseUnicode();
        }

        /** <summary>Runtime-check: Tests whether <c>wx.NET</c> does not require more features than <c>wx-c.dll</c> provides.
         * Please note that unfortunately this cannot be tested for defines of <c>wx.NET</c> that do not have
         * an equivalent in <c>wxWidgets</c>. These defines have the prefix <c>WXNET_</c> .
         * 
         * If this is <c>false</c> then several classes cannot be used since they
         * require functions in the <c>wx-c.dll</c> according to the <c>wx.NET</c> configuration
         * that have not been compiled due to the configuration of the used  wxWidgets
         * system.
         *</summary>
         */
        public static bool CheckCompatibility()
        {
            if (!ReflectConfig_CheckWxWinVersion28()) return false;
            return true;
        }

        /** <summary>This is <c>true</c> iff the  wx.NET is configured for internal use of UTF 8 strings.
         * This option is for instance relevant to the PNET implementation of the .NET framework.
         * </summary>
         */
        public static bool CheckInternalUseUTF8()
        {
#if WXNET_INTERNAL_USE_UTF8
            return true;
#else
            return false;
#endif
        }

        /** <summary>Returns an english string describing the configuration.
         *</summary>*/
        public static string ConfigurationString()
        {
            StringBuilder sb = new StringBuilder();
            if (CheckWxWinVersion28())
                sb.Append("Using version 2.8.X of the wxWidgets library.\n");
            else
                sb.Append("Using version 2.6.X of the wxWidgets library.\n");
            if (CheckWxGTK())
                sb.Append("Compiled for using GTK.\n");
            if (CheckWxMSW())
                sb.Append("Compiled for Windows TM systems.\n");
            if (CheckWxMAC())
                sb.Append("Compiled for using Apple MACs.\n");
            if (CheckUseUnicode())
                sb.Append("Full Unicode support.\n");
            else
                sb.Append("Supporting ANSI characters only.");
            if (CheckInternalUseUTF8())
            {
                sb.Append("Expecting the .NET framework to use UTF 8 internally.");
            }
            if (CheckWxNetDisplay() || CheckStyledTextCtrl() || CheckUseTabDialog())
            {
                sb.Append("Extras: ");
                bool separator = false;
                if (CheckStyledTextCtrl())
                {
                    if (separator) sb.Append(", ");
                    sb.Append("styled text control");
                    separator = true;
                }
                if (CheckWxNetDisplay())
                {
                    if (separator) sb.Append(", ");
                    sb.Append("managament of multiple displays");
                    separator = true;
                }
                if (CheckUseTabDialog())
                {
                    if (separator) sb.Append(", ");
                    sb.Append("tabbed control");
                    separator = true;
                }
            }
            return sb.ToString();
        }
        //@}
        #endregion
    }
}
