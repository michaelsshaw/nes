/**
 * wx.NET Project
 * 
 * \file 
 * 
 * Component model for \e wx-NET.
 * 
 * Written by Harald Meyer auf'm Hofe (C) 2010
 * Licensed under the wxWidgets license, see LICENSE.txt for details.
 *
 * $Id: VisualComps.cs,v 1.1 2010/07/04 19:10:34 harald_meyer Exp $
 */

using System;
using System.Reflection;
using System.Collections.Generic;
using wx;
using wx.Globalization;
using wx.NetMacros;

/** A series of XML-serializable description of wx.NET dialogs.
 * The classes of this namespace form the data model of the wx.NET-dialog builder.
 */
namespace wx.VisualComponent
{
    /// <summary>
    /// Represents a top level window, i.e. Create() will create a wx.Frame or
    /// a wx.Dialog. Instances of this class represent out of the box dialogs or
    /// frames: 
    /// </summary>
    public class TopLevelWindow : Generator
    {
        /// <summary>
        /// Creates an instance representing a wx.Frame created by the default ctor.
        /// </summary>
        public TopLevelWindow() : this(typeof(Frame)) { }

        /// <summary>
        /// Creates an instance of this class providing a type and an array of arguments for a constructor.
        /// </summary>
        /// <param name="type">This �s a factory that will create instances of this type. This must not be an
        /// abstract type.</param>
        /// <param name="ctorArgs">Arguments to the ctor of <c>type</c> that shall be used.</param>
        public TopLevelWindow(Type type, params object[] ctorArgs) : base(type, ctorArgs) { }

        /// <summary>
        /// This will create an instance using the provided method.
        /// If the method descriptor designates a static method, the arguments will be passed to
        /// this method as provided to this ctor. If the method descriptor designated a non-static
        /// method, this method will be called at the first element of the argument list. The rest of
        /// the argument list will be passed as arguments to the called method.
        /// </summary>
        /// <param name="mi">Descriptor of the method that creates the instance.</param>
        /// <param name="methodArgs">Argument list that will be passed to the designated method.</param>
        public TopLevelWindow(MethodInfo mi, params object[] args) : base(mi, args) { }

    }
}
