//-----------------------------------------------------------------------------
// wx.NET - FindReplaceDialog.cs
//
// The wxFindReplaceDialog wrapper class.
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: FindReplaceDialog.cs,v 1.15 2009/10/11 16:23:19 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Drawing;
using System.Runtime.InteropServices;

namespace wx
{
    /** <summary>Flags for wx.FindReplaceData.Flags and wx.FindDialogEvent.Flags.</summary>*/
    [Flags]
    public enum FindReplaceFlags
    {
        /** <summary>Useful for initialization: No flag set.</summary>*/
        NONE =0,
        /** <summary>Flag for the wx.FindReplaceDialog.
         * downward search/replace selected (otherwise - upwards)</summary>*/
        DOWN = 1,
        /** <summary>Flag for the wx.FindReplaceDialog.
         *  whole word search/replace selected</summary>*/
        WHOLEWORD = 2,
        /** <summary>Flag for the wx.FindReplaceDialog.
         * case sensitive search/replace selected (otherwise - case insensitive)</summary>*/
        MATCHCASE = 4,
    }

    /** <summary>wx.FindReplaceDialog is a standard modeless dialog which is used to allow the user to search for some text
     * (and possibly replace it with something else).
     * The actual searching is supposed to be done in the owner window which is the parent of this
     * dialog. Note that it means that unlike for the other standard dialogs this one must have a
     * parent window. Also note that there is no way to use this dialog in a modal way; it is
     * always, by design and implementation, modeless (non-modal).
     * 
     * The dialog issues a FindDialogEvent if a search has been requested.
     * 
     * Currently only one find dialog is supported. So, if you create them on the fly,
     * be sure to place them in <c>using</c> environments to ensure early finalization.</summary>*/
    public class FindReplaceDialog : Dialog
    {
        [DllImport("wx-c")] static extern IntPtr wxFindReplaceDialog_ctor();
        [DllImport("wx-c")] static extern bool   wxFindReplaceDialog_Create(IntPtr self, IntPtr parent, IntPtr data, IntPtr title, uint style);

        [DllImport("wx-c")] static extern IntPtr wxFindReplaceDialog_GetData(IntPtr self);
        [DllImport("wx-c")] static extern void   wxFindReplaceDialog_SetData(IntPtr self, IntPtr data);

        //-----------------------------------------------------------------------------

        public FindReplaceDialog(IntPtr wxObject) 
            : base(wxObject) { }

        static IntPtr LockedCTor()
        {
            lock (DllSync)
            {
                return wxFindReplaceDialog_ctor();
            }
        }

        public FindReplaceDialog()
            : base(LockedCTor()) { }

        public FindReplaceDialog(Window parent, FindReplaceData data, string title)
            : this(parent, data, title, wx.WindowStyles.NO_STYLE) { }

        /** <summary>* Use dialog styles here. Specific styles will start with prefix FR_.</summary>*/
        public FindReplaceDialog(Window parent, FindReplaceData data, string title, wx.WindowStyles style)
            : base(LockedCTor())
        {
            if (!Create(parent, data, title, style))
            {
                throw new InvalidOperationException("Could not create FindReplaceDialog");
            }
        }

        public bool Create(Window parent, FindReplaceData data, string title, wx.WindowStyles style)
        {
            wxString wxTitle = wxString.SafeNew(title);
            return wxFindReplaceDialog_Create(wxObject, Object.SafePtr(parent), Object.SafePtr(data), Object.SafePtr(wxTitle), (uint)style);
        }

        //-----------------------------------------------------------------------------

        /** <summary>Use this to change the data model.
         * This is virtual to enable implementations extending this dialog which have to react
         * on changes in the data model.</summary>*/
        public virtual FindReplaceData Data
        {
            get { return (FindReplaceData)FindObject(wxFindReplaceDialog_GetData(wxObject), typeof(FindReplaceData)); }
            set { wxFindReplaceDialog_SetData(wxObject, Object.SafePtr(value)); } 
        }

        //-----------------------------------------------------------------------------

        /** <summary>The unique listener for the "find" event.</summary>*/
		public event EventListener Find
		{
			add { AddCommandListener(Event.wxEVT_COMMAND_FIND, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

        /** <summary>The unique listener for the "find next" event.</summary>*/
        public event EventListener FindNext
		{
			add { AddCommandListener(Event.wxEVT_COMMAND_FIND_NEXT, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

        /** <summary>The unique listener for the "find/replace" event.</summary>*/
        public event EventListener FindReplace
		{
			add { AddCommandListener(Event.wxEVT_COMMAND_FIND_REPLACE, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

        /** <summary>The unique listener for the "find/replace all" event.</summary>*/
        public event EventListener FindReplaceAll
		{
			add { AddCommandListener(Event.wxEVT_COMMAND_FIND_REPLACE_ALL, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

		public event EventListener FindClose
		{
			add { AddCommandListener(Event.wxEVT_COMMAND_FIND_CLOSE, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}
    }

	//-----------------------------------------------------------------------------

    /** <summary>Event issued by the wx.FindReplaceDialog to start a search process.
     * Use the folloing functions to define event handlers:
     * \li wx.EvtHandler.EVT_FIND() to find a first occurance of the searched string (user pressed RETURN in text field),
     * \li wx.EvtHandler.EVT_FIND_NEXT() to find the next occurance of the searched string (user pressed button),
     * \li wx.EvtHandler.EVT_FIND_REPLACE() to replace strings,
     * \li wx.EvtHandler.EVT_FIND_REPLACE_ALL() to replace all occurances of a string,
     * \li wx.EvtHandler.EVT_FIND_CLOSE() to handle the closing of the dialog.
     * 
     * You may specify the identifier of the find dialog if you use more than one dialog of
     * this type.</summary>*/
    public class FindDialogEvent : CommandEvent
    {
        [DllImport("wx-c")] static extern IntPtr wxFindDialogEvent_ctor(int commandType, int id);

        [DllImport("wx-c")] static extern int    wxFindDialogEvent_GetFlags(IntPtr self);
        [DllImport("wx-c")] static extern void   wxFindDialogEvent_SetFlags(IntPtr self, int flags);

        [DllImport("wx-c")] static extern IntPtr wxFindDialogEvent_GetFindString(IntPtr self);
        [DllImport("wx-c")] static extern void   wxFindDialogEvent_SetFindString(IntPtr self, IntPtr str);

        [DllImport("wx-c")] static extern IntPtr wxFindDialogEvent_GetReplaceString(IntPtr self);
        [DllImport("wx-c")] static extern void   wxFindDialogEvent_SetReplaceString(IntPtr self, IntPtr str);

        [DllImport("wx-c")] static extern IntPtr wxFindDialogEvent_GetDialog(IntPtr self);

        //-----------------------------------------------------------------------------

        public FindDialogEvent(IntPtr wxObject)
            : base(wxObject) { }

        static IntPtr LockedCTor(int commandType, int id)
        {
            lock (DllSync)
            {
                return wxFindDialogEvent_ctor(commandType, id);
            }
        }

        public FindDialogEvent(int commandType, int id)
            : base(LockedCTor(commandType, id)) { }

        //-----------------------------------------------------------------------------

        public FindReplaceFlags Flags
        {
            get { return (FindReplaceFlags)wxFindDialogEvent_GetFlags(wxObject); }
            set { wxFindDialogEvent_SetFlags(wxObject, (int)value); }
        }

        //-----------------------------------------------------------------------------

        public string FindString
        {
            get { return new wxString(wxFindDialogEvent_GetFindString(wxObject), true); }
            set
            {
                wxString wxValue = wxString.SafeNew(value);
                wxFindDialogEvent_SetFindString(wxObject, Object.SafePtr(wxValue));
            }
        }

        //-----------------------------------------------------------------------------

        public string ReplaceString
        {
            get { return new wxString(wxFindDialogEvent_GetReplaceString(wxObject), true); }
            set
            {
                wxString wxValue = wxString.SafeNew(value);
                wxFindDialogEvent_SetReplaceString(wxObject, Object.SafePtr(wxValue));
            }
        }

        //-----------------------------------------------------------------------------

        public FindReplaceDialog Dialog
        {
            get { return (FindReplaceDialog)FindObject(wxFindDialogEvent_GetDialog(wxObject)); }
        }
    }

	//-----------------------------------------------------------------------------

    /** <summary>Data model of the wx.FindReplaceDialog.</summary>*/
    public class FindReplaceData : Object
    {
        [DllImport("wx-c")] static extern IntPtr wxFindReplaceData_ctor(uint flags);

        [DllImport("wx-c")] static extern IntPtr wxFindReplaceData_GetFindString(IntPtr self);
        [DllImport("wx-c")] static extern void   wxFindReplaceData_SetFindString(IntPtr self, IntPtr str);

        [DllImport("wx-c")] static extern int    wxFindReplaceData_GetFlags(IntPtr self);
        [DllImport("wx-c")] static extern void   wxFindReplaceData_SetFlags(IntPtr self, int flags);

        [DllImport("wx-c")] static extern void   wxFindReplaceData_SetReplaceString(IntPtr self, IntPtr str);
        [DllImport("wx-c")] static extern IntPtr wxFindReplaceData_GetReplaceString(IntPtr self);

        //-----------------------------------------------------------------------------

        public FindReplaceData(IntPtr wxObject)
            : base(wxObject)
        {
        }

        public FindReplaceData()
            : this(0)
        {
        }

        static IntPtr LockedCTor(FindReplaceFlags flags)
        {
            lock (DllSync)
            {
                return wxFindReplaceData_ctor((uint)flags);
            }
        }

        public FindReplaceData(FindReplaceFlags flags)
            : base(LockedCTor(flags))
        {
        }

        //-----------------------------------------------------------------------------

        public string FindString
        {
            get { return new wxString(wxFindReplaceData_GetFindString(wxObject), true); }
            set
            {
                wxString wxValue = wxString.SafeNew(value);
                wxFindReplaceData_SetFindString(wxObject, Object.SafePtr(wxValue));
            }
        }

        //-----------------------------------------------------------------------------

        public string ReplaceString
        {
            get { return new wxString(wxFindReplaceData_GetReplaceString(wxObject), true); }
            set
            {
                wxString wxValue = wxString.SafeNew(value);
                wxFindReplaceData_SetReplaceString(wxObject, Object.SafePtr(wxValue));
            }
        }

        //-----------------------------------------------------------------------------

        public FindReplaceFlags Flags
        {
            get { return (FindReplaceFlags) wxFindReplaceData_GetFlags(wxObject); }
            set { wxFindReplaceData_SetFlags(wxObject, (int)value); }
        }
    }
}

