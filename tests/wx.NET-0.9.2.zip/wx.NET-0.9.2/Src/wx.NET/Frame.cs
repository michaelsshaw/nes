//-----------------------------------------------------------------------------
// wx.NET - Frame.cs
//
// The wxFrame wrapper class.
//
// Written by Jason Perkins (jason@379.com), Bryan Bulten (bryan@bulten.ca)
// (C) 2003 by 379, Inc.
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: Frame.cs,v 1.30 2010/01/01 16:50:10 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Drawing;
using System.Runtime.InteropServices;

namespace wx{
    /** <summary> Flags for Frame.ShowFullScreen.
     </summary>*/
    [Flags]
    public enum Fullscreen
    {
        NOMENUBAR   = 0x0001,
        NOTOOLBAR   = 0x0002,
        NOSTATUSBAR = 0x0004,
        NOBORDER    = 0x0008,
        NOCAPTION   = 0x0010,
        ALL         = NOMENUBAR | NOTOOLBAR | NOSTATUSBAR | NOBORDER |NOCAPTION
    }

    /// <summary>
    /// A frame is a window whose size and position can (usually) be changed by the user. It usually has thick borders and a title bar, and can optionally contain a menu bar, toolbar and status bar. A frame can contain any window that is not a frame or dialog.
    ///
    /// A frame that has a status bar and toolbar created via the CreateStatusBar/CreateToolBar functions manages these windows, and adjusts the value returned by GetClientSize to reflect the remaining size available to application windows.
    /// 
    /// Refer to the styles 
    /// WindowStyles.DEFAULT_FRAME_STYLE, WindowStyles.MINIMIZE_BOX, WindowStyles.MAXIMIZE_BOX, WindowStyles.RESIZE_BORDER
    /// WindowStyles.SYSTEM_MENU, WindowStyles.CAPTION, WindowStyles.CLOSE_BOX, WindowStyles.CLIP_CHILDREN ...
    /// </summary>
	public class Frame : Window
	{

        #region C API
        [DllImport("wx-c")] static extern IntPtr wxFrame_ctor();
		[DllImport("wx-c")][return:MarshalAs(UnmanagedType.U1)]
        static extern bool   wxFrame_Create(IntPtr self, IntPtr parent, int id, IntPtr title, int posX, int posY, int width, int height, uint style, IntPtr name);
		[DllImport("wx-c")] static extern IntPtr wxFrame_CreateStatusBar(IntPtr self, int number, uint style, int id, IntPtr name);
		[DllImport("wx-c")] static extern void   wxFrame_SendSizeEvent(IntPtr self);
		[DllImport("wx-c")] static extern void   wxFrame_SetIcon(IntPtr self, IntPtr icon);
        [DllImport("wx-c")]
        static extern IntPtr wxFrame_GetIcon(IntPtr self);
        [DllImport("wx-c")]
        static extern void wxFrame_SetMenuBar(IntPtr self, IntPtr menuBar);
		[DllImport("wx-c")] static extern IntPtr wxFrame_GetMenuBar(IntPtr self);
		[DllImport("wx-c")] static extern void   wxFrame_SetStatusText(IntPtr self, IntPtr text, int number);
        [DllImport("wx-c")] static extern IntPtr wxFrame_CreateToolBar(IntPtr self, uint style, int id, IntPtr name);
		[DllImport("wx-c")] static extern IntPtr wxFrame_GetToolBar(IntPtr self);
		[DllImport("wx-c")] static extern void   wxFrame_SetToolBar(IntPtr self, IntPtr toolbar);

        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxFrame_ShowFullScreen(IntPtr self, bool show, uint style);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxFrame_IsFullScreen(IntPtr self);

		[DllImport("wx-c")] static extern IntPtr wxFrame_GetStatusBar(IntPtr wxObject); 
		[DllImport("wx-c")] static extern void   wxFrame_SetStatusBar(IntPtr wxObject, IntPtr statusbar);

		[DllImport("wx-c")] static extern int    wxFrame_GetStatusBarPane(IntPtr wxObject); 
		[DllImport("wx-c")] static extern void   wxFrame_SetStatusBarPane(IntPtr wxObject, int n); 

		[DllImport("wx-c")] static extern void   wxFrame_SetStatusWidths(IntPtr self, int n, int[] widths);

		[DllImport("wx-c")] static extern void   wxFrame_Iconize(IntPtr wxObject, bool iconize);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxFrame_IsIconized(IntPtr wxObject); 

		[DllImport("wx-c")] static extern void   wxFrame_Maximize(IntPtr wxObject, bool maximize);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxFrame_IsMaximized(IntPtr wxObject); 

		//[DllImport("wx-c")] static extern bool   wxFrame_SetShape(IntPtr self, IntPtr region);
		
		[DllImport("wx-c")] static extern void   wxFrame_GetClientAreaOrigin(IntPtr self, ref Point pt);

        [DllImport("wc-c")]
        static extern void wxTopLevelWindow_SetDefaultItem(IntPtr self, IntPtr window);
        [DllImport("wx-c")]
        static extern IntPtr wxTopLevelWindow_GetDefaultItem(IntPtr self);
        #endregion

        #region CTor
		public Frame(IntPtr wxObject)
			: base(wxObject) { }

        static IntPtr LockedCTor()
        {
            lock (DllSync)
            {
                return wxFrame_ctor();
            }
        }

		public Frame()
			: this(LockedCTor())
        {
        }
			
		public Frame(Window parent, int id, string title)
			: this(parent, id, title, wxDefaultPosition, wxDefaultSize, wx.WindowStyles.FRAME_DEFAULT_STYLE, "frame") { }

		public Frame(Window parent, int id, string title, Point pos)
			: this(parent, id, title, pos, wxDefaultSize, wx.WindowStyles.FRAME_DEFAULT_STYLE, "frame") { }

		public Frame(Window parent, int id, string title, Point pos, Size size)
			: this(parent, id, title, pos, size, wx.WindowStyles.FRAME_DEFAULT_STYLE, "frame") { }

        public Frame(Window parent, int id, string title, Point pos, Size size, wx.WindowStyles style)
			: this(parent, id, title, pos, size, style, "frame") { }

        public Frame(Window parent, int id, string title, Point pos, Size size, wx.WindowStyles style, string name)
			: base(LockedCTor()) 
		{
			if (!Create(parent, id, title, pos, size, style, name))
			{
				throw new InvalidOperationException("Failed to create Frame");
			}
		}
		
		//---------------------------------------------------------------------
		// ctors with self created id
		
		public Frame(Window parent, string title)
			: this(parent, Window.UniqueID, title, wxDefaultPosition, wxDefaultSize, wx.WindowStyles.FRAME_DEFAULT_STYLE, "frame") { }

		public Frame(Window parent, string title, Point pos)
			: this(parent, Window.UniqueID, title, pos, wxDefaultSize, wx.WindowStyles.FRAME_DEFAULT_STYLE, "frame") { }

		public Frame(Window parent, string title, Point pos, Size size)
			: this(parent, Window.UniqueID, title, pos, size, wx.WindowStyles.FRAME_DEFAULT_STYLE, "frame") { }

        public Frame(Window parent, string title, Point pos, Size size, wx.WindowStyles style)
			: this(parent, Window.UniqueID, title, pos, size, style, "frame") { }

        public Frame(Window parent, string title, Point pos, Size size, wx.WindowStyles style, string name)
			: this(parent, Window.UniqueID, title, pos, size, style, name) {}
		
		//---------------------------------------------------------------------

        public bool Create(Window parent, int id, string title, Point pos, Size size, wx.WindowStyles style, string name)
		{
            wxString wxTitle = wxString.SafeNew(title);
            wxString wxName = wxString.SafeNew(name);
			return wxFrame_Create(wxObject, Object.SafePtr(parent), id, Object.SafePtr(wxTitle), pos.X, pos.Y, size.Width, size.Height, (uint)style, Object.SafePtr(wxName));
        }

        //---------------------------------------------------------------------
        
		// Helper constructors

		public Frame(string title)
			: this(null, -1, title) { }
		public Frame(string title, Point pos, Size size)
			: this(null, -1, title, pos, size) { }
        public Frame(string title, Point pos, Size size, wx.WindowStyles style)
			: this(null, -1, title, pos, size, style) { }
        #endregion

        //---------------------------------------------------------------------

        /** <summary> Depending on the value of show parameter the window is either shown full screen or restored to its normal
         * state.
         * <c>style</c> is a bit list containing some or all of the following
         * values, which indicate what elements of the window to hide in
         * full-screen mode:
         * 
         * This function has not been tested with MDI frames.
         * Note that showing a window full screen also actually Show()s if it
         * hadn't been shown yet. </summary>
         */
		public bool ShowFullScreen(bool show, Fullscreen style) 
		{
			return wxFrame_ShowFullScreen(wxObject, show, (uint)style);
		}

        /** <summary>The window is either shown full screen.
         * This function has not been tested with MDI frames.
         * Note that showing a window full screen also actually Show()s if it
         * hadn't been shown yet. </summary>
         */
        public bool ShowFullScreen(bool show) 
		{
			return ShowFullScreen(show, Fullscreen.ALL);
		}

		public bool IsFullScreen
		{
			get { return wxFrame_IsFullScreen(wxObject); }
		}

		//---------------------------------------------------------------------

		public StatusBar CreateStatusBar()
		{ 
			return CreateStatusBar(1, 0, -1, "statusBar"); 
		}
		
		public StatusBar CreateStatusBar(int number)
		{ 
			return CreateStatusBar(number, 0, -1, "statusBar"); 
		}
		
		public StatusBar CreateStatusBar(int number, wx.WindowStyles style)
		{ 
			return CreateStatusBar(number, style, -1, "statusBar"); 
		}
		
		public StatusBar CreateStatusBar(int number, wx.WindowStyles style, int id)
		{ 
			return CreateStatusBar(number, style, id, "statusBar"); 
		}

		public StatusBar CreateStatusBar(int number, wx.WindowStyles style, int id, string name)
		{
            wxString wxname = wxString.SafeNew(name);
			return new StatusBar(wxFrame_CreateStatusBar(wxObject, number, (uint)style, id, Object.SafePtr(wxname)));
		}

		public StatusBar StatusBar
		{
			get { return (StatusBar)FindObject(wxFrame_GetStatusBar(wxObject), typeof(StatusBar)); }
			set { wxFrame_SetStatusBar(wxObject, Object.SafePtr(value)); }
		}

		public int StatusBarPane
		{
			get { return wxFrame_GetStatusBarPane(wxObject); }
			set { wxFrame_SetStatusBarPane(wxObject, value); }
		}

		//---------------------------------------------------------------------

		public void SendSizeEvent()
		{
			wxFrame_SendSizeEvent(wxObject);
		}

		//---------------------------------------------------------------------

        Icon _icon = null;
        /// <summary>
        /// Get or set the icon that will be displayed in the window decorator or when iconifying.
        /// </summary>
		public Icon Icon
		{
			set
            {
                wxFrame_SetIcon(wxObject, Object.SafePtr(value));
                this._icon = value;
            }
            get
            {
                if (this._icon == null)
                    this._icon = new Icon(wxFrame_GetIcon(this.wxObject));
                return this._icon;
            }
		}

		//---------------------------------------------------------------------

        /// <summary>
        /// The menu bar of this instance.
        /// You may get the current instance using this property or set
        /// a new menu bar assigning to this property.
        /// </summary>
		public MenuBar MenuBar
		{
			set { 
				wxFrame_SetMenuBar(wxObject, Object.SafePtr(value)); 
				// add menu events...
				for ( int i = 0; i < MenuBar.MenuCount; ++i )
				{
					Menu menu = value.GetMenu(i);
					menu.ConnectEvents(this);
				}
			}
			get { return (MenuBar)FindObject(wxFrame_GetMenuBar(wxObject), typeof(MenuBar)); }
		}

		//---------------------------------------------------------------------

		public string StatusText
		{
			set { SetStatusText(value); }
		}

		public void SetStatusText(string text) 
		{ SetStatusText(text, 0); }

		public void SetStatusText(string text, int number)
		{
            wxString wxText = wxString.SafeNew(text);
			wxFrame_SetStatusText(wxObject, Object.SafePtr(wxText), number);
		}

		//---------------------------------------------------------------------

		public int[] StatusWidths
		{
			set { SetStatusWidths(value.Length, value); }
		}

		public void SetStatusWidths(int n, int[] widths)
		{
			wxFrame_SetStatusWidths(wxObject, n, widths);
		}

		//---------------------------------------------------------------------

        /// <summary>
        /// Create a toolbar of undefined ID and name (of the toolbar control) "toolBar".
        /// </summary>
        /// <returns>The created toolbar.</returns>
		public ToolBar CreateToolBar()
		{ return CreateToolBar(wx.WindowStyles.BORDER_NONE | wx.WindowStyles.ORIENT_HORIZONTAL, -1, "toolBar"); }

        /// <summary>
        /// Create a toolbar of undefined ID and name (of the toolbar control) "toolBar".. 
        /// </summary>
        /// <param name="style">Window styles to be used. Specific styles have names starting with "TB_".</param>
        /// <returns>The created toolbar.</returns>        
        public ToolBar CreateToolBar(wx.WindowStyles style)
		{ return CreateToolBar(style, -1, "toolBar"); }

        /// <summary>
        /// Create a toolbar with name (of the toolbar control) "toolBar".
        /// </summary>
        /// <param name="style">Window styles to be used. Specific styles have names starting with "TB_".</param>
        /// <param name="id">Window ID of the toolbar.</param>
        /// <returns>The created toolbar.</returns>        
        public ToolBar CreateToolBar(wx.WindowStyles style, int id)
		{ return CreateToolBar(style, id, "toolBar"); }

        /// <summary>
        /// Create a toolbar. 
        /// </summary>
        /// <param name="style">Window styles to be used. Specific styles have names starting with "TB_".</param>
        /// <param name="id">Window ID of the toolbar.</param>
        /// <param name="name">Name of the window.</param>
        /// <returns>The created toolbar.</returns>        
        public ToolBar CreateToolBar(wx.WindowStyles style, int id, string name)
		{
            wxString wxName = wxString.SafeNew(name);
			return new ToolBar(wxFrame_CreateToolBar(wxObject, (uint)style, id, Object.SafePtr(wxName)));
		}

		public ToolBar ToolBar
		{
			get { return (ToolBar)FindObject(wxFrame_GetToolBar(wxObject)); }
			set { wxFrame_SetToolBar(wxObject, Object.SafePtr(value)); }
		}

		//---------------------------------------------------------------------

        /// <summary>
        /// True iff the frame has been iconized. This is false if the frame has been deallocated.
        /// </summary>
		public bool Iconized
		{
			get
            {
                return this.wxObject != IntPtr.Zero && wxFrame_IsIconized(wxObject);
            }
			set { wxFrame_Iconize(wxObject, value); }
		}

		//---------------------------------------------------------------------

        /// <summary>
        /// True iff the frame has been iconized. This is false if the frame has been deallocated.
        /// </summary>
        public bool Maximized
		{
            get { return this.wxObject != IntPtr.Zero && wxFrame_IsMaximized(wxObject); }
			set { wxFrame_Maximize(wxObject, value); }
		}


        //---------------------------------------------------------------------

        /// <summary>
        /// Get or set the default item.
        /// This usually is a button.
        /// </summary>
        public Window DefaultItem
        {
            get
            {
                IntPtr btn = wxTopLevelWindow_GetDefaultItem(wxObject);
                return (Window)Object.FindObject(btn, typeof(wx.Window));
            }
            set
            {
                wxTopLevelWindow_SetDefaultItem(wxObject, value.wxObject);
            }
        }

		//---------------------------------------------------------------------

		/*public bool SetShape(wx.Region region)
		{
			return wxFrame_SetShape(wxObject, Object.SafePtr(region));
		}*/

		//---------------------------------------------------------------------
		
		public override Point ClientAreaOrigin
		{
			get {
				Point pt = new Point();
				wxFrame_GetClientAreaOrigin(wxObject, ref pt);
				return pt;
			}
		}
	}
}
