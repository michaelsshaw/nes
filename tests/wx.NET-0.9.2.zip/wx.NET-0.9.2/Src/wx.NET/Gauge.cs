//-----------------------------------------------------------------------------
// wx.NET - Gauge.cs
//
// The wxGauge wrapper class.
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: Gauge.cs,v 1.15 2010/05/08 19:52:40 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Drawing;
using System.Runtime.InteropServices;

namespace wx
{
	public class Gauge :  Control
	{
		#region C API
		[DllImport("wx-c")] static extern IntPtr wxGauge_ctor();
		[DllImport("wx-c")] static extern void   wxGauge_dtor(IntPtr self);
		[DllImport("wx-c")] static extern bool   wxGauge_Create(IntPtr self, IntPtr parent, int id, int range, int posX, int posY, int width, int height, uint style, IntPtr validator, IntPtr name);
		[DllImport("wx-c")] static extern void   wxGauge_SetRange(IntPtr self, int range);
		[DllImport("wx-c")] static extern int    wxGauge_GetRange(IntPtr self);
		[DllImport("wx-c")] static extern void   wxGauge_SetValue(IntPtr self, int pos);
		[DllImport("wx-c")] static extern int    wxGauge_GetValue(IntPtr self);
		[DllImport("wx-c")] static extern void   wxGauge_SetShadowWidth(IntPtr self, int w);
		[DllImport("wx-c")] static extern int    wxGauge_GetShadowWidth(IntPtr self);
		[DllImport("wx-c")] static extern void   wxGauge_SetBezelFace(IntPtr self, int w);
		[DllImport("wx-c")] static extern int    wxGauge_GetBezelFace(IntPtr self);
		[DllImport("wx-c")] static extern bool   wxGauge_AcceptsFocus(IntPtr self);
		[DllImport("wx-c")] static extern bool   wxGauge_IsVertical(IntPtr self);
		#endregion
		//---------------------------------------------------------------------
		
		#region CTor / DTor
		public Gauge(IntPtr wxObject) 
			: base(wxObject) {}

        static IntPtr LockedCTor()
        {
            lock (DllSync)
            {
                return wxGauge_ctor();
            }
        }

		public Gauge()
			: base(LockedCTor()) { }

		public Gauge(Window parent, int id, int range, Point pos, Size size)
			: this(parent, id, range, pos, size, 0, null) { }

		public Gauge(Window parent, int id, int range, Point pos, Size size, wx.WindowStyles style)
			: this(parent, id, range, pos, size, style, null) { }

		public Gauge(Window parent, int id, int range, Point pos, Size size, wx.WindowStyles style, string name)
			: base(LockedCTor())
		{	
			if (!Create(parent, id, range, pos, size, style, name)) 
			{
				throw new InvalidOperationException("Failed to create Gauge");
			}
		}
		
		//---------------------------------------------------------------------
		// ctors with self created id
		
		public Gauge(Window parent, int range, Point pos, Size size)
			: this(parent, Window.UniqueID, range, pos, size, wx.WindowStyles.NO_STYLE, null) { }

		public Gauge(Window parent, int range, Point pos, Size size, wx.WindowStyles style)
			: this(parent, Window.UniqueID, range, pos, size, style, null) { }

		public Gauge(Window parent, int range, Point pos, Size size, wx.WindowStyles style, string name)
			: this(parent, Window.UniqueID, range, pos, size, style, name) {}
		
		//---------------------------------------------------------------------

		public bool Create(Window parent, int id, int range, Point pos, Size size, wx.WindowStyles style, string name)
		{
            wxString wxname = wxString.SafeNew(name);
			return wxGauge_Create(wxObject, Object.SafePtr(parent), id, range, 
					pos.X, pos.Y, size.Width, size.Height, (uint)style, 
					IntPtr.Zero, Object.SafePtr(wxname));
		}
		
		protected override void CallDTor ()
		{
			wxGauge_dtor(this.wxObject);
		}

		#endregion

		//---------------------------------------------------------------------

		public int Range
		{
			get { return wxGauge_GetRange(wxObject); }
			set { wxGauge_SetRange(wxObject, value); }
		}

		//---------------------------------------------------------------------
        
		public int Value
		{
			get { return wxGauge_GetValue(wxObject); }
			set { wxGauge_SetValue(wxObject, value); }
		}

		//---------------------------------------------------------------------

		public int ShadowWidth
		{
			get { return wxGauge_GetShadowWidth(wxObject); }
			set { wxGauge_SetShadowWidth(wxObject, value); }
		}

		//---------------------------------------------------------------------

		public int BezelFace
		{
			get { return wxGauge_GetBezelFace(wxObject); }
			set { wxGauge_SetBezelFace(wxObject, value); }
		}

		//---------------------------------------------------------------------

		public override bool AcceptsFocus()
		{
			return wxGauge_AcceptsFocus(wxObject);
		}
		
		//---------------------------------------------------------------------
		
		public bool IsVertical
		{
			get { return wxGauge_IsVertical(wxObject); }
		}
	}
}
