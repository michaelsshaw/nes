//-----------------------------------------------------------------------------
// wx.NET - ClientData.cs
//
// The wxClientData wrapper class.
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: ClientData.cs,v 1.16 2009/10/11 16:23:18 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Runtime.InteropServices;

namespace wx
{
    /** <summary>Base class of all classes encapsulating client data.
     * All classes deriving from wx.EvtHandler (such as all controls and App)
     * can hold arbitrary data which is here referred to as "client data". This
     * is useful e.g. for scripting languages which need to handle shadow objects
     * for most of wxWidgets' classes and which store a handle to such a shadow
     * class as client data in that class. This data can either be of type void
     * - in which case the data container does not take care of freeing the data
     * again or it is of type wxClientData or its derivatives. In that case the
     * container (e.g. a control) will free the memory itself later. Note that
     * you must not assign both void data and data derived from the
     * ClientData class to a container.
     *
     * Some controls can hold various items and these controls can additionally
     * hold client data for each item. This is the case for Choice, ComboBox
     * and ListBox. TreeCtrl has a specialized class TreeItemData for each item
     * in the tree.
     * 
     * Refer to SystemObjectClientData for an opportunity to add .NET objects as client
     * as client data.</summary>*/
	public class ClientData : Object
	{
		[DllImport("wx-c")] static extern IntPtr wxClientData_ctor();
		[DllImport("wx-c")] static extern void wxClientData_dtor(IntPtr self);
		[DllImport("wx-c")] static extern void wxClientData_RegisterDisposable(IntPtr self, Virtual_Dispose onDispose);
		
		//---------------------------------------------------------------------
        
		public ClientData(IntPtr wxObject)
			: base(wxObject, StorageMode.RegisteredObject) 
		{ 
			this.wxObject = wxObject;
		}
		
		internal ClientData(IntPtr wxObject, bool memOwn)
            : base(wxObject, StorageMode.RegisteredObject)
		{ 
			this.memOwn = memOwn;
			this.wxObject = wxObject;
		}

        static IntPtr LockedCTor()
        {
            lock (DllSync)
            {
                return wxClientData_ctor();
            }
        }

		public ClientData()
			: this(LockedCTor(), true) 
		{ 
			virtual_Dispose = new Virtual_Dispose(VirtualDispose);
			wxClientData_RegisterDisposable(wxObject, virtual_Dispose);
		}

		//---------------------------------------------------------------------
				
		public override void Dispose()
		{
			if (!disposed)
			{
                if (wxObject != IntPtr.Zero)
				{
					if (memOwn)
					{
                        lock (DllSync)
                        {
                            wxClientData_dtor(wxObject);
                            memOwn = false;
                        }
					}
				}
				RemoveObject(wxObject);
				wxObject = IntPtr.Zero;
                --validInstancesCount;
                disposed = true;
			}
			base.Dispose();
			GC.SuppressFinalize(this);
		}
		
		//---------------------------------------------------------------------
		
		~ClientData() 
		{
			Dispose();
		}
	}

    //---------------------------------------------------------------------

    /** <summary>Generate an instance of this class to use an System.Object as client data of choices etc.
     * This simply generates an instance of ClientData, which holds a new instance of <c>wxClientData</c>.
     * Of course, that <c>wxClientData</c> does not hold any data, but when .NET code refers to client data
     * of a Choice or another control, the selector will use this pointer to a <c>wxClientData</c> to
     * identify this instance via <c>Object.FindObject()</c>.
     *</summary>*/
    public class SystemObjectClientData : ClientData
    {
        object _data;
        public SystemObjectClientData(object data)
            : base()
        {
            this._data=data;
        }

        public object Data { get { return this._data; } }
    }

    //---------------------------------------------------------------------
    
	public class StringClientData : ClientData
	{
		[DllImport("wx-c")] static extern IntPtr wxStringClientData_ctor(IntPtr data);
		[DllImport("wx-c")] static extern void   wxStringClientData_dtor(IntPtr self);
		[DllImport("wx-c")] static extern void   wxStringClientData_SetData(IntPtr self, IntPtr data);
		[DllImport("wx-c")] static extern IntPtr wxStringClientData_GetData(IntPtr self);
		
		//---------------------------------------------------------------------
        
		public StringClientData()
			: this(new wxString("")) { }
			
		public StringClientData(string data)
            : this(new wxString(data))
        {
        }

        static IntPtr LockedCPtr(wxString data)
        {
            lock (DllSync)
            {
                return wxStringClientData_ctor(data.wxObject);
            }
        }

        public StringClientData(wxString data)
			: this(LockedCPtr(data), true) { }
			
		public StringClientData(IntPtr wxObject)
			: base(wxObject) 
		{ 
			this.wxObject = wxObject;
		}
			
		internal StringClientData(IntPtr wxObject, bool memOwn)
			: base(wxObject)
		{ 
			this.memOwn = memOwn;
			this.wxObject = wxObject;
		}
		
		//---------------------------------------------------------------------
				
		public override void Dispose()
		{
			if (!disposed)
			{
                if (wxObject != IntPtr.Zero)
				{
					if (memOwn)
					{
                        lock (DllSync)
                        {
                            wxStringClientData_dtor(wxObject);
                            memOwn = false;
                        }
					}
				}
				RemoveObject(wxObject);
				wxObject = IntPtr.Zero;
                --validInstancesCount;
                disposed = true;
			}
			
			base.Dispose();
			GC.SuppressFinalize(this);
		}
		
		//---------------------------------------------------------------------
		
		~StringClientData() 
		{
			Dispose();
		}

		//---------------------------------------------------------------------
		
		public string Data
		{
			get { return new wxString(wxStringClientData_GetData(wxObject), true); }
			set
            {
                wxString wxValue=new wxString(value);
                wxStringClientData_SetData(this.wxObject, wxValue.wxObject);
            }
		}
	}
}

