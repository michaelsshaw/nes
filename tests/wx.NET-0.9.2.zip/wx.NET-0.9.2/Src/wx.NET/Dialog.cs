//-----------------------------------------------------------------------------
// wx.NET - Dialog.cs
//
// The wxDialog wrapper class.
//
// Written by Jason Perkins (jason@379.com)
// (C) 2003 by 379, Inc.
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: Dialog.cs,v 1.29 2010/05/08 19:52:40 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Drawing;
using System.Runtime.InteropServices;

namespace wx
{
    /// <summary>
    /// A dialog box is a window with a title bar and sometimes a system menu, which can be moved around the screen. It can
    /// contain controls and other windows and is often used to allow the user to make some choice or to answer a question.
    /// 
    /// Dialog Buttons:
    /// 
    /// The dialog usually contains either a single button allowing to close the dialog or two buttons, one accepting the
    /// changes and the other one discarding them (such button, if present, is automatically activated if the user presses
    /// the "Esc" key). By default, buttons with the standard MenuIDs.wxID_OK and MenuIDs.wxID_CANCEL identifiers behave as expected.
    /// Starting with wxWidgets 2.7 it is also possible to use a button with a different identifier instead, see
    /// SetAffirmativeId() and SetEscapeId().
    /// 
    /// Also notice that the CreateButtonSizer() should be used to create the buttons appropriate for the current platform
    /// and positioned correctly (including their order which is platform-dependent).
    /// </summary>
	public class Dialog : Window
	{
        /** <summary>This is for CreateButtonSizer.
         * </summary>
         */
        [Flags]
        public enum ButtonFlags
        {
            /** <summary>Show an YES button.
             * This shall be used together either with NO or CANCEL.
             * There is a wxWidgets assertion.
             * </summary>*/
            YES = 0x00000002,
            /** <summary>Show an OK button.</summary>*/
            OK = 0x00000004,
            /** <summary>Show an NO button.
             * This shall be used together either with DIALOG_YES.
             * There is a wxWidgets assertion.
             * </summary>*/
            NO = 0x00000008,
            /** <summary>Show an CANCEL button.</summary>*/
            CANCEL = 0x00000010,
            /** <summary>Show YES and NO button.</summary>*/
            YES_NO = (YES | NO),
            /** <summary>Used with <c>NO</c>, makes NO button the default.</summary>*/
            NO_DEFAULT = 0x00000080,

            FORWARD = 0x00001000,
            BACKWARD = 0x00002000,
            RESET = 0x00004000,
            HELP = 0x00008000,
            MORE = 0x00010000,
            SETUP = 0x00020000,
        }
        //---------------------------------------------------------------------

        #region C API
        [DllImport("wx-c")] static extern IntPtr wxDialog_ctor();
		[DllImport("wx-c")] static extern void   wxDialog_dtor(IntPtr self);

        [DllImport("wx-c")]
        static extern IntPtr wxDialog_CreateButtonSizer(IntPtr self, uint flags);
        [DllImport("wx-c")]
        static extern IntPtr wxDialog_CreateSeparatedButtonSizer(IntPtr self, uint flags);
        [DllImport("wx-c")]
        static extern IntPtr wxDialog_CreateStdDialogButtonSizer(IntPtr self, uint flags);

		[DllImport("wx-c")] static extern void   wxDialog_SetReturnCode(IntPtr self, int returnCode);
		[DllImport("wx-c")] static extern int    wxDialog_GetReturnCode(IntPtr self);

		[DllImport("wx-c")] static extern IntPtr wxDialog_GetTitle(IntPtr self);
		[DllImport("wx-c")] static extern void   wxDialog_SetTitle(IntPtr self, IntPtr title);

		[DllImport("wx-c")] static extern bool   wxDialog_Create(IntPtr self, IntPtr parent, int id, IntPtr title, int posX, int posY, int width, int height, uint style, IntPtr name);

		[DllImport("wx-c")] static extern void   wxDialog_EndModal(IntPtr self, int retCode);

		[DllImport("wx-c")] static extern bool   wxDialog_IsModal(IntPtr self);

		[DllImport("wx-c")] static extern void   wxDialog_SetIcon(IntPtr self, IntPtr icon);
		//[DllImport("wx-c")] static extern void   wxDialog_SetIcons(IntPtr self, IntPtr icons);

		[DllImport("wx-c")] static extern int    wxDialog_ShowModal(IntPtr self);

        delegate void OverloadedAction();
        [DllImport("wx-c")]
        static extern void wxDialog_SetFocus(IntPtr self);
        [DllImport("wx-c")]
        static extern void wxDialog_SetFocusVirtuals(IntPtr self, OverloadedAction cbSetFocus, OverloadedAction cbSetFocusFromKbd);

        [DllImport("wc-c")]
        static extern void wxTopLevelWindow_SetDefaultItem(IntPtr self, IntPtr window);
        [DllImport("wx-c")]
        static extern IntPtr wxTopLevelWindow_GetDefaultItem(IntPtr self);
        #endregion

        #region State
        OverloadedAction _cbSetFocus = null;
        OverloadedAction _cbSetFocusFromKbd = null;
        #endregion

        //---------------------------------------------------------------------
        #region CTor
        public Dialog(IntPtr wxObject) 
			: base(wxObject) {}

        static IntPtr LockedCTor()
        {
            lock (DllSync)
            {
                return wxDialog_ctor();
            }
        }
        
        protected override void CallDTor ()
        {
        	wxDialog_dtor(this.wxObject);
        }


		public Dialog()
			: base(LockedCTor())
        {
            this._cbSetFocus = new OverloadedAction(this.SetFocus);
            this._cbSetFocusFromKbd = new OverloadedAction(this.SetFocusFromKbd);
            wxDialog_SetFocusVirtuals(this.wxObject, this._cbSetFocus, this._cbSetFocusFromKbd);
        }

		public Dialog(Window parent, string title)
            : this(parent, Window.UniqueID, title, wxDefaultPosition, wxDefaultSize, wx.WindowStyles.DIALOG_DEFAULT_STYLE, null) { }

		public Dialog(Window parent, int id, string title)
            : this(parent, id, title, wxDefaultPosition, wxDefaultSize, wx.WindowStyles.DIALOG_DEFAULT_STYLE, null) { }

		public Dialog(Window parent, int id, string title, Point pos)
            : this(parent, id, title, pos, wxDefaultSize, wx.WindowStyles.DIALOG_DEFAULT_STYLE, null) { }

		public Dialog(Window parent, int id, string title, Point pos, Size size)
            : this(parent, id, title, pos, size, wx.WindowStyles.DIALOG_DEFAULT_STYLE, null) { }

		public Dialog(Window parent, int id, string title, Point pos, Size size, wx.WindowStyles style)
			: this(parent, id, title, pos, size, style, null) { }

        public Dialog(Window parent, int id, string title, Point pos, Size size, wx.WindowStyles style, string name)
			: base(LockedCTor())
		{
            this._cbSetFocus = new OverloadedAction(this.SetFocus);
            this._cbSetFocusFromKbd = new OverloadedAction(this.SetFocusFromKbd);
            wxDialog_SetFocusVirtuals(this.wxObject, this._cbSetFocus, this._cbSetFocusFromKbd);

            if (!Create(parent, id, title, pos, size, style, name))
			{
				throw new InvalidOperationException("Failed to create Dialog");
			}
		}
		
		//---------------------------------------------------------------------
		// ctors with self created id
		
		public Dialog(Window parent, string title, Point pos)
            : this(parent, Window.UniqueID, title, pos, wxDefaultSize, wx.WindowStyles.DIALOG_DEFAULT_STYLE, null) { }

		public Dialog(Window parent, string title, Point pos, Size size)
            : this(parent, Window.UniqueID, title, pos, size, wx.WindowStyles.DIALOG_DEFAULT_STYLE, null) { }

        public Dialog(Window parent, string title, Point pos, Size size, wx.WindowStyles style)
			: this(parent, Window.UniqueID, title, pos, size, style, null) { }

        public Dialog(Window parent, string title, Point pos, Size size, wx.WindowStyles style, string name)
			: this(parent, Window.UniqueID, title, pos, size, style, name) {}
		
		//---------------------------------------------------------------------

		public bool Create(Window window, int id, string title, Point pos,
                           Size size, wx.WindowStyles style, string name)
		{
            wxString wxTitle = wxString.SafeNew(title);
            wxString wxName = wxString.SafeNew(name);
			return wxDialog_Create(wxObject, Object.SafePtr(window), id, Object.SafePtr(wxTitle),
								   pos.X, pos.Y, size.Width, size.Height, (uint)style, Object.SafePtr(wxName));
        }
        #endregion

        #region Button Sizer
        /// <summary>
        /// Creates a sizer with standard buttons. flags is a bit list of the following flags:
        /// ButtonFlags.OK, ButtonFlags.CANCEL, ButtonFlags.YES, ButtonFlags.NO, ButtonFlags.HELP, ButtonFlags.NO_DEFAULT.
        /// 
        /// The sizer lays out the buttons in a manner appropriate to the platform.
        /// 
        /// This function uses CreateStdDialogButtonSizer internally for most platforms but doesn't create the sizer at all for the platforms with hardware buttons (such as smartphones) for which it sets up the hardware buttons appropriately and returns NULL, so don't forget to test that the return value is valid before using it.
        /// </summary>
        /// <param name="flags">The flags defining the buttons to be present.</param>
        /// <returns>A button sizer or <c>null</c> if not supported</returns>
        public Sizer CreateButtonSizer(ButtonFlags flags)
        {
            IntPtr result = wxDialog_CreateButtonSizer(this.wxObject, (uint)flags);
            if (result == IntPtr.Zero)
                return null;
            else
                return new Sizer(result);
        }

        /// <summary>
        /// Creates a sizer with standard buttons using CreateButtonSizer() separated from the rest of the dialog
        /// contents by a horizontal wx.StaticLine.
        ///
        /// Please notice that just like CreateButtonSizer() this function may return <c>null</c> if no buttons were created.
        /// </summary>
        /// <param name="flags">The flags defining the buttons to be present.</param>
        /// <returns>A button sizer or <c>null</c> if not supported</returns>
        public Sizer CreateSeparatedButtonSizer(ButtonFlags flags)
        {
            IntPtr result = wxDialog_CreateSeparatedButtonSizer(this.wxObject, (uint)flags);
            if (result == IntPtr.Zero)
                return null;
            else
                return new Sizer(result);
        }

        /// <summary>
        /// Creates a wxStdDialogButtonSizer with standard buttons. flags is a bit list of the following
        /// flags: ButtonFlags.OK, ButtonFlags.CANCEL, ButtonFlags.YES, ButtonFlags.NO, ButtonFlags.HELP, ButtonFlags.NO_DEFAULT.
        ///
        /// The sizer lays out the buttons in a manner appropriate to the platform.
        /// </summary>
        /// <param name="flags">The flags defining the buttons to be present.</param>
        /// <returns>A button sizer or <c>null</c> if not supported</returns>
        public Sizer CreateStdDialogButtonSizer(ButtonFlags flags)
        {
            IntPtr result = wxDialog_CreateStdDialogButtonSizer(this.wxObject, (uint)flags);
            if (result == IntPtr.Zero)
                return null;
            else
                return new Sizer(result);
        }
        #endregion

        //---------------------------------------------------------------------

        /// <summary>
        /// Use this to get or set the value that will be returned by this dialog if shown modally.
        /// </summary>
		public ShowModalResult ReturnCode
		{
            get { return (ShowModalResult)wxDialog_GetReturnCode(wxObject); }
			set { wxDialog_SetReturnCode(wxObject, (int)value); }
		}

		//---------------------------------------------------------------------

		public override string Title
		{
			get { return new wxString(wxDialog_GetTitle(wxObject), true); }
			set
            {
                wxString wxValue = wxString.SafeNew(value);
                wxDialog_SetTitle(wxObject, Object.SafePtr(wxValue));
            }
		}

		//---------------------------------------------------------------------

		public void EndModal(ShowModalResult retCode)
		{
			wxDialog_EndModal(wxObject, (int)retCode);
		}

		//---------------------------------------------------------------------

		public void SetIcon(Icon icon)
		{
			wxDialog_SetIcon(wxObject, Object.SafePtr(icon));
		}

		/*public void SetIcons(IconBundle icons)
		{
			wxDialog_SetIcons(wxObject, Object.SafePtr(icons);
		}*/

        public override void SetFocusFromKbd()
        {
            wxDialog_SetFocus(wxObject);
        }
        public override void SetFocus()
        {
            wxDialog_SetFocus(wxObject);
        }

		//---------------------------------------------------------------------

        public virtual ShowModalResult ShowModal()
		{
            int result = wxDialog_ShowModal(wxObject);
            if (result == (int)MenuIDs.wxID_OK)
                return ShowModalResult.OK;
            else if (result == (int)MenuIDs.wxID_CANCEL)
                return ShowModalResult.CANCEL;
            else if (result == (int)MenuIDs.wxID_YES)
                return ShowModalResult.YES;
            else if (result == (int)MenuIDs.wxID_NO)
                return ShowModalResult.NO;
			return (ShowModalResult) result;
		}

		//---------------------------------------------------------------------

		public bool Modal
		{
			get { return wxDialog_IsModal(wxObject); }
		}

        //---------------------------------------------------------------------

        /** <summary>Get or set the default item.
         * This usually is a button.</summary>*/
        public Window DefaultItem
        {
            get
            {
                IntPtr btn = wxTopLevelWindow_GetDefaultItem(wxObject);
                return (Window)Object.FindObject(btn, typeof(wx.Window));
            }
            set
            {
                wxTopLevelWindow_SetDefaultItem(wxObject, value.wxObject);
            }
        }
	}
}
