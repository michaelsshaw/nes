//-----------------------------------------------------------------------------
// wx.NET - SplitterWindow.cs
//
// The wxSplitterWindow wrapper class.
//
// Written by Jason Perkins (jason@379.com)
// (C) 2003 by 379, Inc.
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: SplitterWindow.cs,v 1.15 2009/10/11 16:48:42 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Drawing;
using System.Runtime.InteropServices;

namespace wx
{
	public enum SplitMode
	{
		wxSPLIT_HORIZONTAL	= 1,
		wxSPLIT_VERTICAL
	}
	
	//---------------------------------------------------------------------

    /// <summary>
    /// This class manages up to two subwindows.
    /// The current view can be split into two programmatically (perhaps from a menu command), and unsplit either 
    /// programmatically or via the wx.SplitterWindow user interface.
    /// </summary>
    /// <remarks>
    /// The following screenshot shows the appearance of a splitter window with a horizontal split.
    ///
    /// \image html splitter.png
    /// 
    /// The style wx.WindowStyles.SP_3D has been used to show a 3D border and 3D sash.
    /// </remarks>
	public class SplitterWindow : Window
	{
		private delegate void Virtual_OnDoubleClickSash(int x, int y);
		private delegate void Virtual_OnUnsplit(IntPtr removed);
		private delegate bool Virtual_OnSashPositionChange(int newSashPosition);
		
		private Virtual_OnDoubleClickSash virtualOnDoubleClickSash;
		private Virtual_OnUnsplit virtualOnUnsplit;
		private Virtual_OnSashPositionChange virtualOnSashPositionChange;
		
		[DllImport("wx-c")] static extern IntPtr wxSplitWnd_ctor(IntPtr parent, int id, int posX, int posY, int width, int height, uint style, IntPtr name);
		[DllImport("wx-c")] static extern void   wxSplitWnd_RegisterVirtual(IntPtr self, Virtual_OnDoubleClickSash onDoubleClickSash, Virtual_OnUnsplit onUnsplit, Virtual_OnSashPositionChange onSashPositionChange);
		[DllImport("wx-c")] static extern void   wxSplitWnd_OnDoubleClickSash(IntPtr self, int x, int y);
		[DllImport("wx-c")] static extern void   wxSplitWnd_OnUnsplit(IntPtr self, IntPtr removed);
		[DllImport("wx-c")] static extern bool   wxSplitWnd_OnSashPositionChange(IntPtr self, int newSashPosition);
		[DllImport("wx-c")] static extern int    wxSplitWnd_GetSplitMode(IntPtr self);
		[DllImport("wx-c")] static extern bool   wxSplitWnd_IsSplit(IntPtr self);
		[DllImport("wx-c")] static extern bool   wxSplitWnd_SplitHorizontally(IntPtr self, IntPtr wnd1, IntPtr wnd2, int sashPos);
		[DllImport("wx-c")] static extern bool   wxSplitWnd_SplitVertically(IntPtr self, IntPtr wnd1, IntPtr wnd2, int sashPos);
		[DllImport("wx-c")] static extern bool   wxSplitWnd_Unsplit(IntPtr self, IntPtr toRemove);
		[DllImport("wx-c")] static extern void   wxSplitWnd_SetSashPosition(IntPtr self, int position, bool redraw);
		[DllImport("wx-c")] static extern int    wxSplitWnd_GetSashPosition(IntPtr self);
		
		[DllImport("wx-c")] static extern int    wxSplitWnd_GetMinimumPaneSize(IntPtr self);
		[DllImport("wx-c")] static extern IntPtr wxSplitWnd_GetWindow1(IntPtr self);
		[DllImport("wx-c")] static extern IntPtr wxSplitWnd_GetWindow2(IntPtr self);
		[DllImport("wx-c")] static extern void   wxSplitWnd_Initialize(IntPtr self, IntPtr window);
		[DllImport("wx-c")] static extern bool   wxSplitWnd_ReplaceWindow(IntPtr self, IntPtr winOld, IntPtr winNew);
		[DllImport("wx-c")] static extern void   wxSplitWnd_SetMinimumPaneSize(IntPtr self, int paneSize);
		[DllImport("wx-c")] static extern void   wxSplitWnd_SetSplitMode(IntPtr self, int mode);
		[DllImport("wx-c")] static extern void   wxSplitWnd_UpdateSize(IntPtr self);

        // Jacek Trublajewicz <gothic@os.pl>
        [DllImport("wx-c")]
        static extern void wxSplitWnd_SetSashGravity(IntPtr self, double gravity);
		[DllImport("wx-c")]
        static extern double  wxSplitWnd_GetSashGravity(IntPtr self);

		//---------------------------------------------------------------------

		public SplitterWindow(Window parent)
			: this(parent, Window.UniqueID, wxDefaultPosition, wxDefaultSize, wx.WindowStyles.SP_3D, null) { }

		public SplitterWindow(Window parent, int id)
			: this(parent, id, wxDefaultPosition, wxDefaultSize, wx.WindowStyles.SP_3D, null) { }

		public SplitterWindow(Window parent, int id, Point pos)
			: this(parent, id, pos, wxDefaultSize, wx.WindowStyles.SP_3D, null) { }

		public SplitterWindow(Window parent, int id, Point pos, Size size)
			: this(parent, id, pos, size, wx.WindowStyles.SP_3D, null) { }

		public SplitterWindow(Window parent, int id, Point pos, Size size, wx.WindowStyles style)
			: this(parent, id, pos, size, style, null) { }

        public SplitterWindow(Window parent, int id, Point pos, Size size, wx.WindowStyles style, string name)
            : this(parent, id, pos, size, style, wxString.SafeNew(name)) { }

        public SplitterWindow(Window parent, int id, Point pos, Size size, wx.WindowStyles style, wxString name)
			: base(wxSplitWnd_ctor(Object.SafePtr(parent), id, pos.X, pos.Y, size.Width, size.Height, (uint)style, Object.SafePtr(name)))
		{ 
			virtualOnDoubleClickSash = new Virtual_OnDoubleClickSash(OnDoubleClickSash);
			virtualOnUnsplit = new Virtual_OnUnsplit(DoOnUnsplit);
			virtualOnSashPositionChange = new Virtual_OnSashPositionChange(OnSashPositionChange);
			
			wxSplitWnd_RegisterVirtual(wxObject, virtualOnDoubleClickSash, virtualOnUnsplit, virtualOnSashPositionChange);
		}
			
		//---------------------------------------------------------------------
		// ctors with self created id
			
		public SplitterWindow(Window parent, Point pos)
			: this(parent, Window.UniqueID, pos, wxDefaultSize, wx.WindowStyles.SP_3D, null) { }

		public SplitterWindow(Window parent, Point pos, Size size)
			: this(parent, Window.UniqueID, pos, size, wx.WindowStyles.SP_3D, null) { }

		public SplitterWindow(Window parent, Point pos, Size size, wx.WindowStyles style)
			: this(parent, Window.UniqueID, pos, size, style, null) { }

		public SplitterWindow(Window parent, Point pos, Size size, wx.WindowStyles style, string name)
			: this(parent, Window.UniqueID, pos, size, style, name) {}

		//---------------------------------------------------------------------
		
		public virtual void OnDoubleClickSash(int x, int y)
		{
			wxSplitWnd_OnDoubleClickSash(wxObject, x, y);
		}
		
		//---------------------------------------------------------------------
		
		private void DoOnUnsplit(IntPtr removed)
		{
			OnUnsplit((Window)FindObject(removed));
		}
		
		public virtual void OnUnsplit(Window removed)
		{
			wxSplitWnd_OnUnsplit(wxObject, Object.SafePtr(removed));
		}
		
		//---------------------------------------------------------------------
		
		public virtual bool OnSashPositionChange(int newSashPosition)
		{
			return wxSplitWnd_OnSashPositionChange(wxObject, newSashPosition);
		}
		
		//---------------------------------------------------------------------

        /// <summary>
        /// True iff the control is currently split.
        /// this shall be tested before using SplitHorizontally() or SplitVertically().
        /// </summary>
		public bool IsSplit
		{
			get { return wxSplitWnd_IsSplit(wxObject); }
		}

		//---------------------------------------------------------------------

        /// <summary>
        /// Initializes the top and bottom panes of the splitter window.
        /// The child windows are shown if they are currently hidden.
        /// 
        /// Initially, the sash divides the control into two halfs.
        /// </summary>
        /// <remarks>This should be called if you wish to initially view two panes.
        /// It can also be called at any subsequent time,
        /// but the application should check that the window is not currently split using IsSplit.
        /// </remarks>
        /// <param name="wnd1">The left pane</param>
        /// <param name="wnd2">The right pane</param>
        /// <returns>true if successful, false otherwise (the window was already split).</returns>
        public bool SplitHorizontally(Window wnd1, Window wnd2)
		{
			return this.SplitHorizontally(wnd1, wnd2, 0);
		}

        /// <summary>
        /// Initializes the top and bottom panes of the splitter window.
        /// The child windows are shown if they are currently hidden.
        /// </summary>
        /// <remarks>This should be called if you wish to initially view two panes.
        /// It can also be called at any subsequent time,
        /// but the application should check that the window is not currently split using IsSplit.
        /// </remarks>
        /// <param name="wnd1">The left pane</param>
        /// <param name="wnd2">The right pane</param>
        /// <param name="sashPos">The initial position of the sash. If this value is positive,
        /// it specifies the size of the top pane. If it is negative, it is absolute value gives the
        /// size of the bottom pane. Finally, specify 0 (default) to choose the default position
        /// (half of the total window width). </param>
        /// <returns>true if successful, false otherwise (the window was already split).</returns>
        public bool SplitHorizontally(Window wnd1, Window wnd2, int sashPos)
		{
			return wxSplitWnd_SplitHorizontally(wxObject, Object.SafePtr(wnd1), Object.SafePtr(wnd2), sashPos);
		}

		//---------------------------------------------------------------------

		public SplitMode SplitMode
		{
			get { return (SplitMode)wxSplitWnd_GetSplitMode(wxObject); }
			set { wxSplitWnd_SetSplitMode(wxObject, (int)value); }
		}

		//---------------------------------------------------------------------

        /// <summary>
        /// Initializes the left and right panes of the splitter window.
        /// The child windows are shown if they are currently hidden.
        /// 
        /// Sash divides the pane initially in the half.
        /// </summary>
        /// <remarks>This should be called if you wish to initially view two panes.
        /// It can also be called at any subsequent time,
        /// but the application should check that the window is not currently split using IsSplit.
        /// </remarks>
        /// <param name="wnd1">The left pane</param>
        /// <param name="wnd2">The right pane</param>
        /// <returns>true if successful, false otherwise (the window was already split).</returns>
        public bool SplitVertically(Window wnd1, Window wnd2)
		{
			return this.SplitVertically(wnd1, wnd2, 0);
		}

        /// <summary>
        /// Initializes the left and right panes of the splitter window.
        /// The child windows are shown if they are currently hidden.
        /// </summary>
        /// <remarks>This should be called if you wish to initially view two panes.
        /// It can also be called at any subsequent time,
        /// but the application should check that the window is not currently split using IsSplit.
        /// </remarks>
        /// <param name="wnd1">The left pane</param>
        /// <param name="wnd2">The right pane</param>
        /// <param name="sashPos">The initial position of the sash. If this value is positive,
        /// it specifies the size of the left pane. If it is negative, it is absolute value gives the
        /// size of the right pane. Finally, specify 0 (default) to choose the default position
        /// (half of the total window width). </param>
        /// <returns>true if successful, false otherwise (the window was already split).</returns>
		public bool SplitVertically(Window wnd1, Window wnd2, int sashPos)
		{
			return wxSplitWnd_SplitVertically(wxObject, Object.SafePtr(wnd1), Object.SafePtr(wnd2), sashPos);
		}

		//---------------------------------------------------------------------


        /// <summary>
        /// Unsplits the window.
        /// This call will not actually delete the pane being removed; it calls OnUnsplit() which can be overridden
        /// for the desired behaviour. By default, the pane being removed is hidden.
        /// 
        /// This will remove the right or bottom pane.
        /// </summary>
        /// <returns>true if successful, false otherwise (the window was not split).</returns>
        public bool Unsplit()
		{
			return this.Unsplit(null);
		}

        /// <summary>
        /// Unsplits the window.
        /// This call will not actually delete the pane being removed; it calls OnUnsplit() which can be overridden
        /// for the desired behaviour. By default, the pane being removed is hidden.
        /// </summary>
        /// <param name="toRemove">The pane to remove, or <c>null</c> to remove the right or bottom pane.</param>
        /// <returns>true if successful, false otherwise (the window was not split).</returns>
		public bool Unsplit(Window toRemove)
		{
			return wxSplitWnd_Unsplit(wxObject, Object.SafePtr(toRemove));
		}

		//---------------------------------------------------------------------

		public int SashPosition
		{
			set { SetSashPosition(value, true); }
			get { return wxSplitWnd_GetSashPosition(wxObject); }
		}

		public void SetSashPosition(int position, bool redraw)
		{
			wxSplitWnd_SetSashPosition(wxObject, position, redraw);
		}
		
		//---------------------------------------------------------------------
		
		public int MinimumPaneSize
		{
			get { return wxSplitWnd_GetMinimumPaneSize(wxObject); }
			set { wxSplitWnd_SetMinimumPaneSize(wxObject, value); }
		}
		
		//---------------------------------------------------------------------
		
		public Window Window1
		{
			get { return (Window)FindObject(wxSplitWnd_GetWindow1(wxObject), typeof(Window)); }
		}
		
		//---------------------------------------------------------------------
		
		public Window Window2
		{
			get { return (Window)FindObject(wxSplitWnd_GetWindow2(wxObject), typeof(Window)); }
		}
		
		//---------------------------------------------------------------------
		
		public void Initialize(Window window)
		{
			wxSplitWnd_Initialize(wxObject, Object.SafePtr(window));
		}
		
		//---------------------------------------------------------------------
		
		public bool ReplaceWindow(Window winOld, Window winNew)
		{
			return wxSplitWnd_ReplaceWindow(wxObject, Object.SafePtr(winOld), Object.SafePtr(winNew));
		}
		
		//---------------------------------------------------------------------
		
		public void UpdateSize()
		{
			wxSplitWnd_UpdateSize(wxObject);
		}


		/* Sets/gets the sash gravity
		 * 
		 * Gravity should be a real value between 0.0 and 1.0.
		 * 
		 * Gravity is real factor which controls position of sash while resizing wxSplitterWindow. 
		 * Gravity tells wxSplitterWindow how much will left/top window grow while resizing.
		 *
		 * Example values: 
		 * \li 0.0 - only the bottom/right window is automatically resized 
		 * \li 0.5 - both windows grow by equal size 
		 * \li 1.0 - only left/top window grows 
		 *
		 * Default value of sash gravity is 0.0. 
		 * That value is compatible with previous (before gravity was introduced) 
		 * behaviour of wxSplitterWindow.
		 */
		public double SashGravity
		{
			set { wxSplitWnd_SetSashGravity(wxObject, value); }
			get { return wxSplitWnd_GetSashGravity(wxObject); }
		}	

	}
}
