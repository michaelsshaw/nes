//-----------------------------------------------------------------------------
// wx.NET - StyledTextCtrl.h
// 
// The wxStyledTextCtrl wrapper class.
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: StyledTextCtrl.cs,v 1.31 2010/06/11 18:47:58 harald_meyer Exp $
//-----------------------------------------------------------------------------

#if WXNET_STYLEDTEXTCTRL

using System;
using System.Drawing;
using System.Runtime.InteropServices;

/** This namespace provides the wrapper of the Scintilla based styled text editor framework.
 * The main class is StyledTextCtrl which provides Scintilla as wx.NET control.
 * 
 * \image html stcsample.PNG
 */
namespace wx.StyledText
{
    /** <summary>Modes for displaying the white space character.</summary>
     */
    public enum WhiteSpaceModes
    {
        INVISIBLE = 0,
        VISIBLEALWAYS = 1,
        VISIBLEAFTERINDENT = 2,
    }

    /** <summary>Enumeration to represent line ending mode.</summary>*/
    public enum EOLModes
    {
        CRLF = 0,
        CR = 1,
        LF = 2,
    }

    /** <summary>Modes to enforce lower or upper case letters.</summary>*/
    [wx.Globalization.EnumValueTranslations(0, "mixed", "de", "gemischt")]
    [wx.Globalization.EnumValueTranslations(1, "upper case letters", "de", "durchg�ngig gro�e Lettern")]
    [wx.Globalization.EnumValueTranslations(2, "lower case letters", "de", "durchg�ngig kleine Lettern")]
    public enum CaseForce
    {
        /** <summary>Display letter in original case.</summary>*/
        MIXED=0,

        /** <summary>Enforce upper case letters.</summary>*/
        UPPER=1,

        /** <summary>Enforce lower case latters.</summary>*/
        LOWER=2,
    }

        /** <summary>Shapes used for outlining column.
         * Refer to MarkerDefine().</summary>*/
    public enum Mark
    {
        CIRCLE = 0,
        ROUNDRECT = 1,
        ARROW = 2,
        SMALLRECT = 3,
        SHORTARROW = 4,
        EMPTY = 5,
        ARROWDOWN = 6,
        MINUS = 7,
        PLUS = 8,
        VLINE = 9,
        LCORNER = 10,
        TCORNER = 11,
        BOXPLUS = 12,
        BOXPLUSCONNECTED = 13,
        BOXMINUS = 14,
        BOXMINUSCONNECTED = 15,
        LCORNERCURVE = 16,
        TCORNERCURVE = 17,
        CIRCLEPLUS = 18,
        CIRCLEPLUSCONNECTED = 19,
        CIRCLEMINUS = 20,
        CIRCLEMINUSCONNECTED = 21,
        /** <summary>Invisible mark that only sets the line background color.</summary>*/
        BACKGROUND = 22,
        DOTDOTDOT = 23,
        ARROWS = 24,
        PIXMAP = 25,
        CHARACTER = 10000,
    }

        /** <summary>Markers used for outlining column (wrt folding).
         * Refer to MarkerDefine().</summary>*/
    public enum MarkNum
    {
        FOLDEREND = 25,
        FOLDEROPENMID = 26,
        FOLDERMIDTAIL = 27,
        FOLDERTAIL = 28,
        FOLDERSUB = 29,

        /** <summary>Designates a region that can be hidden in a folder.</summary>*/
        FOLDER = 30,

        /** <summary></summary>*/
        FOLDEROPEN = 31,
    }

    /** <summary>The displayed symbol when MarginType.Symbol.</summary>*/
    public enum MarginMask : uint
    {
        NONE = 0,
        FOLDERS = 0x0FE000000,
    }

    /** <summary>Type of a margin.
     * Defines whether a margin shall present symbols, line numbers, etc.</summary>*/
    public enum MarginType
    {
        SYMBOL = 0,
        NUMBER = 1,
        BACK = 2,
        FORE = 3,
    }

    /** <summary> For SciLexer.h: specifying lexer implementations.
     * These are the available lexicographic analysis methods as provided by the used Scintilla implementation.</summary> */
    public enum LexerId
    {
        CONTAINER = 0,
        NULL = 1,
        PYTHON = 2,
        CPP = 3,
        HTML = 4,
        XML = 5,
        PERL = 6,
        SQL = 7,
        VB = 8,
        PROPERTIES = 9,
        ERRORLIST = 10,
        MAKEFILE = 11,
        BATCH = 12,
        XCODE = 13,
        LATEX = 14,
        LUA = 15,
        DIFF = 16,
        CONF = 17,
        PASCAL = 18,
        AVE = 19,
        ADA = 20,
        LISP = 21,
        RUBY = 22,
        EIFFEL = 23,
        EIFFELKW = 24,
        TCL = 25,
        NNCRONTAB = 26,
        BULLANT = 27,
        VBSCRIPT = 28,
        ASP = 29,
        PHP = 30,
        BAAN = 31,
        MATLAB = 32,
        SCRIPTOL = 33,
        ASM = 34,
        CPPNOCASE = 35,
        FORTRAN = 36,
        F77 = 37,
        CSS = 38,
        POV = 39,
        LOUT = 40,
        ESCRIPT = 41,
        PS = 42,
        NSIS = 43,
        MMIXAL = 44,
        TEX = 49,

        //! When a lexer specifies its language as SCLEX_AUTOMATIC it receives a
        //! value assigned in sequence from SCLEX_AUTOMATIC+1.
        AUTOMATIC = 1000,

    }

    /** <summary>This is an enumeration of designatros for keyword sets.
     * Keyword sets are parameters to some LexerStates.</summary>*/
    [wx.Globalization.TypeNameTranslations("Keyword Sets", "de", "Schl�sselw�rtergruppen")]
    [wx.Globalization.EnumValueTranslations(0, "Keyword Set 1", "de", "Schl�sselw�rter Gruppe 1")]
    [wx.Globalization.EnumValueTranslations(0, "Keyword Set 2", "de", "Schl�sselw�rter Gruppe 2")]
    [wx.Globalization.EnumValueTranslations(0, "Keyword Set 3", "de", "Schl�sselw�rter Gruppe 3")]
    [wx.Globalization.EnumValueTranslations(0, "Keyword Set 4", "de", "Schl�sselw�rter Gruppe 4")]
    [wx.Globalization.EnumValueTranslations(0, "Keyword Set 5", "de", "Schl�sselw�rter Gruppe 5")]
    [wx.Globalization.EnumValueTranslations(0, "Keyword Set 6", "de", "Schl�sselw�rter Gruppe 6")]
    [wx.Globalization.EnumValueTranslations(0, "Keyword Set 7", "de", "Schl�sselw�rter Gruppe 7")]
    public enum Keywords
    {
        Set1 =0,
        Set2 =1,
        Set3 =2,
        Set4 =3,
        Set5 =4, 
        Set6 =5,
        Set7 =6,
        Set8 =7,

        C_WORD =Set1,
        C_WORD2 =Set2,
        C_COMMENTDOCKEYWORD =Set3,
        PY_WORD =Set1,
        PY_DEFNAME =Set2,
    }

    /** <summary>These are the lexicographic states that will be assigned by the Scintilla lexers (refer to LexerId).
     * Styles in range 32..37 are predefined for parts of the UI and are not used as normal styles.
     * Styles 38 and 39 are for future use. Styles up to 127 may be used.
     * 
     * Some style are defined w.r.t. sets of keywords.</summary>*/
    public enum LexerStates
    {
        /** <summary>First definitley unused style index.</summary>*/
        LAST_PREDEFINED = 39,

        /** <summary> General styles for any lexer.</summary>*/
        DEFAULT = 32,

        /** <summary>General styles for any lexer.</summary>*/
        LINENUMBER = 33,

        /** <summary>General styles for any lexer.</summary>*/
        BRACELIGHT = 34,

        /** <summary>General styles for any lexer.</summary>*/
        BRACEBAD = 35,

        /** <summary>General styles for any lexer.</summary>*/
        CONTROLCHAR = 36,

        /** <summary>General styles for any lexer.</summary>*/
        INDENTGUIDE = 37,

        /** <summary>General styles for any lexer.</summary>*/
        CALLTIP = 38,

        /** <summary>Lexical state for wx.StyledText.LexerId.PYTHON.</summary>*/
        PY_DEFAULT = 0,

        /** <summary>Lexical state for wx.StyledText.LexerId.PYTHON.</summary>*/
        PY_COMMENTLINE = 1,

        /** <summary>Lexical state for wx.StyledText.LexerId.PYTHON.</summary>*/
        PY_NUMBER = 2,

        /** <summary>Lexical state for wx.StyledText.LexerId.PYTHON.</summary>*/
        PY_STRING = 3,

        /** <summary>Lexical state for wx.StyledText.LexerId.PYTHON.</summary>*/
        PY_CHARACTER = 4,

        /** <summary>Lexical state for wx.StyledText.LexerId.PYTHON.
         * 
         * Uses keyword list Keywords.PY_WORD.</summary>*/
        PY_WORD = 5,

        /** <summary>Lexical state for wx.StyledText.LexerId.PYTHON.</summary>*/
        PY_TRIPLE = 6,

        /** <summary>Lexical state for wx.StyledText.LexerId.PYTHON.</summary>*/
        PY_TRIPLEDOUBLE = 7,

        /** <summary>Lexical state for wx.StyledText.LexerId.PYTHON.</summary>*/
        PY_CLASSNAME = 8,

        /** <summary>Lexical state for wx.StyledText.LexerId.PYTHON.
         * 
         * Uses Keywords.PY_DEFNAME.</summary>*/
        PY_DEFNAME = 9,

        /** <summary>Lexical state for wx.StyledText.LexerId.PYTHON.</summary>*/
        PY_OPERATOR = 10,

        /** <summary>Lexical state for wx.StyledText.LexerId.PYTHON.</summary>*/
        PY_IDENTIFIER = 11,
        /** <summary>Lexical state for wx.StyledText.LexerId.PYTHON.</summary>*/
        PY_COMMENTBLOCK = 12,
        /** <summary>Lexical state for wx.StyledText.LexerId.PYTHON.</summary>*/
        PY_STRINGEOL = 13,


        /** <summary>Lexical state for SCLEX_CPP
         * Refer to wx.StyledText.LexerId.CPP and wx.StyledText.LexerId.CPPNOCASE.</summary>*/
        C_DEFAULT = 0,

        /** <summary>Lexical state for SCLEX_CPP
         * Refer to wx.StyledText.LexerId.CPP and wx.StyledText.LexerId.CPPNOCASE.</summary>*/
        C_COMMENT = 1,

        /** <summary>Lexical state for SCLEX_CPP
         * Refer to wx.StyledText.LexerId.CPP and wx.StyledText.LexerId.CPPNOCASE.</summary>*/
        C_COMMENTLINE = 2,

        /** <summary>Lexical state for SCLEX_CPP
         * Refer to wx.StyledText.LexerId.CPP and wx.StyledText.LexerId.CPPNOCASE.</summary>*/
        C_COMMENTDOC = 3,

        /** <summary>Lexical state for SCLEX_CPP
         * Refer to wx.StyledText.LexerId.CPP and wx.StyledText.LexerId.CPPNOCASE.</summary>*/
        C_NUMBER = 4,

        /** <summary>Lexical state for SCLEX_CPP
         * Refer to wx.StyledText.LexerId.CPP and wx.StyledText.LexerId.CPPNOCASE.
         * 
         * Uses Keywords.C_WORD.</summary>*/
        C_WORD = 5,

        /** <summary>Lexical state for SCLEX_CPP
         * Refer to wx.StyledText.LexerId.CPP and wx.StyledText.LexerId.CPPNOCASE.
         *</summary>*/
        C_STRING = 6,

        /** <summary>Lexical state for SCLEX_CPP
         * Refer to wx.StyledText.LexerId.CPP and wx.StyledText.LexerId.CPPNOCASE.</summary>*/
        C_CHARACTER = 7,

        /** <summary>Lexical state for SCLEX_CPP
         * Refer to wx.StyledText.LexerId.CPP and wx.StyledText.LexerId.CPPNOCASE.</summary>*/
        C_UUID = 8,

        /** <summary>Lexical state for SCLEX_CPP
         * Refer to wx.StyledText.LexerId.CPP and wx.StyledText.LexerId.CPPNOCASE.</summary>*/
        C_PREPROCESSOR = 9,

        /** <summary>Lexical state for SCLEX_CPP
         * Refer to wx.StyledText.LexerId.CPP and wx.StyledText.LexerId.CPPNOCASE.</summary>*/
        C_OPERATOR = 10,

        /** <summary>Lexical state for SCLEX_CPP
         * Refer to wx.StyledText.LexerId.CPP and wx.StyledText.LexerId.CPPNOCASE.</summary>*/
        C_IDENTIFIER = 11,

        /** <summary>Lexical state for SCLEX_CPP
         * Refer to wx.StyledText.LexerId.CPP and wx.StyledText.LexerId.CPPNOCASE.</summary>*/
        C_STRINGEOL = 12,

        /** <summary>Lexical state for SCLEX_CPP
         * Refer to wx.StyledText.LexerId.CPP and wx.StyledText.LexerId.CPPNOCASE.</summary>*/
        C_VERBATIM = 13,

        /** <summary>Lexical state for SCLEX_CPP
         * Refer to wx.StyledText.LexerId.CPP and wx.StyledText.LexerId.CPPNOCASE.</summary>*/
        C_REGEX = 14,

        /** <summary>Lexical state for SCLEX_CPP
         * Refer to wx.StyledText.LexerId.CPP and wx.StyledText.LexerId.CPPNOCASE.</summary>*/
        C_COMMENTLINEDOC = 15,

        /** <summary>Lexical state for SCLEX_CPP
         * Refer to wx.StyledText.LexerId.CPP and wx.StyledText.LexerId.CPPNOCASE.
         * 
         * This will use Keywords.C_WORD2.</summary>*/
        C_WORD2 = 16,

        /** <summary>Lexical state for SCLEX_CPP
         * Refer to wx.StyledText.LexerId.CPP and wx.StyledText.LexerId.CPPNOCASE.
         * 
         * This style covers keyword in comments introduced by '\' or '@'. Typically, these
         * are keywords referring to common document extractors like <c>doxygen</c> or <c>javadoc</c>.
         * 
         * This will use Keywords.C_COMMENTDOCKEYWORD.</summary>*/
        C_COMMENTDOCKEYWORD = 17,

        /** <summary>Lexical state for SCLEX_CPP
         * Refer to wx.StyledText.LexerId.CPP and wx.StyledText.LexerId.CPPNOCASE.</summary>*/
        C_COMMENTDOCKEYWORDERROR = 18,

        /** <summary>Lexical state for wx.StyledText.LexerId.XML and wx.StyledText.LexerId.HTML.</summary>*/
        H_DEFAULT = 0,
        /** <summary>Lexical state for wx.StyledText.LexerId.XML and wx.StyledText.LexerId.HTML.</summary>*/
        H_TAG = 1,
        /** <summary>Lexical state for wx.StyledText.LexerId.XML and wx.StyledText.LexerId.HTML.</summary>*/
        H_TAGUNKNOWN = 2,
        /** <summary>Lexical state for wx.StyledText.LexerId.XML and wx.StyledText.LexerId.HTML.</summary>*/
        H_ATTRIBUTE = 3,
        /** <summary>Lexical state for wx.StyledText.LexerId.XML and wx.StyledText.LexerId.HTML.</summary>*/
        H_ATTRIBUTEUNKNOWN = 4,
        /** <summary>Lexical state for wx.StyledText.LexerId.XML and wx.StyledText.LexerId.HTML.</summary>*/
        H_NUMBER = 5,
        /** <summary>Lexical state for wx.StyledText.LexerId.XML and wx.StyledText.LexerId.HTML.</summary>*/
        H_DOUBLESTRING = 6,
        /** <summary>Lexical state for wx.StyledText.LexerId.XML and wx.StyledText.LexerId.HTML.</summary>*/
        H_SINGLESTRING = 7,
        /** <summary>Lexical state for wx.StyledText.LexerId.XML and wx.StyledText.LexerId.HTML.</summary>*/
        H_OTHER = 8,
        /** <summary>Lexical state for wx.StyledText.LexerId.XML and wx.StyledText.LexerId.HTML.</summary>*/
        H_COMMENT = 9,
        /** <summary>Lexical state for wx.StyledText.LexerId.XML and wx.StyledText.LexerId.HTML.</summary>*/
        H_ENTITY = 10,

        /** <summary>Lexical state for wx.StyledText.LexerId.XML.</summary>*/
        H_TAGEND = 11,
        /** <summary>Lexical state for wx.StyledText.LexerId.XML.</summary>*/
        H_XMLSTART = 12,
        /** <summary>Lexical state for wx.StyledText.LexerId.XML.</summary>*/
        H_XMLEND = 13,
        /** <summary>Lexical state for wx.StyledText.LexerId.XML.</summary>*/
        H_SCRIPT = 14,
        /** <summary>Lexical state for wx.StyledText.LexerId.XML.</summary>*/
        H_ASP = 15,
        /** <summary>Lexical state for wx.StyledText.LexerId.XML.</summary>*/
        H_ASPAT = 16,
        /** <summary>Lexical state for wx.StyledText.LexerId.XML.</summary>*/
        H_CDATA = 17,
        /** <summary>Lexical state for wx.StyledText.LexerId.XML.</summary>*/
        H_QUESTION = 18,

        /** <summary>Lexical state for wx.StyledText.LexerId.HTML.</summary>*/
        H_VALUE = 19,

        /** <summary>Lexical state for wx.StyledText.LexerId.XCODE.</summary>*/
        H_XCCOMMENT = 20,

        /** <summary>Lexical state for wx.StyledText.LexerId.SGML.</summary>*/
        H_SGML_DEFAULT = 21,
        /** <summary>Lexical state for wx.StyledText.LexerId.SGML.</summary>*/
        H_SGML_COMMAND = 22,
        /** <summary>Lexical state for wx.StyledText.LexerId.SGML.</summary>*/
        H_SGML_1ST_PARAM = 23,
        /** <summary>Lexical state for wx.StyledText.LexerId.SGML.</summary>*/
        H_SGML_DOUBLESTRING = 24,
        /** <summary>Lexical state for wx.StyledText.LexerId.SGML.</summary>*/
        H_SGML_SIMPLESTRING = 25,
        /** <summary>Lexical state for wx.StyledText.LexerId.SGML.</summary>*/
        H_SGML_ERROR = 26,
        /** <summary>Lexical state for wx.StyledText.LexerId.SGML.</summary>*/
        H_SGML_SPECIAL = 27,
        /** <summary>Lexical state for wx.StyledText.LexerId.SGML.</summary>*/
        H_SGML_ENTITY = 28,
        /** <summary>Lexical state for wx.StyledText.LexerId.SGML.</summary>*/
        H_SGML_COMMENT = 29,
        /** <summary>Lexical state for wx.StyledText.LexerId.SGML.</summary>*/
        H_SGML_1ST_PARAM_COMMENT = 30,
        /** <summary>Lexical state for wx.StyledText.LexerId.SGML.</summary>*/
        H_SGML_BLOCK_DEFAULT = 31,

        /** \name Embedded Javascript */
        //@{
        HJ_START = 40,
        HJ_DEFAULT = 41,
        HJ_COMMENT = 42,
        HJ_COMMENTLINE = 43,
        HJ_COMMENTDOC = 44,
        HJ_NUMBER = 45,
        HJ_WORD = 46,
        HJ_KEYWORD = 47,
        HJ_DOUBLESTRING = 48,
        HJ_SINGLESTRING = 49,
        HJ_SYMBOLS = 50,
        HJ_STRINGEOL = 51,
        HJ_REGEX = 52,
        //@}

        /** <summary>ASP Javascript wx.StyledText.LexerId.ASP</summary>*/
        HJA_START = 55,
        /** <summary>ASP Javascript wx.StyledText.LexerId.ASP</summary>*/
        HJA_DEFAULT = 56,
        /** <summary>ASP Javascript wx.StyledText.LexerId.ASP</summary>*/
        HJA_COMMENT = 57,
        /** <summary>ASP Javascript wx.StyledText.LexerId.ASP</summary>*/
        HJA_COMMENTLINE = 58,
        /** <summary>ASP Javascript wx.StyledText.LexerId.ASP</summary>*/
        HJA_COMMENTDOC = 59,
        /** <summary>ASP Javascript wx.StyledText.LexerId.ASP</summary>*/
        HJA_NUMBER = 60,
        /** <summary>ASP Javascript wx.StyledText.LexerId.ASP</summary>*/
        HJA_WORD = 61,
        /** <summary>ASP Javascript wx.StyledText.LexerId.ASP</summary>*/
        HJA_KEYWORD = 62,
        /** <summary>ASP Javascript wx.StyledText.LexerId.ASP</summary>*/
        HJA_DOUBLESTRING = 63,
        /** <summary>ASP Javascript wx.StyledText.LexerId.ASP</summary>*/
        HJA_SINGLESTRING = 64,
        /** <summary>ASP Javascript wx.StyledText.LexerId.ASP</summary>*/
        HJA_SYMBOLS = 65,
        /** <summary>ASP Javascript wx.StyledText.LexerId.ASP</summary>*/
        HJA_STRINGEOL = 66,
        /** <summary>ASP Javascript wx.StyledText.LexerId.ASP</summary>*/
        HJA_REGEX = 67,

        /** \name Embedded VBScript */
        //@{
        HB_START = 70,
        HB_DEFAULT = 71,
        HB_COMMENTLINE = 72,
        HB_NUMBER = 73,
        HB_WORD = 74,
        HB_STRING = 75,
        HB_IDENTIFIER = 76,
        HB_STRINGEOL = 77,
        //@}

        /** \name ASP VBScript */
        //@{
        HBA_START = 80,
        HBA_DEFAULT = 81,
        HBA_COMMENTLINE = 82,
        HBA_NUMBER = 83,
        HBA_WORD = 84,
        HBA_STRING = 85,
        HBA_IDENTIFIER = 86,
        HBA_STRINGEOL = 87,
        //@}

        /** \name Embedded Python */
        //@{
        HP_START = 90,
        HP_DEFAULT = 91,
        HP_COMMENTLINE = 92,
        HP_NUMBER = 93,
        HP_STRING = 94,
        HP_CHARACTER = 95,
        HP_WORD = 96,
        HP_TRIPLE = 97,
        HP_TRIPLEDOUBLE = 98,
        HP_CLASSNAME = 99,
        HP_DEFNAME = 100,
        HP_OPERATOR = 101,
        HP_IDENTIFIER = 102,
        //@}

        /** \name ASP Python */
        //@{
        HPA_START = 105,
        HPA_DEFAULT = 106,
        HPA_COMMENTLINE = 107,
        HPA_NUMBER = 108,
        HPA_STRING = 109,
        HPA_CHARACTER = 110,
        HPA_WORD = 111,
        HPA_TRIPLE = 112,
        HPA_TRIPLEDOUBLE = 113,
        HPA_CLASSNAME = 114,
        HPA_DEFNAME = 115,
        HPA_OPERATOR = 116,
        HPA_IDENTIFIER = 117,
        //@}

        /** \name PHP */
        //@{
        HPHP_DEFAULT = 118,
        HPHP_HSTRING = 119,
        HPHP_SIMPLESTRING = 120,
        HPHP_WORD = 121,
        HPHP_NUMBER = 122,
        HPHP_VARIABLE = 123,
        HPHP_COMMENT = 124,
        HPHP_COMMENTLINE = 125,
        HPHP_HSTRING_VARIABLE = 126,
        HPHP_OPERATOR = 127,
        //@}

        /** \name Lexical states for SCLEX_PERL */
        //@{
        PL_DEFAULT = 0,
        PL_ERROR = 1,
        PL_COMMENTLINE = 2,
        PL_POD = 3,
        PL_NUMBER = 4,
        PL_WORD = 5,
        PL_STRING = 6,
        PL_CHARACTER = 7,
        PL_PUNCTUATION = 8,
        PL_PREPROCESSOR = 9,
        PL_OPERATOR = 10,
        PL_IDENTIFIER = 11,
        PL_SCALAR = 12,
        PL_ARRAY = 13,
        PL_HASH = 14,
        PL_SYMBOLTABLE = 15,
        PL_REGEX = 17,
        PL_REGSUBST = 18,
        PL_LONGQUOTE = 19,
        PL_BACKTICKS = 20,
        PL_DATASECTION = 21,
        PL_HERE_DELIM = 22,
        PL_HERE_Q = 23,
        PL_HERE_QQ = 24,
        PL_HERE_QX = 25,
        PL_STRING_Q = 26,
        PL_STRING_QQ = 27,
        PL_STRING_QX = 28,
        PL_STRING_QR = 29,
        PL_STRING_QW = 30,
        //@}

        /** \name Lexical states for SCLEX_VB, SCLEX_VBSCRIPT */
        //@{
        B_DEFAULT = 0,
        B_COMMENT = 1,
        B_NUMBER = 2,
        B_KEYWORD = 3,
        B_STRING = 4,
        B_PREPROCESSOR = 5,
        B_OPERATOR = 6,
        B_IDENTIFIER = 7,
        B_DATE = 8,
        //@}

        /** \name Lexical states for SCLEX_PROPERTIES */
        //@{
        PROPS_DEFAULT = 0,
        PROPS_COMMENT = 1,
        PROPS_SECTION = 2,
        PROPS_ASSIGNMENT = 3,
        PROPS_DEFVAL = 4,
        //@}

        /** \name Lexical states for SCLEX_LATEX */
        //@{
        L_DEFAULT = 0,
        L_COMMAND = 1,
        L_TAG = 2,
        L_MATH = 3,
        L_COMMENT = 4,
        //@}

        /** \name Lexical states for SCLEX_LUA */
        //@{
        LUA_DEFAULT = 0,
        LUA_COMMENT = 1,
        LUA_COMMENTLINE = 2,
        LUA_COMMENTDOC = 3,
        LUA_NUMBER = 4,
        LUA_WORD = 5,
        LUA_STRING = 6,
        LUA_CHARACTER = 7,
        LUA_LITERALSTRING = 8,
        LUA_PREPROCESSOR = 9,
        LUA_OPERATOR = 10,
        LUA_IDENTIFIER = 11,
        LUA_STRINGEOL = 12,
        LUA_WORD2 = 13,
        LUA_WORD3 = 14,
        LUA_WORD4 = 15,
        LUA_WORD5 = 16,
        LUA_WORD6 = 17,
        //@}

        /** \name Lexical states for SCLEX_ERRORLIST */
        //@{
        ERR_DEFAULT = 0,
        ERR_PYTHON = 1,
        ERR_GCC = 2,
        ERR_MS = 3,
        ERR_CMD = 4,
        ERR_BORLAND = 5,
        ERR_PERL = 6,
        ERR_NET = 7,
        ERR_LUA = 8,
        ERR_CTAG = 9,
        ERR_DIFF_CHANGED = 10,
        ERR_DIFF_ADDITION = 11,
        ERR_DIFF_DELETION = 12,
        ERR_DIFF_MESSAGE = 13,
        ERR_PHP = 14,
        ERR_ELF = 15,
        ERR_IFC = 16,
        //@}

        /** \name Lexical states for SCLEX_BATCH */
        //@{
        BAT_DEFAULT = 0,
        BAT_COMMENT = 1,
        BAT_WORD = 2,
        BAT_LABEL = 3,
        BAT_HIDE = 4,
        BAT_COMMAND = 5,
        BAT_IDENTIFIER = 6,
        BAT_OPERATOR = 7,
        //@}

        /** \name Lexical states for SCLEX_MAKEFILE */
        //@{
        MAKE_DEFAULT = 0,
        MAKE_COMMENT = 1,
        MAKE_PREPROCESSOR = 2,
        MAKE_IDENTIFIER = 3,
        MAKE_OPERATOR = 4,
        MAKE_TARGET = 5,
        MAKE_IDEOL = 9,
        //@}

        /** \name Lexical states for SCLEX_DIFF */
        //@{
        DIFF_DEFAULT = 0,
        DIFF_COMMENT = 1,
        DIFF_COMMAND = 2,
        DIFF_HEADER = 3,
        DIFF_POSITION = 4,
        DIFF_DELETED = 5,
        DIFF_ADDED = 6,
        //@}

        /** \name Lexical states for SCLEX_CONF (Apache Configuration Files Lexer) */
        //@{
        CONF_DEFAULT = 0,
        CONF_COMMENT = 1,
        CONF_NUMBER = 2,
        CONF_IDENTIFIER = 3,
        CONF_EXTENSION = 4,
        CONF_PARAMETER = 5,
        CONF_STRING = 6,
        CONF_OPERATOR = 7,
        CONF_IP = 8,
        CONF_DIRECTIVE = 9,
        //@}

        /** \name Lexical states for SCLEX_AVE, Avenue */
        //@{
        AVE_DEFAULT = 0,
        AVE_COMMENT = 1,
        AVE_NUMBER = 2,
        AVE_WORD = 3,
        AVE_STRING = 6,
        AVE_ENUM = 7,
        AVE_STRINGEOL = 8,
        AVE_IDENTIFIER = 9,
        AVE_OPERATOR = 10,
        AVE_WORD1 = 11,
        AVE_WORD2 = 12,
        AVE_WORD3 = 13,
        AVE_WORD4 = 14,
        AVE_WORD5 = 15,
        AVE_WORD6 = 16,
        //@}

        /** <summary>Lexical states for SCLEX_ADA
         * Refer to wx.StyledText.LexerId.ADA.</summary>*/
        ADA_DEFAULT = 0,
        /** <summary>Lexical states for SCLEX_ADA
         * Refer to wx.StyledText.LexerId.ADA.</summary>*/
        ADA_WORD = 1,
        /** <summary>Lexical states for SCLEX_ADA
         * Refer to wx.StyledText.LexerId.ADA.</summary>*/
        ADA_IDENTIFIER = 2,
        /** <summary>Lexical states for SCLEX_ADA
         * Refer to wx.StyledText.LexerId.ADA.</summary>*/
        ADA_NUMBER = 3,
        /** <summary>Lexical states for SCLEX_ADA
         * Refer to wx.StyledText.LexerId.ADA.</summary>*/
        ADA_DELIMITER = 4,
        /** <summary>Lexical states for SCLEX_ADA
         * Refer to wx.StyledText.LexerId.ADA.</summary>*/
        ADA_CHARACTER = 5,
        /** <summary>Lexical states for SCLEX_ADA
         * Refer to wx.StyledText.LexerId.ADA.</summary>*/
        ADA_CHARACTEREOL = 6,
        /** <summary>Lexical states for SCLEX_ADA
         * Refer to wx.StyledText.LexerId.ADA.</summary>*/
        ADA_STRING = 7,
        /** <summary>Lexical states for SCLEX_ADA
         * Refer to wx.StyledText.LexerId.ADA.</summary>*/
        ADA_STRINGEOL = 8,
        /** <summary>Lexical states for SCLEX_ADA
         * Refer to wx.StyledText.LexerId.ADA.</summary>*/
        ADA_LABEL = 9,
        /** <summary>Lexical states for SCLEX_ADA
         * Refer to wx.StyledText.LexerId.ADA.</summary>*/
        ADA_COMMENTLINE = 10,
        /** <summary>Lexical states for SCLEX_ADA
         * Refer to LexerId.ADA.</summary>*/
        ADA_ILLEGAL = 11,

        /** \name Lexical states for SCLEX_BAAN */
        //@{
        BAAN_DEFAULT = 0,
        BAAN_COMMENT = 1,
        BAAN_COMMENTDOC = 2,
        BAAN_NUMBER = 3,
        BAAN_WORD = 4,
        BAAN_STRING = 5,
        BAAN_PREPROCESSOR = 6,
        BAAN_OPERATOR = 7,
        BAAN_IDENTIFIER = 8,
        BAAN_STRINGEOL = 9,
        BAAN_WORD2 = 10,
        //@}

        /** \name Lexical states for SCLEX_LISP */
        //@{
        LISP_DEFAULT = 0,
        LISP_COMMENT = 1,
        LISP_NUMBER = 2,
        LISP_KEYWORD = 3,
        LISP_STRING = 6,
        LISP_STRINGEOL = 8,
        LISP_IDENTIFIER = 9,
        LISP_OPERATOR = 10,
        //@}

        /** \name Lexical states for SCLEX_EIFFEL and SCLEX_EIFFELKW */
        //@{
        EIFFEL_DEFAULT = 0,
        EIFFEL_COMMENTLINE = 1,
        EIFFEL_NUMBER = 2,
        EIFFEL_WORD = 3,
        EIFFEL_STRING = 4,
        EIFFEL_CHARACTER = 5,
        EIFFEL_OPERATOR = 6,
        EIFFEL_IDENTIFIER = 7,
        EIFFEL_STRINGEOL = 8,
        //@}

        /** \name Lexical states for SCLEX_NNCRONTAB (nnCron crontab Lexer) */
        //@{
        NNCRONTAB_DEFAULT = 0,
        NNCRONTAB_COMMENT = 1,
        NNCRONTAB_TASK = 2,
        NNCRONTAB_SECTION = 3,
        NNCRONTAB_KEYWORD = 4,
        NNCRONTAB_MODIFIER = 5,
        NNCRONTAB_ASTERISK = 6,
        NNCRONTAB_NUMBER = 7,
        NNCRONTAB_STRING = 8,
        NNCRONTAB_ENVIRONMENT = 9,
        NNCRONTAB_IDENTIFIER = 10,
        //@}

        /** \name Lexical states for SCLEX_MATLAB */
        //@{
        MATLAB_DEFAULT = 0,
        MATLAB_COMMENT = 1,
        MATLAB_COMMAND = 2,
        MATLAB_NUMBER = 3,
        MATLAB_KEYWORD = 4,
        MATLAB_STRING = 5,
        MATLAB_OPERATOR = 6,
        MATLAB_IDENTIFIER = 7,
        //@}

        /** \name  Lexical states for SCLEX_SCRIPTOL */
        //@{
        SCRIPTOL_DEFAULT = 0,
        SCRIPTOL_COMMENT = 1,
        SCRIPTOL_COMMENTLINE = 2,
        SCRIPTOL_COMMENTDOC = 3,
        SCRIPTOL_NUMBER = 4,
        SCRIPTOL_WORD = 5,
        SCRIPTOL_STRING = 6,
        SCRIPTOL_CHARACTER = 7,
        SCRIPTOL_UUID = 8,
        SCRIPTOL_PREPROCESSOR = 9,
        SCRIPTOL_OPERATOR = 10,
        SCRIPTOL_IDENTIFIER = 11,
        SCRIPTOL_STRINGEOL = 12,
        SCRIPTOL_VERBATIM = 13,
        SCRIPTOL_REGEX = 14,
        SCRIPTOL_COMMENTLINEDOC = 15,
        SCRIPTOL_WORD2 = 16,
        SCRIPTOL_COMMENTDOCKEYWORD = 17,
        SCRIPTOL_COMMENTDOCKEYWORDERROR = 18,
        SCRIPTOL_COMMENTBASIC = 19,
        //@}

        /** \name Lexical states for SCLEX_ASM */
        //@{
        ASM_DEFAULT = 0,
        ASM_COMMENT = 1,
        ASM_NUMBER = 2,
        ASM_STRING = 3,
        ASM_OPERATOR = 4,
        ASM_IDENTIFIER = 5,
        ASM_CPUINSTRUCTION = 6,
        ASM_MATHINSTRUCTION = 7,
        ASM_REGISTER = 8,
        ASM_DIRECTIVE = 9,
        ASM_DIRECTIVEOPERAND = 10,
        //@}

        /** \name Lexical states for SCLEX_FORTRAN */
        //@{
        F_DEFAULT = 0,
        F_COMMENT = 1,
        F_NUMBER = 2,
        F_STRING1 = 3,
        F_STRING2 = 4,
        F_STRINGEOL = 5,
        F_OPERATOR = 6,
        F_IDENTIFIER = 7,
        F_WORD = 8,
        F_WORD2 = 9,
        F_WORD3 = 10,
        F_PREPROCESSOR = 11,
        F_OPERATOR2 = 12,
        F_LABEL = 13,
        F_CONTINUATION = 14,
        //@}

        /** \name Lexical states for SCLEX_CSS */
        //@{
        CSS_DEFAULT = 0,
        CSS_TAG = 1,
        CSS_CLASS = 2,
        CSS_PSEUDOCLASS = 3,
        CSS_UNKNOWN_PSEUDOCLASS = 4,
        CSS_OPERATOR = 5,
        CSS_IDENTIFIER = 6,
        CSS_UNKNOWN_IDENTIFIER = 7,
        CSS_VALUE = 8,
        CSS_COMMENT = 9,
        CSS_ID = 10,
        CSS_IMPORTANT = 11,
        CSS_DIRECTIVE = 12,
        CSS_DOUBLESTRING = 13,
        CSS_SINGLESTRING = 14,
        //@}

        /** \name Lexical states for SCLEX_POV */
        //@{
        POV_DEFAULT = 0,
        POV_COMMENT = 1,
        POV_COMMENTLINE = 2,
        POV_COMMENTDOC = 3,
        POV_NUMBER = 4,
        POV_WORD = 5,
        POV_STRING = 6,
        POV_OPERATOR = 7,
        POV_IDENTIFIER = 8,
        POV_BRACE = 9,
        POV_WORD2 = 10,
        //@}


        TEX_DEFAULT = 0,
        TEX_SPECIAL = 1,
        TEX_GROUP = 2,
        TEX_SYMBOL = 3,
        TEX_COMMAND = 4,
        TEX_TEXT = 5,

        METAPOST_DEFAULT = 0,
        METAPOST_SPECIAL = 1,
        METAPOST_GROUP = 2,
        METAPOST_SYMBOL = 3,
        METAPOST_COMMAND = 4,
        METAPOST_TEXT = 5,
        METAPOST_EXTRA = 6,

    }

        /** <summary>Character set identifiers are used in StyleSetCharacterSet.
          * The values are the same as the Windows *_CHARSET values.</summary>*/
    public enum CharsetIdentifier
    {
        ANSI = 0,
        DEFAULT = 1,
        BALTIC = 186,
        CHINESEBIG5 = 136,
        EASTEUROPE = 238,
        GB2312 = 134,
        GREEK = 161,
        HANGUL = 129,
        MAC = 77,
        OEM = 255,
        RUSSIAN = 204,
        SHIFTJIS = 128,
        SYMBOL = 2,
        TURKISH = 162,
        JOHAB = 130,
        HEBREW = 177,
        ARABIC = 178,
        VIETNAMESE = 163,
        THAI = 222,
    }

    [Flags]
    public enum TheFoldFlags
    {
        LINEBEFORE_EXPANDED = 0x0002,
        LINEBEFORE_CONTRACTED = 0x0004,
        LINEAFTER_EXPANDED = 0x0008,
        LINEAFTER_CONTRACTED = 0x0010,
        LEVELNUMBERS = 0x0040,
        /** <summary>Draws a box around a folded or fodable region.</summary>*/
        FOLDFLAG_BOX = 0x0001,
    }

    /** <summary>The fold level describes properties of a line referring to folding.
     * Refer also to StyledTextCtrl.GetFoldLevel().</summary>*/
    [Flags]
    public enum FoldLevel
    {
        WHITEFLAG = 0x1000,
        /** <summary>This flag is in the fold level iff the referring line starts a foldable region.</summary>*/
        HEADERFLAG = 0x2000,
        BOXHEADERFLAG = 0x4000,
        BOXFOOTERFLAG = 0x8000,
        /** <summary>This is in the fold flags if this line belongs to a foldable region.</summary>*/
        CONTRACTED = 0x10000,
        UNINDENT = 0x20000,

        /** <summary>This is the base for the number describing the folding level.</summary>*/
        BASE = 0x400,
        /** <summary>This is the mask for the number describing the folding level.</summary>*/
        NUMBERMASK = 0x0FFF,
        /** <summary>This is the mask for the flags describing the folding level.</summary>*/
        FLAGSMASK = 0x03F000,
    }

    public enum LayoutCacheModes
    {
        NONE = 0,
        CARET = 1,
        PAGE = 2,
        DOCUMENT = 3,
    }

        /** <summary>Available cursors to be used within the edit control.</summary>*/
    public enum STCCursors
    {
        NORMAL = -1,
        WAIT = 4,
    }

        /** <summary>Modes for wrapping lines if they are too long to fit into the edit control.</summary>*/
    public enum WrapModes
    {
        NONE = 0,
        WORD = 1,
    }

    /** <summary>Use this to define the policy for</summary>*/
    public enum EdgeModes
    {
        NONE = 0,
        LINE = 1,
        BACKGROUND = 2,
    }


    /** <summary> Constants for use with SetVisiblePolicy(), similar to SetCaretPolicy().</summary>*/
    public enum VisiblePolicies
    {
        SLOP = 0x01,
        STRICT = 0x04,
    }

    public enum CaretPolicies
    {
        /** <summary>Caret policy, used by SetXCaretPolicy and SetYCaretPolicy.
         * If CARET_SLOP is set, we can define a slop value: caretSlop.
         * This value defines an unwanted zone (UZ) where the caret is... unwanted.
         * This zone is defined as a number of pixels near the vertical margins,
         * and as a number of lines near the horizontal margins.
         * By keeping the caret away from the edges, it is seen within its context,
         * so it is likely that the identifier that the caret is on can be completely seen,
         * and that the current line is seen with some of the lines following it which are
         * often dependent on that line.</summary>*/
        SLOP = 0x01,

        /** <summary>If CARET_STRICT is set, the policy is enforced... strictly.
          * The caret is centred on the display if slop is not set,
          * and cannot go in the UZ if slop is set.</summary>*/
        STRICT = 0x04,

        //! If CARET_JUMPS is set, the display is moved more energetically
        //! so the caret can move in the same direction longer before the policy is applied again.
        JUMPS = 0x10,

        /** <summary>If CARET_EVEN is not set, instead of having symmetrical UZs,
         * the left and bottom UZs are extended up to right and top UZs respectively.
         * This way, we favour the displaying of useful information: the begining of lines,
         * where most code reside, and the lines after the caret, eg. the body of a function.</summary>*/
        EVEN = 0x08,
    }

    /** <summary>Text control particularly applicable for displaying programming languages.
     * This is a text control with builtin lexicographic analysis (configured by StyledTextCtrl.Lexer).
     * This analysis assigns styles to particular parts of the displayed text. 
     * You may assign various directives for text formatting to these styles.
     * </summary>
     * <remarks>
     * \image html stcsample.PNG "The STC Sample Program"
     * 
     * Purpose:
     * A wxWidgets implementation of Scintilla.  This class is the
     *          one meant to be used directly by wx applications.  It does not
     *          derive directly from the Scintilla classes, and in fact there
     *          is no mention of Scintilla classes at all in this header.
     *          This class delegates all method calls and events to the
     *          Scintilla objects and so forth.  This allows the use of
     *          Scintilla without polluting the namespace with all the
     *          classes and itentifiers from Scintilla.
     * </remarks>
     */
    public class StyledTextCtrl : Control 
    {
        #region C API
        [DllImport("wx-c")] static extern int wxStyledTextCtrl_EVT_STC_CHANGE();
        [DllImport("wx-c")] static extern int wxStyledTextCtrl_EVT_STC_STYLENEEDED();
        [DllImport("wx-c")] static extern int wxStyledTextCtrl_EVT_STC_CHARADDED();
        [DllImport("wx-c")] static extern int wxStyledTextCtrl_EVT_STC_SAVEPOINTREACHED();
        [DllImport("wx-c")] static extern int wxStyledTextCtrl_EVT_STC_SAVEPOINTLEFT();  
        [DllImport("wx-c")] static extern int wxStyledTextCtrl_EVT_STC_ROMODIFYATTEMPT();
        [DllImport("wx-c")] static extern int wxStyledTextCtrl_EVT_STC_KEY();
        [DllImport("wx-c")] static extern int wxStyledTextCtrl_EVT_STC_DOUBLECLICK();
        [DllImport("wx-c")] static extern int wxStyledTextCtrl_EVT_STC_UPDATEUI();
        [DllImport("wx-c")] static extern int wxStyledTextCtrl_EVT_STC_MODIFIED();
        [DllImport("wx-c")] static extern int wxStyledTextCtrl_EVT_STC_MACRORECORD();
        [DllImport("wx-c")] static extern int wxStyledTextCtrl_EVT_STC_MARGINCLICK();
        [DllImport("wx-c")] static extern int wxStyledTextCtrl_EVT_STC_NEEDSHOWN();
        //[DllImport("wx-c")] static extern int wxStyledTextCtrl_EVT_STC_POSCHANGED();
        [DllImport("wx-c")] static extern int wxStyledTextCtrl_EVT_STC_PAINTED();
        [DllImport("wx-c")] static extern int wxStyledTextCtrl_EVT_STC_USERLISTSELECTION();
        [DllImport("wx-c")] static extern int wxStyledTextCtrl_EVT_STC_URIDROPPED();
        [DllImport("wx-c")] static extern int wxStyledTextCtrl_EVT_STC_DWELLSTART();
        [DllImport("wx-c")] static extern int wxStyledTextCtrl_EVT_STC_DWELLEND();
        [DllImport("wx-c")] static extern int wxStyledTextCtrl_EVT_STC_START_DRAG();
        [DllImport("wx-c")] static extern int wxStyledTextCtrl_EVT_STC_DRAG_OVER();
        [DllImport("wx-c")] static extern int wxStyledTextCtrl_EVT_STC_DO_DROP();
        [DllImport("wx-c")] static extern int wxStyledTextCtrl_EVT_STC_ZOOM();
        [DllImport("wx-c")] static extern int wxStyledTextCtrl_EVT_STC_HOTSPOT_CLICK();
        [DllImport("wx-c")] static extern int wxStyledTextCtrl_EVT_STC_HOTSPOT_DCLICK();
        [DllImport("wx-c")] static extern int wxStyledTextCtrl_EVT_STC_CALLTIP_CLICK();

        public static readonly int wxEVT_STC_CHANGE = wxStyledTextCtrl_EVT_STC_CHANGE();
        public static readonly int wxEVT_STC_STYLENEEDED = wxStyledTextCtrl_EVT_STC_STYLENEEDED();
        public static readonly int wxEVT_STC_CHARADDED = wxStyledTextCtrl_EVT_STC_CHARADDED();
        public static readonly int wxEVT_STC_SAVEPOINTREACHED = wxStyledTextCtrl_EVT_STC_SAVEPOINTREACHED();
        public static readonly int wxEVT_STC_SAVEPOINTLEFT = wxStyledTextCtrl_EVT_STC_SAVEPOINTLEFT();  
        public static readonly int wxEVT_STC_ROMODIFYATTEMPT = wxStyledTextCtrl_EVT_STC_ROMODIFYATTEMPT();
        public static readonly int wxEVT_STC_KEY = wxStyledTextCtrl_EVT_STC_KEY();
        public static readonly int wxEVT_STC_DOUBLECLICK = wxStyledTextCtrl_EVT_STC_DOUBLECLICK();
        public static readonly int wxEVT_STC_UPDATEUI = wxStyledTextCtrl_EVT_STC_UPDATEUI();
        public static readonly int wxEVT_STC_MODIFIED = wxStyledTextCtrl_EVT_STC_MODIFIED();
        public static readonly int wxEVT_STC_MACRORECORD = wxStyledTextCtrl_EVT_STC_MACRORECORD();
        public static readonly int wxEVT_STC_MARGINCLICK = wxStyledTextCtrl_EVT_STC_MARGINCLICK();
        public static readonly int wxEVT_STC_NEEDSHOWN = wxStyledTextCtrl_EVT_STC_NEEDSHOWN();
        //public static readonly int wxEVT_STC_POSCHANGED = wxStyledTextCtrl_EVT_STC_POSCHANGED();
        public static readonly int wxEVT_STC_PAINTED = wxStyledTextCtrl_EVT_STC_PAINTED();
        public static readonly int wxEVT_STC_USERLISTSELECTION = wxStyledTextCtrl_EVT_STC_USERLISTSELECTION();
        public static readonly int wxEVT_STC_URIDROPPED = wxStyledTextCtrl_EVT_STC_URIDROPPED();
        public static readonly int wxEVT_STC_DWELLSTART = wxStyledTextCtrl_EVT_STC_DWELLSTART();
        public static readonly int wxEVT_STC_DWELLEND = wxStyledTextCtrl_EVT_STC_DWELLEND();
        public static readonly int wxEVT_STC_START_DRAG = wxStyledTextCtrl_EVT_STC_START_DRAG();
        public static readonly int wxEVT_STC_DRAG_OVER = wxStyledTextCtrl_EVT_STC_DRAG_OVER();
        public static readonly int wxEVT_STC_DO_DROP = wxStyledTextCtrl_EVT_STC_DO_DROP();
        public static readonly int wxEVT_STC_ZOOM = wxStyledTextCtrl_EVT_STC_ZOOM();
        public static readonly int wxEVT_STC_HOTSPOT_CLICK = wxStyledTextCtrl_EVT_STC_HOTSPOT_CLICK();
        public static readonly int wxEVT_STC_HOTSPOT_DCLICK = wxStyledTextCtrl_EVT_STC_HOTSPOT_DCLICK();
        public static readonly int wxEVT_STC_CALLTIP_CLICK = wxStyledTextCtrl_EVT_STC_CALLTIP_CLICK();
        #endregion

        //-----------------------------------------------------------------------------

        public const int wxSTC_INVALID_POSITION = -1;

        public const int wxSTC_START = 2000;
        public const int wxSTC_OPTIONAL_START = 3000;
        public const int wxSTC_LEXER_START = 4000;

        /** <summary>The SC_CP_UTF8 value can be used to enter Unicode mode.
          * This is the same value as CP_UTF8 in Windows
         *</summary>*/
        public const int wxSTC_CP_UTF8 = 65001;
        /** <summary>The SC_CP_DBCS value can be used to indicate a DBCS mode for GTK+.</summary>*/
        public const int wxSTC_CP_DBCS = 1;

        public const int wxSTC_INDIC_MAX = 7;
        public const int wxSTC_INDIC_PLAIN = 0;
        public const int wxSTC_INDIC_SQUIGGLE = 1;
        public const int wxSTC_INDIC_TT = 2;
        public const int wxSTC_INDIC_DIAGONAL = 3;
        public const int wxSTC_INDIC_STRIKE = 4;
        public const int wxSTC_INDIC0_MASK = 0x20;
        public const int wxSTC_INDIC1_MASK = 0x40;
        public const int wxSTC_INDIC2_MASK = 0x80;
        public const int wxSTC_INDICS_MASK = 0xE0;

        /** <summary>PrintColourMode - use same colours as screen.</summary>*/
        public const int wxSTC_PRINT_NORMAL = 0;

        /** <summary>PrintColourMode - invert the light value of each style for printing.</summary>*/
        public const int wxSTC_PRINT_INVERTLIGHT = 1;

        /** <summary>PrintColourMode - force black text on white background for printing.</summary>*/
        public const int wxSTC_PRINT_BLACKONWHITE = 2;

        /** <summary>PrintColourMode - text stays coloured, but all background is forced to be white for printing.</summary>*/
        public const int wxSTC_PRINT_COLOURONWHITE = 3;

        /** <summary>PrintColourMode - only the default-background is forced to be white for printing.</summary>*/
        public const int wxSTC_PRINT_COLOURONWHITEDEFAULTBG = 4;

        public const int wxSTC_FIND_WHOLEWORD = 2;
        public const int wxSTC_FIND_MATCHCASE = 4;
        public const int wxSTC_FIND_WORDSTART = 0x00100000;
        public const int wxSTC_FIND_REGEXP = 0x00200000;
        public const int wxSTC_FIND_POSIX = 0x00400000;

        public const int wxSTC_TIME_FOREVER = 10000000;

        /** \name Notifications
         * Type of modification and the action which caused the modification.
         * These are defined as a bit mask to make it easy to specify which notifications are wanted.
         * One bit is set from each of SC_MOD_* and SC_PERFORMED_*.
         */
        //@{
        public const int wxSTC_MOD_INSERTTEXT = 0x1;
        public const int wxSTC_MOD_DELETETEXT = 0x2;
        public const int wxSTC_MOD_CHANGESTYLE = 0x4;
        public const int wxSTC_MOD_CHANGEFOLD = 0x8;
        public const int wxSTC_PERFORMED_USER = 0x10;
        public const int wxSTC_PERFORMED_UNDO = 0x20;
        public const int wxSTC_PERFORMED_REDO = 0x40;
        public const int wxSTC_LASTSTEPINUNDOREDO = 0x100;
        public const int wxSTC_MOD_CHANGEMARKER = 0x200;
        public const int wxSTC_MOD_BEFOREINSERT = 0x400;
        public const int wxSTC_MOD_BEFOREDELETE = 0x800;
        public const int wxSTC_MODEVENTMASKALL = 0xF77;
        //@}

        /** \name Symbolic key codes and modifier flags.
          * ASCII and other printable characters below 256.
          * Extended keys above 300.
          */
        //@{
        public const int wxSTC_KEY_DOWN = 300;
        public const int wxSTC_KEY_UP = 301;
        public const int wxSTC_KEY_LEFT = 302;
        public const int wxSTC_KEY_RIGHT = 303;
        public const int wxSTC_KEY_HOME = 304;
        public const int wxSTC_KEY_END = 305;
        public const int wxSTC_KEY_PRIOR = 306;
        public const int wxSTC_KEY_NEXT = 307;
        public const int wxSTC_KEY_DELETE = 308;
        public const int wxSTC_KEY_INSERT = 309;
        public const int wxSTC_KEY_ESCAPE = 7;
        public const int wxSTC_KEY_BACK = 8;
        public const int wxSTC_KEY_TAB = 9;
        public const int wxSTC_KEY_RETURN = 13;
        public const int wxSTC_KEY_ADD = 310;
        public const int wxSTC_KEY_SUBTRACT = 311;
        public const int wxSTC_KEY_DIVIDE = 312;
        public const int wxSTC_SCMOD_SHIFT = 1;
        public const int wxSTC_SCMOD_CTRL = 2;
        public const int wxSTC_SCMOD_ALT = 4;
        //@}




        //-----------------------------------------
        /** \name Commands that can be bound to keystrokes. */
        //@{
        //! Redoes the next action on the undo history.
        public const int wxSTC_CMD_REDO = 2011;

        //! Select all the text in the document.
        public const int wxSTC_CMD_SELECTALL = 2013;

        //! Undo one action in the undo history.
        public const int wxSTC_CMD_UNDO = 2176;

        //! Cut the selection to the clipboard.
        public const int wxSTC_CMD_CUT = 2177;

        //! Copy the selection to the clipboard.
        public const int wxSTC_CMD_COPY = 2178;

        //! Paste the contents of the clipboard into the document replacing the selection.
        public const int wxSTC_CMD_PASTE = 2179;

        //! Clear the selection.
        public const int wxSTC_CMD_CLEAR = 2180;

        //! Move caret down one line.
        public const int wxSTC_CMD_LINEDOWN = 2300;

        //! Move caret down one line extending selection to new caret position.
        public const int wxSTC_CMD_LINEDOWNEXTEND = 2301;

        //! Move caret up one line.
        public const int wxSTC_CMD_LINEUP = 2302;

        //! Move caret up one line extending selection to new caret position.
        public const int wxSTC_CMD_LINEUPEXTEND = 2303;

        //! Move caret left one character.
        public const int wxSTC_CMD_CHARLEFT = 2304;

        //! Move caret left one character extending selection to new caret position.
        public const int wxSTC_CMD_CHARLEFTEXTEND = 2305;

        //! Move caret right one character.
        public const int wxSTC_CMD_CHARRIGHT = 2306;

        //! Move caret right one character extending selection to new caret position.
        public const int wxSTC_CMD_CHARRIGHTEXTEND = 2307;

        //! Move caret left one word.
        public const int wxSTC_CMD_WORDLEFT = 2308;

        //! Move caret left one word extending selection to new caret position.
        public const int wxSTC_CMD_WORDLEFTEXTEND = 2309;

        //! Move caret right one word.
        public const int wxSTC_CMD_WORDRIGHT = 2310;

        //! Move caret right one word extending selection to new caret position.
        public const int wxSTC_CMD_WORDRIGHTEXTEND = 2311;

        //! Move caret to first position on line.
        public const int wxSTC_CMD_HOME = 2312;

        //! Move caret to first position on line extending selection to new caret position.
        public const int wxSTC_CMD_HOMEEXTEND = 2313;

        //! Move caret to last position on line.
        public const int wxSTC_CMD_LINEEND = 2314;

        //! Move caret to last position on line extending selection to new caret position.
        public const int wxSTC_CMD_LINEENDEXTEND = 2315;

        //! Move caret to first position in document.
        public const int wxSTC_CMD_DOCUMENTSTART = 2316;

        //! Move caret to first position in document extending selection to new caret position.
        public const int wxSTC_CMD_DOCUMENTSTARTEXTEND = 2317;

        //! Move caret to last position in document.
        public const int wxSTC_CMD_DOCUMENTEND = 2318;

        //! Move caret to last position in document extending selection to new caret position.
        public const int wxSTC_CMD_DOCUMENTENDEXTEND = 2319;

        //! Move caret one page up.
        public const int wxSTC_CMD_PAGEUP = 2320;

        //! Move caret one page up extending selection to new caret position.
        public const int wxSTC_CMD_PAGEUPEXTEND = 2321;

        //! Move caret one page down.
        public const int wxSTC_CMD_PAGEDOWN = 2322;

        //! Move caret one page down extending selection to new caret position.
        public const int wxSTC_CMD_PAGEDOWNEXTEND = 2323;

        //! Switch from insert to overtype mode or the reverse.
        public const int wxSTC_CMD_EDITTOGGLEOVERTYPE = 2324;

        //! Cancel any modes such as call tip or auto-completion list display.
        public const int wxSTC_CMD_CANCEL = 2325;

        //! Delete the selection or if no selection, the character before the caret.
        public const int wxSTC_CMD_DELETEBACK = 2326;

        //! If selection is empty or all on one line replace the selection with a tab character.
        //! If more than one line selected, indent the lines.
        public const int wxSTC_CMD_TAB = 2327;

        //! Dedent the selected lines.
        public const int wxSTC_CMD_BACKTAB = 2328;

        //! Insert a new line, may use a CRLF, CR or LF depending on EOL mode.
        public const int wxSTC_CMD_NEWLINE = 2329;

        //! Insert a Form Feed character.
        public const int wxSTC_CMD_FORMFEED = 2330;

        //! Move caret to before first visible character on line.
        //! If already there move to first character on line.
        public const int wxSTC_CMD_VCHOME = 2331;

        //! Like VCHome but extending selection to new caret position.
        public const int wxSTC_CMD_VCHOMEEXTEND = 2332;

        //! Magnify the displayed text by increasing the sizes by 1 point.
        public const int wxSTC_CMD_ZOOMIN = 2333;

        //! Make the displayed text smaller by decreasing the sizes by 1 point.
        public const int wxSTC_CMD_ZOOMOUT = 2334;

        //! Delete the word to the left of the caret.
        public const int wxSTC_CMD_DELWORDLEFT = 2335;

        //! Delete the word to the right of the caret.
        public const int wxSTC_CMD_DELWORDRIGHT = 2336;

        //! Cut the line containing the caret.
        public const int wxSTC_CMD_LINECUT = 2337;

        //! Delete the line containing the caret.
        public const int wxSTC_CMD_LINEDELETE = 2338;

        //! Switch the current line with the previous.
        public const int wxSTC_CMD_LINETRANSPOSE = 2339;

        //! Duplicate the current line.
        public const int wxSTC_CMD_LINEDUPLICATE = 2404;

        //! Transform the selection to lower case.
        public const int wxSTC_CMD_LOWERCASE = 2340;

        //! Transform the selection to upper case.
        public const int wxSTC_CMD_UPPERCASE = 2341;

        //! Scroll the document down, keeping the caret visible.
        public const int wxSTC_CMD_LINESCROLLDOWN = 2342;

        //! Scroll the document up, keeping the caret visible.
        public const int wxSTC_CMD_LINESCROLLUP = 2343;

        //! Delete the selection or if no selection, the character before the caret.
        //! Will not delete the character before at the start of a line.
        public const int wxSTC_CMD_DELETEBACKNOTLINE = 2344;

        //! Move caret to first position on display line.
        public const int wxSTC_CMD_HOMEDISPLAY = 2345;

        //! Move caret to first position on display line extending selection to
        //! new caret position.
        public const int wxSTC_CMD_HOMEDISPLAYEXTEND = 2346;

        //! Move caret to last position on display line.
        public const int wxSTC_CMD_LINEENDDISPLAY = 2347;

        //! Move caret to last position on display line extending selection to new
        //! caret position.
        public const int wxSTC_CMD_LINEENDDISPLAYEXTEND = 2348;

        //! Move to the previous change in capitalisation.
        public const int wxSTC_CMD_WORDPARTLEFT = 2390;

        //! Move to the previous change in capitalisation extending selection
        //! to new caret position.
        public const int wxSTC_CMD_WORDPARTLEFTEXTEND = 2391;

        //! Move to the change next in capitalisation.
        public const int wxSTC_CMD_WORDPARTRIGHT = 2392;

        //! Move to the next change in capitalisation extending selection
        //! to new caret position.
        public const int wxSTC_CMD_WORDPARTRIGHTEXTEND = 2393;

        //! Delete back from the current position to the start of the line.
        public const int wxSTC_CMD_DELLINELEFT = 2395;

        //! Delete forwards from the current position to the end of the line.
        public const int wxSTC_CMD_DELLINERIGHT = 2396;
        //@}

        /** \name These are like their namesakes Home(Extend)?, LineEnd(Extend)?, VCHome(Extend)?
          * except they behave differently when word-wrap is enabled:
          * They go first to the start / end of the display line, like (Home|LineEnd)Display
          * The difference is that, the cursor is already at the point, it goes on to the start
          * or end of the document line, as appropriate for (Home|LineEnd|VCHome)Extend.
          */
        //@{
        public const int wxSTC_CMD_HOMEWRAP = 2349;
        public const int wxSTC_CMD_HOMEWRAPEXTEND = 2450;
        public const int wxSTC_CMD_LINEENDWRAP = 2451;
        public const int wxSTC_CMD_LINEENDWRAPEXTEND = 2452;
        public const int wxSTC_CMD_VCHOMEWRAP = 2453;
        public const int wxSTC_CMD_VCHOMEWRAPEXTEND = 2454;
        //@}

        /** \name Move caret between paragraphs (delimited by empty lines) */
        //@{
        public const int wxSTC_CMD_PARADOWN = 2413;
        public const int wxSTC_CMD_PARADOWNEXTEND = 2414;
        public const int wxSTC_CMD_PARAUP = 2415;
        public const int wxSTC_CMD_PARAUPEXTEND = 2416;
        //@}

        //-----------------------------------------------------------------------------

        #region C API
        [DllImport("wx-c")] static extern IntPtr wxStyledTextCtrl_ctor(IntPtr parent, int id, int posX, int posY, int width, int height, uint style, IntPtr name);
        [DllImport("wx-c")]
        static extern void wxStyledtextCtrl_dtor(IntPtr wxobject);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_AddText(IntPtr self, IntPtr text);
        //[DllImport("wx-c")] static extern void   wxStyledTextCtrl_AddStyledText(IntPtr self, IntPtr data);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_InsertText(IntPtr self, int pos, IntPtr text);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_ClearAll(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_ClearDocumentStyle(IntPtr self);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_GetLength(IntPtr self);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_GetCharAt(IntPtr self, int pos);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_GetCurrentPos(IntPtr self);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_GetAnchor(IntPtr self);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_GetStyleAt(IntPtr self, int pos);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_Redo(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetUndoCollection(IntPtr self, bool collectUndo);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SelectAll(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetSavePoint(IntPtr self);
        //[DllImport("wx-c")] static extern IntPtr wxStyledTextCtrl_GetStyledText(IntPtr self, int startPos, int endPos);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxStyledTextCtrl_CanRedo(IntPtr self);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_MarkerLineFromHandle(IntPtr self, int handle);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_MarkerDeleteHandle(IntPtr self, int handle);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxStyledTextCtrl_GetUndoCollection(IntPtr self);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_GetViewWhiteSpace(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetViewWhiteSpace(IntPtr self, int viewWS);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_PositionFromPoint(IntPtr self, ref Point pt);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_PositionFromPointClose(IntPtr self, int x, int y);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_GotoLine(IntPtr self, int line);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_GotoPos(IntPtr self, int pos);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetAnchor(IntPtr self, int posAnchor);
        [DllImport("wx-c")] static extern IntPtr wxStyledTextCtrl_GetCurLine(IntPtr self, ref int linePos);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_GetEndStyled(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_ConvertEOLs(IntPtr self, int eolMode);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_GetEOLMode(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetEOLMode(IntPtr self, int eolMode);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_StartStyling(IntPtr self, int pos, int mask);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetStyling(IntPtr self, int length, int style);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxStyledTextCtrl_GetBufferedDraw(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetBufferedDraw(IntPtr self, bool buffered);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetTabWidth(IntPtr self, int tabWidth);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_GetTabWidth(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetCodePage(IntPtr self, int codePage);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_MarkerDefine(IntPtr self, int markerNumber, int markerSymbol, IntPtr foreground, IntPtr background);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_MarkerSetForeground(IntPtr self, int markerNumber, IntPtr fore);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_MarkerSetBackground(IntPtr self, int markerNumber, IntPtr back);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_MarkerAdd(IntPtr self, int line, int markerNumber);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_MarkerDelete(IntPtr self, int line, int markerNumber);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_MarkerDeleteAll(IntPtr self, int markerNumber);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_MarkerGet(IntPtr self, int line);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_MarkerNext(IntPtr self, int lineStart, int markerMask);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_MarkerPrevious(IntPtr self, int lineStart, int markerMask);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_MarkerDefineBitmap(IntPtr self, int markerNumber, IntPtr bmp);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetMarginType(IntPtr self, int margin, int marginType);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_GetMarginType(IntPtr self, int margin);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetMarginWidth(IntPtr self, int margin, int pixelWidth);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_GetMarginWidth(IntPtr self, int margin);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetMarginMask(IntPtr self, int margin, uint mask);
        [DllImport("wx-c")] static extern uint   wxStyledTextCtrl_GetMarginMask(IntPtr self, int margin);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetMarginSensitive(IntPtr self, int margin, bool sensitive);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxStyledTextCtrl_GetMarginSensitive(IntPtr self, int margin);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_StyleClearAll(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_StyleSetForeground(IntPtr self, int style, IntPtr fore);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_StyleSetBackground(IntPtr self, int style, IntPtr back);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_StyleSetBold(IntPtr self, int style, bool bold);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_StyleSetItalic(IntPtr self, int style, bool italic);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_StyleSetSize(IntPtr self, int style, int sizePoints);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_StyleSetFaceName(IntPtr self, int style, IntPtr fontName);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_StyleSetEOLFilled(IntPtr self, int style, bool filled);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_StyleResetDefault(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_StyleSetUnderline(IntPtr self, int style, bool underline);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_StyleSetCase(IntPtr self, int style, int caseForce);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_StyleSetCharacterSet(IntPtr self, int style, int characterSet);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_StyleSetHotSpot(IntPtr self, int style, bool hotspot);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetSelForeground(IntPtr self, bool useSetting, IntPtr fore);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetSelBackground(IntPtr self, bool useSetting, IntPtr back);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetCaretForeground(IntPtr self, IntPtr fore);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_CmdKeyAssign(IntPtr self, int key, int modifiers, int cmd);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_CmdKeyClear(IntPtr self, int key, int modifiers);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_CmdKeyClearAll(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetStyleBytes(IntPtr self, int length, byte[] styleBytes);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_StyleSetVisible(IntPtr self, int style, bool visible);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_GetCaretPeriod(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetCaretPeriod(IntPtr self, int periodMilliseconds);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetWordChars(IntPtr self, IntPtr characters);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_BeginUndoAction(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_EndUndoAction(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_IndicatorSetStyle(IntPtr self, int indic, int style);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_IndicatorGetStyle(IntPtr self, int indic);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_IndicatorSetForeground(IntPtr self, int indic, IntPtr fore);
        [DllImport("wx-c")] static extern IntPtr wxStyledTextCtrl_IndicatorGetForeground(IntPtr self, int indic);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetWhitespaceForeground(IntPtr self, bool useSetting, IntPtr fore);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetWhitespaceBackground(IntPtr self, bool useSetting, IntPtr back);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetStyleBits(IntPtr self, int bits);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_GetStyleBits(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetLineState(IntPtr self, int line, int state);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_GetLineState(IntPtr self, int line);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_GetMaxLineState(IntPtr self);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxStyledTextCtrl_GetCaretLineVisible(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetCaretLineVisible(IntPtr self, bool show);
        [DllImport("wx-c")] static extern IntPtr wxStyledTextCtrl_GetCaretLineBack(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetCaretLineBack(IntPtr self, IntPtr back);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_StyleSetChangeable(IntPtr self, int style, bool changeable);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_AutoCompShow(IntPtr self, int lenEntered, IntPtr itemList);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_AutoCompCancel(IntPtr self);
        [DllImport("wx-c")][return:MarshalAs(UnmanagedType.U1)] static extern bool wxStyledTextCtrl_AutoCompActive(IntPtr self);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_AutoCompPosStart(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_AutoCompComplete(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_AutoCompStops(IntPtr self, IntPtr characterSet);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_AutoCompSetSeparator(IntPtr self, int separatorCharacter);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_AutoCompGetSeparator(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_AutoCompSelect(IntPtr self, IntPtr text);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_AutoCompSetCancelAtStart(IntPtr self, bool cancel);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxStyledTextCtrl_AutoCompGetCancelAtStart(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_AutoCompSetFillUps(IntPtr self, IntPtr characterSet);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_AutoCompSetChooseSingle(IntPtr self, bool chooseSingle);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxStyledTextCtrl_AutoCompGetChooseSingle(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_AutoCompSetIgnoreCase(IntPtr self, bool ignoreCase);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxStyledTextCtrl_AutoCompGetIgnoreCase(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_UserListShow(IntPtr self, int listType, IntPtr itemList);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_AutoCompSetAutoHide(IntPtr self, bool autoHide);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxStyledTextCtrl_AutoCompGetAutoHide(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_AutoCompSetDropRestOfWord(IntPtr self, bool dropRestOfWord);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxStyledTextCtrl_AutoCompGetDropRestOfWord(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_RegisterImage(IntPtr self, int type, IntPtr bmp);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_ClearRegisteredImages(IntPtr self);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_AutoCompGetTypeSeparator(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_AutoCompSetTypeSeparator(IntPtr self, int separatorCharacter);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetIndent(IntPtr self, int indentSize);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_GetIndent(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetUseTabs(IntPtr self, bool useTabs);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxStyledTextCtrl_GetUseTabs(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetLineIndentation(IntPtr self, int line, int indentSize);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_GetLineIndentation(IntPtr self, int line);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_GetLineIndentPosition(IntPtr self, int line);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_GetColumn(IntPtr self, int pos);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetUseHorizontalScrollBar(IntPtr self, bool show);
        [DllImport("wx-c")] static extern bool   wxStyledTextCtrl_GetUseHorizontalScrollBar(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetIndentationGuides(IntPtr self, bool show);
        [DllImport("wx-c")] static extern bool   wxStyledTextCtrl_GetIndentationGuides(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetHighlightGuide(IntPtr self, int column);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_GetHighlightGuide(IntPtr self);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_GetLineEndPosition(IntPtr self, int line);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_GetCodePage(IntPtr self);
        [DllImport("wx-c")] static extern IntPtr wxStyledTextCtrl_GetCaretForeground(IntPtr self);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxStyledTextCtrl_GetReadOnly(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetCurrentPos(IntPtr self, int pos);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetSelectionStart(IntPtr self, int pos);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_GetSelectionStart(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetSelectionEnd(IntPtr self, int pos);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_GetSelectionEnd(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetPrintMagnification(IntPtr self, int magnification);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_GetPrintMagnification(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetPrintColourMode(IntPtr self, int mode);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_GetPrintColourMode(IntPtr self);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_FindText(IntPtr self, int minPos, int maxPos, IntPtr text, int flags);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_FormatRange(IntPtr self, bool doDraw, int startPos, int endPos, IntPtr draw, IntPtr target, ref Rectangle renderRect, ref Rectangle pageRect);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_GetFirstVisibleLine(IntPtr self);
        [DllImport("wx-c")] static extern IntPtr wxStyledTextCtrl_GetLine(IntPtr self, int line);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_GetLineCount(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetMarginLeft(IntPtr self, int pixelWidth);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_GetMarginLeft(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetMarginRight(IntPtr self, int pixelWidth);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_GetMarginRight(IntPtr self);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxStyledTextCtrl_GetModify(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetSelection(IntPtr self, int start, int end);
        [DllImport("wx-c")] static extern IntPtr wxStyledTextCtrl_GetSelectedText(IntPtr self);
        [DllImport("wx-c")] static extern IntPtr wxStyledTextCtrl_GetTextRange(IntPtr self, int startPos, int endPos);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_HideSelection(IntPtr self, bool normal);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_LineFromPosition(IntPtr self, int pos);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_PositionFromLine(IntPtr self, int line);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_LineScroll(IntPtr self, int columns, int lines);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_EnsureCaretVisible(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_ReplaceSelection(IntPtr self, IntPtr text);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetReadOnly(IntPtr self, bool readOnly);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxStyledTextCtrl_CanPaste(IntPtr self);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxStyledTextCtrl_CanUndo(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_EmptyUndoBuffer(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_Undo(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_Cut(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_Copy(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_Paste(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_Clear(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetText(IntPtr self, IntPtr text);
        [DllImport("wx-c")] static extern IntPtr wxStyledTextCtrl_GetText(IntPtr self);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_GetTextLength(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetOvertype(IntPtr self, bool overtype);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxStyledTextCtrl_GetOvertype(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetCaretWidth(IntPtr self, int pixelWidth);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_GetCaretWidth(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetTargetStart(IntPtr self, int pos);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_GetTargetStart(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetTargetEnd(IntPtr self, int pos);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_GetTargetEnd(IntPtr self);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_ReplaceTarget(IntPtr self, IntPtr text);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_ReplaceTargetRE(IntPtr self, IntPtr text);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_SearchInTarget(IntPtr self, IntPtr text);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetSearchFlags(IntPtr self, int flags);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_GetSearchFlags(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_CallTipShow(IntPtr self, int pos, IntPtr definition);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_CallTipCancel(IntPtr self);
        [DllImport("wx-c")] static extern bool   wxStyledTextCtrl_CallTipActive(IntPtr self);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_CallTipPosAtStart(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_CallTipSetHighlight(IntPtr self, int start, int end);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_CallTipSetBackground(IntPtr self, IntPtr back);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_CallTipSetForeground(IntPtr self, IntPtr fore);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_CallTipSetForegroundHighlight(IntPtr self, IntPtr fore);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_VisibleFromDocLine(IntPtr self, int line);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_DocLineFromVisible(IntPtr self, int lineDisplay);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetFoldLevel(IntPtr self, int line, int level);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_GetFoldLevel(IntPtr self, int line);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_GetLastChild(IntPtr self, int line, int level);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_GetFoldParent(IntPtr self, int line);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_ShowLines(IntPtr self, int lineStart, int lineEnd);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_HideLines(IntPtr self, int lineStart, int lineEnd);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxStyledTextCtrl_GetLineVisible(IntPtr self, int line);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetFoldExpanded(IntPtr self, int line, bool expanded);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxStyledTextCtrl_GetFoldExpanded(IntPtr self, int line);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_ToggleFold(IntPtr self, int line);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_EnsureVisible(IntPtr self, int line);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetFoldFlags(IntPtr self, int flags);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_EnsureVisibleEnforcePolicy(IntPtr self, int line);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetTabIndents(IntPtr self, bool tabIndents);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxStyledTextCtrl_GetTabIndents(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetBackSpaceUnIndents(IntPtr self, bool bsUnIndents);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxStyledTextCtrl_GetBackSpaceUnIndents(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetMouseDwellTime(IntPtr self, int periodMilliseconds);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_GetMouseDwellTime(IntPtr self);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_WordStartPosition(IntPtr self, int pos, bool onlyWordCharacters);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_WordEndPosition(IntPtr self, int pos, bool onlyWordCharacters);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetWrapMode(IntPtr self, int mode);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_GetWrapMode(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetLayoutCache(IntPtr self, int mode);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_GetLayoutCache(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetScrollWidth(IntPtr self, int pixelWidth);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_GetScrollWidth(IntPtr self);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_TextWidth(IntPtr self, int style, IntPtr text);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetEndAtLastLine(IntPtr self, bool endAtLastLine);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxStyledTextCtrl_GetEndAtLastLine(IntPtr self);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_TextHeight(IntPtr self, int line);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetUseVerticalScrollBar(IntPtr self, bool show);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxStyledTextCtrl_GetUseVerticalScrollBar(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_AppendText(IntPtr self, IntPtr text);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxStyledTextCtrl_GetTwoPhaseDraw(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetTwoPhaseDraw(IntPtr self, bool twoPhase);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_TargetFromSelection(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_LinesJoin(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_LinesSplit(IntPtr self, int pixelWidth);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetFoldMarginColour(IntPtr self, bool useSetting, IntPtr back);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetFoldMarginHiColour(IntPtr self, bool useSetting, IntPtr fore);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_LineDuplicate(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_HomeDisplay(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_HomeDisplayExtend(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_LineEndDisplay(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_LineEndDisplayExtend(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_MoveCaretInsideView(IntPtr self);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_LineLength(IntPtr self, int line);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_BraceHighlight(IntPtr self, int pos1, int pos2);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_BraceBadLight(IntPtr self, int pos);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_BraceMatch(IntPtr self, int pos);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxStyledTextCtrl_GetViewEOL(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetViewEOL(IntPtr self, bool visible);
        [DllImport("wx-c")] static extern IntPtr wxStyledTextCtrl_GetDocPointer(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetDocPointer(IntPtr self, IntPtr docPointer);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetModEventMask(IntPtr self, int mask);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_GetEdgeColumn(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetEdgeColumn(IntPtr self, int column);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_GetEdgeMode(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetEdgeMode(IntPtr self, int mode);
        [DllImport("wx-c")] static extern IntPtr wxStyledTextCtrl_GetEdgeColour(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetEdgeColour(IntPtr self, IntPtr edgeColour);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SearchAnchor(IntPtr self);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_SearchNext(IntPtr self, int flags, IntPtr text);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_SearchPrev(IntPtr self, int flags, IntPtr text);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_LinesOnScreen(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_UsePopUp(IntPtr self, bool allowPopUp);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxStyledTextCtrl_SelectionIsRectangle(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetZoom(IntPtr self, int zoom);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_GetZoom(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_CreateDocument(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_AddRefDocument(IntPtr self, IntPtr docPointer);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_ReleaseDocument(IntPtr self, IntPtr docPointer);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_GetModEventMask(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetSTCFocus(IntPtr self, bool focus);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxStyledTextCtrl_GetSTCFocus(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetStatus(IntPtr self, int statusCode);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_GetStatus(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetMouseDownCaptures(IntPtr self, bool captures);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxStyledTextCtrl_GetMouseDownCaptures(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetSTCCursor(IntPtr self, int cursorType);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_GetSTCCursor(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetControlCharSymbol(IntPtr self, int symbol);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_GetControlCharSymbol(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_WordPartLeft(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_WordPartLeftExtend(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_WordPartRight(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_WordPartRightExtend(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetVisiblePolicy(IntPtr self, int visiblePolicy, int visibleSlop);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_DelLineLeft(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_DelLineRight(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetXOffset(IntPtr self, int newOffset);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_GetXOffset(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_ChooseCaretX(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetXCaretPolicy(IntPtr self, int caretPolicy, int caretSlop);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetYCaretPolicy(IntPtr self, int caretPolicy, int caretSlop);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetPrintWrapMode(IntPtr self, int mode);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_GetPrintWrapMode(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetHotspotActiveForeground(IntPtr self, bool useSetting, IntPtr fore);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetHotspotActiveBackground(IntPtr self, bool useSetting, IntPtr back);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetHotspotActiveUnderline(IntPtr self, bool underline);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_StartRecord(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_StopRecord(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetLexer(IntPtr self, int lexer);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_GetLexer(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_Colourise(IntPtr self, int start, int end);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetProperty(IntPtr self, IntPtr key, IntPtr value);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetKeyWords(IntPtr self, int keywordSet, IntPtr keyWords);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetLexerLanguage(IntPtr self, IntPtr language);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_GetCurrentLine(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_StyleSetSpec(IntPtr self, int styleNum, IntPtr spec);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_StyleSetFont(IntPtr self, int styleNum, IntPtr font);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_StyleSetFontAttr(IntPtr self, int styleNum, int size, IntPtr faceName, bool bold, bool italic, bool underline);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_CmdKeyExecute(IntPtr self, int cmd);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetMargins(IntPtr self, int left, int right);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_GetSelection(IntPtr self, ref int startPos, ref int endPos);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_PointFromPosition(IntPtr self, int pos, ref Point pt);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_ScrollToLine(IntPtr self, int line);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_ScrollToColumn(IntPtr self, int column);
        [DllImport("wx-c")] static extern int    wxStyledTextCtrl_SendMsg(IntPtr self, int msg, int wp, int lp);
        //[DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetVScrollBar(IntPtr self, IntPtr bar);
        //[DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetHScrollBar(IntPtr self, IntPtr bar);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxStyledTextCtrl_GetLastKeydownProcessed(IntPtr self);
        [DllImport("wx-c")] static extern void   wxStyledTextCtrl_SetLastKeydownProcessed(IntPtr self, bool val);
        [DllImport("wx-c")]
        [return:MarshalAs(UnmanagedType.U1)]
        static extern bool   wxStyledTextCtrl_SaveFile(IntPtr self, IntPtr filename);
        [DllImport("wx-c")]
        [return:MarshalAs(UnmanagedType.U1)]
        static extern bool wxStyledTextCtrl_LoadFile(IntPtr self, IntPtr filename);
        [DllImport("wx-c")]
        static extern void wxStyledTextCtrl_CallTipUseStyle(IntPtr self, int tabsize);
        #endregion

        static StyledTextCtrl()
        {
            Event.AddEventType(wxEVT_STC_CHANGE,               typeof(StyledTextEvent));
            Event.AddEventType(wxEVT_STC_STYLENEEDED,          typeof(StyledTextEvent));
            Event.AddEventType(wxEVT_STC_CHARADDED,            typeof(StyledTextEvent));
            Event.AddEventType(wxEVT_STC_SAVEPOINTREACHED,     typeof(StyledTextEvent));
            Event.AddEventType(wxEVT_STC_SAVEPOINTLEFT,        typeof(StyledTextEvent));
            Event.AddEventType(wxEVT_STC_ROMODIFYATTEMPT,      typeof(StyledTextEvent));
            Event.AddEventType(wxEVT_STC_KEY,                  typeof(StyledTextEvent));
            Event.AddEventType(wxEVT_STC_DOUBLECLICK,          typeof(StyledTextEvent));
            Event.AddEventType(wxEVT_STC_UPDATEUI,             typeof(StyledTextEvent));
            Event.AddEventType(wxEVT_STC_MODIFIED,             typeof(StyledTextEvent));
            Event.AddEventType(wxEVT_STC_MACRORECORD,          typeof(StyledTextEvent));
            Event.AddEventType(wxEVT_STC_MARGINCLICK,          typeof(StyledTextEvent));
            Event.AddEventType(wxEVT_STC_NEEDSHOWN,            typeof(StyledTextEvent));
            //Event.AddEventType(wxEVT_STC_POSCHANGED,           typeof(StyledTextEvent));
            Event.AddEventType(wxEVT_STC_PAINTED,              typeof(StyledTextEvent));
            Event.AddEventType(wxEVT_STC_USERLISTSELECTION,    typeof(StyledTextEvent));
            Event.AddEventType(wxEVT_STC_URIDROPPED,           typeof(StyledTextEvent));
            Event.AddEventType(wxEVT_STC_DWELLSTART,           typeof(StyledTextEvent));
            Event.AddEventType(wxEVT_STC_DWELLEND,             typeof(StyledTextEvent));
            Event.AddEventType(wxEVT_STC_START_DRAG,           typeof(StyledTextEvent));
            Event.AddEventType(wxEVT_STC_DRAG_OVER,            typeof(StyledTextEvent));
            Event.AddEventType(wxEVT_STC_DO_DROP,              typeof(StyledTextEvent));
            Event.AddEventType(wxEVT_STC_ZOOM,                 typeof(StyledTextEvent));
            Event.AddEventType(wxEVT_STC_HOTSPOT_CLICK,        typeof(StyledTextEvent));
            Event.AddEventType(wxEVT_STC_HOTSPOT_DCLICK,       typeof(StyledTextEvent));
            Event.AddEventType(wxEVT_STC_CALLTIP_CLICK,        typeof(StyledTextEvent));
        }


        #region CTor
        public StyledTextCtrl(IntPtr wxObject) 
            : base (wxObject) { }

        public  StyledTextCtrl(Window parent)
            : this(parent, Window.UniqueID, wxDefaultPosition, wxDefaultSize, 0, null) { }

        public  StyledTextCtrl(Window parent, int id)
            : this(parent, id, wxDefaultPosition, wxDefaultSize, 0, null) { }

        public  StyledTextCtrl(Window parent, int id, Point pos)
            : this(parent, id, pos, wxDefaultSize, 0, null) { }

        public  StyledTextCtrl(Window parent, int id, Point pos, Size size)
            : this(parent, id, pos, size, 0, null) { }

        public  StyledTextCtrl(Window parent, int id, Point pos, Size size, WindowStyles style)
            : this(parent, id, pos, size, style, null) { }

        public StyledTextCtrl(Window parent, int id, Point pos, Size size, WindowStyles style, string name)
            : this(parent, id, pos, size, style, wxString.SafeNew(name))
        {
        }
        public StyledTextCtrl(Window parent, int id, Point pos, Size size, WindowStyles style, wxString name)
            : this(wxStyledTextCtrl_ctor(Object.SafePtr(parent), id, pos.X, pos.Y, size.Width, size.Height, (uint)style, Object.SafePtr( name))) { }
	    
	//---------------------------------------------------------------------
	// ctors with self created id
	    
        public  StyledTextCtrl(Window parent, Point pos)
            : this(parent, Window.UniqueID, pos, wxDefaultSize, 0, null) { }

        public  StyledTextCtrl(Window parent, Point pos, Size size)
            : this(parent, Window.UniqueID, pos, size, 0, null) { }

        public StyledTextCtrl(Window parent, Point pos, Size size, WindowStyles style)
            : this(parent, Window.UniqueID, pos, size, style, null) { }

        public StyledTextCtrl(Window parent, Point pos, Size size, WindowStyles style, string name)
	    : this(parent, Window.UniqueID, pos, size, style, name) { }

        protected override void CallDTor()
        {
            if (this.wxObject != IntPtr.Zero)
                wxStyledtextCtrl_dtor(this.wxObject);
        }
        #endregion

        //-----------------------------------------------------------------------------

        public void AddText(string text)
        {
            this.AddText(wxString.SafeNew(text));
        }
        public void AddText(wxString text)
        {
            wxStyledTextCtrl_AddText(wxObject, Object.SafePtr( text));
        }

        public void InsertText(int pos, string text)
        {
            this.InsertText(pos, wxString.SafeNew(text));
        }
        public void InsertText(int pos, wxString text)
        {
            wxStyledTextCtrl_InsertText(wxObject, pos, Object.SafePtr( text));
        }

        //-----------------------------------------------------------------------------

        public void ClearAll()
        {
            wxStyledTextCtrl_ClearAll(wxObject);
        }

        public void ClearDocumentStyle()
        {
            wxStyledTextCtrl_ClearDocumentStyle(wxObject);
        }

        //-----------------------------------------------------------------------------

        public int Length
        {
            get { return wxStyledTextCtrl_GetLength(wxObject); }
        }

        //-----------------------------------------------------------------------------

        public int GetCharAt(int pos)
        {
            return wxStyledTextCtrl_GetCharAt(wxObject, pos);
        }

        //-----------------------------------------------------------------------------

        public int CurrentPos
        {
            get { return wxStyledTextCtrl_GetCurrentPos(wxObject); }
            set { wxStyledTextCtrl_SetCurrentPos(wxObject, value); }
        }

        //-----------------------------------------------------------------------------

        public int Anchor
        {
            get { return wxStyledTextCtrl_GetAnchor(wxObject); }
            set { wxStyledTextCtrl_SetAnchor(wxObject, value); }
        }

        //-----------------------------------------------------------------------------

        public LexerStates GetStyleAt(int pos)
        {
            return (LexerStates)wxStyledTextCtrl_GetStyleAt(wxObject, pos);
        }

        //-----------------------------------------------------------------------------

        public void Redo()
        {
            wxStyledTextCtrl_Redo(wxObject);
        }

        //-----------------------------------------------------------------------------

        public bool UndoCollection
        {
            get { return wxStyledTextCtrl_GetUndoCollection(wxObject); }
            set { wxStyledTextCtrl_SetUndoCollection(wxObject, value); }
        }

        //-----------------------------------------------------------------------------

        public void SelectAll()
        {
            wxStyledTextCtrl_SelectAll(wxObject);
        }

        //-----------------------------------------------------------------------------

        public void SetSavePoint()
        {
            wxStyledTextCtrl_SetSavePoint(wxObject);
        }

        //-----------------------------------------------------------------------------

        public bool CanRedo
        {
            get { return wxStyledTextCtrl_CanRedo(wxObject); }
        }

        //-----------------------------------------------------------------------------

        public int MarkerLineFromHandle(int handle)
        {
            return wxStyledTextCtrl_MarkerLineFromHandle(wxObject, handle);
        }

        public void MarkerDeleteHandle(int handle)
        {
            wxStyledTextCtrl_MarkerDeleteHandle(wxObject, handle);
        }

        //-----------------------------------------------------------------------------

        /** <summary>Defines how to view white spaces.</summary>*/
        public WhiteSpaceModes ViewWhiteSpace
        {
            get { return (WhiteSpaceModes) wxStyledTextCtrl_GetViewWhiteSpace(wxObject); }
            set { wxStyledTextCtrl_SetViewWhiteSpace(wxObject, (int)value); }
        }

        //-----------------------------------------------------------------------------

        /** <summary>Position from a position.
         * This apparently does currently not work. However, this might be a problem of the origin
         * of the coordinates. Mouse positions do not work.</summary>*/
        public int PositionFromPoint(Point pt)
        {
            return wxStyledTextCtrl_PositionFromPoint(wxObject, ref pt);
        }

        public int PositionFromPointClose(int x, int y)
        {
            return wxStyledTextCtrl_PositionFromPointClose(wxObject, x, y);
        }

        //-----------------------------------------------------------------------------

        public void GotoLine(int line)
        {
            wxStyledTextCtrl_GotoLine(wxObject, line);
        }

        //-----------------------------------------------------------------------------

        public void GotoPos(int pos)
        {
            wxStyledTextCtrl_GotoPos(wxObject, pos);
        }

        //-----------------------------------------------------------------------------

        public string CurLine
        {
            get {
                int i;
                return GetCurLine(out i);
            }
        }

        public string GetCurLine(out int linePos)
        {
            linePos = new int();
            return new wxString(wxStyledTextCtrl_GetCurLine(wxObject, ref linePos), true);
        }

        //-----------------------------------------------------------------------------

        public int EndStyled
        {
            get { return wxStyledTextCtrl_GetEndStyled(wxObject); }
        }

        //-----------------------------------------------------------------------------

        public void ConvertEOLs(EOLModes eolMode)
        {
            wxStyledTextCtrl_ConvertEOLs(wxObject, (int)eolMode);
        }

        //-----------------------------------------------------------------------------

        public EOLModes EOLMode
        {
            get { return (EOLModes)wxStyledTextCtrl_GetEOLMode(wxObject); }
            set { wxStyledTextCtrl_SetEOLMode(wxObject, (int)value); }
        }

        //-----------------------------------------------------------------------------

        public void StartStyling(int pos, int mask)
        {
            wxStyledTextCtrl_StartStyling(wxObject, pos, mask);
        }

        //-----------------------------------------------------------------------------

        public void SetStyling(int length, int style)
        {
            wxStyledTextCtrl_SetStyling(wxObject, length, style);
        }

        //-----------------------------------------------------------------------------

        public bool BufferedDraw
        {
            get { return wxStyledTextCtrl_GetBufferedDraw(wxObject); }
            set { wxStyledTextCtrl_SetBufferedDraw(wxObject, value); }
        }

        //-----------------------------------------------------------------------------

        public int TabWidth
        {
            get { return wxStyledTextCtrl_GetTabWidth(wxObject); }
            set { wxStyledTextCtrl_SetTabWidth(wxObject, value); }
        }

        //-----------------------------------------------------------------------------

        public int CodePage
        {
            get { return wxStyledTextCtrl_GetCodePage(wxObject); } 
            set { wxStyledTextCtrl_SetCodePage(wxObject, value); } 
        }

        //-----------------------------------------------------------------------------

        /** <summary>Defines a symbol for the designated marker.
         * \param markerNumber designates a particular marker that is used by this control to display some information.
         * \param markerSymbol is the index of a symbol that shall be used to display the marker.</summary>*/
        public void MarkerDefine(MarkNum markerNumber, Mark markerSymbol)
        {
            this.MarkerDefine(markerNumber, markerSymbol, null, null);
        }

        /** <summary>Defines a symbol for the designated marker.
         * \param markerNumber designates a particular marker that is used by this control to display some information.
         * \param markerSymbol is the index of a symbol that shall be used to display the marker.
         * \param foreground is the foreground colour to be used to draw the marker symbol
         * \param background is the background colour to be used to draw the marker symbol</summary>*/
        public void MarkerDefine(MarkNum markerNumber, Mark markerSymbol, Colour foreground)
        {
            this.MarkerDefine(markerNumber, markerSymbol, foreground, null);
        }

        /** <summary>Defines a symbol for the designated marker.
         * \param markerNumber designates a particular marker that is used by this control to display some information.
         * \param markerSymbol is the index of a symbol that shall be used to display the marker.
         * \param foreground is the foreground colour to be used to draw the marker symbol
         * \param background is the background colour to be used to draw the marker symbol</summary>*/
        public void MarkerDefine(MarkNum markerNumber, Mark markerSymbol, Colour foreground, Colour background)
        {
            wxStyledTextCtrl_MarkerDefine(wxObject, (int)markerNumber, (int)markerSymbol, Object.SafePtr(foreground), Object.SafePtr(background));
        }

        public void MarkerSetForeground(MarkNum markerNumber, Colour fore)
        {
            wxStyledTextCtrl_MarkerSetForeground(wxObject, (int)markerNumber, Object.SafePtr(fore));
        }

        public void MarkerSetBackground(MarkNum markerNumber, Colour back)
        {
            wxStyledTextCtrl_MarkerSetBackground(wxObject, (int)markerNumber, Object.SafePtr(back));
        }

        public int MarkerAdd(int line, MarkNum markerNumber)
        {
            return wxStyledTextCtrl_MarkerAdd(wxObject, line, (int)markerNumber);
        }

        public void MarkerDelete(int line, MarkNum markerNumber)
        {
            wxStyledTextCtrl_MarkerDelete(wxObject, line, (int)markerNumber);
        }

        public void MarkerDeleteAll(MarkNum markerNumber)
        {
            wxStyledTextCtrl_MarkerDeleteAll(wxObject, (int)markerNumber);
        }

        public int MarkerGet(int line)
        {
            return wxStyledTextCtrl_MarkerGet(wxObject, line);
        }

        public int MarkerNext(int lineStart, int markerMask)
        {
            return wxStyledTextCtrl_MarkerNext(wxObject, lineStart, markerMask);
        }

        public int MarkerPrevious(int lineStart, int markerMask)
        {
            return wxStyledTextCtrl_MarkerPrevious(wxObject, lineStart, markerMask);
        }

        public void MarkerDefineBitmap(MarkNum markerNumber, Bitmap bmp)
        {
            wxStyledTextCtrl_MarkerDefineBitmap(wxObject, (int)markerNumber, Object.SafePtr(bmp));
        }

        //-----------------------------------------------------------------------------

        /** <summary>Set a margin to be either numeric or symbolic.
         * Users of this control mey define a number of margins that may display symbols or line numbers etc.</summary>*/
        public void SetMarginType(int marginIndex, MarginType marginType)
        {
            wxStyledTextCtrl_SetMarginType(wxObject, marginIndex, (int)marginType);
        }

        public MarginType GetMarginType(int marginIndex)
        {
            return (MarginType) wxStyledTextCtrl_GetMarginType(wxObject, marginIndex);
        }

        //-----------------------------------------------------------------------------

        /** <summary>Defines margin of the specified type in pixels.
         * Users of this control mey define a number of margins that may display symbols or line numbers etc.</summary>*/
        public void SetMarginWidth(int marginIndex, int pixelWidth)
        {
            wxStyledTextCtrl_SetMarginWidth(wxObject, marginIndex, pixelWidth);
        }

        public int GetMarginWidth(int marginIndex)
        {
            return wxStyledTextCtrl_GetMarginWidth(wxObject, marginIndex);
        }

        //-----------------------------------------------------------------------------

        /** <summary>Set a mask that determines which markers are displayed in a margin.
         * Users of this control mey define a number of margins that may display symbols or line numbers etc.</summary>*/
        public void SetMarginMask(int marginIndex, MarginMask mask)
        {
            wxStyledTextCtrl_SetMarginMask(wxObject, marginIndex, (uint)mask);
        }

        public MarginMask GetMarginMask(int marginIndex)
        {
            return (MarginMask) wxStyledTextCtrl_GetMarginMask(wxObject, marginIndex);
        }

        //-----------------------------------------------------------------------------

        /** <summary>Make a margin sensitive or insensitive to mouse clicks.
         * Users of this control may define a number of margins that may display symbols or line numbers etc.</summary>*/
        public void SetMarginSensitive(int marginIndex, bool sensitive)
        {
            wxStyledTextCtrl_SetMarginSensitive(wxObject, marginIndex, sensitive);
        }

        /** <summary>Return <c>true</c> of the margin of the provided index is sensitive to mouse clicks.</summary>*/
        public bool GetMarginSensitive(int marginIndex)
        {
            return wxStyledTextCtrl_GetMarginSensitive(wxObject, marginIndex);
        }

        //-----------------------------------------------------------------------------

        public void StyleClearAll()
        {
            wxStyledTextCtrl_StyleClearAll(wxObject);
        }

        public void StyleSetForeground(LexerStates style, Colour fore)
        {
            this.StyleSetForeground((int)style, fore);
        }
        void StyleSetForeground(int style, Colour fore)
        {
            wxStyledTextCtrl_StyleSetForeground(wxObject, (int)style, Object.SafePtr(fore));
        }

        public void StyleSetBackground(LexerStates style, Colour fore)
        {
            this.StyleSetBackground((int)style, fore);
        }
        void StyleSetBackground(int style, Colour back)
        {
            wxStyledTextCtrl_StyleSetBackground(wxObject, (int)style, Object.SafePtr(back));
        }

        public void StyleSetBold(LexerStates style, bool fore)
        {
            this.StyleSetBold((int)style, fore);
        }
        void StyleSetBold(int style, bool bold)
        {
            wxStyledTextCtrl_StyleSetBold(wxObject, (int)style, bold);
        }

        public void StyleSetItalic(LexerStates style, bool italic)
        {
            this.StyleSetItalic((int)style, italic);
        }
        void StyleSetItalic(int style, bool italic)
        {
            wxStyledTextCtrl_StyleSetItalic(wxObject, (int)style, italic);
        }

        public void StyleSetSize(LexerStates style, int sizePoints)
        {
            this.StyleSetSize((int)style, sizePoints);
        }
        void StyleSetSize(int style, int sizePoints)
        {
            wxStyledTextCtrl_StyleSetSize(wxObject, (int)style, sizePoints);
        }

        public void StyleSetFaceName(LexerStates style, string fontName)
        {
            this.StyleSetFaceName((int)style, wxString.SafeNew(fontName));
        }
        void StyleSetFaceName(int style, wxString fontName)
        {
            wxStyledTextCtrl_StyleSetFaceName(wxObject, style, Object.SafePtr(fontName));
        }

        public void StyleSetEOLFilled(LexerStates style, bool filled)
        {
            this.StyleSetEOLFilled((int)style, filled);
        }
        void StyleSetEOLFilled(int style, bool filled)
        {
            wxStyledTextCtrl_StyleSetEOLFilled(wxObject, (int)style, filled);
        }

        public void StyleResetDefault()
        {
            wxStyledTextCtrl_StyleResetDefault(wxObject);
        }

        public void StyleSetUnderline(LexerStates style, bool underline)
        {
            this.StyleSetUnderline((int) style, underline);
        }
        void StyleSetUnderline(int style, bool underline)
        {
            wxStyledTextCtrl_StyleSetUnderline(wxObject, style, underline);
        }

        public void StyleSetCase(LexerStates style, CaseForce caseForce)
        {
            this.StyleSetCase((int)style, (int)caseForce);
        }
        void StyleSetCase(int style, int caseForce)
        {
            wxStyledTextCtrl_StyleSetCase(wxObject, style, caseForce);
        }

        public void StyleSetCharacterSet(LexerStates style, CharsetIdentifier characterSet)
        {
            wxStyledTextCtrl_StyleSetCharacterSet(wxObject, (int)style, (int)characterSet);
        }

        public void StyleSetHotSpot(LexerStates style, bool hotspot)
        {
            wxStyledTextCtrl_StyleSetHotSpot(wxObject, (int)style, hotspot);
        }

        public void StyleSetVisible(LexerStates style, bool visible)
        {
            wxStyledTextCtrl_StyleSetVisible(wxObject, (int)style, visible);
        }

        public void StyleSetChangeable(LexerStates style, bool changeable)
        {
            wxStyledTextCtrl_StyleSetChangeable(wxObject, (int)style, changeable);
        }

        //-----------------------------------------------------------------------------

        public void SetSelForeground(bool useSetting, Colour fore)
        {
            wxStyledTextCtrl_SetSelForeground(wxObject, useSetting, Object.SafePtr(fore));
        }

        public void SetSelBackground(bool useSetting, Colour back)
        {
            wxStyledTextCtrl_SetSelBackground(wxObject, useSetting, Object.SafePtr(back));
        }

        //-----------------------------------------------------------------------------

        public Colour CaretForeground
        {
            get { return new Colour(wxStyledTextCtrl_GetCaretForeground(wxObject), true); }
            set { wxStyledTextCtrl_SetCaretForeground(wxObject, Object.SafePtr(value)); } 
        }

        //-----------------------------------------------------------------------------

        public void CmdKeyAssign(int key, int modifiers, int cmd)
        {
            wxStyledTextCtrl_CmdKeyAssign(wxObject, key, modifiers, cmd);
        }

        public void CmdKeyClear(int key, int modifiers)
        {
            wxStyledTextCtrl_CmdKeyClear(wxObject, key, modifiers);
        }

        public void CmdKeyClearAll()
        {
            wxStyledTextCtrl_CmdKeyClearAll(wxObject);
        }

        //-----------------------------------------------------------------------------

        public void SetStyleBytes(int length, byte[] styleBytes)
        {
            wxStyledTextCtrl_SetStyleBytes(wxObject, length, styleBytes);
        }

        //-----------------------------------------------------------------------------

        public int CaretPeriod
        {
            get { return wxStyledTextCtrl_GetCaretPeriod(wxObject); }
            set { wxStyledTextCtrl_SetCaretPeriod(wxObject, value); } 
        }

        //-----------------------------------------------------------------------------

        public void SetWordChars(string characters)
        {
            this.SetWordChars(wxString.SafeNew(characters));
        }
        public void SetWordChars(wxString characters)
        {
            wxStyledTextCtrl_SetWordChars(wxObject, Object.SafePtr( characters));
        }

        //-----------------------------------------------------------------------------

        public void BeginUndoAction()
        {
            wxStyledTextCtrl_BeginUndoAction(wxObject);
        }

        public void EndUndoAction()
        {
            wxStyledTextCtrl_EndUndoAction(wxObject);
        }

        //-----------------------------------------------------------------------------

        public void IndicatorSetStyle(int indic, int style)
        {
            wxStyledTextCtrl_IndicatorSetStyle(wxObject, indic, style);
        }

        public int IndicatorGetStyle(int indic)
        {
            return wxStyledTextCtrl_IndicatorGetStyle(wxObject, indic);
        }

        public void IndicatorSetForeground(int indic, Colour fore)
        {
            wxStyledTextCtrl_IndicatorSetForeground(wxObject, indic, Object.SafePtr(fore));
        }

        public Colour IndicatorGetForeground(int indic)
        {
            return new Colour(wxStyledTextCtrl_IndicatorGetForeground(wxObject, indic), true);
        }

        //-----------------------------------------------------------------------------

        public void SetWhitespaceForeground(bool useSetting, Colour fore)
        {
            wxStyledTextCtrl_SetWhitespaceForeground(wxObject, useSetting, Object.SafePtr(fore));
        }

        public void SetWhitespaceBackground(bool useSetting, Colour back)
        {
            wxStyledTextCtrl_SetWhitespaceBackground(wxObject, useSetting, Object.SafePtr(back));
        }

        //-----------------------------------------------------------------------------

        public int styleBits
        {
            get { return wxStyledTextCtrl_GetStyleBits(wxObject); }
            set { wxStyledTextCtrl_SetStyleBits(wxObject, value); }
        }

        //-----------------------------------------------------------------------------

        public void SetLineState(int line, int state)
        {
            wxStyledTextCtrl_SetLineState(wxObject, line, state);
        }

        public int GetLineState(int line)
        {
            return wxStyledTextCtrl_GetLineState(wxObject, line);
        }

        //-----------------------------------------------------------------------------

        public int MaxLineState
        {
            get { return wxStyledTextCtrl_GetMaxLineState(wxObject); }
        }

        //-----------------------------------------------------------------------------

        public bool CaretLineVisible
        {
            get { return wxStyledTextCtrl_GetCaretLineVisible(wxObject); }
            set { wxStyledTextCtrl_SetCaretLineVisible(wxObject, value); }
        }

        //-----------------------------------------------------------------------------

        public Colour CaretLineBack
        {
            get { return new Colour(wxStyledTextCtrl_GetCaretLineBack(wxObject), true); } 
            set { wxStyledTextCtrl_SetCaretLineBack(wxObject, Object.SafePtr(value)); }
        }

        //-----------------------------------------------------------------------------

        /** <summary>Display a auto-completion list.
          * The lenEntered parameter indicates how many characters before
          * the caret should be used to provide context.</summary>*/
        public void AutoCompShow(int lenEntered, string itemList)
        {
            this.AutoCompShow(lenEntered, wxString.SafeNew(itemList));
        }
        /** <summary>Display a auto-completion list.
          * The lenEntered parameter indicates how many characters before
          * the caret should be used to provide context.</summary>*/
        public void AutoCompShow(int lenEntered, wxString itemList)
        {
            wxStyledTextCtrl_AutoCompShow(wxObject, lenEntered, Object.SafePtr(itemList));
        }

        /** <summary>Remove the auto-completion list from the screen.</summary>*/
        public void AutoCompCancel()
        {
            wxStyledTextCtrl_AutoCompCancel(wxObject);
        }

        /** <summary>Is there an auto-completion list visible?</summary>*/
        public bool AutoCompActive
        {
            get { return wxStyledTextCtrl_AutoCompActive(wxObject); }
        }

        /** <summary>Retrieve the position of the caret when the auto-completion list was displayed.</summary>*/
        public int AutoCompPosStart
        {
            get { return wxStyledTextCtrl_AutoCompPosStart(wxObject); } 
        }

        /** <summary>User has selected an item so remove the list and insert the selection.</summary>*/
        public void AutoCompComplete()
        {
            wxStyledTextCtrl_AutoCompComplete(wxObject);
        }

        /** <summary>Define a set of character that when typed cancel the auto-completion list.</summary>*/
        public string AutoCompStops
        {
            set
            {
                wxString wxvalue = wxString.SafeNew(value);
                wxStyledTextCtrl_AutoCompStops(wxObject, Object.SafePtr(wxvalue));
            }
        }

        /** <summary>Gets or changes the separator character in the string setting up an auto-completion list.
         * Default is space but can be changed if items contain space.</summary>*/
        public char AutoCompSeparator
        {
            get { return (char)wxStyledTextCtrl_AutoCompGetSeparator(wxObject); }
            set { wxStyledTextCtrl_AutoCompSetSeparator(wxObject, (int)value); } 
        }

        /** <summary>Select the item in the auto-completion list that starts with a string.</summary>*/
        public void AutoCompSelect(string text)
        {
            this.AutoCompSelect(wxString.SafeNew(text));
        }
        /** <summary>Select the item in the auto-completion list that starts with a string.</summary>*/
        public void AutoCompSelect(wxString text)
        {
            wxStyledTextCtrl_AutoCompSelect(wxObject, Object.SafePtr( text));
        }

        /** <summary>Should the auto-completion list be cancelled if the user backspaces to a
         * position before where the box was created.</summary>*/
        public bool AutoCompCancelAtStart
        {
            get { return wxStyledTextCtrl_AutoCompGetCancelAtStart(wxObject); }
            set { wxStyledTextCtrl_AutoCompSetCancelAtStart(wxObject, value); } 
        }

        /** <summary>Defines a set of characters that when typed will cause the autocompletion to
         * choose the selected item.</summary>*/
        public string AutoCompFillUps
        {
            set
            {
                wxString wxvalue = wxString.SafeNew(value);
                wxStyledTextCtrl_AutoCompSetFillUps(wxObject, Object.SafePtr(wxvalue));
            }
        }

        /** <summary>Should a single item auto-completion list automatically choose the item.</summary>*/
        public bool AutoCompChooseSingle
        {
            get { return wxStyledTextCtrl_AutoCompGetChooseSingle(wxObject); }
            set { wxStyledTextCtrl_AutoCompSetChooseSingle(wxObject, value); }
        }

        /** <summary>Retrieve whether a single item auto-completion list automatically choose the item.</summary>*/
        public bool AutoCompIgnoreCase
        {
            get { return wxStyledTextCtrl_AutoCompGetIgnoreCase(wxObject); }
            set { wxStyledTextCtrl_AutoCompSetIgnoreCase(wxObject, value); } 
        }

        /** <summary>Set whether case is significant when performing auto-completion searches.</summary>*/
        public bool AutoCompAutoHide
        {
            set { wxStyledTextCtrl_AutoCompSetAutoHide(wxObject, value); }
            get { return wxStyledTextCtrl_AutoCompGetAutoHide(wxObject); }
        }

        /** <summary>Retrieve whether or not autocompletion deletes any word characters
         * after the inserted text upon completion.</summary>*/
        public bool AutoCompDropRestOfWord
        {
            set { wxStyledTextCtrl_AutoCompSetDropRestOfWord(wxObject, value); }
            get { return wxStyledTextCtrl_AutoCompGetDropRestOfWord(wxObject); } 
        }

        /** <summary>Retrieve the auto-completion list type-separator character.</summary>*/
        public int AutoCompTypeSeparator
        {
            get { return wxStyledTextCtrl_AutoCompGetTypeSeparator(wxObject); }
            set { wxStyledTextCtrl_AutoCompSetTypeSeparator(wxObject, value); }
        }

        //-----------------------------------------------------------------------------

        /** <summary>Display a list of strings and send notification when user chooses one.</summary>*/
        public void UserListShow(int listType, string itemList)
        {
            this.UserListShow(listType, wxString.SafeNew(itemList));
        }
        /** <summary>Display a list of strings and send notification when user chooses one.</summary>*/
        public void UserListShow(int listType, wxString itemList)
        {
            wxStyledTextCtrl_UserListShow(wxObject, listType, Object.SafePtr( itemList));
        }

        //-----------------------------------------------------------------------------

        public void RegisterImage(int type, Bitmap bmp)
        {
            wxStyledTextCtrl_RegisterImage(wxObject, type, Object.SafePtr(bmp));
        }

        public void ClearRegisteredImages()
        {
            wxStyledTextCtrl_ClearRegisteredImages(wxObject);
        }

        //-----------------------------------------------------------------------------

        public int Indent
        {
            get { return wxStyledTextCtrl_GetIndent(wxObject); }
            set { wxStyledTextCtrl_SetIndent(wxObject, value); }
        }

        //-----------------------------------------------------------------------------

        /** <summary>Indentation will only use space characters if useTabs is false, otherwise
         * it will use a combination of tabs and spaces.</summary>*/
        public bool UseTabs
        {
            get { return wxStyledTextCtrl_GetUseTabs(wxObject); }
            set { wxStyledTextCtrl_SetUseTabs(wxObject, value); }
        }

        //-----------------------------------------------------------------------------

        public void SetLineIndentation(int line, int indentSize)
        {
            wxStyledTextCtrl_SetLineIndentation(wxObject, line, indentSize);
        }

        public int GetLineIndentation(int line)
        {
            return wxStyledTextCtrl_GetLineIndentation(wxObject, line);
        }

        //-----------------------------------------------------------------------------

        public int GetLineIndentPosition(int line)
        {
            return wxStyledTextCtrl_GetLineIndentPosition(wxObject, line);
        }

        //-----------------------------------------------------------------------------

        public int GetColumn(int pos)
        {
            return wxStyledTextCtrl_GetColumn(wxObject, pos);
        }

        //-----------------------------------------------------------------------------

        public bool UseHorizontalScrollBar
        {
            set { wxStyledTextCtrl_SetUseHorizontalScrollBar(wxObject, value); }
            get { return wxStyledTextCtrl_GetUseHorizontalScrollBar(wxObject); }
        }

        //-----------------------------------------------------------------------------

        public bool IndentationGuides
        {
            set { wxStyledTextCtrl_SetIndentationGuides(wxObject, value); }
            get { return wxStyledTextCtrl_GetIndentationGuides(wxObject); }
        }

        //-----------------------------------------------------------------------------

        public int HighlightGuide
        {
            get { return wxStyledTextCtrl_GetHighlightGuide(wxObject); }
            set { wxStyledTextCtrl_SetHighlightGuide(wxObject, value); }
        }

        //-----------------------------------------------------------------------------

        public int GetLineEndPosition(int line)
        {
            return wxStyledTextCtrl_GetLineEndPosition(wxObject, line);
        }

        //-----------------------------------------------------------------------------

        public bool ReadOnly
        {
            get { return wxStyledTextCtrl_GetReadOnly(wxObject); }
            set { wxStyledTextCtrl_SetReadOnly(wxObject, value); }
        }

        //-----------------------------------------------------------------------------

        public int SelectionStart
        {
            get { return wxStyledTextCtrl_GetSelectionStart(wxObject); } 
            set { wxStyledTextCtrl_SetSelectionStart(wxObject, value); }
        }

        public int SelectionEnd
        {
            get { return wxStyledTextCtrl_GetSelectionEnd(wxObject); }
            set { wxStyledTextCtrl_SetSelectionEnd(wxObject, value); }
        }

        //-----------------------------------------------------------------------------

        public int PrintMagnification
        {
            get { return wxStyledTextCtrl_GetPrintMagnification(wxObject); }
            set { wxStyledTextCtrl_SetPrintMagnification(wxObject, value); }
        }

        public int PrintColourMode
        {
            get { return wxStyledTextCtrl_GetPrintColourMode(wxObject); }
            set { wxStyledTextCtrl_SetPrintColourMode(wxObject, value); } 
        }

        //-----------------------------------------------------------------------------

        public int FindText(int minPos, int maxPos, string text, int flags)
        {
            return this.FindText(minPos, maxPos, wxString.SafeNew(text), flags);
        }
        public int FindText(int minPos, int maxPos, wxString text, int flags)
        {
            return wxStyledTextCtrl_FindText(wxObject, minPos, maxPos, Object.SafePtr( text), flags);
        }

        //-----------------------------------------------------------------------------

        public int FormatRange(bool doDraw, int startPos, int endPos, DC draw, DC target, Rectangle renderRect, Rectangle pageRect)
        {
            return wxStyledTextCtrl_FormatRange(wxObject, doDraw, startPos, endPos, Object.SafePtr(draw), Object.SafePtr(target), ref renderRect, ref pageRect);
        }

        //-----------------------------------------------------------------------------

        public int FirstVisibleLine
        {
            get { return wxStyledTextCtrl_GetFirstVisibleLine(wxObject); }
        }

        //-----------------------------------------------------------------------------

        public string GetLine(int line)
        {
            return new wxString(wxStyledTextCtrl_GetLine(wxObject, line), true);
        }

        //-----------------------------------------------------------------------------

        public int LineCount
        {
            get { return wxStyledTextCtrl_GetLineCount(wxObject); }
        }

        //-----------------------------------------------------------------------------

        public int MarginLeft
        {
            get { return wxStyledTextCtrl_GetMarginLeft(wxObject); }
            set { wxStyledTextCtrl_SetMarginLeft(wxObject, value); }
        }

        public int MarginRight
        {
            get { return wxStyledTextCtrl_GetMarginRight(wxObject); }
            set { wxStyledTextCtrl_SetMarginRight(wxObject, value); }
        }

        //-----------------------------------------------------------------------------

        /** <summary>True if this contains unsafed changes.</summary>*/
        public bool Modify
        {
            get { return wxStyledTextCtrl_GetModify(wxObject); }
        }

        //-----------------------------------------------------------------------------

        public void SetSelection(int start, int end)
        {
            wxStyledTextCtrl_SetSelection(wxObject, start, end);
        }

        public string SelectedText
        {
            get { return new wxString(wxStyledTextCtrl_GetSelectedText(wxObject), true); }
        }

        //-----------------------------------------------------------------------------

        public string GetTextRange(int startPos, int endPos)
        {
            return new wxString(wxStyledTextCtrl_GetTextRange(wxObject, startPos, endPos), true);
        }

        //-----------------------------------------------------------------------------

        public bool HideSelection
        {
            set { wxStyledTextCtrl_HideSelection(wxObject, value); } 
        }

        //-----------------------------------------------------------------------------

        public int LineFromPosition(int pos)
        {
            return wxStyledTextCtrl_LineFromPosition(wxObject, pos);
        }

        public int PositionFromLine(int line)
        {
            return wxStyledTextCtrl_PositionFromLine(wxObject, line);
        }

        //-----------------------------------------------------------------------------

        public void LineScroll(int columns, int lines)
        {
            wxStyledTextCtrl_LineScroll(wxObject, columns, lines);
        }

        //-----------------------------------------------------------------------------

        public void EnsureCaretVisible()
        {
            wxStyledTextCtrl_EnsureCaretVisible(wxObject);
        }

        //-----------------------------------------------------------------------------

        public void ReplaceSelection(string text)
        {
            this.ReplaceSelection(wxString.SafeNew(text));
        }
        public void ReplaceSelection(wxString text)
        {
            wxStyledTextCtrl_ReplaceSelection(wxObject, Object.SafePtr(text));
        }

        //-----------------------------------------------------------------------------

        public bool CanPaste
        {
            get { return wxStyledTextCtrl_CanPaste(wxObject); } 
        }

        public bool CanUndo
        {
            get { return wxStyledTextCtrl_CanUndo(wxObject); }
        }

        //-----------------------------------------------------------------------------

        public void EmptyUndoBuffer()
        {
            wxStyledTextCtrl_EmptyUndoBuffer(wxObject);
        }

        //-----------------------------------------------------------------------------

        public void Undo()
        {
            wxStyledTextCtrl_Undo(wxObject);
        }

        public void Cut()
        {
            wxStyledTextCtrl_Cut(wxObject);
        }

        public void Copy()
        {
            wxStyledTextCtrl_Copy(wxObject);
        }

        public void Paste()
        {
            wxStyledTextCtrl_Paste(wxObject);
        }

        public void Clear()
        {
            wxStyledTextCtrl_Clear(wxObject);
        }

        //-----------------------------------------------------------------------------

        public string Text
        {
            set
            {
                wxString wxvalue = wxString.SafeNew(value);
                wxStyledTextCtrl_SetText(wxObject, Object.SafePtr(wxvalue));
            } 
            get { return new wxString(wxStyledTextCtrl_GetText(wxObject), true); }
        }

        //-----------------------------------------------------------------------------

        public int TextLength
        {
            get { return wxStyledTextCtrl_GetTextLength(wxObject); }
        }

        //-----------------------------------------------------------------------------

        /** <summary>Read or set overtype mode (in contrast to insert mode).</summary>*/
        public bool Overtype
        {
            get { return wxStyledTextCtrl_GetOvertype(wxObject); }
            set { wxStyledTextCtrl_SetOvertype(wxObject, value); }
        }

        //-----------------------------------------------------------------------------

        public int CaretWidth
        {
            get { return wxStyledTextCtrl_GetCaretWidth(wxObject); } 
            set { wxStyledTextCtrl_SetCaretWidth(wxObject, value); }
        }

        //-----------------------------------------------------------------------------

        public int TargetStart
        {
            get { return wxStyledTextCtrl_GetTargetStart(wxObject); }
            set { wxStyledTextCtrl_SetTargetStart(wxObject, value); }
        }

        public int TargetEnd
        {
            get { return wxStyledTextCtrl_GetTargetEnd(wxObject); }
            set { wxStyledTextCtrl_SetTargetEnd(wxObject, value); } 
        }

        public int ReplaceTarget(string text)
        {
            return this.ReplaceTarget(wxString.SafeNew(text));
        }
        public int ReplaceTarget(wxString text)
        {
            return wxStyledTextCtrl_ReplaceTarget(wxObject, Object.SafePtr( text));
        }

        public int ReplaceTargetRE(string text)
        {
            return this.ReplaceTargetRE(wxString.SafeNew(text));
        }
        public int ReplaceTargetRE(wxString text)
        {
            return wxStyledTextCtrl_ReplaceTargetRE(wxObject, Object.SafePtr( text));
        }

        public int SearchInTarget(string text)
        {
            return this.SearchInTarget(wxString.SafeNew(text));
        }
        public int SearchInTarget(wxString text)
        {
            return wxStyledTextCtrl_SearchInTarget(wxObject, Object.SafePtr( text));
        }

        //-----------------------------------------------------------------------------

        public int SetSearchFlags
        {
            get { return wxStyledTextCtrl_GetSearchFlags(wxObject); }
            set { wxStyledTextCtrl_SetSearchFlags(wxObject, value); }
        }

        //-----------------------------------------------------------------------------

        /** <summary>Show a call tip containing a definition near position pos.
         * Prerequisite: CallTipUseStyle().</summary>*/
        public void CallTipShow(int pos, string definition)
        {
            this.CallTipShow(pos, wxString.SafeNew(definition));
        }
        /** <summary>Show a call tip containing a definition near position pos.
         * Prerequisite: CallTipUseStyle().</summary>*/
        public void CallTipShow(int pos, wxString definition)
        {
            wxStyledTextCtrl_CallTipShow(wxObject, pos, Object.SafePtr( definition));
        }

        /** <summary>Remove the call tip from the screen.</summary>*/
        public void CallTipCancel()
        {
            wxStyledTextCtrl_CallTipCancel(wxObject);
        }

        public bool CallTipActive
        {
            get { return wxStyledTextCtrl_CallTipActive(wxObject); }
        }

        public int CallTipPosAtStart
        {
            get { return wxStyledTextCtrl_CallTipPosAtStart(wxObject); }
        }

        public void CallTipSetHighlight(int start, int end)
        {
            wxStyledTextCtrl_CallTipSetHighlight(wxObject, start, end);
        }

        public Colour CallTipBackground
        {
            set { wxStyledTextCtrl_CallTipSetBackground(wxObject, Object.SafePtr(value)); }
        }

        public Colour CallTipForeground
        {
            set { wxStyledTextCtrl_CallTipSetForeground(wxObject, Object.SafePtr(value)); } 
        }

        public Colour CallTipForegroundHighlight
        {
            set { wxStyledTextCtrl_CallTipSetForegroundHighlight(wxObject, Object.SafePtr(value)); }
        }

        /** <summary>Enable use of STYLE_CALLTIP and set call tip tab size in pixels.</summary>*/
        public void CallTipUseStyle(int tabsize)
        {
            wxStyledTextCtrl_CallTipUseStyle(this.wxObject, tabsize);
        }

        //-----------------------------------------------------------------------------

        public int VisibleFromDocLine(int line)
        {
            return wxStyledTextCtrl_VisibleFromDocLine(wxObject, line);
        }

        public int DocLineFromVisible(int lineDisplay)
        {
            return wxStyledTextCtrl_DocLineFromVisible(wxObject, lineDisplay);
        }

        //-----------------------------------------------------------------------------

        /** <summary>Sets the fold level of the designated line.</summary>*/
        public void SetFoldLevel(int line, int level)
        {
            wxStyledTextCtrl_SetFoldLevel(wxObject, line, level);
        }

        /** <summary>The flags in GetFoldLevel().</summary>*/
        public FoldLevel GetFoldLevelFlags(int line)
        {
            return (FoldLevel)(GetFoldLevel(line) & ((int)FoldLevel.FLAGSMASK));
        }

        /** <summary>Fold level number in GetFoldLevel().</summary>*/
        public int GetFoldLevelNumber(int line)
        {
            return (GetFoldLevel(line) & ((int)FoldLevel.NUMBERMASK)) - ((int)FoldLevel.BASE);
        }

        /** <summary>Gets the fold level of the designated line.
         * The result indicates whether this line starts a folded region or not.
         * 
         * Refer to FoldLevel for the documentation of flags.
         *</summary>*/
        public int GetFoldLevel(int line)
        {
            return wxStyledTextCtrl_GetFoldLevel(wxObject, line);
        }

        public int GetLastChild(int line, int level)
        {
            return wxStyledTextCtrl_GetLastChild(wxObject, line, level);
        }

        /** <summary>Returns the line that is the parent of <c>line</c> wrt folding.</summary>*/
        public int GetFoldParent(int line)
        {
            return wxStyledTextCtrl_GetFoldParent(wxObject, line);
        }

        //-----------------------------------------------------------------------------

        public void ShowLines(int lineStart, int lineEnd)
        {
            wxStyledTextCtrl_ShowLines(wxObject, lineStart, lineEnd);
        }

        public void HideLines(int lineStart, int lineEnd)
        {
            wxStyledTextCtrl_HideLines(wxObject, lineStart, lineEnd);
        }

        public bool GetLineVisible(int line)
        {
            return wxStyledTextCtrl_GetLineVisible(wxObject, line);
        }

        //-----------------------------------------------------------------------------

        /** <summary>Contract or expand fold below <c>line</c> (<c>line</c> must denote header line).
        * Use ToggleFold().</summary>*/
        public void SetFoldExpanded(int line, bool expanded)
        {
            wxStyledTextCtrl_SetFoldExpanded(wxObject, line, expanded);
        }

        /** <summary>Result indicates whether fold with header line <c>line</c> is expanded or contracted.</summary>*/
        public bool GetFoldExpanded(int line)
        {
            return wxStyledTextCtrl_GetFoldExpanded(wxObject, line);
        }

        /** <summary>Toggles fold at <c>line</c>.
        * The GetFoldLevelFlags(line) must contain FoldLevel.HEADERFLAG.
        * This will fold up if the fold is expanded. This will fold down otherwise.</summary>*/
        public void ToggleFold(int line)
        {
            wxStyledTextCtrl_ToggleFold(wxObject, line);
        }

        public void EnsureVisible(int line)
        {
            wxStyledTextCtrl_EnsureVisible(wxObject, line);
        }

        //-----------------------------------------------------------------------------

        /** <summary>Defines some flags for folding.
         * Do not forget to define markers in order to configure a fine looking folding capability.</summary>*/
        public TheFoldFlags FoldFlags
        {
            set { wxStyledTextCtrl_SetFoldFlags(wxObject, (int)value); }
        }

        //-----------------------------------------------------------------------------

        public void EnsureVisibleEnforcePolicy(int line)
        {
            wxStyledTextCtrl_EnsureVisibleEnforcePolicy(wxObject, line);
        }

        //-----------------------------------------------------------------------------

        public bool TabIndents
        {
            get { return wxStyledTextCtrl_GetTabIndents(wxObject); }
            set { wxStyledTextCtrl_SetTabIndents(wxObject, value); }
        }

        //-----------------------------------------------------------------------------

        public bool BackSpaceUnIndents
        {
            get { return wxStyledTextCtrl_GetBackSpaceUnIndents(wxObject); }
            set { wxStyledTextCtrl_SetBackSpaceUnIndents(wxObject, value); }
        }

        //-----------------------------------------------------------------------------

        public int MouseDwellTime
        {
            set { wxStyledTextCtrl_SetMouseDwellTime(wxObject, value); }
            get { return wxStyledTextCtrl_GetMouseDwellTime(wxObject); }
        }

        //-----------------------------------------------------------------------------

        public int WordStartPosition(int pos, bool onlyWordCharacters)
        {
            return wxStyledTextCtrl_WordStartPosition(wxObject, pos, onlyWordCharacters);
        }

        public int WordEndPosition(int pos, bool onlyWordCharacters)
        {
            return wxStyledTextCtrl_WordEndPosition(wxObject, pos, onlyWordCharacters);
        }

        //-----------------------------------------------------------------------------

        public WrapModes WrapMode
        {
            get { return (WrapModes)wxStyledTextCtrl_GetWrapMode(wxObject); }
            set { wxStyledTextCtrl_SetWrapMode(wxObject, (int)value); }
        }

        //-----------------------------------------------------------------------------

        public LayoutCacheModes LayoutCache
        {
            set { wxStyledTextCtrl_SetLayoutCache(wxObject, (int)value); }
            get { return (LayoutCacheModes) wxStyledTextCtrl_GetLayoutCache(wxObject); }
        }

        //-----------------------------------------------------------------------------

        public int ScrollWidth
        {
            get { return wxStyledTextCtrl_GetScrollWidth(wxObject); }
            set { wxStyledTextCtrl_SetScrollWidth(wxObject, value); }
        }

        //-----------------------------------------------------------------------------

        public int TextWidth(int style, string text)
        {
            return this.TextWidth(style, wxString.SafeNew(text));
        }
        public int TextWidth(int style, wxString text)
        {
            return wxStyledTextCtrl_TextWidth(wxObject, style, Object.SafePtr( text));
        }

        //-----------------------------------------------------------------------------

        public bool EndAtLastLine
        {
            get { return (bool)wxStyledTextCtrl_GetEndAtLastLine(wxObject); }
            set { wxStyledTextCtrl_SetEndAtLastLine(wxObject, value); }
        }

        //-----------------------------------------------------------------------------

        public int TextHeight(int line)
        {
            return wxStyledTextCtrl_TextHeight(wxObject, line);
        }

        //-----------------------------------------------------------------------------

        public bool UseVerticalScrollBar
        {
            get { return wxStyledTextCtrl_GetUseVerticalScrollBar(wxObject); }
            set { wxStyledTextCtrl_SetUseVerticalScrollBar(wxObject, value); }
        }

        //-----------------------------------------------------------------------------


        public void AppendText(string text)
        {
            this.AppendText(wxString.SafeNew(text));
        }
	    public void AppendText(wxString text)
	    {
		    wxStyledTextCtrl_AppendText(wxObject, Object.SafePtr(text));
	    }

        //-----------------------------------------------------------------------------

        public bool TwoPhaseDraw
        {
            get { return wxStyledTextCtrl_GetTwoPhaseDraw(wxObject); } 
            set { wxStyledTextCtrl_SetTwoPhaseDraw(wxObject, value); }
        }

        //-----------------------------------------------------------------------------

        public void TargetFromSelection()
        {
            wxStyledTextCtrl_TargetFromSelection(wxObject);
        }

        //-----------------------------------------------------------------------------

        public void LinesJoin()
        {
            wxStyledTextCtrl_LinesJoin(wxObject);
        }

        public void LinesSplit(int pixelWidth)
        {
            wxStyledTextCtrl_LinesSplit(wxObject, pixelWidth);
        }

        //-----------------------------------------------------------------------------

        public void SetFoldMarginColour(bool useSetting, Colour back)
        {
            wxStyledTextCtrl_SetFoldMarginColour(wxObject, useSetting, Object.SafePtr(back));
        }

        public void SetFoldMarginHiColour(bool useSetting, Colour fore)
        {
            wxStyledTextCtrl_SetFoldMarginHiColour(wxObject, useSetting, Object.SafePtr(fore));
        }

        //-----------------------------------------------------------------------------

        public void LineDuplicate()
        {
            wxStyledTextCtrl_LineDuplicate(wxObject);
        }

        //-----------------------------------------------------------------------------

        public void HomeDisplay()
        {
            wxStyledTextCtrl_HomeDisplay(wxObject);
        }

        public void HomeDisplayExtend()
        {
            wxStyledTextCtrl_HomeDisplayExtend(wxObject);
        }

        //-----------------------------------------------------------------------------

        public void LineEndDisplay()
        {
            wxStyledTextCtrl_LineEndDisplay(wxObject);
        }

        public void LineEndDisplayExtend()
        {
            wxStyledTextCtrl_LineEndDisplayExtend(wxObject);
        }

        //-----------------------------------------------------------------------------

        public void MoveCaretInsideView()
        {
            wxStyledTextCtrl_MoveCaretInsideView(wxObject);
        }

        //-----------------------------------------------------------------------------

        public int LineLength(int line)
        {
            return wxStyledTextCtrl_LineLength(wxObject, line);
        }

        //-----------------------------------------------------------------------------

        public void BraceHighlight(int pos1, int pos2)
        {
            wxStyledTextCtrl_BraceHighlight(wxObject, pos1, pos2);
        }

        public void BraceBadLight(int pos)
        {
            wxStyledTextCtrl_BraceBadLight(wxObject, pos);
        }

        public int BraceMatch(int pos)
        {
            return wxStyledTextCtrl_BraceMatch(wxObject, pos);
        }

        //-----------------------------------------------------------------------------

        public bool ViewEOL
        {
            get { return wxStyledTextCtrl_GetViewEOL(wxObject); }
            set { wxStyledTextCtrl_SetViewEOL(wxObject, value); } 
        }

        //-----------------------------------------------------------------------------

        // Not really usable yet, unless sharing documents between styled
        // text controls (?)

        public Object DocPointer
        {
            get { return FindObject(wxStyledTextCtrl_GetDocPointer(wxObject)); }
            set { wxStyledTextCtrl_SetDocPointer(wxObject, Object.SafePtr(value)); }
        }

        //-----------------------------------------------------------------------------

        public int ModEventMask
        {
            get { return wxStyledTextCtrl_GetModEventMask(wxObject); } 
            set { wxStyledTextCtrl_SetModEventMask(wxObject, value); }
        }

        //-----------------------------------------------------------------------------

        public int EdgeColumn
        {
            get { return wxStyledTextCtrl_GetEdgeColumn(wxObject); }
            set { wxStyledTextCtrl_SetEdgeColumn(wxObject, value); }
        }

        //-----------------------------------------------------------------------------

        public EdgeModes EdgeMode
        {
            get { return (EdgeModes)wxStyledTextCtrl_GetEdgeMode(wxObject); } 
            set { wxStyledTextCtrl_SetEdgeMode(wxObject, (int)value); }
        }

        //-----------------------------------------------------------------------------

        public Colour EdgeColour
        {
            get { return new Colour(wxStyledTextCtrl_GetEdgeColour(wxObject), true); } 
            set { wxStyledTextCtrl_SetEdgeColour(wxObject, Object.SafePtr(value)); }
        }

        //-----------------------------------------------------------------------------

        public void SearchAnchor()
        {
            wxStyledTextCtrl_SearchAnchor(wxObject);
        }

        public int SearchNext(int flags, string text)
        {
            return this.SearchNext(flags, wxString.SafeNew(text));
        }
        public int SearchNext(int flags, wxString text)
        {
            return wxStyledTextCtrl_SearchNext(wxObject, flags, Object.SafePtr(text));
        }

        public int SearchPrev(int flags, string text)
        {
            return this.SearchPrev(flags, wxString.SafeNew(text));
        }
        public int SearchPrev(int flags, wxString text)
        {
            return wxStyledTextCtrl_SearchPrev(wxObject, flags, Object.SafePtr(text));
        }

        //-----------------------------------------------------------------------------

        public int LinesOnScreen
        {
            get { return wxStyledTextCtrl_LinesOnScreen(wxObject); }
        }

        //-----------------------------------------------------------------------------

        public bool UsePopUp
        {
            set { wxStyledTextCtrl_UsePopUp(wxObject, value); }
        }

        //-----------------------------------------------------------------------------

        public bool SelectionIsRectangle
        {
            get { return wxStyledTextCtrl_SelectionIsRectangle(wxObject); }
        }

        //-----------------------------------------------------------------------------

        public int Zoom
        {
            get { return wxStyledTextCtrl_GetZoom(wxObject); }
            set { wxStyledTextCtrl_SetZoom(wxObject, value); }
        }

        //-----------------------------------------------------------------------------

        public void CreateDocument()
        {
            wxStyledTextCtrl_CreateDocument(wxObject);
        }

        public void AddRefDocument(Object docPointer)
        {
            wxStyledTextCtrl_AddRefDocument(wxObject, Object.SafePtr(docPointer));
        }

        public void ReleaseDocument(Object docPointer)
        {
            wxStyledTextCtrl_ReleaseDocument(wxObject, Object.SafePtr(docPointer));
        }

        //-----------------------------------------------------------------------------

        public bool STCFocus
        {
            get { return wxStyledTextCtrl_GetSTCFocus(wxObject); } 
            set { wxStyledTextCtrl_SetSTCFocus(wxObject, value); }
        }

        //-----------------------------------------------------------------------------

        public int Status
        {
            get { return wxStyledTextCtrl_GetStatus(wxObject); }
            set { wxStyledTextCtrl_SetStatus(wxObject, value); }
        }

        //-----------------------------------------------------------------------------

        public bool MouseDownCaptures
        {
            get { return wxStyledTextCtrl_GetMouseDownCaptures(wxObject); }
            set { wxStyledTextCtrl_SetMouseDownCaptures(wxObject, value); }
        }

        //-----------------------------------------------------------------------------

        public STCCursors STCCursor
        {
            set { wxStyledTextCtrl_SetSTCCursor(wxObject,(int) value); }
            get { return (STCCursors) wxStyledTextCtrl_GetSTCCursor(wxObject); }
        }

        //-----------------------------------------------------------------------------

        public int ControlCharSymbol
        {
            set { wxStyledTextCtrl_SetControlCharSymbol(wxObject, value); }
            get { return wxStyledTextCtrl_GetControlCharSymbol(wxObject); }
        }

        //-----------------------------------------------------------------------------

        public void WordPartLeft()
        {
            wxStyledTextCtrl_WordPartLeft(wxObject);
        }

        public void WordPartLeftExtend()
        {
            wxStyledTextCtrl_WordPartLeftExtend(wxObject);
        }

        public void WordPartRight()
        {
            wxStyledTextCtrl_WordPartRight(wxObject);
        }

        public void WordPartRightExtend()
        {
            wxStyledTextCtrl_WordPartRightExtend(wxObject);
        }

        //-----------------------------------------------------------------------------

        public void SetVisiblePolicy(VisiblePolicies visiblePolicy, int visibleSlop)
        {
            wxStyledTextCtrl_SetVisiblePolicy(wxObject, (int)visiblePolicy, visibleSlop);
        }

        //-----------------------------------------------------------------------------

        public void DelLineLeft()
        {
            wxStyledTextCtrl_DelLineLeft(wxObject);
        }

        public void DelLineRight()
        {
            wxStyledTextCtrl_DelLineRight(wxObject);
        }

        //-----------------------------------------------------------------------------

        public int XOffset
        {
            set { wxStyledTextCtrl_SetXOffset(wxObject, value); }
            get { return wxStyledTextCtrl_GetXOffset(wxObject); }
        }

        //-----------------------------------------------------------------------------

        public void ChooseCaretX()
        {
            wxStyledTextCtrl_ChooseCaretX(wxObject);
        }

        //-----------------------------------------------------------------------------

        public void SetXCaretPolicy(CaretPolicies caretPolicy, int caretSlop)
        {
            wxStyledTextCtrl_SetXCaretPolicy(wxObject, (int)caretPolicy, caretSlop);
        }

        public void SetYCaretPolicy(CaretPolicies caretPolicy, int caretSlop)
        {
            wxStyledTextCtrl_SetYCaretPolicy(wxObject, (int)caretPolicy, caretSlop);
        }

        //-----------------------------------------------------------------------------

        public WrapModes PrintWrapMode
        {
            set { wxStyledTextCtrl_SetPrintWrapMode(wxObject, (int)value); }
            get { return (WrapModes)wxStyledTextCtrl_GetPrintWrapMode(wxObject); }
        }

        //-----------------------------------------------------------------------------

        public void SetHotspotActiveForeground(bool useSetting, Colour fore)
        {
            wxStyledTextCtrl_SetHotspotActiveForeground(wxObject, useSetting, Object.SafePtr(fore));
        }

        public void SetHotspotActiveBackground(bool useSetting, Colour back)
        {
            wxStyledTextCtrl_SetHotspotActiveBackground(wxObject, useSetting, Object.SafePtr(back));
        }

        public void SetHotspotActiveUnderline(bool underline)
        {
            wxStyledTextCtrl_SetHotspotActiveUnderline(wxObject, underline);
        }

        //-----------------------------------------------------------------------------

        public void StartRecord()
        {
            wxStyledTextCtrl_StartRecord(wxObject);
        }

        public void StopRecord()
        {
            wxStyledTextCtrl_StopRecord(wxObject);
        }

        //-----------------------------------------------------------------------------

        /** <summary>Returns or defines the used lexer.</summary>*/
        public LexerId Lexer
        {
            set { wxStyledTextCtrl_SetLexer(wxObject, (int)value); }
            get { return (LexerId)wxStyledTextCtrl_GetLexer(wxObject); }
        }

        //-----------------------------------------------------------------------------

        public void Colourise(int start, int end)
        {
            wxStyledTextCtrl_Colourise(wxObject, start, end);
        }

        //-----------------------------------------------------------------------------

        /** <summary>Defines properties.</summary><remarks>
         * Examples:
         * \code
                SetProperty("fold", "1");
                SetProperty("fold.comment", "1");
                SetProperty("fold.compact", "1");

                SetProperty("fold.html", "1");
                SetProperty("fold.htmlprep", "1");
                SetProperty("fold.commentpy", "1");
                SetProperty("fold.quotespy", "1");
         \endcode
         * </remarks>*/
        public void SetProperty(string key, string value)
        {
            this.SetProperty(wxString.SafeNew(key), wxString.SafeNew(value));
        }

        /** <summary>Defines properties.</summary>*/
        public void SetProperty(wxString key, wxString value)
        {
            wxStyledTextCtrl_SetProperty(wxObject, Object.SafePtr( key), Object.SafePtr( value));
        }

        //-----------------------------------------------------------------------------


        /** <summary>Defines a set of keywords of the specified type.
         * This defines parameters that will be used by the lexer: a set of keywords.</summary>*/
        public void SetKeyWords(Keywords keywordSet, string[] keywords)
        {
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            for (int index = 0; index < keywords.Length; ++index)
            {
                if (index > 0)
                    sb.Append(" ");
                sb.Append(keywords[index]);
            }
            this.SetKeyWords(keywordSet, sb.ToString());
        }

        /** <summary>Defines a set of keywords of the specified type.
         * This defines parameters that will be used by the lexer: a set of keywords separated by a single blank character.</summary>*/
        public void SetKeyWords(Keywords keywordSet, string keyWords)
        {
            wxString wxKeyWords = wxString.SafeNew(keyWords);
            this.SetKeyWords(keywordSet, wxKeyWords);
        }
        /** <summary>Defines a set of keywords of the specified type.
         * This defines parameters that will be used by the lexer: a set of keywords separated by a single blank character.</summary>*/
        public void SetKeyWords(Keywords keywordSet, wxString keyWords)
        {
            wxStyledTextCtrl_SetKeyWords(wxObject, (int)keywordSet, Object.SafePtr(keyWords));
        }

        //-----------------------------------------------------------------------------

        public string LexerLanguage
        {
            set
            {
                wxString wxvalue = wxString.SafeNew(value);
                wxStyledTextCtrl_SetLexerLanguage(wxObject, Object.SafePtr(wxvalue));
            }
        }

        //-----------------------------------------------------------------------------

        public int CurrentLine
        {
            get { return wxStyledTextCtrl_GetCurrentLine(wxObject); } 
        }

        //-----------------------------------------------------------------------------

        /** <summary>Extract style settings from a spec-string which is composed of one or more of the following comma separated elements:
          * \li bold                    turns on bold
          * \li italic                  turns on italics
          * \li fore:[name or #RRGGBB]  sets the foreground colour
          * \li back:[name or #RRGGBB]  sets the background colour
          * \li face:[facename]         sets the font face name to use
          * \li size:[num]              sets the font size in points
          * \li eol                     turns on eol filling
          * \li underline               turns on underlining</summary>*/
        public void StyleSetSpec(LexerStates stateDescr, string spec)
        {
            this.StyleSetSpec((int)stateDescr, spec);
        }
        /** <summary>Extract style settings from a spec-string which is composed of one or more of the following comma separated elements:
          * \li bold                    turns on bold
          * \li italic                  turns on italics
          * \li fore:[name or #RRGGBB]  sets the foreground colour
          * \li back:[name or #RRGGBB]  sets the background colour
          * \li face:[facename]         sets the font face name to use
          * \li size:[num]              sets the font size in points
          * \li eol                     turns on eol filling
          * \li underline               turns on underlining</summary>*/
        public void StyleSetSpec(int styleNum, string spec)
        {
            this.StyleSetSpec(styleNum, spec);
        }
        public void StyleSetSpec(int styleNum, wxString spec)
        {
            wxStyledTextCtrl_StyleSetSpec(wxObject, styleNum, Object.SafePtr(spec));
        }

        public void StyleSetFont(LexerStates stateDescr, Font font)
        {
            this.StyleSetFont((int)stateDescr, font);
        }
        public void StyleSetFont(int styleNum, Font font)
        {
            wxStyledTextCtrl_StyleSetFont(wxObject, styleNum, Object.SafePtr(font));
        }

        public void StyleSetFontAttr(LexerStates styleNum, int size, string faceName, bool bold, bool italic, bool underline)
        {
            this.StyleSetFontAttr((int)styleNum, size, faceName, bold, italic, underline);
        }
        public void StyleSetFontAttr(int styleNum, int size, string faceName, bool bold, bool italic, bool underline)
        {
            this.StyleSetFontAttr(styleNum, size, wxString.SafeNew(faceName), bold, italic, underline);
        }
        public void StyleSetFontAttr(int styleNum, int size, wxString faceName, bool bold, bool italic, bool underline)
        {
            wxStyledTextCtrl_StyleSetFontAttr(wxObject, styleNum, size, Object.SafePtr(faceName), bold, italic, underline);
        }

        //-----------------------------------------------------------------------------

        public void CmdKeyExecute(int cmd)
        {
            wxStyledTextCtrl_CmdKeyExecute(wxObject, cmd);
        }

        //-----------------------------------------------------------------------------

        public void SetMargins(int left, int right)
        {
            wxStyledTextCtrl_SetMargins(wxObject, left, right);
        }

        //-----------------------------------------------------------------------------

        public void GetSelection(out int startPos, out int endPos)
        {
            startPos = new int();
            endPos = new int();
            wxStyledTextCtrl_GetSelection(wxObject, ref startPos, ref endPos);
        }

        //-----------------------------------------------------------------------------

        public Point PointFromPosition(int pos)
        {
            Point pt = new Point();
            wxStyledTextCtrl_PointFromPosition(wxObject, pos, ref pt);
            return pt;
        }

        //-----------------------------------------------------------------------------

        public void ScrollToLine(int line)
        {
            wxStyledTextCtrl_ScrollToLine(wxObject, line);
        }

        //-----------------------------------------------------------------------------

        public void ScrollToColumn(int column)
        {
            wxStyledTextCtrl_ScrollToColumn(wxObject, column);
        }

        //-----------------------------------------------------------------------------

        public int SendMsg(int msg, int wp, int lp)
        {
            return wxStyledTextCtrl_SendMsg(wxObject, msg, wp, lp);
        }

        //-----------------------------------------------------------------------------

        /*public ScrollBar VScrollBar
        {
            set { wxStyledTextCtrl_SetVScrollBar(wxObject, Object.SafePtr(value)); }
        }*/

        //-----------------------------------------------------------------------------

        /*public ScrollBar SetHScrollBar
        {
            set { wxStyledTextCtrl_SetHScrollBar(wxObject, Object.SafePtr(value)); }
        }*/

        //-----------------------------------------------------------------------------

        public bool LastKeydownProcessed
        {
            get { return wxStyledTextCtrl_GetLastKeydownProcessed(wxObject); }
            set { wxStyledTextCtrl_SetLastKeydownProcessed(wxObject, value); }
        }

        //-----------------------------------------------------------------------------

        public bool SaveFile(string filename)
        {
            return this.SaveFile(wxString.SafeNew(filename));
        }
        public bool SaveFile(wxString filename)
        {
            return wxStyledTextCtrl_SaveFile(wxObject, Object.SafePtr(filename));
        }

        /// <summary>
        /// Loading a file into the editor.
        /// Please note that loading a file is treated as an editor action.
        /// Loading a file will be reflected by the Undo/Redo-buffer and 
        /// the control shall not be readonly when loading. This, you may wish
        /// to set <c>ReadOnly</c> to false before loading a file and
        /// call <c>EmptyUndoBuffer</c> after loading.
        /// </summary>
        /// <param name="filename">The name of the loaded file.</param>
        /// <returns></returns>
        public bool LoadFile(string filename)
        {
            return this.LoadFile(wxString.SafeNew(filename));
        }
        /// <summary>
        /// Loading a file into the editor.
        /// Please note that loading a file is treated as an editor action.
        /// Loading a file will be reflected by the Undo/Redo-buffer and 
        /// the control shall not be readonly when loading. This, you may wish
        /// to set <c>ReadOnly</c> to false before loading a file and
        /// call <c>EmptyUndoBuffer</c> after loading.
        /// </summary>
        /// <param name="filename">The name of the loaded file.</param>
        /// <returns></returns>
        public bool LoadFile(wxString filename)
        {
            return wxStyledTextCtrl_LoadFile(wxObject, Object.SafePtr(filename));
        }

        //-----------------------------------------------------------------------------

        /** <summary>This will be raised on any kind of change.
         * Use Modify() in the event handler if you want to trigger actions only if the text has been changed.</summary>*/
        public event EventListener Change
		{
			add { AddCommandListener(wxEVT_STC_CHANGE, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

		public event EventListener StyleNeeded
		{
			add { AddCommandListener(wxEVT_STC_STYLENEEDED, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

		public event EventListener CharAdded
		{
			add { AddCommandListener(wxEVT_STC_CHARADDED, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

		public event EventListener SavePointReached
		{
			add { AddCommandListener(wxEVT_STC_SAVEPOINTREACHED, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

		public event EventListener SavePointLeft
		{
			add { AddCommandListener(wxEVT_STC_SAVEPOINTLEFT, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

		public event EventListener ROModifyAttempt
		{
			add { AddCommandListener(wxEVT_STC_ROMODIFYATTEMPT, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

		public event EventListener Key
		{
			add { AddCommandListener(wxEVT_STC_KEY, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

		public event EventListener DoubleClick
		{
			add { AddCommandListener(wxEVT_STC_DOUBLECLICK, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

		public override event EventListener UpdateUI
		{
			add { AddCommandListener(wxEVT_STC_UPDATEUI, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

		public event EventListener Modified
		{
			add { AddCommandListener(wxEVT_STC_MODIFIED, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

		public event EventListener MacroRecord
		{
			add { AddCommandListener(wxEVT_STC_MACRORECORD, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

		public event EventListener MarginClick
		{
			add { AddCommandListener(wxEVT_STC_MARGINCLICK, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

		public event EventListener NeedShown
		{
			add { AddCommandListener(wxEVT_STC_NEEDSHOWN, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

		/*public event EventListener PositionChanged
		{
			add { AddCommandListener(wxEVT_STC_POSCHANGED, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}*/

		public event EventListener Paint
		{
			add { AddCommandListener(wxEVT_STC_PAINTED, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

		public event EventListener UserListSelection
		{
			add { AddCommandListener(wxEVT_STC_USERLISTSELECTION, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

		public event EventListener URIDropped
		{
			add { AddCommandListener(wxEVT_STC_URIDROPPED, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

		public event EventListener DwellStart
		{
			add { AddCommandListener(wxEVT_STC_DWELLSTART, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

		public event EventListener DwellEnd
		{
			add { AddCommandListener(wxEVT_STC_DWELLEND, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

		public event EventListener StartDrag
		{
			add { AddCommandListener(wxEVT_STC_START_DRAG, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

		public event EventListener DragOver
		{
			add { AddCommandListener(wxEVT_STC_DRAG_OVER, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

		public event EventListener DoDrop
		{
			add { AddCommandListener(wxEVT_STC_DO_DROP, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

		public event EventListener Zoomed
		{
			add { AddCommandListener(wxEVT_STC_ZOOM, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

		public event EventListener HotspotClick
		{
			add { AddCommandListener(wxEVT_STC_HOTSPOT_CLICK, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

		public event EventListener HotspotDoubleClick
		{
			add { AddCommandListener(wxEVT_STC_HOTSPOT_DCLICK, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

		public event EventListener CalltipClick
		{
			add { AddCommandListener(wxEVT_STC_CALLTIP_CLICK, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

        #region Lexer State Utilities
        /** <summary>This will return a prefix string defining all those values of STCStyle that describe valid states of <c>lexer</c>.
         * Example: LexerId.CPP and LexerId.CPPNOCASE will return {"C_"}.
         * The result may be <c>null</c> if this is not supported.</summary>*/
        public static string[] StatePrefixForLexer(LexerId lexer)
        {
            switch (lexer)
            {
                case LexerId.ADA: return new string[] { "ADA_" };
                case LexerId.CPP: return new string[] { "C_" };
                case LexerId.CPPNOCASE: return new string[] { "C_" };
                case LexerId.HTML: return new string[] { "H_" };
                case LexerId.XML: return new string[] { "H_" };
                case LexerId.XCODE: return new string[] { "H_" };
                case LexerId.PYTHON: return new string[] { "PY_" };
                case LexerId.ASP: return new string[] { "HJA_" };
                case LexerId.VB: return new string[] { "B_" };
                case LexerId.LUA: return new string[] { "LUA_" };
                case LexerId.MAKEFILE: return new string[] { "MAKE_" };
            }
            return null;
        }

        /** <summary>Returns the name of the lexer at the designated position.</summary>*/
        public string GetLexerStateNameAtPos(int pos)
        {
            return GetLexerStateName(this.GetStyleAt(pos), this.Lexer);
        }

        /** <summary>This returns a name string for the lexer state <c>state</c> that refers to <c>lexer</c>.
         * Problem: Lexer state are named ambigiously among different lexers.</summary>*/
        public static string GetLexerStateName(LexerStates state, LexerId lexer)
        {
            string[] prefixes = StatePrefixForLexer(lexer);
            if (prefixes != null)
            {
                foreach (string prefix in prefixes)
                {
                    foreach (string lexerStateName in Enum.GetNames(typeof(LexerStates)))
                    {
                        if (lexerStateName.StartsWith(prefix)
                            && Enum.Parse(typeof(LexerStates), lexerStateName).Equals(state))
                        {
                            return lexerStateName;
                        }
                    }
                }
            }
            return state.ToString();
        }
        #endregion
    }

    public class StyledTextEvent : CommandEvent 
    {
        [DllImport("wx-c")] static extern IntPtr wxStyledTextEvent_ctor(int commandType, int id);
        [DllImport("wx-c")] static extern void   wxStyledTextEvent_SetPosition(IntPtr self, int pos);
        [DllImport("wx-c")] static extern void   wxStyledTextEvent_SetKey(IntPtr self, int k);
        [DllImport("wx-c")] static extern void   wxStyledTextEvent_SetModifiers(IntPtr self, int m);
        [DllImport("wx-c")] static extern void   wxStyledTextEvent_SetModificationType(IntPtr self, int t);
        [DllImport("wx-c")] static extern void   wxStyledTextEvent_SetText(IntPtr self, IntPtr t);
        [DllImport("wx-c")] static extern void   wxStyledTextEvent_SetLength(IntPtr self, int len);
        [DllImport("wx-c")] static extern void   wxStyledTextEvent_SetLinesAdded(IntPtr self, int num);
        [DllImport("wx-c")] static extern void   wxStyledTextEvent_SetLine(IntPtr self, int val);
        [DllImport("wx-c")] static extern void   wxStyledTextEvent_SetFoldLevelNow(IntPtr self, int val);
        [DllImport("wx-c")] static extern void   wxStyledTextEvent_SetFoldLevelPrev(IntPtr self, int val);
        [DllImport("wx-c")] static extern void   wxStyledTextEvent_SetMargin(IntPtr self, int val);
        [DllImport("wx-c")] static extern void   wxStyledTextEvent_SetMessage(IntPtr self, int val);
        [DllImport("wx-c")] static extern void   wxStyledTextEvent_SetWParam(IntPtr self, int val);
        [DllImport("wx-c")] static extern void   wxStyledTextEvent_SetLParam(IntPtr self, int val);
        [DllImport("wx-c")] static extern void   wxStyledTextEvent_SetListType(IntPtr self, int val);
        [DllImport("wx-c")] static extern void   wxStyledTextEvent_SetX(IntPtr self, int val);
        [DllImport("wx-c")] static extern void   wxStyledTextEvent_SetY(IntPtr self, int val);
        [DllImport("wx-c")] static extern void   wxStyledTextEvent_SetDragText(IntPtr self, IntPtr val);
        [DllImport("wx-c")] static extern void   wxStyledTextEvent_SetDragAllowMove(IntPtr self, bool val);
        //[DllImport("wx-c")] static extern void   wxStyledTextEvent_SetDragResult(IntPtr self, wxDragResult val);
        [DllImport("wx-c")] static extern int    wxStyledTextEvent_GetPosition(IntPtr self);
        [DllImport("wx-c")] static extern int    wxStyledTextEvent_GetKey(IntPtr self);
        [DllImport("wx-c")] static extern int    wxStyledTextEvent_GetModifiers(IntPtr self);
        [DllImport("wx-c")] static extern int    wxStyledTextEvent_GetModificationType(IntPtr self);
        [DllImport("wx-c")] static extern IntPtr wxStyledTextEvent_GetText(IntPtr self);
        [DllImport("wx-c")] static extern int    wxStyledTextEvent_GetLength(IntPtr self);
        [DllImport("wx-c")] static extern int    wxStyledTextEvent_GetLinesAdded(IntPtr self);
        [DllImport("wx-c")] static extern int    wxStyledTextEvent_GetLine(IntPtr self);
        [DllImport("wx-c")] static extern int    wxStyledTextEvent_GetFoldLevelNow(IntPtr self);
        [DllImport("wx-c")] static extern int    wxStyledTextEvent_GetFoldLevelPrev(IntPtr self);
        [DllImport("wx-c")] static extern int    wxStyledTextEvent_GetMargin(IntPtr self);
        [DllImport("wx-c")] static extern int    wxStyledTextEvent_GetMessage(IntPtr self);
        [DllImport("wx-c")] static extern int    wxStyledTextEvent_GetWParam(IntPtr self);
        [DllImport("wx-c")] static extern int    wxStyledTextEvent_GetLParam(IntPtr self);
        [DllImport("wx-c")] static extern int    wxStyledTextEvent_GetListType(IntPtr self);
        [DllImport("wx-c")] static extern int    wxStyledTextEvent_GetX(IntPtr self);
        [DllImport("wx-c")] static extern int    wxStyledTextEvent_GetY(IntPtr self);
        [DllImport("wx-c")] static extern IntPtr wxStyledTextEvent_GetDragText(IntPtr self);
        [DllImport("wx-c")] static extern bool   wxStyledTextEvent_GetDragAllowMove(IntPtr self);
        //[DllImport("wx-c")] static extern IntPtr wxStyledTextEvent_GetDragResult(IntPtr self);
        [DllImport("wx-c")] static extern bool   wxStyledTextEvent_GetShift(IntPtr self);
        [DllImport("wx-c")] static extern bool   wxStyledTextEvent_GetControl(IntPtr self);
        [DllImport("wx-c")] static extern bool   wxStyledTextEvent_GetAlt(IntPtr self);

        //-----------------------------------------------------------------------------

		public StyledTextEvent(IntPtr wxObject) 
            : base(wxObject) { }

        public  StyledTextEvent(int commandType, int id)
            : base(wxStyledTextEvent_ctor(commandType, id)) { }

        //-----------------------------------------------------------------------------

        public int Position
        {
            get { return wxStyledTextEvent_GetPosition(wxObject); }
            set { wxStyledTextEvent_SetPosition(wxObject, value); }
        }

        //-----------------------------------------------------------------------------

        public int Key
        {
            get { return wxStyledTextEvent_GetKey(wxObject); }
            set { wxStyledTextEvent_SetKey(wxObject, value); }
        }

        //-----------------------------------------------------------------------------

        public int Modifiers
        {
            set { wxStyledTextEvent_SetModifiers(wxObject, value); }
            get { return wxStyledTextEvent_GetModifiers(wxObject); } 
        }

        //-----------------------------------------------------------------------------

        public int ModificationType
        {
            set { wxStyledTextEvent_SetModificationType(wxObject, value); }
            get { return wxStyledTextEvent_GetModificationType(wxObject); }
        }

        //-----------------------------------------------------------------------------

        public string Text
        {
            set
            {
                wxString wxvalue = wxString.SafeNew(value);
                wxStyledTextEvent_SetText(wxObject, Object.SafePtr(wxvalue));
            } 
            get { return new wxString(wxStyledTextEvent_GetText(wxObject), true); }
        }

        //-----------------------------------------------------------------------------

        public int Length
        {
            set { wxStyledTextEvent_SetLength(wxObject, value); }
            get { return wxStyledTextEvent_GetLength(wxObject); }
        }

        //-----------------------------------------------------------------------------

        public int LinesAdded
        {
            set { wxStyledTextEvent_SetLinesAdded(wxObject, value); } 
            get { return wxStyledTextEvent_GetLinesAdded(wxObject); }
        }

        //-----------------------------------------------------------------------------

        public int Line
        {
            set { wxStyledTextEvent_SetLine(wxObject, value); } 
            get { return wxStyledTextEvent_GetLine(wxObject); }
        }

        //-----------------------------------------------------------------------------


        public int FoldLevelNow
        {
            set { wxStyledTextEvent_SetFoldLevelNow(wxObject, (int)value); }
            get { return wxStyledTextEvent_GetFoldLevelNow(wxObject); }
        }

        public int FoldLevelPrev
        {
            set { wxStyledTextEvent_SetFoldLevelPrev(wxObject, (int)value); }
            get { return wxStyledTextEvent_GetFoldLevelPrev(wxObject); }
        }

        //-----------------------------------------------------------------------------

        public int Margin
        {
            set { wxStyledTextEvent_SetMargin(wxObject, value); }
            get { return wxStyledTextEvent_GetMargin(wxObject); }
        }

        //-----------------------------------------------------------------------------

        public int Message
        {
            set { wxStyledTextEvent_SetMessage(wxObject, value); } 
            get { return wxStyledTextEvent_GetMessage(wxObject); }
        }

        //-----------------------------------------------------------------------------

        public int WParam
        {
            set { wxStyledTextEvent_SetWParam(wxObject, value); }
            get { return wxStyledTextEvent_GetWParam(wxObject); }
        }

        //-----------------------------------------------------------------------------

        public int LParam
        {
            set { wxStyledTextEvent_SetLParam(wxObject, value); }
            get { return wxStyledTextEvent_GetLParam(wxObject); }
        }

        //-----------------------------------------------------------------------------

        public int ListType
        {
            set { wxStyledTextEvent_SetListType(wxObject, value); }
            get { return wxStyledTextEvent_GetListType(wxObject); }
        }

        //-----------------------------------------------------------------------------

        public int X
        {
            set { wxStyledTextEvent_SetX(wxObject, value); }
            get { return wxStyledTextEvent_GetX(wxObject); }
        }

        //-----------------------------------------------------------------------------

        public int Y
        {
            set { wxStyledTextEvent_SetY(wxObject, value); }
            get { return wxStyledTextEvent_GetY(wxObject); }
        }

        //-----------------------------------------------------------------------------

        public string DragText
        {
            set
            {
                wxString wxvalue = wxString.SafeNew(value);
                wxStyledTextEvent_SetDragText(wxObject, Object.SafePtr(wxvalue));
            }
            get { return new wxString(wxStyledTextEvent_GetDragText(wxObject), true); }
        }

        //-----------------------------------------------------------------------------

        public bool DragAllowMove
        {
            set { wxStyledTextEvent_SetDragAllowMove(wxObject, value); } 
            get { return wxStyledTextEvent_GetDragAllowMove(wxObject); }
        }

        //-----------------------------------------------------------------------------

        /*public DragResult DragResult
        {
            set { wxStyledTextEvent_SetDragResult(wxObject, Object.SafePtr(value)); }
            get { return wxStyledTextEvent_GetDragResult(wxObject); }
        }*/

        //-----------------------------------------------------------------------------

        public bool Shift
        {
            get { return wxStyledTextEvent_GetShift(wxObject); }
        }

        public bool Control
        {
            get { return wxStyledTextEvent_GetControl(wxObject); }
        }

        public bool Alt
        {
            get { return wxStyledTextEvent_GetAlt(wxObject); }
        }
    }
}

#endif 

