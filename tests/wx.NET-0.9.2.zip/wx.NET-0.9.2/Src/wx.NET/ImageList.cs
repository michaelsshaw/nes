//-----------------------------------------------------------------------------
// wx.NET - ImageList.cs
//
// The wxImageList wrapper class.
//
// Written by Jason Perkins (jason@379.com)
// (C) 2003 by 379, Inc.
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: ImageList.cs,v 1.10 2010/04/21 20:43:47 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Runtime.InteropServices;

namespace wx
{
	public enum wxImageList
	{
        /** <summary>Normal size icons.</summary>*/
		wxIMAGE_LIST_NORMAL=0,
        /** <summary>Small size icons</summary>*/
        wxIMAGE_LIST_SMALL = 1,
        /** <summary>Not yet implemented.
         * Refer to  wxWidgets documentation.</summary>*/
		wxIMAGE_LIST_STATE=3,

        /** <summary>Normal size icons
         * Same as wxIMAGE_LIST_NORMAL().</summary>*/
        Normal = 0,
        /** <summary>Small size icons
         * Same as wxIMAGE_LIST_SMALL().</summary>*/
        Small = 1,
	}
	
	//---------------------------------------------------------------------

    /// <summary>
    /// An image list is a list of images that may have transparent areas.
    /// The class helps an application organise a collection of images so that they can be
    /// referenced by integer index instead of by pointer.
    /// </summary>
	public class ImageList : Object
	{
        [Flags]
        /** <summary>Style flags for Draw().</summary>*/
        public enum DrawStyle
        {
		    NORMAL	= 0x0001,
		    TRANSPARENT	= 0x0002,
		    SELECTED	= 0x0004,
		    FOCUSED	= 0x0008,
        }

        #region State
        System.Collections.Generic.List<Bitmap> _bitmaps = new System.Collections.Generic.List<Bitmap>();
        #endregion

        #region C API
        [DllImport("wx-c")] static extern IntPtr wxImageList_ctor(int width, int height, bool mask, int initialCount);
		[DllImport("wx-c")] static extern IntPtr wxImageList_ctor2();
		[DllImport("wx-c")] static extern int    wxImageList_AddBitmap1(IntPtr self, IntPtr bmp, IntPtr mask);
		[DllImport("wx-c")] static extern int    wxImageList_AddBitmap(IntPtr self, IntPtr bmp, IntPtr maskColour);
		[DllImport("wx-c")] static extern int    wxImageList_AddIcon(IntPtr self, IntPtr icon);
		[DllImport("wx-c")] static extern int    wxImageList_GetImageCount(IntPtr self);
		
		[DllImport("wx-c")] static extern bool   wxImageList_Draw(IntPtr self, int index, IntPtr dc, int x, int y, int flags, bool solidBackground);
		
		[DllImport("wx-c")] static extern bool   wxImageList_Create(IntPtr self, int width, int height, bool mask, int initialCount);
		
		[DllImport("wx-c")] static extern bool   wxImageList_Replace(IntPtr self, int index, IntPtr bitmap);
		
		[DllImport("wx-c")] static extern bool   wxImageList_Remove(IntPtr self, int index);
		[DllImport("wx-c")] static extern bool   wxImageList_RemoveAll(IntPtr self);
		
		[DllImport("wx-c")] static extern IntPtr wxImageList_GetBitmap(IntPtr self, int index);
		
		[DllImport("wx-c")] static extern bool   wxImageList_GetSize(IntPtr self, int index, ref int width, ref int height);
        #endregion

        /// <summary>
        /// Constructor specifying the image size, whether image masks should be created, and the initial size of the list.
        /// The mask will be created for all images.
        /// </summary>
        /// <param name="width">Width of the images in the list.</param>
        /// <param name="height">Height of the images in the list.</param>
        public ImageList(int width, int height)
			: this(width, height, true, 1) {}

        /// <summary>
        /// Constructor specifying the image size, whether image masks should be created, and the initial size of the list.
        /// </summary>
        /// <param name="width">Width of the images in the list.</param>
        /// <param name="height">Height of the images in the list.</param>
        /// <param name="mask">true if masks should be created for all images (default).</param>
        public ImageList(int width, int height, bool mask)
			: this(width, height, mask, 1) {}

        /// <summary>
        /// Constructor specifying the image size, whether image masks should be created, and the initial size of the list.
        /// </summary>
        /// <param name="width">Width of the images in the list.</param>
        /// <param name="height">Height of the images in the list.</param>
        /// <param name="mask">true if masks should be created for all images.</param>
        /// <param name="initialCount">The initial size of the list.</param>
		public ImageList(int width, int height, bool mask, int initialCount)
			: base(wxImageList_ctor(width, height, mask, initialCount)) {}

		public ImageList(IntPtr wxObject) 
			: base(wxObject) {}
			
		public ImageList()
			: base(wxImageList_ctor2()) {}

		//---------------------------------------------------------------------

        /// <summary>
        /// Adds a new image or images using a bitmap.
        /// </summary>
        /// <param name="bitmap">Bitmap representing the opaque areas of the image.</param>
        /// <returns>The zero-based image index of the new bitmap.</returns>
		public int Add(Bitmap bitmap)
		{
            this._bitmaps.Add(bitmap);
			return wxImageList_AddBitmap1(wxObject, Object.SafePtr(bitmap), IntPtr.Zero);
		}
		
        /// <summary>
        /// Adds a new image or images using a bitmap and optional mask bitmap.
        /// </summary>
        /// <param name="bitmap">Bitmap representing the opaque areas of the image.</param>
        /// <param name="mask">Monochrome mask bitmap, representing the transparent areas of the image. </param>
        /// <returns>The zero-based image index of the new bitmap.</returns>
		public int Add(Bitmap bitmap, Bitmap mask)
		{
            this._bitmaps.Add(bitmap);
            return wxImageList_AddBitmap1(wxObject, Object.SafePtr(bitmap), Object.SafePtr(mask));
		}

        /// <summary>
        /// Adds a new image or images using a bitmap and optional mask bitmap.
        /// </summary>
        /// <param name="icon">Icon to use as the image.</param>
        /// <returns>The zero-based image index of the new bitmap.</returns>
        public int Add(Icon icon)
		{
            this._bitmaps.Add(null);
            return wxImageList_AddIcon(wxObject, Object.SafePtr(icon));
		}

        /// <summary>
        /// Adds a new image or images using a bitmap and optional mask bitmap.
        /// </summary>
        /// <param name="bitmap">Bitmap representing the opaque areas of the image.</param>
        /// <param name="maskColour">Colour indicating which parts of the image are transparent.</param>
        /// <returns>The zero-based image index of the new bitmap.</returns>
        public int Add(Bitmap bitmap, Colour maskColour)
		{
            this._bitmaps.Add(bitmap);
            return wxImageList_AddBitmap(wxObject, Object.SafePtr(bitmap), Object.SafePtr(maskColour));
		}

		//---------------------------------------------------------------------
		
		public bool Create(int width, int height)
		{
			return Create(width, height, true, 1);
		}
		
		public bool Create(int width, int height, bool mask)
		{
			return Create(width, height, mask, 1);
		}
		
		public bool Create(int width, int height, bool mask, int initialCount)
		{
			return wxImageList_Create(wxObject, width, height, mask, initialCount);
		}
		
		//---------------------------------------------------------------------

        /// <summary>
        /// Number of images.
        /// </summary>
        public int Count
        {
            get { return this.ImageCount; }
        }

        /// <summary>
        /// Number of images
        /// </summary>
		public int ImageCount
		{
			get { return wxImageList_GetImageCount(wxObject); }
		}
		
		//---------------------------------------------------------------------
		
		public bool Draw(int index, DC dc, int x, int y)
		{
			return Draw(index, dc, x, y, DrawStyle.NORMAL, false);
		}
		
		public bool Draw(int index, DC dc, int x, int y, DrawStyle flags)
		{
			return Draw(index, dc, x, y, flags, false);
		}
		
		public bool Draw(int index, DC dc, int x, int y, DrawStyle flags, bool solidBackground)
		{
			return wxImageList_Draw(wxObject, index, Object.SafePtr(dc), x, y, (int)flags, solidBackground);
		}
		
		//---------------------------------------------------------------------
		
		public bool Replace(int index, Bitmap bitmap)
		{
			return wxImageList_Replace(wxObject, index, Object.SafePtr(bitmap));
		}
		
		//---------------------------------------------------------------------
		
		public bool Remove(int index)
		{
			return wxImageList_Remove(wxObject, index);
		}
		
		//---------------------------------------------------------------------
		
		public bool RemoveAll()
		{
			return wxImageList_RemoveAll(wxObject);
		}
		
		//---------------------------------------------------------------------
		
        /// <summary>
        /// Returns the bitmap of the provided zero-based index.
        /// </summary>
        /// <param name="index">The index of the bitmap to be returned</param>
		public Bitmap GetBitmap(int index)
		{
            Bitmap result = this._bitmaps[index];
            if (result == null)
            {
                result = new Bitmap(wxImageList_GetBitmap(this.wxObject, index));
                this._bitmaps[index] = result;
            }
            return result;
		}

        /// <summary>
        /// Synonym for GetBitmap().
        /// </summary>
        /// <param name="index">The zero-based index of the bitmap to return.</param>
        public Bitmap this[int index]
        {
            get
            {
                return this.GetBitmap(index);
            }
        }
		
		//---------------------------------------------------------------------
		
		public bool GetSize(int index, ref int width, ref int height)
		{
			return wxImageList_GetSize(wxObject, index, ref width, ref height);
		}
	}
}
