//-----------------------------------------------------------------------------
// wx.NET - MessageDialog.cs
//
// The wxMessageDialog wrapper class.
//
// Written by Jason Perkins (jason@379.com)
// (C) 2003 by 379, Inc.
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: MessageDialog.cs,v 1.16 2009/10/11 16:23:20 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Drawing;
using System.Runtime.InteropServices;

namespace wx
{
	// The MessageDialog class implements the interface for wxWidgets' 
	// wxMessageDialog class and wxMessageBox.
    /** <summary>This class represents a dialog that shows a single or multi-line message, with a choice of OK, Yes, No and Cancel buttons.</summary>*/
	public class MessageDialog : Dialog
	{
		// MessageBox function
		[DllImport("wx-c")] static extern int    wxMsgBox(IntPtr parent, IntPtr msg, IntPtr cap, uint style, int posX, int posY);

		// Message dialog methods
		[DllImport("wx-c")] static extern IntPtr wxMessageDialog_ctor(IntPtr parent, IntPtr message, IntPtr caption, uint style, int posX, int posY);
		[DllImport("wx-c")] static extern int    wxMessageDialog_ShowModal(IntPtr self);

		//---------------------------------------------------------------------
	
		internal MessageDialog(IntPtr wxObject) 
			: base(wxObject) { }

        /// <summary>
        /// Creates a message dialog.
        /// </summary>
        /// <param name="parent">the parent of the dialog. This may be <c>null</c>, but typically this is the window implementing
        /// the action that triggered the display action. This dialog will be (de-)iconified and closed together with
        /// its parent.</param>
        /// <param name="msg">The text message that will be displayed in the dialog.</param>
        public MessageDialog(Window parent, string msg)
            : this(parent, msg, "Message box", wx.WindowStyles.DIALOG_OK | wx.WindowStyles.DIALOG_CANCEL | wx.WindowStyles.DIALOG_CENTRE, wxDefaultPosition) { }

        /// <summary>
        /// Creates a message dialog.
        /// </summary>
        /// <param name="parent">the parent of the dialog. This may be <c>null</c>, but typically this is the window implementing
        /// the action that triggered the display action. This dialog will be (de-)iconified and closed together with
        /// its parent.</param>
        /// <param name="msg">The text message that will be displayed in the dialog.</param>
        /// <param name="caption">The caption of the dialog that will be displayed in the decorator of the dialog window.</param>
        public MessageDialog(Window parent, string msg, string caption)
            : this(parent, msg, caption, wx.WindowStyles.DIALOG_OK | wx.WindowStyles.DIALOG_CANCEL | wx.WindowStyles.DIALOG_CENTRE, wxDefaultPosition) { }

        /// <summary>
        /// Creates a message dialog.
        /// </summary>
        /// <param name="parent">the parent of the dialog. This may be <c>null</c>, but typically this is the window implementing
        /// the action that triggered the display action. This dialog will be (de-)iconified and closed together with
        /// its parent.</param>
        /// <param name="msg">The text message that will be displayed in the dialog.</param>
        /// <param name="caption">The caption of the dialog that will be displayed in the decorator of the dialog window.</param>
        /// <param name="style">Typically defines icons and buttons of the dialog like <c>WindowStyles.DIALOG_OK | WindowStyles.ICON_INFORMATION</c>
        /// </param>
        public MessageDialog(Window parent, string msg, string caption, wx.WindowStyles style)
			: this(parent, msg, caption, style, wxDefaultPosition) { }

        /// <summary>
        /// Creates a message dialog.
        /// </summary>
        /// <param name="parent">the parent of the dialog. This may be <c>null</c>, but typically this is the window implementing
        /// the action that triggered the display action. This dialog will be (de-)iconified and closed together with
        /// its parent.</param>
        /// <param name="msg">The text message that will be displayed in the dialog.</param>
        /// <param name="caption">The caption of the dialog that will be displayed in the decorator of the dialog window.</param>
        /// <param name="style">Typically defines icons and buttons of the dialog like <c>WindowStyles.DIALOG_OK | WindowStyles.ICON_INFORMATION</c>
        /// </param>
        /// <param name="pos">Dialog position. Currently ignored by wxWidgets implementation at least on Windows</param>
        public MessageDialog(Window parent, string msg, string caption, wx.WindowStyles style, Point pos)
			: this(parent, wxString.SafeNew(msg), wxString.SafeNew(caption), style, pos) { }

        /// <summary>
        /// Creates a message dialog.
        /// </summary>
        /// <param name="parent">the parent of the dialog. This may be <c>null</c>, but typically this is the window implementing
        /// the action that triggered the display action. This dialog will be (de-)iconified and closed together with
        /// its parent.</param>
        /// <param name="msg">The text message that will be displayed in the dialog.</param>
        /// <param name="caption">The caption of the dialog that will be displayed in the decorator of the dialog window.</param>
        /// <param name="style">Typically defines icons and buttons of the dialog like <c>WindowStyles.DIALOG_OK | WindowStyles.ICON_INFORMATION</c>
        /// </param>
        /// <param name="pos">Dialog position. Currently ignored by wxWidgets implementation at least on Windows</param>
        public MessageDialog(Window parent, wxString msg, wxString caption, wx.WindowStyles style, Point pos)
            : this(wxMessageDialog_ctor(Object.SafePtr(parent), Object.SafePtr(msg), Object.SafePtr(caption), (uint)style, pos.X, pos.Y)) { } 

		//---------------------------------------------------------------------

        /** <summary>Shows the dialog, returning one of wx.ShowModalResult.</summary>*/
        public override ShowModalResult ShowModal()
		{
            int result=wxMessageDialog_ShowModal(wxObject);
            switch (result)
            {
                case 5100 /* wxID_OK */: return ShowModalResult.OK;
                case 5103 /* wxID_YES */: return ShowModalResult.YES;
                case 5104 /* wxID_NO */: return ShowModalResult.NO;
                default:
                    return ShowModalResult.CANCEL;
            }
        }

		//---------------------------------------------------------------------

		// MessageBox interface

        /// <summary>
        /// Shows a modal message dialog.
        /// </summary>
        /// <param name="msg">The text message that will be displayed in the dialog.</param>
        /// <param name="caption">The caption of the dialog that will be displayed in the decorator of the dialog window.</param>
        /// <param name="style">Typically defines icons and buttons of the dialog like <c>WindowStyles.DIALOG_OK | WindowStyles.ICON_INFORMATION</c>
        /// </param>
        /// <returns></returns>
        public static ShowModalResult ShowModal(string msg, string caption, wx.WindowStyles style)
		{
			return ShowModal(null, msg, caption, style, new Point(-1, -1));
		}

        /// <summary>
        /// Shows a modal message dialog.
        /// </summary>
        /// <param name="parent">the parent of the dialog. This may be <c>null</c>, but typically this is the window implementing
        /// the action that triggered the display action. This dialog will be (de-)iconified and closed together with
        /// its parent.</param>
        /// <param name="msg">The text message that will be displayed in the dialog.</param>
        /// <param name="caption">The caption of the dialog that will be displayed in the decorator of the dialog window.</param>
        /// <param name="style">Typically defines icons and buttons of the dialog like <c>WindowStyles.DIALOG_OK | WindowStyles.ICON_INFORMATION</c>
        /// </param>
        /// <returns></returns>
        public static ShowModalResult ShowModal(Window parent, string msg, string caption, wx.WindowStyles style)
		{
			return ShowModal(parent, msg, caption, style, new Point(-1, -1));
		}

        /// <summary>
        /// Shows a modal message dialog.
        /// </summary>
        /// <param name="parent">the parent of the dialog. This may be <c>null</c>, but typically this is the window implementing
        /// the action that triggered the display action. This dialog will be (de-)iconified and closed together with
        /// its parent.</param>
        /// <param name="msg">The text message that will be displayed in the dialog.</param>
        /// <param name="caption">The caption of the dialog that will be displayed in the decorator of the dialog window.</param>
        /// <param name="style">Typically defines icons and buttons of the dialog like <c>WindowStyles.DIALOG_OK | WindowStyles.ICON_INFORMATION</c>
        /// </param>
        /// <param name="pos">Dialog position. Currently ignored by wxWidgets implementation at least on Windows</param>
        /// <returns></returns>
        public static ShowModalResult ShowModal(Window parent, string msg, string caption, wx.WindowStyles style, Point pos)
		{
            return ShowModal(parent, wxString.SafeNew(msg), wxString.SafeNew(caption), style, pos);
        }

        /// <summary>
        /// Shows a modal message dialog.
        /// </summary>
        /// <param name="parent">the parent of the dialog. This may be <c>null</c>, but typically this is the window implementing
        /// the action that triggered the display action. This dialog will be (de-)iconified and closed together with
        /// its parent.</param>
        /// <param name="msg">The text message that will be displayed in the dialog.</param>
        /// <param name="caption">The caption of the dialog that will be displayed in the decorator of the dialog window.</param>
        /// <param name="style">Typically defines icons and buttons of the dialog like <c>WindowStyles.DIALOG_OK | WindowStyles.ICON_INFORMATION</c>
        /// </param>
        /// <param name="pos">Dialog position. Currently ignored by wxWidgets implementation at least on Windows</param>
        /// <returns></returns>
        public static ShowModalResult ShowModal(Window parent, wxString msg, wxString caption, wx.WindowStyles style, Point pos)
		{
            /* Yes indeed, position argument is not supported at least under windows.
            MessageDialog dialog = new MessageDialog(parent, msg, caption, style, pos);
            return dialog.ShowModal();
             */
			return (ShowModalResult)wxMsgBox(Object.SafePtr(parent), Object.SafePtr(msg), Object.SafePtr(caption), (uint)style, pos.X, pos.Y);
		}

        /// <summary>
        /// Displays a dialog with cation "Message" (or a translation of "Message") and style wx.WindowStyles.DIALOG_OK.
        /// </summary>
        /// <param name="msg">The text to be desplayed.</param>
        /// <returns></returns>
        public static ShowModalResult MessageBox(string msg)
		{
			return ShowModal(null, msg, _("Message"), wx.WindowStyles.DIALOG_OK, new Point(-1, -1));
		}

        /// <summary>
        /// Displays a message dialog.
        /// </summary>
        /// <param name="msg">The text to be desplayed.</param>
        /// <param name="caption">The caption that will be display in the dialog's window decorator.</param>
        /// <returns></returns>
        public static ShowModalResult MessageBox(string msg, string caption)
		{
            return ShowModal(null, msg, caption, wx.WindowStyles.DIALOG_OK, new Point(-1, -1));
		}

        /// <summary>
        /// Displays a dialog with style wx.WindowStyles.DIALOG_OK.
        /// </summary>
        /// <param name="msg">The text message that will be displayed in the dialog.</param>
        /// <param name="caption">The caption of the dialog that will be displayed in the decorator of the dialog window.</param>
        /// <param name="style">Typically defines icons and buttons of the dialog like <c>WindowStyles.DIALOG_OK | WindowStyles.ICON_INFORMATION</c>
        /// </param>
        /// <returns></returns>
        public static ShowModalResult MessageBox(string msg, string caption, wx.WindowStyles style)
		{
			return ShowModal(null, msg, caption, style, new Point(-1, -1));
		}

        /// <summary>
        /// Displays a dialog with style wx.WindowStyles.DIALOG_OK.
        /// </summary>
        /// <param name="parent">the parent of the dialog. This may be <c>null</c>, but typically this is the window implementing
        /// the action that triggered the display action. This dialog will be (de-)iconified and closed together with
        /// its parent.</param>
        /// <param name="msg">The text message that will be displayed in the dialog.</param>
        /// <param name="caption">The caption of the dialog that will be displayed in the decorator of the dialog window.</param>
        /// <param name="style">Typically defines icons and buttons of the dialog like <c>WindowStyles.DIALOG_OK | WindowStyles.ICON_INFORMATION</c>
        /// </param>
        /// <returns></returns>
        public static ShowModalResult MessageBox(string msg, string caption, wx.WindowStyles style, Window parent)
		{
			return ShowModal(parent, msg, caption, style, new Point(-1, -1));
		}

        /// <summary>
        /// Displays a dialog with style wx.WindowStyles.DIALOG_OK.
        /// </summary>
        /// <param name="parent">the parent of the dialog. This may be <c>null</c>, but typically this is the window implementing
        /// the action that triggered the display action. This dialog will be (de-)iconified and closed together with
        /// its parent.</param>
        /// <param name="msg">The text message that will be displayed in the dialog.</param>
        /// <param name="caption">The caption of the dialog that will be displayed in the decorator of the dialog window.</param>
        /// <param name="style">Typically defines icons and buttons of the dialog like <c>WindowStyles.DIALOG_OK | WindowStyles.ICON_INFORMATION</c>
        /// </param>
        /// <param name="pos">Dialog position. Currently ignored by wxWidgets implementation at least on Windows</param>
        /// <returns></returns>
        public static ShowModalResult MessageBox(string msg, string caption, wx.WindowStyles style, Window parent, Point pos)
		{
			return ShowModal(parent, msg, caption, style, pos);
		}
	}
}
