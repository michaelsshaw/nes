//-----------------------------------------------------------------------------
// wx.NET - ListBox.cs
//
// wxListBox wrapper class.
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: ListBox.cs,v 1.36 2010/05/08 19:54:35 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Drawing;
using System.Runtime.InteropServices;

namespace wx
{
	public class ListBox : ControlWithItems
	{
		#region C API
		[DllImport("wx-c")] static extern IntPtr wxListBox_ctor();
		[DllImport("wx-c")] static extern void   wxListBox_dtor(IntPtr self);
		[DllImport("wx-c")] static extern bool   wxListBox_Create(IntPtr self, IntPtr parent, int id, ref Point pos, ref Size size, IntPtr choices, uint style, IntPtr validator, IntPtr name);
		[DllImport("wx-c")] static extern void   wxListBox_InsertItems(IntPtr self, IntPtr items, int pos);
		[DllImport("wx-c")] static extern void   wxListBox_Set(IntPtr self, IntPtr items, IntPtr[] clientData);
		//[DllImport("wx-c")] static extern void   wxListBox_Select(IntPtr self, int n);
		[DllImport("wx-c")] static extern void   wxListBox_Deselect(IntPtr self, int n);
		[DllImport("wx-c")] static extern void   wxListBox_DeselectAll(IntPtr self, int itemToLeaveSelected);
		[DllImport("wx-c")] static extern IntPtr wxListBox_GetSelections(IntPtr self);
		[DllImport("wx-c")] static extern void   wxListBox_SetFirstItem(IntPtr self, int n);
		[DllImport("wx-c")] static extern void   wxListBox_SetFirstItemText(IntPtr self, IntPtr s);
		[DllImport("wx-c")] static extern bool   wxListBox_HasMultipleSelection(IntPtr self);
		[DllImport("wx-c")] static extern bool   wxListBox_IsSorted(IntPtr self);
		[DllImport("wx-c")] static extern void   wxListBox_Command(IntPtr self, IntPtr evt);
		#endregion
		//---------------------------------------------------------------------
		
		#region CTor / DTor
		public ListBox(IntPtr wxObject) 
			: base(wxObject) { }
	
		public ListBox()
			: base(wxListBox_ctor()) { }

		public ListBox(Window parent, int id)
			: this(parent, id, wxDefaultPosition, wxDefaultSize, null, WindowStyles.NO_STYLE, null) { }
	
		public ListBox(Window parent, int id, Point pos)
            : this(parent, id, pos, wxDefaultSize, null, WindowStyles.NO_STYLE, null) { }
	
		public ListBox(Window parent, int id, Point pos, Size size)
            : this(parent, id, pos, size, null, WindowStyles.NO_STYLE, null) { }
	
		public ListBox(Window parent, int id, Point pos, Size size, string[] choices)
            : this(parent, id, pos, size, choices, WindowStyles.NO_STYLE, null) { }

        public ListBox(Window parent, int id, Point pos, Size size, string[] choices, WindowStyles style)
			: this(parent, id, pos, size, choices, style, null) { }

        public ListBox(Window parent, int id, Point pos, Size size, string[] choices, WindowStyles style, string name)
            : this(parent, id, pos, size, ArrayString.SafeNewFrom(choices), style, new wxString(name))
        {
        }
        internal ListBox(Window parent, int id, Point pos, Size size, ArrayString choices, WindowStyles style, wxString name)
			: base(wxListBox_ctor())
		{
			if(!wxListBox_Create(wxObject, Object.SafePtr(parent), id,
					ref pos, ref size, Object.SafePtr(choices), (uint)style,
					IntPtr.Zero, Object.SafePtr(name)))
			{
				throw new InvalidOperationException("Failed to create ListBox");
			}
		}
		
		//---------------------------------------------------------------------
		// ctors with self created id
		
		public ListBox(Window parent)
			: this(parent, Window.UniqueID, wxDefaultPosition, wxDefaultSize, null, wx.WindowStyles.NO_STYLE, null) { }
	
		public ListBox(Window parent, Point pos)
            : this(parent, Window.UniqueID, pos, wxDefaultSize, null, wx.WindowStyles.NO_STYLE, null) { }
	
		public ListBox(Window parent, Point pos, Size size)
            : this(parent, Window.UniqueID, pos, size, null, wx.WindowStyles.NO_STYLE, null) { }
	
		public ListBox(Window parent, Point pos, Size size, string[] choices)
			: this(parent, Window.UniqueID, pos, size, choices, 0, null) { }

        public ListBox(Window parent, Point pos, Size size, string[] choices, wx.WindowStyles style)
			: this(parent, Window.UniqueID, pos, size, choices, style, null) { }

        public ListBox(Window parent, Point pos, Size size, string[] choices, wx.WindowStyles style, string name)
            : this(parent, Window.UniqueID, pos, size, ArrayString.SafeNewFrom(choices), style, new wxString(name))
        {
        }
        internal ListBox(Window parent, Point pos, Size size, ArrayString choices, wx.WindowStyles style, wxString name)
			: this( parent, Window.UniqueID, pos, size, choices, style, name)
        {
        }
		
		//---------------------------------------------------------------------

        public bool Create(Window parent, int id, Point pos, Size size, string[] choices, wx.WindowStyles style, string name)
        {
            return this.Create(parent, id, pos, size, ArrayString.SafeNewFrom(choices), style, new wxString(name));
        }
        internal bool Create(Window parent, int id, Point pos, Size size, ArrayString choices, wx.WindowStyles style, wxString name)
		{
			return wxListBox_Create(wxObject, Object.SafePtr(parent), id, ref pos, ref size, Object.SafePtr(choices), (uint)style, IntPtr.Zero, Object.SafePtr(name));
		}
		
		protected override void CallDTor ()
		{
			wxListBox_dtor(this.wxObject);
		}

		#endregion
		//---------------------------------------------------------------------
			
		public void InsertItems(string[] items, int pos)
		{
		    this.InsertItems(ArrayString.SafeNewFrom(items), pos);
		}
        internal void InsertItems(ArrayString items, int pos)
        {
            wxListBox_InsertItems(wxObject, Object.SafePtr(items), pos);
        }
	
		//---------------------------------------------------------------------

        public void Set(string[] items, ClientData[] data)
        {
            this.Set(new ArrayString(items), data);
        }

        internal void Set(ArrayString items, ClientData[] data)
		{
            if (items.Count != data.Length)
                throw new ArgumentOutOfRangeException("data");
            IntPtr[] clientobjects = new IntPtr[data.Length];
            for (int i = 0; i < data.Length; ++i)
            {
                clientobjects[i] = data[i].wxObject;
            }
            wxListBox_Set(wxObject, Object.SafePtr(items), clientobjects);
		}

        public void Set(string[] items)
        {
            this.Set(new ArrayString(items));
        }
        internal void Set(ArrayString items)
		{
			wxListBox_Set(this.wxObject, Object.SafePtr(items), null);
		}
	
		//---------------------------------------------------------------------
		
		public bool Sorted
		{
			get { return wxListBox_IsSorted(wxObject); }
		}
	
		//---------------------------------------------------------------------
	
		public bool HasMultipleSelection()
		{
			return wxListBox_HasMultipleSelection(wxObject);
		}
	
		//---------------------------------------------------------------------
	
		public void Deselect(int n)
		{
			wxListBox_Deselect(wxObject, n);
		}
	
		public void DeselectAll(int itemToLeaveSelected)
		{
			wxListBox_DeselectAll(wxObject, itemToLeaveSelected);
		}
	
		//---------------------------------------------------------------------
	
		public int[] Selections
		{
			get { return new ArrayInt(wxListBox_GetSelections(wxObject), true); }
		}
	
		//---------------------------------------------------------------------
	
		public void SetFirstItem(int n)
		{
			wxListBox_SetFirstItem(wxObject, n);
		}
	
		public void SetFirstItem(string s)
		{
            this.SetFirstItem(new wxString(s));
        }
        public void SetFirstItem(wxString s)
        {
			wxListBox_SetFirstItemText(this.wxObject, s.wxObject);
		}
	
		//---------------------------------------------------------------------
	
		public void Command(Event evt)
		{
			wxListBox_Command(wxObject, Object.SafePtr(evt));
		}
	
		//---------------------------------------------------------------------
		
		public event EventListener Select
		{
			add { AddCommandListener(Event.wxEVT_COMMAND_LISTBOX_SELECTED, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}
	
		public event EventListener DoubleClick
		{
			add { AddCommandListener(Event.wxEVT_COMMAND_LISTBOX_DOUBLECLICKED, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}
	}
	
	//---------------------------------------------------------------------
	
	public class CheckListBox : ListBox
	{
		[DllImport("wx-c")] static extern IntPtr wxCheckListBox_ctor1();
		[DllImport("wx-c")] static extern IntPtr wxCheckListBox_ctor2(IntPtr parent, 
			int id,
			ref Point pos,
			ref Size size,
			IntPtr choices,
			uint style,
			IntPtr validator,
			IntPtr name);
		[DllImport("wx-c")] static extern bool wxCheckListBox_IsChecked(IntPtr self, int index);
		[DllImport("wx-c")] static extern void wxCheckListBox_Check(IntPtr self, int index, bool check);
		[DllImport("wx-c")] static extern int wxCheckListBox_GetItemHeight(IntPtr self);
		
		//---------------------------------------------------------------------
	
		public CheckListBox(IntPtr wxObject)
			: base(wxObject) {}
			
		public CheckListBox()
			: base(wxCheckListBox_ctor1()) {}
			
		public CheckListBox(Window parent, int id)
			: this(parent, id, wxDefaultPosition, wxDefaultSize, (string[])null, wx.WindowStyles.NO_STYLE, null) {}
			
		public CheckListBox(Window parent, int id, Point pos)
			: this(parent, id, pos, wxDefaultSize, (string[])null, wx.WindowStyles.NO_STYLE, null) {}
			
		public CheckListBox(Window parent, int id, Point pos, Size size)
			: this(parent, id, pos, size, (string[])null, wx.WindowStyles.NO_STYLE, null) {}
			
		public CheckListBox(Window parent, int id, Point pos, Size size, string[] choices)
			: this(parent, id, pos, size, choices, wx.WindowStyles.NO_STYLE, null) {}
			
		public CheckListBox(Window parent, int id, Point pos, Size size, string[] choices, wx.WindowStyles style)
			: this(parent, id, pos, size, choices, style, null) {}
						
		public CheckListBox(Window parent, int id, Point pos, Size size, string[] choices, wx.WindowStyles style, string name)
			: this(parent, id, pos, size, ArrayString.SafeNewFrom(choices), style, new wxString(name))
        {
        }
        internal CheckListBox(Window parent, int id, Point pos, Size size, ArrayString choices, wx.WindowStyles style, wxString name)
			: base(wxCheckListBox_ctor2(Object.SafePtr(parent), id, ref pos, ref size, Object.SafePtr(choices), (uint)style, IntPtr.Zero, name.wxObject))
        {
        }
			
		//---------------------------------------------------------------------
		// ctors with self created id
			
		public CheckListBox(Window parent)
            : this(parent, Window.UniqueID, wxDefaultPosition, wxDefaultSize, null, wx.WindowStyles.NO_STYLE, null) { }
			
		public CheckListBox(Window parent, Point pos)
            : this(parent, Window.UniqueID, pos, wxDefaultSize, null, wx.WindowStyles.NO_STYLE, null) { }
			
		public CheckListBox(Window parent, Point pos, Size size)
			: this(parent, Window.UniqueID, pos, size, null, wx.WindowStyles.NO_STYLE, null) {}
			
		public CheckListBox(Window parent, Point pos, Size size, string[] choices)
			: this(parent, Window.UniqueID, pos, size, choices, wx.WindowStyles.NO_STYLE, null) {}
			
		public CheckListBox(Window parent, Point pos, Size size, string[] choices, wx.WindowStyles style)
			: this(parent, Window.UniqueID, pos, size, choices, style, null) {}
			
		public CheckListBox(Window parent, Point pos, Size size, string[] choices, wx.WindowStyles style, string name)
			: this(parent, Window.UniqueID, pos, size, choices, style, name) {}
			
		//--------------------------------------------------------------------
		
		public bool IsChecked(int index)
		{
			return wxCheckListBox_IsChecked(wxObject, index);
		}
		
		//---------------------------------------------------------------------
		
		public void Check(int index)
		{
			Check(index, true);
		}
		
		public void Check(int index, bool check)
		{
			wxCheckListBox_Check(wxObject, index, check);
		}
		
		//---------------------------------------------------------------------

        /** <summary>Returns the item height.
         * This is not supported for <c>wx.ReflectConfig.CheckWxMAC</c>.
         * </summary>
         */
        public int ItemHeight
		{
			get
            {
                if (ReflectConfig.CheckWxMAC())
                    throw new NotSupportedException("Not supported for wxMAC");
                return wxCheckListBox_GetItemHeight(wxObject);
            }
		}
		
		//---------------------------------------------------------------------
		
		public event EventListener Checked
		{
			add { AddCommandListener(Event.wxEVT_COMMAND_CHECKLISTBOX_TOGGLED, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}
	}
}
