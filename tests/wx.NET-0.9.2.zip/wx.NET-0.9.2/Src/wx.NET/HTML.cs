//-----------------------------------------------------------------------------
// wx.NET - HTML.cs
// 
// The wxHTML wrapper classes.
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: HTML.cs,v 1.52 2010/07/12 18:23:50 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Collections;
using System.Diagnostics;
using wx.FileSys;

/** This namespace contains wrappers and utilities of the  wxWidgets HTML window.
 */
namespace wx.Html
{
	public enum HtmlURLType
	{
		wxHTML_URL_PAGE,
		wxHTML_URL_IMAGE,
		wxHTML_URL_OTHER
	}
	
	//-----------------------------------------------------------------------------
	
	public enum HtmlOpeningStatus
	{
		wxHTML_OPEN,
		wxHTML_BLOCK,
		wxHTML_REDIRECT
	}

    /** <summary>Conditions for HtmlCell.Find().</summary>*/
    public enum HtmlCond
    {
        /** <summary>Finds the anchor of 'param' name (argument is a string).</summary>*/
        IS_ANCHOR=1,

        /** <summary>Finds imagemap of 'param' name (argument is a string).</summary>*/
        IS_IMAGEMAP=2,
    }
	
    /** <summary>Refer to HtmlCell.FindCellByPos().</summary>*/
    public enum HtmlFind
    {
        EXACT             = 1,
        NEAREST_BEFORE    = 2,
        NEAREST_AFTER     = 4
    }


	//-----------------------------------------------------------------------------

    /** <summary>A window displaying (reduced) HTML formatted text.
     * </summary>
     * <remarks>
     * \image html helpview.jpg
     * </remarks>
     */
    public class HtmlWindow : ScrolledWindow
    {
        #region Public Types
        private delegate void Virtual_OnLinkClicked(IntPtr link);
        private delegate void Virtual_OnSetTitle(IntPtr title);
        private delegate void Virtual_OnCellMouseHover(IntPtr cell, int x, int y);
        private delegate bool Virtual_OnCellClicked(IntPtr cell, int x, int y, IntPtr mouseevent);
        private delegate int Virtual_OnOpeningURL(int type, IntPtr url, IntPtr redirect);
        private delegate int Virtual_LoadFile(IntPtr wxStringFilenameNativeMode);
        private delegate int Virtual_LoadPage(IntPtr wxStringLocation);
        #endregion

        #region State
        private Virtual_OnLinkClicked virtual_OnLinkClicked;
        private Virtual_OnSetTitle virtual_OnSetTitle;
        private Virtual_OnCellMouseHover virtual_OnCellMouseHover;
        private Virtual_OnCellClicked virtual_OnCellClicked;
        private Virtual_OnOpeningURL virtual_OnOpeningUrl;
        private Virtual_LoadFile virtual_LoadFile;
        private Virtual_LoadPage virtual_LoadPage;
        int _version = 0;
        #endregion

        #region C API
        [DllImport("wx-c")]
        static extern IntPtr wxHtmlWindow_ctor();
        [DllImport("wx-c")]
        static extern void wxHtmlWindow_RegisterVirtual(IntPtr self,
                                                        Virtual_OnLinkClicked onLinkClicked,
                                                        Virtual_OnSetTitle onSetTitle,
                                                        Virtual_OnCellMouseHover onCellMouseHover,
                                                        Virtual_OnCellClicked onCellClicked,
                                                        Virtual_OnOpeningURL onOpeningURL,
                                                        Virtual_LoadFile loadFile,
                                                        Virtual_LoadPage loadPage);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxHtmlWindow_Create(IntPtr self, IntPtr parent, int id, ref Point pos, ref Size size, uint style, IntPtr name);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxHtmlWindow_SetPage(IntPtr self, IntPtr source);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxHtmlWindow_AppendToPage(IntPtr self, IntPtr source);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxHtmlWindow_LoadPage(IntPtr self, IntPtr location);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxHtmlWindow_LoadFile(IntPtr self, IntPtr filename);
        [DllImport("wx-c")]
        static extern IntPtr wxHtmlWindow_GetOpenedPage(IntPtr self);
        [DllImport("wx-c")]
        static extern IntPtr wxHtmlWindow_GetOpenedAnchor(IntPtr self);
        [DllImport("wx-c")]
        static extern IntPtr wxHtmlWindow_GetOpenedPageTitle(IntPtr self);
        [DllImport("wx-c")]
        static extern void wxHtmlWindow_SetRelatedFrame(IntPtr self, IntPtr frame, IntPtr format);
        [DllImport("wx-c")]
        static extern IntPtr wxHtmlWindow_GetRelatedFrame(IntPtr self);
        [DllImport("wx-c")]
        static extern void wxHtmlWindow_SetRelatedStatusBar(IntPtr self, int bar);
        [DllImport("wx-c")]
        static extern void wxHtmlWindow_SetFonts(IntPtr self, IntPtr normal_face, IntPtr fixed_face, int[] sizes);
        [DllImport("wx-c")]
        static extern void wxHtmlWindow_SetBorders(IntPtr self, int b);
        [DllImport("wx-c")]
        static extern void wxHtmlWindow_ReadCustomization(IntPtr self, IntPtr cfg, IntPtr path);
        [DllImport("wx-c")]
        static extern void wxHtmlWindow_WriteCustomization(IntPtr self, IntPtr cfg, IntPtr path);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxHtmlWindow_HistoryBack(IntPtr self);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxHtmlWindow_HistoryForward(IntPtr self);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxHtmlWindow_HistoryCanBack(IntPtr self);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxHtmlWindow_HistoryCanForward(IntPtr self);
        [DllImport("wx-c")]
        static extern void wxHtmlWindow_HistoryClear(IntPtr self);
        [DllImport("wx-c")]
        static extern IntPtr wxHtmlWindow_GetInternalRepresentation(IntPtr self);
        //[DllImport("wx-c")]static extern void wxHtmlWindow_AddFilter(IntPtr filter);
        [DllImport("wx-c")]
        static extern IntPtr wxHtmlWindow_GetParser(IntPtr self);
        [DllImport("wx-c")]
        static extern void wxHtmlWindow_AddProcessor(IntPtr self, IntPtr processor);
        [DllImport("wx-c")]
        static extern void wxHtmlWindow_AddGlobalProcessor(IntPtr processor);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxHtmlWindow_AcceptsFocusFromKeyboard(IntPtr self);
        [DllImport("wx-c")]
        static extern void wxHtmlWindow_OnSetTitle(IntPtr self, IntPtr title);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxHtmlWindow_OnCellClicked(IntPtr self, IntPtr cell, int x, int y, IntPtr evt);
        [DllImport("wx-c")]
        static extern void wxHtmlWindow_OnLinkClicked(IntPtr self, IntPtr link);
        [DllImport("wx-c")]
        static extern int wxHtmlWindow_OnOpeningURL(IntPtr self, int type, IntPtr url, IntPtr redirect);

        [DllImport("wx-c")]
        static extern void wxHtmlWindow_SelectAll(IntPtr self);
        [DllImport("wx-c")]
        static extern void wxHtmlWindow_SelectWord(IntPtr self, ref Point pos);
        [DllImport("wx-c")]
        static extern void wxHtmlWindow_SelectLine(IntPtr self, ref Point pos);
        [DllImport("wx-c")]
        static extern void wxHtmlWindow_SelectCells(IntPtr self, IntPtr firstCell, IntPtr lastCell);

        [DllImport("wx-c")]
        static extern IntPtr wxHtmlWindow_ToText(IntPtr self);

        [DllImport("wx-c")]
        static extern IntPtr wxHtmlWindow_SelectionToText(IntPtr self);

        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxHtmlWindow_HasSelection(IntPtr self);

        [DllImport("wx-c")]
        static extern IntPtr wxHtmlWindow_SelectionFromCell(IntPtr self);
        [DllImport("wx-c")]
        static extern IntPtr wxHtmlWindow_SelectionToCell(IntPtr self);
        [DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxHtmlWindow_SelectionPosition(IntPtr self, ref int fromX, ref int fromY, ref int toX, ref int toY);
        #endregion

        #region CTor
        public HtmlWindow(IntPtr wxObject)
            : base(wxObject) { }

        public HtmlWindow()
            : base(wxHtmlWindow_ctor()) { }

        public HtmlWindow(Window parent, int id)
            : this(parent, id, wxDefaultPosition, wxDefaultSize, wx.WindowStyles.HW_SCROLLBAR_AUTO, "HtmlWindow") { }

        public HtmlWindow(Window parent, int id, Point pos)
            : this(parent, id, pos, wxDefaultSize, wx.WindowStyles.HW_SCROLLBAR_AUTO, "HtmlWindow") { }

        public HtmlWindow(Window parent, int id, Point pos, Size size)
            : this(parent, id, pos, size, wx.WindowStyles.HW_SCROLLBAR_AUTO, "HtmlWindow") { }

        public HtmlWindow(Window parent, int id, Point pos, Size size, wx.WindowStyles style)
            : this(parent, id, pos, size, style, "HtmlWindow") { }

        public HtmlWindow(Window parent, int id, Point pos, Size size, wx.WindowStyles style, string name)
            : base(wxHtmlWindow_ctor())
        {
            virtual_OnLinkClicked = new Virtual_OnLinkClicked(DoOnLinkClicked);
            virtual_OnSetTitle = new Virtual_OnSetTitle(DoOnSetTitle);
            virtual_OnCellMouseHover = new Virtual_OnCellMouseHover(DoOnCellMouseHover);
            virtual_OnCellClicked = new Virtual_OnCellClicked(DoOnCellClicked);
            virtual_OnOpeningUrl = new Virtual_OnOpeningURL(DoOnOpeningURL);
            virtual_LoadFile = new Virtual_LoadFile(DoLoadFile);
            virtual_LoadPage = new Virtual_LoadPage(DoLoadPage);

            wxHtmlWindow_RegisterVirtual(wxObject,
                virtual_OnLinkClicked,
                virtual_OnSetTitle,
                virtual_OnCellMouseHover,
                virtual_OnCellClicked,
                virtual_OnOpeningUrl,
                virtual_LoadFile,
                virtual_LoadPage
                );

            if (!Create(parent, id, pos, size, style|wx.WindowStyles.WANTS_CHARS, name))
            {
                throw new InvalidOperationException("Failed to create HtmlWindow");
            }

            this.AddCommandListener(wx.Event.wxEVT_LOAD_HTML_PAGE, -1, new EventListener(this.OnLoadPageEvent));
        }

        //---------------------------------------------------------------------
        // ctors with self created id

        public HtmlWindow(Window parent)
            : this(parent, Window.UniqueID, wxDefaultPosition, wxDefaultSize, wx.WindowStyles.HW_SCROLLBAR_AUTO, "HtmlWindow") { }

        public HtmlWindow(Window parent, Point pos)
            : this(parent, Window.UniqueID, pos, wxDefaultSize, wx.WindowStyles.HW_SCROLLBAR_AUTO, "HtmlWindow") { }

        public HtmlWindow(Window parent, Point pos, Size size)
            : this(parent, Window.UniqueID, pos, size, wx.WindowStyles.HW_SCROLLBAR_AUTO, "HtmlWindow") { }

        public HtmlWindow(Window parent, Point pos, Size size, wx.WindowStyles style)
            : this(parent, Window.UniqueID, pos, size, style, "HtmlWindow") { }

        public HtmlWindow(Window parent, Point pos, Size size, wx.WindowStyles style, string name)
            : this(parent, Window.UniqueID, pos, size, style, name) { }

        //-----------------------------------------------------------------------------

        public new bool Create(Window parent, int id, Point pos, Size size, wx.WindowStyles style, string name)
        {
            return this.Create(parent, id, pos, size, style, wxString.SafeNew(name));
        }
        new public bool Create(Window parent, int id, Point pos, Size size, wx.WindowStyles style, wxString name)
        {
            return wxHtmlWindow_Create(wxObject, Object.SafePtr(parent), id, ref pos, ref size, (uint)style, name.wxObject);
        }
        #endregion

        #region Loading a new Page
        /** <summary>This has to be called before changing the displayed HTML page.
         * This method increments the version counter and will remove the wrappers
         * of the currently displayed page if they don't own their memory.</summary>
         */
        void OnNewPage()
        {
            ++this._version;
            if (this._findDialog != null)
            {
                // destroy the find dialog if open.
                this._findDialog.Destroy();
                this._findDialog = null;
            }
            this.InternalRepresentation.DisposeAllNonOwners();
        }

        IList _widgetCells = new ArrayList();
        /** <summary>A .NET wx.HtmlWidgetCell will register itself here.
         * Reason: ClearWidgetCells().</summary>
         * */
        internal void RegisterWidgetCell(HtmlWidgetCell cell)
        {
            this._widgetCells.Add(cell);
        }

        /** <summary>This will make all widgets in cells invisible and clear the list of registered cells.
         * This is a work around a bug in the HTML framework: If we load an existing</summary> wx.HtmlWindow
         * with a new page with new instances of wx.HtmlWidgetCell, all the old instances of
         * wx.HtmlWidgetCell not be destroyed immediately. This usually disturbs the event chain.
         * So, the \e wx.NET system will make widget cells invisible as soon as they will be
         * replaced.</summary>
         */
        internal void SetInvisibleWidgetCells()
        {
            foreach (HtmlWidgetCell cell in this._widgetCells)
            {
                if (!cell.disposed) // this can happen if the previous page containing controls has never been shown
                {
                    cell.Window.Disable();
                    cell.Window.Show(false);
                }
            }
            this._widgetCells.Clear();
        }

        /** <summary>This will set a new HTML text to be displayed.</summary>
         * <param name="source">The HTML source code that shall be displayed.</param>
         */
        public bool SetPage(string source)
        {
            using (wxString newPageSource = new wxString(source))
            {
                return this.SetPage(newPageSource);
            }
        }
        /** <summary>This will set a new HTML text to be displayed.</summary>
         * <param name="source">The HTML source code that shall be displayed.</param>
         */
        public bool SetPage(wxString source)
        {
            this.SetInvisibleWidgetCells();
            this.OnNewPage();
            return wxHtmlWindow_SetPage(wxObject, source.wxObject);
        }

        /** <summary>This will append string <c>source</c> to the currently displayed text.</summary>
         */
        public bool AppendToPage(string source)
        {
            using (wxString wxSrc = new wxString(source))
            {
                return this.AppendToPage(wxSrc);
            }
        }
        /** <summary>This will append string \c source to the currently displayed text.</summary>
         */
        public bool AppendToPage(wxString source)
        {
            this.OnNewPage();
            return wxHtmlWindow_AppendToPage(wxObject, source.wxObject);
        }

        //-----------------------------------------------------------------------------

        /** <summary>Call this only on wx.CommandEvent().
         * This will load the page URL retrieved from the client string wx.CommandEvent.String.
         * </summary>
         */
        internal void OnLoadPageEvent(object sender, Event evt)
        {
            if (evt is CommandEvent)
            {
                CommandEvent cevt = (CommandEvent)evt;
                if (!LoadPage(cevt.String)) cevt.Skip(true);
            }
            else
                evt.Skip(true);
        }

        /** <summary>Overload this to change the behaviour on loading a page from the designated location.
         * Refer to FSFile and FileSystemHandler for remarks on available locations.</summary>
         */
        public virtual bool LoadPage(string location)
        {
            wxString wxLocation = new wxString(location);
            return this.LoadPage(wxLocation);
        }

        /** <summary>Overload this to change the behaviour on loading a page from the designated location.
         * Refer to FSFile and FileSystemHandler for remarks on available locations.</summary>
         */
        public virtual bool LoadPage(wxString location)
        {
            this.SetInvisibleWidgetCells();
            this.OnNewPage();
            return wxHtmlWindow_LoadPage(wxObject, location.wxObject);
        }

        private int DoLoadPage(IntPtr clocation)
        {
            wxString location = new wxString(clocation, false);
            return this.LoadPage(location) ? 1 : 0;
        }

        /** <summary>Overload this to change the behaviour on loading a file.
         * The argument is a file name in native style.</summary>
         */
        virtual public bool LoadFile(string filename)
        {
            return this.LoadFile(new wxString(filename));
        }

        /** <summary>Overload this to change the behaviour on loading a file.
         * The argument is a file name in native style.</summary>
         */
        virtual public bool LoadFile(wxString filename)
        {
            return wxHtmlWindow_LoadFile(wxObject, filename.wxObject);
        }

        private int DoLoadFile(IntPtr cfilename)
        {
            wxString filename = new wxString(cfilename);
            return this.LoadFile(filename) ? 1 : 0;
        }
        #endregion

        #region Properties of the open page
        /** <summary>HTML text displayed by this window.</summary>
         */
        public string OpenedPage
        {
            get { return new wxString(wxHtmlWindow_GetOpenedPage(wxObject), true); }
        }

        public string OpenedAnchor
        {
            get { return new wxString(wxHtmlWindow_GetOpenedAnchor(wxObject), true); }
        }

        public string OpenedPageTitle
        {
            get { return new wxString(wxHtmlWindow_GetOpenedPageTitle(wxObject), true); }
        }

        /** <summary>This will be incremented whenver the displayed document changes.</summary>
         */
        public int Version { get { return this._version; } }
        #endregion

        #region Related Frame
        /** <summary>Sets the related frame.
         * This window will change the title of the related frame according to
         * the title definition of the displayed HTML text.</summary>
         * <remarks>
         * Sample: 
         <code>
         m_html.SetRelatedFrame(this, "HTML: %s");
         </code>
         * This will display the title according to the displayed HTML page plus
         * a prefix "HTML:"
         * </remarks>
         */
        public void SetRelatedFrame(Frame frame, string format)
        {
            using (wxString wxformat = new wxString(format))
            {
                this.SetRelatedFrame(frame, new wxString(wxformat));
            }
        }
        /** <summary>Sets the related frame.
         * This window will change the title of the related frame according to
         * the title definition of the displayed HTML text.</summary>
         */
        public void SetRelatedFrame(Frame frame, wxString format)
        {
            wxHtmlWindow_SetRelatedFrame(wxObject, Object.SafePtr(frame), format.wxObject);
        }

        /** <summary>Set or gets the related frame.
         * This window will change the title of the related frame according to
         * the title definition of the displayed HTML text.
         * This will simply use "%s" as format for the related frame.</summary>
         */
        public Frame RelatedFrame
        {
            get
            {
                return (Frame)FindObject(wxHtmlWindow_GetRelatedFrame(wxObject),
                    typeof(Frame));
            }
            set
            {
                this.SetRelatedFrame(value, "%s");
            }
        }

        public int RelatedStatusBar
        {
            set { wxHtmlWindow_SetRelatedStatusBar(wxObject, value); }
        }
        #endregion

        //-----------------------------------------------------------------------------

        public void SetFonts(string normal_face, string fixed_face, int[] sizes)
        {
            this.SetFonts(new wxString(normal_face), new wxString(fixed_face), sizes);
        }
        public void SetFonts(wxString normal_face, wxString fixed_face, int[] sizes)
        {
            wxHtmlWindow_SetFonts(wxObject, normal_face.wxObject, fixed_face.wxObject, sizes);
        }

        //-----------------------------------------------------------------------------

        public int Borders
        {
            set { wxHtmlWindow_SetBorders(wxObject, value); }
        }

        #region Write And Read Customization
        /** <summary>The HTML window is able to configure several properties.
         * You may read from a particular configuration to reuse settings that have
         * been done on previous runs of the appliation.
         * Cf. WriteCustomization().</summary>
         */
        public virtual void ReadCustomization(Config cfg)
        {
            this.ReadCustomization(cfg, "");
        }
        /** <summary>The HTML window is able to configure several properties.
         * You may read from a particular configuration to reuse settings that have
         * been done on previous runs of the appliation.
         * Cf. WriteCustomization().</summary>
         */
        public virtual void ReadCustomization(Config cfg, string path)
        {
            this.ReadCustomization(cfg, new wxString(path));
        }
        /** <summary>The HTML window is able to configure several properties.
         * You may read from a particular configuration to reuse settings that have
         * been done on previous runs of the appliation.</summary>
         */
        void ReadCustomization(Config cfg, wxString path)
        {
            wxHtmlWindow_ReadCustomization(wxObject, Object.SafePtr(cfg), path.wxObject);
        }


        /** <summary>The HTML window is able to configure several properties.
         * You may read from a particular configuration to reuse settings that have
         * been done on previous runs of the appliation.
         * Cf. ReadCustomization().</summary>
         */
        public void WriteCustomization(Config cfg)
        {
            WriteCustomization(cfg, "");
        }
        /** <summary>The HTML window is able to configure several properties.
         * You may read from a particular configuration to reuse settings that have
         * been done on previous runs of the appliation.
         * Cf. ReadCustomization().</summary>
         */
        public virtual void WriteCustomization(Config cfg, string path)
        {
            WriteCustomization(cfg, new wxString(path));
        }
        void WriteCustomization(Config cfg, wxString path)
        {
            wxHtmlWindow_WriteCustomization(wxObject, Object.SafePtr(cfg), path.wxObject);
        }
        #endregion

        #region Navigation History
        public bool HistoryBack()
        {
            return wxHtmlWindow_HistoryBack(wxObject);
        }

        public bool HistoryForward()
        {
            return wxHtmlWindow_HistoryForward(wxObject);
        }

        public bool HistoryCanBack()
        {
            return wxHtmlWindow_HistoryCanBack(wxObject);
        }

        public bool HistoryCanForward()
        {
            return wxHtmlWindow_HistoryCanForward(wxObject);
        }

        public void HistoryClear()
        {
            lock (wx.Object.DllSync)
            {
                wxHtmlWindow_HistoryClear(wxObject);
            }
        }
        #endregion


        /** <summary>Use this to gain access to the internal representation of the displayed HTML text.
         * HTML is displayed as a tree of cells where the container cell represends a node
         * with occasionally more than one sibling.</summary>
         */
        public HtmlContainerCell InternalRepresentation
        {
            get { return (HtmlContainerCell)FindObject(wxHtmlWindow_GetInternalRepresentation(wxObject), typeof(HtmlContainerCell)); }
        }

        //-----------------------------------------------------------------------------

        public HtmlWinParser Parser
        {
            get { return (HtmlWinParser)FindObject(wxHtmlWindow_GetParser(wxObject), typeof(HtmlWinParser)); }
        }

        //-----------------------------------------------------------------------------

        public void AddProcessor(HtmlProcessor processor)
        {
            wxHtmlWindow_AddProcessor(wxObject, Object.SafePtr(processor));
        }

        public static void AddGlobalProcessor(HtmlProcessor processor)
        {
            wxHtmlWindow_AddGlobalProcessor(Object.SafePtr(processor));
        }

        //-----------------------------------------------------------------------------

        public override bool AcceptsFocusFromKeyboard()
        {
            return wxHtmlWindow_AcceptsFocusFromKeyboard(wxObject);
        }

        //-----------------------------------------------------------------------------

        private void DoOnSetTitle(IntPtr title)
        {
            OnSetTitle((string)new wxString(title, false));
        }

        public virtual void OnSetTitle(string title)
        {
            this.OnSetTitle(new wxString(title));
        }
        void OnSetTitle(wxString title)
        {
            wxHtmlWindow_OnSetTitle(wxObject, title.wxObject);
        }

        //-----------------------------------------------------------------------------

        private void DoOnCellMouseHover(IntPtr cell, int x, int y)
        {
            HtmlCell cellWrapper = (HtmlCell)Object.FindOrCreateObjectUsingClassInfo(cell);
            OnCellMouseHover(cellWrapper, x, y);
        }

        /** <summary>This will be called when the mouse is moved over the cell.</summary>
         */
        public virtual void OnCellMouseHover(HtmlCell cell, int x, int y)
        {
            // Do nothing here
        }

        //-----------------------------------------------------------------------------

        private bool DoOnCellClicked(IntPtr cell, int x, int y, IntPtr mouseevent)
        {
            HtmlCell cellWrapper = (HtmlCell)Object.FindOrCreateObjectUsingClassInfo(cell);
            MouseEvent evt = (MouseEvent)Object.FindObject(mouseevent);
            if (evt == null)
                evt = new MouseEvent(mouseevent);
            return OnCellClicked(cellWrapper, x, y, evt);
        }

        /** <summary>This is called when the user clicks at a particular cell.</summary>
         */
        public virtual bool OnCellClicked(HtmlCell cell, int x, int y, MouseEvent evt)
        {
            return wxHtmlWindow_OnCellClicked(wxObject, Object.SafePtr(cell), x, y, Object.SafePtr(evt));
        }

        //-----------------------------------------------------------------------------

        private void DoOnLinkClicked(IntPtr link)
        {
            OnLinkClicked(new HtmlLinkInfo(link));
        }

        /** <summary>This is called when the user clicks on a cell representing a hyper link.</summary>
         */
        public virtual void OnLinkClicked(HtmlLinkInfo link)
        {
            wxHtmlWindow_OnLinkClicked(wxObject, Object.SafePtr(link));
        }

        //-----------------------------------------------------------------------------

        private int DoOnOpeningURL(int type, IntPtr url, IntPtr redirect)
        {
            return (int)OnOpeningURL((HtmlURLType)type, (string)new wxString(url, true), (string)new wxString(redirect, false));
        }

        public virtual HtmlOpeningStatus OnOpeningURL(HtmlURLType type, string url, string redirect)
        {
            wxString wxRedirect = new wxString(redirect);
            HtmlOpeningStatus result = this.OnOpeningURL(type, new wxString(url), wxRedirect);
            redirect = wxRedirect;
            return result;
        }

        HtmlOpeningStatus OnOpeningURL(HtmlURLType type, wxString url, wxString redirect)
        {
            return (HtmlOpeningStatus)wxHtmlWindow_OnOpeningURL(wxObject, (int)type, url.wxObject, redirect.wxObject);
        }

        //-----------------------------------------------------------------------------

        /** <summary>This will select the whole text.</summary>
         */
        public void SelectAll()
        {
            wxHtmlWindow_SelectAll(wxObject);
        }

        //-----------------------------------------------------------------------------

        /** <summary>This will select a line in the text.
         * Please note, that this method will not scroll to the selected word.
         * Call wx.Window.Scroll().</summary>
         */
        public void SelectLine(Point pos)
        {
            wxHtmlWindow_SelectLine(wxObject, ref pos);
        }

        #region Selections
        /** <summary>This will select a word that is displayed at the provided position.
         * Please note, that this method will not scroll to the selected word.
         * Call wx.Window.Scroll().</summary>*/
        public void SelectWord(Point pos)
        {
            bool alreadyHaveSelection=this.HasSelection;
            wxHtmlWindow_SelectWord(wxObject, ref pos);
            if (alreadyHaveSelection)
                this.Refresh(); // work around a missing refresh
        }

        /** <summary>This will select the content of the provided cell.
         * Note, that the provided cell may be a formatting cell. So, you might
         * see nothing of the selection.
         * 
         * Please also note, that this method will not scroll the window to
         * the selected cell. Call ScrollToCell() for this purpose.</summary>*/
        public void SelectCell(HtmlCell cell)
        {
            wxHtmlWindow_SelectCells(this.wxObject, Object.SafePtr(cell), Object.SafePtr(cell));
        }

        /** <summary>Additional method to select cells.
        * <c>fromCell</c> and <c>lastCell</c> may be the same cell. Otherwise,
        * leafs of <c>fromCell</c> must be before those of <c>lastCell</c> when traversing
        * the HTML document.</summary>*/
        internal void SelectCells(HtmlCell firstCell, HtmlCell lastCell)
        {
            wxHtmlWindow_SelectCells(this.wxObject, Object.SafePtr(firstCell), Object.SafePtr(lastCell));
        }

        /** <summary>This will scroll to the position of the provided cell.</summary><remarks>
         * Equivalent to \code this.Scroll(cell.AbsPos) \endcode.</remarks>*/
        public void ScrollToCell(HtmlCell cell)
        {
            this.Scroll(cell.AbsPos);
        }

        /** <summary>This is true if the window knows a selection.</summary>*/
        public bool HasSelection
        {
            get { return wxHtmlWindow_HasSelection(this.wxObject); }
        }

        /** <summary>This contains detailled information of a selection if there is any.</summary>*/
        public class InfoOnSelection
        {
            Point _fromPos;
            Point _toPos;
            HtmlCell _fromCell;
            HtmlCell _toCell;
            string _text;
            HtmlWindow _window;

            /** <summary>This will read and store the current information on the provided window.
             * This will throw an exception if the argument does not have a selection.</summary>*/
            internal InfoOnSelection(HtmlWindow window)
            {
                if (window.HasSelection)
                {
                    this._window=window;
                    int fromX=0;
                    int fromY=0;
                    int toX=0;
                    int toY=0;
                    wxHtmlWindow_SelectionPosition(Object.SafePtr(window), ref fromX, ref fromY, ref toX, ref toY);
                    this._fromPos = new Point(fromX, fromY);
                    this._toPos = new Point(toX, toY);
                    this._fromCell = (HtmlCell)Object.FindObject(
                        wxHtmlWindow_SelectionFromCell(Object.SafePtr(window)), typeof(HtmlCell));
                    this._toCell = (HtmlCell)Object.FindObject(
                        wxHtmlWindow_SelectionToCell(Object.SafePtr(window)), typeof(HtmlCell));
                    this._text = this._window.SelectionText;
                }
                else
                    throw new ArgumentException("Cannot retrieve selection info from an HTML window without selection.");
            }

            /** <summary>This is the window where the selection has been recorded.</summary>*/
            public HtmlWindow Window { get { return this._window; } }

            /** <summary>This will return the position where the current selection starts.</summary>*/
            public Point FromPosition { get { return this._fromPos; } }

            /** <summary>This will return the position where the current selection ends.</summary>*/
            public Point ToPosition { get { return this._toPos; } }

            /** <summary>This is the first cell of selected content.</summary>*/
            public HtmlCell FromCell { get { return this._fromCell; } }

            /** <summary>This is the last cell of selected content.</summary>*/
            public HtmlCell ToCell { get { return this._toCell; } }

            /** <summary>Returns the selected text.</summary>*/
            public string Text { get { return this._text; } }
        }

        /** <summary>Returns a new instance providing information in the current selection.
         * The result will be <c>null</c> if nothing is selected.</summary>*/
        public InfoOnSelection SelectionInfo
        {
            get
            {
                if (this.HasSelection)
                    return new InfoOnSelection(this);
                return null;
            }
        }
       
        /** <summary>This is the displayed HTML as text.</summary>*/
        public string Text
        {
            get { return new wxString(wxHtmlWindow_ToText(wxObject), true); }
        }

        //-----------------------------------------------------------------------------

        /** <summary>This is the selected part of the HTML</summary>*/
        public string SelectionText
        {
            get { return new wxString(wxHtmlWindow_SelectionToText(wxObject), true); }
        }
        #endregion

        #region Searching HTML Text
        static string _titleFindDialog=null;
        static string TitleFindDialog
        {
            get
            {
                if (_titleFindDialog==null)
                    _titleFindDialog=_("Searching the HTML page");
                return _titleFindDialog;
            }
        }

        HtmlFindDialog _findDialog = null;
        /** <summary>This is a new feature explusive to  wx.NET: A search dialog for searching the presented HTML page.
         * This will read the dialog and create one if this has not yet been created.
         * You may alteratively use ShowFindDialog() to show the dialog with particular data.</summary>*/
        public HtmlFindDialog FindDialog
        {
            get
            {
                if (this._findDialog == null)
                {
                    FindReplaceData data = new FindReplaceData();
                    data.FindString = this.SelectionText;
                    this._findDialog = new HtmlFindDialog(this, data, TitleFindDialog);
                }
                return this._findDialog;
            }
        }

        /** <summary>This will open a find dialog for the current HTML page.
         * The result will be <c>true</c> in case of success and <c>false</c> in case of any problem.
         * This method will fail to open the dialog if it is already open.
         * 
         * Cf. wx.HtmlWindow.FindDialog and HtmlFindDialog.</summary>*/
        public bool OpenFindDialog(FindReplaceData data)
        {
            if (this._findDialog != null && this._findDialog.State==HtmlFindDialog.States.Searching)
                return false;

            if (this._findDialog == null || this._findDialog.State==HtmlFindDialog.States.Closed)
            {
                if (this._findDialog != null)
                    this._findDialog.Dispose();
                this._findDialog = new HtmlFindDialog(this, data, TitleFindDialog);
            }
            else
            {
                this._findDialog.Data = data;
            }
            if (!this._findDialog.IsShown)
                this._findDialog.Show(true);
            return true;
        }
        #endregion
    }
		
    //-----------------------------------------------------------------------------

    /** <summary>This is a pure .NET 2 implementation iterating over terminal siblings of an wx.HtmlCell.
     * You may turn this off defining <c>NET_1_1_ONLY</c> on compilation.
     * 
     * You may increment or decrement the iterator. The iterator will complete a list of all
     * terminal cells on demand. Once this list has been created, it will not be maintained. So,
     * you probably will encounter problems if you edit cells while iterating thair siblings.
     * </summary>
     */
    public class HtmlTerminalCellIterator : System.Collections.Generic.IEnumerator<HtmlCell>
    {
        #region Public Types
        /** <summary>Something of this kind will be called on searching.
         * \param current snd <c>end</c> specify a measure for the progress. 
         * \param end is the end point for current on completed search. However, if this
         *        is negative, progress report is not supported.
         * 
         * You may return <c>false</c> in order to stop searching and <c>true</c> to proceed.</summary>*/
        public delegate bool DelegateProgressReport(int current, int end);
        #endregion

        #region State
        HtmlCell _root;
        System.Collections.Generic.List<HtmlCell> _listOfTerminalCells
            = new System.Collections.Generic.List<HtmlCell>();
        System.Collections.Generic.List<HtmlCell> _listOfSelectionStarts=null;
        int _posInList = -1;
        HtmlCell _current = null;

        bool _listOfCellsCompleted=false;
        string _originalFindString = null;
        string[] _findString = null;
        /** <summary>This will be used if searching for consecutive words to record the text
         * content of previously selected cells (wx.FindReplaceFlags.WHOLEWORD).</summary>*/
        System.Collections.Generic.Queue<HtmlCell> _currentCellSelection = null;

        FindReplaceFlags _findFlags = FindReplaceFlags.NONE;

        DelegateProgressReport _callbackProgressReport=null;
        #endregion

        #region CTor
        /** <summary>This will iterate all relevant cells that are siblings of <c>root</c>.
         * </summary>
         */
        public HtmlTerminalCellIterator(HtmlCell root)
        {
            this._root = root;
        }
        /** <summary>This will iterate all relevant cells that are siblings of <c>root</c> starting  after <c>start</c>.
         * The start of iteration is not defined if <c>start</c> is not a sibling of
         * <c>root</c>.
         * </summary>
         */
        public HtmlTerminalCellIterator(HtmlCell root, HtmlCell start)
        {
        }

        /** <summary>Set this if you want a specific function to be called regularly during search.
         * This function may terminate the search returning <c>false</c>.
         * </summary>
         */
        public DelegateProgressReport CallbackProgressReport
        {
            get { return this._callbackProgressReport; }
            set { this._callbackProgressReport = value; }
        }

        /** <summary>Central private method to create an array of words that will be used as a filter for terminal cells.
         * Use double quotes to suppress splitting.
         * </summary>
         * <param name="findFlags"> defines the mode of the search (that might influence normalization
         *        of the find string) and will be changed if the find string comprises mode specifications.
         *        If the find string is quoted by either single or double quotes, mode will switch to
         *        searching for whole words. In that case, the words in the find string do not define
         *        alternatives for matching but a sequence of constraints that have to be met.
         * </param>
         */
        static string[] LoadFindString(string findString, ref FindReplaceFlags findFlags)
        {
            findString = findString.Trim();
            if (findString.Length > 0
                && (findString[0] == '"' || findString[0] == '\'')
                )
            {
                findFlags = findFlags | FindReplaceFlags.WHOLEWORD;
                findString=findString.Trim('"', '\'');
            }
            if ((findFlags & FindReplaceFlags.MATCHCASE) == FindReplaceFlags.NONE)
                findString = findString.ToLower();
            if ((findFlags & FindReplaceFlags.WHOLEWORD)==FindReplaceFlags.NONE)
            {
                findString = findString.Replace(':', '.');
                findString = findString.Replace("..", ".");
                findString = findString.Replace("  ", " ");
                findString = findString.TrimEnd('.');
                return findString.Split(' ', ',', ';', '?', '!');
            }
            else
            {
                return findString.Split(' ');
            }
        }

        /** <summary>Enumerates terminal cells below <c>root</c> that comprise text complying with <c>findString</c>.
         * The text contents complies with <c>findString</c> if it is a word from <c>findString</c>.
         * </summary>
         */
        public HtmlTerminalCellIterator(HtmlCell root, string findString, FindReplaceFlags findFlags)
            : this(root)
        {
            this._originalFindString = findString;
            this._findFlags = findFlags;
            this._findString = LoadFindString(findString, ref this._findFlags);
        }

        /** <summary>Enumerates terminal cells below <c>root</c> starting at position after <c>start</c> that comprise text complying with <c>findString</c>.
         * The text contents complies with <c>findString</c> if it is a word from <c>findString</c>.
         * 
         * Refer to the remarks on the CTor defining a start position without a find string for
         * details on setting the start position.
         * </summary>
         */
        public HtmlTerminalCellIterator(HtmlCell root, HtmlCell start, string findString, FindReplaceFlags findFlags)
        {
            if (findString != null && findString.Length > 0)
            {
                this._originalFindString = findString.Trim();
                this._findFlags = findFlags;
                this._findString = LoadFindString(findString, ref this._findFlags);
            }
            this._root = root;
            if (findString != null && findString.Length > 0)
            {
                start = this.FindNextNode(start);

                int noOfRelevantNodes = this.ListOfCells.Count;
                this._posInList = -1;
                if (start != null && noOfRelevantNodes > 0)
                {
                    int index = 0;
                    while (this._listOfTerminalCells[0] != start && index < noOfRelevantNodes)
                    {
                        this._listOfTerminalCells.Add(this._listOfTerminalCells[0]);
                        this._listOfTerminalCells.RemoveAt(0);

                        ++index;
                    }
                    if (this._listOfTerminalCells[0] == start)
                    {
                        this._posInList = 0;
                        this._current = start;
                    }
                }
            }
        }
        #endregion

        #region IEnumerator<HtmlCell> Member
        public HtmlCell Current
        {
            get { return this._current; }
        }
        #endregion

        #region IDisposable Member
        public void Dispose()
        {
        }
        #endregion

        #region IEnumerator Member
        object IEnumerator.Current
        {
            get { return this._current; }
        }

        /** <summary>Moves one position forward to the next element.
         * This must be called once before reading a current element.
         * this will return <c>true</c> iff more elements exist in this direction.</summary>*/
        public bool MoveNext()
        {
            if (this._listOfCellsCompleted)
            {
                ++this._posInList;
                if (this._posInList >= this._listOfTerminalCells.Count)
                {
                    this._posInList = -1;
                    this._current=null;
                }
                else
                    this._current=this._listOfTerminalCells[this._posInList];
            }
            else
            {
                this._current = this.FindNextNode(this._current);
                if (this._current == null)
                {
                    this._posInList = -1;
                    this._listOfCellsCompleted=true;
                }
                else
                {
                    this._posInList = this._listOfTerminalCells.Count;
                    this._listOfTerminalCells.Add(this._current);
                }
            }
            return this._current!=null;
        }

        /** <summary>Moves the iterator back to the initial position before the first element or behind the next.</summary>*/
        public void Reset()
        {
            this._posInList=-1;
            this._current = null;
            this._listOfCellsCompleted = false;
            this._listOfTerminalCells.Clear();
        }
        #endregion

        #region Public Methods And Properties
        /** <summary>Selects in the argument according to the currently enumerated selection.
         * This iterator enumerated cells but also selections that may comprise more than
         * cell. The current cell is always the last cell of this selection. However, if
         * this searches for more than one word (searching e.g. for a quoted find string),
         * then the resulting selection will comprise also cells preceeding the current.
         * This iterator keeps track of this. So, if you want select in the searched dialog
         * acording to this iterator, use this method.
         * 
         * Please note: <c>wnd</c> must comprise the root of this document.</summary>*/
        public void SelectCurrent(HtmlWindow wnd)
        {
            if (this._currentCellSelection == null || this._currentCellSelection.Count == 0)
                wnd.SelectCell(this.Current);
            else if (this._listOfSelectionStarts != null && this._posInList >= 0)
                wnd.SelectCells(this._listOfSelectionStarts[this._posInList], this._current);
            else
                wnd.SelectCells(this._currentCellSelection.Peek(), this._current);
        }

        /** <summary>The original strings that this dialog shall find.
         * You may also set this here.</summary>*/
        public string FindString
        {
            get { return this._originalFindString; }
            set
            {
                if (this._originalFindString != value)
                {
                    this._originalFindString = value;
                    this._findFlags = this._findFlags & (~FindReplaceFlags.WHOLEWORD);
                    this._findString=LoadFindString(this._originalFindString, ref this._findFlags);
                    this.Reset();
                }
            }
        }

        /** <summary>Returns the number of yet found cells that comply.</summary>*/
        public int NumberOfFoundCells { get { return this._listOfTerminalCells.Count; } }

        /** <summary>True iff all relevant cells have been visited at least once.</summary>*/
        public bool VisitedAllRelevantCells { get { return this._listOfCellsCompleted; } }

        /** <summary>These are the flags that will be used for searching the HTML page.</summary>*/
        public FindReplaceFlags FindFlags
        {
            get { return this._findFlags; }
            set
            {
                if (this._findFlags != value)
                {
                    this._findFlags = value;
                    if (this._originalFindString != null)
                        this.FindString = this.FindString;
                }
            }
        }

        /** <summary>This is a list of all cells that will be enumerated by this enumerator.
         * \b Do \b not \b modify \b this.</summary>*/
        System.Collections.Generic.IList<HtmlCell> ListOfCells
        {
            get
            {
                if (!this._listOfCellsCompleted)
                {
                    HtmlCell current = null;
                    if (this._listOfTerminalCells == null)
                        this._listOfTerminalCells = new System.Collections.Generic.List<HtmlCell>();
                    if (this._listOfTerminalCells.Count > 0)
                        current = this._listOfTerminalCells[this._listOfTerminalCells.Count - 1];
                    current = this.FindNextNode(current);
                    while (current != null)
                    {
                        this._listOfTerminalCells.Add(current);
                        current = this.FindNextNode(current);
                    }
                    this._listOfCellsCompleted = true;
                }
                return this._listOfTerminalCells;
            }
        }

        /** <summary>The array of relevant cells.</summary>*/
        public HtmlCell[] RelevantCells
        {
            get
            {
                HtmlCell[] result=new HtmlCell[this.ListOfCells.Count];
                this.ListOfCells.CopyTo(result, 0);
                return result;
            }
        }

        /** <summary>Returns the array of words that this instance uses as a filter.
         * This might be <c>null</c>;</summary>*/
        public string[] FindStrings { get { return this._findString; } }

        /** <summary>This is <c>true</c> iff the argument is equivalent to the currently used find string.</summary>*/
        public bool EquivalentToFindString(string alternativeFindString, FindReplaceFlags alternativeFlags)
        {
            if (this._findFlags != alternativeFlags)
                return false;
            if (this._findString == null)
                return alternativeFindString == null;
            if (alternativeFindString == null)
                return false;
            if (!this.CompliesWithFindString(alternativeFindString))
                return false;
            string[] oldFindStr = this._findString;
            FindReplaceFlags findFlags = this._findFlags;
            this._findString = LoadFindString(alternativeFindString, ref findFlags);
            bool result = findFlags==this._findFlags && this.CompliesWithFindString(oldFindStr);
            this._findString = oldFindStr;
            return result;
        }

        /** <summary>Moves back to the previous position.
         * If the current position is the initial position, this will move to
         * the last terminal cell.
         * The result will be <c>true</c> iff more elements exist in this direction.</summary>*/
        public bool MoveBack()
        {
            if (this._posInList < 0)
            {
                this._posInList = this.ListOfCells.Count - 1;
                if (this._posInList >= 0)
                    this._current = this.ListOfCells[this._posInList];
                else
                    this._current = null;
                return this._current != null;
            }
            else if (this._posInList == 0)
            {
                this._posInList = -1;
                this._current = null;
                return false;
            }
            else
            {
                --this._posInList;
                this._current = this.ListOfCells[this._posInList];
                return true;
            }
        }
        #endregion

        #region Protected Overloads
        /** <summary>Use this to test text associated with a HTML cell agains the find string.
         * If this iterator does filter according to string input, this is always <c>true</c>.
         * 
         * This method will be used within IsCellRelevant() to test with resp. to a find string.
         * You may either reuse this in alternative implementations of IsCellRelevant() or
         * you may replace this to implement alternative filters regarding text.
         * </summary>
         */
        protected bool CompliesWithFindString(string cellString)
        {
            if (this._findString == null)
                return true;
            else if (cellString.Length > 0)
            {
                FindReplaceFlags findFlags = this._findFlags;
                return this.CompliesWithFindString(LoadFindString(cellString, ref findFlags));
            }
            else
                return false;
        }

        /** <summary>Use this to test text associated with a HTML cell agains the find string.
         * If this iterator does filter according to string input, this is always <c>true</c>.
         * 
         * This method will be used within IsCellRelevant() to test with resp. to a find string.
         * You may either reuse this in alternative implementations of IsCellRelevant() or
         * you may replace this to implement alternative filters regarding text.
         * </summary>
         */
        protected bool CompliesWithFindString(string[] cellWords)
        {
            if (this._findString == null)
                return true;
            else if ((this._findFlags & FindReplaceFlags.WHOLEWORD) == FindReplaceFlags.NONE)
            {
                bool hit = false;
                foreach (string findWord in this._findString)
                {
                    if (findWord.Length == 0)
                        continue;
                    foreach (string cellWord in cellWords)
                    {
                        if (cellWord.Length == 0)
                            continue;
                        if (cellWord.Contains(findWord))
                        {
                            hit = true;
                            break;
                        }
                    }
                    if (hit)
                        break;
                }
                return hit;
            }
            else if (this._findString.Length == cellWords.Length)
            {
                bool hit = true;
                IEnumerator itFindString = this._findString.GetEnumerator();
                IEnumerator itCellString = cellWords.GetEnumerator();
                while (hit && itFindString.MoveNext() && itCellString.MoveNext())
                {
                    string cellStringHere = ((string)itCellString.Current).Trim();
                    if ((this._findFlags & FindReplaceFlags.MATCHCASE) == FindReplaceFlags.NONE)
                        cellStringHere = cellStringHere.ToLower();
                    hit = itFindString.Current.Equals(cellStringHere);
                }
                return hit;
            }
            else
            {
                return false;
            }
        }

        /** <summary>Overload this to implement iterators selecting non-terminal or more specific terminal nodes.
         * This method will be asked before selecting a new Current() node on MoveNext() and
         * MoveBack(). This must be true for all Current() nodes.
         * 
         * Overload and change this to select different classes of nodes.
         * 
         * Currently, this will select terminal nodes which are not formatting nodes.
         * If this iterations defines a find string then this method will also take
         * </summary>
         */
        protected virtual bool IsCellRelevant(System.Collections.Generic.Queue<HtmlCell> preceedingCells)
        {
            string[] cellStrings = new string[preceedingCells.Count];
            int index = 0;
            foreach (HtmlCell preceedingCell in preceedingCells)
            {
                cellStrings[index] = preceedingCell.Text.Trim();
                ++index;
            }
            return this.CompliesWithFindString(cellStrings);
        }

        /** <summary>Overload this to implement iterators selecting non-terminal or more specific terminal nodes.
         * This method will be asked before selecting a new Current() node on MoveNext() and
         * MoveBack(). This must be true for all Current() nodes.
         * 
         * Overload and change this to select different classes of nodes.
         * 
         * Currently, this will select terminal nodes which are not formatting nodes.
         * If this iterations defines a find string then this method will also take
         * </summary>
         */
        protected virtual bool IsCellRelevant(HtmlCell cell)
        {
            return this.CompliesWithFindString(cell.Text);
        }
        #endregion

        #region Private Helpers
        /** <summary>This method will return the next relevant cell after <c>current</c>.
         * You may pass <c>null</c> as an argument. In that case, this will start with
         * <c>root</c>.
         * This will return <c>null</c> if this cannot find a next relevant cell.
         * </summary>
         */
        HtmlCell FindNextNode(HtmlCell current)
        {
            if (current == null)
            {
                current = this._root;
                this._currentCellSelection = null;
                this._listOfSelectionStarts = null;
                //Trace.WriteLine(string.Format("Set to root cell {0}x{1}:\"{2}\".", current.PosX, current.PosY, current.Text));
                
                if (this.IsCellRelevant(current))
                    return current;
            }

            int depth = 0;
            DateTime nextUpdateTime = DateTime.Now.AddSeconds(0.5);

            while (current != null)
            {
                //Trace.WriteLine(string.Format("{5}: Reading cell {3}/{4}:{0}x{1}:\"{2}\".", current.PosX, current.PosY, current.Text, current.GetTypeName(), current.GetType().Name, depth));
                HtmlCell firstChild = current.FirstChild;
                if (firstChild==null)
                {
                    //Trace.WriteLine("Is terminal.");
                    while (current.Next == null)
                    {
                        //Trace.WriteLine("Switch to parent.");
                        --depth;
                        current = current.Parent;
                        if (current == null)
                            break;
                    }
                    if (current != null)
                    {
                        //Trace.WriteLine("Switch to next.");
                        current = current.Next;
                    }
                }
                else
                {
                    current = firstChild;
                    ++depth;
                    //Trace.WriteLine("Switch to first child.");
                }

                if (current == null)
                    break;

                //Trace.WriteLine(string.Format("{6}: Now reading cell {3}/{4}:{0}x{1}:\"{2}\" {5}.", current.PosX, current.PosY, current.Text, current.GetTypeName(), current.GetType().Name, current.IsTerminalCell?"is terminal":"non-terminal", depth));
                if ((this._findFlags & FindReplaceFlags.WHOLEWORD) == FindReplaceFlags.NONE)
                {
                    if (this.IsCellRelevant(current))
                        break;
                }
                else
                {
                    if (this._currentCellSelection == null)
                        this._currentCellSelection = new System.Collections.Generic.Queue<HtmlCell>();
                    if (current.Text.Trim().Length > 0)
                    {
                        this._currentCellSelection.Enqueue(current);
                        while (this._currentCellSelection.Count > this._findString.Length)
                            this._currentCellSelection.Dequeue();
                        if (this.IsCellRelevant(this._currentCellSelection))
                            break;
                    }
                }

                DateTime now = DateTime.Now;
                if (now > nextUpdateTime)
                {
                    nextUpdateTime = now.AddSeconds(0.5);
                    if (this._callbackProgressReport != null
                        && !this._callbackProgressReport(-1, -1))
                    {
                        //Trace.WriteLine("Break due to callback instruction.");
                        return null;
                    }
                }
            }
            if (this._listOfSelectionStarts == null && this._currentCellSelection!=null)
            {
                this._listOfSelectionStarts = new System.Collections.Generic.List<HtmlCell>();
            }
            if (this._currentCellSelection!=null && this._currentCellSelection.Count > 0)
                this._listOfSelectionStarts.Add(this._currentCellSelection.Peek());
            return current;
        }
        #endregion
    }

    /** <summary>This is a dialog supporting finding strings in HTML cells.
     * You will normally not create this on your own but use wx.HtmlWindow.OpenFindDialog()
     * to open this.</summary>*/
    public class HtmlFindDialog : FindReplaceDialog
    {
        #region Public Types
        public enum States
        {
            Idle,
            Searching,
            Closed
        }
        #endregion

        #region State
        States _state = States.Idle;
        HtmlWindow _parent;
        HtmlTerminalCellIterator _cellEnumerator=null;
        #endregion

        #region CTor
        public HtmlFindDialog(HtmlWindow parent, FindReplaceData data, string title)
            : base(parent, data, title)
        {
            this._parent = parent;
            EVT_FIND(new EventListener(OnFind));
            EVT_FIND_NEXT(new EventListener(OnFindNext));
            EVT_FIND_CLOSE(new EventListener(OnCloseFind));
        }

        HtmlTerminalCellIterator CellEnumerator
        {
            get
            {
                if (this._cellEnumerator == null)
                {
                    FindReplaceData data = this.Data;
                    HtmlCell current = null;
                    if (this._parent.SelectionInfo != null)
                        current = this._parent.SelectionInfo.ToCell;
                    this._cellEnumerator = new HtmlTerminalCellIterator(this._parent.InternalRepresentation, current, data.FindString, data.Flags);
                    this._cellEnumerator.CallbackProgressReport = new HtmlTerminalCellIterator.DelegateProgressReport(this.CallbackProgress);
                }
                return this._cellEnumerator;
            }
        }

        bool CallbackProgress(int current, int end)
        {
            wx.App.TheApp.SafeYield(this);
            return this._state==States.Searching;
        }
        #endregion

        #region Event Handlers
        void OnFind(object sender, Event evt)
        {
            this.DoFind();
        }
        /** <summary>Act as if [ENTER] has been pressed in the search string control.</summary>*/
        public void DoFind()
        {
            this.CellEnumerator.Reset();
            this.DoFindNext();
        }

        void OnFindNext(object sender, Event evt)
        {
            this.DoFindNext();
        }
        /** <summary>Act as if the "find next" button has been pressed.</summary>*/
        public void DoFindNext()
        {
            this.CellEnumerator.FindString = this.Data.FindString;
            if (this.CellEnumerator.FindFlags != this.Data.Flags)
            {
                this.CellEnumerator.FindFlags = this.Data.Flags;
                this.CellEnumerator.Reset();
            }
            this._state = States.Searching;
            bool found = false;
            if ((this.Data.Flags & FindReplaceFlags.DOWN) == FindReplaceFlags.NONE)
                found=this.CellEnumerator.MoveBack();
            else
                found=this.CellEnumerator.MoveNext();
            if (found)
            {
                this.CellEnumerator.SelectCurrent(this._parent);
                this._parent.ScrollToCell(this.CellEnumerator.Current);
            }
            else
            {
                this.Show(false);
                Utils.Bell();
                MessageDialog.ShowModal(_("Searched the page up to the bottom."), _("Information"), WindowStyles.ICON_INFORMATION | WindowStyles.DIALOG_OK);
            }
            this._state = States.Idle;
        }

        void OnCloseFind(object sender, Event evt)
        {
            evt.Skip(false);
            this.DoCloseFind();
        }
        public void DoCloseFind()
        {
            this._state = States.Closed;
            this.Show(false);
        }
        #endregion

        #region Public Methods
        public void SelectNextString(string findString)
        {
            FindReplaceData data = this.Data;
            data.FindString = findString;
            this.Data = data;
            this.DoFindNext();
        }
        #endregion

        #region Public Properties
        /** <summary>True if this dialog is currently searching. 
         * If this is <c>true</c>, all further actions will be aborted.</summary>*/
        public States State { get { return this._state; } }

        new public HtmlWindow Parent
        {
            get { return this._parent; }
        }

        public override FindReplaceData Data
        {
            get
            {
                return base.Data;
            }
            set
            {
                base.Data = value;
                this._cellEnumerator = null;
            }
        }
        #endregion
    }

    public class HtmlWindowWithSearch : Panel
    {
        #region State
        HtmlWindow _html;
        BitmapButton _back;
        BitmapButton _forward;
        BitmapButton _hide;
        TextCtrl _searchtext;
        HtmlTerminalCellIterator _cellEnumerator = null;
        int _htmlVersion = 0;

        /** <summary>Background of the search text will switch to this colour if the specified text cannot be found.</summary>*/
        public Colour TextBgOnError;

        /** <summary>Background of the search text will switch to this colour if all occurances of the search text have been found but the search can be restarted.</summary>*/
        public Colour TextBgOnCompletedSearch;
        #endregion

        #region CTor
        /** <summary>This is for two step construction.</summary>*/
        public HtmlWindowWithSearch()
        {
        }
        public HtmlWindowWithSearch(Window parent)
            : this(parent, Window.UniqueID, wxDefaultPosition, wxDefaultSize, wx.WindowStyles.HW_SCROLLBAR_AUTO, "HtmlWindow") { }

        public HtmlWindowWithSearch(Window parent, Point pos)
            : this(parent, Window.UniqueID, pos, wxDefaultSize, wx.WindowStyles.HW_SCROLLBAR_AUTO, "HtmlWindow") { }

        public HtmlWindowWithSearch(Window parent, Point pos, Size size)
            : this(parent, Window.UniqueID, pos, size, wx.WindowStyles.HW_SCROLLBAR_AUTO, "HtmlWindow") { }

        public HtmlWindowWithSearch(Window parent, Point pos, Size size, wx.WindowStyles style)
            : this(parent, Window.UniqueID, pos, size, style, "HtmlWindowWithSearch") { }

        public HtmlWindowWithSearch(Window parent, Point pos, Size size, wx.WindowStyles style, string name)
            : this(parent, Window.UniqueID, pos, size, style, name) { }

        public HtmlWindowWithSearch(Window parent, int id, Point pos, Size size, wx.WindowStyles style, string name)
            : base(parent, id, pos, size, style | WindowStyles.TAB_TRAVERSAL | WindowStyles.BORDER_NONE, name)
        {
            this.Init();
        }

        void Init()
        {
            BoxSizer sizerTop = new BoxSizer(Orientation.wxVERTICAL);
            AutoLayout = true;

            int idSearchtext = Window.UniqueID;
            int idBack = Window.UniqueID;
            int idForward = Window.UniqueID;
            int idHide = Window.UniqueID;
            this._searchtext = new TextCtrl(this, idSearchtext, "", wxDefaultPosition, wxDefaultSize);
            this._back = new BitmapButton(this, idBack, ArtProvider.GetBitmap(ArtID.wxART_GO_BACK, ArtClient.wxART_BUTTON, new Size(16, 16)), wxDefaultPosition, wxDefaultSize, wx.WindowStyles.BU_AUTODRAW);
            this._forward = new BitmapButton(this, idForward, ArtProvider.GetBitmap(ArtID.wxART_GO_FORWARD, ArtClient.wxART_BUTTON, new Size(16, 16)), wxDefaultPosition, wxDefaultSize, wx.WindowStyles.BU_AUTODRAW);
            this._hide = new BitmapButton(this, idHide, ArtProvider.GetBitmap(ArtID.wxART_ERROR, ArtClient.wxART_BUTTON, new Size(16, 16)), wxDefaultPosition, wxDefaultSize, wx.WindowStyles.BU_AUTODRAW);

            this._searchtext.Show(false);
            this._back.Show(false);
            this._forward.Show(false);
            this._hide.Show(false);

            this.TextBgOnError = Colour.wxRED;
            this.TextBgOnCompletedSearch = Colour.TheColourDatabase.Find("YELLOW");

            BoxSizer searchSizer = new BoxSizer(Orientation.wxHORIZONTAL);
            searchSizer.Add(this._searchtext, 1, SizerFlag.wxEXPAND | SizerFlag.wxALL, 0);
            searchSizer.Add(this._back, 0, SizerFlag.wxSHAPED | SizerFlag.wxALL, 0);
            searchSizer.Add(this._forward, 0, SizerFlag.wxSHAPED | SizerFlag.wxALL, 0);
            searchSizer.Add(this._hide, 0, SizerFlag.wxSHAPED | SizerFlag.wxALL, 0);

            sizerTop.Add(searchSizer, 0, SizerFlag.wxEXPAND | SizerFlag.wxALL);
            this._html = this.CreateHtmlWindow();
            sizerTop.Add(this._html, 1, SizerFlag.wxEXPAND | SizerFlag.wxALL);

            SetSizer(sizerTop);
            sizerTop.SetSizeHints(this);
            sizerTop.Fit(this);

            EVT_BUTTON(idBack, new EventListener(this.DoSearchBack));
            EVT_BUTTON(idForward, new EventListener(this.DoSearchForward));
            EVT_BUTTON(idHide, new EventListener(this.DoHideSearchPanel));
            EVT_TEXT(idSearchtext, new EventListener(this.DoSearchNew));
        }

        public new void Create(Window parent, int id, Point pos, Size size, wx.WindowStyles style, string name)
        {
            base.Create(parent, id, pos, size, style, name);
            this.Init();
        }
        #endregion

        #region Protected Helpers
        /** <summary>You may overload this if you want to have a specialization of this class dealing with specific HTML windows.
         * The result mus have <c>this</c> as parent.</summary>*/
        protected virtual HtmlWindow CreateHtmlWindow()
        {
            return new HtmlWindow(this);
        }
        #endregion

        #region Event Handlers
        bool CallbackProgress(int current, int end)
        {
            wx.App.GetApp().Yield();
            return this.IsSearchPanelShown;
        }


        wx.Colour _standardBG = null;
        /** <summary>This is the bell on error or completed search.</summary>*/
        void Bell()
        {
            if (this._standardBG==null)
                this._standardBG = this._searchtext.BackgroundColour;

            if (this._cellEnumerator.NumberOfFoundCells == 0 && this.TextBgOnError != null)
            {
                this._searchtext.BackgroundColour = this.TextBgOnError;
                this.Refresh();
            }
            else if (this.TextBgOnCompletedSearch != null)
            {
                this._searchtext.BackgroundColour = this.TextBgOnCompletedSearch;
                this.Refresh();
                Utils.Bell();
            }
            else
                this._searchtext.BackgroundColour = this._standardBG;
        }

        void DoSearchBack(object sender, wx.Event evt)
        {
            if (this.GetCellEnumerator().FindStrings != null)
            {
                bool found = this.GetCellEnumerator().MoveBack();
                if (found)
                {
                    this.GetCellEnumerator().SelectCurrent(this._html);
                    this._html.ScrollToCell(this.GetCellEnumerator().Current);
                    if (this._standardBG!=null)
                    {
                        this._searchtext.BackgroundColour = this._standardBG;
                        this._standardBG = null;
                        this.Refresh();
                    }
                }
                else
                {
                    if (this._cellEnumerator.NumberOfFoundCells > 0)
                        this.GetCellEnumerator().MoveNext();
                    this.Bell();
                }
            }
        }

        void DoSearchForward(object sender, wx.Event evt)
        {
            if (this.GetCellEnumerator().FindStrings != null)
            {
                bool found = this.GetCellEnumerator().MoveNext();
                if (found)
                {
                    this.GetCellEnumerator().SelectCurrent(this._html);
                    this._html.ScrollToCell(this.GetCellEnumerator().Current);
                    if (this._standardBG != null)
                    {
                        this._searchtext.BackgroundColour = this._standardBG;
                        this._standardBG = null;
                        this._cellEnumerator = null;
                        this.Refresh();
                    }
                }
                else
                {
                    if (this._cellEnumerator.NumberOfFoundCells > 0)
                        this.GetCellEnumerator().MoveBack();
                    this.Bell();
                }
            }
        }

        void DoSearchNew(object sender, wx.Event evt)
        {
            if (this._searchtext.Value.Trim().Length > 0)
            {
                this.GetCellEnumerator().FindString = this._searchtext.Value;
                this.DoSearchForward(sender, evt);
            }
            else if (this._standardBG != null)
            {
                this._searchtext.BackgroundColour = this._standardBG;
                this._standardBG = null;
                this._cellEnumerator = null;
                this.Refresh();
            }
        }

        void DoHideSearchPanel(object sender, wx.Event evt)
        {
            this.ShowSearchPanel(false);
        }
        #endregion

        #region Public Properties
        /** <summary>This is the encapsulated HTML window.</summary>*/
        public HtmlWindow Html
        {
            get { return this._html; }
        }

        internal HtmlTerminalCellIterator GetCellEnumerator()
        {
            if (this._cellEnumerator == null || this._html.Version > this._htmlVersion)
            {
                this._cellEnumerator = new HtmlTerminalCellIterator(this._html.InternalRepresentation, null, null, FindReplaceFlags.NONE);
                this._cellEnumerator.CallbackProgressReport = new HtmlTerminalCellIterator.DelegateProgressReport(this.CallbackProgress);
                this._htmlVersion = this._html.Version;
            }
            return _cellEnumerator;
        }

        /** <summary>True iff the integrated search panel is shown.</summary>*/
        public bool IsSearchPanelShown
        {
            get
            {
                return this._searchtext.IsShown;
            }
        }
        #endregion

        #region Public Methods
        /** <summary>This will show or hide the search panel.
         * Run with <c>true</c> to show and with <c>false</c> to hide the search panel.
         * 
         * This will initialize the search text with the current selection of
         * the search panel becomes visible because of this method call.</summary>*/
        public void ShowSearchPanel(bool showOrHide)
        {
            this.ShowSearchPanel(showOrHide, !this.IsSearchPanelShown && showOrHide);
            if (showOrHide)
                this._searchtext.SetFocus();
        }
        /** <summary>This will show or hide the search panel.
         * Run with <c>true</c> to show and with <c>false</c> to hide the search panel.
         * \param pickCurrentSelection will cause this method with <c>true</c> to initialize
         *        the search text with the current selection.</summary>*/
        public void ShowSearchPanel(bool showOrHide, bool pickCurrentSelection)
        {
            if (pickCurrentSelection)
            {
                this._searchtext.Value = this._html.SelectionText.Trim();
            }
            this._searchtext.Show(showOrHide);
            this._back.Show(showOrHide);
            this._forward.Show(showOrHide);
            this._hide.Show(showOrHide);
            this.Layout();
            this.Refresh();
        }

        /** <summary>Changes visibility of the internal search panel.</summary>*/
        public void ToggleSearchPanel()
        {
            this.ShowSearchPanel(!this.IsSearchPanelShown);
        }

        public void FindNext(string searchString)
        {
            this.ShowSearchPanel(true, false);
            this._searchtext.Value = searchString;
        }
        #endregion
    }

    //-----------------------------------------------------------------------------

    /** <summary>A wx.HtmlCell containing font information.</summary>*/
    public class HtmlFontCell : HtmlCell
    {
        [DllImport("wx-c")] static extern IntPtr wxHtmlFontCell_ctor(IntPtr font);
        [DllImport("wx-c")] static extern void   wxHtmlFontCell_Draw(IntPtr self, IntPtr dc, int x, int y, int view_y1, int view_y2, IntPtr info);
        [DllImport("wx-c")] static extern void   wxHtmlFontCell_DrawInvisible(IntPtr self, IntPtr dc, int x, int y, IntPtr info);
        /** <summary>Returns Ptr to the  wxWidgets RTTI.</summary>*/
        [DllImport("wx-c")]
        public static extern IntPtr HtmlFontCell_GetWxClassInfo();

        //-----------------------------------------------------------------------------

        public HtmlFontCell(IntPtr wxObject)
            : base(wxObject) {}

        static IntPtr LockedCTor(IntPtr font)
        {
            lock (DllSync)
            {
                return wxHtmlFontCell_ctor(font);
            }
        }

        public HtmlFontCell(Font font)
            : this(LockedCTor(Object.SafePtr(font))) { }

        //-----------------------------------------------------------------------------

        public override void Draw(DC dc, int x, int y, int view_y1, int view_y2, HtmlRenderingInfo info)
        {
            wxHtmlFontCell_Draw(wxObject, Object.SafePtr(dc), x, y, view_y1, view_y2, Object.SafePtr(info));
        }
		
        //-----------------------------------------------------------------------------
		
        public override void DrawInvisible(DC dc, int x, int y, HtmlRenderingInfo info)
        {
            wxHtmlFontCell_DrawInvisible(wxObject, Object.SafePtr(dc), x, y, Object.SafePtr(info));
        }
    }

    //-----------------------------------------------------------------------------

    /** <summary>A wx.HtmlCell containing colour information.</summary>*/
    public class HtmlColourCell : HtmlCell
    {
        [DllImport("wx-c")] static extern IntPtr wxHtmlColourCell_ctor(IntPtr clr, int flags);
        [DllImport("wx-c")] static extern void   wxHtmlColourCell_Draw(IntPtr self, IntPtr dc, int x, int y, int view_y1, int view_y2, IntPtr info);
        [DllImport("wx-c")] static extern void   wxHtmlColourCell_DrawInvisible(IntPtr self, IntPtr dc, int x, int y, IntPtr info);
        /** <summary>Returns Ptr to the  wxWidgets RTTI.</summary>*/
        [DllImport("wx-c")]
        public static extern IntPtr HtmlColourCell_GetWxClassInfo();

        //-----------------------------------------------------------------------------

        public HtmlColourCell(IntPtr wxObject)
            : base(wxObject)
        {
        }

      
        static IntPtr LockedCTor(Colour clr, int flags)
        {
            lock (DllSync)
            {
                return wxHtmlColourCell_ctor(Object.SafePtr(clr), flags);
            }
        }

        public  HtmlColourCell(Colour clr, int flags)
            : this(LockedCTor(clr, flags)) { }

        //-----------------------------------------------------------------------------

        public override void Draw(DC dc, int x, int y, int view_y1, int view_y2, HtmlRenderingInfo info)
        {
            wxHtmlColourCell_Draw(wxObject, Object.SafePtr(dc), x, y, view_y1, view_y2, Object.SafePtr(info));
        }

        //-----------------------------------------------------------------------------

        public override void DrawInvisible(DC dc, int x, int y, HtmlRenderingInfo info)
        {
            wxHtmlColourCell_DrawInvisible(wxObject, Object.SafePtr(dc), x, y, Object.SafePtr(info));
        }
    }

    //-----------------------------------------------------------------------------

    public class HtmlLinkInfo : Object
    {
        [DllImport("wx-c")] static extern IntPtr wxHtmlLinkInfo_ctor();
        [DllImport("wx-c")] static extern IntPtr wxHtmlLinkInfo_ctor(string href, string target);
        //[DllImport("wx-c")] static extern IntPtr wxHtmlLinkInfo_ctor(IntPtr l);
        [DllImport("wx-c")] static extern void   wxHtmlLinkInfo_SetEvent(IntPtr self, IntPtr e);
        [DllImport("wx-c")] static extern void   wxHtmlLinkInfo_SetHtmlCell(IntPtr self, IntPtr e);
        [DllImport("wx-c")] static extern IntPtr wxHtmlLinkInfo_GetHref(IntPtr self);
        [DllImport("wx-c")] static extern IntPtr wxHtmlLinkInfo_GetTarget(IntPtr self);
        [DllImport("wx-c")] static extern IntPtr wxHtmlLinkInfo_GetEvent(IntPtr self);
        [DllImport("wx-c")] static extern IntPtr wxHtmlLinkInfo_GetHtmlCell(IntPtr self);
		
        //-----------------------------------------------------------------------------
		
        public HtmlLinkInfo(IntPtr wxObject)
            : base(wxObject) {}
		
        public  HtmlLinkInfo()
            : base(wxHtmlLinkInfo_ctor()) { }
		
        //-----------------------------------------------------------------------------
		
        public  HtmlLinkInfo(string href, string target)
            : base(wxHtmlLinkInfo_ctor(href, target)) { }
		
        //-----------------------------------------------------------------------------
		
        /*public  HtmlLinkInfo(HtmlLinkInfo l)
            : base(wxHtmlLinkInfo_ctor(Object.SafePtr(l))) { }*/
		
		//-----------------------------------------------------------------------------
		
		public MouseEvent Event
		{
			set { wxHtmlLinkInfo_SetEvent(wxObject, Object.SafePtr(value)); }
			get { return (MouseEvent)FindObject(wxHtmlLinkInfo_GetEvent(wxObject), typeof(MouseEvent)); }
		}
		
		//-----------------------------------------------------------------------------
		
		public string Href
		{
			get { return new wxString(wxHtmlLinkInfo_GetHref(wxObject), true); }
		}
		
		//-----------------------------------------------------------------------------
		
		public string Target
		{
			get { return new wxString(wxHtmlLinkInfo_GetTarget(wxObject), true); }
		}
		
		//-----------------------------------------------------------------------------
		
		public HtmlCell HtmlCell
		{
			get { return (HtmlCell)FindObject(wxHtmlLinkInfo_GetHtmlCell(wxObject), typeof(HtmlCell)); }
			set { wxHtmlLinkInfo_SetHtmlCell(wxObject, Object.SafePtr(value)); }
		}
	}

	//-----------------------------------------------------------------------------

    /** <summary>The wrapper for the <c>wxHtmlWidgetCell</c> of  wxWidgets.
     * Please note, that the  wx.NET system uses a specialization of <c>wxHtmlWidgetCell</c>
     * that contains some fixes.
     * </summary>*/
    public class HtmlWidgetCell : HtmlCell
    {
        [DllImport("wx-c")] static extern IntPtr wxHtmlWidgetCell_ctor(IntPtr wnd, int w);
        [DllImport("wx-c")] static extern void wxHtmlWidgetCell_RegisterDispose(IntPtr self, Virtual_Dispose onDispose);
        [DllImport("wx-c")] static extern void wxHtmlWidgetCell_Draw(IntPtr self, IntPtr dc, int x, int y, int view_y1, int view_y2, IntPtr info);
        [DllImport("wx-c")] static extern void   wxHtmlWidgetCell_DrawInvisible(IntPtr self, IntPtr dc, int x, int y, IntPtr info);
        [DllImport("wx-c")] static extern void   wxHtmlWidgetCell_Layout(IntPtr self, int w);
        [DllImport("wx-c")] static extern IntPtr wxHtmlWidgetCell_GetWindow(IntPtr self);
        //-----------------------------------------------------------------------------

		public HtmlWidgetCell(IntPtr wxObject)
			: base(wxObject) {}

        public HtmlWidgetCell(Window wnd)
            : this(wnd, 0)
        {
        }

        public HtmlWidgetCell(Window wnd, int w)
            : this(wxHtmlWidgetCell_ctor(Object.SafePtr(wnd), w))
        {
            this.virtual_Dispose=new Virtual_Dispose(this.VirtualDispose);
            wxHtmlWidgetCell_RegisterDispose(this.wxObject, this.virtual_Dispose);
            if (wnd.Parent is HtmlWindow)
                ((HtmlWindow)wnd.Parent).RegisterWidgetCell(this);
        }

        //-----------------------------------------------------------------------------

        internal Window Window
        {
            get { return (Window)Object.FindObject(wxHtmlWidgetCell_GetWindow(this.wxObject), typeof(Window)); }
        }

        //-----------------------------------------------------------------------------

        public override void Draw(DC dc, int x, int y, int view_y1, int view_y2, HtmlRenderingInfo info)
        {
            wxHtmlWidgetCell_Draw(wxObject, Object.SafePtr(dc), x, y, view_y1, view_y2, Object.SafePtr(info));
        }

        //-----------------------------------------------------------------------------

        public override void DrawInvisible(DC dc, int x, int y, HtmlRenderingInfo info)
        {
            wxHtmlWidgetCell_DrawInvisible(wxObject, Object.SafePtr(dc), x, y, Object.SafePtr(info));
        }

        //-----------------------------------------------------------------------------

        public override void Layout(int w)
        {
            wxHtmlWidgetCell_Layout(wxObject, w);
        }
    }

	//-----------------------------------------------------------------------------

    /** <summary>Internal representation of HTML in a wx.HtmlWindow.
     * HTML is represented as a tree of nodes, the so-called cells.
     * The framework uses several classes of nodes.
     * 
     * Please note, that the current implementation might not call all virtual methods.</summary>*/
    public class HtmlCell : Object
    {
        #region C API
        [DllImport("wx-c")] static extern IntPtr wxHtmlCell_ctor();
        [DllImport("wx-c")] static extern void   wxHtmlCell_SetParent(IntPtr self, IntPtr p);
        [DllImport("wx-c")] static extern IntPtr wxHtmlCell_GetParent(IntPtr self);
        [DllImport("wx-c")] static extern int    wxHtmlCell_GetPosX(IntPtr self);
        [DllImport("wx-c")] static extern int    wxHtmlCell_GetPosY(IntPtr self);
        [DllImport("wx-c")] static extern int    wxHtmlCell_GetWidth(IntPtr self);
        [DllImport("wx-c")] static extern int    wxHtmlCell_GetHeight(IntPtr self);
        [DllImport("wx-c")] static extern int    wxHtmlCell_GetDescent(IntPtr self);
        [DllImport("wx-c")] static extern IntPtr wxHtmlCell_GetId(IntPtr self);
        [DllImport("wx-c")] static extern void   wxHtmlCell_SetId(IntPtr self, IntPtr id);
        [DllImport("wx-c")] static extern IntPtr wxHtmlCell_GetNext(IntPtr self);
        [DllImport("wx-c")] static extern void   wxHtmlCell_SetPos(IntPtr self, int x, int y);
        [DllImport("wx-c")] static extern void   wxHtmlCell_SetLink(IntPtr self, IntPtr link);
        [DllImport("wx-c")] static extern IntPtr wxHtmlCell_GetLink(IntPtr self);
        [DllImport("wx-c")] static extern void   wxHtmlCell_SetNext(IntPtr self, IntPtr cell);
        [DllImport("wx-c")] static extern void   wxHtmlCell_Layout(IntPtr self, int w);
        [DllImport("wx-c")] static extern void   wxHtmlCell_Draw(IntPtr self, IntPtr dc, int x, int y, int view_y1, int view_y2, IntPtr info);
        [DllImport("wx-c")] static extern void   wxHtmlCell_DrawInvisible(IntPtr self, IntPtr dc, int x, int y, IntPtr info);
        [DllImport("wx-c")] static extern IntPtr wxHtmlCell_Find(IntPtr self, int condition, IntPtr param);
        [DllImport("wx-c")] static extern void   wxHtmlCell_OnMouseClick(IntPtr self, IntPtr parent, int x, int y, IntPtr evt);
        [DllImport("wx-c")][return:MarshalAs(UnmanagedType.U1)] static extern bool wxHtmlCell_AdjustPagebreak(IntPtr self, ref int pagebreak);
        [DllImport("wx-c")] static extern void   wxHtmlCell_SetCanLiveOnPagebreak(IntPtr self, bool can);
        [DllImport("wx-c")] static extern void   wxHtmlCell_GetHorizontalConstraints(IntPtr self, ref int left, ref int right);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxHtmlCell_IsTerminalCell(IntPtr self);
        [DllImport("wx-c")][return:MarshalAs(UnmanagedType.U1)]
        static extern bool wxHtmlCell_IsFormattingCell(IntPtr self);
        [DllImport("wx-c")] static extern IntPtr wxHtmlCell_FindCellByPos(IntPtr self, int x, int y, int mode);
        [DllImport("wx-c")]
        static extern IntPtr wxHtmlCell_GetFirstChild(IntPtr self);
        [DllImport("wx-c")]
        static extern IntPtr wxHtmlCell_GetFirstTerminal(IntPtr self);
        [DllImport("wx-c")]
        static extern IntPtr wxHtmlCell_GetLastTerminal(IntPtr self);
        [DllImport("wx-c")]
        static extern IntPtr wxHtmlCell_GetRootCell(IntPtr self);
        [DllImport("wx-c")][return:MarshalAs(UnmanagedType.U1)]
        static extern bool wxHtmlCell_IsBefore(IntPtr self, IntPtr arg);
        [DllImport("wx-c")]
        static extern IntPtr wxHtmlWindow_ConvertToText(IntPtr self);
        [DllImport("wx-c")]
        static extern void wxHtmlCell_GetAbsPos(IntPtr self, IntPtr rootCell, ref int x, ref int y);

        /** <summary>Returns Ptr to the  wxWidgets RTTI.</summary>*/
        [DllImport("wx-c")]
        public static extern IntPtr HtmlCell_GetWxClassInfo();
        #endregion

        #region Internal State
        /** <summary>This will hold all wrappers of siblings if this is a root node.
         * DisposeAllNonOwners() depends on this.</summary>*/
        internal ArrayList _siblings = new ArrayList();

        internal void DisposeAllNonOwners()
        {
            if (!this.memOwn)
                this.VirtualDispose();
            foreach (HtmlCell cell in this._siblings)
            {
                if (!cell.memOwn)
                    cell.VirtualDispose();
            }
            this._siblings.Clear();
        }
        #endregion

        #region CTor
        public HtmlCell(IntPtr wxObject) 
            : base(wxObject)
        {
            if (this.RootCell != null)
                this.RootCell._siblings.Add(this);
        }


        static IntPtr SafeCTor()
        {
            lock (DllSync)
            {
                return wxHtmlCell_ctor();
            }
        }
        public HtmlCell()
            : base(SafeCTor())
        {
        }
        #endregion

        #region Properties
        public HtmlContainerCell Parent
        {
            set { wxHtmlCell_SetParent(wxObject, Object.SafePtr(value)); }
            get { return (HtmlContainerCell)FindObject(wxHtmlCell_GetParent(wxObject), typeof(HtmlContainerCell)); }
        }

        /** <summary>This is the position of the cell within its parent.</summary>*/
        public int PosX
        {
            get { return wxHtmlCell_GetPosX(wxObject); }
        }

        /** <summary>This is the position of the cell within its parent.</summary>*/
        public int PosY
        {
            get { return wxHtmlCell_GetPosY(wxObject); }
        }

        /** <summary>This is the position of the cell within its parent.</summary>*/
        public Point Pos
        {
            get { return new Point(PosX, PosY); }
            set
            {
                SetPos(value.X, value.Y);
            }
        }

        /** <summary>This returns the absolute position of the cell relative to the root.</summary>*/
        public Point AbsPos
        {
            get
            {
                int x = 0;
                int y = 0;
                wxHtmlCell_GetAbsPos(this.wxObject, IntPtr.Zero, ref x, ref y);
                return new Point(x, y);
            }
        }

        /** <summary>This returns the position of this cell relative to the argument.
         * The argument shall be a parent or a parent of the parent etc.</summary>*/
        public Point RelativePos(HtmlCell root)
        {
            int x = 0;
            int y = 0;
            wxHtmlCell_GetAbsPos(this.wxObject, Object.SafePtr(root), ref x, ref y);
            return new Point(x, y);
        }

        public int Width
        {
            get { return wxHtmlCell_GetWidth(wxObject); }
        }

        public int Height
        {
            get { return wxHtmlCell_GetHeight(wxObject); }
        }

        public int Descent
        {
            get { return wxHtmlCell_GetDescent(wxObject); }
        }

        public virtual string Id
        {
            get { return new wxString(wxHtmlCell_GetId(wxObject), true); }
            set
            {
                using (wxString wxvalue = new wxString(value))
                {
                    wxHtmlCell_SetId(wxObject, wxvalue.wxObject);
                }
            }
        }

        public HtmlCell Next
        {
            get { return Object.FindOrCreateObjectUsingClassInfo(wxHtmlCell_GetNext(wxObject)) as HtmlCell; }
            set { wxHtmlCell_SetNext(wxObject, Object.SafePtr(value)); }
        }

        /** <summary>First cell that is part of this node.
         * Follow the HtmlCell.Next() cells to enumerate all direct siblings of this node.</summary>*/
        public HtmlCell FirstChild
        {
            get{ return Object.FindOrCreateObjectUsingClassInfo(wxHtmlCell_GetFirstChild(wxObject)) as HtmlCell; }
        }

        /** <summary>First terminal cell below.</summary>*/
        public HtmlCell FirstTerminal
        {
            get { return Object.FindOrCreateObjectUsingClassInfo(wxHtmlCell_GetFirstTerminal(wxObject)) as HtmlCell; }
        }

        /** <summary>Last terminal cell below.</summary>*/
        public HtmlCell LastTerminal
        {
            get { return Object.FindOrCreateObjectUsingClassInfo(wxHtmlCell_GetLastTerminal(wxObject)) as HtmlCell; }
        }

        public HtmlCell RootCell
        {
            get { return Object.FindOrCreateObjectUsingClassInfo(wxHtmlCell_GetRootCell(wxObject)) as HtmlCell; }
        }

        /** <summary>The contained text.</summary>*/
        public string Text
        {
            get
            {
                wxString text = new wxString(wxHtmlWindow_ConvertToText(this.wxObject));
                return text;
            }
        }

        /** <summary>This will load all texts from this node or the children up to the maximum length.
         * Words will be separated by a single blank.</summary>*/
        public string GetTextUpToLength(int maxLength)
        {
            HtmlCell current=this.FirstChild;
            if (current == null)
                return this.Text;
            else
            {
                string result = "";
                int depth = 1;
                while (current != null && current != this && depth > 0)
                {
                    HtmlCell firstChild = current.FirstChild;
                    if (firstChild == null)
                    {
                        result += current.Text;
                        if (result.Length >= maxLength)
                            break;

                        while (current.Next == null)
                        {
                            current = current.Parent;
                            --depth;
                            if (current == null)
                                break;
                        }
                        if (current != null)
                            current = current.Next;
                    }
                    else
                    {
                        current = firstChild;
                        ++depth;
                    }
                }
                return result;
            }
        }

        /** <summary>Get or set the information on contained hyper link.
         * Note, that this infor may be <c>null</c>.
         * </summary>
         */
        public HtmlLinkInfo Link
        {
            get
            {
                IntPtr cptr = wxHtmlCell_GetLink(this.wxObject);
                if (cptr == IntPtr.Zero)
                    return null;
                return new HtmlLinkInfo(cptr);
            }
            set { wxHtmlCell_SetLink(wxObject, Object.SafePtr(value)); }
        }

        public bool IsTerminalCell
        {
            get { return wxHtmlCell_IsTerminalCell(wxObject); }
        }

        public bool IsFormattingCell
        {
            get { return wxHtmlCell_IsFormattingCell(this.wxObject); }
        }

        /** <summary>Returns true if the cell appears before 'cell' in natural order of cells (as they are read).
         * If cell A is (grand)parent of cell B, then both A.IsBefore(B) and B.IsBefore(A)
         * returns true.
         *</summary>*/
        public bool IsBefore(HtmlCell otherCell)
        {
            return wxHtmlCell_IsBefore(this.wxObject, Object.SafePtr(otherCell));
        }
        #endregion

        #region Methods
        /** <summary>Deprecated: Use property <c>pos</c>.
         * </summary>
         */
        public void SetPos(int x, int y)
        {
            wxHtmlCell_SetPos(wxObject, x, y);
        }

        public virtual void Layout(int w)
        {
            wxHtmlCell_Layout(wxObject, w);
        }

        /// <summary>Renders the cell.</summary>
        /// <param name="dc">Device context to which the cell is to be drawn</param>
        /// <param name="x">X-Coordinate of the parent's upper left corner (origin). You must add this to
        ///       <c>m_PosX</c> when passing coordinates to dc's methods Example:
        ///       <c>dc.DrawText("hello",x+m_PosX,y+m_PosY)</c></param>
        /// <param name="y">X-Coordinate of the parent's upper left corner (origin). You must add this to
        ///       <c>m_PosY</c> when passing coordinates to dc's methods Example:
        ///       <c>dc.DrawText("hello",x+m_PosX,y+m_PosY)</c></param>
        /// <param name="view_y1">y-coord of the first line visible in window. This is used to optimize rendering speed</param>
        /// <param name="view_y2">y-coord of the last line visible in window. This is used to optimize rendering speed</summary>*/</param>
        public void Draw(DC dc, int x, int y, int view_y1, int view_y2)
        {
            this.Draw(dc, x, y, view_y1, view_y2, null);
        }

        /// <summary>Renders the cell.</summary>
        /// <param name="dc">Device context to which the cell is to be drawn</param>
        /// <param name="x">X-Coordinate of the parent's upper left corner (origin). You must add this to
        ///       <c>m_PosX</c> when passing coordinates to dc's methods Example:
        ///       <c>dc.DrawText("hello",x+m_PosX,y+m_PosY)</c></param>
        /// <param name="y">X-Coordinate of the parent's upper left corner (origin). You must add this to
        ///       <c>m_PosY</c> when passing coordinates to dc's methods Example:
        ///       <c>dc.DrawText("hello",x+m_PosX,y+m_PosY)</c></param>
        /// <param name="view_y1">y-coord of the first line visible in window. This is used to optimize rendering speed</param>
        /// <param name="view_y2">y-coord of the last line visible in window. This is used to optimize rendering speed</summary></param>
        /// <param name="info"> is optional information on selections etc. that influence the presentation. You may use <c>null</c> here.</param>
        public virtual void Draw(DC dc, int x, int y, int view_y1, int view_y2, HtmlRenderingInfo info)
        {
            wxHtmlCell_Draw(wxObject, Object.SafePtr(dc), x, y, view_y1, view_y2, Object.SafePtr(info));
        }

        public virtual void DrawInvisible(DC dc, int x, int y, HtmlRenderingInfo info)
        {
            wxHtmlCell_DrawInvisible(wxObject, Object.SafePtr(dc), x, y, Object.SafePtr(info));
        }

        /** <summary>This method returns the first cell complying with the designated condition referring to the provided string.</summary>*/
        public HtmlCell Find(HtmlCond condition, string text)
        {
            return this.Find(condition, (wx.Object)wxString.SafeNew(text));
        }

        /** <summary>This method returns a pointer to the FIRST cell for that the condition is true.</summary>
         * <remarks>
         * It first checks if the condition is true for this
         * cell and then calls the next ones. (Note: it checks
         * all subcells if the cell is container).
         * Condition is unique condition identifier (see htmldefs.h)
         * (user-defined condition IDs should start from 10000)
         * and param is optional parameter
         * Example:
         * \code
         cell.Find(HtmlCond.IS_ANCHOR, "news");
         \endcode
         * returns pointer to anchor news.
         * </remarks>
         */
        public virtual HtmlCell Find(HtmlCond condition, Object param)
        {
            return Object.FindOrCreateObjectUsingClassInfo(wxHtmlCell_Find(wxObject, (int)condition, Object.SafePtr(param))) as HtmlCell;
        }

        public virtual void OnMouseClick(Window parent, int x, int y, MouseEvent evt)
        {
            wxHtmlCell_OnMouseClick(wxObject, Object.SafePtr(parent), x, y, Object.SafePtr(evt));
        }

        public virtual bool AdjustPagebreak(ref int pagebreak)
        {
            return wxHtmlCell_AdjustPagebreak(wxObject, ref pagebreak);
        }

        public bool CanLiveOnPagebreak
        {
            set { wxHtmlCell_SetCanLiveOnPagebreak(wxObject, value); }
        }

        public void GetHorizontalConstraints(out int left, out int right)
        {
            left = right = 0;
            wxHtmlCell_GetHorizontalConstraints(wxObject, ref left, ref right);
        }

        /** <summary>Find a cell which is part of this one according to the provided position relative to this cell.
         * Cf. RelativePos().</summary>*/
        public HtmlCell FindCellByPos(Point pos)
        {
            return this.FindCellByPos(pos.X, pos.Y);
        }

        /** <summary>Find a cell which is part of this one according to the provided position relative to this cell.
         * Cf. RelativePos().</summary>*/
        public HtmlCell FindCellByPos(int x, int y)
        {
            return this.FindCellByPos(x, y, HtmlFind.EXACT);
        }

        /** <summary>Find a cell which is part of this one according to the provided position relative to this cell.
         * Cf. RelativePos().</summary>*/
        public HtmlCell FindCellByPos(Point pos, HtmlFind mode)
        {
            return this.FindCellByPos(pos.X, pos.Y, mode);
        }

        /** <summary>Find a cell which is part of this one according to the provided position relative to this cell.
         * Cf. RelativePos().</summary>*/
        public HtmlCell FindCellByPos(int x, int y, HtmlFind mode)
        {
            return Object.FindOrCreateObjectUsingClassInfo(wxHtmlCell_FindCellByPos(wxObject, x, y, (int)mode)) as HtmlCell;
        }

        public static implicit operator HtmlCell (IntPtr obj) 
        {
            return Object.FindOrCreateObjectUsingClassInfo(obj) as HtmlCell;
        }
        #endregion
    }

	//-----------------------------------------------------------------------------

    public class HtmlWordCell : HtmlCell
    {
        [DllImport("wx-c")] static extern IntPtr wxHtmlWordCell_ctor(IntPtr word, IntPtr dc);
        [DllImport("wx-c")] static extern void   wxHtmlWordCell_Draw(IntPtr self, IntPtr dc, int x, int y, int view_y1, int view_y2, IntPtr info);
        /** <summary>Returns Ptr to the  wxWidgets RTTI.</summary>*/
        [DllImport("wx-c")]
        public static extern IntPtr HtmlWordCell_GetWxClassInfo();

        //-----------------------------------------------------------------------------

		public HtmlWordCell(IntPtr wxObject)
			: base(wxObject) {}

        public  HtmlWordCell(string word, DC dc)
            : this(new wxString(word), dc)
        {
        }

        static IntPtr SafeCTor(IntPtr word, IntPtr dc)
        {
            lock (DllSync)
            {
                return wxHtmlWordCell_ctor(word, dc);
            }
        }
        public HtmlWordCell(wxString word, DC dc)
            : this(SafeCTor(word.wxObject, Object.SafePtr(dc))) { }

        //-----------------------------------------------------------------------------

        public override void Draw(DC dc, int x, int y, int view_y1, int view_y2, HtmlRenderingInfo info)
        {
            wxHtmlWordCell_Draw(wxObject, Object.SafePtr(dc), x, y, view_y1, view_y2, Object.SafePtr(info));
        }
    }

	//-----------------------------------------------------------------------------

    /** <summary>Internal representation of HTML in a wx.HtmlWindow.
     * HTML is represented as a tree of nodes, the so-called cells.
     * The framework uses several classes of nodes. This class represends a node that
     * occasionally has more than one sibling.
     * 
     * Please note, that the current implementation might not call all virtual methods.
     * 
     * Note, that the HtmlCell.Next cell is the next cell of the HtmlCell.Parent.
     * </summary>
     */
    public class HtmlContainerCell : HtmlCell
    {
        #region C API
        [DllImport("wx-c")] static extern IntPtr wxHtmlContainerCell_ctor(IntPtr parent);
        [DllImport("wx-c")] static extern void   wxHtmlContainerCell_Layout(IntPtr self, int w);
        [DllImport("wx-c")] static extern void   wxHtmlContainerCell_Draw(IntPtr self, IntPtr dc, int x, int y, int view_y1, int view_y2, IntPtr info);
        [DllImport("wx-c")] static extern void   wxHtmlContainerCell_DrawInvisible(IntPtr self, IntPtr dc, int x, int y, IntPtr info);
        [DllImport("wx-c")][return:MarshalAs(UnmanagedType.U1)] static extern bool   wxHtmlContainerCell_AdjustPagebreak(IntPtr self, ref int pagebreak);
        [DllImport("wx-c")] static extern void   wxHtmlContainerCell_InsertCell(IntPtr self, IntPtr cell);
        [DllImport("wx-c")] static extern void   wxHtmlContainerCell_SetAlignHor(IntPtr self, int al);
        [DllImport("wx-c")] static extern int    wxHtmlContainerCell_GetAlignHor(IntPtr self);
        [DllImport("wx-c")] static extern void   wxHtmlContainerCell_SetAlignVer(IntPtr self, int al);
        [DllImport("wx-c")] static extern int    wxHtmlContainerCell_GetAlignVer(IntPtr self);
        [DllImport("wx-c")] static extern void   wxHtmlContainerCell_SetIndent(IntPtr self, int i, int what, int units);
        [DllImport("wx-c")] static extern int    wxHtmlContainerCell_GetIndent(IntPtr self, int ind);
        [DllImport("wx-c")] static extern int    wxHtmlContainerCell_GetIndentUnits(IntPtr self, int ind);
        [DllImport("wx-c")] static extern void   wxHtmlContainerCell_SetAlign(IntPtr self, IntPtr tag);
        [DllImport("wx-c")] static extern void   wxHtmlContainerCell_SetWidthFloat(IntPtr self, int w, int units);
        [DllImport("wx-c")] static extern void   wxHtmlContainerCell_SetWidthFloatTag(IntPtr self, IntPtr tag, double pixel_scale);
        [DllImport("wx-c")] static extern void   wxHtmlContainerCell_SetMinHeight(IntPtr self, int h, int align);
        [DllImport("wx-c")] static extern void   wxHtmlContainerCell_SetBackgroundColour(IntPtr self, IntPtr clr);
        [DllImport("wx-c")] static extern IntPtr wxHtmlContainerCell_GetBackgroundColour(IntPtr self);
        [DllImport("wx-c")] static extern void   wxHtmlContainerCell_SetBorder(IntPtr self, IntPtr clr1, IntPtr clr2);
        [DllImport("wx-c")] static extern IntPtr wxHtmlContainerCell_GetLink(IntPtr self, int x, int y);
        [DllImport("wx-c")] static extern IntPtr wxHtmlContainerCell_Find(IntPtr self, int condition, IntPtr param);
        [DllImport("wx-c")] static extern void   wxHtmlContainerCell_OnMouseClick(IntPtr self, IntPtr parent, int x, int y, IntPtr evt);
        [DllImport("wx-c")] static extern void   wxHtmlContainerCell_GetHorizontalConstraints(IntPtr self, ref int left, ref int right);
        /** <summary>Returns Ptr to the  wxWidgets RTTI.</summary>*/
        [DllImport("wx-c")]
        public static extern IntPtr HtmlContainerCell_GetWxClassInfo();
        #endregion

        #region CTor
        public HtmlContainerCell(IntPtr wxObject)
            : base(wxObject)
        {
        }

        static IntPtr SafeCTor(IntPtr parent)
        {
            lock (DllSync)
            {
                return wxHtmlContainerCell_ctor(parent);
            }
        }
        public HtmlContainerCell(HtmlContainerCell parent)
            : this(SafeCTor(Object.SafePtr(parent))) { }
        #endregion

        #region Overrides
        public override void Layout(int w)
        {
            wxHtmlContainerCell_Layout(wxObject, w);
        }

        public override void Draw(DC dc, int x, int y, int view_y1, int view_y2, HtmlRenderingInfo info)
        {
            wxHtmlContainerCell_Draw(wxObject, Object.SafePtr(dc), x, y, view_y1, view_y2, Object.SafePtr(info));
        }

        public override void DrawInvisible(DC dc, int x, int y, HtmlRenderingInfo info)
        {
            wxHtmlContainerCell_DrawInvisible(wxObject, Object.SafePtr(dc), x, y, Object.SafePtr(info));
        }

        public override bool AdjustPagebreak(ref int pagebreak)
        {
            return wxHtmlContainerCell_AdjustPagebreak(wxObject, ref pagebreak);
        }
        #endregion

        #region Public Methods
        public HtmlCell[] GetChildren()
        {
            ArrayList result = new ArrayList();
            HtmlCell child = this.FirstChild;
            while (child != null)
            {
                result.Add(child);
                child = child.Next;
            }
            return (HtmlCell[])result.ToArray(typeof(HtmlCell));
        }

        public void InsertCell(HtmlCell cell)
        {
            wxHtmlContainerCell_InsertCell(wxObject, Object.SafePtr(cell));
        }

        public int AlignHor
        {
            set { wxHtmlContainerCell_SetAlignHor(wxObject, value); }
            get { return wxHtmlContainerCell_GetAlignHor(wxObject); }
        }

        public int AlignVer
        {
            set { wxHtmlContainerCell_SetAlignVer(wxObject, value); }
            get { return wxHtmlContainerCell_GetAlignVer(wxObject); }
        }

        public void SetIndent(int i, int what, int units)
        {
            wxHtmlContainerCell_SetIndent(wxObject, i, what, units);
        }

        public int GetIndent(int ind)
        {
            return wxHtmlContainerCell_GetIndent(wxObject, ind);
        }

        public int GetIndentUnits(int ind)
        {
            return wxHtmlContainerCell_GetIndentUnits(wxObject, ind);
        }

        public HtmlTag Align
        {
            set { wxHtmlContainerCell_SetAlign(wxObject, Object.SafePtr(value)); }
        }

        public void SetWidthFloat(int w, int units)
        {
            wxHtmlContainerCell_SetWidthFloat(wxObject, w, units);
        }

        public void SetWidthFloat(HtmlTag tag, double pixel_scale)
        {
            wxHtmlContainerCell_SetWidthFloatTag(wxObject, Object.SafePtr(tag), pixel_scale);
        }

        public void SetMinHeight(int h, int align)
        {
            wxHtmlContainerCell_SetMinHeight(wxObject, h, align);
        }

        public Colour BackgroundColour
        {
            set { wxHtmlContainerCell_SetBackgroundColour(wxObject, Object.SafePtr(value)); }
            get { return new Colour(wxHtmlContainerCell_GetBackgroundColour(wxObject), true); }
        }

        public void SetBorder(Colour clr1, Colour clr2)
        {
            wxHtmlContainerCell_SetBorder(wxObject, Object.SafePtr(clr1), Object.SafePtr(clr2));
        }

        public virtual HtmlLinkInfo GetLink(int x, int y)
        {
            return (HtmlLinkInfo)FindObject(wxHtmlContainerCell_GetLink(wxObject, x, y), typeof(HtmlLinkInfo));
        }

        public override HtmlCell Find(HtmlCond condition, Object param)
        {
            return (HtmlCell)FindObject(wxHtmlContainerCell_Find(wxObject, (int)condition, Object.SafePtr(param)), typeof(HtmlCell));
        }

        public override void OnMouseClick(Window parent, int x, int y, MouseEvent evt)
        {
            wxHtmlContainerCell_OnMouseClick(wxObject, Object.SafePtr(parent), x, y, Object.SafePtr(evt));
        }

        public new void GetHorizontalConstraints(out int left, out int right)
        {
            left = right = 0;
            wxHtmlContainerCell_GetHorizontalConstraints(wxObject, ref left, ref right);
        }
        #endregion
    }

	//-----------------------------------------------------------------------------

    public class HtmlTag : Object
    {
        [DllImport("wx-c")] static extern IntPtr wxHtmlTag_GetParent(IntPtr self);
        [DllImport("wx-c")] static extern IntPtr wxHtmlTag_GetFirstSibling(IntPtr self);
        [DllImport("wx-c")] static extern IntPtr wxHtmlTag_GetLastSibling(IntPtr self);
        [DllImport("wx-c")] static extern IntPtr wxHtmlTag_GetChildren(IntPtr self);
        [DllImport("wx-c")] static extern IntPtr wxHtmlTag_GetPreviousSibling(IntPtr self);
        [DllImport("wx-c")] static extern IntPtr wxHtmlTag_GetNextSibling(IntPtr self);
        [DllImport("wx-c")] static extern IntPtr wxHtmlTag_GetNextTag(IntPtr self);
        [DllImport("wx-c")] static extern IntPtr wxHtmlTag_GetName(IntPtr self);
        [DllImport("wx-c")][return:MarshalAs(UnmanagedType.U1)]
        static extern bool   wxHtmlTag_HasParam(IntPtr self, IntPtr par);
        [DllImport("wx-c")] static extern IntPtr wxHtmlTag_GetParam(IntPtr self, IntPtr par, bool with_commas);
        [DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)]static extern bool wxHtmlTag_GetParamAsColour(IntPtr self, IntPtr par, IntPtr clr);
        [DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)]static extern bool wxHtmlTag_GetParamAsInt(IntPtr self, IntPtr par, ref int clr);
        //[DllImport("wx-c")] static extern int    wxHtmlTag_ScanParam(IntPtr self, IntPtr par, IntPtr format, IntPtr param);
        [DllImport("wx-c")] static extern IntPtr wxHtmlTag_GetAllParams(IntPtr self);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxHtmlTag_IsEnding(IntPtr self);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxHtmlTag_HasEnding(IntPtr self);
        [DllImport("wx-c")] static extern int    wxHtmlTag_GetBeginPos(IntPtr self);
        [DllImport("wx-c")] static extern int    wxHtmlTag_GetEndPos1(IntPtr self);
        [DllImport("wx-c")] static extern int    wxHtmlTag_GetEndPos2(IntPtr self);
        [DllImport("wx-c")] static extern void   wxHtmlTag_dtor(IntPtr self);

        //-----------------------------------------------------------------------------

        #region CTor / DTor
        public HtmlTag(IntPtr wxObject) 
            : base(wxObject, StorageMode.VolatileObject) { }

        protected override void CallDTor()
        {
            wxHtmlTag_dtor(wxObject);
        }
        #endregion

        //-----------------------------------------------------------------------------

        public HtmlTag Parent
        {
            get { return wxHtmlTag_GetParent(wxObject); }
        }

        public HtmlTag FirstSibling
        {
            get { return wxHtmlTag_GetFirstSibling(wxObject); }
        }

        public HtmlTag LastSibling
        {
            get { return wxHtmlTag_GetLastSibling(wxObject); }
        }

        public HtmlTag Children
        {
            get { return wxHtmlTag_GetChildren(wxObject); }
        }

        //-----------------------------------------------------------------------------

        public HtmlTag PreviousSibling
        {
            get { return wxHtmlTag_GetPreviousSibling(wxObject); }
        }

        public HtmlTag NextSibling
        {
            get { return wxHtmlTag_GetNextSibling(wxObject); }
        }

        //-----------------------------------------------------------------------------

        public HtmlTag NextTag
        {
            get { return wxHtmlTag_GetNextTag(wxObject); }
        }

        //-----------------------------------------------------------------------------

        public string Name
        {
            get { return new wxString(wxHtmlTag_GetName(wxObject), true); }
        }

        //-----------------------------------------------------------------------------

        public bool HasParam(string par)
        {
            using (wxString wxpar = new wxString(par))
            {
                return wxHtmlTag_HasParam(wxObject, wxpar.wxObject);
            }
        }

        public string GetParam(string par)
        {
            return this.GetParam(par, false);
        }

        public string GetParam(string par, bool with_commas)
        {
            using (wxString wxpar = new wxString(par))
            {
                return new wxString(wxHtmlTag_GetParam(wxObject, wxpar.wxObject, with_commas), true);
            }
        }

        //-----------------------------------------------------------------------------

        public bool GetParamAsColour(string par, Colour clr)
        {
            using (wxString wxpar = new wxString(par))
            {
                return wxHtmlTag_GetParamAsColour(wxObject, wxpar.wxObject, Object.SafePtr(clr));
            }
        }

        //-----------------------------------------------------------------------------

        public bool GetParamAsInt(string par, out int clr)
        {
            clr = 0;
            wxString wxpar = new wxString(par);
            return wxHtmlTag_GetParamAsInt(wxObject, wxpar.wxObject, ref clr);
        }

        //-----------------------------------------------------------------------------

        public string AllParams
        {
            get { return new wxString(wxHtmlTag_GetAllParams(wxObject), true); }
        }

        //-----------------------------------------------------------------------------

        public bool IsEnding
        {
            get { return wxHtmlTag_IsEnding(wxObject); }
        }

        public bool HasEnding
        {
            get { return wxHtmlTag_HasEnding(wxObject); }
        }

        //-----------------------------------------------------------------------------

        public int BeginPos
        {
            get { return wxHtmlTag_GetBeginPos(wxObject); }
        }

        public int EndPos1
        {
            get { return wxHtmlTag_GetEndPos1(wxObject); }
        }

        public int EndPos2
        {
            get { return wxHtmlTag_GetEndPos2(wxObject); }
        }

        //-----------------------------------------------------------------------------

        public static implicit operator HtmlTag (IntPtr obj) 
        {
            return (HtmlTag)FindObject(obj, typeof(HtmlTag));
        }

        public override string ToString()
        {
            if (this.HasEnding)
                return string.Format("<{0} {1}>..</{0}>", this.Name, this.AllParams);
            return string.Format("<{0} {1}>", this.Name, this.AllParams);
        }
    }

	//-----------------------------------------------------------------------------

    public class HtmlWinParser : HtmlParser
    {
        [DllImport("wx-c")] static extern IntPtr wxHtmlWinParser_ctor(IntPtr wnd);
        [DllImport("wx-c")] static extern void   wxHtmlWinParser_InitParser(IntPtr self, IntPtr source);
        [DllImport("wx-c")] static extern void   wxHtmlWinParser_DoneParser(IntPtr self);
        [DllImport("wx-c")] static extern IntPtr wxHtmlWinParser_GetProduct(IntPtr self);
        //[DllImport("wx-c")] static extern IntPtr wxHtmlWinParser_OpenURL(IntPtr self, int type, IntPtr url);
        [DllImport("wx-c")] static extern void   wxHtmlWinParser_SetDC(IntPtr self, IntPtr dc, double pixel_scale);
        [DllImport("wx-c")] static extern IntPtr wxHtmlWinParser_GetDC(IntPtr self);
        [DllImport("wx-c")] static extern double wxHtmlWinParser_GetPixelScale(IntPtr self);
        [DllImport("wx-c")] static extern int    wxHtmlWinParser_GetCharHeight(IntPtr self);
        [DllImport("wx-c")] static extern int    wxHtmlWinParser_GetCharWidth(IntPtr self);
        [DllImport("wx-c")] static extern IntPtr wxHtmlWinParser_GetWindow(IntPtr self);
        [DllImport("wx-c")] static extern void   wxHtmlWinParser_SetFonts(IntPtr self, IntPtr normal_face, IntPtr fixed_face, int[] sizes);
        //[DllImport("wx-c")] static extern void   wxHtmlWinParser_AddModule(IntPtr self, IntPtr module);
        //[DllImport("wx-c")] static extern void   wxHtmlWinParser_RemoveModule(IntPtr self, IntPtr module);
        [DllImport("wx-c")] static extern IntPtr wxHtmlWinParser_GetContainer(IntPtr self);
        [DllImport("wx-c")] static extern IntPtr wxHtmlWinParser_OpenContainer(IntPtr self);
        [DllImport("wx-c")] static extern IntPtr wxHtmlWinParser_SetContainer(IntPtr self, IntPtr c);
        [DllImport("wx-c")] static extern IntPtr wxHtmlWinParser_CloseContainer(IntPtr self);
        [DllImport("wx-c")] static extern int    wxHtmlWinParser_GetFontSize(IntPtr self);
        [DllImport("wx-c")] static extern void   wxHtmlWinParser_SetFontSize(IntPtr self, int s);
        [DllImport("wx-c")] static extern int    wxHtmlWinParser_GetFontBold(IntPtr self);
        [DllImport("wx-c")] static extern void   wxHtmlWinParser_SetFontBold(IntPtr self, int x);
        [DllImport("wx-c")] static extern int    wxHtmlWinParser_GetFontItalic(IntPtr self);
        [DllImport("wx-c")] static extern void   wxHtmlWinParser_SetFontItalic(IntPtr self, int x);
        [DllImport("wx-c")] static extern int    wxHtmlWinParser_GetFontUnderlined(IntPtr self);
        [DllImport("wx-c")] static extern void   wxHtmlWinParser_SetFontUnderlined(IntPtr self, int x);
        [DllImport("wx-c")] static extern int    wxHtmlWinParser_GetFontFixed(IntPtr self);
        [DllImport("wx-c")] static extern void   wxHtmlWinParser_SetFontFixed(IntPtr self, int x);
        [DllImport("wx-c")] static extern IntPtr wxHtmlWinParser_GetFontFace(IntPtr self);
        [DllImport("wx-c")] static extern void   wxHtmlWinParser_SetFontFace(IntPtr self, IntPtr face);
        [DllImport("wx-c")] static extern int    wxHtmlWinParser_GetAlign(IntPtr self);
        [DllImport("wx-c")] static extern void   wxHtmlWinParser_SetAlign(IntPtr self, int a);
        [DllImport("wx-c")] static extern IntPtr wxHtmlWinParser_GetLinkColor(IntPtr self);
        [DllImport("wx-c")] static extern void   wxHtmlWinParser_SetLinkColor(IntPtr self, IntPtr clr);
        [DllImport("wx-c")] static extern IntPtr wxHtmlWinParser_GetActualColor(IntPtr self);
        [DllImport("wx-c")] static extern void   wxHtmlWinParser_SetActualColor(IntPtr self, IntPtr clr);
        [DllImport("wx-c")] static extern IntPtr wxHtmlWinParser_GetLink(IntPtr self);
        [DllImport("wx-c")] static extern void   wxHtmlWinParser_SetLink(IntPtr self, IntPtr link);
        [DllImport("wx-c")] static extern IntPtr wxHtmlWinParser_CreateCurrentFont(IntPtr self);

        //-----------------------------------------------------------------------------

		public HtmlWinParser(IntPtr wxObject)
			: base(wxObject)
        {
        }

        public HtmlWinParser(HtmlWindow wnd)
            : base(wxHtmlWinParser_ctor(Object.SafePtr(wnd))) { }

        //-----------------------------------------------------------------------------

        public override void InitParser(string source)
        {
            using (wxString wxsource = new wxString(source))
            {
                wxHtmlWinParser_InitParser(wxObject, wxsource.wxObject);
            }
        }

        //-----------------------------------------------------------------------------

        public override void DoneParser()
        {
            wxHtmlWinParser_DoneParser(wxObject);
        }

        //-----------------------------------------------------------------------------

        public override Object Product
        {
            get { return FindObject(wxHtmlWinParser_GetProduct(wxObject), typeof(Object)); }
        }

        //-----------------------------------------------------------------------------

        /*public FSFile OpenURL(HtmlURLType type, string url)
        {
            return wxHtmlWinParser_OpenURL(wxObject, Object.SafePtr(type), url);
        }*/

        //-----------------------------------------------------------------------------

        public void SetDC(DC dc, double pixel_scale)
        {
            wxHtmlWinParser_SetDC(wxObject, Object.SafePtr(dc), pixel_scale);
        }

        //-----------------------------------------------------------------------------

        public DC DC
        {
            get { return (DC)FindObject(wxHtmlWinParser_GetDC(wxObject), typeof(DC)); }
        }

        //-----------------------------------------------------------------------------

        public double PixelScale
        {
            get { return wxHtmlWinParser_GetPixelScale(wxObject); }
        }

        //-----------------------------------------------------------------------------

        public int CharHeight
        {
            get { return wxHtmlWinParser_GetCharHeight(wxObject); }
        }

        public int CharWidth
        {
            get { return wxHtmlWinParser_GetCharWidth(wxObject); }
        }

        //-----------------------------------------------------------------------------

        public HtmlWindow Window
        {
            get { return (HtmlWindow)FindObject(wxHtmlWinParser_GetWindow(wxObject), typeof(HtmlWindow)); }
        }

        //-----------------------------------------------------------------------------

        public void SetFonts(string normal_face, string fixed_face, int[] sizes)
        {
            wxString wx_normal_face = new wxString(normal_face);
            wxString wx_fixed_face = new wxString(fixed_face);
            wxHtmlWinParser_SetFonts(wxObject, wx_normal_face.wxObject, wx_fixed_face.wxObject, sizes);
        }

        //-----------------------------------------------------------------------------

        public HtmlContainerCell Container
        {
            get { return (HtmlContainerCell)FindObject(wxHtmlWinParser_GetContainer(wxObject), typeof(HtmlContainerCell)); }
        }

        public HtmlContainerCell SetContainter(HtmlContainerCell cont)
        {
            return (HtmlContainerCell)FindObject(wxHtmlWinParser_SetContainer(wxObject, Object.SafePtr(cont)), typeof(HtmlContainerCell));
        }

        //-----------------------------------------------------------------------------

        public HtmlContainerCell OpenContainer()
        {
            return (HtmlContainerCell)FindObject(wxHtmlWinParser_OpenContainer(wxObject), typeof(HtmlContainerCell));
        }

        public HtmlContainerCell CloseContainer()
        {
            return (HtmlContainerCell)FindObject(wxHtmlWinParser_CloseContainer(wxObject), typeof(HtmlContainerCell));
        }

        //-----------------------------------------------------------------------------

        public int FontSize
        {
            get { return wxHtmlWinParser_GetFontSize(wxObject); }
            set { wxHtmlWinParser_SetFontSize(wxObject, value); }
        }

        public int FontBold
        {
            get { return wxHtmlWinParser_GetFontBold(wxObject); }
            set { wxHtmlWinParser_SetFontBold(wxObject, value); }
        }

        public int FontItalic
        {
            get { return wxHtmlWinParser_GetFontItalic(wxObject); }
            set { wxHtmlWinParser_SetFontItalic(wxObject, value); }
        }

        public int FontUnderlined
        {
            get { return wxHtmlWinParser_GetFontUnderlined(wxObject); }
            set { wxHtmlWinParser_SetFontUnderlined(wxObject, value); }
        }

        public int FontFixed
        {
            get { return wxHtmlWinParser_GetFontFixed(wxObject); }
            set { wxHtmlWinParser_SetFontFixed(wxObject, value); }
        }

        public string FontFace
        {
            get { return new wxString(wxHtmlWinParser_GetFontFace(wxObject), true); }
            set
            {
                wxString wxvalue = new wxString(value);
                wxHtmlWinParser_SetFontFace(wxObject, wxvalue.wxObject);
            }
        }

        //-----------------------------------------------------------------------------

        public int Align
        {
            get { return wxHtmlWinParser_GetAlign(wxObject); }
            set { wxHtmlWinParser_SetAlign(wxObject, value); }
        }

        //-----------------------------------------------------------------------------

        public Colour LinkColor
        {
            get { return new Colour(wxHtmlWinParser_GetLinkColor(wxObject), true); }
            set { wxHtmlWinParser_SetLinkColor(wxObject, Object.SafePtr(value)); }
        }

        public Colour ActualColor
        {
            get { return new Colour(wxHtmlWinParser_GetActualColor(wxObject), true); }
            set { wxHtmlWinParser_SetActualColor(wxObject, Object.SafePtr(value)); }
        }

        //-----------------------------------------------------------------------------

        public HtmlLinkInfo Link
        {
            get { return (HtmlLinkInfo)FindObject(wxHtmlWinParser_GetLink(wxObject), typeof(HtmlLinkInfo)); }
            set { wxHtmlWinParser_SetLink(wxObject, Object.SafePtr(value)); }
        }

        //-----------------------------------------------------------------------------

        public Font CreateCurrentFont()
        {
            return new Font(wxHtmlWinParser_CreateCurrentFont(wxObject));
        }
    }

	//-----------------------------------------------------------------------------

    /** <summary>Overload this and add this to an HtmlParser to define new tags.
     * The typical use of tag handlers is the definition of new tags that designate
     * forms which have been implemented as  wxWidgets panels. Refer to wx.HtmlHelpFrame.OnAboutBox()
     * for a simple example.
     * 
     * Refer to HtmlButtonTagHandler for a tag presenting a button that raises a CommandEvent.
     * </summary>*/
    public abstract class HtmlTagHandler : Object
    {
        #region Delegates, Types
        delegate IntPtr Virtual_GetSupportedTags();
        delegate int Virtual_HandleTag(IntPtr varib);
        #endregion
        #region C API
        [DllImport("wx-c")]
        static extern IntPtr wxHtmlTagHandler_CTor();
        [DllImport("wx-c")]
        static extern void  wxHtmlTagHandler_SetParser(IntPtr self, IntPtr parser);
        [DllImport("wx-c")]
        static extern void wxHtmlTagHandler_RegisterVirtual(IntPtr self, Virtual_Dispose onDispose, Virtual_GetSupportedTags callbackSupportedTags, Virtual_HandleTag callbackHandleTag);
        [DllImport("wx-c")]
        static extern IntPtr wxHtmlTagHandler_GetParser(IntPtr self);
        [DllImport("wx-c")]
        static extern IntPtr wxHtmlTagHandler_GetWParser(IntPtr self);
        [DllImport("wx-c")]
        static extern void wxHtmlTagHandler_ParseInner(IntPtr self, IntPtr tag);
        #endregion

        //-----------------------------------------------------------------------------

        IntPtr DoGetSupportedTags()
        {
            string result = this.GetSupportedTags();
            result = result.ToUpper();
            DisposableStringBox boxedResult = new DisposableStringBox(new wxString(result));
            return boxedResult.wxObject;
        }

        int DoHandleTag(IntPtr varib)
        {
            HtmlTag tag = new HtmlTag(varib);
            tag.memOwn = false;
            if (this.HandleTag(tag))
                return 1;
            else
                return 0;
        }

        #region State
        Virtual_GetSupportedTags _doGetSupportedTags=null;
        Virtual_HandleTag        _doHandleTag=null;
        #endregion

        #region CTor
        public HtmlTagHandler(IntPtr wxObject) 
            : base(wxObject)
        {
        }

        public HtmlTagHandler()
            : this(wxHtmlTagHandler_CTor())
        {
            _doGetSupportedTags = new Virtual_GetSupportedTags(DoGetSupportedTags);
            _doHandleTag = new Virtual_HandleTag(DoHandleTag);
            virtual_Dispose = new Virtual_Dispose(VirtualDispose);
            wxHtmlTagHandler_RegisterVirtual(this.wxObject, virtual_Dispose, _doGetSupportedTags, _doHandleTag);
        }
        #endregion

        #region public Properties
        public HtmlParser Parser
        {
            set
            {
                wxHtmlTagHandler_SetParser(wxObject, Object.SafePtr(value));
            }
            get
            {
                return HtmlParser.FindObject(wxHtmlTagHandler_GetParser(this.wxObject));
            }
        }

        public HtmlWinParser WParser
        {
            get
            {
                return (HtmlWinParser)HtmlParser.FindObject(wxHtmlTagHandler_GetWParser(this.wxObject));
            }
        }
        #endregion

        #region Abstract Methods
        /** <summary>Use this to define the tags that this handler implements.
         * Return a comma-separated list of tag names like "I,B,FONT,P".
         * 
         * Please note, that in contrast to modern XML-compatible conventions  wxWidgets 
         * uses upper case letters as standard form for tag names. For this reason,  wx.NET
         * will convert th result of this method automatically into upper case form. However,
         * analogous code in C++ will probably not run with the original  wxWidgets in C++ if
         * this result contains lower case letters.</summary>*/
        public abstract string GetSupportedTags();
        /** <summary>Implement the tags as defined by GetSupportedTags().</summary>*/
        public abstract bool HandleTag(HtmlTag tag);
        #endregion

        #region Protected Helpers
        protected void ParseInner(HtmlTag tag)
        {
            wxHtmlTagHandler_ParseInner(this.wxObject, tag.wxObject);
        }
        #endregion
    }

    /** <summary>A handler for tag <c>wxbutton</c> that defines a button on an HTML page raising a command event.</summary>
     * <remarks>
     * Use attributes <c>label</c> to provide a string to be displayed as a label and <c>id</c> to provide
     * an integer command ID for the event. Additionally instead of specifying a <c>cmd</c>, you might also
     * use <c>eventstring</c>. If an event string is specified, the command event caused by the button will
     * also hold the event string in the appropriate member variable.
     * Sample
     * \verbatim
     <wxoption label="Label" id="100">
     \endverbatim
     * You might use <c>labelart</c> to specify a label bitmap instead of a label string.
     \code
     string.Format("<wxbutton labelart=\"{0}\" id=\"{1}\" eventstring=\"This can be read from the event.\">", (int)ArtID.wxART_QUESTION, (int)MenuIDs.wxID_ABOUT);
     \endcode
     * Alternatively, you may provide the name of an art item as "artid_label" value. Example:
     \code
     string.Format("<wxbutton artid_label=\"QUESTION\" width=16 height=16 id=\"{0}\" eventstring=\"This can be read from the event.\">", (int)MenuIDs.wxID_ABOUT);
     \endcode
     * This also works:
     \code
     string.Format("<wxbutton artid_label=\"wxART_QUESTION\" width=16 height=16 id=\"{0}\" eventstring=\"This can be read from the event.\">", (int)MenuIDs.wxID_ABOUT);
     \endcode
     * Styles may be defined as text attribute "styles". The corresponding text will be parsed by the parser of enumeration
     * wx.WindowStyles.
     \code
     string.Format("<wxbutton artid_label=\"QUESTION\" styles=\"BU_AUTODRAW\" width=16 height=16 id=\"{0}\" eventstring=\"This can be read from the event.\">", (int)MenuIDs.wxID_ABOUT);
     \endcode
     * Additional parameters of the WXBUTTON tag are:
     * <list type="table">
     * <listheader><term>Parameter</term><description>Effect</description></listheader>
     * <item><term>width</term><description>The width of the button in pixel.</description></item>
     * <item><term>height</term><description>The height of the button in pixel.</description></item>
     * <item><term>id</term><description>The window ID of the created button control.</description></item>
     * <item><term>fgcolor</term><description>The foreground (text) color in HTML notation</description></item>
     * <item><term>bgcolor</term><description>The background color in HTML notation.</description></item>
     * </list>
     * </remarks>
     */
    public class HtmlButtonTagHandler : HtmlTagHandler
    {
        public HtmlButtonTagHandler()
        {
        }

        /** <summary> Handler for HTML tag "WXBUTTON".
         * Please note, that in contrast to modern XML-compatible conventions  wxWidgets 
         * uses upper case letters as standard form for tag names. So, use upper class letters
         * here exclusively.
         * </summary>
         */
        public override string GetSupportedTags()
        {
            return "wxbutton";
        }

        /** <summary>This contains the <c>eventstr</c> if one is specified and this implements the addition of the event string to the event.</summary>*/
        internal class CmdClosure
        {
            string _eventstr;
            internal CmdClosure(string eventstr)
            {
                this._eventstr = eventstr;
            }

            /** <summary>This will complete the button event if an event string has been specified by the hyperlink.</summary>*/
            internal void OnButtonSelect(object sender, Event evt)
            {
                ((CommandEvent)evt).String = this._eventstr;
                evt.Skip();
            }
        }

        /** <summary>This generates a window with a single button to be placed into the HTML page.
         * Return value is false to enable inner parsing.</summary>*/
        public override bool HandleTag(HtmlTag tag)
        {
            int cmd = Window.wxID_ANY;
            if (!tag.GetParamAsInt("id", out cmd))
                tag.GetParamAsInt("cmd", out cmd);
            int artProviderBitmap = -1;
            if (!tag.GetParamAsInt("artid_label", out artProviderBitmap))
                artProviderBitmap = -1;
            if (artProviderBitmap < 0 && tag.HasParam("artid_label"))
            {
                string artid = tag.GetParam("artid_label");
                if (!artid.ToLower().StartsWith("wxart_"))
                    artid = "wxART_" + artid;
                try
                {
                    artProviderBitmap = (int)Enum.Parse(typeof(wx.ArtID), artid, true);
                }
                catch (Exception exc)
                {
                    wx.Log.LogWarning(_("Parsing attribute LABELART of tag WXBUTTON caused exception {0}."), exc.Message);
                }
            }
            wx.WindowStyles style = wx.WindowStyles.NO_STYLE;
            if (tag.HasParam("styles"))
            {
                string[] styleNames = tag.GetParam("styles").Split('|', ',', ';');
                foreach (string scannedStyleName in styleNames)
                {
                    string styleName = scannedStyleName.Trim();
                    if (styleName.StartsWith("wx"))
                        styleName = styleName.Substring(2);
                    try
                    {
                        style = style | (wx.WindowStyles)Enum.Parse(typeof(wx.WindowStyles), styleName, true);
                    }
                    catch (Exception exc)
                    {
                        wx.Log.LogWarning(_("Error {1} parsing styles \"{0}\" in WXBUTTON tag.", tag.GetParam("styles"), exc));
                    }
                }
            }

            int x = -1;
            if (!tag.GetParamAsInt("width", out x))
                if (!tag.GetParamAsInt("x", out x))
                    x = -1;
            int y = -1;
            if (!tag.GetParamAsInt("height", out y))
                if (!tag.GetParamAsInt("y", out y))
                    y = -1;

            wx.Colour fgColor = null;
            if (tag.HasParam("fgcolor"))
            {
                try
                {
                    fgColor = new Colour(tag.GetParam("fgcolor"));
                }
                catch (Exception exc)
                {
                    System.Diagnostics.Trace.WriteLine(exc.Message);
                }
            }
            wx.Colour bgColor = null;
            if (tag.HasParam("bgcolor"))
            {
                try
                {
                    bgColor = new Colour(tag.GetParam("bgcolor"));
                }
                catch (Exception exc)
                {
                    System.Diagnostics.Trace.WriteLine(exc.Message);
                }
            }

            string label = tag.GetParam("label", false);
            string eventstr = tag.GetParam("eventstring", false);

            Window wnd = null;
            if (artProviderBitmap >= 0)
            {
                BitmapButton button = new BitmapButton(this.WParser.Window, cmd, ArtProvider.GetBitmap((ArtID)artProviderBitmap, ArtClient.wxART_BUTTON, new Size(x, y)), new Point(0, 0), wx.Window.wxDefaultSize, style);
                wnd = button;
                wnd.BackgroundColour = this.WParser.Window.BackgroundColour;
            }
            else
            {
                // this is a hack to make the button initially invisible
                wnd = new Button(this.WParser.Window, cmd, label, new Point(0, 0), Window.wxDefaultSize, 0);
            }
            if (bgColor != null)
                wnd.BackgroundColour = bgColor;
            if (fgColor != null)
                wnd.ForegroundColour = fgColor;
                
            wnd.Show(false);
            if (eventstr != null && eventstr.Length > 0)
            {
                CmdClosure cmdClosure = new CmdClosure(eventstr);
                wnd.AddCommandListener(Event.wxEVT_COMMAND_BUTTON_CLICKED, cmd, new EventListener(cmdClosure.OnButtonSelect), cmdClosure);
            }
            this.WParser.Container.InsertCell(new HtmlWidgetCell(wnd));

            return false;
        }
    }

    /** <summary>A handler for tag <c>wxoption</c> that defines a wx.CheckBox on an HTML page raising a command event.</summary>
     * <remarks>
     * Use attributes <c>label</c> to provide a string to be displayed as a label and <c>id</c> to provide
     * an integer command ID for the event
     * Sample:
     * \verbatim
     <wxoption label="Label" id="100">
     \endverbatim
     * Styles may be defined as text attribute "styles". The corresponding text will be parsed by the parser of enumeration
     * wx.WindowStyles.
     \code
     <wxoption styles=\"CHK_3STATE|CHK_ALLOW_3RD_STATE_FOR_USER\" width=16 height=16 id="100" >
     \endcode
     * Additional parameters of the WXBUTTON tag are:
     * <list type="table">
     * <listheader><term>Parameter</term><description>Effect</description></listheader>
     * <item><term>width</term><description>The width of the button in pixel.</description></item>
     * <item><term>height</term><description>The height of the button in pixel.</description></item>
     * <item><term>state</term><description>The initial state of the check in 2 state mode. Either "true" or "false" or "0" or "1".</description></item>
     * <item><term>tristate</term><description>The initial state of the check. Either CHECKED, UNCHECKED, or UNDETERMINED.</description></item>
     * <item><term>id</term><description>The window ID of the created button control.</description></item>
     * <item><term>fgcolor</term><description>The foreground (text) color in HTML notation</description></item>
     * <item><term>bgcolor</term><description>The background color in HTML notation.</description></item>
     * </list>
     * </remarks>
     */
    public class HtmlOptionTagHandler : HtmlTagHandler
    {
        public HtmlOptionTagHandler()
        {
        }

        /** <summary> Handler for HTML tag "WXOPTION".
         * </summary>
         */
        public override string GetSupportedTags()
        {
            return "WXOPTION";
        }

        /** <summary>This generates a window with a check box to be placed into the HTML page.
         * Return value is false to enable inner parsing.</summary>*/
        public override bool HandleTag(HtmlTag tag)
        {
            int cmd = Window.wxID_ANY;
            tag.GetParamAsInt("id", out cmd);
            wx.WindowStyles style = wx.WindowStyles.NO_STYLE;
            if (tag.HasParam("styles"))
            {
                string[] styleNames = tag.GetParam("styles").Split('|', ',', ';');
                foreach (string scannedStyleName in styleNames)
                {
                    string styleName = scannedStyleName.Trim();
                    if (styleName.StartsWith("wx"))
                        styleName = styleName.Substring(2);
                    try
                    {
                        style = style | (wx.WindowStyles)Enum.Parse(typeof(wx.WindowStyles), styleName, true);
                    }
                    catch (Exception exc)
                    {
                        wx.Log.LogWarning(_("Error {1} parsing styles \"{0}\" in WXOPTION tag.", tag.GetParam("styles"), exc));
                    }
                }
            }

            bool state2State = false;
            CheckBoxState state = CheckBoxState.UNCHECKED;
            if (tag.HasParam("tristate"))
            {
                string stateName = tag.GetParam("tristate").ToUpper().Trim();
                if (stateName == "CHECKED")
                {
                    state = CheckBoxState.CHECKED;
                    state2State = true;
                }
                else if (stateName == "UNCHECKED")
                    state = CheckBoxState.UNCHECKED;
                else if (stateName == "UNDETERMINED")
                    state = CheckBoxState.UNDETERMINED;
                else
                    wx.Log.LogWarning(_("Unknown tristate descriptor {0} in WXOPTION tag. Assuming unchecked state.", stateName));
            }
            if (tag.HasParam("state"))
            {
                string stateName = tag.GetParam("state").ToLower().Trim();
                if (stateName == "1" || stateName == "true")
                {
                    state = CheckBoxState.CHECKED;
                    state2State = true;
                }
                else if (stateName == "0" || stateName == "false")
                {
                    state = CheckBoxState.UNCHECKED;
                    state2State = false;
                }
                else
                    wx.Log.LogWarning(_("Unknown state descriptor {0} in WXOPTION tag. Assuming unchecked state.", stateName));
            }

            int x = -1;
            if (!tag.GetParamAsInt("width", out x))
                if (!tag.GetParamAsInt("x", out x))
                    x = -1;
            int y = -1;
            if (!tag.GetParamAsInt("height", out y))
                if (!tag.GetParamAsInt("y", out y))
                    y = -1;

            wx.Colour fgColor = null;
            if (tag.HasParam("fgcolor"))
            {
                try
                {
                    fgColor = new Colour(tag.GetParam("fgcolor"));
                }
                catch (Exception exc)
                {
                    System.Diagnostics.Trace.WriteLine(exc.Message);
                }
            }
            wx.Colour bgColor = null;
            if (tag.HasParam("bgcolor"))
            {
                try
                {
                    bgColor = new Colour(tag.GetParam("bgcolor"));
                }
                catch (Exception exc)
                {
                    System.Diagnostics.Trace.WriteLine(exc.Message);
                }
            }

            string label = tag.GetParam("label", false);
            CheckBox wnd = new CheckBox(this.WParser.Window, cmd, label, Point.Empty, Window.wxDefaultSize, style, "");
            if (wnd.Is3State())
                wnd.ThreeStateValue = state;
            else
                wnd.Value = state2State;
            if (bgColor != null)
                wnd.BackgroundColour = bgColor;
            if (fgColor != null)
                wnd.ForegroundColour = fgColor;

            wnd.Show(false);
            this.WParser.Container.InsertCell(new HtmlWidgetCell(wnd));

            return false;
        }
    }

    /** <summary>Tag presenting a bitmap from an art provider.</summary>
     * <remarks>
     * Tag is WXART, legal attributes are 
     * <list type="table">
     * <item><term> ARTID</term><description> with a string describing an art id as argument. The string will be converted to
     *     upper case letters and the prefix "wxART_" will be added. The result will be passed to
     *     the parser of enumeration wx.ArtID. Example: Value "cross_mark" will be converted to
     *     "wxART_CROSS_MARK" that will be parsed to wx.ArtID.wxART_CROSS_MARK. However, you may also
     *     pass "wxART_CROSS_MARK" directly as attribute or a number representing the index
     *     of the art work.
     *     This attribute is mandatory.
     *     </description></item>
     * <item><term> WIDTH</term><description> is a number providing the desired size in X direction.</description></item>
     * <item><term> HEIGHT</term><description> is a number providing the desired size in Y direction.</description></item>
     * <item><term> CLIENT</term><description> is analog to ARTID a string describing an element of wx.ArtClient with our without prefix.</description></item>
     * </list>
     * </remarks>
     */
    public class HtmlArtProviderTagHandler : HtmlTagHandler
    {
        public HtmlArtProviderTagHandler()
        {
        }

        /** <summary>"WXART"</summary>*/
        public override string GetSupportedTags()
        {
            return "wxart";
        }

        /** <summary>This generates a window presenting an image of the specified size.</summary>*/
        public override bool HandleTag(HtmlTag tag)
        {
            int artProviderBitmap = -1;
            if (!tag.GetParamAsInt("artid", out artProviderBitmap))
                artProviderBitmap = -1;
            if (artProviderBitmap < 0 && tag.HasParam("artid"))
            {
                string artid = tag.GetParam("artid");
                if (!artid.ToLower().StartsWith("wxart_"))
                    artid = "wxART_" + artid;
                try
                {
                    artProviderBitmap = (int)Enum.Parse(typeof(wx.ArtID), artid, true);
                }
                catch (Exception exc)
                {
                    wx.Log.LogWarning(_("Parsing attribute ARTID of tag WXART caused exception: {0}."), exc.Message);
                }
            }
            int x = -1;
            if (!tag.GetParamAsInt("width", out x))
                if (!tag.GetParamAsInt("x", out x))
                    x = -1;
            int y = -1;
            if (!tag.GetParamAsInt("height", out y))
                if (!tag.GetParamAsInt("y", out y))
                    y = -1;

            wx.ArtClient client = wx.ArtClient.wxART_OTHER;
            if (tag.HasParam("client"))
            {
                string artclient = tag.GetParam("client");
                if (!artclient.ToLower().StartsWith("wxart_"))
                    artclient = "wxART_" + artclient;
                try
                {
                   client = (wx.ArtClient)Enum.Parse(typeof(wx.ArtClient), artclient, true);
                }
                catch (Exception exc)
                {
                    wx.Log.LogWarning(_("Parsing attribute CLIENT of tag WXART caused exception: {0}"), exc.Message);
                }
            }

            StaticBitmap wnd = null;
            if (artProviderBitmap >= 0)
            {
                Bitmap b=ArtProvider.GetBitmap((ArtID)artProviderBitmap, client, new Size(x, y));
                wnd = new StaticBitmap(this.WParser.Window, b);
            }

            wnd.Show(false);
            this.WParser.Container.InsertCell(new HtmlWidgetCell(wnd));
            return false;
        }
    }

    /** <summary>This is a tag handler that offers you a choice among hyper links or actions.</summary><remarks>
     * Choices may be specified by constructors or tags. Actions may be action events or
     * hyper links. You may choose between the styles "Choice" and "List".
     * Example:
     * \code
     HtmlChoiceTagHandler tagHandler = new HtmlChoiceTagHandler(HtmlChoiceTagHandler.Style.List, "mychoice");
     tagHandler.Append("First choice: Command event", 23);
     tagHandler.Append("Second choice: Hyperlink", "http://testserver/page#section");
     \endcode
     * This handler will interpret tags like:
     *\verbatim
     <mychoice style="choice" id=24>
     <mychoice_choice cmd=24 name="Third choice"></mychoice>
     <mychoice_choice href="http://testserver/page#section2" name="Forth choice"></choice>
     <!-- the following three selections all have the same effect: Selection of item 0. !-->
     <mychoice_select cmd=23>
     <mychoice_select name="First choice: Command event">
     <mychoice_select pos=0>
     </mychoice>
     \endverbatim
     * Appending labels to the tag handler is useful for reusing a handler in several documents
     * while specifying choices in HTML is appropriate if the choice is exclusively relevant to the 
     * current document.
     * 
     * Items may be identified in contained tags like ".._SELECT" by the attributes <c>name</c>="Name" by their
     * name or the associated command: <c>href</c>="info.html" for an item
     * representing a certain page to be loaded and <c>cmd</c>=24 for items issueing a command event of the 
     * provided ID. The third option is to identify items by their position on the list: <c>pos</c>=0.
     * 
     * Please note that method Append() shall run before processing the tag. So, this method can be
     * considered as a part of the contructor.
     * 
     * This class relies on the fixes in the  wx.NET implementation of wx.HtmlWidgetCell. So,
     * analogously implementations will probably not work with the original  wxWidgets system in C++.
     * 
     * \b Please \b note that because of a bug in  wxWidgets this handler currently does not use
     * wx.HtmlParser.PushTagHandler and wx.HtmlParser.PopTagHandler but implements tags with suffix
     * "_CHOICE" and "_SELECT" as presented in the example.
     * 
     * Please note, that the type of the events caused by the control created by this tag handler
     * depends on the style. This will raise <c>EVT_LISTBOX</c> if the style requires a list. The 
     * event will be processed by <c>EVT_CHOICE</c> in case of style "choice".
     * </remarks>
     */
    public class HtmlChoiceTagHandler : HtmlTagHandler
    {
        #region Types
        public enum Style
        {
            List,
            Choice
        }
        #endregion
        #region State
        string _tag;
        int _id=-1;
        Style _style;
        IList _options = new ArrayList();
        IList _localOptions = new ArrayList();
        int _selection = -1;
        int _localSelection = -1;
        Size _size = Window.wxDefaultSize;
        #endregion
        #region CTor
        /// <summary>
        /// Creates a handler.
        /// </summary>
        /// <param name="style">The style (appearance) of the switch/choice-control.</param>
        /// <param name="tag">The HTML tag that this handler implements.</param>
        /// <param name="id">The window id of the choice dialog. This may be overridden by attribute ID.</param>
        /// <param name="size">The size of the control in pixel.</param>
        public HtmlChoiceTagHandler(Style style, string tag, Size size, int id)
            : this(style, tag)
        {
            this._id = id;
            this._size = size;
        }

        /// <summary>
        /// Creates a handler.
        /// </summary>
        /// <param name="style">The style (appearance) of the switch/choice-control.</param>
        /// <param name="tag">The HTML tag that this handler implements.</param>
        /// <param name="id">The window id of the choice dialog. This may be overridden by attribute ID.</param>
        public HtmlChoiceTagHandler(Style style, string tag, int id)
            : this(style, tag)
        {
            this._id = id;
        }

        /// <summary>
        /// Creates a handler.
        /// </summary>
        /// <param name="style">The style (appearance) of the switch/choice-control.</param>
        /// <param name="tag">The HTML tag that this handler implements.</param>
        public HtmlChoiceTagHandler(Style style, string tag)
            : base()
        {
            this._style = style;
            this._tag = tag.ToUpper();
        }

        /** <summary>Adds an item to the control without any command associated.</summary>*/
        public void Append(string item)
        {
            object[] pair = new object[2];
            pair[0] = item;
            this._options.Add(pair);
        }

        /** <summary>Add an item to the control.
         * Selecting the item will cause a command event that may be processed in surrounding
         * windows.
         *</summary>*/
        public void Append(string item, int cmd)
        {
            object[] pair = new object[2];
            pair[0] = item;
            pair[1] = cmd;
            this._options.Add(pair);
        }

        /** <summary>Add an item to the control loading a URL on selection.</summary>*/
        public void Append(string item, string hyperref)
        {
            object[] pair = new object[2];
            pair[0] = item;
            pair[1] = hyperref;
            this._options.Add(pair);
        }

        /// <summary>
        /// this creates a choice with attached client data.
        /// </summary>
        /// <param name="item">The name of the item.</param>
        /// <param name="clientdata">The client data.</param>
        public void Append(string item, object clientdata)
        {
            object[] pair = new object[3];
            pair[0] = item;
            pair[1] = null;
            pair[2] = clientdata;
            this._options.Add(pair);
        }

        /** <summary>Returns or sets the label of the selected item.
         * This is an empty string if nothing is selected.
         * Please refer to SelectCmd() and SelectHyperref() for alternative methods
         * of selecting items.
         * 
         * Assignments trying to select an unknown item will be ignored silently.
         * Refer to SelectItem() for an alternative method.</summary>*/
        public string SelectionString
        {
            get
            {
                if (this._selection < 0)
                    return "";
                else if (this._selection < this._options.Count)
                    return (string)((object[])this._options[this._selection])[0];
                else
                    return (string)((object[])this._localOptions[this._selection - this._options.Count])[0];
            }
            set
            {
                this.Selection=this.FindItem(value);
            }
        }

        public int Selection
        {
            get { return this._selection; }
            set { if (value >= 0 && value < this._options.Count+this._localOptions.Count) this._selection = value; }
        }

        /** <summary>Find the provided item string and return its index on success or -1 otherwise.</summary>*/
        public int FindItem(string item)
        {
            int index = 0;
            foreach (object[] pair in this._options)
            {
                if (item == ((string)pair[0]))
                    return index;
                ++index;
            }
            foreach (object[] pair in this._localOptions)
            {
                if (item == ((string)pair[0]))
                    return index;
                ++index;
            }
            return -1;
        }

        /** <summary>Find the first item of the provided command ID and return its index on success or -1 otherwise.
         * Items are often subject of localization/translation. A neutral designator for
         * selecting item is a representation of the action issued by the item. Therefore,
         * this method enables a user to select an item issueing a certain command.</summary>*/
        public int FindCmd(int cmd)
        {
            int index = 0;
            foreach (object[] pair in this._options)
            {
                if (pair[1] is int && cmd == ((int)pair[1]))
                    return index;
                ++index;
            }
            foreach (object[] pair in this._localOptions)
            {
                if (pair[1] is int && cmd == ((int)pair[1]))
                    return index;
                ++index;
            }
            return -1;
        }

        /** <summary>Find the first item of the provided hyperref and return its index on success or -1 otherwise.
         * Items are often subject of localization/translation. A neutral designator for
         * selecting item is a representation of the action issued by the item. Therefore,
         * this method enables a user to select an item issueing a new page to be displayed.</summary>*/
        public int FindHyperref(string hyperref)
        {
            int index = 0;
            foreach (object[] pair in this._options)
            {
                if (pair[1] is string && hyperref == ((string)pair[1]))
                    return index;
                ++index;
            }
            foreach (object[] pair in this._localOptions)
            {
                if (pair[1] is string && hyperref == ((string)pair[1]))
                    return index;
                ++index;
            }
            return -1;
        }
        #endregion

        #region Public Virtual
        public override string GetSupportedTags()
        {
            return this._tag + "," + this._tag + "_CHOICE," + this._tag + "_SELECT";
        }

        public override bool HandleTag(HtmlTag tag)
        {
            if (tag.Name == this._tag + "_CHOICE")
            {
                if (tag.HasParam("name"))
                {
                    if (tag.HasParam("cmd"))
                    {
                        int cmd = -1;
                        if (tag.GetParamAsInt("cmd", out cmd))
                        {
                            object[] pair = new object[2];
                            pair[0] = tag.GetParam("name");
                            pair[1] = cmd;
                            this._localOptions.Add(pair);
                        }
                    }
                    else if (tag.HasParam("href"))
                    {
                        object[] pair = new object[2];
                        pair[0] = tag.GetParam("name");
                        pair[1] = tag.GetParam("href");
                        this._localOptions.Add(pair);
                    }
                    else
                    {
                        object[] pair = new object[2];
                        pair[0] = tag.GetParam("name");
                        this._localOptions.Add(pair);
                    }
                }
            }
            else if (tag.Name == this._tag + "_SELECT")
            {
                if (tag.HasParam("cmd"))
                {
                    string cmdString = tag.GetParam("cmd", false);
                    try
                    {
                        int cmd = Int32.Parse(cmdString);
                        this._localSelection=this.FindCmd(cmd);
                    }
                    catch (Exception)
                    {
                    }
                }
                else if (tag.HasParam("href"))
                {
                    string hyperref = tag.GetParam("href", false);
                    this._localSelection = this.FindHyperref(hyperref);
                }
                else if (tag.HasParam("name"))
                {
                    string itemname = tag.GetParam("name", false);
                    this._localSelection = this.FindItem(itemname);
                }
                else if (tag.HasParam("pos"))
                {
                    tag.GetParamAsInt("pos", out this._localSelection);
                }
            }
            else
            {
                this._localOptions.Clear();
                this._localSelection = this._selection;

                if (tag.HasEnding)
                {
                    this.ParseInner(tag);
                }

                ControlWithItems wnd = null;
                int w = this._size.Width;
                int h = this._size.Height;
                int id = this._id;
                if (tag.HasParam("id"))
                {
                    try
                    {
                        id = Convert.ToInt32(tag.GetParam("id"));
                    }
                    catch (Exception exc)
                    {
                        System.Diagnostics.Trace.WriteLine(exc.Message);
                    }
                }
                if (tag.HasParam("h"))
                {
                    try
                    {
                        h = Convert.ToInt32(tag.GetParam("h"));
                    }
                    catch (Exception exc)
                    {
                        System.Diagnostics.Trace.WriteLine(exc.Message);
                    }
                }
                if (tag.HasParam("w"))
                {
                    try
                    {
                        w = Convert.ToInt32(tag.GetParam("w"));
                    }
                    catch (Exception exc)
                    {
                        System.Diagnostics.Trace.WriteLine(exc.Message);
                    }
                }

                Style style = this._style;
                string stylestring = tag.GetParam("style", false);
                stylestring = stylestring.ToLower();
                if (stylestring == "choice")
                    style = Style.Choice;
                else if (stylestring == "list")
                    style = Style.List;

                switch (style)
                {
                    case Style.List:
                        if (w < 80) w=80;
                        wnd = new ListBox(this.WParser.Window, id, Window.wxDefaultPosition, new Size(w, h));
                        wnd.EVT_LISTBOX(-1, new EventListener(OnSelectChoice));
                        break;
                    case Style.Choice:
                        wnd = new Choice(this.WParser.Window, id, Window.wxDefaultPosition, new Size(w, h), null);
                        wnd.EVT_CHOICE(-1, new EventListener(OnSelectChoice));
                        break;
                }
                int indexOfChoice=0;
                foreach (object[] pair in this._options)
                {
                    wnd.Append((string)pair[0]);
                    if (pair.Length > 2)
                        wnd.SetClientData(indexOfChoice, new SystemObjectClientData(pair[2]));
                    indexOfChoice += 1;
                }
                foreach (object[] pair in this._localOptions)
                {
                    wnd.Append((string)pair[0]);
                    indexOfChoice += 1;
                }
                if (this._options.Count + this._localOptions.Count > 0)
                {
                    if (this._localSelection < 0) this._localSelection = 0;
                    wnd.Selection = this._localSelection;
                }
                this._localOptions.Clear();
                this._localSelection = -1;

                this.WParser.Container.InsertCell(new HtmlWidgetCell(wnd));
            }
            return false;
        }
        #endregion
        #region Helper Functions
        internal void OnSelectChoice(object sender, Event evt)
        {
            int selectedIndex = ((CommandEvent)evt).Int;
            object[] option=null;
            if (selectedIndex >= this._options.Count
                && selectedIndex < this._options.Count+this._localOptions.Count)
            {
                option = (object[]) this._localOptions[selectedIndex-this._options.Count];
            }
            else if (selectedIndex >= 0 && selectedIndex < this._options.Count)
            {
                option = (object[]) this._options[selectedIndex];
            }
            if (option != null && option.Length > 1 && option[1] != null && option[1] is string)
            {
                CommandEvent loadPageEvent = new CommandEvent(Event.wxEVT_LOAD_HTML_PAGE);
                loadPageEvent.String = (string)option[1];
                this.WParser.Window.AddPendingEvent(loadPageEvent);
            }
            else
                evt.Skip();
        }
        #endregion
    }

    /** <summary>This tag handler will produce a text field in wxHTML pages using the wx.TextCtrl.</summary>
     * <remarks>
     * Add an instance of this to the tag handlers of an HTML parser before use:
     * <code>
     * wx.Html.HtmlWindow html = new wx.Html.HtmlWindow(this);
     * html.Parser.AddTagHandler(new wx.Html.HtmlTextFieldTagHandler());
     * </code>
     * From this code on, <c>html.Parser</c> will understand the tag "WXTEXT"
     * with the following parameters:
     * <list type="table">
     * <listheader><term>Parameter</term><description>Effect</description></listheader>
     * <item><term>text</term><description>Provides the default text that will be displayed before the user put something in.</description></item>
     * <item><term>id</term><description>A positive integer - the id of the created text window.</description></item>
     * <item><term>width</term><description>Specifies the width in pixels</description></item>
     * <item><term>height</term><description>Specifies the height in pixels</description></item>
     * <item><term>styles</term><description>Is a comma-separated list of style names (like <c>TE_MULTILINE</c> or <c>TE_PASSWORD</c>) that will be used to create the window.
     * Additional styles: DIRECTORY or DIRECTORY_LIST. These styles will add a button that will open a directory selector.
     * </description></item>
     * <item><term>fgcolor</term><description>The foreground (text) color in HTML notation</description></item>
     * <item><term>bgcolor</term><description>The background color in HTML notation.</description></item>
     * </list>
     * Please note, that the tag handler may raise EVT_TEXT() events (class wx.CommantEvent) with empty
     * string on startup. 
     * In contrast to the standard bahaviour of the wx.TextCtrl, the control used by this tag handler
     * will also raise a EVT_TEXT_ENTER event on loosing the focus. Unfortunately, you may encounter
     * unexpected senders. The sender will be determined according to the C++ interface to the wxWidgets
     * system - the class that implements the used event table.
     * </remarks>
     */
    public class HtmlTextFieldTagHandler : HtmlTagHandler
    {
        #region CTor 
        public HtmlTextFieldTagHandler() : base()
        {
        }
        #endregion

        #region Overrides
        public override string GetSupportedTags()
        {
            return "WXTEXT";
        }

        enum SpecialStyles
        {
            None,
            Directory,
            DirectoryList,
        }

        public override bool HandleTag(HtmlTag tag)
        {
            if (tag.Name == "WXTEXT")
            {
                wx.WindowStyles style = wx.WindowStyles.NO_STYLE;
                string defaultText = "";
                int id = -1;
                int w = -1;
                int h = -1;
                wx.Colour fgColor = null;
                wx.Colour bgColor = null;
                if (tag.HasParam("text"))
                {
                    defaultText = tag.GetParam("text", false);
                }
                if (tag.HasParam("fgcolor"))
                {
                    try
                    {
                        fgColor = new Colour(tag.GetParam("fgcolor"));
                    }
                    catch (Exception exc)
                    {
                        System.Diagnostics.Trace.WriteLine(exc.Message);
                    }
                }
                if (tag.HasParam("bgcolor"))
                {
                    try
                    {
                        bgColor = new Colour(tag.GetParam("bgcolor"));
                    }
                    catch (Exception exc)
                    {
                        System.Diagnostics.Trace.WriteLine(exc.Message);
                    }
                }

                SpecialStyles specialStyle=SpecialStyles.None;
                if (tag.HasParam("styles"))
                {
                    string styleStrings = tag.GetParam("styles", true);
                    if (styleStrings.StartsWith("\"") && styleStrings.EndsWith("\""))
                        styleStrings = styleStrings.Substring(1, styleStrings.Length - 2);
                    try
                    {
                        foreach (string styleString in styleStrings.Split(',', ';', '|'))
                        {
                            string styleStringToParse = styleString;
                            if (styleStringToParse.StartsWith("wx"))
                                styleStringToParse = styleStringToParse.Substring(2);
                            if (styleStringToParse.ToLower().Equals("directory"))
                                specialStyle = SpecialStyles.Directory;
                            else if (styleStringToParse.ToLower().Equals("directory_list"))
                                specialStyle = SpecialStyles.DirectoryList;
                            else
                            {
                                try
                                {
                                    WindowStyles styleHere = (WindowStyles)Enum.Parse(typeof(WindowStyles), styleStringToParse);
                                    style = style | styleHere;
                                }
                                catch (Exception exc)
                                {
                                    Trace.WriteLine(exc.Message);
                                }
                            }
                        }
                    }
                    catch(Exception exc)
                    {
                        System.Diagnostics.Trace.WriteLine(exc.Message);
                    }
                }
                if (tag.HasParam("id"))
                {
                    string idString = tag.GetParam("id", false);
                    try
                    {
                        id = Int32.Parse(idString);
                    }
                    catch (Exception)
                    {
                    }
                }
                if (tag.HasParam("width"))
                {
                    try
                    {
                        w = Int32.Parse(tag.GetParam("width", false));
                    }
                    catch (Exception)
                    {
                    }
                }
                if (tag.HasParam("height"))
                {
                    try
                    {
                        h = Int32.Parse(tag.GetParam("height", false));
                    }
                    catch (Exception)
                    {
                    }
                }
                Window parent=this.WParser.Window;
                Panel panel = null;
                if (specialStyle != SpecialStyles.None)
                {
                    panel = new Panel(parent, -1, Window.wxDefaultPosition, new Size(w, h));
                    parent = panel;
                }
                wx.TextCtrl wnd = new TextCtrl(parent, id, defaultText, Window.wxDefaultPosition, new Size(w, h), style);
                if (bgColor != null)
                    wnd.BackgroundColour = bgColor;
                if (fgColor != null)
                    wnd.ForegroundColour = fgColor;
                wnd.EVT_LEAVE_WINDOW(new EventListener(this.OnLeave));
                if (panel == null)
                    this.WParser.Container.InsertCell(new HtmlWidgetCell(wnd));
                else
                {
                    BoxSizer topsizer = new BoxSizer(Orientation.wxHORIZONTAL);
                    topsizer.Add(wnd, 1, SizerFlag.wxEXPAND | SizerFlag.wxALL, 1);
                    BitmapButton b = new BitmapButton(panel, ArtProvider.GetBitmap(ArtID.wxART_FOLDER_OPEN, ArtClient.wxART_BUTTON, new Size(16, 16)), Window.wxDefaultPosition, new Size(16, 16), WindowStyles.BORDER_RAISED);
                    b.ClientData = new object[2] { wnd, specialStyle};
                    b.EVT_BUTTON(-1, new EventListener(this.OnAskForDirectories));
                    topsizer.Add(b, 0, SizerFlag.wxALL, 1);
                    panel.AutoLayout = true;
                    panel.SetSizer(topsizer);
                    topsizer.Fit(panel);
                    this.WParser.Container.InsertCell(new HtmlWidgetCell(panel));
                }
            }
            return false;
        }
        #endregion

        #region Events
        /// <summary>
        /// This will be called on the EVT_LEAVE_WINDOW event of the created text window and will send
        /// a Event.wxEVT_COMMAND_TEXT_ENTER
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="evt"></param>
        void OnLeave(object sender, Event evt)
        {
            CommandEvent cevt=new CommandEvent(Event.wxEVT_COMMAND_TEXT_ENTER, ((wx.Window)sender).ID);
            ((wx.Window)sender).ProcessEvent(cevt);
            evt.Skip();
        }

        /// <summary>
        /// Will be called on pressing the button and opening the directory selector.
        /// </summary>
        /// <param name="sender">This should be the button for opening the directory selector.</param>
        /// <param name="evt"></param>
        void OnAskForDirectories(object sender, Event evt)
        {
            Window senderWnd = (Window)sender;
            object[] senderData=(object[])senderWnd.ClientData;
            TextCtrl textwnd = (TextCtrl)senderData[0];
            SpecialStyles style = (SpecialStyles)senderData[1];
            if (style != SpecialStyles.None)
            {
                string result=new DirSelector(_("Choose a directory.")).Value;
                if (result != null)
                {
                    if (style == SpecialStyles.Directory || textwnd.Value.Trim().Length == 0)
                        textwnd.Value = result;
                    else if (Environment.OSVersion.Platform == PlatformID.Unix)
                        textwnd.Value = textwnd.Value.Trim() + ":" + result;
                    else
                        textwnd.Value = textwnd.Value.Trim() + ";" + result;
                    textwnd.ProcessEvent(new CommandEvent(Event.wxEVT_COMMAND_TEXT_ENTER, textwnd.ID));
                }
            }
        }
        #endregion
    }

	//-----------------------------------------------------------------------------

    public class HtmlEntitiesParser : Object
    {
        [DllImport("wx-c")] static extern IntPtr wxHtmlEntitiesParser_ctor();
        [DllImport("wx-c")] static extern void   wxHtmlEntitiesParser_SetEncoding(IntPtr self, int encoding);
        [DllImport("wx-c")] static extern IntPtr wxHtmlEntitiesParser_Parse(IntPtr self, IntPtr input);
        [DllImport("wx-c")] static extern char   wxHtmlEntitiesParser_GetEntityChar(IntPtr self, IntPtr entity);
        [DllImport("wx-c")] static extern char   wxHtmlEntitiesParser_GetCharForCode(IntPtr self, uint code);

        //-----------------------------------------------------------------------------

		public HtmlEntitiesParser(IntPtr wxObject)
			: base(wxObject) {}

        public  HtmlEntitiesParser()
            : base(wxHtmlEntitiesParser_ctor()) { }

        //-----------------------------------------------------------------------------

        public FontEncoding Encoding
        {
            set { wxHtmlEntitiesParser_SetEncoding(wxObject, (int)value); }
        }

        //-----------------------------------------------------------------------------

        public string Parse(string input)
        {
            using (wxString wxInput = new wxString(input))
            {
                return new wxString(wxHtmlEntitiesParser_Parse(wxObject, wxInput.wxObject), true);
            }
        }

        //-----------------------------------------------------------------------------

        public char GetEntityChar(string entity)
        {
            using (wxString wxentity = new wxString(entity))
            {
                return wxHtmlEntitiesParser_GetEntityChar(wxObject, wxentity.wxObject);
            }
        }

        public char GetCharForCode(uint code)
        {
            return wxHtmlEntitiesParser_GetCharForCode(wxObject, code);
        }
    }

	//-----------------------------------------------------------------------------

    public abstract class HtmlParser : Object
    {
        [DllImport("wx-c")] static extern void   wxHtmlParser_SetFS(IntPtr self, IntPtr fs);
        [DllImport("wx-c")] static extern IntPtr wxHtmlParser_GetFS(IntPtr self);
        [DllImport("wx-c")] static extern IntPtr wxHtmlParser_OpenURL(IntPtr self, int type, IntPtr url);
        [DllImport("wx-c")] static extern IntPtr wxHtmlParser_Parse(IntPtr self, IntPtr source);
        [DllImport("wx-c")] static extern void   wxHtmlParser_InitParser(IntPtr self, IntPtr source);
        [DllImport("wx-c")] static extern void   wxHtmlParser_DoneParser(IntPtr self);
        [DllImport("wx-c")] static extern void   wxHtmlParser_StopParsing(IntPtr self);
        [DllImport("wx-c")] static extern void   wxHtmlParser_DoParsing(IntPtr self, int begin_pos, int end_pos);
        [DllImport("wx-c")] static extern void   wxHtmlParser_DoParsingAll(IntPtr self);
        [DllImport("wx-c")] static extern IntPtr wxHtmlParser_GetCurrentTag(IntPtr self);
        [DllImport("wx-c")] static extern void   wxHtmlParser_AddTagHandler(IntPtr self, IntPtr handler);
        [DllImport("wx-c")] static extern void   wxHtmlParser_PushTagHandler(IntPtr self, IntPtr handler, IntPtr tags);
        [DllImport("wx-c")] static extern void   wxHtmlParser_PopTagHandler(IntPtr self);
        [DllImport("wx-c")] static extern IntPtr wxHtmlParser_GetSource(IntPtr self);
        [DllImport("wx-c")] static extern void   wxHtmlParser_SetSource(IntPtr self, IntPtr src);
        [DllImport("wx-c")] static extern void   wxHtmlParser_SetSourceAndSaveState(IntPtr self, IntPtr src);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxHtmlParser_RestoreState(IntPtr self);
        [DllImport("wx-c")] static extern IntPtr wxHtmlParser_ExtractCharsetInformation(IntPtr self, IntPtr markup);
        [DllImport("wx-c")] [return: MarshalAs(UnmanagedType.U1)] static extern bool wxHtmlParser_IsWinParser(IntPtr self);

        //-----------------------------------------------------------------------------

        public HtmlParser(IntPtr wxObject) 
            : base(wxObject) { }


        /** <summary>A virtual construction of a  wx.NET parser object from a pointer to a  wxWidgets parser object.
         * Use this method to ensure existance of an appropriate wrapper for a HTML parser object.
         * Problem:  wxWidgets knows 2 classes: The general <c>wxHtmlParser</c> and the <c>wxHtmlWinParser</c>.
         * This will return (and create of not existing) an instance of wx.HtmlWinParser iff the
         * argument is a pointer to a <c>wxHtmlWinParser</c> instance. This method will use the internal
         * run time type information built into  wxWidgets.
         * 
         * Consider this as a specialization of method wx.Object.FindObject().
         * 
         * <c>IntPtr.Zero</c> will always result into <c>null</c>.
         * </summary>
         */
        new static public HtmlParser FindObject(IntPtr aWxObject)
        {
            if (aWxObject == IntPtr.Zero) return null;

            Type parserType = typeof(HtmlParser);
            if (wxHtmlParser_IsWinParser(aWxObject))
            {
                parserType = typeof(HtmlWinParser);
            }
            return (HtmlParser)Object.FindObject(aWxObject, parserType);
        }

        //-----------------------------------------------------------------------------

        /** <summary>.NET form of <c>wxHtmlParser</c>::GetFS() and <c>wxHtmlParser</c>::SetFS().
         * Please note, on setting the file system of the parser: The HTML parser
         * will take control of the native C++ instance that is wrapped by assigned
         * instance of wx.FileSystem. So, the .NET wrapper must have memory ownership of
         * instances, that will be assigned to this property. Otherwise, this will raise
         * an exception.</summary>*/
        public FileSystem FS
        {
            get
            {
                FileSystem fs=(FileSystem) Object.FindObject(wxHtmlParser_GetFS(wxObject), typeof(FileSystem));
                fs.memOwn = false; // this will be deallocated by the C++ instance of the parser.
                return fs;
            }
            set
            {
                if (!value.memOwn)
                    throw new Exception("Cannot set file system for HTML parser that is already in use.");
                value.memOwn = false;
                wxHtmlParser_SetFS(value.wxObject, value.wxObject);
            }
        }

        //-----------------------------------------------------------------------------

        public FSFile OpenURL(HtmlURLType type, string url)
        {
            using (wxString wxUrl = new wxString(url))
            {
                return new FSFile(wxHtmlParser_OpenURL(this.wxObject, (int)type, wxUrl.wxObject));
            }
        }

        //-----------------------------------------------------------------------------

        public Object Parse(string source)
        {
            using (wxString wxSource = new wxString(source))
            {
                return new Object(wxHtmlParser_Parse(this.wxObject, wxSource.wxObject));
            }
        }

        //-----------------------------------------------------------------------------

        public virtual void InitParser(string source)
        {
            using (wxString wxSource = new wxString(source))
            {
                wxHtmlParser_InitParser(this.wxObject, wxSource.wxObject);
            }
        }

        //-----------------------------------------------------------------------------

        public virtual void DoneParser()
        {
            wxHtmlParser_DoneParser(wxObject);
        }

        //-----------------------------------------------------------------------------

        public void StopParsing()
        {
            wxHtmlParser_StopParsing(wxObject);
        }

        //-----------------------------------------------------------------------------

        public void DoParsing(int begin_pos, int end_pos)
        {
            wxHtmlParser_DoParsing(wxObject, begin_pos, end_pos);
        }

        //-----------------------------------------------------------------------------

        public void DoParsing()
        {
            wxHtmlParser_DoParsingAll(wxObject);
        }

        //-----------------------------------------------------------------------------

        public HtmlTag GetCurrentTag()
        {
            return wxHtmlParser_GetCurrentTag(wxObject);
        }

        //-----------------------------------------------------------------------------

        public abstract Object Product { get; }

        //-----------------------------------------------------------------------------

        public void AddTagHandler(HtmlTagHandler handler)
        {
            wxHtmlParser_AddTagHandler(wxObject, Object.SafePtr(handler));
        }

        //-----------------------------------------------------------------------------

        public void PushTagHandler(HtmlTagHandler handler, string tags)
        {
            using (wxString wxTags = new wxString(tags))
            {
                wxHtmlParser_PushTagHandler(this.wxObject, Object.SafePtr(handler), wxTags.wxObject);
            }
        }

        //-----------------------------------------------------------------------------

        public void PopTagHandler()
        {
            wxHtmlParser_PopTagHandler(this.wxObject);
        }

        //-----------------------------------------------------------------------------

        public string Source
        {
            get { return new wxString(wxHtmlParser_GetSource(wxObject), true); }
            set
            {
                using (wxString wxSource = new wxString(value))
                {
                    wxHtmlParser_SetSource(this.wxObject, wxSource.wxObject);
                }
            }
        }

        public string SourceAndSaveState
        {
            set
            {
                using (wxString wxValue = new wxString(value))
                {
                    wxHtmlParser_SetSourceAndSaveState(this.wxObject, wxValue.wxObject);
                }
            }
        }

        public bool RestoreState()
        {
            return wxHtmlParser_RestoreState(wxObject);
        }

        //-----------------------------------------------------------------------------

        public string ExtractCharsetInformation(string markup)
        {
            using (wxString wxMarkup = new wxString(markup))
            {
                return new wxString(wxHtmlParser_ExtractCharsetInformation(this.wxObject, wxMarkup.wxObject), true);
            }
        }
    }

	//-----------------------------------------------------------------------------

    public abstract class HtmlProcessor : Object
    {
        [DllImport("wx-c")] static extern int    wxHtmlProcessor_GetPriority(IntPtr self);
        [DllImport("wx-c")] static extern void   wxHtmlProcessor_Enable(IntPtr self, bool enable);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxHtmlProcessor_IsEnabled(IntPtr self);

        //-----------------------------------------------------------------------------

        public HtmlProcessor(IntPtr wxObject) 
            : base(wxObject) { }

        //-----------------------------------------------------------------------------

        public abstract string Process(string text);

        //-----------------------------------------------------------------------------

        public int Priority
        {
            get { return wxHtmlProcessor_GetPriority(wxObject); }
        }

        //-----------------------------------------------------------------------------

        public bool Enabled
        {
            set { wxHtmlProcessor_Enable(wxObject, value); }
            get { return wxHtmlProcessor_IsEnabled(wxObject); }
        }
    }
    
	//-----------------------------------------------------------------------------
    
	public class HtmlRenderingInfo : Object
	{
		[DllImport("wx-c")] static extern IntPtr wxHtmlRenderingInfo_ctor();
		[DllImport("wx-c")] static extern void wxHtmlRenderingInfo_dtor(IntPtr self);
		[DllImport("wx-c")] static extern void wxHtmlRenderingInfo_SetSelection(IntPtr self, IntPtr s);
		[DllImport("wx-c")] static extern IntPtr wxHtmlRenderingInfo_GetSelection(IntPtr self);
		
		//-----------------------------------------------------------------------------
		
		public HtmlRenderingInfo(IntPtr wxObject)
			: base(wxObject) 
		{	
			this.wxObject = wxObject;
		}
		
		internal HtmlRenderingInfo(IntPtr wxObject, bool memOwn)
			: base(wxObject)
		{ 
			this.memOwn = memOwn;
			this.wxObject = wxObject;
		}
			
		public HtmlRenderingInfo()
			: this(wxHtmlRenderingInfo_ctor(), true) {}
			
		//---------------------------------------------------------------------
				
		public override void Dispose()
		{
			if (!disposed)
			{
                if (wxObject != IntPtr.Zero)
				{
					if (memOwn)
					{
                        lock (DllSync)
                        {
						wxHtmlRenderingInfo_dtor(wxObject);
						memOwn = false;
                        }
					}
				}
				RemoveObject(wxObject);
				wxObject = IntPtr.Zero;
                --validInstancesCount;
                disposed = true;
			}
			
			base.Dispose();
			GC.SuppressFinalize(this);
		}
		
		//---------------------------------------------------------------------
		
		~HtmlRenderingInfo() 
		{
			Dispose();
		}
			
		//-----------------------------------------------------------------------------
		
		public HtmlSelection Selection
		{
			get { return (HtmlSelection)FindObject(wxHtmlRenderingInfo_GetSelection(wxObject), typeof(HtmlSelection)); }
			set { wxHtmlRenderingInfo_SetSelection(wxObject, Object.SafePtr(value)); }
		}
	}
	
	//-----------------------------------------------------------------------------
	
	public class HtmlSelection : Object
	{
		[DllImport("wx-c")] static extern IntPtr wxHtmlSelection_ctor();
		[DllImport("wx-c")] static extern void wxHtmlSelection_dtor(IntPtr self);
		[DllImport("wx-c")] static extern void wxHtmlSelection_Set(IntPtr self, ref Point fromPos, IntPtr fromCell, ref Point toPos, IntPtr toCell);
		[DllImport("wx-c")] static extern void wxHtmlSelection_Set2(IntPtr self, IntPtr fromCell, IntPtr toCell);
		[DllImport("wx-c")] static extern IntPtr wxHtmlSelection_GetFromCell(IntPtr self);
		[DllImport("wx-c")] static extern IntPtr wxHtmlSelection_GetToCell(IntPtr self);
		[DllImport("wx-c")] static extern void wxHtmlSelection_GetFromPos(IntPtr self, out Point fromPos);
		[DllImport("wx-c")] static extern void wxHtmlSelection_GetToPos(IntPtr self, out Point toPos);
		[DllImport("wx-c")] static extern void wxHtmlSelection_GetFromPrivPos(IntPtr self, out Point fromPrivPos);
		[DllImport("wx-c")] static extern void wxHtmlSelection_GetToPrivPos(IntPtr self, out Point toPrivPos);
		[DllImport("wx-c")] static extern void wxHtmlSelection_SetFromPrivPos(IntPtr self, ref Point pos);
		[DllImport("wx-c")] static extern void wxHtmlSelection_SetToPrivPos(IntPtr self, ref Point pos);
		[DllImport("wx-c")] static extern void wxHtmlSelection_ClearPrivPos(IntPtr self);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxHtmlSelection_IsEmpty(IntPtr self);
		
		//-----------------------------------------------------------------------------

		public HtmlSelection(IntPtr wxObject)
			: base(wxObject) 
		{
			this.wxObject = wxObject;
		}
		
		internal HtmlSelection(IntPtr wxObject, bool memOwn)
			: base(wxObject)
		{ 
			this.memOwn = memOwn;
			this.wxObject = wxObject;
		}
			
		public HtmlSelection()
			: this(wxHtmlSelection_ctor(), true) {}
			
		//---------------------------------------------------------------------
				
		public override void Dispose()
		{
			if (!disposed)
			{
                if (wxObject != IntPtr.Zero)
				{
					if (memOwn)
					{
                        lock (DllSync)
                        {
						wxHtmlSelection_dtor(wxObject);
						memOwn = false;
                        }
					}
				}
				RemoveObject(wxObject);
				wxObject = IntPtr.Zero;
                --validInstancesCount;
                disposed = true;
			}
			
			base.Dispose();
			GC.SuppressFinalize(this);
		}
		
		//---------------------------------------------------------------------
		
		~HtmlSelection() 
		{
			Dispose();
		}
			
		//-----------------------------------------------------------------------------
		
		public void Set(Point fromPos, HtmlCell fromCell, Point toPos, HtmlCell toCell)
		{
			wxHtmlSelection_Set(wxObject, ref fromPos, Object.SafePtr(fromCell), ref toPos, Object.SafePtr(toCell));
		}
		
		public void Set(HtmlCell fromCell, HtmlCell toCell)
		{
			wxHtmlSelection_Set2(wxObject, Object.SafePtr(fromCell), Object.SafePtr(toCell));
		}
		
		//-----------------------------------------------------------------------------
		
		public HtmlCell FromCell
		{
			get { return (HtmlCell)Object.FindObject(wxHtmlSelection_GetFromCell(wxObject), typeof(HtmlCell)); }
		}
		
		public HtmlCell ToCell
		{
			get { return (HtmlCell)Object.FindObject(wxHtmlSelection_GetToCell(wxObject), typeof(HtmlCell)); }
		}
		
		//-----------------------------------------------------------------------------
		
		public Point FromPos
		{
			get { 
				Point tpoint = new Point();
				wxHtmlSelection_GetFromPos(wxObject, out tpoint);
				return tpoint;
			}
		}
		
		public Point ToPos
		{
			get {
				Point tpoint = new Point();
				wxHtmlSelection_GetToPos(wxObject, out tpoint);
				return tpoint;
			}
		}
		
		//-----------------------------------------------------------------------------
		
		public Point FromPrivPos
		{
			get { 
				Point tpoint = new Point();
				wxHtmlSelection_GetFromPrivPos(wxObject, out tpoint);
				return tpoint;
			}
			
			set { wxHtmlSelection_SetFromPrivPos(wxObject, ref value); }
		}
		
		public Point ToPrivPos
		{
			get {
				Point tpoint = new Point();
				wxHtmlSelection_GetToPrivPos(wxObject, out tpoint);
				return tpoint;
			}
			
			set { wxHtmlSelection_SetToPrivPos(wxObject, ref value); }
		}
		
		//-----------------------------------------------------------------------------
		
		public void ClearPrivPos()
		{
			wxHtmlSelection_ClearPrivPos(wxObject);
		}
		
		//-----------------------------------------------------------------------------
		
		public bool Empty
		{
			get { return wxHtmlSelection_IsEmpty(wxObject); }
		}
	}
	
	//-----------------------------------------------------------------------------
	
	public class HtmlEasyPrinting : Object
	{
		public const int wxPAGE_ODD	= 0;
		public const int wxPAGE_EVEN	= 1;
		public const int wxPAGE_ALL	= 2;
		
		//-----------------------------------------------------------------------------
	
		[DllImport("wx-c")] static extern IntPtr wxHtmlEasyPrinting_ctor(IntPtr name, IntPtr parent);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxHtmlEasyPrinting_PreviewFile(IntPtr self, IntPtr htmlfile);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxHtmlEasyPrinting_PreviewText(IntPtr self, IntPtr htmltext, IntPtr basepath);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxHtmlEasyPrinting_PrintFile(IntPtr self, IntPtr htmlfile);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxHtmlEasyPrinting_PrintText(IntPtr self, IntPtr htmltext, IntPtr basepath);
		[DllImport("wx-c")] static extern void   wxHtmlEasyPrinting_PageSetup(IntPtr self);
        [DllImport("wx-c")] static extern void wxHtmlEasyPrinting_SetHeader(IntPtr self, IntPtr header, int pg);
        [DllImport("wx-c")] static extern void wxHtmlEasyPrinting_SetFooter(IntPtr self, IntPtr footer, int pg);
		[DllImport("wx-c")] static extern void   wxHtmlEasyPrinting_SetFonts(IntPtr self, IntPtr normal_face, IntPtr fixed_face, int[] sizes);
		[DllImport("wx-c")] static extern void   wxHtmlEasyPrinting_SetStandardFonts(IntPtr self, int size, IntPtr normal_face, IntPtr fixed_face);
		[DllImport("wx-c")] static extern IntPtr wxHtmlEasyPrinting_GetPrintData(IntPtr self);
		[DllImport("wx-c")] static extern IntPtr wxHtmlEasyPrinting_GetPageSetupData(IntPtr self);
		
		//-----------------------------------------------------------------------------
		
		public HtmlEasyPrinting(IntPtr wxObject)
			: base(wxObject) {}
			
		public HtmlEasyPrinting()
			: this("Printing", null) {}
			
		public HtmlEasyPrinting(string name)
			: this(name, null) {}
			
		public HtmlEasyPrinting(string name, Window parentWindow)
			: this(new wxString(name), parentWindow) {}

        public HtmlEasyPrinting(wxString name, Window parentWindow)
            : base(wxHtmlEasyPrinting_ctor(name.wxObject, Object.SafePtr(parentWindow))) { }
        
        //-----------------------------------------------------------------------------
		
		public bool PreviewFile(string htmlfile)
		{
            using (wxString wxhtmlfile = new wxString(htmlfile))
            {
                return wxHtmlEasyPrinting_PreviewFile(wxObject, wxhtmlfile.wxObject);
            }
		}
		
		//-----------------------------------------------------------------------------
		
		public bool PreviewText(string htmltext)
		{
			return PreviewText(htmltext, "");
		}
		
		public bool PreviewText(string htmltext, string basepath)
		{
            using (wxString wxhtmltext = new wxString(htmltext))
            using (wxString wxbasepath = new wxString(basepath))
            {
                return wxHtmlEasyPrinting_PreviewText(wxObject, wxhtmltext.wxObject, wxbasepath.wxObject);
            }
		}
		
		//-----------------------------------------------------------------------------
		
		public bool PrintFile(string htmlfile)
		{
            using (wxString wxHtmlfile = new wxString(htmlfile))
            {
                return wxHtmlEasyPrinting_PrintFile(wxObject, wxHtmlfile.wxObject);
            }
		}
		
		//-----------------------------------------------------------------------------
		
		public bool PrintText(string htmltext)
		{
			return PrintText(htmltext, "");
		}
		
		public bool PrintText(string htmltext, string basepath)
		{
            using (wxString wxHtmlText = new wxString(htmltext))
            using (wxString wxBasePath = new wxString(basepath))
            {
                return wxHtmlEasyPrinting_PrintText(wxObject, wxHtmlText.wxObject, wxBasePath.wxObject);
            }
		}
		
		//-----------------------------------------------------------------------------
		
		/*public void PrinterSetup()
		{
			wxHtmlEasyPrinting_PrinterSetup(wxObject);
		}*/
		
		//-----------------------------------------------------------------------------
		
		public void PageSetup()
		{
			wxHtmlEasyPrinting_PageSetup(wxObject);
		}
		
		//-----------------------------------------------------------------------------
		
		public void SetHeader(string header)
		{
			SetHeader(header, wxPAGE_ALL);
		}
		
		public void SetHeader(string header, int pg)
		{
            using (wxString wxHeader = new wxString(header))
            {
                wxHtmlEasyPrinting_SetHeader(wxObject, wxHeader.wxObject, pg);
            }
		}
		
		//-----------------------------------------------------------------------------
		
		public void SetFooter(string footer)
		{
			SetFooter(footer, wxPAGE_ALL);
		}
		
		public void SetFooter(string footer, int pg)
		{
            using (wxString wxFooter = new wxString(footer))
            {
                wxHtmlEasyPrinting_SetFooter(wxObject, wxFooter.wxObject, pg);
            }
		}
		
		//-----------------------------------------------------------------------------
		
		public void SetFonts(string normal_face, string fixed_face)
		{
			SetFonts(normal_face, fixed_face, null);
		}
		
		public void SetFonts(string normal_face, string fixed_face, int[] sizes)
		{
            using (wxString wxFixedFont = new wxString(fixed_face))
            using (wxString wxNormalFont = new wxString(normal_face))
            {
                wxHtmlEasyPrinting_SetFonts(wxObject, wxNormalFont.wxObject, wxFixedFont.wxObject, sizes);
            }
		}
		
		//-----------------------------------------------------------------------------
		
		public void SetStandardFonts()
		{
			SetStandardFonts(-1, "", "");
		}
		
		public void SetStandardFonts(int size)
		{
			SetStandardFonts(size, "", "");
		}
		
		public void SetStandardFonts(int size, string normal_face)
		{
			SetStandardFonts(size, normal_face, "");
		}
		
		public void SetStandardFonts(int size, string normal_face, string fixed_face)
		{
            using (wxString wxFixedFont = new wxString(fixed_face))
            using (wxString wxNormalFont = new wxString(normal_face))
            {
                wxHtmlEasyPrinting_SetStandardFonts(wxObject, size, wxNormalFont.wxObject, wxFixedFont.wxObject);
            }
		}
		
		//-----------------------------------------------------------------------------
		
		public PrintData PrintData
		{
			get { return (PrintData)FindObject(wxHtmlEasyPrinting_GetPrintData(wxObject), typeof(PrintData)); }
		}
		
		//-----------------------------------------------------------------------------
		
		public PageSetupDialogData PageSetupData
		{
			get { return (PageSetupDialogData)FindObject(wxHtmlEasyPrinting_GetPageSetupData(wxObject), typeof(PageSetupDialogData)); }
		}
	}
}

