//-----------------------------------------------------------------------------
// wx.NET - Accelerator.cs
//
// The wxAccelerator* interfaces
//
// Written by Alexander Olk (xenomorph2@onlinehome.de)
// (C) 2004 by Alexander Olk
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: Accelerator.cs,v 1.16 2010/07/12 21:42:50 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Runtime.InteropServices;

namespace wx
{
    /// <summary>
    /// An entry in the AcceleratorTable.
    /// </summary>
	public class AcceleratorEntry : Object
    {
        #region Types
        /** <summary>Use this to define any modifier key that has to be pressed together with the provided key code.</summary>
         */
        [Flags]
        public enum AccelFlags
        {
            NORMAL=0x0000,
            ALT   =0x0001,
            CTRL  =0x0002,
            SHIFT =0x0004
        }
        #endregion

        #region C API
        [DllImport("wx-c")] static extern IntPtr wxAcceleratorEntry_ctor(int flags, int keyCode, int cmd, IntPtr item);
		[DllImport("wx-c")] static extern void   wxAcceleratorEntry_dtor(IntPtr self);
		[DllImport("wx-c")] static extern void   wxAcceleratorEntry_Set(IntPtr self, int flags, int keyCode, int cmd, IntPtr item);
		[DllImport("wx-c")] static extern void   wxAcceleratorEntry_SetMenuItem(IntPtr self, IntPtr item);
		[DllImport("wx-c")] static extern int    wxAcceleratorEntry_GetFlags(IntPtr self);
		[DllImport("wx-c")] static extern int    wxAcceleratorEntry_GetKeyCode(IntPtr self);
		[DllImport("wx-c")] static extern int    wxAcceleratorEntry_GetCommand(IntPtr self);
		[DllImport("wx-c")] static extern IntPtr wxAcceleratorEntry_GetMenuItem(IntPtr self);
        #endregion

        #region CTor
        public AcceleratorEntry(IntPtr wxObject)
			: base(wxObject)
		{
			this.wxObject = wxObject;
		}
			
		internal AcceleratorEntry(IntPtr wxObject, bool memOwn)
			: base(wxObject)
		{ 
			this.memOwn = memOwn;
			this.wxObject = wxObject;
		}
			
		public AcceleratorEntry()
			: this(0, 0, 0, null) {}

        public AcceleratorEntry(AccelFlags flags)
			: this(flags, 0, 0, null) {}

        public AcceleratorEntry(AccelFlags flags, KeyCode keyCode)
			: this(flags, keyCode, 0, null) {}

        public AcceleratorEntry(AccelFlags flags, KeyCode keyCode, int cmd)
			: this(flags, keyCode, cmd, null) {}

        static IntPtr LockedCTor(AccelFlags flags, KeyCode keyCode, int cmd, MenuItem item)
        {
            lock (DllSync)
            {
                return wxAcceleratorEntry_ctor((int)flags, (int)keyCode, cmd, Object.SafePtr(item));
            }
        }

        public AcceleratorEntry(AccelFlags flags, KeyCode keyCode, int cmd, MenuItem item)
			: this(LockedCTor(flags, keyCode, cmd, item), false) 
		{
			virtual_Dispose = new Virtual_Dispose(VirtualDispose);
		}

        public AcceleratorEntry(AccelFlags flags, char keyCode)
            : this(flags, (KeyCode) keyCode, 0, null) { }

        public AcceleratorEntry(AccelFlags flags, char keyCode, int cmd)
            : this(flags, (KeyCode)keyCode, cmd, null) { }

        public AcceleratorEntry(AccelFlags flags, char keyCode, int cmd, MenuItem mi)
            : this(flags, (KeyCode)keyCode, cmd, mi) { }
		
		//---------------------------------------------------------------------

		internal static IntPtr SafePtr(AcceleratorEntry obj)
		{
			return (obj == null) ? IntPtr.Zero : obj.wxObject;
        }
        #endregion

        #region Modifiers
        public void Set(int flags, int keyCode, int cmd)
		{
			Set(flags, keyCode, cmd);
		}
		
		public void Set(int flags, int keyCode, int cmd, MenuItem item)
		{
			wxAcceleratorEntry_Set(wxObject, flags, keyCode, cmd, Object.SafePtr(item));
        }
        #endregion

        #region Properties
        public MenuItem MenuItem
		{
			set { wxAcceleratorEntry_SetMenuItem(wxObject, Object.SafePtr(value)); }
			get { return (MenuItem)Object.FindObject(wxAcceleratorEntry_GetMenuItem(wxObject), typeof(MenuItem)); }
		}
		
		//-----------------------------------------------------------------------------
		
		public int Flags
		{
			get { return wxAcceleratorEntry_GetFlags(wxObject); }
		}
		
		//-----------------------------------------------------------------------------
		
		public int KeyCode
		{
			get { return wxAcceleratorEntry_GetKeyCode(wxObject); }
		}
		
		//-----------------------------------------------------------------------------
		
		public int Command
		{
			get { return wxAcceleratorEntry_GetCommand(wxObject); }
        }
        #endregion

        #region DTor
        protected override void CallDTor ()
        {
            wxAcceleratorEntry_dtor(wxObject);
        }
		
		//---------------------------------------------------------------------
		
		~AcceleratorEntry() 
		{
			Dispose();
        }
        #endregion
    }
	
	//-----------------------------------------------------------------------------
	
    /// <summary>
    /// An accelerator table allows the application to specify a table of keyboard shortcuts for menu or button commands.
    /// Initially, windows bear an accelerator table with no data.
    /// </summary>
	public class AcceleratorTable : Object
    {
        #region CTor
        [DllImport("wx-c")] static extern IntPtr wxAcceleratorTable_ctor();
		[DllImport("wx-c")] static extern bool   wxAcceleratorTable_Ok(IntPtr self);

        [DllImport("wx-c")]
        static extern IntPtr wxAcceleratorArrayNet_ctor(int size);
        [DllImport("wx-c")]
        static extern void wxAcceleratorArrayNet_Set(IntPtr self, int pos, IntPtr entry);
        [DllImport("wx-c")]
        static extern void wxAcceleratorArrayNet_dtor(IntPtr self);
        [DllImport("wx-c")]
        static extern IntPtr wxAcceleratorTable_ctorWithEntries(IntPtr acceleratorArray);
        #endregion

        #region CTor
        /** <summary>This is for internal purposes only.
         * This CTor will be used on creating wrappers for internally created instances.</summary>
         */
        public AcceleratorTable(IntPtr wxObject)
			: base(wxObject) {}
		
        static IntPtr LockedCTor()
        {
            lock (DllSync)
            {
                return wxAcceleratorTable_ctor();
            }
        }

        protected override void CallDTor ()
        {
        	wxAcceleratorArrayNet_dtor(this.wxObject);
        }


        /** <summary>Creates a NULL accelerator table.</summary>
         */
		public AcceleratorTable()
			: this(LockedCTor()) {}

        static IntPtr CreateInstance(AcceleratorEntry[] entries)
        {
            if (entries == null || entries.Length == 0)
                return LockedCTor();
            IntPtr result = IntPtr.Zero;
            lock (DllSync)
            {
                IntPtr array = IntPtr.Zero;
                try
                {
                    array = wxAcceleratorArrayNet_ctor(entries.Length);
                    for (int i = 0; i < entries.Length; ++i)
                    {
                        wxAcceleratorArrayNet_Set(array, i, entries[i].wxObject);
                    }
                    result = wxAcceleratorTable_ctorWithEntries(array);
                }
                finally
                {
                    if (array != IntPtr.Zero)
                        wxAcceleratorArrayNet_dtor(array);
                }
            }
            return result;
        }

        /** <summary>Creates an accelerator table from an array of accelerator entries.</summary>
         */
        public AcceleratorTable(params AcceleratorEntry[] entries)
            : this(CreateInstance(entries))
        {
        }
        #endregion
		
		public bool Ok
		{
			get { return wxAcceleratorTable_Ok(wxObject); }
		}
	}
}

