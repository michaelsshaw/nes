//-----------------------------------------------------------------------------
// wx.NET - Utils.cs
//
// Common Utils wrapper classes.
//
// Written by Alexander Olk (xenomorph2@onlinehome.de)
// (C) 2003 Alexander Olk
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: Utils.cs,v 1.32 2010/02/13 17:23:31 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Collections;
using System.Drawing;
using System.Runtime.InteropServices;

namespace wx
{
    public class Utils
    {
		[DllImport("wx-c")] static extern void wxGlobal_Bell();
		public static void Bell()
		{
			wxGlobal_Bell();
		}

        [DllImport("wx-c")]
        static extern void wxGlobal_Exit();
        /** <summary>Exits application after calling wx.App.OnExit().
         * Should only be used in an emergency: normally the top-level frame should be deleted (after deleting all
         * other frames) to terminate the application. See wx.CloseEvent and wx.App.</summary>*/
        public static void Exit()
        {
            wxGlobal_Exit();
        }
		
		//---------------------------------------------------------------------
		[DllImport("wx-c")] static extern IntPtr wxGlobal_GetHomeDir();

		public static string GetHomeDir()
		{
			return new wxString(wxGlobal_GetHomeDir(), true);
		}
		
		//---------------------------------------------------------------------

		[DllImport("wx-c")] static extern void wxSleep_func(int num);
        /// <summary>
        /// Sleeps for the specified number of seconds.
        /// This is deprecated. Use System.Threading.Thread.Sleep() instead.
        /// </summary>
        /// <param name="num">Number of seconds to sleep.</param>
		public static void wxSleep(int num)
		{
			wxSleep_func(num);
		}
		
		//---------------------------------------------------------------------

		[DllImport("wx-c")][return:MarshalAs(UnmanagedType.U1)] static extern bool wxYield_func();

        /// <summary>
        /// Calls wx.App.Yield.
        ///
        /// This function is kept only for backwards compatibility. Please use the wx.App.Yield method instead in any new code.
        /// </summary>
		public static void wxYield()
		{
            lock (Object.DllSync)
            {
                wxYield_func();
            }
		}
		
		//---------------------------------------------------------------------

		[DllImport("wx-c")] static extern void wxBeginBusyCursor_func();

		public static void BeginBusyCursor()
		{
			wxBeginBusyCursor_func();
		}

		[DllImport("wx-c")] static extern void wxEndBusyCursor_func();

		public static void EndBusyCursor()
		{
			wxEndBusyCursor_func();
		}
		
		//---------------------------------------------------------------------
		
		[DllImport("wx-c")] static extern void wxMutexGuiEnter_func();
		
		public static void MutexGuiEnter()
		{
			wxMutexGuiEnter_func();
		}
		
		[DllImport("wx-c")] static extern void wxMutexGuiLeave_func();
		
		public static void MutexGuiLeave()
		{
			wxMutexGuiLeave_func();
		}
		
			
		//-----------------------------------------------------------------------------

	        [DllImport("wx-c")] static extern int wxGetSingleChoiceIndex_func(IntPtr message, IntPtr caption, IntPtr choices, IntPtr parent, int x, int y, bool centre, int width, int height);

        	//-----------------------------------------------------------------------------

		public static int GetSingleChoiceIndex(string message, string caption, string[] choices)
		{
            wxString wxMessage = wxString.SafeNew(message);
            wxString wxCaption = wxString.SafeNew(caption);
            ArrayString wxChoices = ArrayString.SafeNewFrom(choices);
            return wxGetSingleChoiceIndex_func(Object.SafePtr(wxMessage), Object.SafePtr(wxCaption), Object.SafePtr(wxChoices), IntPtr.Zero, -1, -1, true, 200, 150);
		}

        	//-----------------------------------------------------------------------------

		public static int GetSingleChoiceIndex(string message, string caption, string[] choices, Window parent, int x, int y, bool centre, int width, int height)
		{
            wxString wxMessage = wxString.SafeNew(message);
            wxString wxCaption = wxString.SafeNew(caption);
            ArrayString wxChoices = ArrayString.SafeNewFrom(choices);
            return wxGetSingleChoiceIndex_func(Object.SafePtr(wxMessage), Object.SafePtr(wxCaption), Object.SafePtr(wxChoices), Object.SafePtr(parent), x, y, centre, width, height);
		}
	}
	
	//---------------------------------------------------------------------

	public class BusyCursor : IDisposable
	{
		public BusyCursor()
		{
			Utils.BeginBusyCursor();
		}
		
		public void Dispose()
		{
			Utils.EndBusyCursor();
		}
	}
	
	//---------------------------------------------------------------------

	public class WindowDisabler : Object
	{
		[DllImport("wx-c")] static extern IntPtr wxWindowDisabler_ctor(IntPtr winToSkip);
		[DllImport("wx-c")] static extern void wxWindowDisabler_dtor(IntPtr self);
		
		//---------------------------------------------------------------------

		public WindowDisabler(IntPtr wxObject)
			: base(wxObject)
		{
			this.wxObject = wxObject;
		}
		
		internal WindowDisabler(IntPtr wxObject, bool memOwn)
			: base(wxObject)
		{ 
			this.memOwn = memOwn;
			this.wxObject = wxObject;
		}

		public WindowDisabler()
			: this(null) {}

		public WindowDisabler(Window winToSkip)
			: this(wxWindowDisabler_ctor(Object.SafePtr(winToSkip)), true) {}
			
		//---------------------------------------------------------------------
				
		public override void Dispose()
		{
			if (!disposed)
			{
				if (wxObject != IntPtr.Zero)
				{
					if (memOwn)
					{
						wxWindowDisabler_dtor(wxObject);
						memOwn = false;
					}
				}
				RemoveObject(wxObject);
				wxObject = IntPtr.Zero;
                --validInstancesCount;
                disposed = true;
			}
			
			base.Dispose();
			GC.SuppressFinalize(this);
		}
		
		//---------------------------------------------------------------------
		
		~WindowDisabler() 
		{
			Dispose();
		}
	}
	
	//---------------------------------------------------------------------

    /// <summary>
    /// This class makes it easy to tell your user that the program is temporarily busy. Just create a wx.BusyInfo object
    /// within a <c>using</c> scope block, a message window will be shown.
    /// </summaryY
    /// <remarks>
    /// For example:
    /// <code>
    /// using (wx.BusyInfo wait=new wx.BusyInfo("Please wait, working..."))
    /// {
    ///   for (int i = 0; i < 100000; i++)
    ///   {
    ///     DoACalculation();
    ///   }
    /// </code>
    /// It works by creating a window in the constructor, and deleting it in the destructor (on dispose).
    /// You may also want to call wx.App.TheApp.Yield() to refresh the window periodically (in case it had been obscured
    /// by other windows, for example) like this:
    /// 
    /// <code>
    /// using (wx.BusyInfo wait=new wx.BusyInfo("Please wait, working..."))
    /// {
    ///   for (int i = 0; i < 100000; i++)
    ///   {
    ///     DoACalculation();
    ///     if ( !(i % 1000) )
    ///        wx.App.TheApp.SafeYield();
    ///   }
    /// }
    /// </code>
    /// but take care to not cause undesirable reentrancies when doing it (see wx.App.Yield() for more details).
    /// </remarks>
	public class BusyInfo : Object
	{
		[DllImport("wx-c")] static extern IntPtr wxBusyInfo_ctor(IntPtr message, IntPtr parent);
		[DllImport("wx-c")] static extern void   wxBusyInfo_dtor(IntPtr self);
		
		//---------------------------------------------------------------------
	
		public BusyInfo(IntPtr wxObject)
			: base(wxObject)
		{
			this.wxObject = wxObject;
		}
	
		public BusyInfo(string message)
			: this(message, null) {}

        public BusyInfo(string message, Window parent)
            : this(new wxString(message), parent)
        {
        }
		public BusyInfo(wxString message, Window parent)
			: this(wxBusyInfo_ctor(message.wxObject, Object.SafePtr(parent)), true) {}
			
		internal BusyInfo(IntPtr wxObject, bool memOwn)
			: base(wxObject)
		{
			this.memOwn = memOwn;
			this.wxObject = wxObject;
		}
		
		//---------------------------------------------------------------------

		public override void Dispose()
		{
			if (!disposed)
			{
                if (wxObject != IntPtr.Zero)
				{
					if (memOwn)
					{
						wxBusyInfo_dtor(wxObject);
					}
				}
				RemoveObject(wxObject);
				wxObject = IntPtr.Zero;
                --validInstancesCount;
                disposed = true;
			}
			
			base.Dispose();
			GC.SuppressFinalize(this);
		}
		
		//---------------------------------------------------------------------
		
		~BusyInfo() 
		{
			Dispose();
		}
	}
	
	//---------------------------------------------------------------------

    /** <summary>
     * Pops up a directory selector dialog. The arguments have the same meaning as those of wx.DirDialog.DirDialog().
     * The message is displayed at the top, and the default_path, if specified, is set as the initial selection.
     *
     * The application must check for an empty return value (if the user pressed Cancel).
     *
     * </summary>
     * <remarks>
     *  For example:
     * <code>
     * string dir = new wx.DirSelector("Choose a folder").Value;
     * if ( !dir.empty() )
     * {
     *   ...
     * }
     * </code>
     * </remarks>
     */
    public class DirSelector
    {
        [DllImport("wx-c")]
        static extern IntPtr wxGlobal_DirSelector(IntPtr message, IntPtr default_path, uint flags, IntPtr self, int x, int y);

        string value = "";

        /// <summary>
        /// Starts an instance with message string _("Select a file").
        /// </summary>
		public DirSelector()
            : this(Object._("Select a file"), (string)null, 0, null, Window.wxDefaultPosition) { }
	
        /// <summary>
        /// Selects a directory displaying the provided message.
        /// </summary>
        /// <param name="message">Message string</param>
        public DirSelector(string message)
            : this(message, (string)null, 0, null, Window.wxDefaultPosition) { }

        /// <summary>
        /// Selects a directory displaying the provided message.
        /// </summary>
        /// <param name="default_path">Starts with this directory. This directory shall exist.</param>
        /// <param name="message">Message string</param>
        /// <param name="default_path">Displays files in this path first</param>
        public DirSelector(string message, string default_path)
            : this(message, default_path, 0, null, Window.wxDefaultPosition) { }

        /// <summary>
        /// Selects a directory displaying the provided message.
        /// </summary>
        /// <param name="default_path">Starts with this directory. This directory shall exist.</param>
        /// <param name="message">Message string</param>
        /// <param name="flags">The window styles</param>
        public DirSelector(string message, string default_path, wx.WindowStyles flags)
            : this(message, default_path, flags, null, Window.wxDefaultPosition) { }

        /// <summary>
        /// Selects a directory displaying the provided message.
        /// </summary>
        /// <param name="message">Message string</param>
        /// <param name="default_path">Starts with this directory. This directory shall exist.</param>
        /// <param name="flags">The window styles</param>
        /// <param name="parent">The parent window</param>
        public DirSelector(string message, string default_path, wx.WindowStyles flags, Window parent)
			: this(message, default_path, flags, parent, Window.wxDefaultPosition) {}

        /// <summary>
        /// Selects a directory displaying the provided message.
        /// </summary>
        /// <param name="message">Message string</param>
        /// <param name="default_path">Starts with this directory. This directory shall exist.</param>
        /// <param name="flags">The window styles</param>
        /// <param name="parent">The parent window</param>
        /// <param name="position">The position of this dialog</param>
        public DirSelector(string message, string default_path, wx.WindowStyles flags, Window parent, Point position)
            : this(new wxString(message), new wxString(default_path), flags, parent, position.X, position.Y)
        {
        }

        /// <summary>
        /// Selects a directory displaying the provided message.
        /// </summary>
        /// <param name="message">Message string</param>
        /// <param name="default_path">Starts with this directory. This directory shall exist.</param>
        /// <param name="flags">The window styles</param>
        /// <param name="parent">The parent window</param>
        /// <param name="x">The x-coordinate of this dialog</param>
        /// <param name="y">The y-coordinate of this dialog</param>
        public DirSelector(wxString message, wxString default_path, wx.WindowStyles flags, Window parent, int x, int y)
		{
			value = new wxString(wxGlobal_DirSelector(message.wxObject, default_path.wxObject, (uint)flags, Object.SafePtr(parent), x, y), true);
		}
		
		//---------------------------------------------------------------------

        /// <summary>
        /// the selected file or the empty string if the user cancelled the input.
        /// This, use something like the following to deal with cancelations.
        /// <code>
        /// string result=new DirSelector(..).Value;
        /// if (result.Length == 0)
        ///     return; // cancelled input.
        /// </code>
        /// </summary>
        public string Value
        {
            get
            {
                return this.value;
            }
        }

		public static implicit operator string(DirSelector f)
		{
			return f.value;
		}
    }

    /** <summary>Asks for a file name opening a file selector dialog.
     * Especially relevant flags (on wx.WindowStyles) start with prefix FD_.
     * </summary>
     * <remarks>
     * Pops up a file selector box. In Windows, this is the common file selector dialog. In X, this is a file selector
     * box with the same functionality. The path and filename are distinct elements of a full file pathname. If path
     * is empty, the current directory will be used. If filename is empty, no default filename will be supplied.
     * The wildcard determines what files are displayed in the file selector, and file extension supplies a type extension
     * for the required filename. Flags may be a combination of wx.WindowStyles.FD_OPEN, wx.WindowStyles.FD_SAVE,
     * wx.WindowStyles.FD_OVERWRITE_PROMPT, or wx.WindowStyles.FD_FILE_MUST_EXIST. Note that .wx.WindowStyles.FD_MULTIPLE
     * can only be used with wx.FileDialog and not here as this function only returns a single file name.
     *
     * Both the Unix and Windows versions implement a wildcard filter. Typing a filename containing wildcards (*, ?) in 
     * the filename text item, and clicking on Ok, will result in only those files matching the pattern being displayed.
     *
     * The wildcard may be a specification for multiple types of file with a description for each, such as:
     * <c>"BMP files (*.bmp)|*.bmp|GIF files (*.gif)|*.gif"</c>.
     *
     * The application must check for an empty return value (the user pressed Cancel). For example:
     * <code>
     * wxString filename = wxFileSelector("Choose a file to open");
     * if ( !filename.empty() )
     * {
     *     // work with the file
     *     ...
     * }
     * //else: cancelled by user
     * </code>
     * </remarks>
     * <seealso cref="DirSelector"/>
     */
    public class FileSelector
	{
		private string value = "";
		
		//---------------------------------------------------------------------

		[DllImport("wx-c")] static extern IntPtr wxGlobal_FileSelector(IntPtr message, IntPtr default_path, IntPtr default_filename, IntPtr default_extension, IntPtr wildcard, uint flags, IntPtr self, int x, int y);
		
		//---------------------------------------------------------------------

        /// <summary>
        /// Starts an instance with message string _("Select a file").
        /// </summary>
		public FileSelector()
            : this(Object._("Select a file"), (string)null, (string)null, (string)null, "*", 0, null, Window.wxDefaultPosition) { }
	
        /// <summary>
        /// Selects a file displaying the provided message.
        /// </summary>
        /// <param name="message">Message string</param>
		public FileSelector(string message)
            : this(message, (string)null, (string)null, (string)null, "*", 0, null, Window.wxDefaultPosition) { }

        /// <summary>
        /// Selects a file displaying the provided message.
        /// </summary>
        /// <param name="message">Message string</param>
        /// <param name="default_path">Displays files in this path first</param>
        public FileSelector(string message, string default_path)
            : this(message, default_path, (string)null, (string)null, "*", 0, null, Window.wxDefaultPosition) { }

        /// <summary>
        /// Selects a file displaying the provided message.
        /// </summary>
        /// <param name="message">Message string</param>
        /// <param name="default_path">Displays files in this path first</param>
        /// <param name="default_filename">The default filename</param>
        public FileSelector(string message, string default_path, string default_filename)
            : this(message, default_path, default_filename, (string)null, "*", 0, null, Window.wxDefaultPosition) { }

        /// <summary>
        /// Selects a file displaying the provided message.
        /// </summary>
        /// <param name="message">Message string</param>
        /// <param name="default_path">Displays files in this path first</param>
        /// <param name="default_filename">The default filename</param>
        /// <param name="default_extension">The default extension of the searched files</param>
        public FileSelector(string message, string default_path, string default_filename, string default_extension)
            : this(message, default_path, default_filename, default_extension, "*", 0, null, Window.wxDefaultPosition) { }

        /// <summary>
        /// Selects a file displaying the provided message.
        /// </summary>
        /// <param name="message">Message string</param>
        /// <param name="default_path">Displays files in this path first</param>
        /// <param name="default_filename">The default filename</param>
        /// <param name="default_extension">The default extension of the searched files</param>
        /// <param name="wildcard">Determines which files will be displayed. Example: <c>"BMP files (*.bmp)|*.bmp|GIF files (*.gif)|*.gif"</c>.</param>
        public FileSelector(string message, string default_path, string default_filename, string default_extension, string wildcard)
            : this(message, default_path, default_filename, default_extension, wildcard, 0, null, Window.wxDefaultPosition) { }

        /// <summary>
        /// Selects a file displaying the provided message.
        /// </summary>
        /// <param name="message">Message string</param>
        /// <param name="default_path">Displays files in this path first</param>
        /// <param name="default_filename">The default filename</param>
        /// <param name="default_extension">The default extension of the searched files</param>
        /// <param name="wildcard">Determines which files will be displayed. Example: <c>"BMP files (*.bmp)|*.bmp|GIF files (*.gif)|*.gif"</c>.</param>
        /// <param name="flags">The window styles</param>
        public FileSelector(string message, string default_path, string default_filename, string default_extension, string wildcard, wx.WindowStyles flags)
            : this(message, default_path, default_filename, default_extension, wildcard, flags, null, Window.wxDefaultPosition) { }

        /// <summary>
        /// Selects a file displaying the provided message.
        /// </summary>
        /// <param name="message">Message string</param>
        /// <param name="default_path">Displays files in this path first</param>
        /// <param name="default_filename">The default filename</param>
        /// <param name="default_extension">The default extension of the searched files</param>
        /// <param name="wildcard">Determines which files will be displayed. Example: <c>"BMP files (*.bmp)|*.bmp|GIF files (*.gif)|*.gif"</c>.</param>
        /// <param name="flags">The window styles</param>
        /// <param name="parent">The parent window</param>
        public FileSelector(string message, string default_path, string default_filename, string default_extension, string wildcard, wx.WindowStyles flags, Window parent)
			: this(message, default_path, default_filename, default_extension, wildcard, flags, parent, Window.wxDefaultPosition) {}

        /// <summary>
        /// Selects a file displaying the provided message.
        /// </summary>
        /// <param name="message">Message string</param>
        /// <param name="default_path">Displays files in this path first</param>
        /// <param name="default_filename">The default filename</param>
        /// <param name="default_extension">The default extension of the searched files</param>
        /// <param name="wildcard">Determines which files will be displayed. Example: <c>"BMP files (*.bmp)|*.bmp|GIF files (*.gif)|*.gif"</c>.</param>
        /// <param name="flags">The window styles</param>
        /// <param name="parent">The parent window</param>
        /// <param name="position">The position of this dialog</param>
        public FileSelector(string message, string default_path, string default_filename, string default_extension, string wildcard, wx.WindowStyles flags, Window parent, Point position)
            : this(new wxString(message), new wxString(default_path), new wxString(default_filename), new wxString(default_extension), new wxString(wildcard), flags, parent, position.X, position.Y)
        {
        }

        /// <summary>
        /// Selects a file displaying the provided message.
        /// </summary>
        /// <param name="message">Message string</param>
        /// <param name="default_path">Displays files in this path first</param>
        /// <param name="default_filename">The default filename</param>
        /// <param name="default_extension">The default extension of the searched files</param>
        /// <param name="wildcard">Determines which files will be displayed. Example: <c>"BMP files (*.bmp)|*.bmp|GIF files (*.gif)|*.gif"</c>.</param>
        /// <param name="flags">The window styles</param>
        /// <param name="parent">The parent window</param>
        /// <param name="x">The x-coordinate of this dialog</param>
        /// <param name="y">The y-coordinate of this dialog</param>
        public FileSelector(wxString message, wxString default_path, wxString default_filename, wxString default_extension, wxString wildcard, wx.WindowStyles flags, Window parent, int x, int y)
		{
			value = new wxString(wxGlobal_FileSelector(message.wxObject, default_path.wxObject, default_filename.wxObject, default_extension.wxObject, wildcard.wxObject, (uint)flags, Object.SafePtr(parent), x, y), true);
		}
		
		//---------------------------------------------------------------------

        /// <summary>
        /// the selected file or the empty string if the user cancelled the input.
        /// This, use something like the following to deal with cancelations.
        /// <code>
        /// string result=fileselector.Value;
        /// if (result.Length == 0)
        ///     return; // cancelled input.
        /// </code>
        /// </summary>
        public string Value
        {
            get
            {
                return this.value;
            }
        }

		public static implicit operator string(FileSelector f)
		{
			return f.value;
		}

        /// <summary>
        /// Returns a file that has been selected by the user.
        /// </summary>
        /// <param name="message">Message string</param>
        /// <param name="default_path">Displays files in this path first</param>
        /// <param name="default_filename">The default filename</param>
        /// <param name="default_extension">The default extension of the searched files</param>
        /// <param name="wildcard">Determines which files will be displayed. Example: <c>"BMP files (*.bmp)|*.bmp|GIF files (*.gif)|*.gif"</c>.</param>
        /// <returns>The path to the selected file. The result will be empty if the user cancelled the dialog.</returns>
        public static string ShowModal(string message, string default_path, string default_filename, string default_extension, string wildcard)
        {
            return ShowModal(message, default_extension, default_filename, default_extension, wildcard, wx.WindowStyles.NO_STYLE, null, Window.wxDefaultPosition);
        }

        /// <summary>
        /// Returns a file that has been selected by the user.
        /// </summary>
        /// <param name="message">Message string</param>
        /// <param name="default_path">Displays files in this path first</param>
        /// <param name="default_filename">The default filename</param>
        /// <param name="default_extension">The default extension of the searched files</param>
        /// <param name="wildcard">Determines which files will be displayed. Example: <c>"BMP files (*.bmp)|*.bmp|GIF files (*.gif)|*.gif"</c>.</param>
        /// <param name="flags">The window styles</param>
        /// <returns>The path to the selected file. The result will be empty if the user cancelled the dialog.</returns>
        public static string ShowModal(string message, string default_path, string default_filename, string default_extension, string wildcard, wx.WindowStyles flags)
        {
            return ShowModal(message, default_extension, default_filename, default_extension, wildcard, flags, null, Window.wxDefaultPosition);
        }

        /// <summary>
        /// Returns a file that has been selected by the user.
        /// </summary>
        /// <param name="message">Message string</param>
        /// <param name="default_path">Displays files in this path first</param>
        /// <param name="default_filename">The default filename</param>
        /// <param name="default_extension">The default extension of the searched files</param>
        /// <param name="wildcard">Determines which files will be displayed. Example: <c>"BMP files (*.bmp)|*.bmp|GIF files (*.gif)|*.gif"</c>.</param>
        /// <param name="flags">The window styles</param>
        /// <param name="parent">The parent window</param>
        /// <returns>The path to the selected file. The result will be empty if the user cancelled the dialog.</returns>
        public static string ShowModal(string message, string default_path, string default_filename, string default_extension, string wildcard, wx.WindowStyles flags, Window parent)
        {
            return ShowModal(message, default_extension, default_filename, default_extension, wildcard, flags, parent, Window.wxDefaultPosition);
        }

        /// <summary>
        /// Returns a file that has been selected by the user.
        /// </summary>
        /// <param name="message">Message string</param>
        /// <param name="default_path">Displays files in this path first</param>
        /// <param name="default_filename">The default filename</param>
        /// <param name="default_extension">The default extension of the searched files</param>
        /// <param name="wildcard">Determines which files will be displayed. Example: <c>"BMP files (*.bmp)|*.bmp|GIF files (*.gif)|*.gif"</c>.</param>
        /// <param name="flags">The window styles</param>
        /// <param name="parent">The parent window</param>
        /// <param name="position">The position of this dialog</param>
        /// <returns>The path to the selected file. The result will be empty if the user cancelled the dialog.</returns>
        public static string ShowModal(string message, string default_path, string default_filename, string default_extension, string wildcard, wx.WindowStyles flags, Window parent, Point position)
        {
            FileSelector dialog = new FileSelector(message, default_path, default_path, default_extension, wildcard, flags, parent, position);
            return dialog.Value;
        }
	}
	
	//---------------------------------------------------------------------

    /** <summary>This is an internal class representing a byte buffer.
     * This class is applied sometimes when <c>wxWidgets</c> expects a void* buffer.
     *</summary>*/
    internal class ByteBuffer : wx.Object
    {
        #region C API
        [DllImport("wx-c")]
        static extern IntPtr ByteBuffer_ctor(int sizeReserved);
        [DllImport("wx-c")]
        [return: MarshalAs(UnmanagedType.U1)]
        static extern byte ByteBuffer_at(IntPtr self, int index);
        [DllImport("wx-c")]
        static extern void ByteBuffer_atSet(IntPtr self, int index, [MarshalAs(UnmanagedType.U1)] byte val);
        [DllImport("wx-c")]
        static extern int ByteBuffer_reserved(IntPtr self);
        [DllImport("wx-c")]
        static extern int ByteBuffer_filled(IntPtr self);
        [DllImport("wx-c")]
        static extern IntPtr ByteBuffer_ptrToBuffer(IntPtr self);
        #endregion

        #region CTor
        static IntPtr SyncCTor(int size)
        {
            lock (DllSync)
            {
                return ByteBuffer_ctor(size);
            }
        }

        /** <summary>Generates an instance capable of holding at most <c>size</c> bytes.
         * </summary>
         */
        public ByteBuffer(int size)
            : base(SyncCTor(size), StorageMode.VolatileObject, true)
        {
        }
        /** <summary>This is a CTor where callers can set memOwn. 
         * This is for the construction of temporarily needed wrappers.
         * </summary>
         */
        internal ByteBuffer(IntPtr cInstance, StorageMode mode, bool memOwn)
            : base(cInstance, mode, memOwn)
        {
        }

        /** <summary>Creates an instance copying the data from <c>bytes</c> or resturns <c>null</c> in case of argument <c>null</c>.
         * </summary>
         */
        public static ByteBuffer SafeNew(byte[] bytes)
        {
            if (bytes == null)
                return null;
            ByteBuffer result = new ByteBuffer(bytes.Length);
            for (int i = 0; i < bytes.Length; ++i)
                result[i] = bytes[i];
            return result;
        }
        #endregion

        public override void Dispose()
        {
            base.Dispose();
        }

        #region Properties
        /** <summary>Generates the filled byte at the provided index or 0 if the index is too large.</summary>*/
        public byte this[int index]
        {
            get
            {
                return ByteBuffer_at(this.wxObject, index);
            }
            set
            {
                ByteBuffer_atSet(this.wxObject, index, value);
            }
        }
        /** <summary>This is the number of bytes that can be stored within this index.</summary>*/
        public int SizeReserved { get { return ByteBuffer_reserved(this.wxObject); } }
        /** <summary>This is the number of bytes that have been written into this instance.</summary>*/
        public int SizeFilled { get { return ByteBuffer_filled(this.wxObject); } }

        /** <summary>Returns a pointer to the internally represented <c>char</c>[] buffer.
         * Please note, that this buffer is not terminated by a 0.</summary>*/
        public IntPtr PtrToBuffer { get { return ByteBuffer_ptrToBuffer(this.wxObject); } }
        #endregion

        public override string ToString()
        {
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            sb.AppendFormat("ByteArray[{0}]={1}", this.SizeReserved, '{');
            for (int i = 0; i < this.SizeFilled; ++i)
                sb.AppendFormat(" {0}", this[i]);
            sb.Append(" }");
            return sb.ToString();
        }
    }

    /** <summary>Wrapper around the  wxWidgets array of integer numbers.</summary>*/
	public class ArrayInt : Object
	{
		[DllImport("wx-c")] static extern IntPtr wxArrayInt_ctor();
		[DllImport("wx-c")] static extern void   wxArrayInt_dtor(IntPtr self);
		[DllImport("wx-c")] static extern void   wxArrayInt_Add(IntPtr self, int toadd);
		[DllImport("wx-c")] static extern int    wxArrayInt_Item(IntPtr self, int num);
		[DllImport("wx-c")] static extern int    wxArrayInt_GetCount(IntPtr self);
		
		//---------------------------------------------------------------------

		public ArrayInt(IntPtr wxObject)
			: base(wxObject)
		{
			this.wxObject = wxObject;
		}
			
		internal ArrayInt(IntPtr wxObject, bool memOwn)
			: base(wxObject)
		{
			this.memOwn = memOwn;
			this.wxObject = wxObject;
		}

		public ArrayInt()
			: this(wxArrayInt_ctor(), true) 
		{
		}

        /** <summary>Creates a new ArrayInt. However, if <c>ptr</c> is <c>IntPtr.Zer</c>, then the result is <c>null</c>.</summary>*/
        internal static ArrayInt SafeNew(IntPtr ptr)
        {
            if (ptr == IntPtr.Zero)
                return null;
            else
                return new ArrayInt(ptr, true);
        }

		//---------------------------------------------------------------------

		public static implicit operator int[] (ArrayInt ari)
		{
			int[] tmpi = new int[ari.Count];
			for (int i = 0; i < ari.Count; i++)
				tmpi[i] = ari.Item(i);
			return tmpi;
		}

		public void Add(int toadd)
		{
			wxArrayInt_Add(wxObject, toadd);
		}

		public int Item(int num)
		{
			return wxArrayInt_Item(wxObject, num);
		}

		public int Count
		{
			get { return wxArrayInt_GetCount(wxObject); }
		}
                
		//---------------------------------------------------------------------

		public override void Dispose()
		{
			if (!disposed)
			{
                if (wxObject != IntPtr.Zero)
				{
					if (memOwn)
					{
						wxArrayInt_dtor(wxObject);
					}
				}
				RemoveObject(wxObject);
				wxObject = IntPtr.Zero;
                --validInstancesCount;
                disposed = true;
			}
			
			virtual_Dispose = null;
			base.Dispose();
			GC.SuppressFinalize(this);
		}
		
		//---------------------------------------------------------------------
		
		~ArrayInt() 
		{
			Dispose();
		}
	}
	
	//---------------------------------------------------------------------

    /** <summary>This is a wrapper for a simple <c>void**</c> array.
     * This will be used for instance to pass client data to choice dialogs.</summary>*/
    internal class ArrayIntPtr : IDisposable
    {
        #region C API
        [DllImport("wx-c")]
        static extern IntPtr wxArrayIntPtr_ctor(int length);
        [DllImport("wx-c")]
        static extern void wxArrayIntPtr_dtor(IntPtr self);
        [DllImport("wx-c")]
        static extern void wxArrayIntPtr_Set(IntPtr self, int pos, IntPtr value);
        [DllImport("wx-c")]
        static extern IntPtr wxArrayIntPtr_Get(IntPtr self, int pos);
        #endregion
        #region State
        IntPtr _cptr;
        int _lenght;
        #endregion
        #region CTor
        public ArrayIntPtr(int length)
        {
            this._lenght = length;
            this._cptr = wxArrayIntPtr_ctor(length);
        }
        #endregion

        #region IDisposable Member
        public void  Dispose()
        {
            if (this._cptr != IntPtr.Zero)
            {
                wxArrayIntPtr_dtor(this._cptr);
            }
            GC.SuppressFinalize(this);
        }
        #endregion

        #region Public Properties
        public IntPtr this[int pos]
        {
            get
            {
                if (pos >= 0 && pos < this._lenght)
                    return wxArrayIntPtr_Get(this._cptr, pos);
                else
                    return IntPtr.Zero;
            }
            set
            {
                if (pos >= 0 && pos < this._lenght)
                    wxArrayIntPtr_Set(this._cptr, pos, value);
            }
        }
        public int Length { get { return this._lenght; } }
        #endregion

        #region Safe Creation
        public static ArrayIntPtr SafeNewFrom(ClientData[] data)
        {
            if (data == null || data.Length == 0)
                return null;
            ArrayIntPtr result = new ArrayIntPtr(data.Length);
            for (int pos = 0; pos < data.Length; ++pos)
            {
                result[pos] = Object.SafePtr(data[pos]);
            }
            return result;
        }

        public static IntPtr SafePtr(ArrayIntPtr obj)
        {
            if (obj == null)
                return IntPtr.Zero;
            return obj._cptr;
        }
        #endregion
    }

    /** <summary>A wrapper for  wxWidgets arrays of string.
     * This is used for internal purposes. However, just like wxString this has been
     * left public to allow extreme non-functional optimizations reducing conversions
     * between arrays of .NET strings and this.</summary>*/
    public class ArrayString : Object
	{
		[DllImport("wx-c")] static extern IntPtr wxArrayString_ctor();
		[DllImport("wx-c")] static extern void   wxArrayString_dtor(IntPtr self);
		[DllImport("wx-c")] static extern void   wxArrayString_Add(IntPtr self, IntPtr toadd);
		[DllImport("wx-c")] static extern IntPtr wxArrayString_Item(IntPtr self, int num);
		[DllImport("wx-c")] static extern int    wxArrayString_GetCount(IntPtr self);
        [DllImport("wx-c")] static extern void   wxArrayString_Clear(IntPtr self);
        [DllImport("wx-c")] static extern void   wxArrayString_Sort(IntPtr self, [MarshalAs(UnmanagedType.U1)] bool reversed);
        [DllImport("wx-c")] static extern int    wxArrayString_Index(IntPtr self, IntPtr sz, [MarshalAs(UnmanagedType.U1)] bool bCase, [MarshalAs(UnmanagedType.U1)] bool bFromEnd);
        [DllImport("wx-c")] static extern void wxArrayString_RemoveAt(IntPtr self, int pos);
        [DllImport("wx-c")] static extern void wxArrayString_Remove(IntPtr self, IntPtr sz);
		
		//---------------------------------------------------------------------

		public ArrayString(IntPtr wxObject)
			: base(wxObject)
		{
			this.wxObject = wxObject;
		}
			
		internal ArrayString(IntPtr wxObject, bool memOwn)
			: base(wxObject)
		{
			this.memOwn = memOwn;
			this.wxObject = wxObject;
		}

		public ArrayString()
			: this(wxArrayString_ctor(), true) 
		{
		}

        /** <summary>Generates an instance comprising the items of the argument.
         * All items of the argument shall be strings. Otherwise, this method
         * will throw an dynamic type error.
         * The argument may also be <c>null</c>. In this case, this is equivalent to
         * the default constructor (generate an instance of size 0).</summary>*/
        public ArrayString(IEnumerable elems)
            : this(wxArrayString_ctor(), true)
        {
            if (elems != null)
                foreach(string elem in elems) this.Add(elem);
        }

        /** <summary>This is a safe alternative for the corresponding CTor.
         * Safe means here: If the argument is <c>null</c>, the result is also <c>null</c> without
         * any exceptions.</summary>*/
        public static ArrayString SafeNewFrom(IEnumerable elems)
        {
            if (elems == null)
                return null;
            else
                return new ArrayString(elems);
        }

        //---------------------------------------------------------------------

        public void Clear()
        {
            wxArrayString_Clear(this.wxObject);
        }

        public void RemoveAt(int pos)
        {
            wxArrayString_RemoveAt(this.wxObject, pos);
        }

        public void Remove(string what)
        {
            this.Remove(new wxString(what));
        }

        public void Remove(wxString what)
        {
            wxArrayString_Remove(this.wxObject, what.wxObject);
        }

		//---------------------------------------------------------------------

        public void Sort()
        {
            this.Sort(false);
        }
        /** <summary>Sorts the entry (optionally in reversed order).
         *</summary>*/
        public void Sort(bool reversed)
        {
            wxArrayString_Sort(this.wxObject, reversed);
        }
		//---------------------------------------------------------------------

        public string[] ToArray()
        {
            string[] tmps = new string[this.Count];
            for (int i = 0; i < this.Count; i++)
                tmps[i] = this[i];
            return tmps;
        }

		public static implicit operator string[] (ArrayString ars)
		{
			return ars.ToArray();
		}

        /** <summary>Access string <c>num</c> of the array.
         * Will cause an assert error on illegal indices.
         *</summary>*/
        public string this[int num]
        {
            get
            {
                return new wxString(wxArrayString_Item(wxObject, num), true);
            }
        }

        /** <summary>This will add the elements of the collection.
         * This will throw an exception of the collection contains non-strings.
         *</summary>*/
        public void Add(IEnumerable toadd)
        {
            foreach (string elem in toadd)
                this.Add(elem);
        }

		public void Add(string toadd)
        {
            this.Add(new wxString(toadd));
        }
		public void Add(wxString toadd)
		{
			wxArrayString_Add(wxObject, Object.SafePtr(toadd));
		}

		public int Count
		{
			get { return wxArrayString_GetCount(wxObject); }
		}

        //---------------------------------------------------------------------

        /** <summary>This will return the first index of string <c>lookForThisEntry</c> or -1 is this string is not in the array.</summary>*/
        public int Index(string lookForThisEntry)
        {
            return this.Index(new wxString(lookForThisEntry), true, false);
        }

        public int Index(string lookForThisEntry, bool bCase)
        {
            return this.Index(new wxString(lookForThisEntry), bCase, false);
        }

        public int Index(string lookForThisEntry, bool bCase, bool bFromEnd)
        {
            return this.Index(new wxString(lookForThisEntry), bCase, bFromEnd);
        }

        /** <summary>Search the element in the array, starting from the beginning if <c>bFromEnd</c> is false or from end otherwise.
         * If <c>bCase</c>, comparison is case sensitive (default), otherwise the case is ignored.
         *
         * This function uses linear search for <c>ArrayString</c> and binary search for <c>SortedArrayString</c>,
         * but it ignores the <c>bCase</c> and <c>bFromEnd</c> parameters in the latter case.
         *
         * Returns index of the first item matched or -1 if there is no match.
         *</summary>*/
        public int Index(wxString lookForThisEntry, bool bCase, bool bFromEnd)
        {
            return wxArrayString_Index(this.wxObject, lookForThisEntry.wxObject, bCase, bFromEnd);
        }

        //---------------------------------------------------------------------

		public override void Dispose()
		{
			if (!disposed)
			{
                if (wxObject != IntPtr.Zero)
				{
					if (memOwn)
					{
						wxArrayString_dtor(wxObject);
					}
				}
				RemoveObject(wxObject);
				wxObject = IntPtr.Zero;
                --validInstancesCount;
                disposed = true;
			}
			
			base.Dispose();
			GC.SuppressFinalize(this);
		}
		
		//---------------------------------------------------------------------
		
		~ArrayString() 
		{
			Dispose();
		}
	}
	
	//---------------------------------------------------------------------
	
    /** <summary>This will produce or wrap a <c>wxSize</c> object.
     * Use instances of this class, to pass <c>wxSize</c> objects to the C DLL.</summary>*/
	public class wxSize : Object
	{
		[DllImport("wx-c")] static extern IntPtr wxSize_ctor(int x, int y);
		[DllImport("wx-c")] static extern void   wxSize_dtor(IntPtr self);
		[DllImport("wx-c")] static extern void   wxSize_SetWidth(IntPtr self, int w);
		[DllImport("wx-c")] static extern void   wxSize_SetHeight(IntPtr self, int h);
		[DllImport("wx-c")] static extern int    wxSize_GetWidth(IntPtr self);
		[DllImport("wx-c")] static extern int    wxSize_GetHeight(IntPtr self);

		//---------------------------------------------------------------------

		public wxSize(IntPtr wxObject)
            : base(wxObject, StorageMode.VolatileObject)
		{ 
			this.wxObject = wxObject;
		}
		
		internal wxSize(IntPtr wxObject, bool memOwn)
            : base(wxObject, StorageMode.VolatileObject, memOwn)
		{ 
			this.wxObject = wxObject;
		}
			
		public wxSize()
			: this(0,0) {}

        /** <summary>Convert an instance from a C# standard size.
         * This will throw an exception on a <c>null</c> argument. You may use SafeNew() instead.</summary>*/
        public wxSize(Size s)
			: this(s.Width, s.Height) {}

		public wxSize(int x, int y)
			: this(wxSize_ctor(x, y), true) { }

        /** <summary>This will generate an instance from a C# standard rectangle without throwing exception on a <c>null</c> argument.
         * In that case this will also return a <c>null</c>.</summary>*/
        public static wxSize SafeNew(Size size)
        {
            return new wxSize(size);
        }


		//---------------------------------------------------------------------

		public static implicit operator Size (wxSize size)
		{
			Size nsize = new Size();
			nsize.Width = size.Width;
			nsize.Height = size.Height;
			return nsize;
		}
		
		public int Width
		{
			get { return wxSize_GetWidth(wxObject); }
			set { wxSize_SetWidth(wxObject, value); }
		}
		
		public int Height
		{
			get { return wxSize_GetHeight(wxObject); }
			set { wxSize_SetHeight(wxObject, value); }
		}		
		
		//---------------------------------------------------------------------
				
		public override void Dispose()
		{
			if (!disposed)
			{
                if (wxObject != IntPtr.Zero)
				{
					if (memOwn)
					{
						wxSize_dtor(wxObject);
						memOwn = false;
					}
				}
				RemoveObject(wxObject);
				wxObject = IntPtr.Zero;
                --validInstancesCount;
                disposed = true;
			}
			
			base.Dispose();
			GC.SuppressFinalize(this);
		}
		
		//---------------------------------------------------------------------
		
		~wxSize() 
		{
			Dispose();
		}
	}

	//---------------------------------------------------------------------
	
    /** <summary>This will produce or wrap instances of  wxWidgets <c>wxRect</c>.
     * Never use <c>System.Drawing.Rectangle</c> with <c>wx-c.dll</c>. Always rely to instances of this class instead.
     * </summary>
     */
	public class wxRect : Object
	{
		[DllImport("wx-c")] static extern IntPtr wxRect_ctor(int x, int y, int w, int h);
		[DllImport("wx-c")] static extern void   wxRect_dtor(IntPtr self);
		[DllImport("wx-c")] static extern void   wxRect_RegisterDisposable(IntPtr self, Virtual_Dispose onDispose);
		[DllImport("wx-c")] static extern int    wxRect_GetX(IntPtr self);
		[DllImport("wx-c")] static extern void   wxRect_SetX(IntPtr self, int x);
		[DllImport("wx-c")] static extern int    wxRect_GetY(IntPtr self);
		[DllImport("wx-c")] static extern void   wxRect_SetY(IntPtr self, int y);
		[DllImport("wx-c")] static extern int    wxRect_GetWidth(IntPtr self);
		[DllImport("wx-c")] static extern void   wxRect_SetWidth(IntPtr self, int w);
		[DllImport("wx-c")] static extern int    wxRect_GetHeight(IntPtr self);
		[DllImport("wx-c")] static extern void   wxRect_SetHeight(IntPtr self, int h);
		
		//---------------------------------------------------------------------

		public wxRect(IntPtr wxObject)
			: base(wxObject, StorageMode.VolatileObject)
		{ 
			this.wxObject = wxObject;
		}
		
		internal wxRect(IntPtr wxObject, bool memOwn)
            : base(wxObject, StorageMode.VolatileObject)
		{ 
			this.memOwn = memOwn;
			this.wxObject = wxObject;
		}
			
		public wxRect()
			: this(0,0,0,0) {}
			
        /** <summary>Convert an instance from a C# standard rectangle.
         * This will throw an exception on a <c>null</c> argument. You may use SafeNew() instead.</summary>*/
		public wxRect(Rectangle r)
			: this(r.X, r.Y, r.Width, r.Height) {}

		public wxRect(int x, int y, int w, int h)
			: this(wxRect_ctor(x, y, w, h), true) 
		{ 
			virtual_Dispose = new Virtual_Dispose(VirtualDispose);
			wxRect_RegisterDisposable(wxObject, virtual_Dispose);
		}

        /** <summary>This will generate an instance from a C# standard rectangle without throwing exception on a <c>null</c> argument.
         * In that case this will also return a <c>null</c>.</summary>*/
        public static wxRect SafeNew(Rectangle rect)
        {
            return new wxRect(rect);
        }

		//---------------------------------------------------------------------

		public static implicit operator Rectangle (wxRect rect)
		{
			Rectangle nrect = new Rectangle();
			nrect.X = rect.X;
			nrect.Y = rect.Y;
			nrect.Width = rect.Width;
			nrect.Height = rect.Height;
			return nrect;
		}
		
		public int X
		{
			get { return wxRect_GetX(wxObject); }
			set { wxRect_SetX(wxObject, value); }
		}
		
		public int Y
		{
			get { return wxRect_GetY(wxObject); }
			set { wxRect_SetY(wxObject, value); }
		}		
		
		public int Width
		{
			get { return wxRect_GetWidth(wxObject); }
			set { wxRect_SetWidth(wxObject, value); }
		}
		
		public int Height
		{
			get { return wxRect_GetHeight(wxObject); }
			set { wxRect_SetHeight(wxObject, value); }
		}		
		
		//---------------------------------------------------------------------
				
		public override void Dispose()
		{
			if (!disposed)
			{
				if (wxObject != IntPtr.Zero)
				{
					if (memOwn)
					{
						wxRect_dtor(wxObject);
						memOwn = false;
					}
				}
				RemoveObject(wxObject);
				wxObject = IntPtr.Zero;
                --validInstancesCount;
                disposed = true;
			}
			
			base.Dispose();
			GC.SuppressFinalize(this);
		}
		
		//---------------------------------------------------------------------
		
		~wxRect() 
		{
			Dispose();
		}
	}


    /** <summary>This will produce or wrap instances of  wxWidgets <c>wxPoint</c>.
     * Never use <c>System.Drawing.Point</c> with <c>wx-c.dll</c>. Always rely to instances of this class instead.
     * </summary>
     */
    public class wxPoint : Object
    {
        #region C API
        [DllImport("wx-c")]
        static extern IntPtr wxPoint_ctor(int x, int y);
        [DllImport("wx-c")]
        static extern int wxPoint_GetX(IntPtr self);
        [DllImport("wx-c")]
        static extern void wxPoint_SetX(IntPtr self, int x);
        [DllImport("wx-c")]
        static extern int wxPoint_GetY(IntPtr self);
        [DllImport("wx-c")]
        static extern void wxPoint_SetY(IntPtr self, int y);
        #endregion

        #region CTor
        public wxPoint()
            : this(-1, -1)
        {
        }

        public wxPoint(int x, int y)
            : base(wxPoint_ctor(x, y), StorageMode.VolatileObject)
        {
        }

        /** <summary>Convert an instance from a C# standard rectangle.
         * This will throw an exception on a <c>null</c> argument. You may use SafeNew() instead.</summary>*/
        public wxPoint(Point point)
            : this(point.X, point.Y)
        {
        }

        public wxPoint(IntPtr wxObject)
            : base(wxObject, StorageMode.VolatileObject)
        {
        }

        /** <summary>This will generate an instance from a C# standard rectangle without throwing exception on a <c>null</c> argument.
         * In that case this will also return a <c>null</c>.</summary>*/
        public static wxPoint SafeNew(Point point)
        {
            return new wxPoint(point);
        }
        #endregion

        public static implicit operator Point(wxPoint point)
        {
            return new Point(point.X, point.Y);
        }

        #region Public Properties
        public int X
        {
            get
            {
                return wxPoint_GetX(this.wxObject);
            }
            set
            {
                wxPoint_SetX(this.wxObject, value);
            }
        }
        public int Y
        {
            get
            {
                return wxPoint_GetY(this.wxObject);
            }
            set
            {
                wxPoint_SetY(this.wxObject, value);
            }
        }
        #endregion
    }
}
