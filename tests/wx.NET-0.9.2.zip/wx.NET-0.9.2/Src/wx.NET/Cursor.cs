//-----------------------------------------------------------------------------
// wx.NET - Cursor.cs
//
// The wxCursor wrapper class.
//
// Written by Jason Perkins (jason@379.com)
// (C) 2003 by 379, Inc.
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: Cursor.cs,v 1.8 2009/11/04 18:15:40 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Runtime.InteropServices;

namespace wx
{
	public enum StockCursor
	{
		wxCURSOR_NONE,
		wxCURSOR_ARROW,
		wxCURSOR_RIGHT_ARROW,
		wxCURSOR_BULLSEYE,
		wxCURSOR_CHAR,
		wxCURSOR_CROSS,
		wxCURSOR_HAND,
		wxCURSOR_IBEAM,
		wxCURSOR_LEFT_BUTTON,
		wxCURSOR_MAGNIFIER,
		wxCURSOR_MIDDLE_BUTTON,
		wxCURSOR_NO_ENTRY,
		wxCURSOR_PAINT_BRUSH,
		wxCURSOR_PENCIL,
		wxCURSOR_POINT_LEFT,
		wxCURSOR_POINT_RIGHT,
		wxCURSOR_QUESTION_ARROW,
		wxCURSOR_RIGHT_BUTTON,
		wxCURSOR_SIZENESW,
		wxCURSOR_SIZENS,
		wxCURSOR_SIZENWSE,
		wxCURSOR_SIZEWE,
		wxCURSOR_SIZING,
		wxCURSOR_SPRAYCAN,
		wxCURSOR_WAIT,
		wxCURSOR_WATCH,
		wxCURSOR_BLANK,
		wxCURSOR_ARROWWAIT,
	}

    /// <summary>
    /// A cursor is a small bitmap usually used for denoting where the mouse pointer is, with a picture that
    /// might indicate the interpretation of a mouse click. As with icons, cursors in X and MS Windows are
    /// created in a different manner. Therefore, separate cursors will be created for the different
    /// environments. Platform-specific methods for creating a wxCursor object are catered for, and this
    /// is an occasion where conditional compilation will probably be required (see wxIcon for an example).
    /// </summary>
    /// <remarks>
    /// A single cursor object may be used in many windows (any subwindow type). The wx.NET convention is to
    /// set the cursor for a window, as in X, rather than to set it globally as in MS Windows.
    /// </remarks>
	public class Cursor : Bitmap
	{
		[DllImport("wx-c")] static extern IntPtr wxCursor_ctorById(StockCursor id);
		[DllImport("wx-c")] static extern IntPtr wxCursor_ctorImage(IntPtr image);
		[DllImport("wx-c")] static extern IntPtr wxCursor_ctorCopy(IntPtr cursor);

		[DllImport("wx-c")] static extern bool   wxCursor_Ok(IntPtr self);
		
		[DllImport("wx-c")] static extern void   wxCursor_SetCursor(IntPtr cursor);

		//---------------------------------------------------------------------

        /// <summary>
        /// A CTor that creates a <c>null</c> if the arg is a IntPtr.Zero.
        /// </summary>
        /// <param name="arg">Native cursor pointer.</param>
        internal static Cursor SafeNew(IntPtr arg)
        {
            if (arg == IntPtr.Zero)
                return null;
            else
                return new Cursor(arg);
        }

		public Cursor(IntPtr wxObject)
			: base(wxObject) {}

        static IntPtr LockedCTor(StockCursor id)
        {
            lock (DllSync)
            {
                return wxCursor_ctorById(id);
            }
        }

		public Cursor(StockCursor id)
			: base(LockedCTor(id))
		{
		}

        static IntPtr LockedCTorByImage(Image image)
        {
            lock (DllSync)
            {
                return wxCursor_ctorImage(Object.SafePtr(image));
            }
        }

		public Cursor(Image image)
			: base(LockedCTorByImage(image))
		{
		}

        static IntPtr LockedCTor(Cursor cursor)
        {
            lock (DllSync)
            {
                return wxCursor_ctorCopy(Object.SafePtr(cursor));
            }
        }

		public Cursor(Cursor cursor)
			: base(LockedCTor(cursor))
		{
		}

		//---------------------------------------------------------------------

		public override bool Ok()
		{
			return wxCursor_Ok(wxObject);
		}

		//---------------------------------------------------------------------
		
		public static void SetCursor(Cursor cursor)
		{
			wxCursor_SetCursor(Object.SafePtr(cursor));
		}
	}
}
