//-----------------------------------------------------------------------------
// wx.NET - ActivateEvent.cs
//
// The wxActivateEvent wrapper class.
//
// Written by Alexander Olk (xenomorph2@onlinehome.de)
// (C) 2004 by Alexander Olk
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// ActivateEvent.cs,v 1.3 2004/10/16 18:23:46 olkalex Exp
//-----------------------------------------------------------------------------

using System;
using System.Runtime.InteropServices;

namespace wx
{
	public class ActivateEvent : Event
	{
		[DllImport("wx-c")] static extern IntPtr wxActivateEvent_ctor(int type);
		[DllImport("wx-c")] static extern bool wxActivateEvent_GetActive(IntPtr self);
		
		//-----------------------------------------------------------------------------

		public ActivateEvent(IntPtr wxObject) 
			: base(wxObject)
        {
        }

        static IntPtr LockedCTor(int type)
        {
            lock (DllSync)
            {
                return wxActivateEvent_ctor(type);
            }
        }

		public ActivateEvent(int type)
			: this(LockedCTor(type)) { }

		//-----------------------------------------------------------------------------	
		
		public bool Active
		{
			get { return wxActivateEvent_GetActive(wxObject); }
		}
	}
}
