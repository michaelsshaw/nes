//-----------------------------------------------------------------------------
// wx.NET - Notebook.cs
//
// The wxNotebook wrapper class.
//
// Written by Jason Perkins (jason@379.com)
// (C) 2003 by 379, Inc.
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: Notebook.cs,v 1.25 2010/01/24 13:44:49 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Drawing;
using System.Runtime.InteropServices;

namespace wx
{
    /** <summary>This event will be raised on selecting tabs in notebooks.</summary>*/
	public class NotebookEvent : NotifyEvent
	{
		[DllImport("wx-c")] static extern IntPtr wxNotebookEvent_ctor(int commandType, int id, int nSel, int nOldSel);
		[DllImport("wx-c")] static extern int    wxNotebookEvent_GetSelection(IntPtr self);
		[DllImport("wx-c")] static extern void   wxNotebookEvent_SetSelection(IntPtr self, int nSel);
		[DllImport("wx-c")] static extern int    wxNotebookEvent_GetOldSelection(IntPtr self);
		[DllImport("wx-c")] static extern void   wxNotebookEvent_SetOldSelection(IntPtr self, int nOldSel);

		//-----------------------------------------------------------------------------

		public NotebookEvent(IntPtr wxObject)
			: base(wxObject) { }

		public NotebookEvent(int commandType, int id, int nSel, int nOldSel)
			: base(wxNotebookEvent_ctor(commandType, id, nSel, nOldSel)) { }

		//-----------------------------------------------------------------------------


        /** <summary>Returns the currently selected page, or -1 if none was selected.
         * NB: under Windows, <c>Selection</c> will return the same value as <c>OldSelection</c> when called from
         * <c>EVT_NOTEBOOK_PAGE_CHANGING</c> handler and not the page which is going to be selected.
         * Also note that the values of selection and old selection returned for an event generated in
         * response to a call to wx.Notebook.SetSelection shouldn't be trusted as they are currently inconsistent
         * under different platforms (but in this case you presumably don't need them anyhow as you already
         * have the corresponding information).</summary>*/
		public int Selection
		{
			get { return wxNotebookEvent_GetSelection(wxObject); }
			set { wxNotebookEvent_SetSelection(wxObject, value); }
		}

		//-----------------------------------------------------------------------------

		public int OldSelection
		{
			get { return wxNotebookEvent_GetOldSelection(wxObject); }
			set { wxNotebookEvent_SetOldSelection(wxObject, value); }
		}		
	}

    /// <summary>
    /// This class represents a notebook control, which manages multiple windows with associated tabs.
    ///
    /// To use the class, create a wx.Notebook object and call AddPage or InsertPage, passing a window to be
    /// used as the page. Do not explicitly delete the window for a page that is currently managed by wx.Notebook.
    /// </summary>
    /// <remarks>
    /// \image html notebooksmall.png
    /// </remarks>
	public class Notebook : Control
	{
		[DllImport("wx-c")] static extern IntPtr wxNotebook_ctor();
		[DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)] static extern bool   wxNotebook_AddPage(IntPtr self, IntPtr page, IntPtr text, bool select, int imageId);
        [DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)] static extern bool wxNotebook_Create(IntPtr self, IntPtr parent, int id, int posX, int posY, int width, int height, uint style, IntPtr name);
		[DllImport("wx-c")] static extern int    wxNotebook_GetPageCount(IntPtr self);
		[DllImport("wx-c")] static extern IntPtr wxNotebook_GetPage(IntPtr self, int nPage);
		[DllImport("wx-c")] static extern int    wxNotebook_GetSelection(IntPtr self);
        [DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)] static extern bool wxNotebook_SetPageText(IntPtr self, int nPage, IntPtr strText);
		[DllImport("wx-c")] static extern IntPtr wxNotebook_GetPageText(IntPtr self, int nPage);
		[DllImport("wx-c")] static extern void   wxNotebook_SetImageList(IntPtr self, IntPtr imageList);
		[DllImport("wx-c")] static extern void   wxNotebook_AssignImageList(IntPtr self, IntPtr imageList);
		[DllImport("wx-c")] static extern IntPtr wxNotebook_GetImageList(IntPtr self);
		[DllImport("wx-c")] static extern int    wxNotebook_GetPageImage(IntPtr self, int nPage);
        [DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)] static extern bool wxNotebook_SetPageImage(IntPtr self, int nPage, int nImage);
		[DllImport("wx-c")] static extern int    wxNotebook_GetRowCount(IntPtr self);
		[DllImport("wx-c")] static extern void   wxNotebook_SetPageSize(IntPtr self, ref Size size);
		[DllImport("wx-c")] static extern void   wxNotebook_SetPadding(IntPtr self, ref Size padding);
		[DllImport("wx-c")] static extern void   wxNotebook_SetTabSize(IntPtr self, ref Size sz);
        [DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)] static extern bool wxNotebook_DeletePage(IntPtr self, int nPage);
        [DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)] static extern bool wxNotebook_RemovePage(IntPtr self, int nPage);
        [DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)] static extern bool wxNotebook_DeleteAllPages(IntPtr self);
        [DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)] static extern bool wxNotebook_InsertPage(IntPtr self, int nPage, IntPtr pPage, IntPtr strText, bool bSelect, int imageId);
		[DllImport("wx-c")] static extern int    wxNotebook_SetSelection(IntPtr self, int nPage);
		[DllImport("wx-c")] static extern void   wxNotebook_AdvanceSelection(IntPtr self, bool forward);

		//---------------------------------------------------------------------
		
		public Notebook(IntPtr wxObject) 
			: base(wxObject) { }

		public Notebook()
			: base(wxNotebook_ctor()) { }

		public Notebook(Window parent)
			: this(parent, Window.UniqueID, wxDefaultPosition, wxDefaultSize, wx.WindowStyles.NO_STYLE, null) { }

		public Notebook(Window parent, int id)
			: this(parent, id, wxDefaultPosition, wxDefaultSize, wx.WindowStyles.NO_STYLE, null) { }

		public Notebook(Window parent, int id, Point pos, Size size)
			: this(parent, id, pos, size, wx.WindowStyles.NO_STYLE, null) { }

		public Notebook(Window parent, int id, Point pos, Size size, wx.WindowStyles style)
			: this(parent, id, pos, size, style, null) { }

		public Notebook(Window parent, int id, Point pos, Size size, wx.WindowStyles style, string name)
			: this(parent, id, pos, size, style, wxString.SafeNew(name))
		{
        }
		public Notebook(Window parent, int id, Point pos, Size size, wx.WindowStyles style, wxString name)
			: base(wxNotebook_ctor())
		{
			if (!wxNotebook_Create(wxObject, Object.SafePtr(parent), id, pos.X, pos.Y, size.Width, size.Height, (uint)style, Object.SafePtr(name)))
			{
				throw new InvalidOperationException("Failed to create Notebook");
			}
		}

		//---------------------------------------------------------------------
		// ctors with self created id
			
		public Notebook(Window parent, Point pos, Size size)
			: this(parent, Window.UniqueID, pos, size, wx.WindowStyles.NO_STYLE, null) { }

		public Notebook(Window parent, Point pos, Size size, wx.WindowStyles style)
			: this(parent, Window.UniqueID, pos, size, style, null) { }

		public Notebook(Window parent, Point pos, Size size, wx.WindowStyles style, string name)
			: this(parent, Window.UniqueID, pos, size, style, name) {}
        
		//---------------------------------------------------------------------

		// TODO: Switch window with NotebookPage

		public bool AddPage(Window page, string text)
		{ return AddPage(page, text, false, -1); }
		
		public bool AddPage(Window page, string text, bool select)
		{ return AddPage(page, text, select, -1); }

        public bool AddPage(Window page, string text, bool select, int imageId)
        {
            return this.AddPage(page, wxString.SafeNew(text), select, imageId);
        }
		public bool AddPage(Window page, wxString text, bool select, int imageId)
		{
			return wxNotebook_AddPage(wxObject, Object.SafePtr(page), Object.SafePtr(text), select, imageId);
		}

		//---------------------------------------------------------------------

		public ImageList Images
		{
			set { wxNotebook_SetImageList(wxObject, Object.SafePtr(value)); }
			get { return (ImageList)FindObject(wxNotebook_GetImageList(wxObject)); }
		}

		//---------------------------------------------------------------------

		public int PageCount
		{
			get { return wxNotebook_GetPageCount(wxObject); }
		}

		/// <summary>
		/// The window representing the page.
		/// </summary>
		/// <param name="page">Zero-based index</param>
		public Window GetPage(int page)
		{
			return (Window)FindObject(wxNotebook_GetPage(wxObject, page));
		}

		//---------------------------------------------------------------------

        /// <summary>
        /// The zero-based index of the currently selected page. Use this property
        /// to read or set the currently selected note.
        /// </summary>
		public int Selection
		{
			get { return wxNotebook_GetSelection(wxObject); }
			set { wxNotebook_SetSelection(wxObject, value); }
		}

		public void AdvanceSelection(bool forward)
		{
			wxNotebook_AdvanceSelection(wxObject, forward);
		}

		//---------------------------------------------------------------------

        public bool SetPageText(int page, string text)
        {
            return this.SetPageText(page, wxString.SafeNew(text));
        }
		public bool SetPageText(int page, wxString text)
		{
			return wxNotebook_SetPageText(wxObject, page, Object.SafePtr(text));
		}

		public string GetPageText(int page)
		{
			return new wxString(wxNotebook_GetPageText(wxObject, page), true);
		}

		//---------------------------------------------------------------------

		public void AssignImageList(ImageList imageList)
		{
			wxNotebook_AssignImageList(wxObject, Object.SafePtr(imageList));
		}

		//---------------------------------------------------------------------

		public int GetPageImage(int page)
		{
			return wxNotebook_GetPageImage(wxObject, page);
		}

		public bool SetPageImage(int page, int image)
		{
			return wxNotebook_SetPageImage(wxObject, page, image);
		}

		//---------------------------------------------------------------------

		public int RowCount
		{
			get { return wxNotebook_GetRowCount(wxObject); }
		}

		//---------------------------------------------------------------------

		public Size PageSize
		{
			set { wxNotebook_SetPageSize(wxObject, ref value); }
		}

		public Size Padding
		{
			set { wxNotebook_SetPadding(wxObject, ref value); }
		}

		public Size TabSize
		{
			set { wxNotebook_SetTabSize(wxObject, ref value); }
		}

		//---------------------------------------------------------------------

		public bool DeletePage(int page)
		{
			return wxNotebook_DeletePage(wxObject, page);
		}

		public bool RemovePage(int page)
		{
			return wxNotebook_RemovePage(wxObject, page);
		}

		public bool DeleteAllPages()
		{
			return wxNotebook_DeleteAllPages(wxObject);
		}

		//---------------------------------------------------------------------

		// TODO: Switch window with NotebookPage
        public bool InsertPage(int page, Window window, string text, bool select, int image)
        {
            return this.InsertPage(page, window, wxString.SafeNew(text), select, image);
        }
		public bool InsertPage(int page, Window window, wxString text, bool select, int image)
		{
			return wxNotebook_InsertPage(wxObject, page,
										 Object.SafePtr(window), Object.SafePtr(text), select,
										 image);
		}

		//---------------------------------------------------------------------

		public event EventListener PageChange
		{
			add { AddCommandListener(Event.wxEVT_COMMAND_NOTEBOOK_PAGE_CHANGED, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}

		public event EventListener PageChanging
		{
			add { AddCommandListener(Event.wxEVT_COMMAND_NOTEBOOK_PAGE_CHANGING, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}
	}
}
