/**
 * wx.NET Project
 * 
 * \file 
 * 
 * Using masked text input with wx.TextCtrl
 * 
 * Written by Harald Meyer auf'm Hofe (C) 2008 
 * Licensed under the wxWidgets license, see LICENSE.txt for details.
 *
 * $Id: MaskedEdit.cs,v 1.19 2010/05/08 19:54:35 harald_meyer Exp $
 */

using System;
using System.Collections.Generic;
using wx;

/** <summary>This namespace contains controls and utilites that have been implemented on top of  wxWidgets.
 * \image html maskededit.png "The new masked edit control and specializations."</summary>*/
namespace wx.MaskedEdit
{
    /** <summary>This event will be raised whenever the value of a field is modified.
     * Handlers may veto or change the value.</summary>*/
    public class MaskedEditFieldValueChangingEvent : EventArgs
    {
        #region Internals
        object _newValue;
        object _oldValue;
        object _newValueChanged=null;
        bool _vetoed = false;
        bool _changed = false;
        EditField _field;
        internal MaskedEditFieldValueChangingEvent(MaskedEditService editCtrl, EditField field, object newValue, object oldValue)
        {
            this._field = field;
            this._newValue = newValue;
            this._newValueChanged = newValue;
            this._oldValue = oldValue;
        }
        #endregion

        #region Public Properties
        /** <summary>Returns whether a previous handler vetoed the change.</summary>*/
        public bool Vetoed
        {
            get { return this._vetoed; }
        }

        /** <summary>Returns true iff event handlers proposed an alternative value to be set.</summary>*/
        public bool Changed
        {
            get {return this._changed; }
        }

        /** <summary>Use this to read the value that will be set with the field.
         * Reads the <c>ChangedNewValue</c> if <c>Changed</c>, the <c>OriginalValue</c> if <c>Vetoed</c>, and the <c>OriginalNewValue</c> otherwise.</summary>*/
        public object Value
        {
            get
            {
                if (this.Changed)
                    return this._newValueChanged;
                else if (this.Vetoed)
                    return this._oldValue;
                else
                    return this._newValue;
            }
            set
            {
                this.Change(value);
            }
        }

        public object OriginalNewValue { get { return this._newValue; } }
        public object OriginalValue { get { return this._oldValue; } }
        public object ChangedNewValue { get { return this._newValueChanged; } }

        public EditField Field { get { return this._field; } }
        #endregion

        #region Public Actions
        /** <summary>Veto.
         * The communicated change will be rolled back. If an alternative value has been proposed, this proposal will be removed and discarded.</summary>*/
        public void Veto()
        {
            this._vetoed=true;
            this._changed=false;
            this._newValueChanged=null;
        }

        /** <summary>Change the proposed value.
         * A previous veto will be discarded.</summary>*/
        public void Change(object newValue)
        {
            this._vetoed = false;
            this._changed = true;
            this._newValueChanged = newValue;
        }
        #endregion
    }

    /** <summary>Handler for the MaskedEditFieldValueChangingEvent.</summary>*/
    public delegate void MaskedEditFieldValueChangingHandler(object sender, MaskedEditFieldValueChangingEvent evt);

    /** <summary>Evetns of this class will be fired after the value of a field changed.</summary>*/
    public class MaskedEditFieldValueChangedEvent : EventArgs
    {
        #region Internals
        object _newValue;
        object _oldValue;
        EditField _field;
        internal MaskedEditFieldValueChangedEvent(MaskedEditService editCtrl, EditField field, object newValue, object oldValue)
        {
            this._newValue = newValue;
            this._oldValue = oldValue;
            this._field = field;
        }
        #endregion

        public object OriginalValue { get { return this._oldValue; } }
        public object NewValue { get { return this._newValue; } }

        public EditField Field { get { return this._field; } }
    }

    /** <summary>Handler for the MaskedEditFieldValueChangedEvent.
     * </summary>
     */
    public delegate void MaskedEditFieldValueChangedHandler(object sender, MaskedEditFieldValueChangedEvent evt);

    /** <summary>Base class of all field declarations.
     * </summary>
     */
    public abstract class EditField
    {
        #region State
        internal MaskedEditService _maskedEdit = null;
        /** <summary>Textposition in the masked text.
         * This will be maintained by the control.
         * </summary>
         */
        internal int _posStart = -1;
        /** <summary>Textposition in the masked text.
         * This will be maintained by the control.
         * </summary>
         */
        internal int _posEnd = -1;

        /** <summary>Minimal width of a field.
         * </summary>
         */
        public int MinWidth = 0;
        /** <summary>Maximal width of a field.
         * All input exceeding this number of characters will discarded.
         * </summary>
         */
        public int MaxWidth = int.MaxValue;

        /** <summary>Leading characters if this kind will be ignored.</summary>*/
        public char EmptyChar = ' ';

        /** <summary>The text attributes to be used for this field if not <c>null</c>.
         * </summary>
         */
        public TextAttr TextAttributes = null;
        #endregion

        #region Properties
        /** <summary>An optional name for this field.
         * </summary>
         */
        public string Name = "";

        /** <summary>This will e.g. appear in the tooltip text if not empty.
         * </summary>
         */
        public string DisplayName = "";

        /** <summary>If this differs from <c>null</c>, than this property defines a number of predefined choices that may be for instance used in popup menus.
         * </summary>
         */
        public virtual string[] PredefinedChoices { get { return null; } }

        /** <summary>Returns or the text appearance of the current value.
         * </summary>
         */
        abstract public string TextValue { get; }

        /** <summary>This returns the data object of the field.
         * </summary>
         */
        public abstract object Object { get; set; }

        public virtual string TooltipText
        {
            get
            {
                if (this.DisplayName != null && this.DisplayName.Length > 0)
                    return this.DisplayName;
                return wx.Window._("Masked edit field.");
            }
        }

        /** <summary>Result indicates, that the  n characters beginning with <c>EmphasizeStart</c> shall be emphasized.
         * This is 0 by default => no emphasize.
         * </summary>
         */
        public virtual int EmphasizeLength { get { return 0; } }

        /** <summary>If <c>EmphasizeLength</c> is larger than 0, then this is the first emphasized character.
         * </summary>
         */
        public virtual int EmphasizeStart { get { return 0; } }

        /** <summary>Indicates with <c>true</c> that adding more characters will truncate elder input.
         * </summary>
         */
        public bool IsFull
        {
            get
            {
                string currentText = this.TextValue;
                return currentText.Length > 0 && currentText.Length == this.MaxWidth && currentText[0] != this.EmptyChar;
            }
        }
        #endregion

        #region Base Operations
        /** <summary>This will change <c>TextValue</c>.
         * Setting this property will start interpretation of the string.
         * The result is true on success, i.e. <c>TextValue</c> has been changed.
         * This does not necessarily mean, that <c>TextValue</c> equals <c>newTextValue</c>
         * because <c>TextValue</c> may contain leading <c>EmptyChar</c> etc.
         * </summary>
         */
        abstract public bool SetTextValue(string newTextValue);

        /** <summary>Delete a character from the text input of the field and return <c>true</c> on success.</summary>*/
        public virtual bool DeleteChar()
        {
            string currentText = this.TextValue;
            if (currentText.Length > 0)
            {
                this.SetTextValue(currentText.Substring(0, currentText.Length - 1));
                return true;
            }
            else
                return false;
        }

        /** <summary>Adds a new character to the field assuming explicit input.</summary>*/
        public virtual bool AddChar(char newChar)
        {
            string newString = new string(newChar, 1);
            newString = this.TextValue + newString;
            if (newString.Length > this.MaxWidth)
                newString = newString.Substring(newString.Length - this.MaxWidth);
            return this.SetTextValue(newString);
        }
        #endregion

        #region Complex Commands
        public virtual void OnUp()
        {
            this._maskedEdit.ShowError(this, wx.Object._("Cannot go up here."));
        }
        public virtual void OnDown()
        {
            this._maskedEdit.ShowError(this, wx.Object._("Cannot go down here."));
        }
        public virtual void OnPageUp()
        {
            this._maskedEdit.ShowError(this, wx.Object._("Cannot go page up here."));
        }
        public virtual void OnPageDown()
        {
            this._maskedEdit.ShowError(this, wx.Object._("Cannot go page down here."));
        }
        #endregion

        #region Events
        public event MaskedEditFieldValueChangingHandler OnChanging;
        public event MaskedEditFieldValueChangedHandler OnChanged;

        protected bool HasOnchangingEvent { get { return this.OnChanging != null; } }
        protected void RaiseOnChangingEvent(MaskedEditFieldValueChangingEvent evt)
        {
            bool equals = evt.OriginalValue == null && evt.OriginalNewValue == null;
            if (!equals && evt.OriginalValue != null)
                equals = evt.OriginalValue.Equals(evt.OriginalNewValue);
            if (!equals)
                if (this.OnChanging != null)
                    this.OnChanging(this, evt);
        }

        protected bool HasOnchangedEvent { get { return this.OnChanged != null; } }
        /** <summary>Helper for calling events after changing a value.
         * This will test whether we have listeners to the event and create an event and fire it.
         * The event as modified by the listeners will be returned. The result may be <c>null</c>.
         * </summary>
         */
        protected MaskedEditFieldValueChangedEvent RaiseOnChangedEvent(object oldValue)
        {
            if (this.OnChanged != null)
            {
                bool valueHasChanged = true;
                object currentValue = this.Object;
                if (currentValue == null)
                {
                    valueHasChanged = oldValue != null;
                }
                else
                {
                    valueHasChanged = !currentValue.Equals(oldValue);
                }
                if (valueHasChanged)
                {
                    MaskedEditFieldValueChangedEvent evt = new MaskedEditFieldValueChangedEvent(this._maskedEdit, this, currentValue, oldValue);
                    this.OnChanged(this, evt);
                    return evt;
                }
            }
            return null;
        }
        #endregion
    }

    /** <summary>Defines a text field containing an integer number.</summary>*/
    public class EditIntField : EditField
    {
        #region Private State
        int? _value = null;
        int _pageStep = 10;
        #endregion

        #region Events
        public class OverflowEvent
        {
            public int Value;
            public EditIntField Field;
            public OverflowEvent(EditIntField field, int value)
            {
                this.Field = field;
                this.Value=value;
            }
        }
        public delegate void OverflowEventHandler(object sender, OverflowEvent evt);
        public class UnderflowEvent
        {
            public int Value;
            public EditIntField Field;
            public UnderflowEvent(EditIntField field, int value)
            {
                this.Field = field;
                this.Value = value;
            }
        }
        public delegate void UnderflowEventHandler(object sender, UnderflowEvent evt);

        public event OverflowEventHandler OnOverflow;
        public event UnderflowEventHandler OnUnderflow;
        #endregion

        #region Public State And Properties
        public int MinValue = int.MinValue;
        public int MaxValue = int.MaxValue;

        public override string[] PredefinedChoices
        {
            get
            {
                int l=MaxValue - MinValue+1;
                if (l > 0 && l <= 31)
                {
                    string[] result=new string[l];
                    for (int i = 0; i < l; ++i)
                        result[i] = (MinValue + i).ToString();
                    return result;
                }
                else if (l > 31 && this.Value != null && this.Value.HasValue)
                {
                    int start = this.Value.Value - 15;
                    if (start + 31 > this.MaxValue)
                        start = this.MaxValue - 31;
                    if (start < this.MinValue)
                        start = this.MinValue;
                    List<string> result = new List<string>();
                    for (int i = start; i < start + 31 && i < this.MaxValue; ++i)
                    {
                        result.Add(i.ToString());
                    }
                    return result.ToArray();
                }
                else
                    return base.PredefinedChoices;
            }
        }

        /** <summary>Return the value of this field.
         * Setting the value will raise MaskedEditFieldValueChangingEvent and MaskedEditFieldValueChangedEvent(s).</summary>*/
        public int? Value
        {
            get { return this._value; }
            set
            {
                int? oldValue = this._value;
                if (value != null && value.HasValue)
                {
                    if (value.Value > this.MaxValue || value.Value < this.MinValue)
                    {
                        this._maskedEdit.ShowError(this, wx.Object._("Integer value out of range."));
                        return;
                    }
                }
                if (this.HasOnchangingEvent)
                {
                    MaskedEditFieldValueChangingEvent evt = new MaskedEditFieldValueChangingEvent(this._maskedEdit, this, value, this._value);
                    this.RaiseOnChangingEvent(evt);
                    if (evt.Vetoed)
                        return;
                    this._value = evt.Value as int?;
                }
                else
                    this._value = value;
                this.RaiseOnChangedEvent(oldValue);
                if (this._maskedEdit!=null)
                    this._maskedEdit.RefreshValue();
            }
        }

        public override object Object
        {
            get
            {
                if (this._value != null && this._value.HasValue)
                    return this._value;
                else
                    return null;
            }
            set
            {
                if (value is byte)
                    value = (int)(byte)value;
                if (value is int)
                    this.Value = (int)value;
                else if (value is int?)
                    this.Value = (int?)value;
                else
                    this.Value = null;
            }
        }

        public override string TextValue
        {
            get
            {
                bool addMinus = false;
                string result = "";
                if (this._value != null && this._value.HasValue)
                {
                    if (this.EmptyChar == '0' && this._value < 0)
                    {
                        addMinus = true;
                        result = (-this._value.Value).ToString();
                    }
                    else
                        result = this._value.Value.ToString();
                }
                while (result.Length < this.MinWidth)
                    result = new string(this.EmptyChar, this.MinWidth - result.Length) + result;
                if (addMinus)
                {
                    if (this.MaxWidth < result.Length + 1)
                        result = result.Substring(result.Length - this.MaxWidth);
                    result = "-" + result;
                }
                else
                {
                    if (this.MaxWidth < result.Length)
                        result = result.Substring(result.Length - this.MaxWidth);
                }
                return result;
            }
        }

        public override bool SetTextValue(string value)
        {
            try
            {
                int sign = 1;
                if (value.Length > this.MaxWidth)
                    value = value.Substring(value.Length - this.MaxWidth);
                if (value.Length > 0 && value[value.Length - 1] == '-')
                {
                    sign = -1 * sign;
                    value = value.Substring(0, value.Length - 1);
                }
                int startPos = 0;
                while (startPos < value.Length && value[startPos] == this.EmptyChar)
                    ++startPos;
                value = value.Substring(startPos);
                if (value.Length > 0)
                {
                    int newValue = sign * Convert.ToInt32(value);
                    if (newValue > this.MaxValue && value.Length > 1)
                    {
                        value = value.Substring(1);
                        newValue = sign * Convert.ToInt32(value);
                    }
                    if (newValue < this.MinValue)
                        newValue = this.MinValue + newValue;
                    if (newValue > this.MaxValue)
                        newValue = this.MaxValue;
                    this.Value = newValue;
                }
                else if (this.EmptyChar >= '0' && this.EmptyChar <= '9')
                {
                    if (this.MinValue > 0)
                        this.Value = this.MinValue;
                    else
                        this.Value = 0;
                }
                else
                    this.Value = null;
                return true;
            }
            catch (Exception exc)
            {
                this._maskedEdit.ShowError(this, exc.Message);
                return false;
            }
        }

        public override string TooltipText
        {
            get
            {
                string result = this.DisplayName;
                if (result == null)
                    result = "";
                if (result.Length > 0)
                    result += "\n";
                result += wx.Object._("Type in an integer number in decimal notation.");
                if (this.MinValue > int.MinValue && this.MaxValue < int.MaxValue)
                    result += "\n" + wx.Object._("The number must be larger than or equal to {0} and smaller than or equal to {1}.", this.MinValue, this.MaxValue);
                else if (this.MinValue > int.MinValue)
                    result += "\n" + wx.Object._("The number must be larger than or equal to {0}.", this.MinValue);
                else if (this.MaxValue < int.MaxValue)
                    result += "\n" + wx.Object._("The number must be smaller than or equal to {0}.", this.MaxValue);
                result += "\n" + wx.Object._("You may also use the cursor up and down or the page up and down keys to scroll over the values.");
                return result;
            }
        }
        #endregion

        #region CTor
        EditIntField() { this.EmptyChar = '0'; }

        public static EditIntField New() { return new EditIntField(); }
        /** <summary>Creates an instance of a particular name.
         * This name may be used to identify the field in event handlers.</summary>*/
        public static EditIntField New(string name) { EditIntField result = new EditIntField(); result.Name = name; return result; }

        /** <summary>Setting <c>MinValue</c> and <c>MaxValue</c>.</summary>
         * <returns> this instance </returns>
         */
        public EditIntField SetIn(int min, int max)
        {
            this.MinValue = min;
            this.MaxValue = max;
            if (this._value == null || !this._value.HasValue || this._value < this.MinValue)
                this._value = this.MinValue;
            if (this._value != null && this._value.HasValue && this._value > this.MaxValue)
                this._value = this.MaxValue;
            return this;
        }

        /** <summary>Sets the <c>MinWidth</c>.
         * </summary>
         * <returns>this instance</returns>
         */
        public EditIntField SetMinWidth(int width) { this.MinWidth = width; return this; }
        /** <summary>Sets the <c>MaxWidth</c>.
         * </summary>
         * <returns>this instance</returns>
         */
        public EditIntField SetMaxWidth(int width) { this.MaxWidth = width; return this; }
        /** <summary>Sets minimal and maximal width.
         * </summary>
         */
        public EditIntField SetWidth(int width) { this.MaxWidth = width; this.MinWidth = width; return this; }

        /** <summary>Sets the <c>EmptyChar</c> to the provided value and return <c>this</c>.
         * </summary>
         * <remarks>
         * Samples:
         * \li <c>StringField.New().SetEmptyChar(</c>'_')
         * \li <c>StringField.New().SetEmptyChar(</c>'0')
         * 
         * Use decimals es empty character if you want to prevent this field from returning result value <c>null</c>.
         * </remarks>
         */
        public EditIntField SetEmptyChar(char emptyChar) { this.EmptyChar = emptyChar; return this; }

        /** <summary>Defines text and background colour.
         * Provide <c>null</c> if you do not want to specify text attributes explicitely.
         * </summary>
         */
        public EditIntField SetTextAttributes(TextAttr attr)
        {
            this.TextAttributes = attr;
            return this;
        }
        #endregion

        #region Complex Actions
        public override void OnUp()
        {
            this._pageStep = 0;
            if (this._value == null && !this.Value.HasValue)
            {
                if (this.MaxValue > 0)
                    this.Value = this.MaxValue;
                else
                    this.Value = 0;
            }
            else
            {
                if (this.Value.Value >= this.MaxValue)
                {
                    if (this.MaxValue > 0)
                    {
                        this.Value = this.MaxValue;
                        if (this.OnOverflow != null)
                            this.OnOverflow(this, new OverflowEvent(this, this.Value.Value));
                    }
                    else
                        this.Value = 0;
                }
                else
                    this.Value += 1;
            }
        }

        public override void OnDown()
        {
            this._pageStep = 0;
            if (this.Value == null && !this.Value.HasValue)
            {
                if (this.MinValue < 0)
                    this.Value = this.MinValue;
                else
                    this.Value = 0;
            }
            else
            {
                if (this.Value <= this.MinValue)
                {
                    this.Value = this.MinValue;
                    if (this.OnUnderflow != null)
                        this.OnUnderflow(this, new UnderflowEvent(this, this.Value.Value));
                }
                else
                    this.Value -= 1;
            }
        }

        public override void OnPageUp()
        {
            if (this._pageStep > 0)
            {
                if (this._value == (this._value / 10 / this._pageStep) * 10 * this._pageStep)
                    this._pageStep = this._pageStep * 10;
            }
            else
                this._pageStep = 10;
            this._value = (this._value / this._pageStep) * this._pageStep;
            this.AddToFieldValue(this._pageStep);
        }
        void AddToFieldValue(int offset)
        {
            if (this._value == null && !this._value.HasValue)
            {
                if (this.MinValue > 0)
                    this._value = this.MinValue;
                else
                    this._value = 0;
            }
            else if (offset >= 0)
            {
                if (this._value > this.MaxValue - offset)
                {
                    this.Value = this.MaxValue;
                    if (this.OnOverflow != null)
                        this.OnOverflow(this, new OverflowEvent(this, this.Value.Value));
                }
                else
                    this.Value = this._value + offset;
            }
            else
            {
                if (this._value < this.MinValue - offset)
                {
                    this.Value = this.MinValue;
                    if (this.OnUnderflow != null)
                        this.OnUnderflow(this, new UnderflowEvent(this, this.Value.Value));
                }
                else
                    this.Value = this._value + offset;
            }
        }
        public override void OnPageDown()
        {
            if (this._pageStep < 0)
            {
                if (this._value == (this._value / 10 / this._pageStep) * 10 * this._pageStep)
                    this._pageStep = this._pageStep * 10;
            }
            else
                this._pageStep = -10;
            this.AddToFieldValue(this._pageStep);
            this._value = (this._value / this._pageStep) * this._pageStep;
        }
        #endregion
    }

    /** <summary>This is a field containing a string.
     * </summary>
     */
    public class StringEditField : EditField
    {
        #region Hidden State
        int _emphasizeLength = 0;
        /** <summary>If this is set, this.Object will be converted from the selected string.</summary>*/
        System.Collections.Generic.Dictionary<string, object> _objectConversion = null;
        #endregion

        #region Public State
        /** <summary>Set this to a string of characters to constrain the used characters.
         * If not <c>null</c> only characters mentioned in this string will be allowed in <c>value</c>.
         * </summary>
         */
        public string AllowedChars = null;

        /** <summary>If this is non-null, then this is a number of choices the user may select.
         * Insert an empty string (not <c>null)</c> to allow additionally free input.</summary>*/
        public string[] Choices = null;

        string _value = "";
        /** <summary>Return the value of this field.
         * Setting the value will raise MaskedEditFieldValueChangingEvent and MaskedEditFieldValueChangedEvent(s).
         * </summary>
         */
        public string Value
        {
            get { return this._value; }
            set
            {
                this.SetTextValue(value);
            }
        }

        /** <summary>This returns <c>Choices</c>.</summary>*/
        public override string[] PredefinedChoices
        {
            get
            {
                return this.Choices;
            }
        }

        /** <summary>This is the <c>Value</c> of this field, a string.
         * However, if SetChoices() has been called with an enumeration type, this will
         * return instances of this type instead.</summary>*/
        public override object Object
        {
            get
            {
                if (this._objectConversion == null)
                    return this.Value;
                else
                    return this._objectConversion[this.Value];
            }
            set
            {
                if (this._objectConversion == null)
                    this.Value = value as string;
                else
                {
                    foreach (KeyValuePair<string, object> pair in this._objectConversion)
                    {
                        if (pair.Value.Equals(value))
                            this.Value = pair.Key;
                    }
                }
            }
        }

        /** <summary><c>Value</c> but expanded to <c>MinWidth</c> und trancated by <c>MaxWidth</c>.</summary>*/
        public override string TextValue
        {
            get
            {
                string result = this.Value;
                if (result.Length < this.MinWidth)
                    result = (new string(this.EmptyChar, this.MinWidth - result.Length)) + result;
                if (result.Length > this.MaxWidth)
                    result = result.Substring(result.Length - this.MaxWidth);
                return result;
            }
        }

        public override bool SetTextValue(string value)
        {
            string oldValue = this._value;

            int prefixLen = 0;
            while (prefixLen < value.Length && value[prefixLen] == this.EmptyChar)
                ++prefixLen;
            if (prefixLen > 0)
                value = value.Substring(prefixLen);

            if (this.Choices != null)
            {
                bool hasFreeChoice = false;
                bool foundExplicitChoice = false;
                string bestChoice = "";
                foreach (string choice in this.Choices)
                {
                    if (choice == null || choice.Length == 0)
                        hasFreeChoice = true;
                    else
                    {
                        if (choice.ToLower().StartsWith(value.ToLower()))
                        {
                            if (!foundExplicitChoice)
                            {
                                foundExplicitChoice = true;
                                bestChoice = choice;
                            }
                        }
                    }
                }
                if (value.Length == 0 && hasFreeChoice)
                    value = "";
                else if (foundExplicitChoice)
                    value = bestChoice;
                else if (!foundExplicitChoice && !hasFreeChoice)
                {
                    this._maskedEdit.ShowError(this, wx.Object._("You have to choose amoung predefined choices.\nCannot identify an available choice from your input."));
                    return false;
                }
                else if (!foundExplicitChoice && hasFreeChoice && this.AllowedChars != null)
                {
                    for (int i = 0; i < value.Length; ++i)
                    {
                        if (this.AllowedChars.IndexOf(value[i]) < 0)
                        {
                            this._maskedEdit.ShowError(this, wx.Object._("Illegal character input. Choose one from \"{0}\".", this.AllowedChars));
                            return false;
                        }
                    }
                }
            }
            else if (this.AllowedChars != null)
            {
                for (int i = 0; i < value.Length; ++i)
                {
                    if (this.AllowedChars.IndexOf(value[i]) < 0)
                    {
                        this._maskedEdit.ShowError(this, wx.Object._("Illegal character input. Choose one from \"{0}\".", this.AllowedChars));
                        return false;
                    }
                }
            }

            if (this.HasOnchangingEvent)
            {
                MaskedEditFieldValueChangingEvent evt = new MaskedEditFieldValueChangingEvent(this._maskedEdit, this, value, this._value);
                this.RaiseOnChangingEvent(evt);
                if (evt.Vetoed)
                    return false;
                this._value = evt.Value as string;
                this._emphasizeLength = 0;
            }
            else
            {
                this._value = value;
                this._emphasizeLength = 0;
            }
            this.RaiseOnChangedEvent(oldValue);
            if (this._maskedEdit != null)
                this._maskedEdit.RefreshValue();
            return true;
        }

        public override bool DeleteChar()
        {
            int oldEmphLength = this._emphasizeLength;
            if (base.DeleteChar())
            {
                if (oldEmphLength > 0)
                    this._emphasizeLength = oldEmphLength - 1;
                return true;
            }
            else
                return false;
        }

        public override bool AddChar(char c)
        {
            if (this.Choices != null && this.Choices.Length > 0)
            {
                int oldEmphLength = this._emphasizeLength;
                string newText = this.EmphasizedString;
                newText += new string(c, 1);
                if (this.SetTextValue(newText))
                {
                    this._emphasizeLength = oldEmphLength + 1;
                    return true;
                }
                else
                    return false;
            }
            else
                return base.AddChar(c);
        }

        public override int EmphasizeLength
        {
            get { return this._emphasizeLength; }
        }
        public override int EmphasizeStart
        {
            get
            {
                if (this._value != null && this._value.Length < this.MinWidth)
                    return this.MinWidth - this._value.Length;
                return 0;
            }
        }
        public string EmphasizedString
        {
            get
            {
                if (this._value != null && this._emphasizeLength > 0)
                {
                    if (this._emphasizeLength > this._value.Length)
                        this._emphasizeLength = this._value.Length;
                    return this._value.Substring(0, this._emphasizeLength);
                }
                else
                    return "";
            }
        }

        public override string TooltipText
        {
            get
            {
                string result = this.DisplayName;
                if (result == null)
                    result = "";
                if (result.Length > 0)
                    result += "\n";
                result+=wx.Object._("Free text input.");
                if (this.Choices != null && this.Choices.Length > 0)
                {
                    result += " " + wx.Object._("You may either use the cursor up and down keys to scroll over predefined choices or you might explicitely type in text. The text that you typed in will be shown in bold faces.");
                    bool freeInputallowed = false;
                    foreach (string choice in this.Choices)
                    {
                        if (choice == null || choice.Length == 0)
                        {
                            freeInputallowed = true;
                            break;
                        }
                    }
                    if (!freeInputallowed)
                    {
                        System.Text.StringBuilder sb = new System.Text.StringBuilder();
                        bool thisIsTheFirst = true;
                        foreach (string choice in this.Choices)
                        {
                            if (!thisIsTheFirst)
                                sb.Append(", ");
                            sb.Append(choice);
                            thisIsTheFirst = false;
                        }
                        result += " " + wx.Object._("You have to choose among the following alternatives: {0}. Text input will select the first matching choice.", sb);
                    }
                }
                if (this.AllowedChars != null && this.AllowedChars.Length > 0)
                {
                    result += " " + wx.Object._("Please, use only characters from \"{0}\".", this.AllowedChars);
                }
                return result;
            }
        }
        #endregion

        #region CTor
        StringEditField() { }

        /** <summary>Creates a new instance.
         * </summary>
         */
        public static StringEditField New() { return new StringEditField(); }
        /** <summary>Creates an instance of a particular name.
         * This name may be used to identify the field in event handlers.
         * </summary>
         */
        public static StringEditField New(string name) { StringEditField field = new StringEditField(); field.Name = name; return field; }

        /** <summary>Sets the width to the provided value and return <c>this</c>.
         * Sample: <c>StringField.New().SetWidth(10)</c> is equivalent to StringField.New().SetMinWidth(10).SetMaxWidth(10).
         * </summary>
         */
        public StringEditField SetWidth(int width) { this.MinWidth = width; this.MaxWidth = width; return this; }
        /** <summary>Sets the width to the provided value and return <c>this</c>.
         * Sample: <c>StringField.New().SetMinWidth(10).SetMaxWidth(10)</c>
         * </summary>
         */
        public StringEditField SetMinWidth(int width) { this.MinWidth = width; return this; }
        /** <summary>Sets the width to the provided value and return <c>this</c>.
         * Sample: <c>StringField.New().SetMinWidth(10).SetMaxWidth(10)</c>
         * </summary>
         */
        public StringEditField SetMaxWidth(int width) { this.MaxWidth = width; return this; }
        /** <summary>Sets the <c>AllowedChars</c> to the provided value and return <c>this</c>.
         * Sample: <c>StringField.New().AllowedChars(</c>"abcdefghijklmnopqrstuvwxyz")
         * </summary>
         */
        public StringEditField SetIn(string allowedChars) { this.AllowedChars = allowedChars; return this; }
        /** <summary>Sets the <c>EmptyChar</c> to the provided value and return <c>this</c>.
         * Sample: <c>StringField.New().SetEmptyChar(</c>'_')
         * </summary>
         */
        public StringEditField SetEmptyChar(char emptyChar) { this.EmptyChar = emptyChar; return this; }
        /** <summary>Sets availabel choices.
         * Add an empty string to allow additionally free text input.
         * Sample: <c>StringField.New().SetChoices(</c>"", "one choice", "another choice")
         * </summary>
         */
        public StringEditField SetChoices(params string[] choices)
        {
            if (choices != null && choices.Length > 0)
            {
                this.Choices = choices;
                this._value = choices[0];
            }
            return this;
        }

        /** <summary>This will set the values of the provided enumeration type as choices.
         * This will enumerate the values of the provided enumeration, translate them, and
         * include them into the available choices.
         * Note: If this has been called, this.Object will return instances of the <c>enumType</c>.
         * Note, that this will raise exceptions, is <c>enumType</c> is not an enumeration type.
         * </summary>
         */
        public StringEditField SetChoices(Type enumType)
        {
            this._objectConversion=new Dictionary<string,object>();
            List<string> choices=new List<string>();
            Array instances = Enum.GetValues(enumType);
            foreach (object instance in instances)
            {
                string translation=wx.Object.GetTranslation((Enum) instance);
                this._objectConversion[translation] = instance;
                choices.Add(translation);
            }
            this.Choices = choices.ToArray();
            this._value = this.Choices[0];
            return this;
        }

        /** <summary>Defines text and background colour.
         * Provide <c>null</c> if you do not want to specify e.g. the background explicitely.</summary>*/
        public StringEditField SetTextAttributes(TextAttr attr)
        {
            this.TextAttributes = attr;
            return this;
        }
        #endregion

        #region Complex Actions
        int IndexOfCurrentChoice()
        {
            if (this.Value == null || this.Choices == null || this.Choices.Length == 0)
                return -1;
            else
            {
                for (int i = 0; i < this.Choices.Length; ++i)
                {
                    if (this.Choices[i].Equals(this.Value))
                        return i;
                }
                return -1;
            }
        }

        public override void OnUp()
        {
            this._emphasizeLength = 0;
            int current = this.IndexOfCurrentChoice();
            if (current < 0)
            {
                if (this.Choices != null && this.Choices.Length > 0)
                    this.Value = this.Choices[0];
                else
                    base.OnUp();
            }
            else
            {
                string newChoice = this.Choices[(current + 1) % this.Choices.Length];
                if (newChoice == null || newChoice.Length == 0)
                    newChoice = this.Choices[(current + 2) % this.Choices.Length];
                this.Value = newChoice;
            }
        }

        public override void OnDown()
        {
            this._emphasizeLength = 0;
            int current = this.IndexOfCurrentChoice();
            if (current < 0)
            {
                if (this.Choices != null && this.Choices.Length > 0)
                    this.Value = this.Choices[0];
                else
                    base.OnDown();
            }
            else
            {
                int newIndex = current - 1;
                while (newIndex < 0)
                    newIndex += this.Choices.Length;
                string newChoice = this.Choices[newIndex];
                if (newChoice == null || newChoice.Length == 0)
                    newIndex -= 1;
                if (newIndex < 0)
                    newIndex += this.Choices.Length;
                newChoice = this.Choices[newIndex];
                this.Value = newChoice;
            }
        }
        #endregion
    }

    /** <summary>Internal class providing service level for masked text edit.</summary>*/
    internal class MaskedEditService : System.Collections.IEnumerable
    {
        #region State
        TextCtrl _textCtrl;
        EditField[] _fields;
        string _textMask;
        int _selectedField = -1;
        /** <summary>This will be used to count the number of characters that have been added to the current field.
         * This will be compared to the maximal width in order to determine whether to switch to the next field.</summary>*/
        int _charsAddedToSelectedField = 0;
        #endregion

        #region CTor
        public MaskedEditService(TextCtrl textCtrl, string textMask, params EditField[] fields)
        {
            this._textCtrl = textCtrl;
            this._textMask = textMask;
            this._fields = fields;

            if (fields == null || textMask == null || fields.Length == 0)
                throw new FormatException(wx.Object._("Cannot create masked edit controls with empty text mask or field declaration."));

            for (int i = 0; i < this._fields.Length; ++i)
            {
                if (this._fields[i]._maskedEdit != null)
                    throw new FormatException(wx.Object._("Created a masked edit reusing field declaration {0}. Each masked edit requires fresh field declarations.", i));
                if (this._textMask.IndexOf(string.Format("{{{0}}}", i)) < 0)
                    throw new FormatException(wx.Object._("Field {0} in masked edit without entry in the text mask.", i));
                this._fields[i]._maskedEdit = this;
            }

            this.RefreshValue();

            this._textCtrl.EVT_SET_FOCUS(new EventListener(this.OnSetFocus));
            this._textCtrl.EVT_KILL_FOCUS(new EventListener(this.OnKillFocus));
            this._textCtrl.EVT_CHAR(new EventListener(this.OnChar));
            this._textCtrl.EVT_MOUSE_EVENTS(new EventListener(this.OnMouseClick));
        }
        #endregion

        #region Events
        void OnSetFocus(object sender, Event evt)
        {
            if (this._selectedField < 0)
                this.SelectField(0);
        }
        void OnKillFocus(object sender, Event evt)
        {
            this._textCtrl.SetSelection(0, 0);
            this._selectedField = -1;
        }

        public int NearestField(System.Drawing.Point position)
        {
            int pos=0;
            TextCtrlHitTestResult hit = this._textCtrl.HitTest(position, out pos);
            if (hit != TextCtrlHitTestResult.wxTE_HT_UNKNOWN)
                return NearestField(pos);
            else
                return -1;
        }

        public int NearestField(int textCursorPosition)
        {
            int result = 0;
            if (textCursorPosition >= 0)
            {
            for (int i = 1; i < this._fields.Length; ++i)
            {
                if (this._fields[result]._posEnd < this._fields[i]._posStart)
                {
                    int distResult = textCursorPosition - this._fields[result]._posEnd;
                    int distCurrent = this._fields[i]._posStart - textCursorPosition;
                    if (distCurrent < distResult)
                        result = i;
                }
                else
                {
                    int distResult = this._fields[result]._posStart - textCursorPosition;
                    int distCurrent = textCursorPosition - this._fields[i]._posEnd;
                    if (distCurrent < distResult)
                        result = i;
                }
            }
            }
            return result;
        }

        void OnMouseClick(object sender, Event evt)
        {
            MouseEvent mevt = evt as MouseEvent;
            if (mevt != null && mevt.IsButton)
            {
                this._textCtrl.SetFocus();
                int nearestFieldIndex=NearestField(mevt.Position);
                if (nearestFieldIndex >= 0)
                {
                this.SelectField(nearestFieldIndex);
                if (nearestFieldIndex >= 0)
                {
                    EditField nearestField = this._fields[nearestFieldIndex];
                    if (mevt.RightDown && nearestField.PredefinedChoices != null)
                    {
                        Menu popup = new Menu();
                        int valueIndex=0;
                        foreach (string choice in nearestField.PredefinedChoices)
                        {
                            if (choice != null && choice.Length > 0)
                                popup.Append(valueIndex, choice);
                            ++valueIndex;
                        }
                        popup.EVT_MENU(-1, new EventListener(OnPopupValueSelection));
                        this._textCtrl.PopupMenu(popup);
                    }
                }
                }
                else
                  this.SelectField(0);
            }
        }

        void OnPopupValueSelection(object sender, Event evt)
        {
            CommandEvent cmdevt = evt as CommandEvent;
            if (cmdevt != null && this._selectedField >= 0)
            {
                int currentSelection=this._selectedField;
                EditField selectedField=this._fields[currentSelection];
                if (selectedField.PredefinedChoices != null && cmdevt.ID >= 0 && cmdevt.ID < selectedField.PredefinedChoices.Length)
                {
                    string value = selectedField.PredefinedChoices[cmdevt.ID];
                    selectedField.SetTextValue(value);
                    this.RefreshValue();
                    this.SelectField(currentSelection);
                }
            }
        }

        /** <summary>This is the action triggered by the "Home" key: Step to field 0.
         * Please note, that this action will use the order of the fields w.r.t. their index.</summary>*/
        void StepToFirstField()
        {
            this.SelectField(0);
            /* the following implementation uses real coordinates to find the left most
             * field.
            int leftMostPos = int.MaxValue;
            int leftMostField=0;
            int currentField=0;
            foreach(EditField field in this._fields)
            {
                if (field._posStart < leftMostPos)
                {
                    leftMostPos = field._posStart;
                    leftMostField = currentField;
                }
                ++currentField;
            }
            this.SelectField(leftMostField);
             */
        }

        /** <summary>This is the action triggered by the "End" key: Step to field 0.
         * Please note, that this action will use the order of the fields w.r.t. their index.</summary>*/
        void StepToLastField()
        {
            this.SelectField(this._fields.Length - 1);
            /* the following implementation uses real coordinates to find the right most
             * field.
            int rightMostPos = int.MinValue;
            int rightMostField = this._fields.Length - 1;
            int currentField = 0;
            foreach (EditField field in this._fields)
            {
                if (field._posStart > rightMostPos)
                {
                    rightMostPos = field._posStart;
                    rightMostField = currentField;
                }
                ++currentField;
            }
            this.SelectField(rightMostField);
             */
        }

        /** <summary>This is the action triggered by the "Cursor right" key: Step to field 0.
         * Please note, that this action will use the order of the fields w.r.t. their index.
         * Prerequisite: We have a current selection.</summary>*/
        public void StepRight()
        {
            if (this._selectedField < 0)
                this.SelectField(0);
            else
            {
                if (this._selectedField < this._fields.Length - 1)
                    this.SelectField(this._selectedField + 1);
                else
                    this.SelectField(0);
                /** <summary>the following implementation uses real coordinates to find the right neighbour.
                  
                int leftBound = this._fields[this._selectedField]._posStart;
                int leftMostRightNeighbourPos = int.MaxValue;
                int leftMostRightNeighbourField = 0; // this will only be changed if a right neighbour exist
                                                    // so, we will step to field 0 if this is called on the right
                                                   // most field.
                int currentField = 0;
                foreach (EditField field in this._fields)
                {
                    if (field._posStart > leftBound && field._posStart < leftMostRightNeighbourPos)
                    {
                        leftMostRightNeighbourPos = field._posStart;
                        leftMostRightNeighbourField = currentField;
                    }
                    ++currentField;
                }
                this.SelectField(leftMostRightNeighbourField);</summary>*/
            }
        }

        /** <summary>This is the action triggered by the "Cursor left" key: Step to field 0.
         * Please note, that this action will use the order of the fields w.r.t. their index.
         * Prerequisite: We have a current selection.</summary>*/
        public void StepLeft()
        {
            if (this._selectedField < 0)
                this.SelectField(0);
            else
            {
                if (this._selectedField > 0)
                    this.SelectField(this._selectedField - 1);
                else
                    this.SelectField(this._fields.Length - 1);
                /** <summary>the following implementation uses real coordinates to find the right neighbour.
                  
                int rightBound = this._fields[this._selectedField]._posStart;
                int rightMostLeftNeighbourPos = int.MinValue;
                int rightMostLeftNeighbourField = this._fields.Length-1; // this will only be changed if a right neighbour exist
                // so, we will step to field 0 if this is called on the right
                // most field.
                int currentField = 0;
                foreach (EditField field in this._fields)
                {
                    if (field._posStart < rightBound && field._posStart > rightMostLeftNeighbourPos)
                    {
                        rightMostLeftNeighbourPos = field._posStart;
                        rightMostLeftNeighbourField = currentField;
                    }
                    ++currentField;
                }
                this.SelectField(rightMostLeftNeighbourField);</summary>*/
            }
        }

        void DeleteField()
        {
            EditField current = this._fields[this._selectedField];
            current.SetTextValue("");
            this._charsAddedToSelectedField = 0;
            this.RefreshValue();
            this.SelectField(this._selectedField);
        }

        void DeleteChar()
        {
            EditField current = this._fields[this._selectedField];
            if (current.DeleteChar())
            {
                if (this._charsAddedToSelectedField > 0)
                    this._charsAddedToSelectedField -= 1;
                this.RefreshValue();
                this.SelectField(this._selectedField);
            }
            else
                this.ShowError(current, wx.Object._("BACKSPACE on already empty string."));
        }

        void DownInField()
        {
            EditField current = this._fields[this._selectedField];
            current.OnDown();
            this.RefreshValue();
            this.SelectField(this._selectedField);
        }

        void UpInField()
        {
            EditField current = this._fields[this._selectedField];
            current.OnUp();
            this.RefreshValue();
            this.SelectField(this._selectedField);
        }

        void PageDownInField()
        {
            EditField current = this._fields[this._selectedField];
            current.OnPageDown();
            this.RefreshValue();
            this.SelectField(this._selectedField);
        }

        void PageUpInField()
        {
            EditField current = this._fields[this._selectedField];
            current.OnPageUp();
            this.RefreshValue();
            this.SelectField(this._selectedField);
        }

        /** <summary>Updates the text content from the values of the fields-</summary>*/
        public void RefreshValue()
        {
            TextAttr attr = null;
            this._textCtrl.Value = ExpandText(this._textMask, this._fields);
            for (int i = 0; i < this._fields.Length; ++i)
            {
                EditField field=this._fields[i];
                int emphLength = field.EmphasizeLength;
                if (emphLength > 0)
                {
                    if (emphLength > field._posEnd - field._posStart)
                        emphLength = field._posEnd - field._posStart;
                    if (attr == null)
                    {
                        attr = new TextAttr();
                        attr.Flags = TextAttr.Attr.FontWeight;
                        attr.Font = FontList.TheFontList.FindOrCreateWithWeight(this._textCtrl.Font, FontWeight.wxBOLD);
                    }
                    int startingPoint=field._posStart+field.EmphasizeStart;
                    this._textCtrl.SetStyle(startingPoint, startingPoint + emphLength, attr);
                }

                if (field.TextAttributes != null)
                {
                    this._textCtrl.SetStyle(field._posStart, field._posEnd, field.TextAttributes);
                }
            }
        }

        /** <summary>This will be called on adding a new character input to the currently selected field.
         * This is made public to ease use of masked edits in tables.</summary>*/
        public void OnChar(object sender, Event evt)
        {
            if (this._selectedField >= 0)
            {
                EditField current = this._fields[this._selectedField];
                KeyEvent kevt = evt as KeyEvent;
                if (kevt != null)
                {
                    switch (kevt.KeyCode)
                    {
                        case (int)KeyCode.WXK_TAB:
                            {
                                if (!kevt.ShiftDown && this._selectedField < this._fields.Length - 1)
                                {
                                    this.StepRight();
                                }
                                else if (kevt.ShiftDown && this._selectedField > 0)
                                {
                                    this.StepLeft();
                                }
                                else
                                {
                                    Window next = null;
                                    if (kevt.ShiftDown)
                                        next = this._textCtrl.GetPreviousWindow();
                                    else
                                        next = this._textCtrl.GetNextWindow();
                                    if (next == null)
                                        this.SelectField(0);
                                    else
                                        next.SetFocusFromKbd();
                                }
                            }
                            break;
                        case (int)KeyCode.WXK_RETURN: this.StepRight(); break;
                        case (int)KeyCode.WXK_NUMPAD_ENTER: this.StepRight(); break;
                        case (int)KeyCode.WXK_HOME: this.StepToFirstField(); break;
                        case (int)KeyCode.WXK_NUMPAD_HOME: this.StepToFirstField(); break;
                        case (int)KeyCode.WXK_END: this.StepToLastField(); break;
                        case (int)KeyCode.WXK_NUMPAD_END: this.StepToLastField(); break;
                        case (int)KeyCode.WXK_DELETE: this.DeleteField(); break;
                        case (int)KeyCode.WXK_BACK:     this.DeleteChar();      break;
                        case (int)KeyCode.WXK_DOWN:     this.DownInField();     break;
                        case (int)'-': this.DownInField(); break;
                        case (int)KeyCode.WXK_NUMPAD_DOWN: this.DownInField(); break;
                        case (int)KeyCode.WXK_NUMPAD_SUBTRACT: this.DownInField(); break;
                        case (int)KeyCode.WXK_UP: this.UpInField(); break;
                        case (int)'+': this.UpInField(); break;
                        case (int)KeyCode.WXK_NUMPAD_UP: this.UpInField(); break;
                        case (int)KeyCode.WXK_NUMPAD_ADD: this.UpInField(); break;
                        case (int)KeyCode.WXK_PAGEDOWN: this.PageDownInField(); break;
                        case (int)KeyCode.WXK_NUMPAD_PAGEDOWN: this.PageDownInField(); break;
                        case (int)KeyCode.WXK_PAGEUP: this.PageUpInField(); break;
                        case (int)KeyCode.WXK_NUMPAD_PAGEUP: this.PageUpInField(); break;
                        case (int)KeyCode.WXK_RIGHT: this.StepRight(); break;
                        case (int)KeyCode.WXK_NUMPAD_RIGHT: this.StepRight(); break;
                        case (int)KeyCode.WXK_LEFT: this.StepLeft(); break;
                        case (int)KeyCode.WXK_NUMPAD_LEFT: this.StepLeft(); break;
                        default:
                            {
                                // this is not a special key but a standard text input.
                                char newChar = kevt.UnicodeChar;
                                if (newChar > 0 && !char.IsControl(newChar))
                                {
                                    if (current.AddChar(newChar))
                                        ++this._charsAddedToSelectedField;
                                }
                                this.RefreshValue();
                                int reselect = this._selectedField;
                                if (this._charsAddedToSelectedField >= current.MaxWidth)
                                {
                                    if (this._selectedField < this._fields.Length - 1)
                                        reselect += 1;
                                    else
                                        reselect = 0;
                                }
                                this.SelectField(reselect);
                            }
                            break;
                    }
                }
            }
        }
        #endregion

        #region Internal Interfaces
        /** <summary>This will be called by fields on rejecting input.</summary>*/
        internal void ShowError(EditField field, string message)
        {
            Utils.Bell();
            this._textCtrl.ToolTip = message;
            Log.LogError(message);
        }

        /** <summary>Return expanded copy of <c>textMask</c> referring to info from <c>fields</c> and update of positions in the <c>fields</c>.</summary>*/
        static public string ExpandText(string textMask, params EditField[] fields)
        {
            if (fields != null && fields.Length > 0)
            {
                SortedList<int, int> posToIndex = new SortedList<int, int>();
                for (int i = 0; i < fields.Length; ++i)
                {
                    string wildcard = string.Format("{{{0}}}", i);
                    int posInTextMask=textMask.IndexOf(wildcard);
                    while (posInTextMask >= 0)
                    {
                        posToIndex.Add(posInTextMask, i);
                        posInTextMask = textMask.IndexOf(wildcard, posInTextMask+1);
                    }
                }
                string result = textMask;
                int offset = 0;
                foreach (KeyValuePair<int, int> posIndexPair in posToIndex)
                {
                    int i = posIndexPair.Value;
                    int pos = posIndexPair.Key + offset;
                    EditField f = fields[i];
                    string ftext = f.TextValue;
                    result = result.Substring(0, pos) + ftext + result.Substring(pos + 3);
                    offset += ftext.Length - 3;

                    f._posStart = pos;
                    f._posEnd = pos + ftext.Length;
                }
                return result;
            }
            else
                return "";
        }

        /** <summary>Select field <c>i</c> provided that ExpandText() has been done.</summary>*/
        public void SelectField(int i)
        {
            EditField f=this._fields[i];
            this._textCtrl.InsertionPoint = f._posStart;
            this._textCtrl.SetSelection(f._posStart, f._posEnd);
            if (i != this._selectedField)
            {
                this._selectedField = i;
                this._charsAddedToSelectedField = 0;
                this._textCtrl.ToolTip = f.TooltipText;
            }
        }
        #endregion

        #region Public Properties
        /** <summary>Number of fields.
         *</summary>*/
        public int Count { get { return this._fields.Length; } }

        /** <summary>Gets the field of index <c>i</c>.
         * Negative numbers will count the fields from the end. So, -1 designates the
         * last edit field.</summary>*/
        public EditField this[int i]
        {
            get
            {
                if (i < 0)
                    i += this.Count;
                return this._fields[i];
            }
        }

        /** <summary>The text mask defining the format of the input.</summary>*/
        public string TextMask
        {
            get { return this._textMask; }
        }
        #endregion

        #region IEnumerable Member

        public System.Collections.IEnumerator GetEnumerator()
        {
            return this._fields.GetEnumerator();
        }

        #endregion
    }

    /** <summary>This is a masked edit control.
     * Define a number of instances of EditField and a string mask.
     * </summary>
     */
    public class MaskedEdit : TextCtrl
    {
        #region State
        MaskedEditService _maskedEdit;
        #endregion

        #region CTor
        /** <summary>CTor creating a masked edit of the provided fields. Note, that <c>textMask</c> has to be compatible to the number of fields.
         * If you tell this edit to process ENTER, the ENTER key will proceed from the currently selected field to the next field.
         * </summary>
         * <param name="textMask"> is the text mask for the input. Like  format strings, the mask contains "{0}" and similar wildcards for each
         *        fields. The mask has to provide a wildcard fo each field. Otherwise, this CTor will raise a <c>FormatException</c>.
         *        </param>
         * <param name="fields"> is an array of field definitions containing an element for each input value. Note, that the provided instances
         *        will be used to hold the values. So, you may refer directly to these instances rather than to the provided indexer.
         *        Please note, that fields should be provided in the order that shall define the action on pressing HOME, END, Cursor Left, and
         *        Cursor Right.
         *        </param>
         * 
         */
        public MaskedEdit(Window parent, int id, System.Drawing.Point pos, System.Drawing.Size size, WindowStyles style,
            string textMask,
            params EditField[] fields)
            : base(parent, id, MaskedEditService.ExpandText(textMask, fields), pos, size, style | WindowStyles.TE_RICH2 /*| WindowStyles.TE_PROCESS_ENTER*/)
        {
            this._maskedEdit = new MaskedEditService(this, textMask, fields);
        }

        /** <summary>CTor creating a masked edit of the provided fields. Note, that <c>textMask</c> has to be compatible to the number of fields.
         * </summary>
         * <param name="textMask"> is the text mask for the input. Like  format strings, the mask contains "{0}" and similar wildcards for each
         *        fields. The mask has to provide a wildcard fo each field. Otherwise, this CTor will raise a <c>FormatException</c>.
         *        </param>
         * <param name="fields"> is an array of field definitions containing an element for each input value. Note, that the provided instances
         *        will be used to hold the values. So, you may refer directly to these instances rather than to the provided indexer.
         *        Please note, that fields should be provided in the order that shall define the action on pressing HOME, END, Cursor Left, and
         *        Cursor Right.
         *        </param>
         */
        public MaskedEdit(Window parent, System.Drawing.Point pos, System.Drawing.Size size, WindowStyles style,
            string textMask,
            params EditField[] fields)
            : this(parent, -1, pos, size, style, textMask, fields)
        {
        }

        /** <summary>CTor creating a masked edit of the provided fields. Note, that <c>textMask</c> has to be compatible to the number of fields.
         * </summary>
         * <param name="textMask"> is the text mask for the input. Like  format strings, the mask contains "{0}" and similar wildcards for each
         *        fields. The mask has to provide a wildcard fo each field. Otherwise, this CTor will raise a <c>FormatException</c>.
         *        </param>
         * <param name="fields"> is an array of field definitions containing an element for each input value. Note, that the provided instances
         *        will be used to hold the values. So, you may refer directly to these instances rather than to the provided indexer.
         *        Please note, that fields should be provided in the order that shall define the action on pressing HOME, END, Cursor Left, and
         *        Cursor Right.
         *        </param>
         */
        public MaskedEdit(Window parent, string textMask, params EditField[] fields)
            : this(parent, -1, wxDefaultPosition, wxDefaultSize, WindowStyles.BORDER_SUNKEN, textMask, fields)
        {
        }
        #endregion

        #region Public Properties
        /** <summary>Number of fields.
         *</summary>*/
        public int Count { get { return this._maskedEdit.Count; } }

        /** <summary>Gets the field of index <c>i</c>.
         * </summary>
         */
        public EditField this[int i]
        {
            get
            {
                return this._maskedEdit[i];
            }
        }
        #endregion
    }

    /** <summary>This class receives a string and a number of separators and will enumerate over all parts of the received string, that are separated by one of the separator.
     * </summary>
     */
    public class Tokenizer : IEnumerator<string>, IEnumerable<string>
    {
        #region State
        string[] _separators;
        string _text;
        string _current = null;
        int _pos = -1;
        #endregion

        #region CTor
        public Tokenizer(string text, params string[] separators)
        {
            this._text=text;
            this._separators=separators;
        }
        #endregion

        #region IEnumerator<string> Member

        public string Current
        {
            get { return this._current; }
        }

        #endregion

        #region IDisposable Member

        public void Dispose()
        {
            this._current = null;
            this._separators = null;
            this._text = null;
        }

        #endregion

        #region IEnumerator Member

        object System.Collections.IEnumerator.Current
        {
            get { return this._current; }
        }

        public bool MoveNext()
        {
            int posFirstSep = int.MaxValue;
            foreach (string separator in this._separators)
            {
                int posSeparator;
                if (this._pos >= 0)
                    posSeparator = this._text.IndexOf(separator, this._pos);
                else
                    posSeparator = this._text.IndexOf(separator);
                if (posSeparator == this._pos)
                    posSeparator += separator.Length; // separator is first substring. the next token will be this first separator.
                if (posSeparator >= 0 && posSeparator < posFirstSep)
                    posFirstSep = posSeparator;
            }
            if (posFirstSep == int.MaxValue)
            {
                if (this._pos >= 0 && this._pos < this._text.Length)
                {
                    this._current = this._text.Substring(this._pos);
                    this._pos = this._text.Length;
                    return true;
                }
                else
                    return false;
            }
            else
            {
                if (this._pos >= 0)
                    this._current = this._text.Substring(this._pos, posFirstSep - this._pos);
                else
                    this._current = this._text.Substring(0, posFirstSep);
                this._pos = posFirstSep;
                return true;
            }
        }

        public void Reset()
        {
            this._pos = -1;
        }

        #endregion

        #region IEnumerable<string> Member

        public IEnumerator<string> GetEnumerator()
        {
            return this;
        }

        #endregion

        #region IEnumerable Member

        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            return this;
        }

        #endregion
    }

    /** <summary>Service class for DateTime input.</summary>
     * <remarks>
     * This will manage a masked input if a DateTime. Configure the mask using
     * the format strings
     * \li \c {dd} specifying the output of the day in month index 1-31,
     * \li \c {ddd} specifying the output of an abbreviated name of the day (like "Mon", "Tue", etc),
     * \li \c {dddd} specifying the output of the full name of the day,
     * \li \c {hh} displays the hour 1-12,
     * \li \c {HH} displays the hour 0-23,
     * \li \c {mm} displays the minutes 0-59,
     * \li \c {MM} displays the month 1-12,
     * \li \c {MMM} displays the abbreviated name of the month,
     * \li \c {MMMM} displays the full name of the month,
     * \li \c {ss} displays the number of seconds,
     * \li \c {tt} displays the AM or PM designator,
     * \li \c {yy} displays the year with two digits,
     * \li \c {yyyy} displays the year with four digits.
     * \li \c %d will be replaced by the short date pattern according to <c>CultureInfo.CurrentCulture.DateTimeFormat.ShortDatePattern</c>.
     * \li \c %D will be replaced by the long date pattern according to <c>CultureInfo.CurrentCulture.DateTimeFormat.LongDatePattern</c>.
     * \li \c %t will be replaced by the short time pattern according to <c>CultureInfo.CurrentCulture.DateTimeFormat.ShortTimePattern</c>.
     * \li \c %T will be replaced by the long time pattern according to <c>CultureInfo.CurrentCulture.DateTimeFormat.LongTimePattern</c>.
     * \li \c %f is equivalent to "%D %t"
     * \li \c %F is defined with respect to <c>CultureInfo.CurrentCulture.DateTimeFormatInfo.FullDateTimePattern</c>
     * \li \c %g is equivalent to "%d %t"
     * \li \c %G is equivalent to "%d %T"
     * \li \c %M is defined with respect to <c>CultureInfo.CurrentCulture.DateTimeFormatInfo.MonthDayPattern</c>
     * \li \c %Y is defined with respect to <c>CultureInfo.CurrentCulture.DateTimeFormatInfo.YearMonthPattern</c>
     * 
     * This will use string from the definition of the current culture <c>CultureInfo.CurrentCulture.DateTimeFormat</c>.
     * The current  wxWidgets locale does not influence this.
     * </remarks>
     */
    internal class MaskedDateTimeEditService
    {
        #region State
        MaskedEditService _edit;
        DateTime? _minValue;
        DateTime? _maxValue;
        DateTime? _currentValue;
        bool _allowNull;
        #endregion

        #region Static Helper
        /** <summary>This will return the edit field for wildcard <c>c</c> and <c>cardinality</c>.
         * Example: "yyyy" => <c>c</c>='y', <c>cardinality</c>=4 => "{yyyy}".</summary>*/
        static string EditWildcard(char c, int cardinality)
        {
            bool found = true;
            switch (c)
            {
                case 'y': if (cardinality < 4) cardinality = 2; else cardinality = 4; break;
                case 'd': if (cardinality <= 2) cardinality = 2; else if (cardinality <= 3) cardinality = 3; else cardinality = 4; break;
                case 'M': if (cardinality <= 2) cardinality = 2; else if (cardinality <= 3) cardinality = 3; else cardinality = 4; break;
                case 'h': cardinality = 2; break;
                case 'H': cardinality = 2; break;
                case 'm': cardinality = 2; break;
                case 's': cardinality = 2; break;
                case 't': cardinality = 2; break;
                default: found = false; break;
            }
            if (found)
                return "{" + new string(c, cardinality) + "}";
            else
                return new string(c, cardinality);
        }

        /** <summary>Turns a standard date mask for example from <c>System.Globalization.CultureInfo.CurrentCulture.DateTimeFormat.ShortDatePattern</c> into a string mask for this control.
         * Sample: "yyyyMMdd" => "{yyyy}{MM}{dd}".</summary>*/
        internal static string StdMaskToEditMask(string stdMask)
        {
            System.Text.StringBuilder newMask=new System.Text.StringBuilder();
            char c='\0';
            int num = 0;
            for (int i = 0; i < stdMask.Length; ++i)
            {
                char foundNewFunktionC = '\0';
                // the current character belongs to a wildcard
                switch (stdMask[i])
                {
                    case 'y': foundNewFunktionC = stdMask[i]; break;
                    case 'h': foundNewFunktionC = stdMask[i]; break;
                    case 'M': foundNewFunktionC = stdMask[i]; break;
                    case 'm': foundNewFunktionC = stdMask[i]; break;
                    case 'H': foundNewFunktionC = stdMask[i]; break;
                    case 'd': foundNewFunktionC = stdMask[i]; break;
                    case 't': foundNewFunktionC = stdMask[i]; break;
                    case 's': foundNewFunktionC = stdMask[i]; break;
                    default:
                        break;
                }

                if (c != '\0' && c == foundNewFunktionC)
                    ++num; // this is the same wildcard as the previous character.
                else
                {
                    if (c != '\0')
                    {
                        // we changed the wild card likd in yyyyMMdd
                        // or wildcard in <c> now comes to an end.
                        newMask.Append(EditWildcard(c, num));
                    }
                    c = foundNewFunktionC;
                    if (c == '\0')
                        num = 0;
                    else
                        num = 1;
                }
                if (foundNewFunktionC=='\0')
                    newMask.Append(stdMask[i]);
            }
            if (c != '\0' && num > 0)
                newMask.Append(EditWildcard(c, num));
            return newMask.ToString();
        }

        /** <summary>This will return an AM designator even iff the current culture does not define one.</summary>*/
        public static string AMDesignator
        {
            get
            {
                string amDesignator = System.Globalization.DateTimeFormatInfo.CurrentInfo.AMDesignator;
                if (amDesignator.Length == 0)
                    amDesignator = "a.m."; // even if the culture does not know this, the control has to be able to display it
                return amDesignator;
            }
        }

        /** <summary>This will return an AM designator even iff the current culture does not define one.</summary>*/
        public static string PMDesignator
        {
            get
            {
                string pmDesignator = System.Globalization.DateTimeFormatInfo.CurrentInfo.PMDesignator;
                if (pmDesignator.Length == 0)
                    pmDesignator = "p.m."; // even if the culture does not know this, the control has to be able to display it
                return pmDesignator;
            }
        }

        /** <summary>Turns .NET standard mask into an edit mask as used by the DateTime mask edit control.</summary>*/
        internal static string StdMasksToEditMask(string stdMask)
        {
            stdMask = stdMask.Replace("%g", "%d %t");
            stdMask = stdMask.Replace("%G", "%d %T");
            stdMask = stdMask.Replace("%f", "%D %t");
            stdMask = stdMask.Replace("%d", StdMaskToEditMask(System.Globalization.CultureInfo.CurrentCulture.DateTimeFormat.ShortDatePattern));
            stdMask = stdMask.Replace("%D", StdMaskToEditMask(System.Globalization.CultureInfo.CurrentCulture.DateTimeFormat.LongDatePattern));
            stdMask = stdMask.Replace("%t", StdMaskToEditMask(System.Globalization.CultureInfo.CurrentCulture.DateTimeFormat.ShortTimePattern));
            stdMask = stdMask.Replace("%T", StdMaskToEditMask(System.Globalization.CultureInfo.CurrentCulture.DateTimeFormat.LongTimePattern));
            stdMask = stdMask.Replace("%F", StdMaskToEditMask(System.Globalization.CultureInfo.CurrentCulture.DateTimeFormat.FullDateTimePattern));
            stdMask = stdMask.Replace("%M", StdMaskToEditMask(System.Globalization.CultureInfo.CurrentCulture.DateTimeFormat.MonthDayPattern));
            stdMask = stdMask.Replace("%Y", StdMaskToEditMask(System.Globalization.CultureInfo.CurrentCulture.DateTimeFormat.YearMonthPattern));
            return stdMask;
        }

        /** <summary>This will add a prefix to the string form of <c>number</c> consisting of <c>emptyChar</c> in such a way that the result is of length <c>length</c>.</summary>*/
        static string IntToString(int length, char emptyChar, int number)
        {
            string str = number.ToString();
            if (str.Length >= length)
                return str;
            else
                return (new string(emptyChar, length - str.Length)) + str;
        }

        /** <summary>Produces a string output of <c>data</c> according to a format string that is compatible to the format specifications of this control.
         * This expand the following format strings using <c>data</c>:
         * \li \c {dd} specifying the output of the day in month index 1-31,
         * \li \c {ddd} specifying the output of an abbreviated name of the day (like "Mon", "Tue", etc),
         * \li \c {dddd} specifying the output of the full name of the day,
         * \li \c {hh} displays the hour 1-12,
         * \li \c {HH} displays the hour 0-23,
         * \li \c {mm} displays the minutes 0-59,
         * \li \c {MM} displays the month 1-12,
         * \li \c {MMM} displays the abbreviated name of the month,
         * \li \c {MMMM} displays the full name of the month,
         * \li \c {ss} displays the number of seconds,
         * \li \c {tt} displays the AM or PM designator,
         * \li \c {yy} displays the year with two digits,
         * \li \c {yyyy} displays the year with four digits.
         * \li \c %d will be replaced by the short date pattern according to <c>CultureInfo.CurrentCulture.DateTimeFormat.ShortDatePattern</c>.
         * \li \c %D will be replaced by the long date pattern according to <c>CultureInfo.CurrentCulture.DateTimeFormat.LongDatePattern</c>.
         * \li \c %t will be replaced by the short time pattern according to <c>CultureInfo.CurrentCulture.DateTimeFormat.ShortTimePattern</c>.
         * \li \c %T will be replaced by the long time pattern according to <c>CultureInfo.CurrentCulture.DateTimeFormat.LongTimePattern</c>.
         * \li \c %f is equivalent to "%D %t"
         * \li \c %F is defined with respect to <c>CultureInfo.CurrentCulture.DateTimeFormatInfo.FullDateTimePattern</c>
         * \li \c %g is equivalent to "%d %t"
         * \li \c %G is equivalent to "%d %T"
         * \li \c %M is defined with respect to <c>CultureInfo.CurrentCulture.DateTimeFormatInfo.MonthDayPattern</c>
         * \li \c %Y is defined with respect to <c>CultureInfo.CurrentCulture.DateTimeFormatInfo.YearMonthPattern</c></summary>*/
        public static string ExpandFormatString(string formatString, DateTime data)
        {
            formatString = StdMasksToEditMask(formatString);
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            Tokenizer tokens = new Tokenizer(formatString,
                    "{yyyy}", "{yy}", "{MM}", "{MMM}", "{MMMM}", "{mm}", "{hh}", "{HH}", "{ss}", "{tt}", "{dd}", "{ddd}", "{dddd}"
                );
            foreach (string token in tokens)
            {
                if (token == "{yyyy}")
                    sb.Append(IntToString(4, '0', data.Year));
                else if (token == "{yy}")
                    sb.Append((data.Year % 100).ToString());
                else if (token == "{MM}")
                    sb.Append(IntToString(2, '0', data.Month));
                else if (token == "{MMM}")
                    sb.Append(System.Globalization.CultureInfo.CurrentCulture.DateTimeFormat.AbbreviatedMonthNames[data.Month - 1]);
                else if (token == "{MMMM}")
                    sb.Append(System.Globalization.CultureInfo.CurrentCulture.DateTimeFormat.MonthNames[data.Month - 1]);
                else if (token == "{dd}")
                    sb.Append(IntToString(2, '0', data.Day));
                else if (token == "{ddd}")
                    sb.Append(System.Globalization.CultureInfo.CurrentCulture.DateTimeFormat.AbbreviatedDayNames[(int)data.DayOfWeek]);
                else if (token == "{dddd}")
                    sb.Append(System.Globalization.CultureInfo.CurrentCulture.DateTimeFormat.DayNames[(int)data.DayOfWeek]);
                else if (token == "{HH}")
                    sb.Append(IntToString(2, '0', data.Hour));
                else if (token == "{hh}")
                {
                    int hh = data.Hour % 12;
                    if (hh == 0)
                        hh = 12;
                    sb.Append(IntToString(2, '0', hh));
                }
                else if (token == "{mm}")
                    sb.Append(IntToString(2, '0', data.Minute));
                else if (token == "{ss}")
                    sb.Append(IntToString(2, '0', data.Second));
                else if (token == "{tt}")
                {
                    if (data.Hour >= 1 && data.Hour <= 12)
                        sb.Append(AMDesignator);
                    else
                        sb.Append(PMDesignator);
                }
                else
                    sb.Append(token);
            }
            return sb.ToString();
        }

        /** <summary>This will transform a <c>DateTimeFormatInfo</c> format string into a format string applicable to this.
         * This will always use the current culture info for text patterns.
         * 
         * This will create</summary>*/
        void CreateMaskEdit(TextCtrl textCtrl, string stdMask)
        {
            stdMask = StdMasksToEditMask(stdMask);

            System.Text.StringBuilder newMask=new System.Text.StringBuilder();
            Tokenizer tokens = new Tokenizer(stdMask,
                    "{yyyy}", "{yy}", "{MM}", "{MMM}", "{MMMM}", "{mm}", "{hh}", "{HH}", "{ss}", "{tt}", "{dd}", "{ddd}", "{dddd}"
                );
            List<EditField> fields = new List<EditField>();
            foreach (string token in tokens)
            {
                if (token=="{yyyy}")
                {
                    int index = fields.Count;
                    EditIntField newField = EditIntField.New("yyyy");
                    if (this._minValue != null && this._minValue.HasValue && this._maxValue != null && this._maxValue.HasValue)
                        newField = newField.SetIn(this._minValue.Value.Year, this._maxValue.Value.Year);
                    else if (this._minValue != null && this._minValue.HasValue)
                        newField = newField.SetIn(this._minValue.Value.Year, int.MaxValue);
                    else if (this._maxValue != null && this._maxValue.HasValue)
                        newField = newField.SetIn(int.MinValue, this._maxValue.Value.Year);
                    newField = newField.SetWidth(4);
                    if (this._allowNull)
                        newField.SetEmptyChar('_');
                    else
                        newField.SetEmptyChar('0');
                    if (this._currentValue != null && this._currentValue.HasValue)
                        newField.Value = this._currentValue.Value.Year;
                    newField.DisplayName = Window._("This is the calendar year in 4 digit representation.");
                    fields.Add(newField);
                    newField.OnChanged += new MaskedEditFieldValueChangedHandler(this.OnEditValueChanged);
                    newField.OnChanging += new MaskedEditFieldValueChangingHandler(this.OnChangingLongYear);
                    newMask.Append("{" + index.ToString() + "}");
                }
                else if (token == "{yy}")
                {
                    int index = fields.Count;
                    EditIntField newField = EditIntField.New("yy");
                    newField = newField.SetWidth(2);
                    if (this._allowNull)
                        newField.SetEmptyChar('_');
                    else
                        newField.SetEmptyChar('0');
                    newField.DisplayName = Window._("This is the year in the current century in 2 digit representation.");
                    if (this._minValue != null && this._minValue.HasValue
                        && this._maxValue != null && this._maxValue.HasValue
                        && this._maxValue.Value.Year / 100 == this._minValue.Value.Year / 100)
                    {
                        newField = newField.SetIn(this._minValue.Value.Year % 100, this._maxValue.Value.Year % 100);
                    }
                    if (this._currentValue != null && this._currentValue.HasValue)
                        newField.Value = this._currentValue.Value.Year % 100;
                    fields.Add(newField);
                    newField.OnChanged += new MaskedEditFieldValueChangedHandler(this.OnEditValueChanged);
                    newField.OnChanging += new MaskedEditFieldValueChangingHandler(this.OnChangingShortYear);
                    newMask.Append("{" + index.ToString() + "}");
                }
                else if (token=="{MM}")
                {
                    int index = fields.Count;
                    EditIntField newField = EditIntField.New("MM");
                    newField = newField.SetWidth(2);
                    if (this._allowNull)
                        newField.SetEmptyChar('_');
                    else
                        newField.SetEmptyChar('0');
                    newField.DisplayName = Window._("This is the calendar month in 2 digit representation.");
                    if (this._minValue != null && this._minValue.HasValue
                        && this._maxValue != null && this._maxValue.HasValue
                        && this._maxValue.Value.Year == this._minValue.Value.Year)
                    {
                        newField = newField.SetIn(this._minValue.Value.Month, this._maxValue.Value.Month);
                    }
                    else
                        newField = newField.SetIn(1, 12);
                    if (this._currentValue != null && this._currentValue.HasValue)
                        newField.Value = this._currentValue.Value.Month;
                    fields.Add(newField);
                    newField.OnChanged += new MaskedEditFieldValueChangedHandler(this.OnEditValueChanged);
                    newField.OnChanging += new MaskedEditFieldValueChangingHandler(this.OnChangingMonthIndex);
                    newField.OnOverflow += new EditIntField.OverflowEventHandler(this.OnOverflowField);
                    newField.OnUnderflow += new EditIntField.UnderflowEventHandler(this.OnUnderflowField);
                    newMask.Append("{" + index.ToString() + "}");
                }
                else if (token=="{MMM}")
                {
                    int index = fields.Count;
                    StringEditField newField = StringEditField.New("MMM");
                    if (this._minValue != null && this._minValue.HasValue
                        && this._maxValue != null && this._maxValue.HasValue
                        && this._maxValue.Value.Year == this._minValue.Value.Year)
                    {
                        string[] selectedMonths = new string[this._maxValue.Value.Month - this._minValue.Value.Month];
                        System.Globalization.CultureInfo.CurrentCulture.DateTimeFormat.AbbreviatedMonthNames.CopyTo(selectedMonths, this._minValue.Value.Month - 1);
                        newField = newField.SetChoices(selectedMonths);
                    }
                    else
                    {
                        newField = newField.SetChoices(
                            System.Globalization.CultureInfo.CurrentCulture.DateTimeFormat.AbbreviatedMonthNames
                            );
                    }
                    if (this._currentValue != null && this._currentValue.HasValue)
                        newField.SetTextValue(System.Globalization.CultureInfo.CurrentCulture.DateTimeFormat.AbbreviatedMonthNames[this._currentValue.Value.Month - 1]);
                    newField.DisplayName = Window._("This is the abbreviated name of the month.");
                    fields.Add(newField);
                    newField.OnChanged += new MaskedEditFieldValueChangedHandler(this.OnEditValueChanged);
                    newField.OnChanging += new MaskedEditFieldValueChangingHandler(this.OnChangingMonthAbbrev);
                    newMask.Append("{" + index.ToString() + "}");
                }
                else if (token=="{MMMM}")
                {
                    int index = fields.Count;
                    StringEditField newField = StringEditField.New("MMMM");
                    if (this._minValue != null && this._minValue.HasValue
                        && this._maxValue != null && this._maxValue.HasValue
                        && this._maxValue.Value.Year == this._minValue.Value.Year)
                    {
                        string[] selectedMonths = new string[this._maxValue.Value.Month - this._minValue.Value.Month];
                        System.Globalization.CultureInfo.CurrentCulture.DateTimeFormat.MonthNames.CopyTo(selectedMonths, this._minValue.Value.Month - 1);
                        newField = newField.SetChoices(selectedMonths);
                    }
                    else
                    {
                        newField = newField.SetChoices(
                            System.Globalization.CultureInfo.CurrentCulture.DateTimeFormat.MonthNames
                            );
                    }
                    if (this._currentValue != null && this._currentValue.HasValue)
                        newField.SetTextValue(System.Globalization.CultureInfo.CurrentCulture.DateTimeFormat.MonthNames[this._currentValue.Value.Month - 1]);
                    fields.Add(newField);
                    newField.DisplayName = Window._("This is the full name of the month.");
                    newField.OnChanged += new MaskedEditFieldValueChangedHandler(this.OnEditValueChanged);
                    newField.OnChanging += new MaskedEditFieldValueChangingHandler(this.OnChangingMonthName);
                    newMask.Append("{" + index.ToString() + "}");
                }
                else if (token=="{dd}")
                {
                    int index = fields.Count;
                    EditIntField newField = EditIntField.New("dd");
                    newField = newField.SetWidth(2);
                    if (this._allowNull)
                        newField.SetEmptyChar('_');
                    else
                        newField.SetEmptyChar('0');
                    if (this._minValue != null && this._minValue.HasValue
                        && this._maxValue != null && this._maxValue.HasValue
                        && this._maxValue.Value.Year == this._minValue.Value.Year)
                    {
                        newField = newField.SetIn(this._minValue.Value.Month, this._maxValue.Value.Month);
                    }
                    else
                        newField = newField.SetIn(1, 31);
                    if (this._currentValue != null && this._currentValue.HasValue)
                    {
                        newField.Value = this._currentValue.Value.Day;
                        newField.MaxValue = DateTime.DaysInMonth(this._currentValue.Value.Year, this._currentValue.Value.Month);
                    }
                    fields.Add(newField);
                    newField.OnChanged += new MaskedEditFieldValueChangedHandler(this.OnEditValueChanged);
                    newField.OnChanging += new MaskedEditFieldValueChangingHandler(this.OnChangingDayInMonth);
                    newField.OnOverflow += new EditIntField.OverflowEventHandler(this.OnOverflowField);
                    newField.OnUnderflow += new EditIntField.UnderflowEventHandler(this.OnUnderflowField);
                    newMask.Append("{" + index.ToString() + "}");
                }
                else if (token=="{ddd}")
                {
                    int index = fields.Count;
                    StringEditField newField = StringEditField.New("ddd");
                    if (this._minValue != null && this._minValue.HasValue
                        && this._maxValue != null && this._maxValue.HasValue
                        && this._maxValue.Value == this._minValue.Value)
                    {
                        string[] selectedMonths = new string[this._maxValue.Value.Month - this._minValue.Value.Month];
                        System.Globalization.CultureInfo.CurrentCulture.DateTimeFormat.AbbreviatedDayNames.CopyTo(selectedMonths, (int)this._minValue.Value.DayOfWeek);
                        newField = newField.SetChoices(selectedMonths);
                    }
                    else
                    {
                        newField = newField.SetChoices(
                            System.Globalization.CultureInfo.CurrentCulture.DateTimeFormat.AbbreviatedDayNames
                            );
                    }
                    if (this._currentValue != null && this._currentValue.HasValue)
                        newField.SetTextValue(System.Globalization.CultureInfo.CurrentCulture.DateTimeFormat.AbbreviatedDayNames[(int)this._currentValue.Value.DayOfWeek]);
                    fields.Add(newField);
                    newField.OnChanged += new MaskedEditFieldValueChangedHandler(this.OnEditValueChanged);
                    newField.OnChanging += new MaskedEditFieldValueChangingHandler(this.OnChangingAbbrvDayOfWeek);
                    newMask.Append("{" + index.ToString() + "}");
                }
                else if (token=="{dddd}")
                {
                    int index = fields.Count;
                    StringEditField newField = StringEditField.New("dddd");
                    if (this._minValue != null && this._minValue.HasValue
                        && this._maxValue != null && this._maxValue.HasValue
                        && this._maxValue.Value == this._minValue.Value)
                    {
                        string[] selectedDays = new string[this._maxValue.Value.DayOfWeek - this._minValue.Value.DayOfWeek];
                        System.Globalization.CultureInfo.CurrentCulture.DateTimeFormat.DayNames.CopyTo(selectedDays, (int)this._minValue.Value.DayOfWeek);
                        newField = newField.SetChoices(selectedDays);
                    }
                    else
                    {
                        newField = newField.SetChoices(
                            System.Globalization.CultureInfo.CurrentCulture.DateTimeFormat.DayNames
                            );
                    }
                    if (this._currentValue != null && this._currentValue.HasValue)
                        newField.SetTextValue(System.Globalization.CultureInfo.CurrentCulture.DateTimeFormat.DayNames[(int)this._currentValue.Value.DayOfWeek]);
                    fields.Add(newField);
                    newField.OnChanged += new MaskedEditFieldValueChangedHandler(this.OnEditValueChanged);
                    newField.OnChanging += new MaskedEditFieldValueChangingHandler(this.OnChangingDayOfWeek);
                    newMask.Append("{" + index.ToString() + "}");
                }
                else if (token=="{HH}")
                {
                    int index = fields.Count;
                    EditIntField newField = EditIntField.New("HH");
                    newField = newField.SetWidth(2);
                    if (this._allowNull)
                        newField.SetEmptyChar('_');
                    else
                        newField.SetEmptyChar('0');
                    newField = newField.SetIn(0, 23);
                    if (this._currentValue != null && this._currentValue.HasValue)
                    {
                        newField.Value = this._currentValue.Value.Hour;
                    }
                    fields.Add(newField);
                    newField.OnChanged += new MaskedEditFieldValueChangedHandler(this.OnEditValueChanged);
                    newField.OnChanging += new MaskedEditFieldValueChangingHandler(this.OnChangingHour24);
                    newMask.Append("{" + index.ToString() + "}");
                }
                else if (token=="{hh}")
                {
                    int index = fields.Count;
                    EditIntField newField = EditIntField.New("hh");
                    newField = newField.SetWidth(2);
                    if (this._allowNull)
                        newField.SetEmptyChar('_');
                    else
                        newField.SetEmptyChar('0');
                    newField = newField.SetIn(1, 12);
                    if (this._currentValue != null && this._currentValue.HasValue)
                    {
                        int newValue = this._currentValue.Value.Hour % 12;
                        if (newValue == 0)
                            newValue = 12;
                        newField.Value = newValue;
                    }
                    fields.Add(newField);
                    newField.OnChanged += new MaskedEditFieldValueChangedHandler(this.OnEditValueChanged);
                    newField.OnChanging += new MaskedEditFieldValueChangingHandler(this.OnChangingHour12);
                    newMask.Append("{" + index.ToString() + "}");
                }
                else if (token=="{mm}")
                {
                    int index = fields.Count;
                    EditIntField newField = EditIntField.New("mm");
                    newField = newField.SetWidth(2);
                    if (this._allowNull)
                        newField.SetEmptyChar('_');
                    else
                        newField.SetEmptyChar('0');
                    newField = newField.SetIn(0, 59);
                    if (this._currentValue != null && this._currentValue.HasValue)
                    {
                        newField.Value = this._currentValue.Value.Minute;
                    }
                    fields.Add(newField);
                    newField.OnChanged += new MaskedEditFieldValueChangedHandler(this.OnEditValueChanged);
                    newField.OnChanging += new MaskedEditFieldValueChangingHandler(this.OnChangingMinute);
                    newMask.Append("{" + index.ToString() + "}");
                }
                else if (token=="{ss}")
                {
                    int index = fields.Count;
                    EditIntField newField = EditIntField.New("ss");
                    newField = newField.SetWidth(2);
                    if (this._allowNull)
                        newField.SetEmptyChar('_');
                    else
                        newField.SetEmptyChar('0');
                    newField = newField.SetIn(0, 59);
                    if (this._currentValue != null && this._currentValue.HasValue)
                    {
                        newField.Value = this._currentValue.Value.Minute;
                    }
                    fields.Add(newField);
                    newField.OnChanged += new MaskedEditFieldValueChangedHandler(this.OnEditValueChanged);
                    newField.OnChanging += new MaskedEditFieldValueChangingHandler(this.OnChangingSeconds);
                    newMask.Append("{" + index.ToString() + "}");
                }
                else if (token=="{tt}")
                {
                    int index = fields.Count;
                    StringEditField newField = StringEditField.New("tt");

                    string amDesignator = AMDesignator;
                    string pmDesignator = PMDesignator;
                    newField.SetChoices(new string[] { amDesignator, pmDesignator });
                    if (this._currentValue != null && this._currentValue.HasValue)
                    {
                        if (this._currentValue.Value.Hour >= 12)
                            newField.SetTextValue(pmDesignator);
                        else
                            newField.SetTextValue(amDesignator);
                    }
                    fields.Add(newField);
                    newField.OnChanged += new MaskedEditFieldValueChangedHandler(this.OnEditValueChanged);
                    newField.OnChanging += new MaskedEditFieldValueChangingHandler(this.OnChangingTT);
                    newMask.Append("{" + index.ToString() + "}");
                    
                }
                else
                    newMask.Append(token);
            }
            this._edit = new MaskedEditService(textCtrl, newMask.ToString(), fields.ToArray());
        }
        #endregion

        #region Events
        /** <summary>This will be called immediately after the value has been changed.</summary>*/
        public event DateTimeValueChangedEventHandler OnValueChanged;

        /** <summary>Writes the current value into the fields.
         * \param protected is a field that will not be updated</summary>*/ 
        void UpdateFieldValues(EditField protectedField)
        {
            if (this._currentValue == null || !this._currentValue.HasValue)
            {
                foreach (EditField field in this._edit)
                {
                    if (protectedField != field)
                    {
                        field.SetTextValue("");
                    }
                }
            }
            else
            {
                foreach (EditField field in this._edit)
                {
                    if (protectedField != field)
                    {
                        string newValue = this._currentValue.Value.ToString(field.Name);
                        if (newValue.Length == 0 && field.Name == "tt")
                        {
                            // a.m. and p.m. are only in some cultures defined. most others do not know them.
                            // however, this shall worl always.
                            if (this._currentValue.Value.Hour <= 12)
                                newValue = AMDesignator;
                            else
                                newValue = PMDesignator;
                        }
                        field.SetTextValue(newValue);
                        this.ResetCurrentValue();
                    }
                }
            }
        }

        bool _onEditValueRecursion = false;
        /** <summary>Will update all filds if one changed.</summary>*/
        void OnEditValueChanged(object sender, MaskedEditFieldValueChangedEvent evt)
        {
            if (!this._onEditValueRecursion)
            {
                try
                {
                    this._onEditValueRecursion = true;
                    this.UpdateFieldValues(evt.Field);
                }
                finally
                {
                    this._onEditValueRecursion = false;
                }

                if (this.OnValueChanged != null)
                {
                    this.OnValueChanged(this, new DateTimeValueChangedEvent(this._currentValue));
                }
            }
        }

        /** <summary>Helper to find a standard for the current value of required but not set.</summary>*/
        void ResetCurrentValue()
        {
            if (this._currentValue == null || !this._currentValue.HasValue)
            {
                this._currentValue = DateTime.Now;
            }
            if (this._minValue != null && this._minValue.HasValue && this._minValue > this._currentValue)
                this._currentValue = this._minValue;
            if (this._maxValue != null && this._maxValue.HasValue && this._maxValue < this._currentValue)
                this._currentValue = this._maxValue;
        }

        /** <summary>Called on overflow in day/month input.</summary>*/
        void OnOverflowField(object sender, EditIntField.OverflowEvent evt)
        {
            if (this.Value != null && this.Value.HasValue)
            {
                if (evt.Field.Name == "dd"
                    || evt.Field.Name == "ddd"
                    || evt.Field.Name == "ddd")
                {
                    DateTime newTarget = this.Value.Value;
                    newTarget = newTarget.AddDays(-newTarget.Day + 1).AddMonths(1);
                    if (newTarget < this._maxValue)
                        this.Value = newTarget;
                }
                else if (evt.Field.Name == "MM"
                    || evt.Field.Name == "MMM"
                    || evt.Field.Name == "MMMM")
                {
                    DateTime newTarget = this.Value.Value;
                    newTarget = newTarget.AddYears(1).AddMonths(1 - newTarget.Month);
                    if (newTarget < this._maxValue)
                        this.Value = newTarget;
                }
            }
        }

        /** <summary>Called on overflow in day/month input.</summary>*/
        void OnUnderflowField(object sender, EditIntField.UnderflowEvent evt)
        {
            if (this.Value != null && this.Value.HasValue)
            {
                if (evt.Field.Name == "dd"
                    || evt.Field.Name == "ddd"
                    || evt.Field.Name == "ddd")
                {
                    DateTime newTarget = this.Value.Value;
                    newTarget = newTarget.AddDays(-1);
                    if (newTarget > this._minValue)
                        this.Value = newTarget;
                }
                else if (evt.Field.Name == "MM"
                    || evt.Field.Name == "MMM"
                    || evt.Field.Name == "MMMM")
                {
                    DateTime newTarget = this.Value.Value;
                    newTarget = newTarget.AddYears(-1).AddMonths(12-newTarget.Month);
                    if (newTarget > this._minValue)
                        this.Value = newTarget;
                }
            }
        }

        /** <summary>Called if a field on the full year has changed.</summary>*/
        void OnChangingLongYear(object sender, MaskedEditFieldValueChangingEvent evt)
        {
            if (evt.ChangedNewValue == null)
            {
                this._currentValue = null;
            }
            else
            {
                // we add the distance to the current year. So, we let DateTime deal with leap days here.
                this.ResetCurrentValue();
                this._currentValue = this._currentValue.Value.AddYears((int)evt.ChangedNewValue - this._currentValue.Value.Year);
                this.ResetCurrentValue();
                evt.Change(this._currentValue.Value.Year);
            }
        }

        /** <summary>Called if a field on the final two digits of the year has changed.</summary>*/
        void OnChangingShortYear(object sender, MaskedEditFieldValueChangingEvent evt)
        {
            if (evt.ChangedNewValue == null)
            {
                this._currentValue = null;
            }
            else
            {
                this.ResetCurrentValue();
                int diff = ((int)evt.ChangedNewValue % 100)-(this._currentValue.Value.Year % 100);
                if (diff < -50)
                    diff += 100;
                else if (diff > 50)
                    diff -= 100;
                this._currentValue = this._currentValue.Value.AddYears(diff);
                this.ResetCurrentValue();
                evt.Change(this._currentValue.Value.Year % 100);
            }
        }

        void OnChangingMonthIndex(object sender, MaskedEditFieldValueChangingEvent evt)
        {
            if (evt.ChangedNewValue == null)
            {
                this._currentValue = null;
            }
            else
            {
                this.ResetCurrentValue();
                int diff = (int)evt.ChangedNewValue - this._currentValue.Value.Month;
                if (diff < -6)
                    diff += 12;
                else if (diff > 6)
                    diff -= 12;
                this._currentValue = this._currentValue.Value.AddMonths(diff);
                this.ResetCurrentValue();
                evt.Change(this._currentValue.Value.Month);
            }
        }

        static int FindInArray(string[] arr, string val)
        {
            for (int index = 0; index < arr.Length; ++index)
            {
                if (arr[index] == val)
                    return index;
            }
            return -1;
        }

        void OnChangingMonthAbbrev(object sender, MaskedEditFieldValueChangingEvent evt)
        {
            if (evt.ChangedNewValue == null)
            {
                this._currentValue = null;
            }
            else
            {
                this.ResetCurrentValue();
                int index = FindInArray(System.Globalization.DateTimeFormatInfo.CurrentInfo.AbbreviatedMonthNames, (string)evt.ChangedNewValue);
                if (index >= 0)
                {
                    int diff = index + 1 - this._currentValue.Value.Month;
                    if (diff < -6)
                        diff += 12;
                    else if (diff > 6)
                        diff -= 7;
                    this._currentValue = this._currentValue.Value.AddMonths(diff);
                    this.ResetCurrentValue();
                }
                evt.Change(this._currentValue.Value.ToString("MMM"));
            }
        }

        void OnChangingMonthName(object sender, MaskedEditFieldValueChangingEvent evt)
        {
            if (evt.ChangedNewValue == null)
            {
                this._currentValue = null;
            }
            else
            {
                this.ResetCurrentValue();
                int index = FindInArray(System.Globalization.DateTimeFormatInfo.CurrentInfo.MonthNames, (string)evt.ChangedNewValue);
                if (index >= 0)
                {
                    int diff = index + 1 - this._currentValue.Value.Month;
                    if (diff < -6)
                        diff += 12;
                    else if (diff > 6)
                        diff -= 7;
                    this._currentValue=this._currentValue.Value.AddMonths(diff);
                    this.ResetCurrentValue();
                }
                evt.Change(this._currentValue.Value.ToString("MMMM"));
            }
        }

        void OnChangingDayInMonth(object sender, MaskedEditFieldValueChangingEvent evt)
        {
            if (evt.ChangedNewValue == null)
            {
                this._currentValue = null;
            }
            else
            {
                this.ResetCurrentValue();
                int dayIndex = (int)evt.ChangedNewValue;
                int monthOffset = 0;
                int diff = dayIndex - this._currentValue.Value.Day;
                if (diff < -15)
                    monthOffset = 1;
                else if (diff > 15)
                    monthOffset = -1;
                this._currentValue = this._currentValue.Value.AddDays(diff).AddMonths(monthOffset);
                this.ResetCurrentValue();
                evt.Change(this._currentValue.Value.Day);
            }
        }

        void OnChangingDayOfWeek(object sender, MaskedEditFieldValueChangingEvent evt)
        {
            if (evt.ChangedNewValue == null)
            {
                this._currentValue = null;
            }
            else
            {
                this.ResetCurrentValue();
                int index = FindInArray(System.Globalization.DateTimeFormatInfo.CurrentInfo.DayNames, (string)evt.ChangedNewValue);
                if (index >= 0)
                {
                    int diff = index - (int)this._currentValue.Value.DayOfWeek;
                    if (diff < -3)
                        diff += 7;
                    if (diff > 3)
                        diff -= 7;
                    this._currentValue = this._currentValue.Value.AddDays(diff);
                    this.ResetCurrentValue();
                }
            }
        }

        void OnChangingAbbrvDayOfWeek(object sender, MaskedEditFieldValueChangingEvent evt)
        {
            if (evt.ChangedNewValue == null)
            {
                this._currentValue = null;
            }
            else
            {
                this.ResetCurrentValue();
                int index = FindInArray(System.Globalization.DateTimeFormatInfo.CurrentInfo.AbbreviatedDayNames, (string)evt.ChangedNewValue);
                if (index >= 0)
                {
                    int diff = index - (int)this._currentValue.Value.DayOfWeek;
                    if (diff < -3)
                        diff += 7;
                    if (diff > 3)
                        diff -= 7;
                    this._currentValue = this._currentValue.Value.AddDays(diff);
                    this.ResetCurrentValue();
                }
            }
        }

        void OnChangingTT(object sender, MaskedEditFieldValueChangingEvent evt)
        {
            if (evt.ChangedNewValue == null)
            {
                this._currentValue = null;
            }
            else
            {
                this.ResetCurrentValue();
                if (AMDesignator.Equals(evt.ChangedNewValue))
                {
                    if (this._currentValue.Value.Hour > 12)
                        this._currentValue = this._currentValue.Value.AddHours(-12);
                }
                else
                {
                    if (this._currentValue.Value.Hour <= 12)
                        this._currentValue = this._currentValue.Value.AddHours(12);
                }
                this.ResetCurrentValue();
            }
        }

        void OnChangingHour24(object sender, MaskedEditFieldValueChangingEvent evt)
        {
            if (evt.ChangedNewValue == null)
            {
                this._currentValue = null;
            }
            else
            {
                this.ResetCurrentValue();
                int hh = (int)evt.ChangedNewValue;
                int diff = hh - this._currentValue.Value.Hour;
                if (diff < -12)
                    diff += 24;
                if (diff > 12)
                    diff -= 24;
                this._currentValue = this._currentValue.Value.AddHours(diff);
                this.ResetCurrentValue();
            }
        }

        void OnChangingHour12(object sender, MaskedEditFieldValueChangingEvent evt)
        {
            if (evt.ChangedNewValue == null)
            {
                this._currentValue = null;
            }
            else
            {
                this.ResetCurrentValue();
                int hh = (int)evt.ChangedNewValue;
                int diff = this._currentValue.Value.Hour % 12;
                diff = -diff;
                diff += hh;
                if (diff < -6)
                    diff += 12;
                if (diff > 6)
                    diff -= 12;
                this._currentValue = this._currentValue.Value.AddHours(diff);
                this.ResetCurrentValue();
            }
        }

        void OnChangingMinute(object sender, MaskedEditFieldValueChangingEvent evt)
        {
            if (evt.ChangedNewValue == null)
            {
                this._currentValue = null;
            }
            else
            {
                this.ResetCurrentValue();
                int mm = (int)evt.ChangedNewValue;
                int diff = mm - this._currentValue.Value.Minute;
                if (diff < -30)
                    diff += 60;
                if (diff > 30)
                    diff -= 60;
                this._currentValue = this._currentValue.Value.AddMinutes(diff);
                this.ResetCurrentValue();
            }
        }


        void OnChangingSeconds(object sender, MaskedEditFieldValueChangingEvent evt)
        {
            if (evt.ChangedNewValue == null)
            {
                this._currentValue = null;
            }
            else
            {
                this.ResetCurrentValue();
                int ss = (int)evt.ChangedNewValue;
                int diff = ss - this._currentValue.Value.Second;
                if (diff < -30)
                    diff += 60;
                if (diff > 30)
                    diff -= 60;
                this._currentValue = this._currentValue.Value.AddSeconds(diff);
                this.ResetCurrentValue();
            }
        }
        #endregion

        #region Public Helpers
        /** <summary>Select the edit field of the provided index.</summary>*/
        public void Select(int i)
        {
            this._edit.SelectField(i);
        }

        /** <summary>Returns the index of the edit field that is as near as possible to the provided text position.</summary>*/
        public int GetNearest(int textPosition)
        {
            return this._edit.NearestField(textPosition);
        }

        /** <summary>Returns the index of the edit field that is as near as possible to the provided window position.</summary>*/
        public int GetNearest(System.Drawing.Point position)
        {
            return this._edit.NearestField(position);
        }
        #endregion

        #region Properties
        /** <summary>Get or set the current value.
         * This may be <c>null</c> of this allows empty input.</summary>*/
        public DateTime? Value
        {
            get
            {
                return this._currentValue;
            }
            set
            {
                this._currentValue = value;
                this.ResetCurrentValue();
                this.UpdateFieldValues(null);
                this._edit.RefreshValue();

                if (this.OnValueChanged != null)
                    this.OnValueChanged(this, new DateTimeValueChangedEvent(this._currentValue));
            }
        }

        /** <summary>Returns the text mask defining the format of the text presentation.</summary>*/
        public string TextMask
        {
            get { return this._edit.TextMask; }
        }

        /** <summary>Directly calls this method of the masked edit.
         * Refer to MaskedEditService.OnChar().</summary>*/
        public void OnChar(object sender, Event evt)
        {
            this._edit.OnChar(sender, evt);
        }

        /** <summary>Returns the number of input fields.</summary>*/
        public int Count { get { return this._edit.Count; } }

        /** <summary>Returns the edit field at the provided position.
         * Use a number between 0 and this.Count. Otherwise, this will raise exceptions.
         * Negative numbers will count the fields from the end. So, -1 designates the
         * last edit field.</summary>*/
        public EditField this[int i] { get { return this._edit[i]; } }
        #endregion

        #region CTor
        /** <summary>* \param ctrl is the text control that will be used for input.
         * \param startValue is the optional initial value.
         * \param mask is the string mask. This may be an arbitrary string with format specifiers as listed in the
         *        documentation of this class (in curly brackets).
         * \param minValue is optional minimal acceptable value.
         * \param maxValue is optional maximal acceptable value.
         * \param allowNull is true if the user may defer or abort input.</summary>*/
        public MaskedDateTimeEditService(TextCtrl ctrl, DateTime? startValue, string mask, DateTime? minValue, DateTime? maxValue, bool allowNull)
        {
            this._allowNull=allowNull;
            this._minValue=minValue;
            this._maxValue=maxValue;
            if (!this._allowNull && (startValue== null || !startValue.HasValue))
                startValue = DateTime.Today;
            if (this._minValue != null && this._minValue.HasValue && startValue != null && startValue.HasValue && startValue < this._minValue)
                startValue = this._minValue;
            if (this._maxValue != null && this._maxValue.HasValue && startValue != null && startValue.HasValue && startValue > this._maxValue)
                startValue = this._maxValue;
            this._currentValue = startValue;

            this.CreateMaskEdit(ctrl, mask);
        }
        #endregion
    }

    /** <summary>This is a masked edit control for DateTime input.
     * This will manage a masked input if a DateTime.
     * </summary>
     * <remarks>
     * Configure the mask using
     * the format strings
     * \li \c {dd} specifying the output of the day in month index 1-31,
     * \li \c {ddd} specifying the output of an abbreviated name of the day (like "Mon", "Tue", etc),
     * \li \c {dddd} specifying the output of the full name of the day,
     * \li \c {hh} displays the hour 1-12,
     * \li \c {HH} displays the hour 0-23,
     * \li \c {mm} displays the minutes 0-59,
     * \li \c {MM} displays the month 1-12,
     * \li \c {MMM} displays the abbreviated name of the month,
     * \li \c {MMMM} displays the full name of the month,
     * \li \c {ss} displays the number of seconds,
     * \li \c {tt} displays the AM or PM designator,
     * \li \c {yy} displays the year with two digits,
     * \li \c {yyyy} displays the year with four digits.
     * \li \c %d will be replaced by the short date pattern according to <c>CultureInfo.CurrentCulture.DateTimeFormat.ShortDatePattern</c>.
     * \li \c %D will be replaced by the long date pattern according to <c>CultureInfo.CurrentCulture.DateTimeFormat.LongDatePattern</c>.
     * \li \c %t will be replaced by the short time pattern according to <c>CultureInfo.CurrentCulture.DateTimeFormat.ShortTimePattern</c>.
     * \li \c %T will be replaced by the long time pattern according to <c>CultureInfo.CurrentCulture.DateTimeFormat.LongTimePattern</c>.
     * \li \c %f is equivalent to "%D %t"
     * \li \c %F is defined with respect to <c>CultureInfo.CurrentCulture.DateTimeFormatInfo.FullDateTimePattern</c>
     * \li \c %g is equivalent to "%d %t"
     * \li \c %G is equivalent to "%d %T"
     * \li \c %M is defined with respect to <c>CultureInfo.CurrentCulture.DateTimeFormatInfo.MonthDayPattern</c>
     * \li \c %Y is defined with respect to <c>CultureInfo.CurrentCulture.DateTimeFormatInfo.YearMonthPattern</c>
     * 
     * This will use string from the definition of the current culture <c>CultureInfo.CurrentCulture.DateTimeFormat</c>.
     * The current  wxWidgets locale does not influence this.
     * </remarks>
     */
    public class DateTimeEdit : TextCtrl
    {
        #region State
        MaskedDateTimeEditService _maskedEdit;
        #endregion

        #region CTor
        /** <summary>CTor creating a <c>DateTime</c> edit.
         * \param startValue is an optional value that will be displayed on start.
         * \param textMask is a string containing format characters according to the class documentation, e.g. "%d". Refer to
         *                 the documentation of the class for further remarks on this.
         * \param minValue is an optional lower bound or the input.
         * \param maxValue is an optional upper bound of the input.
         * \param allowNull indicates with <c>true</c> that this may return a <c>null</c>, i.e. that the input is optional.
         * \param style this will accept all styles that also fit wx.TextCtrl. We recomment <c>wx.WindowStyles.BORDER_SUNKEN</c>.
         * 
         * If you tell this edit to process ENTER, the ENTER key will proceed from the currently selected field to the next field.</summary>*/
        public DateTimeEdit(Window parent, int id, System.Drawing.Point pos, System.Drawing.Size size, WindowStyles style,
            DateTime? startValue, string textMask, DateTime? minValue, DateTime? maxValue, bool allowNull)
            : base(parent, id, textMask, pos, size, style | WindowStyles.TE_RICH2)
        {
            this._maskedEdit = new MaskedDateTimeEditService(this, startValue, textMask, minValue, maxValue, allowNull);
            this._maskedEdit.OnValueChanged+=new DateTimeValueChangedEventHandler(this.RaiseOnValueChanged);
        }

        /** <summary>CTor creating a <c>DateTime</c> edit.
         * \param startValue is an optional value that will be displayed on start.
         * \param textMask is a string containing format characters according to the class documentation, e.g. "%d". Refer to
         *                 the documentation of the class for further remarks on this.
         * \param minValue is an optional lower bound or the input.
         * \param maxValue is an optional upper bound of the input.
         * \param allowNull indicates with <c>true</c> that this may return a <c>null</c>, i.e. that the input is optional.
         * 
         * If you tell this edit to process ENTER, the ENTER key will proceed from the currently selected field to the next field.</summary>*/
        public DateTimeEdit(Window parent, System.Drawing.Point pos, System.Drawing.Size size, WindowStyles style,
            DateTime? startValue, string textMask, DateTime? minValue, DateTime? maxValue, bool allowNull)
            : this(parent, -1, pos, size, style, startValue, textMask, minValue, maxValue, allowNull)
        {
        }

        /** <summary>CTor creating a <c>DateTime</c> edit reading a date in localized standard format.
         * \param startValue is an optional value that will be displayed on start.</summary>*/
        public DateTimeEdit(Window parent, DateTime startValue)
            : this(parent, -1, wxDefaultPosition, wxDefaultSize, WindowStyles.BORDER_SUNKEN, startValue, "%d", null, null, false)
        {
        }
        #endregion

        #region Events
        /** <summary>This event fires after changing the value of this control.</summary>*/
        public DateTimeValueChangedEventHandler OnValueChanged;

        void RaiseOnValueChanged(object sender, DateTimeValueChangedEvent evt)
        {
            if (this.OnValueChanged != null)
                this.OnValueChanged(this, evt);
        }
        #endregion

        #region Public Helpers
        /** <summary>Select the edit field of the provided index.</summary>*/
        public void Select(int i)
        {
            this._maskedEdit.Select(i);
        }

        /** <summary>Returns the index of the edit field that is as near as possible to the provided text position.</summary>*/
        public int GetNearest(int textPosition)
        {
            return this._maskedEdit.GetNearest(textPosition);
        }

        /** <summary>Returns the index of the edit field that is as near as possible to the provided window position.</summary>*/
        public int GetNearest(System.Drawing.Point position)
        {
            return this._maskedEdit.GetNearest(position);
        }
        #endregion

        #region Public Properties
        /** <summary>Get or set the value.
         * The result may be <c>null</c> if this allows empt input.</summary>*/
        new public DateTime? Value
        {
            get
            {
                return this._maskedEdit.Value;
            }
            set
            {
                this._maskedEdit.Value = value;
            }
        }

        /** <summary>Returns the text mask defining the format of the text presentation.</summary>*/
        public string TextMask
        {
            get { return this._maskedEdit.TextMask; }
        }

        /** <summary>Directly calls this method of the masked edit.
         * Refer to MaskedEditService.OnChar().</summary>*/
        public void OnChar(object sender, Event evt)
        {
            this._maskedEdit.OnChar(sender, evt);
        }

        /** <summary>Returns the number of input fields.</summary>*/
        public int Count { get { return this._maskedEdit.Count; } }

        /** <summary>Returns the edit field at the provided position.
         * Use a number between 0 and this.Count. Otherwise, this will raise exceptions.
         * Negative numbers will count the fields from the end. So, -1 designates the
         * last edit field.</summary>*/
        public EditField this[int i] { get { return this._maskedEdit[i]; } }

        #endregion
    }
}
