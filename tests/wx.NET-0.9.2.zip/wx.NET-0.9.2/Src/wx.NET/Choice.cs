//-----------------------------------------------------------------------------
// wx.NET - Choice.cs
//
// The wxChoice wrapper class.
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: Choice.cs,v 1.25 2010/05/08 19:51:26 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Collections;
using System.Drawing;
using System.Runtime.InteropServices;

namespace wx
{
	public class Choice : ControlWithItems
	{
		#region C API
		[DllImport("wx-c")] static extern IntPtr wxChoice_ctor();
        [DllImport("wx-c")] [return: MarshalAs(UnmanagedType.U1)]
        static extern bool wxChoice_Create(IntPtr self, IntPtr parent, int id, int x, int y, int w, int h, IntPtr choices, uint style, IntPtr validator, IntPtr name);
		[DllImport("wx-c")] static extern void   wxChoice_dtor(IntPtr self);

		[DllImport("wx-c")] static extern void   wxChoice_SetColumns(IntPtr self, int n);
		[DllImport("wx-c")] static extern int    wxChoice_GetColumns(IntPtr self);

		[DllImport("wx-c")] static extern void   wxChoice_Command(IntPtr self, IntPtr evt);

        [DllImport("wx-c")] static extern int wxChoice_GetCurrentSelection(IntPtr self);
		#endregion

        //---------------------------------------------------------------------
		
		#region CTor
		public Choice(IntPtr wxObject) 
			: base(wxObject) {}

        static IntPtr LockedCTor()
        {
            lock (DllSync)
            {
                return wxChoice_ctor();
            }
        }
        
        protected override void CallDTor ()
        {
        	wxChoice_dtor(this.wxObject);
        }


		public Choice()
			: base(LockedCTor()) { }

		public Choice(Window parent, int id)
			: this(parent, id, wxDefaultPosition, wxDefaultSize, new string[] { }, wx.WindowStyles.NO_STYLE, null) { }

		public Choice(Window parent, int id, Point pos, Size size, string[] choices)
			: this(parent, id, pos, size, choices, wx.WindowStyles.NO_STYLE, null) { }

        /** <summary>Refer to prefix <c>CB_</c> for especially applicable style flags.</summary>*/
        public Choice(Window parent, int id, Point pos, Size size, string[] choices, wx.WindowStyles style)
			: this(parent, id, pos, size, choices, style, null) { }

        /** <summary>Refer to prefix <c>CB_</c> for especially applicable style flags.</summary>*/
        public Choice(Window parent, int id, Point pos, Size size, 
					  string[] choices, wx.WindowStyles style, string name)
            : this(parent, id, pos, size, ArrayString.SafeNewFrom(choices), style, new wxString(name))
        {
        }

        internal Choice(Window parent, int id, Point pos, Size size,
                      ArrayString choices, wx.WindowStyles style, wxString name)
			: base(LockedCTor())
		{
			if(!wxChoice_Create(this.wxObject, Object.SafePtr(parent), id, pos.X, pos.Y, size.Width, size.Height,
								Object.SafePtr(choices), (uint)style, 
								IntPtr.Zero, name.wxObject))
			{
				throw new InvalidOperationException("Failed to create ListBox");
			}
		}
		
		//---------------------------------------------------------------------
		// ctors with self created id
		
		public Choice(Window parent)
			: this(parent, Window.UniqueID, wxDefaultPosition, wxDefaultSize, new string[] { }, wx.WindowStyles.NO_STYLE, null) { }

		public Choice(Window parent, Point pos, Size size, string[] choices)
			: this(parent, Window.UniqueID, pos, size, choices, wx.WindowStyles.NO_STYLE, null) { }

		public Choice(Window parent, Point pos, Size size, string[] choices, wx.WindowStyles style)
			: this(parent, Window.UniqueID, pos, size, choices, style, null) { }

		public Choice(Window parent, Point pos, Size size, string[] choices, wx.WindowStyles style, string name)
			: this(parent, Window.UniqueID, pos, size, choices, style, name) {}
		
		//---------------------------------------------------------------------

		public bool Create(Window parent, int id, Point pos, Size size, string[] choices, wx.WindowStyles style, string name)
		{
            return this.Create(parent, id, pos, size, ArrayString.SafeNewFrom(choices), style, new wxString(name));
        }
        public bool Create(Window parent, int id, Point pos, Size size, ArrayString choices, wx.WindowStyles style, wxString name)
        {
            return wxChoice_Create(wxObject, Object.SafePtr(parent), id,
								   pos.X, pos.Y, size.Width, size.Height, Object.SafePtr(choices), 
								   (uint)style, IntPtr.Zero, name.wxObject);
		}
		#endregion
		//---------------------------------------------------------------------

		public int Columns
		{
			get { return wxChoice_GetColumns(wxObject); }
			set { wxChoice_SetColumns(wxObject, value); }
		}
		
		//---------------------------------------------------------------------

		public void Command(Event evt)
		{
			wxChoice_Command(wxObject, Object.SafePtr(evt));
		}
				
		//---------------------------------------------------------------------

        /** <summary>Read-only property returning the index of the current selection.
         * Unlike ControlWithItems.Selection() which only returns the accepted selection value,
         * i.e. the selection in the control once the user closes the dropdown
         * list, this function returns the current selection. That is, while
         * the dropdown list is shown, it returns the currently selected item
         * in it. When it is not shown, its result is the same as for the other
         * function.
         *</summary>*/
        public int CurrentSelection
        {
            get
            {
                return wxChoice_GetCurrentSelection(this.wxObject);
            }
        }
		
		//-----------------------------------------------------------------------------
				        
		public event EventListener Selected
		{
			add { AddCommandListener(Event.wxEVT_COMMAND_CHOICE_SELECTED, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}
	}
}
