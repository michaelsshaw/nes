/**
 * wx.NET Project
 * 
 * \file 
 * 
 * Attributes allowing for translations in attributes.
 * 
 * Written by Dr. Harald Meyer auf'm Hofe (C) 2008 
 * Licensed under the wxWidgets license, see LICENSE.txt for details.
 *
 * $Id: maskedcell.cs,v 1.4 2009/09/20 14:10:58 harald_meyer Exp $
 */

using System;
using wx;
using wx.GridCtrl;
using wx.MaskedEdit;

namespace wx.GridCtrl
{
    namespace Editors
    {
        /** <summary>Input of DateTime values using the wx.MaskedEdit.DateTimeCtrl.
         * This will expect the grid model to store the natural string forms of System.DateTime
         * values.
         * 
         * Refer to wx.GridCtrl.Renderers.GridCellDateTimeMaskRenderer for a compatible renderer.</summary>*/
        public class GridCellDateTimeEditor : wx.GridCtrl.Editors.GridCellEditor
        {
            #region State
            string _textMask;
            DateTimeEdit _ctrl=null;
            DateTime _min;
            DateTime _max;
            bool _allowNull;
            #endregion

            #region CTor
            public GridCellDateTimeEditor(string textMask, DateTime min, DateTime max, bool allowNull)
            {
                this._textMask=textMask;
                this._min = min;
                this._max = max;
                this._allowNull = allowNull;
            }
            #endregion

            public override void Create(Window parent, int id, EvtHandler evtHandler)
            {
                this._ctrl = new DateTimeEdit(parent, Window.wxDefaultPosition, Window.wxDefaultSize, WindowStyles.NO_STYLE,
                    null, this._textMask, this._min, this._max, this._allowNull);
                this.SetControl(this._ctrl);
                if (evtHandler != null)
                    this._ctrl.PushEventHandler(evtHandler);
            }

            /** <summary>Returns the input control.</summary>*/
            public DateTimeEdit InputCtrl
            {
                get
                {
                    return this._ctrl;
                }
            }

            public override void StartingKey(KeyEvent e)
            {
                DateTimeEdit ctrl = this.InputCtrl;
                if (ctrl != null)
                {
                    ctrl.OnChar(this, e);
                }
            }

            /* Normalize size of the control.
             * This is a port of the \e wxWidgets source.
             */
            public override void SetSize(System.Drawing.Rectangle rect)
            {
                if (ReflectConfig.CheckWxGTK())
                {
                    if (rect.X != 0)
                    {
                        rect.X += 1;
                        rect.Y += 1;
                        rect.Width -= 1;
                        rect.Height -= 1;
                    }
                }
                else if (ReflectConfig.CheckWxMSW())
                {
                    /* This has been taken from the string editor of 2.8.7.
                     * however, this does not seem to be necessary by now (2.8.9.)
                    if (rect.X == 0)
                        rect.X += 2;
                    else
                        rect.X += 3;

                    if (rect.Y == 0)
                        rect.Y += 2;
                    else
                        rect.Y += 3;
                    */
                    rect.Width += 2;
                    rect.Height += 2;
                }
                else
                {
                    int extra_x = (rect.X > 2) ? 2 : 1;
                    int extra_y = (rect.Y > 2) ? 2 : 1;


                    rect.X = rect.X < extra_x ? 0 : rect.X - extra_x;
                    rect.Y = rect.Y < extra_y ? 0 : rect.Y - extra_y;
                    rect.Width += 2 * extra_x;
                    rect.Height += 2 * extra_y;
                }

                base.SetSize(rect);
            }
              
            public override void BeginEdit(int row, int col, Grid grid)
            {
                DateTimeEdit ctrl = this.InputCtrl;
                string valString = grid.GetCellValue(row, col);
                ctrl.Value = DateTime.Parse(valString);
                ctrl.SetFocus();
                ctrl.Select(0);
            }

            public override bool EndEdit(int row, int col, Grid grid)
            {
                string valString = grid.GetCellValue(row, col);
                DateTime gridValue = DateTime.Parse(valString);
                DateTimeEdit ctrl = this.InputCtrl;
                if (ctrl.Value != gridValue)
                {
                    grid.SetCellValue(row, col, ctrl.Value.ToString());
                    return true;
                }
                else
                    return false;
            }

            public override void Reset()
            {
            }

            public override GridCellEditor Clone()
            {
                return new GridCellDateTimeEditor(this._textMask, this._min, this._max, this._allowNull);
            }
        }
    }

    namespace Renderers
    {
        /** <summary>Renders DateTime data compatbile to wx.GridCtrl.Editors.GridCellDateTimeEditor.</summary>
         * <remarks>
         * This expand the following format strings using <c>data</c>:
         * \li \c {dd} specifying the output of the day in month index 1-31,
         * \li \c {ddd} specifying the output of an abbreviated name of the day (like "Mon", "Tue", etc),
         * \li \c {dddd} specifying the output of the full name of the day,
         * \li \c {hh} displays the hour 1-12,
         * \li \c {HH} displays the hour 0-23,
         * \li \c {mm} displays the minutes 0-59,
         * \li \c {MM} displays the month 1-12,
         * \li \c {MMM} displays the abbreviated name of the month,
         * \li \c {MMMM} displays the full name of the month,
         * \li \c {ss} displays the number of seconds,
         * \li \c {tt} displays the AM or PM designator,
         * \li \c {yy} displays the year with two digits,
         * \li \c {yyyy} displays the year with four digits.
         * \li \c %d will be replaced by the short date pattern according to <c>CultureInfo.CurrentCulture.DateTimeFormat.ShortDatePattern</c>.
         * \li \c %D will be replaced by the long date pattern according to <c>CultureInfo.CurrentCulture.DateTimeFormat.LongDatePattern</c>.
         * \li \c %t will be replaced by the short time pattern according to <c>CultureInfo.CurrentCulture.DateTimeFormat.ShortTimePattern</c>.
         * \li \c %T will be replaced by the long time pattern according to <c>CultureInfo.CurrentCulture.DateTimeFormat.LongTimePattern</c>.
         * \li \c %f is equivalent to "%D %t"
         * \li \c %F is defined with respect to <c>CultureInfo.CurrentCulture.DateTimeFormatInfo.FullDateTimePattern</c>
         * \li \c %g is equivalent to "%d %t"
         * \li \c %G is equivalent to "%d %T"
         * \li \c %M is defined with respect to <c>CultureInfo.CurrentCulture.DateTimeFormatInfo.MonthDayPattern</c>
         * \li \c %Y is defined with respect to <c>CultureInfo.CurrentCulture.DateTimeFormatInfo.YearMonthPattern</c>
         * </remarks>
         */
        public class GridCellDateTimeMaskRenderer : GridCellRenderer
        {
            #region State
            string _format;
            #endregion

            /** <summary>Creates a renderer showing data in the provided format.
             * refer to the class documentation.
             * </summary>
             */
            public GridCellDateTimeMaskRenderer(string format)
            {
                this._format = format;
            }

            /** <summary>returns the format string.
             * </summary>
             */
            public string Format { get { return this._format; } }

            /** <summary>Creates a string from <c>data</c> using the format string <c>Format</c>.
             * </summary>
             */
            public string DateTimeToString(DateTime data)
            {
                return MaskedEdit.MaskedDateTimeEditService.ExpandFormatString(this._format, data);
            }

            public override void  Draw(Grid grid, GridCellAttr attr, DC dc, System.Drawing.Rectangle rect, int row, int col, bool isSelected)
            {
                DateTime currentData=DateTime.Parse(grid.GetCellValue(row, col));
                string newString=this.DateTimeToString(currentData);
                dc.BackgroundMode = DCBackgroundMode.SOLID;
                dc.Brush = Brush.TheBrushList.FindOrCreateBrush(attr.BackgroundColour, Brush.Styles.SOLID);
                dc.Pen = Pen.ThePenList.FindOrCreatePen(attr.BackgroundColour, 1, Pen.Styles.SOLID);
                dc.DrawRectangle(rect);
                dc.Font = attr.Font;
                dc.TextForeground = attr.TextColour;
                dc.TextBackground = attr.BackgroundColour;
                dc.BackgroundMode = DCBackgroundMode.SOLID;
                dc.DrawText(newString, rect.X + 1, rect.Y + 1);
            }

            public override System.Drawing.Size  GetBestSize(Grid grid, GridCellAttr attr, DC dc, int row, int col)
            {
                DateTime currentData = DateTime.Parse(grid.GetCellValue(row, col));
                string newString = this.DateTimeToString(currentData);
                System.Drawing.Size extent=dc.GetTextExtent(newString, attr.Font);
                return new System.Drawing.Size(extent.Width + 2, extent.Height + 2);
            }

            public override GridCellRenderer  Clone()
            {
 	            return new GridCellDateTimeMaskRenderer(this._format);
            }
        }
    }
}
