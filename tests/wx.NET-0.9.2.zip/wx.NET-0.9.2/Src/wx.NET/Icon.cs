//-----------------------------------------------------------------------------
// wx.NET - Icon.cs
//
// The wxIcon wrapper class.
//
// Written by Jason Perkins (jason@379.com)
// (C) 2003 by 379, Inc.
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: Icon.cs,v 1.15 2009/09/20 14:10:58 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Reflection;
using System.Runtime.InteropServices;

namespace wx
{
	public class Icon : Bitmap
	{
		[DllImport("wx-c")] static extern IntPtr wxIcon_ctor();
		[DllImport("wx-c")] static extern void   wxIcon_CopyFromBitmap(IntPtr self, IntPtr bitmap);
		[DllImport("wx-c")] static extern bool   wxIcon_LoadFile(IntPtr self, IntPtr name, BitmapType type);

		//---------------------------------------------------------------------

        /** <summary>CTor for ZipResource support.</summary>
         * <remarks>
         * This will load an image <c>resourceName</c> from ZipResource file or directory <c>archiveName</c>.
         * \code
         wx.ZipResource.AddCatalogLookupPrefix(@"..\Utils\MemLogDisplay");
         wx.Icon icon=new wx.Icon("archiveName.zrs", "iconname.png");
         \endcode
         * </remarks>
         */
        public Icon(string archiveName, string resourceName)
            : this()
        {
            Bitmap bmp = new Bitmap(archiveName, resourceName);
            wxIcon_CopyFromBitmap(wxObject, bmp.wxObject);
        }

        /// <summary>This loads the icon from a local file.
        /// This CTor will NOT raise exceptions but display a default icon if the file cannot be loaded.
        /// You may use the CTor requiring a BitmapType to specify alternative ways of loading.</summary>
        /// <param name="name">Filename of the icon to be displayed.</param>
        public Icon(string name)
            : this(name, false)
        {
        }

        /// <summary>This loads the icon from a local file. You may use the CTor requiring a BitmapType to specify alternative ways of loading.</summary>
        /// <param name="name">Filename of the icon to be displayed.</param>
        /// <param name="enableException">Enables with <c>true</c> raising of exceptions if the file has not been found.</param>
        /// <exception cref="System.ArgumentException">Raised if <c>enableExceptions</c> and the icon file cannot be loaded.</exception>
		public Icon(string name, bool enableException)
			: this()
		{
			Image img = new Image();
            Bitmap bmp;
            if (img.LoadFile(name))
                 bmp = new Bitmap(img);
            else
            {
                if (enableException)
                    throw new ArgumentException("file '" + name + "' not found");
                else
                    bmp = ArtProvider.GetBitmap(ArtID.wxART_MISSING_IMAGE);
            }

			wxIcon_CopyFromBitmap(wxObject, bmp.wxObject);
		}

        /** <summary>Loads a bitmap of the provided type.
         * Use wx.BitmapType.wxBITMAP_TYPE_ANY if you have no information on the type
         * of the bitmap. Use wx.BitmapType.wxBITMAP_TYPE_RESOURCE to load a bitmap
         * from the .NET resource named <c>name</c>.
         * </summary>
         */
        public Icon(string name, BitmapType type)
			: this()
		{
			if (type == BitmapType.wxBITMAP_TYPE_RESOURCE)
			{
				Assembly ResourceAssembly = Assembly.GetCallingAssembly();
				
				Image img = new Image(name, ResourceAssembly);
				
				Bitmap bmp = new Bitmap(img);
				wxIcon_CopyFromBitmap(wxObject, bmp.wxObject);
			}
			else
			{
                wxString wxName = wxString.SafeNew(name);
				if (!wxIcon_LoadFile(wxObject, Object.SafePtr(wxName), type))
					throw new ArgumentException();
			}
		}

		/** <summary>Convenience CTor for reading the resource of the provided name from the provided assembly.</summary>*/
		public Icon(string resourceName, Assembly resourceAssembly)
			: this()
		{
			Bitmap bmp=new Bitmap(resourceName, resourceAssembly);
			wxIcon_CopyFromBitmap(wxObject, bmp.wxObject);
		}

		public Icon()
			: base(wxIcon_ctor())
		{
		}
		
		public Icon(IntPtr wxObject) 
			: base(wxObject) { }		

		//---------------------------------------------------------------------

		public void CopyFromBitmap(Bitmap bitmap)
		{
			wxIcon_CopyFromBitmap(wxObject, Object.SafePtr(bitmap));
		}

		//---------------------------------------------------------------------
	}
}
