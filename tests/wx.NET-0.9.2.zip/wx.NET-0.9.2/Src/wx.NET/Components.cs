/**
 * wx.NET Project
 * 
 * \file 
 * 
 * Component model for \e wx-NET.
 * 
 * Written by Dr. Harald Meyer auf'm Hofe (C) 2009
 * Licensed under the wxWidgets license, see LICENSE.txt for details.
 *
 * $Id: Components.cs,v 1.8 2010/07/04 19:05:03 harald_meyer Exp $
 */

using System;
using System.Reflection;
using System.Collections.Generic;
using wx;
using wx.Globalization;

/** \page binding Binding: Linking view layer and application layers
 * 
 * Bridging the gap between the view layer and the control or application layer is
 * one of the key issues of most frameworks for generating user interfaces. The problem
 * is to develop both aspects of the application, GUI and domain logic, independently
 * from each other since the domain logic often has to be reused for instance with other
 * user interfaces while the GUI often needs to be maintained w.r.t. latest options
 * of new operating systems, platforms, multimedia capabilities etc.
 * 
 * Another issue is the complexity of modern user interfaces as well. On the one hand, dependencies
 * between different controls within the same user interface become more and more complex. A selection
 * here causes a selection there, leading to a changed list of options at a third place, and so on
 * and so forth. Consistent update strategies for such controls that are strongly linked due to the
 * visualized domain knowledge are hard to develop. To make things even worse, many applications
 * require more that one user interface for the same purpose. The complexity of the developed
 * user interfaces forces system designers to adopt them to different types of users, that cause
 * sometimes similar actions in the system but have a completely different view on the underlying
 * domain logic.
 * 
 * \e wx.NET is connected either to the \e wxWidgets framework as well as to Microsoft's .NET
 * world that both provide capabilities to more or less separate view layer and application/domain layer.
 * 
 * \e wxWidgets provides on the one hand the \c wxValidator class and its derivations. On the other hand,
 * complex dialogs like the grid and the list control provide specialized interfaces to a domain model.
 * Both means can be used like a glue between application and user interface since they usually achieve a
 * consistency between both offering a standard set of events to cause updates of the other side.
 * 
 * The .NET world uses the term data binding to express the purpose to offer building blocks connecting
 * view to application like binding lists and binding sources. However, these implementations lack a clear
 * concept. There behaviour is often hard to predict.
 * 
 * Therefore, \e wx.NET comes with its own component model, that, however, borrows the best from validators
 * and bindings. The idea of \c wx.ComponentModel is to provide classes representing standard models for the 
 * data and the controls, that provide standard events and interfaces. These models can be plugged together
 * to represent the logical dependencies between them. In such a way, a list control can be programmed to react
 * on the selection in another list without knowing it directly: It knows the relation to an appropriate view model
 * that is linked to the model of the changing list. Thus, only one piece of code knows this relation: The code that
 * builds the configuration of models that represents this dependency. Dynamic interdependencies are represented as
 * a static configuration. This can make things easier.
 * 
 * 
 */


/** The \e wx.NET component model.
 * The component model implements the \e wx.NET means of binding data sources to controls.
 * This concept replaces either the standard .NET component model as well as \e wxWidget's 
 * validator concept.
 * 
 * The motivation of a component model simply is to specify the dynamic dependencies between
 * widgets and the data model by a dependency graph that is generated once but will not change
 * while the widget lives. \e wx.NET implements its own component model since the original implementation
 * can hardly be used (unnecessary complex, errors, unpredictable behaviour) and the interface to the
 * data model - the implemented program logic - makes heavy use of .NET's concepts for reflection.
 * 
 * The idea is, to specify a dependency network consisting of dependency nodes. Terminal nodes are either
 * widgets or instances of data model classes. Both are linked via a third class of dependency nodes:
 * Instances of wx.ComponentModel.DataModel. The arcs between these nodes are implemented by references
 * and events: Each dependency node knows depending nodes and, this, propagates changes of values.
 *
 * Programmers create complex dialogs building an appropriate dependency network first. Then, the leave
 * nodes in this network will be asked for adequate controls using some predefined abstract constructors.
 * These controls will be arranged using sizers. Done!
 * 
 * Refer also to \ref binding
 */
namespace wx.ComponentModel
{
    #region Events
    /** <summary>Event class to indicate a value change.
     * This event is used by all data models to indicate a value change.
     * </summary>
     */
    public class ValueChangedEvent : EventArgs
    {
        object _newValue;
        object _oldValue;

        public ValueChangedEvent(object newValue, object oldValue)
        {
            this._newValue = newValue;
            this._oldValue = oldValue;
        }

        /** <summary>Gets the new value whose assignment raised this event.
         * </summary>
         */
        public object NewValue { get { return this._newValue; } }

        /** <summary>Get the old value that has been replaced by <c>NewValue</c>.
         * Both are equal iff either a data model ends initialization or a data model has been
         * told to propagate its value.
         * </summary>
         */
        public object OldValue { get { return this._oldValue; } }
    }

    /** <summary>Handler of the ValueChangedEvent.
     * </summary>
     */
    public delegate void ValueChangedHandler(object sender, ValueChangedEvent evt);

    /// <summary>
    /// This event indicates the change of a property. this is a specialization of
    /// ValueChangedEvent. The new and the old value property of the instances of this class
    /// are the old and the new value of the changed property.
    /// </summary>
    public class PropertyChangedEvent : ValueChangedEvent
    {
        #region State
        string _propertyName;
        #endregion

        #region CTor
        /// <summary>
        /// Creates an instance.
        /// </summary>
        /// <param name="propertyName">The property that changed.</param>
        /// <param name="newValue">The new value of the property.</param>
        /// <param name="oldValue">The old value of the property.</param>
        public PropertyChangedEvent(string propertyName, object newValue, object oldValue)
            : base(newValue, oldValue)
        {
            this._propertyName = propertyName;
        }
        #endregion

        /// <summary>
        /// The name of the property that changed.
        /// </summary>
        public string PropertyName { get { return this._propertyName; } }
    }

    /// <summary>
    /// Handles a PropertyChangedEvent. A property of the sender has been changed.
    /// </summary>
    /// <param name="sender">The object where a property changed.</param>
    /// <param name="evt">The event data</param>
    public delegate void PropertyChangedHandler(object sender, PropertyChangedEvent evt);
    #endregion

    #region Attributes
    /** <summary>Use this to annotate a property that raises an event on changing its value.
     * Use this in combination with a PropertyModel to declare that the annotated property
     * raises a particular event on changing its value (of type ValueChangedHandler). If you create a property model for
     * such a property, this property model will install itself as a handler of this event.
     * 
     * Usually, property models like field models cannot guarantee to propagate all changes
     * of the managed property or field since they simply will not be informed of a changed value.
     * However, the  wx.NET component model allows for programmers to specify some events that will
     * be fired in case of value change.
     * </summary>
     */
    [AttributeUsage(AttributeTargets.Property)]
    public class RaisesChangeEventAttribute : Attribute
    {
        #region State
        string _eventName;
        #endregion

        #region CTor
        /** <summary>Indicates that the annotated property raises an event named <c>eventName</c> on changing its value.</summary>*/
        public RaisesChangeEventAttribute(string eventName)
        {
            this._eventName = eventName;
        }
        #endregion

        #region Properties
        /** <summary>Name of the event that will be raised on changing the annotated property.</summary>*/
        public string EventName { get { return this._eventName; } }
        #endregion
    }

    /** <summary>This attribute indicates that a property or field shall be visible in a GenericFormPanel.
     * You may declare a neutral name and comment and, if you like, translations of these into specific cultures.
     * These names and remarks will be displayed in the generic field if appropriate. Additionally, you may declare
     * the property as  read  only. You may also assign a criterion for sorting the items in the form.</summary>*/
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class FormItemAttribute : Attribute
    {
        #region State
        StringInCultures _name;
        StringInCultures _comment;
        bool _isReadOnly = false;
        int _sortCriterion = 0;
        #endregion

        #region CTor
        /** <summary>Creates an attribute defining a string that shall be used as a title on presenting the field.</summary><remarks>
         * \param name is the neutral name of the property to be shown in the form if this has not been translated into the current culture.
         * \param comment is the neutral comment of the property to be displayed if a better translation is not available.
         * \param triplesCanonicalNamePlusPropNamePlusComment is a sequence of triples canonical culture name (like "de-DE"), translated
         *        name, translated comment.
         * 
         * Example: Use this to declare a property of a form
         * \code
         class FormData
         {
         [FormItemAttribute("Valuation", "A value to be used for valuation.",
                            "de", "Bewertung", "Ein Wert zur Bewertung.")]
         int _valuation;
         }
         \endcode
         * </remarks>*/
        public FormItemAttribute(string name, string comment, params string[] triplesCanonicalNamePlusPropNamePlusComment)
        {
            List<string> localizedNames = new List<string>();
            List<string> localizedComments = new List<string>();

            if (triplesCanonicalNamePlusPropNamePlusComment != null)
            {
                for (int pos = 0; pos < triplesCanonicalNamePlusPropNamePlusComment.Length - 2; pos += 3)
                {
                    localizedNames.Add(triplesCanonicalNamePlusPropNamePlusComment[pos]);
                    localizedNames.Add(triplesCanonicalNamePlusPropNamePlusComment[pos + 1]);
                    localizedComments.Add(triplesCanonicalNamePlusPropNamePlusComment[pos]);
                    localizedComments.Add(triplesCanonicalNamePlusPropNamePlusComment[pos + 2]);
                }
            }

            if (localizedNames.Count > 0 && localizedComments.Count > 0)
            {
                this._name = new StringInCultures(name, localizedNames.ToArray());
                this._comment = new StringInCultures(comment, localizedComments.ToArray());
            }
            else
            {
                this._name = new StringInCultures(name);
                this._comment = new StringInCultures(comment);
            }
        }
        #endregion

        #region Properties
        /** <summary>Name of this property in the dialog.</summary>*/
        public StringInCultures Name { get { return this._name; } }

        /** <summary>This is a text that describes the meaning of this form field.
         * Usually this will be displayed as tool tip.</summary>*/
        public StringInCultures Comment { get { return this._comment; } }

        /** <summary>True iff this shall be presented read-only.</summary>*/
        public bool IsReadOnly { get { return this._isReadOnly; } set { this._isReadOnly = value; } }

        /** <summary>If possible, items will be sorted according to this parameter.</summary>*/
        public int Sort { get { return this._sortCriterion; } set { this._sortCriterion = value; } }
        #endregion
    }

    /** <summary>Use this attribute to define groups of form items.
     * Use this attributes to define item groups to be displayed together. Users may hide item groups and make them
     * visible again as long as the group is not declared to be statically visible.
     * Groups have a name/label and optionally a comment. You may provide additional translations of names and comments.
     * 
     * The neutral (not translated) name of the group serves as a key. Usually, you will provide one instance of this
     * attribute with full data and additional instances only comprising a neutral name to designate additional items
     * that shall join the group. The form will choose one definition of the group to provide all the data.</summary>*/
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class FormItemGroupAttribute : Attribute
    {
        #region State
        bool _isStatic = false;
        int _sortCriterion = 0;
        StringInCultures _name;
        StringInCultures _comment = null;
        #endregion

        #region CTor
        /** <summary>Creates an instance without data.
         * </summary>
         */
        public FormItemGroupAttribute(string name)
        {
            this._name = new StringInCultures(name);
        }

        /** <summary>Creates an instance including data.
         * </summary>
         * <remarks>
         * This attribute makes only sence if used together with FormItemAttribute.
         * 
         * Even if you provide <c>null</c> as comment, this instance will be considered as a definition of
         * the item group providing full data.
         * 
         * \param name is the neutral name of the property to be shown in the form if this has not been translated into the current culture.
         * \param comment is the neutral comment of the property to be displayed if a better translation is not available.
         * \param triplesCanonicalNamePlusPropNamePlusComment is a sequence of triples canonical culture name (like "de-DE"), translated
         *        name, translated comment.
         * 
         * Example: Use this to declare a property of a form
         * \code
         class FormData
         {
         [FormItemGroupAttribute("Valuation Factors", "Some factors for valuation.",
                                 "de", "Bewertungsangaben", "Angaben zur Bewertung.")]
         [FormItemAttribute("Factor 1", "A value to be used for valuation.",
                            "de", "Faktor 1", "Bewertungsfaktor 1.", Sort=1)]
         int _factor1;

         [FormItemGroupAttribute("Valuation Factors")]
         [FormItemAttribute("Factor 2", "Another value to be used for valuation.",
                            "de", "Faktor 1", "Bewertungsfaktor 2.", Sort=2)]
         int _factor2;
         }
         \endcode
         * </remarks>
         */
        public FormItemGroupAttribute(string name, string comment, params string[] triplesCanonicalNamePlusPropNamePlusComment)
        {
            List<string> localizedNames = new List<string>();
            List<string> localizedComments = new List<string>();

            if (triplesCanonicalNamePlusPropNamePlusComment != null)
            {
                for (int pos = 0; pos < triplesCanonicalNamePlusPropNamePlusComment.Length - 2; pos += 3)
                {
                    localizedNames.Add(triplesCanonicalNamePlusPropNamePlusComment[pos]);
                    localizedNames.Add(triplesCanonicalNamePlusPropNamePlusComment[pos + 1]);
                    localizedComments.Add(triplesCanonicalNamePlusPropNamePlusComment[pos]);
                    localizedComments.Add(triplesCanonicalNamePlusPropNamePlusComment[pos + 2]);
                }
            }

            if (localizedNames.Count > 0 && localizedComments.Count > 0)
            {
                this._name = new StringInCultures(name, localizedNames.ToArray());
                this._comment = new StringInCultures(comment, localizedComments.ToArray());
            }
            else
            {
                this._name = new StringInCultures(name);
                this._comment = new StringInCultures(comment);
            }
        }
        #endregion

        #region Public Properties
        /** <summary>The untranslated name of this group that also serves as a key to designate the group.</summary>*/
        public string Id { get { return this._name.DefaultTranslation; } }

        /** <summary>The name of the item group and its translations.</summary>*/
        public StringInCultures Name { get { return this._name; } }

        /** <summary>The comment on this item group and its translations.
         * This may be <c>null</c> if this instance does not contain data.
         * The form will choose one of the instances of this attribute on the same group where this property
         * is not <c>null</c>.
         * </summary>
         */
        public StringInCultures Comment { get { return this._comment; } }

        /** <summary>True to require this attribute to be statically visible in the form (without scrolling).
         * Please do not use this too often, because this might cause large and ugly looking forms.
         * This is meant for fields like Name, affected year etc., that are something like a headline
         * for the rest of the form.
         * </summary>
         */
        public bool IsStatic { get { return this._isStatic; } set { this._isStatic = value; } }

        /** <summary>If possible, item groups will be sorted according to this parameter.
         * </summary>
         */
        public int Sort { get { return this._sortCriterion; } set { this._sortCriterion = value; } }
        #endregion
    }

    /** <summary>This attribute declares a particular form item to join the designated row in the form.
     * This attribute makes only sence if used together with FormItemAttribute.
     * 
     * Use instances of this attribtue to declare that two or more form items shall join the same 
     * row. The sort criterion of the form items will be used to determine the order in which the items appear
     * in the row. The sort criterion of this designator will be used to determine the place that
     * the designated row occupies in the form.
     *</summary>*/
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class ItemRowDesignatorAttribute : Attribute
    {
        #region State
        int _id;
        int _sort;
        #endregion

        #region CTor
        /** <summary>The provided integer is the designator of the row as well as the criterion for sorting.</summary>*/
        public ItemRowDesignatorAttribute(int id)
        {
            this._id = id;
            this._sort = id;
        }
        #endregion

        #region Public Properties
        /** <summary>Returns the designator if the form row.</summary>*/
        public int Id { get { return this._id; } }

        /** <summary>Returns or sets the sorting index.</summary>*/
        public int Sort { get { return this._sort; } set { this._sort = value; } }
        #endregion
    }
    #endregion

    #region Models
    /** <summary>Classification of messages.</summary>*/
    [wx.Globalization.EnumValueTranslations(0, "Error", "de", "Fehler")]
    [wx.Globalization.EnumValueTranslations(1, "Warning", "de", "Warnung")]
    [wx.Globalization.EnumValueTranslations(2, "Information")]
    public enum MessageClass
    {
        /** <summary>The message is an error.
         * The latest input cannot be accepted by the system and will be rejected.</summary>*/
        Error=0,

        /** <summary>This is a warning message.
         * The latest input will be accepted but another the system recommends to
         * think this over.</summary>*/
        Warning=1,

        /** <summary>This is a message simply for information.</summary>*/
        Info=2,
    }

    /** <summary>Interface of means to display errors, warnings, or messages in response to value changes.
     * Refer also to ErrorMessageException.</summary>*/
    public interface IErrorHandler
    {
        /** <summary>This tells the error handler to show the message of the provided properties.
         * \param msgClass is the message class, typically wx.MessageClass.Error.
         * \param msgFormat is a messge string that may contain wild cards like "{0}" or "{1}" that will be
         *                  replaced by the string form of the designated object. Typically, a translation
         *                  of <c>msgFormat</c> into the current culture or locale will be shown. However, this is left
         *                  to the error handler.
         * \param objects is a sequence of objects that either occur in <c>msgFormat</c> or may serve as a structured information
         *                on the error. The interpretation of such objects are left to the error handler. For instance, a
         *                handler using the calendar control may use a <c>System.DateTime</c> object to determine the day
         *                that is affected by the error.</summary>*/
        void ShowMessage(MessageClass msgClass, string msgFormat, params object[] objects);
    }

    /** <summary>This exception represents an error message that shall be caught and passed to an error handler.
     * All built in data models will catch this and pass it to an error handler.</summary>*/
    public class ErrorMessageException : Exception
    {
        #region State
        string _msgFormat;
        object[] _objects;
        #endregion

        public ErrorMessageException(string msgFormat, object[] objects)
            : base(string.Format(msgFormat, objects))
        {
            this._msgFormat = msgFormat;
            this._objects = objects;
        }

        /** <summary>Display this on the provided error handler.
         * If the argument is <c>null</c>, this will use a standard error handler (message dialog).</summary>*/
        public void Show(IErrorHandler handler)
        {
            if (handler == null)
            {
                handler = new ErrorMessageDialog();
            }
            handler.ShowMessage(MessageClass.Error, this._msgFormat, this._objects);
        }
    }


    /** <summary>Shows an error using the wx.MessageDialog.
     * Opens at most one dialog non-modal.</summary>*/
    public class ErrorMessageDialog : IErrorHandler
    {
        #region State
        Window _parent;
        MessageDialog _dialog = null;
        #endregion

        /** <summary>Creates an instance without parent.</summary>*/
        public ErrorMessageDialog()
        {
            this._parent = null;
        }

        /** <summary>Creates an instance with parent that will be used to determine the position of the dialog.</summary>*/
        public ErrorMessageDialog(Window parent)
        {
            this._parent = parent;
        }

        /** <summary>Returns the parent.
         * The result may be <c>null</c>.
         * </summary>
         */
        public Window Parent { get { return this._parent; } }

        #region IErrorHandler Member
        /** <summary>Closing and destroying the old message box if one exists and open a new one.</summary>*/
        public void ShowMessage(MessageClass msgClass, string msgFormat, params object[] objects)
        {
            if (this._dialog != null)
            {
                this._dialog.Show(false);
                this._dialog.Destroy();
            }
            WindowStyles icon=WindowStyles.ICON_INFORMATION;
            switch (msgClass)
            {
                case MessageClass.Error: icon=WindowStyles.ICON_ERROR; break;
                case MessageClass.Warning: icon=WindowStyles.ICON_WARNING; break;
            }
            this._dialog = new wx.MessageDialog(this._parent, Object._(msgFormat, objects), Object._(msgClass), WindowStyles.DIALOG_OK | icon);
            this._dialog.Show(true);
        }
        #endregion
    }

    /** <summary>Interface of nodes in the dependency network.</summary>*/
    public interface IDataModel
    {
        /** <summary>Read or change the encapsulated model.</summary><remarks>
         * Writing this value is always equivalent to
         * \code
         IDataModel m=...;
         m.Value=value; // this is equivalent to the following
         
         if (this._referenceType.IsInstanceOfType(value))
         {
             try
             {
                m.BeginSetValue(value);
                m.EndSetValue(true);
             }
             catch (ErrorMessageException exc)
             {
                exc.Show(m.ErrorHandler);
                m.EndSetValue(false);
             }
             catch (Exception exc)
             {
                m.EndSetValue(false);
                throw exc;
             }
         }
         else
           throw new ArgumentException();
         \endcode
         * 
         * The compatibility with the reference type is often tested in <c>BeginSetValue()</c> instead.
         * 
         * Please note, that this property is required to return the new value while propagating a change.</remarks>*/
        object Value { get; set; }

        /** <summary>This is the reference type.
         * This contraints assignments to <c>Value</c>.
         * If reflection is used to define labale texts or visible parts of the model,
         * then this type will be used.
         * </summary>
         */
        Type ReferenceType { get; }

        /** <summary>This will be called on any change to <c>Value</c>.
         * </summary>
         */
        event ValueChangedHandler OnValueChange;

        /** <summary>True iff all models, that this depends on, fire an event for changing a value.
         * </summary>
         */
        bool PropagatesChanges { get; }

        /** <summary>This will assign <c>newValue</c> and assign value propagation.
         * Call EndSetValue() to end this transaction.
         * 
         * Please note, that this will raise a <c>System.ApplicationException</c> if BeginSetValue() has been run without
         * a following EndSetValue() and both values differ. This is to avoid non-terminating recursions.
         * Please note, that dependency networks shall have the form of acyclic graphs. In acyclic graphs, propagation
         * of dependencies is known to terminate.
         * </summary>
         */
        void BeginSetValue(object newValue);

        /** <summary>Ends transaction safe setting of a value that has been initialized by BeginSetValue().</summary>
         * <param name="commitOrRollback"> is <c>true</c> if the changes shall be committed and <c>false</c> if this shall rollback all changes since the
         *        last BeginSetValue().</param>
         * 
         */
        void EndSetValue(bool commitOrRollback);

        /** <summary>All events will be deferred until EndInit() is called.
         * </summary>
         */
        void BeginInit();

        /** <summary>Fires events that have been deferred by BeginnInit().
         * However, redundant events will not fire. Example: If this changes its value twice
         * after BeginInit(), only the final assignment will be communicated by events.
         * 
         * This is usually the same as PropagateValue() but additionally ends BeginnInit().
         * </summary>
         */
        void EndInit();

        /** <summary>Create events as if the current value has been set.
         * The corresponding change event will have the current value as old value as well as 
         * new value.
         * </summary>
         */
        void PropagateValue();

        /** <summary>This is the used error handler. 
         * This may be <c>null</c>.
         * </summary>
         */
        IErrorHandler ErrorHandler { get; set; }
    }

    /** <summary>Base class that helps to implement data models.
     * This basically implements propagation of changes over depending models.
     * </summary>
     */
    public abstract class DataModelBase : IDataModel
    {
        #region State
        object _changingToThisValue = null;
        bool _isInitializing = false;
        bool _propagatesChange = false;
        IErrorHandler _errorHandler = null;
        Type _referenceType;
        #endregion

        #region CTor
        /** <summary>Create an instance of the provided reference type.</summary>*/
        protected DataModelBase(Type referenceType)
        {
            if (referenceType == null)
                this._referenceType = typeof(System.Object);
            else
                this._referenceType = referenceType;
        }

        /** <summary>Create an instance of reference type <c>System.Object</c>.</summary>*/
        protected DataModelBase() : this(null)
        {
        }
        #endregion

        #region Protected Virtuals
        /** <summary>Override this to change the represented value without propagation of dependencies.
         * This MUST work without exceptions of IsConsistentValue() returns true.</summary>*/
        protected abstract void SetValue(object value);

        /** <summary>True iff <c>value</c> may be assigned by <c>SetValue()</c> without error.
         * This is also allowed to throw an <c>ErrorMessageException</c> in order to provide full
         * information for an error handler.</summary>*/
        protected abstract bool IsConsistentValue(object value);

        /** <summary>Override this to read the represented value.</summary>*/
        protected abstract object GetValue();
        #endregion

        #region ProtectedService
        /** <summary>This will raise <c>OnValueChange</c>.</summary>*/
        protected void PropagateChange(object newValue, object oldValue)
        {
            if (this.OnValueChange != null)
                this.OnValueChange(this, new ValueChangedEvent(newValue, oldValue));
        }
        #endregion

        #region IDataModel Member
        /** <summary>Get or set the encapsulated value.</summary>*/
        public virtual object Value
        {
            get
            {
                if (this._propagatesChange)
                    return this._changingToThisValue;
                return this.GetValue();
            }
            set
            {
                try
                {
                    this.BeginSetValue(value);
                    this.EndSetValue(true);
                }
                catch (ErrorMessageException exc)
                {
                    exc.Show(this.ErrorHandler);
                    this.EndSetValue(false);
                }
                catch (Exception exc)
                {
                    this.EndSetValue(false);
                    throw exc;
                }
            }
        }

        /** <summary>The configured reference type of the value.</summary>*/
        public Type ReferenceType { get { return this._referenceType; } }

        /** <summary>This event will be called on changing the value.</summary>*/
        public event ValueChangedHandler OnValueChange;

        /** <summary>Overload this to declare whether this model is really able to detect and propagate all changes of the value.</summary>*/
        public abstract bool PropagatesChanges { get; }

        /** <summary>Initializes value changing transaction.
         * This will change the value and</summary>*/
        public void BeginSetValue(object newValue)
        {
            try
            {
                object currentValue = this.GetValue();
                this._changingToThisValue = newValue;
                if ((currentValue == null && newValue != null)
                    || (currentValue != null && newValue == null)
                    || (currentValue != null && newValue != null && !currentValue.Equals(newValue)))
                {
                    // Only assign and propagate as change if the new value really is different.
                    if (this._propagatesChange)
                        throw new ApplicationException(Object._("Called wx.ComponentModel.IDataModel.BeginSetValue() while propagating a value."));

                    // test the value for compatiblity
                    if (!this._referenceType.IsInstanceOfType(newValue))
                        throw new ArgumentException(Object._("wx.ComponentModel.IDataModel.BeginSetValue({0}) but reference type {1}.", newValue, this._referenceType.FullName));

                    if (!this.IsConsistentValue(newValue))
                        throw new ArgumentException(Object._("Value {0} is not allowed here.", newValue));

                    if (!this._isInitializing && this.OnValueChange != null)
                    {
                        this.OnValueChange(this, new ValueChangedEvent(newValue, currentValue));
                    }
                }
            }
            finally
            {
                this._propagatesChange = true;
            }
        }

        /** <summary>Ends the transaction for setting a new value.
         * This throws a <c>System.ApplitionException()</c>, if <c>BeginSetValue()</c> has not been called before.
         * 
         * If <c>commitOrRollback</c> is <c>true</c>, then assign the new value. Otherwise, reset to the original value.</summary>*/
        public void EndSetValue(bool commitOrRollback)
        {
            try
            {
                if (!this._propagatesChange)
                    throw new ApplicationException(Object._("Called wx.ComponentModel.EndSetValue() without preceeding wx.ComponentModel.BeginSetValue()."));
                if (!this._isInitializing)
                {
                    if (commitOrRollback)
                        this.SetValue(this._changingToThisValue);
                    this._changingToThisValue = null;
                }
            }
            finally
            {
                this._propagatesChange = false;
            }
        }

        public void BeginInit()
        {
            this._isInitializing = true;
        }

        public void EndInit()
        {
            try
            {
                if (!this._isInitializing)
                    throw new ApplicationException(Object._("Called wx.ComponentModel.EndInit() without preceeding wx.ComponentModel.BeginInit()."));
                this.SetValue(this._changingToThisValue);
                this._changingToThisValue = null;
                this.PropagateValue();
            }
            finally
            {
                this._isInitializing = false;
            }
        }

        /** <summary>Propagate the current value raising <c>OnValueChange</c> as if the current value replaces the current value.</summary>*/
        public void PropagateValue()
        {
            if (this.OnValueChange != null)
            {
                object currentValue = this.GetValue();
                this.OnValueChange(this, new ValueChangedEvent(currentValue, currentValue));
            }
        }

        /** <summary>Get or set the error handler.</summary>*/
        public IErrorHandler ErrorHandler
        {
            get
            {
                return this._errorHandler;
            }
            set
            {
                this._errorHandler = value;
            }
        }

        #endregion
    }

    /** <summary>A Value model encapsulates an object. This object will be the value.</summary>*/
    public class ValueModel : DataModelBase
    {
        object _value;

        /** <summary>Creates a model of the provided value using type information from <c>referenceType</c>.
         * Ths will raise an System.ArgumentException, if <c>value</c> is not an instance of <c>referenceType</c>.
         * </summary>
         */
        public ValueModel(object value, Type referenceType) : base(referenceType)
        {
            if (referenceType != null && !referenceType.IsInstanceOfType(value))
                throw new ApplicationException(Object._("wx.ComponentModel.ValueModel({0}, {1}) is inconsistent.", value, referenceType.FullName));
            this._value = value;
        }

        protected override bool IsConsistentValue(object value)
        {
            return true;
        }

        protected override void SetValue(object value)
        {
            this._value = value;
        }

        protected override object GetValue()
        {
            return this._value;
        }

        /// <summary>
        /// Get or set the value.
        /// </summary>
        public override object Value { get { return this._value; } set { this.SetValue(value); } }

        /** <summary>True, if this safely detects all changes of the encapsulated value.
         * Unfortunately, this is not able to notice any change within the value if this is a class.
         * However, on value types, the only way to change this is to call <c>SetValue</c>. Of course, this
         * will be noticed and this change will be propagated.
         * </summary>
         */
        public override bool PropagatesChanges
        {
            get { return this.ReferenceType.IsValueType; }
        }
    }

    /** <summary>A data model observing a certain property of a structured value of a data model.
     * </summary>
     */
    public class PropertyModel : DataModelBase
    {
        #region Local Private Types
        struct ObjectEventDescr
        {
            public EventInfo Event;
            public object Object;

            public ObjectEventDescr(object obj, EventInfo evt)
            {
                this.Event = evt;
                this.Object = obj;
            }

            public void Add(ValueChangedHandler evtHandler)
            {
                if (this.Object != null && this.Event != null)
                    this.Event.AddEventHandler(this.Object, evtHandler);
            }

            public void Remove(ValueChangedHandler evtHandler)
            {
                if (this.Object != null && this.Event != null)
                    this.Event.RemoveEventHandler(this.Object, evtHandler);
            }

            public bool IsEmpty { get { return this.Object == null || this.Event == null; } }

            public void MakeEmpty()
            {
                this.Object = null;
                this.Event = null;
            }

            public void Set(object obj, EventInfo ev)
            {
                this.Event = ev;
                this.Object = obj;
            }
        }
        #endregion

        #region State
        public string PropertyName;
        public IDataModel Data;
        bool _propagatesChanges = false;
        string _propagatorEventName = null;
        ValueChangedHandler _propagateChangesHandler = null;
        ObjectEventDescr _listeningToThisPropertyChangeEvent = new ObjectEventDescr(null, null);
        #endregion

        #region CTor
        /** <summary>Creates an instance encapsulating property <c>propertyName</c> of the value of <c>data</c>.
         * If <c>data</c> does not have this property, this will be <c>null</c>.
         * 
         * This will look for an <c>RaisesChangeEventAttribute</c> of the property in the reference
         * type if <c>data</c> to determine, whether this propagates all changes. So, this will fail
         * to keep track of changes if the property or the <c>RaisesChangeEventAttribute</c> is not declared
         * in the reference type of the data source.
         * </summary>
         */
        public PropertyModel(string propertyName, IDataModel data)
        {
            this.Data = data;
            this.PropertyName = propertyName;

            data.OnValueChange += new ValueChangedHandler(this.OnChangingDataSource);

            this._propagatesChanges = data.PropagatesChanges;
            PropertyInfo pi = data.ReferenceType.GetProperty(this.PropertyName);
            object[] attributes=pi.GetCustomAttributes(typeof(RaisesChangeEventAttribute), true); // look for a change event.
            if (attributes != null)
            {
                foreach (RaisesChangeEventAttribute attribute in attributes)
                {
                    this._propagatorEventName = attribute.EventName;
                    this.AddChangeEventHandlerToObject(data.Value);
                }
            }
        }
        #endregion

        #region Private Helpers
        /** <summary>Propagate the change.</summary>*/
        void OnChangingProperty(object sender, ValueChangedEvent args)
        {
            this.PropagateChange(args.NewValue, args.OldValue);
        }

        /** <summary>Adds this as listener to the event named <c>_propagatorEventName</c> in value.</summary>*/
        void AddChangeEventHandlerToObject(object value)
        {
            this._propagatesChanges = false;
            if (this._propagateChangesHandler != null && !this._listeningToThisPropertyChangeEvent.IsEmpty)
                this._listeningToThisPropertyChangeEvent.Remove(this._propagateChangesHandler);
            this._listeningToThisPropertyChangeEvent.MakeEmpty();
            if (value != null && this._propagatorEventName != null)
            {
                EventInfo ev = value.GetType().GetEvent(this._propagatorEventName);
                if (ev != null)
                {
                    if (this._propagateChangesHandler == null)
                        this._propagateChangesHandler = new ValueChangedHandler(this.OnChangingProperty);
                    this._listeningToThisPropertyChangeEvent.Set(value, ev);
                    this._listeningToThisPropertyChangeEvent.Add(this._propagateChangesHandler);

                    // OK, if the data source propagates all changes, then this reports all changes,
                    // since all changes of the current property will be noticed.
                    this._propagatesChanges = this.Data.PropagatesChanges;
                }
            }
        }

        /** <summary>Makes sure that this listens to changes in the new value (if possible) and propagates <c>OnValueChange</c> events.</summary>*/
        void OnChangingDataSource(object sender, wx.ComponentModel.ValueChangedEvent evt)
        {
            this.AddChangeEventHandlerToObject(evt.NewValue);
            object newPropertyValue = this.ReadPropertyFromValue(evt.NewValue);
            object oldPropertyValue = this.ReadPropertyFromValue(evt.OldValue);
            this.PropagateChange(newPropertyValue, oldPropertyValue);
        }

        /** <summary>Reads the property of interest of the provided value.
         * If the property does not exist, return <c>null</c>.
         * </summary>
         */
        object ReadPropertyFromValue(object value)
        {
            PropertyInfo pi = value.GetType().GetProperty(this.PropertyName);
            if (pi == null || !pi.CanRead)
                return null;
            else
                return pi.GetValue(value, null);
        }
        #endregion

        #region Overrides
        protected override bool IsConsistentValue(object value)
        {
            PropertyInfo pi = value.GetType().GetProperty(this.PropertyName);
            return pi != null && pi.CanWrite && pi.DeclaringType.IsInstanceOfType(value);
        }

        protected override void SetValue(object value)
        {
            PropertyInfo pi = value.GetType().GetProperty(this.PropertyName);
            pi.SetValue(this.Data.Value, value, null);
        }

        /** <summary>Reads property from the current data source value.</summary>*/
        protected override object GetValue()
        {
            return this.ReadPropertyFromValue(this.Data);
        }

        /** <summary>True if the data source propagates changes and this listens to an event that indicates changes of the encapsulated property of the current value that can be read from the data source.</summary>*/
        public override bool PropagatesChanges
        {
            get { return this._propagatesChanges; }
        }
        #endregion
    }
    #endregion
}

