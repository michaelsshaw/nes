//-----------------------------------------------------------------------------
// wx.NET - ToggleButton.cs
//
// The wxToggleToggleButton wrapper class.
//
// Written by Florian Fankhauser (f.fankhauser@gmx.at)
// (C) 2003 Florian Fankhauser
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: ToggleButton.cs,v 1.10 2009/01/06 18:27:17 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Drawing;
using System.Runtime.InteropServices;

namespace wx
{
	public class ToggleButton : Control
	{
		[DllImport("wx-c")] static extern IntPtr wxToggleButton_ctor();
		[DllImport("wx-c")] static extern bool   wxToggleButton_Create(IntPtr self, IntPtr parent,
			int id, IntPtr label, int x, int y, int width, int height, uint style,
			IntPtr validator, IntPtr name);
		[DllImport("wx-c")] static extern bool wxToggleButton_GetValue(IntPtr self);
		[DllImport("wx-c")] static extern bool wxToggleButton_SetValue(IntPtr self, bool state);

		//---------------------------------------------------------------------
		
		public ToggleButton(IntPtr wxObject) 
			: base(wxObject) { }

		public ToggleButton()
			: base(wxToggleButton_ctor())	{ }

		public ToggleButton(Window parent, int id, string label)
			: this(parent, id, label, wxDefaultPosition, wxDefaultSize, 0, null) { }

		public ToggleButton(Window parent, int id, string label, Point pos)
			: this(parent, id, label, pos, wxDefaultSize, 0, null) { }

		public ToggleButton(Window parent, int id, string label, Point pos, Size size)
			: this(parent, id, label, pos, size, 0, null) { }

        public ToggleButton(Window parent, int id, string label, Point pos, Size size, WindowStyles style)
			: this(parent, id, label, pos, size, style, null) { }

        public ToggleButton(Window parent, int id, string label, Point pos, Size size, WindowStyles style, string name)
            : this(parent, id, wxString.SafeNew(label), pos, size, style, wxString.SafeNew(name))
        {
        }
        public ToggleButton(Window parent, int id, wxString label, Point pos, Size size, WindowStyles style, wxString name)
			: base(wxToggleButton_ctor())
		{
			if (!Create(parent, id, label, pos, size, style, name))
			{
				throw new InvalidOperationException("Failed to create ToggleButton");
			}
		}
		
		//---------------------------------------------------------------------
		
		public ToggleButton(Window parent, string label)
			: this(parent, Window.UniqueID, label, wxDefaultPosition, wxDefaultSize, 0, null) { }

		public ToggleButton(Window parent, string label, Point pos)
			: this(parent, Window.UniqueID, label, pos, wxDefaultSize, 0, null) { }

		public ToggleButton(Window parent, string label, Point pos, Size size)
			: this(parent, Window.UniqueID, label, pos, size, 0, null) { }

        public ToggleButton(Window parent, string label, Point pos, Size size, WindowStyles style)
			: this(parent, Window.UniqueID, label, pos, size, style, null) { }

		public ToggleButton(Window parent, string label, Point pos, Size size, WindowStyles style, string name)
			: this(parent, Window.UniqueID, label, pos, size, style, name) {}
		
		//---------------------------------------------------------------------

        public bool Create(Window parent, int id, string label, Point pos, Size size, WindowStyles style, string name)
        {
            return this.Create(parent, id, wxString.SafeNew(label), pos, size, style, wxString.SafeNew(name));
        }
		public bool Create(Window parent, int id, wxString label, Point pos, Size size, WindowStyles style, wxString name)
		{
			return wxToggleButton_Create(wxObject, Object.SafePtr(parent), id, Object.SafePtr(label), pos.X, pos.Y, size.Width, size.Height,
				(uint)style, IntPtr.Zero, Object.SafePtr(name));
		}

		//---------------------------------------------------------------------

		public bool State
		{
			get { return wxToggleButton_GetValue(wxObject); }
			set { wxToggleButton_SetValue(wxObject, value); }
		}

		//---------------------------------------------------------------------

		public event EventListener Click
		{
			add { AddCommandListener(Event.wxEVT_COMMAND_TOGGLEBUTTON_CLICKED, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}
	}
}

