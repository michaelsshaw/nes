//-----------------------------------------------------------------------------
// wx.NET - Brush.cs
//
// The wxBrush wrapper class.
//
// Written by Jason Perkins (jason@379.com)
// (C) 2003 by 379, Inc.
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: Brush.cs,v 1.12 2010/04/11 16:14:27 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Runtime.InteropServices;

namespace wx
{
	public class Brush : GDIObject
	{
        [DllImport("wx-c")] static extern IntPtr wxBrush_ctor();
		[DllImport("wx-c")] static extern bool   wxBrush_Ok(IntPtr self);
		[DllImport("wx-c")] static extern uint wxBrush_GetStyle(IntPtr self);
		[DllImport("wx-c")] static extern void   wxBrush_SetStyle(IntPtr self, uint style);
		[DllImport("wx-c")] static extern IntPtr wxBrush_GetStipple(IntPtr self);
		[DllImport("wx-c")] static extern void   wxBrush_SetStipple(IntPtr self, IntPtr stipple);
        [DllImport("wx-c")] static extern IntPtr wxBrush_GetColour(IntPtr self);
		[DllImport("wx-c")] static extern void   wxBrush_SetColour(IntPtr self, IntPtr col);

		//---------------------------------------------------------------------

        /** <summary>Styles for brushes.</summary>*/
        public enum Styles
        {
            SOLID = 100,
            TRANSPARENT,

            STIPPLE = 110,
            BDIAGONAL_HATCH,
            CROSSDIAG_HATCH,
            FDIAGONAL_HATCH,
            CROSS_HATCH,
            HORIZONTAL_HATCH,
            VERTICAL_HATCH,
        }

        static IntPtr LockedCTor()
        {
            lock (DllSync)
            {
                return wxBrush_ctor();
            }
        }

		public Brush()
			: this(LockedCTor()) { }

		public Brush(IntPtr wxObject)
			: base(wxObject) { }

		public Brush(Colour colour) 
			: this(colour, Styles.SOLID) { }
			
		public Brush(Colour colour, Styles style)
			: this()
		{
			Colour = colour;
			Style = style;
		}

		public Brush(Bitmap stippleBitmap) 
			: this()
		{
			Stipple = stippleBitmap;
		}

		public Brush(string name) 
			: this(name, Styles.SOLID) { }
			
		public Brush(string name, Styles style) 
			: this() 
		{ 
			Colour = new Colour(name);
			Style = style;
		}

        /** <summary>This is synonym to wx.BrushList.TheBrushList.</summary>*/
        public static BrushList TheBrushList
        {
            get { return wx.BrushList.TheBrushList; }
        }

		//---------------------------------------------------------------------

		public bool Ok() 
		{
			return wxBrush_Ok(wxObject);
		}

		//---------------------------------------------------------------------

		public Styles Style
		{
			get { return (Styles)wxBrush_GetStyle(wxObject); }
			set {
                if (this.IsReadonly)
                    throw new CannotChangeReadonly();
                wxBrush_SetStyle(wxObject, (uint)value);
            }
		}

		//---------------------------------------------------------------------

		public Bitmap Stipple
		{
			get { return (Bitmap)FindObject(wxBrush_GetStipple(wxObject), typeof(Bitmap)); }
			set {
                if (this.IsReadonly)
                    throw new CannotChangeReadonly();
                value.MakeReadOnly();
                wxBrush_SetStipple(wxObject, Object.SafePtr(value));
            }
		}

		//---------------------------------------------------------------------

		public Colour Colour
		{
			get { return new Colour(wxBrush_GetColour(wxObject), true); }
			set {
                if (this.IsReadonly)
                    throw new CannotChangeReadonly();
                value.MakeReadOnly();
                wxBrush_SetColour(wxObject, Object.SafePtr(value));
            }
		}
	}
}
