//-----------------------------------------------------------------------------
// wx.NET - DateTime.cs
// 
// The wxDateTime wrapper class.
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: wxDateTime.cs,v 1.13 2009/09/20 14:10:58 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System.Runtime.InteropServices;
using System.Drawing;
using System;

namespace wx
{
    /** <summary>A wrapper to the  wxWidgets representation of points in time.
     * </summary>
     */
    internal class wxDateTime : Object
    {
        #region C API
        [DllImport("wx-c")]
        static extern IntPtr wxDateTime_ctor();
        [DllImport("wx-c")]
        static extern void wxDateTime_dtor(IntPtr self);
        [DllImport("wx-c")]
        static extern void wxDateTime_Set(IntPtr self, ushort day, int month, int year, ushort hour, ushort minute, ushort second, ushort millisec);
        [DllImport("wx-c")]
        static extern ushort wxDateTime_GetYear(IntPtr self);
        [DllImport("wx-c")]
        static extern int wxDateTime_GetMonth(IntPtr self);
        [DllImport("wx-c")]
        static extern ushort wxDateTime_GetDay(IntPtr self);
        [DllImport("wx-c")]
        static extern ushort wxDateTime_GetHour(IntPtr self);
        [DllImport("wx-c")]
        static extern ushort wxDateTime_GetMinute(IntPtr self);
        [DllImport("wx-c")]
        static extern ushort wxDateTime_GetSecond(IntPtr self);
        [DllImport("wx-c")]
        static extern ushort wxDateTime_GetMillisecond(IntPtr self);
        #endregion 

        
        #region CTor /DTor
        public wxDateTime(IntPtr wxObject)
            : base(wxObject)
        {
            this.wxObject = wxObject;
        }

        internal wxDateTime(IntPtr wxObject, bool memOwn)
            : base(wxObject)
        {
            this.memOwn = memOwn;
            this.wxObject = wxObject;
        }

        public wxDateTime()
            : this(wxDateTime_ctor(), true) { }

        protected override void CallDTor()
        {
            wxDateTime_dtor(wxObject);
        }

        ~wxDateTime()
        {
            Dispose();
        }
        #endregion

        #region Public Methods and Properties
        public void Set(ushort day, int month, int year, ushort hour, ushort minute, ushort second, ushort millisec)
        {
            wxDateTime_Set(wxObject, day, month, year, hour, minute, second, millisec);
        }

        //-----------------------------------------------------------------------------

        public ushort Year
        {
            get { return wxDateTime_GetYear(wxObject); }
        }

        public int Month
        {
            get { return wxDateTime_GetMonth(wxObject); }
        }

        public ushort Day
        {
            get { return wxDateTime_GetDay(wxObject); }
        }

        public ushort Hour
        {
            get { return wxDateTime_GetHour(wxObject); }
        }

        public ushort Minute
        {
            get { return wxDateTime_GetMinute(wxObject); }
        }

        public ushort Second
        {
            get { return wxDateTime_GetSecond(wxObject); }
        }

        public ushort Millisecond
        {
            get { return wxDateTime_GetMillisecond(wxObject); }
        }
        #endregion

        /** <summary>Comprehensable output.
         *</summary>*/
        public override string ToString()
        {
            return string.Format("wxDateTime {0}.{1}.{2} {3}:{4}:{5} {6}/1000", Day, Month, Year, Hour, Minute, Second, Millisecond);
        }
        //-----------------------------------------------------------------------------

        public static implicit operator DateTime(wxDateTime wdt)
        {
            DateTime dt = new DateTime(wdt.Year, (int)wdt.Month + 1, (int)wdt.Day,
                                       (int)wdt.Hour, (int)wdt.Minute,
                                       (int)wdt.Second, (int)wdt.Millisecond);
            return dt;
        }

        public static implicit operator wxDateTime(DateTime dt)
        {
            wxDateTime wdt = new wxDateTime();
            wdt.Set((ushort)dt.Day, dt.Month - 1, dt.Year, (ushort)dt.Hour,
                    (ushort)dt.Minute, (ushort)dt.Second,
                    (ushort)dt.Millisecond);
            return wdt;
        }

        #region Static Helpers to convert related enumerations.
        /** <summary>Converts the int into a DayOfWeek assuming the argumetn to be an index in  wxWidgets enumeration <c>WeekDay</c>.
         * This will throw an System.ArgumentOutOfRangeException on negative arguments.
         * </summary>
         */
        static public DayOfWeek FromWxWeekDay(int wxWeekDay)
        {
            if (wxWeekDay < 0) throw new ArgumentOutOfRangeException();
            wxWeekDay = wxWeekDay % 7;
            switch (wxWeekDay)
            {
                case 0: return DayOfWeek.Sunday;
                case 1: return DayOfWeek.Monday;
                case 2: return DayOfWeek.Tuesday;
                case 3: return DayOfWeek.Wednesday;
                case 4: return DayOfWeek.Thursday;
                case 5: return DayOfWeek.Friday;
            }
            return DayOfWeek.Saturday;
        }
        #endregion
    }
}

