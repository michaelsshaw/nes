//-----------------------------------------------------------------------------
// wx.NET - RadioButton.cs
//
// The wxRadioButton wrapper class.
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//-----------------------------------------------------------------------------

using System;
using System.Drawing;
using System.Runtime.InteropServices;

namespace wx
{
	public class RadioButton : Control 
	{
		[DllImport("wx-c")] static extern IntPtr wxRadioButton_ctor();
		[DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)] static extern bool   wxRadioButton_Create(IntPtr self, IntPtr parent, int id, IntPtr label, int posX, int posY, int width, int height, uint style, IntPtr val, IntPtr name);
        [DllImport("wx-c")][return: MarshalAs(UnmanagedType.U1)] static extern bool wxRadioButton_GetValue(IntPtr self);
		[DllImport("wx-c")] static extern void   wxRadioButton_SetValue(IntPtr self, bool state);
	
		//---------------------------------------------------------------------
		
		public RadioButton(IntPtr wxObject) 
			: base(wxObject) {}
		
		public RadioButton()
			: base (wxRadioButton_ctor()) { }

		public RadioButton(Window parent, int id, string label)
			: this(parent, id, label, wxDefaultPosition, wxDefaultSize, wx.WindowStyles.NO_STYLE, null) { }

		public RadioButton(Window parent, int id, string label, Point pos)
			: this(parent, id, label, pos, wxDefaultSize, wx.WindowStyles.NO_STYLE, null) { }

		public RadioButton(Window parent, int id, string label, Point pos, Size size)
			: this(parent, id, label, pos, size, wx.WindowStyles.NO_STYLE, null) { }

		public RadioButton(Window parent, int id, string label, Point pos, Size size, wx.WindowStyles style)
			: this(parent, id, label, pos, size, style, null) { }

		public RadioButton(Window parent, int id, string label, Point pos, Size size, wx.WindowStyles style, string name)
			: base(wxRadioButton_ctor())
		{
            wxString wxname = wxString.SafeNew(name);
            wxString wxlabel = wxString.SafeNew(label);
            if (!wxRadioButton_Create(wxObject, Object.SafePtr(parent), id,
					Object.SafePtr(wxlabel), pos.X, pos.Y, size.Width, size.Height, (uint)style, IntPtr.Zero, Object.SafePtr(wxname)))
			{
				throw new InvalidOperationException("Failed to create RadioButton");
			}
		}
		
		//---------------------------------------------------------------------
		// ctors with self created id
		
		public RadioButton(Window parent, string label)
			: this(parent, Window.UniqueID, label, wxDefaultPosition, wxDefaultSize, wx.WindowStyles.NO_STYLE, null) { }

		public RadioButton(Window parent, string label, Point pos)
			: this(parent, Window.UniqueID, label, pos, wxDefaultSize, wx.WindowStyles.NO_STYLE, null) { }

		public RadioButton(Window parent, string label, Point pos, Size size)
			: this(parent, Window.UniqueID, label, pos, size, wx.WindowStyles.NO_STYLE, null) { }

		public RadioButton(Window parent, string label, Point pos, Size size, wx.WindowStyles style)
			: this(parent, Window.UniqueID, label, pos, size, style, null) { }

		public RadioButton(Window parent, string label, Point pos, Size size, wx.WindowStyles style, string name)
			: this(parent, Window.UniqueID, label, pos, size, style, name) {}

		//---------------------------------------------------------------------

		public bool Create(Window parent, int id, string label, Point pos, Size size, wx.WindowStyles style, string name)
		{
            wxString wxname = wxString.SafeNew(name);
            wxString wxlabel = wxString.SafeNew(label);
            return wxRadioButton_Create(wxObject, Object.SafePtr(parent), id,
				 Object.SafePtr(wxlabel), pos.X, pos.Y, size.Width, size.Height, (uint)style, IntPtr.Zero, Object.SafePtr(wxname));
		}

		//---------------------------------------------------------------------

		public bool Value
		{
			get { return wxRadioButton_GetValue(wxObject); }
			set { wxRadioButton_SetValue(wxObject, value); }
		}

		//---------------------------------------------------------------------

		public event EventListener Select
		{
			add { AddCommandListener(Event.wxEVT_COMMAND_RADIOBUTTON_SELECTED, ID, value, this); }
			remove { RemoveHandler(value, this); }
		}
	}
}
