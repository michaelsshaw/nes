//-----------------------------------------------------------------------------
// wx.NET - TaskBarIcon.cs
//
// The wxTaskBarIcon wrapper class.
//
// Written by Jacek Trublajewicz
// (C) 2008 by Jacek Trublajewicz
// Licensed under the wxWidgets license, see LICENSE.txt for details.
// 
// $Id: TaskBarIcon.cs,v 1.3 2009/09/20 14:10:58 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Runtime.InteropServices;

namespace wx
{
    /** <summary>This class represents a taskbar icon.
     * A taskbar icon is an icon that appears in the 'system tray' and responds to mouse clicks, optionally with a tooltip
     * above it to help provide information.
     * 
     * \par wxNET notes
     * Apparently, task icons prohibit application exit on closing the main frame. So, you will have to use
     * <c>wx.Utils.Exit()</c> instead where appropriate.
     * 
     * \par X Window System Note
     * Under X Window System, the window manager must support either the System Tray Protocol by <c>freedesktop.org</c>
     * (WMs used by modern desktop environments such as GNOME >= 2, KDE >= 3 and XFCE >= 4 all do) or the older
     * methods used in GNOME 1.2 and KDE 1 and 2. If it doesn't, the icon will appear as a toplevel window on
     * user's desktop.
     *
     * Because not all window managers have system tray, there's no guarantee that wx.TaskBarIcon will work correctly
     * under X Window System and so the applications should use it only as an optional component of their user interface.
     * The user should be required to explicitly enable the taskbar icon on Unix, it shouldn't be on by default.
     *
     * \par Event handling
     *
     * To process input from a taskbar icon, use the following event handler macros to direct input to member functions
     * that take a wxTaskBarIconEvent argument. Note that not all ports are required to send these events and so it's 
     * better to override CreatePopupMenu if all that the application does is that it shows a popup menu in reaction to
     * mouse click.
     *
     * \li <c>EVT_TASKBAR_MOVE(func)</c>  Process a <c>wxEVT_TASKBAR_MOVE</c> event.  
     * \li <c>EVT_TASKBAR_LEFT_DOWN(func)</c>  Process a <c>wxEVT_TASKBAR_LEFT_DOWN</c> event.  
     * \li <c>EVT_TASKBAR_LEFT_UP(func)</c>  Process a <c>wxEVT_TASKBAR_LEFT_UP</c> event.  
     * \li <c>EVT_TASKBAR_RIGHT_DOWN(func)</c>  Process a <c>wxEVT_TASKBAR_RIGHT_DOWN</c> event.  
     * \li <c>EVT_TASKBAR_RIGHT_UP(func)</c>  Process a <c>wxEVT_TASKBAR_RIGHT_UP</c> event.  
     * \li <c>EVT_TASKBAR_LEFT_DCLICK(func)</c>  Process a <c>wxEVT_TASKBAR_LEFT_DCLICK</c> event.  
     * \li <c>EVT_TASKBAR_RIGHT_DCLICK(func)</c>  Process a <c>wxEVT_TASKBAR_RIGHT_DCLICK</c> event.  
     * \li <c>EVT_TASKBAR_CLICK(func)</c>  This is a synonym for either <c>EVT_TASKBAR_RIGHT_DOWN</c> or <c>UP</c>
     * depending on the platform, use this event macro to catch the event which should result in the menu being displayed on the current platform.  
     * 
     * Contributed by Jacek Trublajewicz 2008 with some changes by Harald Meyer auf'm Hofe.</summary>*/
    public class TaskBarIcon : EvtHandler
    {
        #region C API
        [DllImport("wx-c")] static extern IntPtr wxTaskBarIcon_ctor();
		[DllImport("wx-c")]
		[return:MarshalAs(UnmanagedType.U1)]
		static extern bool wxTaskBarIcon_IsOk(IntPtr self);
		[DllImport("wx-c")]
		[return: MarshalAs(UnmanagedType.U1)]
		static extern bool wxTaskBarIcon_SetIcon(IntPtr self, IntPtr icon, IntPtr tooltip);
		[DllImport("wx-c")] static extern void wxTaskBarIcon_dtor(IntPtr self);
		[DllImport("wx-c")] 
		[return: MarshalAs(UnmanagedType.U1)]		
		static extern bool wxTaskBarIcon_IsIconInstalled(IntPtr self);
		[DllImport("wx-c")] 
		[return: MarshalAs(UnmanagedType.U1)]		
		static extern bool wxTaskBarIcon_PopupMenu(IntPtr self, IntPtr menu);
		[DllImport("wx-c")] 
		[return: MarshalAs(UnmanagedType.U1)]		
		static extern bool wxTaskBarIcon_RemoveIcon(IntPtr self);

        delegate IntPtr CreatePopupMenuHandler();
        [DllImport("wx-c")]
        static extern void wxTaskBarIcon_RegisterVirtuals(IntPtr self, CreatePopupMenuHandler handler);
        #endregion
		
        #region State
        CreatePopupMenuHandler _createPopupHandler;
        #endregion

        #region CTor / DTor
        public TaskBarIcon() 
			: this(wxTaskBarIcon_ctor()) 
		{
            this._createPopupHandler = new CreatePopupMenuHandler(this.DoCreatePopupMenu);
            wxTaskBarIcon_RegisterVirtuals(this.wxObject, this._createPopupHandler);
		}		
		
		public TaskBarIcon(IntPtr wxObject) 
			: base(wxObject) {}

        protected override void CallDTor()
        {
			wxTaskBarIcon_dtor(wxObject);
        }
        #endregion

        //---------------------------------------------------------------------
			
		public bool IsOk
		{
            get
            {
                return wxTaskBarIcon_IsOk(wxObject);
            }
		}
		
        /** <summary>True iff icon is presented in the task bar.
         * Call RemoveIcon() to remove the icon from the task bar.</summary>*/
		public bool IsIconInstalled
		{
            get
            {
                return wxTaskBarIcon_IsIconInstalled(wxObject);
            }
		}

        /** <summary>Defines icon and optional tool tip to be presented inthe task bar.
         * Call RemoveIcon() to remove the icon from the task bar.</summary>*/
        public bool SetIcon(Icon icon, string tooltip)
		{
			wxString txt = new wxString(tooltip);
			return wxTaskBarIcon_SetIcon(wxObject, Object.SafePtr(icon), Object.SafePtr(txt)); 	                      
		}
		
        /** <summary>This will remove the icon from the task bar.</summary>*/
		public bool RemoveIcon()
		{
			return wxTaskBarIcon_RemoveIcon(wxObject);
		}
		
        /** <summary>This method is called by the library when the user requests popup menu (on Windows and Unix platforms, this is when the user right-clicks the icon).
         * Override this function in order to provide popup menu associated with the icon.
         *
         * If CreatePopupMenu returns <c>null</c> (this happens by default), no menu is shown, otherwise the menu is displayed
         * and then deleted by the library as soon as the user dismisses it. The events can be handled by a class derived
         * from wx.TaskBarIcon.
         * 
         * Note, that the returned wrapper will loose ownership of the native wx menu immediately after this method has
         * been finished.</summary>*/
		public virtual Menu CreatePopupMenu()
		{  return null; }

        /** <summary>Pops up a menu at the current mouse position.
         * The events can be handled by a class derived from wx.TaskBarIcon.
         * \par Note
         * It is recommended to override <c>CreatePopupMenu()</c> callback instead of calling this method from event handler,
         * because some ports (e.g. wxCocoa) may not implement <c>PopupMenu()</c> and mouse click events at all.</summary>*/
		public bool PopupMenu(Menu menu)
		{
			return wxTaskBarIcon_PopupMenu(wxObject, Object.SafePtr(menu));
		}
		
        IntPtr DoCreatePopupMenu()
        {
            Menu menu=this.CreatePopupMenu();
            if (menu != null)
            {
                IntPtr menuPtr = menu.wxObject;
                menu.VirtualDispose();
                return menuPtr;
            }
            else
                return IntPtr.Zero;
        }

        /* HMaH
         * the original contribution used this method as default event handler
         * for pressing the icon in the task bar. however, the wxWidgets help file
         * states, that these events will not fire in every port of wxWidgets.
         * the manual suggests to use a direct implementation of CreatePopup instead.
         * this wrapper, thus, enable real overloading of CreatePopup
		void OnClick(object sender, wx.Event evt)
		{	
			wx.Menu popupMenu = CreatePopupMenu();
			if (popupMenu is Menu)
				PopupMenu(popupMenu);
		}
         */
	}
}
