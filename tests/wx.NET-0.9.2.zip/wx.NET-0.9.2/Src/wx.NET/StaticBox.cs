//-----------------------------------------------------------------------------
// wx.NET - StaticBox.cs
//
// The wxStaticBox wrapper class.
//
// Written by Bryan Bulten (bryan@bulten.ca)
// (C) 2003 Bryan Bulten
// Licensed under the wxWidgets license, see LICENSE.txt for details.
// $Id: StaticBox.cs,v 1.13 2009/09/20 14:10:58 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Drawing;
using System.Runtime.InteropServices;

namespace wx
{
    /** <summary>A static box is a rectangle drawn around other panel items to denote a logical grouping of items.
     *
     * Please note that a static box should not be used as the parent for the controls it contains,
     * instead they should be siblings of each other. Although using a static box as a parent might
     * work in some versions of wxWidgets, it results in a crash under, for example, <c>wxGTK</c>. 
     *
     * Also, please note that because of this, the order in which you create new controls is important.
     * Create your <c>wx.StaticBox</c> control before any siblings that are to appear inside the <c>wx.StaticBox</c> in order
     * to preserve the correct Z-Order of controls.</summary>*/
	public class StaticBox : Control
	{
		[DllImport("wx-c")] static extern IntPtr wxStaticBox_ctor();
		[DllImport("wx-c")][return:MarshalAs(UnmanagedType.U1)] static extern bool wxStaticBox_Create(IntPtr self, IntPtr parent, int id, IntPtr label, int posX, int posY, int width, int height, uint style, IntPtr name);
	
		//---------------------------------------------------------------------

		public StaticBox()
			: base(wxStaticBox_ctor()) { }

		public StaticBox(IntPtr wxObject)
			: base(wxObject) { }
			
		public StaticBox(Window window, int id, string label)
			: this(window, id, label, wxDefaultPosition, wxDefaultSize, 0, null) { }
			
		public StaticBox(Window window, int id, string label, Point pos)
			: this(window, id, label, pos, wxDefaultSize, 0, null) { }

		public StaticBox(Window window, int id, string label, Point pos, Size size)
			: this(window, id, label, pos, size, 0, null) { }

		public StaticBox(Window window, int id, string label, Point pos, Size size, wx.WindowStyles style)
			: this(window, id, label, pos, size, style, null) { }

		public StaticBox(Window window, int id, string label, Point pos, Size size, wx.WindowStyles style, string name)
			: this()
		{
			if (!Create(window, id, label, pos, size, style, name))
			{
				throw new InvalidOperationException("Failed to create StaticBox");
			}
		}
		
		//---------------------------------------------------------------------
		// ctors with self created id
		
		public StaticBox(Window window, string label)
			: this(window, Window.UniqueID, label, wxDefaultPosition, wxDefaultSize, wx.WindowStyles.NO_STYLE, null) { }
			
		public StaticBox(Window window, string label, Point pos)
			: this(window, Window.UniqueID, label, pos, wxDefaultSize, wx.WindowStyles.NO_STYLE, null) { }

		public StaticBox(Window window, string label, Point pos, Size size)
            : this(window, Window.UniqueID, label, pos, size, wx.WindowStyles.NO_STYLE, null) { }

        public StaticBox(Window window, string label, Point pos, Size size, wx.WindowStyles style)
			: this(window, Window.UniqueID, label, pos, size, style, null) { }

        public StaticBox(Window window, string label, Point pos, Size size, wx.WindowStyles style, string name)
			: this(window, Window.UniqueID, label, pos, size, style, name) {}

		//---------------------------------------------------------------------

        public bool Create(Window window, int id, string label, Point pos, Size size, wx.WindowStyles style, string name)
        {
            return this.Create(window, id, wxString.SafeNew(label), pos, size, style, wxString.SafeNew(name));
        }
        public bool Create(Window window, int id, wxString label, Point pos, Size size, wx.WindowStyles style, wxString name)
		{
			return wxStaticBox_Create(wxObject, Object.SafePtr(window), 
					id, Object.SafePtr( label), pos.X, pos.Y, size.Width, size.Height, 
					(uint)style, Object.SafePtr( name));
		}
	}
}
