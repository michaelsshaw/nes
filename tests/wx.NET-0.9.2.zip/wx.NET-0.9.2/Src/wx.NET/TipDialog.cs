//-----------------------------------------------------------------------------
// wx.NET - TipDialog.cs
//
// The wxTipProvider proxy interface.
//
// Written by Alexander Olk (xenomorph2@onlinehome.de)
// (C) 2003 by Alexander Olk
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: TipDialog.cs,v 1.5 2010/06/05 11:58:52 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Drawing;
using System.Runtime.InteropServices;

namespace wx
{
	/// <summary>
	/// Offers opportunity to display a unique tip dialog showing tips from a file.
	/// </summary>
    public class TipProvider
    {
	[DllImport("wx-c")] static extern IntPtr wxCreateFileTipProvider_func(IntPtr filename, int currentTip);
	[DllImport("wx-c")][return:MarshalAs(UnmanagedType.I1)] static extern bool wxShowTip_func(IntPtr parent, bool showAtStartup);
	[DllImport("wx-c")] static extern int wxTipProvider_GetCurrentTip();

	/// <summary>
	/// Creates a tip provider.
	/// </summary>
	/// <param name="filename">Name of the file providing the tips-
	/// </param>
	/// <param name="currentTip">Index of the current tip.
	/// </param>
    public static void CreateFileTipProvider(string filename, int currentTip)
    {
        TipProvider.CreateFileTipProvider(wxString.SafeNew(filename), currentTip);
    }
	/// <summary>
	/// Creates a tip provider.
	/// </summary>
	/// <param name="filename">Name of the file providing the tips-
	/// </param>
	/// <param name="currentTip">Index of the current tip.
	/// </param>
	public static void CreateFileTipProvider(wxString filename, int currentTip)
	{
		wxCreateFileTipProvider_func(Object.SafePtr( filename), currentTip);
	}

		/// <summary>
		/// Shows the dialog.
		/// </summary>
		/// <param name="parent">This shall be the parent of the tip dialog.
		/// </param>
		/// <returns>True on success.
		/// </returns>
	public static bool ShowTip(Window parent)
	{
		return wxShowTip_func(Object.SafePtr(parent), true);
	}

		/// <summary>
		/// Shows the dialog.
		/// </summary>
		/// <param name="parent">This shall be the parent of the tip dialog.
		/// </param>
		/// <returns>True on success.
		/// </returns>
	public static bool ShowTip(Window parent, bool showAtStartup)
	{
		return wxShowTip_func(Object.SafePtr(parent), showAtStartup);
	}

		/// <summary>
		/// Returns the current tip.
		/// </summary>
	public static int CurrentTip
	{
		get { return wxTipProvider_GetCurrentTip(); }
	}
    }
}
