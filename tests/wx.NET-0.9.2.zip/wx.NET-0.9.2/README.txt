wx.NET Source README
====================

wx.NET is a .NET Common Language Infrastructure (CLI) wrapper for wxWidgets. 
It is composed of two parts:

   + wx-c is a C++ library which exposes the wxWidgets API as a 
     collection of C# friendly functions. It is named libwx-c.so 
     on Linux, wx-c.dylib on MacOS X, and wx-c.dll on Windows.

   + wx.NET is a .NET assembly written in C# which parallels the wxWidgets 
     class hierarchy. It is named wx.NET.dll on all platforms.

Please review the HTML user's manual online at http://wxnet.sf.net/apiref/
or start Bin/helpview.exe. It contains detailed build instructions and 
other important information.

You will need .NET-Framework 2.0 and the VC 2008 x86 C++ redistributable package 
under Windows or mono (http//www.go-mono.org) to run the programs.
Windows users can find a version of the VC++ redistributable package in folder
"Install".

Start Sample-Launcher.exe with double-click under Windows or with
> mono Sample-Launcher.exe 
in a Linux X-terminal.

wx.NET is distributed under the wxWidgets license. Please see LICENSE.txt.

You can find more information about wx.NET at:

   http://wxnet.sf.net/

-------------------------------

This distribution comes with the complete source code, compiled assemblies
and demo programs, and compiled versions of the wx-c-0-9-0-1.dll for 32-Bit
Windows platforms and a libwx-c-0-9-0-1.so compiled on OpenSuse 11.2 in
"i586" architecture. The Linux library requires GTK+ 2.0.
The containes wx.Net.dll has a strong name signed with my private key.
You may install wx.Net.dll in the global assembly cache and put wx-c-0-9-0-1.dll
into the Windows/System32 directory without any risk of side effects with other
versions of the software.
In contrast, the shipped source files refer to the standard name of the
native DLL: wx-c.dll, or libwx-c.so respectively.
 
