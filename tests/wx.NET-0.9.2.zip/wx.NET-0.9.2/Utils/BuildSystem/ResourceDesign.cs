/** Build system for wx.NET.
 * 
 * This DLL contains basic implementations to build (compile and link) C/C++ programs,
 * compile .NET assemblies written in C#, sign them, and install them.
 * 
 * \file 
 *
 * Copyright 2009 Harald Meyer auf'm Hofe harald_meyer@users.sourceforge.net
 * 
 * Licensed under the wxWidgtes license, see LICENSE.txt for details.
 * 
 * $Id: ResourceDesign.cs,v 1.11 2010/03/21 20:50:05 harald_meyer Exp $
 */

using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Text;
using System.IO;

namespace wx.Build
{
    /// <summary>
    /// Resource designators describe resources as input to the assembly linker or compiler.
    /// Instances of this class are used in instances of wx.Build.Net.CSharpAssemblyProject to
    /// define resources.
    /// Resource designators amend a content file with an internal name that this file will have
    /// as a resource in an assembly.
    /// </summary>
    /// <remarks>
    /// If the resource has been compiled into the assembly, either ZipResource or the
    /// ManifestResourceInfo may be used to read it. Use the \c ResourceDesignator.Name
    /// to designate the resource. Assume the following project definition.
    /// <code>
    /// wx.Build.Net.CSharpAssemblyProject project = new wx.Build.Net.CSharpAssemblyProject(ProjectPreference.Default,
    ///             "ResourceDesignatorSample",
    ///             "program.exe",
    ///             "Exemplifies declaration and use of resources.");
    /// project.Resources=new wx.Build.ResourceDesignator[] {
    ///     new wx.Build.ResourceDesignator(new wx.Build.ContentFile(wx.Build.ContentType.PNG, "APicture.png"), "APicture_PNG")
    /// };
    /// </code>
    /// Then, use the following code to access the data.
    /// <code>
    /// ManifestResourceInfo rsInfo = callingAssembly.GetManifestResourceInfo("APicture_PNG");
    /// if (rsInfo != null)
    /// {
    ///    Stream resourceStream = resourceAssembly.GetManifestResourceStream(derivate);
    ///    BinaryReader reader = new BinaryReader(resourceStream);
    ///    byte[] resourceBytes = reader.ReadBytes((int)resourceStream.Length);
    /// }
    /// </code>
    /// Another use case are external resources. These resource will not compiled into an assembly, but the build system
    /// will take care that these files are at the appropiate place after building the project. In this scenario, the internal
    /// name of the resource is the relative filename that will be used in the program code to load the resource.
    /// Here again we have two cases:
    /// <list type="bullet">
    /// <item>The resource is already at the appropriate place, i.e. original filename of the resource and internal
    /// name are the same. Thsi scenario might appear useless but note that meta projects like
    /// wx.Build.Release.MakeReleaseProject
    /// use this information to copy the resources in such a way that they are at the required position relative to the 
    /// createds program code.</item>
    /// <item>Orginal filename and resource name differ. In that case, the project will create actions to copy
    /// the original file to the desired directory.</item>
    /// </list>
    /// The following example contains a declaration for both of the abovementioned use cases.
    /// <code>
    /// wx.Build.Net.CSharpAssemblyProject project = new wx.Build.Net.CSharpAssemblyProject(ProjectPreference.Default,
    ///             "ResourceDesignatorSample",
    ///             "program.exe",
    ///             "Exemplifies declaration and use of resources.");
    /// project.ExternalResources = new ResourceDesignator[] {
    ///    new ResourceDesignator(ContentType.PNG, "..\\Images\\APictureToCopy.PNG", "Images\\APictureCopied.PNG")
    ///    new ResourceDesignator(ContentType.PNG, "Images\\APictureAlreadyAtTheDesiredPlace.PNG")
    /// };
    /// </code>
    /// </remarks>
    public class ResourceDesignator : IBuildProduct, System.Xml.Serialization.IXmlSerializable
    {
        #region State
        ISingleFileProduct _resourceFile;
        string _name;
        bool _private = false;
        #endregion

        #region CTor
        /// <summary>
        /// Creates an empty resource. Use this CTor only to create an instance that reads its properties from an
        /// XML stream using ReadXml().
        /// </summary>
        public ResourceDesignator()
        {
            this._resourceFile = null;
            this._name = "";
        }

        /// <summary>
        /// This will assign an automatically created name to the provided <c>resourceFile</c>.
        /// The name will consist of the base file name without extension plus underscrore "_" plus extension of the file.
        /// </summary>
        /// <param name="resourceFile">Typically a content file but maybe also a project implementing ISingleFileProduct.</param>
        public ResourceDesignator(ISingleFileProduct resourceFile)
        {
            this._name = Path.GetFileName(resourceFile.File.FileName).Replace('.', '_');
            this._resourceFile = resourceFile;
        }

        /// <summary>
        /// This creates an instance referring to a resource of the provided type that will be read from the provided filename.
        /// The program code will refer to the specified internal name.
        /// </summary>
        /// <param name="t">Type of the resource.</param>
        /// <param name="originalFilename">Filename of the resource.</param>
        /// <param name="internalName">The internal name that will be used bythe program code to refer to the resource. There
        /// are 2 uswe cases:
        /// <list type="bullet">
        /// <item>The name is a flat string representing the file in the manifest stream (.NET resource system).
        /// The resource designator has been used in conjunction with wx.Build.Net.CSharpAssemblyProject.Resources.</item>
        /// <item>The name is a relative filename (relative to the produced program if the resource designator has been used
        /// in conjunction with wx.Build.Net.CSharpAssemblyProject.ExternalResources.
        /// </item></list>
        /// </param>
        public ResourceDesignator(ContentType t, string originalFilename, string internalName)
            : this(new ContentFile(t, originalFilename), internalName)
        {
        }

        /// <summary>
        /// This designates a resource consisting of the content of <c>resourceFile</c> that may be retrieved by the internal <c>name</c>.
        /// </summary>
        /// <param name="resourceFile">The resource file.</param>
        /// <param name="name">This defines the name that will be used to refer to the represented resource. 2 Use cases:
        /// <list type="bullet">
        /// <item>The name is a flat string representing the file in the manifest stream (.NET resource system).
        /// The resource designator has been used in conjunction with wx.Build.Net.CSharpAssemblyProject.Resources.</item>
        /// <item>The name is a relative filename (relative to the produced program if the resource designator has been used in conjunction with
        /// </item></list>
        /// </param>
        public ResourceDesignator(ContentFile resourceFile, string name)
        {
            this._name = name;
            this._resourceFile = resourceFile;
        }

        /// <summary>This designates a resource consisting of the content of <c>resourceFile</c> that may be retrieved by
        /// the internal <c>name</c>.</summary>
        /// <param name="resourceFile">The source file that this instance designates.</param>
        /// <param name="name">The internal name that will be used bythe program code to refer to the resource. There
        /// are 2 uswe cases:
        /// <list type="bullet">
        /// <item>The name is a flat string representing the file in the manifest stream (.NET resource system).
        /// The resource designator has been used in conjunction with wx.Build.Net.CSharpAssemblyProject.Resources.</item>
        /// <item>The name is a relative filename (relative to the produced program if the resource designator has been used
        /// in conjunction with wx.Build.Net.CSharpAssemblyProject.ExternalResources.
        /// </item></list>
        /// <param name="isThisPrivate">Indicates with <c>true</c> that the resource shall be linked privately.
        /// This flag will only be used when the resource is compiled into the manifest. If this refers to an
        /// external resource, this flag will be ignored,</param>
        public ResourceDesignator(ContentFile resourceFile, string name, bool isThisPrivate)
        {
            this._name = name;
            this._resourceFile = resourceFile;
            this._private = isThisPrivate;
        }

        /// <summary>
        /// This produces a collection of resource designators that refer to files in a particular directory.
        /// The files will be selected according to a search pattern according to System.IO.Directory.GetFiles().
        /// The internal name will be created due to the provided destination path. Refer to , Net.CSharpAssemblyProject.ExternalResources.
        /// </summary>
        /// <remarks>
        /// Example: Assume, that directory "..\\Images" contains the files "img01.png" and "img02.jpg".
        /// <code>
        /// ICollection&lt; ResourceDesignator &gt; resultPNG=ResourceDesignator.SelectExternalResources(ContentType.PNG, "..\\Images", "*.png", "..\\Images");
        /// ICollection&lt; ResourceDesignator &gt; resultJPG=ResourceDesignator.SelectExternalResources(ContentType.JPEG, "..\\Images", "*.jpg", "..\\Images");
        /// ICollection&lt; ResourceDesignator &gt; resultERROR=ResourceDesignator.SelectExternalResources(ContentType.PNG, "..\\Images", "*.*", "..\\Images");
        /// </code>
        /// <list type="bullet">
        /// <item><c>resultPNG</c> will contain exactly on resource designator referring to file "..\\Images\\img01.png" and declaring the internal name "..\\Images\\img01.png".</item>
        /// <item><c>resultJPG</c> will contain exactly on resource designator referring to file "..\\Images\\img02.jpg" and declaring the internal name "..\\Images\\img02.jpg".</item>
        /// <item><c>resultERROR</c> will contain two resource designators referring to the files "..\\Images\\img01.png" and "..\\Images\\img02.jpg" but assuming content type PNG for
        /// both files. This is likely to get you in trouble because the logic of the build system will assume the wrong content type for the JPEG file "img2.jpg".</item>
        /// </list>
        /// </remarks>
        /// <param name="t">The content type that will be assumed for the resulting resources.</param>
        /// <param name="srcDirectoryPath">The directory, where the resources will be searched.</param>
        /// <param name="searchPattern">The search pattern including wild cards that can be interpreted by System.IO.Directory.GetFiles().</param>
        /// <param name="destDirPath">This is the directory that will be used to create the resource name. This must be a relative path. "." or "" will
        /// cause the build procedure to place the resource side by side with the created assembly.</param>
        /// <returns>Collection of resource designators that are appropriate to represent external resources.</returns>
        /// <seealso cref="wx.Build.Net.CSharpAssemblyProject"/>
        public static ICollection<ResourceDesignator> SelectExternalResources(ContentType t, string srcDirectoryPath, string searchPattern, string destDirPath)
        {
            if (destDirPath != null)
                destDirPath=destDirPath.Trim();
            List<ResourceDesignator> result = new List<ResourceDesignator>();
            string absDirPath = Path.Combine(BuildConfig.PathRoot, srcDirectoryPath);
            absDirPath=Path.GetFullPath(absDirPath);
            string[] filenames=System.IO.Directory.GetFiles(absDirPath, searchPattern, SearchOption.TopDirectoryOnly);
            if (filenames != null)
            {
                foreach (string filename in filenames)
                {
                    string noDir = Path.GetFileName(filename);
                    string relocatedFilename = Path.Combine(srcDirectoryPath, noDir);
                    string internalName=noDir;
                    if (destDirPath != null
                        && destDirPath != ""
                        && destDirPath != ".")
                        internalName = Path.Combine(destDirPath, internalName);
                    result.Add(new ResourceDesignator(t, relocatedFilename, internalName));
                }
            }
            return result;
        }
        #endregion

        #region Properties
        /// <summary>
        /// Returns the name that the resource will have in the assembly.
        /// If this resource will be compiled into the assembly, this is usually a flat name
        /// consisting excusively of lower case letters without dots, slashes, and backslashes.
        /// If this is an external resource, this is a relative path the will be used to compute
        /// a target position of the resource.
        /// </summary>
        /// <seealso cref="wx.Build.Net.CSharpAssemblyProject"/>
        public string Name { get { return this._name; } }

        /** <summary> This is the file that provides the content. </summary> */
        public ContentFile ResourceFile { get { return this._resourceFile.File; } }

        /// <summary>
        /// The resource is in fact a ISingleFileProduct.
        /// This is the instance actually representing the resource. This will differ from
        /// <c>ResourceFile</c> iff the resource is a project rather like an explicitely known file.
        /// </summary>
        public ISingleFileProduct ResourceFileProject { get { return this._resourceFile; } }

        /** <summary> True iff this is will be private to the assembly. </summary> */
        public bool IsPrivate { get { return this._private; } }

        #endregion

        #region Helper Methods
        /// <summary>
        /// Use this to get the filename that a program will expect this resource to have, if this
        /// is used as external resource.
        /// </summary>
        /// <param name="dirOfUsingAssembly">The directory where the program resides that uses this resource.
        /// This method will expect that the program uses the internal name relatively to this directory.</param>
        /// <returns>The filename that a program will expect this resource to have.</returns>
        public ContentFile DestinationOfExternalResource(string dirOfUsingAssembly)
        {
            string absInternalName = Path.Combine(dirOfUsingAssembly, this._resourceFile.File.BaseFileName);
            return new ContentFile(this._resourceFile.Type, absInternalName);
        }

        /// <summary>
        /// True iff DestinationOfExternalResource() is equal to the resource file. In this case, the resource
        /// shall not be copied in order to build a runnable version of the program.
        /// </summary>
        /// <param name="dirOfUsingAssembly">The directory where the program resides that uses this resource.
        /// This method will expect that the program uses the internal name relatively to this directory.</param>
        public bool DoNotCopyIfExternalReference(string dirOfUsingAssembly)
        {
            return this._resourceFile.Equals(DestinationOfExternalResource(dirOfUsingAssembly));
        }
        #endregion

        #region IBuildProduct Member
        /** <summary> This is a target on itself. </summary> */
        public ICollection<IBuildProduct> GetTargets()
        {
            return new wx.Build.IBuildProduct[] { this };
        }

        /// <summary>
        /// Returns an array containing the resource of the resource is a project.
        /// </summary>
        public ICollection<RefToProject> GetProjects()
        {
            if (this._resourceFile is RefToProject)
                return new RefToProject[] { (RefToProject)this._resourceFile };
            else
                return null;
        }

        /** <summary> Simply return <c>true </c> . </summary> */
        public bool Execute(BuildToolFamilyEnv env, DateTime validityOfBuildSystem)
        {
            return this._resourceFile.File.Execute(env, validityOfBuildSystem);
        }

        #endregion

        #region IBuildProduct Member

        public DateTime GetValidity()
        {
            return this._resourceFile.GetValidity();
        }

        public DateTime GetValidityDemand()
        {
            return this._resourceFile.GetValidityDemand();
        }
        #endregion

        #region Overrides
        public int CompareTo(object o)
        {
            if (o is ResourceDesignator)
            {
                ResourceDesignator arg = (ResourceDesignator)o;
                int cmp = 0;
                if (cmp == 0)
                    cmp = this._resourceFile.CompareTo(arg._resourceFile);
                if (cmp == 0)
                    cmp = this._name.CompareTo(arg._name);
                if (cmp == 0)
                    cmp = this._private.CompareTo(arg._private);
                return cmp;
            }
            else
                return this.GetType().FullName.CompareTo(o.GetType().FullName);
        }

        public override bool Equals(object obj)
        {
            if (obj is ResourceDesignator)
                return this._resourceFile.Equals(((ResourceDesignator)obj)._resourceFile)
                    && this._name.Equals(((ResourceDesignator)obj)._name);
            else
                return false;
        }

        public override int GetHashCode()
        {
            return this._resourceFile.GetHashCode();
        }

        public override string ToString()
        {
            return string.Format("{0}={1}", this._name, this._resourceFile)+(this._private?" (private)":"");
        }
        #endregion

        #region IXmlSerializable Member

        public System.Xml.Schema.XmlSchema GetSchema()
        {
            return null;
        }

        public void ReadXml(System.Xml.XmlReader reader)
        {
            if (reader.IsStartElement("resource_designator"))
            {
                this._name = reader.GetAttribute("name");
                string privateString = reader.GetAttribute("private");
                this._private = Convert.ToBoolean(privateString);
                string assemblyName = reader.GetAttribute("assembly");
                string typeName = reader.GetAttribute("type");
                reader.Read();
                System.Reflection.Assembly assembly = typeof(BuildProject).Assembly;
                if (assemblyName != null)
                    assembly = System.Reflection.Assembly.Load(assemblyName);
                System.Type t = assembly.GetType(typeName);
                this._resourceFile = (ISingleFileProduct)Activator.CreateInstance(t);
                this._resourceFile.ReadXml(reader);
                reader.ReadEndElement();
            }
            else
                reader.ReadStartElement("resource_designator"); // This will produce an exception
        }

        public void WriteXml(System.Xml.XmlWriter writer)
        {
            writer.WriteStartElement("resource_designator");
            writer.WriteAttributeString("name", this._name);
            writer.WriteAttributeString("private", this._private.ToString());
            if (this._resourceFile.GetType().Assembly != typeof(BuildProject).Assembly)
                writer.WriteAttributeString("assembly", this._resourceFile.GetType().Assembly.FullName);
            writer.WriteAttributeString("type", this._resourceFile.GetType().FullName);
            this._resourceFile.WriteXml(writer);
            writer.WriteEndElement();
        }

        #endregion
    }
}
