/** Build system for wx.NET.
 * 
 * This DLL contains basic implementations to build (compile and link) C/C++ programs,
 * compile .NET assemblies written in C#, sign them, and install them.
 * 
 * \file 
 *
 * Copyright 2009 Harald Meyer auf'm Hofe harald_meyer@users.sourceforge.net
 * 
 * Licensed under the wxWidgtes license, see LICENSE.txt for details.
 * 
 * $Id: CxxCompiler.cs,v 1.7 2010/01/24 13:37:54 harald_meyer Exp $
 */



using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

using System.Text.RegularExpressions;

namespace wx.Build.Cxx
{
    /** <summary> Used to represent the desired degree of optimization in CxxCompilerParameters. </summary> */
    public enum CxxOptimization
    {
        /** <summary> Do not optimize. </summary> */
        No, 

        /** <summary> Prefers to create compact code. </summary> */
        CompactCode,

        /** <summary> Prefers to create fast code. </summary> */
        FastCode,

        /** <summary> Specifies overall optimization that does not particularly focus on code size nor optimization of run time. </summary> */
        OverallOptimization,
    }

    /** <summary> Warning levels in CxxCompilerParameters. </summary> */
    public enum CxxWarningLevel
    {
        /** <summary> Suppress all warnings. </summary> */
        NoWarnings,

        /** <summary> Print only the most significant warnings. </summary> */
        ImportantWarnings,

        /** <summary> Also print <c>ImportantWarnings </c>  and, addionally, less significant warnings. </summary> */
        BasicWarnings,

        /** <summary> Print <c>BasicWarnings </c>  and those warnings referring to production stable code. </summary> */
        QualityWarnings,
    }

    /** <summary> This is an enumeration for the platform independent notation of libraries that shall be linked in order to build a project.
    * Operating systems and development environments usually provide a large number of optional components that might be linked
    * to the built program if required. This enumeration provides a small collection of abstract notations for such options
    * that may be used in CxxParameters to describe platform independent some libraries that shall be linked.
    * The conversion of these enumerations into concrete "link with" directives will be done by the implementations
    * of the actions.
    *
    * The idea is to enable portable programs to be compiled for different platforms using the same build
    * project definition. However, the program unfortunately has still to be portable, i.e. use conditional
    * compilation to adopt itself to different platforms. Another viable option is to use portable frameworks
    * like wxWidgets.
    *
    * wxWidgets is not mentioned here, since libraries and paths shall not be determined by a specific tool.
    * The handling of wxWidgets is quite the same for all compilers (operating on a particular platform). For
    * example MS Visual Studio compilers and linkers will access wxWidgets in rather the same way as MingW
    * will do. These flags will be interpreted by the particular tool. So, wxWidgets is rather its own tool than
    * a flag in this enumeration. </summary> */
    [Flags]
    public enum CxxLibraries
    {
        /** <summary> This is not a flag but a name for the absence of any flag.
        * The absence of any standard lib flag will usually be translated into flags that tell compiler
        * and linker to ignore standard libraries. </summary> */
        NoStdLibraries=0,

        /** <summary> This tells linker to link with a library providing basic C functions.
        * Typically, this enables <c>libc </c> .so and <c>libm </c> .so (Unix). The MS VC compiler
        * tells already the compiler to link for a specific implementation of this class
        * of functions. </summary> */
        BasicCLibraries=1,

        /** <summary> Libraries of basic C++ functionality typically only usable in C++ compilation mode (mangled symbols).
        * This includes implementations of the STL. </summary> */
        BasicCPlusPlusLibraries=2,

        /** <summary> Libraries providing basic access to the operating system.
        * On MS Windows, this includes <c>kernel32 </c> .lib, <c>user32 </c> .lib, <c>shell32 </c> .lib, <c>advapi32 </c> .lib,
        * <c>ole32 </c> .lib, <c>oleaut32 </c> .lib. </summary> */
        GeneralOSLibraries = 4,

        /** <summary> Libraries supporting standard graphical user interfaces.
        * Under MS Windows, this includes <c>gdi32 </c> .lib, <c>gdiplus </c> .lib, <c>comdlg32 </c> .lib, <c>comctl32 </c> .lib
        * but no MFC stuff.
        * Under Unix, this will comprise X Windows and Gnome libraries. </summary> */
        GDILibraries = 8,

        /** <summary> Libraries providing access to basic remoting and networking capabilities.
        * On MS Windows, this includes <c>rpcrt4 </c> .lib, <c>wsock32 </c> .lib. </summary> */
        TcpAndRpcLibraries =16,
    }

    /** <summary> Represents a collection of include paths and some services that depend on these paths.
     * Use instances of this class to store the include paths.
     * Then you may use CheckDependencies() to read paths to included sources. </summary> */
    public class CollectionOfIncludePaths : ICollection<string>
    {
        #region State
        List<string> _paths = new List<string>();
        bool _readOnly = false;
        #endregion

        #region CTor
        public CollectionOfIncludePaths()
        {
        }
        #endregion

        #region ICollection<string> Member
        /** <summary> This will add the provided <c>includePath </c>  at the end of the current collection of paths. </summary> */
        public void Add(string includePath)
        {
            if (this._readOnly)
                throw new NotSupportedException("Cannot Add() to readonly collection.");
            includePath = BuildConfig.GetFullPathname(includePath);
            if (Directory.Exists(includePath))
                this._paths.Add(includePath);
        }

        public void Clear()
        {
            if (this._readOnly)
                throw new NotSupportedException("Cannot Clear() to readonly collection.");
            this._paths.Clear();
        }

        public void AddRange(ICollection<string> includePaths)
        {
            if (this._readOnly)
                throw new NotSupportedException("Cannot Add() to readonly collection.");
            this._paths.AddRange(includePaths);
        }

        public bool Contains(string includePath)
        {
            return this._paths.Contains(includePath);
        }

        public void CopyTo(string[] array, int arrayIndex)
        {
            this._paths.CopyTo(array, arrayIndex);
        }

        public int Count
        {
            get { return this._paths.Count; }
        }

        public bool IsReadOnly
        {
            get { return this._readOnly; }
        }

        /** <summary> After calling this method, all modifiers of this instance will throw exceptions. </summary> */
        public void SetReadOnly()
        {
            this._readOnly = true;
        }

        public bool Remove(string includePath)
        {
            if (this._readOnly)
                throw new NotSupportedException("Cannot Remove() from readonly collection.");
            return this._paths.Remove(includePath);
        }

        #endregion

        #region IEnumerable<string> Member

        public IEnumerator<string> GetEnumerator()
        {
            return this._paths.GetEnumerator();
        }

        #endregion

        #region IEnumerable Member

        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            return this._paths.GetEnumerator();
        }

        #endregion

        #region Find Dependencies
        /** <summary> Finds file of base name <c>filename </c>  (with extension) into one of the contained directories and returns the absolute paths. </summary> */
        public ContentFiles FindFile(string filename)
        {
            return this.FindFile(null, filename);
        }

        /** <summary> This will first look for <c>filename </c>  in <c>additionalPath </c>  and then in the contained paths.</summary><remarks>
         * Each match will be added to the result.
         * \param additionalPath designates an additional directory that will be searched first before
         *  visiting the contained directories. </remarks> */
        public ContentFiles FindFile(string additionalPath, string filename)
        {
            ContentFiles result = new ContentFiles(ContentType.CPlusPlusInclude);
            if (additionalPath != null)
            {
                if (File.Exists(Path.Combine(additionalPath, filename)))
                {
                    result.Add(Path.Combine(additionalPath, filename));
                }
            }
            foreach (string path in this)
            {
                string fullFilename = Path.Combine(path, filename);
                if (File.Exists(fullFilename))
                {
                    result.Add(fullFilename);
                }
            }
            return result;
        }

        /// <summary>Returns a collection of files that are included by source file <c>sourceFile</c>.
        /// <para>This will look for the #include keyword and collect all filenames of includes.
        /// These files will then be searched in the stored directories. Missing include 
        /// files will be silently ignored. All found files will also be searched for includes
        /// and so on.</para>
        /// </summary>
        /// <param name="sourceFile">The source file that will be analysed.</param>
        public ContentFiles GetPathToIncludes(string sourceFile)
        {
            ContentFiles filenames = new ContentFiles(ContentType.CPlusPlusInclude);
            if (File.Exists(sourceFile))
            {
                Regex regexLocalInclude = new Regex("^ *#include *\"(?<filename>[^\"]*)\"", RegexOptions.Compiled | RegexOptions.Singleline);
                Regex regexGlobalInclude = new Regex("^ *#include *<(?<filename>[^>]*)>", RegexOptions.Compiled | RegexOptions.Singleline);

                TextReader reader = new StreamReader(sourceFile);
                while (true)
                {
                    string line = reader.ReadLine();
                    if (line == null)
                        break;
                    foreach (Match match in regexLocalInclude.Matches(line))
                    {
                        filenames.AddRange(this.FindFile(Path.GetDirectoryName(sourceFile), match.Groups["filename"].Value));
                    }
                    foreach (Match match in regexGlobalInclude.Matches(line))
                    {
                        filenames.AddRange(this.FindFile(match.Groups["filename"].Value));
                    }
                }
            }
            return filenames;
        }
        #endregion

        #region Overrides
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Include from ");
            bool first = true;
            foreach (string pathname in this)
            {
                if (!first)
                    sb.Append(", ");
                sb.Append(pathname);
                first = false;
            }
            return sb.ToString();
        }
        #endregion
    }

    /** <summary> Portable set of parameters for running C/C++ compilers and linkers. </summary> */
    public class CxxParameters : BuildParameters
    {
        #region Private State
        Dictionary<string, string> _options = new Dictionary<string, string>();
        #endregion

        /** <summary>If this is turned on (standard), the compiler will mangle the signature (types of the argument list) into the symbol of the function in the object code.
         * This is common practice in C++ compilation. C++ compilers use this feature to allow different implementations of functions as long as
         * they are declared with different argument lists. C allows each function name to be used only once. Mangling can be turned off
         * by the program code declaring a functions as \c extern \c "C".
         * 
         * There is no standard for the C++ mangling of function names. So, DLLs providing mangled symbols for functions can only be used
         * by code that is compiled with the same compiler.
         * </summary>
         */
        public bool CompileAsCxx = true;

        /** <summary>Determines desired optimizations.</summary>
         */
        public CxxOptimization Optimization = CxxOptimization.OverallOptimization;

        /** <summary>Enables use of exceptions.
         * If \c true (the default), the created code will be able to catch exceptions.
         * This can be turned off (not recommended) because this causes significant overhead.
         * 
         * For instance using \c cl.exe (Microsoft compiler), this will enable option <c>/EHsc</c>.
         * </summary>
         */
        public bool EnableExceptions = true;

        /** <summary>Code is considered to be compilable reusing old code.
         * This enables features like "minimal rebuild" that usually presuppose, that classes, structs, and other data types
         * share the same declaration throughout the system. This is a good idea anyway but C/C++ allows all kinds of rubish
         * to become source code.</summary>
         */
        public bool Incremental = false;

        /** <summary>Compiles debug info into the code.
         * 
         * For instance applied to the \c cl.exe Microsoft compiler, this will enable option <c>/Zi</c>.</summary>
         */
        public bool DebugInfo = false;

        /** <summary>Paths where the compiler should look for include files.
         * These are typically paths to global include files that do NOT depend to the compiler distribution.
         * Paths to includes that have been shipped with the compiler will be added by the tool.
         * Additionally, C/C++-projects may add paths that are specific to the project.</summary>
         */
        public CollectionOfIncludePaths IncludePaths = new CollectionOfIncludePaths();

        /** <summary>Warning level.</summary>
         */
        public CxxWarningLevel WarningLevel = CxxWarningLevel.ImportantWarnings;

        /** <summary>Libraries that shall be linked with the project.</summary>
        */
        public CxxLibraries Libraries = CxxLibraries.BasicCLibraries
            | CxxLibraries.BasicCPlusPlusLibraries
            | CxxLibraries.GDILibraries
            | CxxLibraries.GeneralOSLibraries
            | CxxLibraries.TcpAndRpcLibraries;

        /** <summary>Globally defined features.</summary>
        */
        public FeatureList Features = new FeatureList();

        #region CTor
        /** <summary>The standard CTor might also define some tool specific options (cf. SetOptions()).</summary>
         * <remarks>
         * You may reconfigure some default tool specific options.
         * \li cl.exe defines WINVER to 0x400, the sysmbols WIN32, _WINDOWS, _MBCS (multi-byte string support), _UNICODE,
         *     _WINDLL (relocatible code), precise floating point model...
         * \li link.exe defines /MANIFESTUAC:"level='asInvoker' uiAccess='false'"
         * </remarks>
         */
        public CxxParameters()
        {
            this.SetOptions("cl.exe", "/D \"WINVER=0x400\" /D WIN32 /D _WINDOWS /D _MBCS /D _UNICODE /D _MT /D _WINDLL /Gy /fp:precise /FC");
            this.SetOptions("link.exe", "/MANIFESTUAC:\"level='asInvoker' uiAccess='false'\" /MACHINE:X86");
        }

        public override BuildParameters Clone()
        {
            return (BuildParameters)this.MemberwiseClone();
        }
        #endregion

        #region Options
        /** <summary>Options that are specific to a particular tool.
         * C/C++ knows a lot of tools using important non-standard options.
         * This is the place where to define these options. They may be on stack allocation,
         * packing structure, floting point arithmetics etc.
         * 
         * If this parameter set does not know options particular to <c>toolName</c>, the
         * result will be an empty string.</summary>
         */
        public string GetOptions(string toolName)
        {
            if (this._options.ContainsKey(toolName))
                return this._options[toolName];
            else
                return "";
        }

        /** <summary>Options that are specific to a particular tool.
         * C/C++ knows a lot of tools using important non-standard options.
         * This is the place where to define these options. They may be on stack allocation,
         * packing structure, floting point arithmetics etc.
         * 
         * If this already knows options particular to \c toolName, those will be replaced.
         * <c>GetOptions(toolName)</c> will return \c options after calling this.
         * </summary>
         */
        public void SetOptions(string toolName, string options)
        {
            this._options[toolName] = options;
        }

        /** <summary>Options that are specific to a particular tool.
         * C/C++ knows a lot of tools using important non-standard options.
         * This is the place where to define these options. They may be on stack allocation,
         * packing structure, floting point arithmetics etc.
         * 
         * Already known options will be extended by \c options (string concattenation:
         * <c>old options + ' ' + options</c>). Otherwise, this is equivalent to SetOptions().
         * </summary>
         * <returns>the options of <c>toolName</c> after processing the method (equivalent to GetOptions()).</returns>
         */
        public string AddOptions(string toolName, string options)
        {
            if (this._options.ContainsKey(toolName))
                this._options[toolName] = this._options[toolName] + " " + options;
            else
                this._options[toolName] = options;
            return this._options[toolName];
        }

        /** <summary>This is a copy of the tool specific options that have been added by AddOptions().</summary>
        */
        public ToolSpecificOptionsCollection Options
        {
            get
            {
                return new ToolSpecificOptionsCollection(this._options);
            }
        }
        #endregion
    }


}
