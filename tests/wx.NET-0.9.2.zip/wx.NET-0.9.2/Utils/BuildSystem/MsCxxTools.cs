/** Build system for wx.NET.
 * 
 * This DLL contains basic implementations to build (compile and link) C/C++ programs,
 * compile .NET assemblies written in C#, sign them, and install them.
 * 
 * \file 
 *
 * Copyright 2009-2010 Harald Meyer auf'm Hofe harald_meyer@users.sourceforge.net
 * 
 * Licensed under the wxWidgtes license, see LICENSE.txt for details.
 * 
 * $Id: MsCxxTools.cs,v 1.17 2010/06/16 18:12:32 harald_meyer Exp $
 */



using System;
using System.Collections.Generic;
using System.IO;

using wx.Build.Cxx;

namespace wx.Build.MS
{
    /** <summary> Toolwrapper of the MS C/C++ compiler as shipped e.g. with Visual Studio (Express) or, for free, with the platform SDK.
     * This tool defines symbol  <code>_MSC_VER</code>. You may use this for conditional compilation.
     * </summary> */
    public class Cl : BaseAction, IBuildActionProvider, IBuildAction
    {
        #region State of build action
        ContentFile _target = null;
        ContentFile _source = null;
        ContentFiles _includeFiles = new ContentFiles(ContentType.CCPlusPlusInclude);
        #endregion

        #region CTor
        /** <summary> Use the CTor to create an instance that serves as an implementation of IBuildActionClass. </summary> */
        public Cl()
        {
        }
        #endregion

        #region IBuildActionProvider Member

        public ICollection<OperatingSystem> ApplicableOSs
        {
            get { return new OperatingSystem[] { OperatingSystem.WinXP }; }
        }

        public override IDictionary<string, EnvironmentVarInfo> UsedVars
        {
            get
            {
                Dictionary<string, EnvironmentVarInfo> result = new Dictionary<string, EnvironmentVarInfo>();
                result.Add("PATH", new EnvironmentVarInfo("PATH", "Semicolon separated list of directories where CMD looks for executable programs.", typeof(DirectoryName)));
                result.Add("INCLUDE", new EnvironmentVarInfo("INCLUDE", "Semicolon separated list of directories where CL.EXE looks for include files.", typeof(DirectoryList)));
                result.Add("CL", new EnvironmentVarInfo("CL", "Additional options for the CL.EXE compiler.", typeof(string)));
                return result;
            }
        }

        /** <summary> cl.exe</summary>
         */
        public string Name
        {
            get { return "cl.exe"; }
        }

        /** <summary>"MS VC"</summary>
         */
        public string ToolFamily
        {
            get { return "MS VC"; }
        }

        public string Description
        {
            get { return "The MS C/C++ compiler."; }
        }

        /** <summary> The filename of the compiler. </summary> */
        public string FileName
        {
            get
            {
                string vcPath = ToolProperties.GetVCBinPath();
                string clFile = Path.Combine(vcPath, this.Name);
                return clFile;
            }
        }

        public bool IsAvailable
        {
            get
            {
              try {
                string vcPath = ToolProperties.GetVCBinPath();
                string vcvarsFile = Path.Combine(vcPath, "vcvars32.bat");
                return File.Exists(vcvarsFile) && File.Exists(this.FileName);
              } catch {
                return false;
              }
            }
        }

        public bool MayContentFilePrerequisitesSuffice(ContentType target, ICollection<ContentType> prerequisites)
        {
            if (target.Implies(ContentType.VCCoffObj))
            {
                foreach (ContentType t in prerequisites)
                    if (t.Contains(ContentType.CCode) || t.Contains(ContentType.CPlusPlusCode))
                        return true;
            }
            return false;
        }

        /// <summary>
        /// This produces file of type ContentType.VCCoffObj.
        /// </summary>
        public ICollection<ContentType> ContentFileTargets
        {
            get
            {
                return new ContentType[] { ContentType.VCCoffObj };
            }
        }

        public IBuildAction Create(BuildToolFamilyEnv env, IBuildProduct target, ICollection<IBuildProduct> prerequisites)
        {
            ContentFile targetFile = target as ContentFile;
            if (targetFile != null && targetFile.Type.Implies(ContentType.VCCoffObj))
            {
                Cl result = new Cl();
                result._target = targetFile;
                CollectionOfIncludePaths includePaths = this.GetIncludePaths(env, null);
                foreach (IBuildProduct prereq in prerequisites)
                {
                    if (prereq is ContentFile)
                    {
                        ContentFile prereqFile = (ContentFile)prereq;
                        if (Path.GetFileNameWithoutExtension(prereqFile.FileName) == Path.GetFileNameWithoutExtension(targetFile.FileName)
                            && (prereqFile.Type.Implies(ContentType.CCode)
                                || prereqFile.Type.Implies(ContentType.CPlusPlusCode)))
                        {
                            result._source = prereqFile;
                            ContentFiles newIncludeFiles = includePaths.GetPathToIncludes(prereqFile.FileName);
                            if (result._includeFiles == null)
                                result._includeFiles = newIncludeFiles;
                            else
                                result._includeFiles.AddRange(newIncludeFiles);
                        }
                    }
                }
                return result;
            }
            return null;
        }

        #endregion

        #region IBuildAction Member

        /** <summary> This is its own action provider. </summary> */
        public IBuildActionProvider ActionProvider
        {
            get { return this; }
        }

        public override ICollection<Type> ParameterTypes
        {
            get
            {
                return new Type[] { typeof(CxxParameters) };
            }
        }

        public ActionPriority Priority
        {
            get { return ActionPriority.Preferred; }
        }

        /// <summary>
        /// This will be called for any action provider before IBuildAction.AppendBooCode() is called.
        /// This provides action providers with the opportunity to import modules and create variables
        /// for global options.
        /// </summary>
        /// <param name="env">Environment containing status that can be shared among tools of the same family.</param>
        /// <param name="importModules">List of modules that shall be imported. Add required modules here. Each module
        /// will be imported exactly once (even if it occurs more than once in the list).</param>
        /// <param name="booDeclarations">Lines of code that will be added to the preamble of the BOO code.
        /// Please note, that each line may only appear once. All subsequent additions of this line of
        /// code will be ignored. These lines shall contain declarations of variables etc.</param>
        /// <param name="booDefinitions">Lines of code that that will be added before the code provided by
        /// the actions to build the system. Typically, this will contain the definition of functions
        /// that are used on building. Lines starting with "import" will only be added once to the final code. </param>
        /// <remarks>This will define a function <c>RunMsLink</c> receiving all objects that shall be linked.
        /// </remarks>
        public override void AppendToBooPreamble(BuildToolFamilyEnv env, List<string> importModules, List<string> booDeclarations, List<string> booDefinitions)
        {
            #region Declarations
            CxxParameters parameters = (CxxParameters)BuildConfig.GetDefaultParameterOfType(typeof(CxxParameters));
            #region Code Generation
            booDeclarations.Add("#");
            booDeclarations.Add("# Path to the Visual C/C++ Development Environment (Express of commercial edition)");
            booDeclarations.Add(string.Format("VisualCPath=\"{0}\"", ContentFile.ConvertFilenameToBooString(ToolProperties.GetVCPath())));
            booDeclarations.Add("#");
            booDeclarations.Add("# Path to the Visual C/C++ Development tools (Express of commercial edition)");
            booDeclarations.Add(string.Format("VisualCEnvPath=\"{0}\"", ContentFile.ConvertFilenameToBooString(ToolProperties.GetEnvDir())));
            booDeclarations.Add("#");
            booDeclarations.Add("# Path to Microsoft's Platform Development Kit");
            booDeclarations.Add(string.Format("PlatformSDKPath=\"{0}\"", ContentFile.ConvertFilenameToBooString(ToolProperties.GetPlatformSDK())));
            booDeclarations.Add("#");
            booDeclarations.Add("# These are the flags that will be passed to CL.EXE controlling");
            booDeclarations.Add("# code generation. These flags are different when including debug");
            booDeclarations.Add("# information into the code.");
            if (parameters.DebugInfo)
            {
                booDeclarations.Add("CL_CodeGeneration=\"/MDd /ZI /D _MT /D _DLL /D _DEBUG /D _CRTDBG_MAP_ALLOC\" # DEBUG MODE");
                booDeclarations.Add("#CL_CodeGeneration=\"/MD /D _MT /D _DLL /D NDEBUG\" # RELEASE MODE");
            }
            else
            {
                booDeclarations.Add("#CL_CodeGeneration=\"/MDd /ZI /D _MT /D _DLL /D _DEBUG /D _CRTDBG_MAP_ALLOC\" # DEBUG MODE");
                booDeclarations.Add("CL_CodeGeneration=\"/MD /D _MT /D _DLL /D NDEBUG\" # RELEASE MODE");
            }
            #endregion
            #region Code Generation C/C++, Optimization
            if (parameters.CompileAsCxx)
            {
                booDeclarations.Add("CL_Language=\"/TP\" # Compile as C++");
                booDeclarations.Add("#CL_Language=\"/TC\" # Compile as C");
            }
            else
            {
                booDeclarations.Add("CL_Language=\"/TC\" # Compile as C");
                booDeclarations.Add("#CL_Language=\"/TP\" # Compile as C++");
            }
            if (parameters.EnableExceptions)
                booDeclarations.Add("CL_Exceptions=\"/EHsc\" # Enable exceptions");
            else
                booDeclarations.Add("CL_Exceptions=\"\" # /EHsc to enable exceptions");
            booDeclarations.Add("# Options to configure code optimization: /O1 (compact) or /O2 (fast) or /Ox (unspecific opt.) or /Od (no optimization)");
            switch (parameters.Optimization)
            {
                case CxxOptimization.CompactCode: booDeclarations.Add("CL_Optimization=\"/O1\""); break;
                case CxxOptimization.FastCode: booDeclarations.Add("CL_Optimization=\"/O2\""); break;
                case CxxOptimization.OverallOptimization: booDeclarations.Add("CL_Optimization=\"/Ox\""); break;
                case CxxOptimization.No: booDeclarations.Add("CL_Optimization=\"/Od\""); break;
            }

            #endregion
            #region Warnings, Errors
            System.Text.StringBuilder warningsErrors = new System.Text.StringBuilder();
            switch (parameters.WarningLevel)
            {
                case CxxWarningLevel.BasicWarnings: warningsErrors.Append("/W1"); break;
                case CxxWarningLevel.ImportantWarnings: warningsErrors.Append(" /W2"); break;
                case CxxWarningLevel.QualityWarnings: warningsErrors.Append(" /W3"); break;
                case CxxWarningLevel.NoWarnings: warningsErrors.Append(" /w"); break;
            }
            if (BuildConfig.GetConfig().AbortOptions == AbortOptions.TreatWarningsAsErrors)
                warningsErrors.Append(" /WX");
            booDeclarations.Add("#");
            booDeclarations.Add("# Warning levels: /W1, /W2, /W3 or /w to turn off warnings");
            booDeclarations.Add("# /WX will tell the compiler to treat warnings as errors");
            booDeclarations.Add(string.Format("CL_Warnings=\"{0}\"", warningsErrors.ToString()));
            #endregion
            #region Special Parameters
            string specialParameters = parameters.GetOptions(this.Name);
            booDeclarations.Add("#");
            booDeclarations.Add("# These are options that have been added to the parameter set especially for");
            booDeclarations.Add("# this compiler. I do not know why. You have to assess this yourself.");
            if (specialParameters == null)
            {
                booDeclarations.Add("CL_SpecialParameters=\"\" # no special parameters declared");
            }
            else
            {
                booDeclarations.Add(string.Format("CL_SpecialParameters=\"{0}\"", ContentFile.ConvertFilenameToBooString(specialParameters)));
            }
            #endregion
            #region Features
            booDeclarations.Add("#");
            booDeclarations.Add("# The following variable activates features of the implementation.");
            booDeclarations.Add("# Activate or deactivate features depending on your needs and whether");
            booDeclarations.Add("# your system meets the requirements or not.");
            if (parameters.Features == null)
                booDeclarations.Add(string.Format("CL_Features=\"\""));
            else
            {
                System.Text.StringBuilder featureBuilder=new System.Text.StringBuilder();
                featureBuilder.Append("CL_Features=\"");
                foreach (string symbol in parameters.Features.EnabledSymbols)
                    featureBuilder.AppendFormat(" /D {0}", symbol);
                featureBuilder.Append("\"");
                booDeclarations.Add(featureBuilder.ToString());
                foreach(FeatureEntry feature in parameters.Features.Keys)
                {
                    booDeclarations.Add(string.Format("# /D {0}: {1}:{2}", feature.Symbol, feature.Displayname, feature.Description));
                }
            }
            #endregion
            #region StdLibs
            booDeclarations.Add("#");
            booDeclarations.Add("# Include paths referring to standard libraries.");
            if (parameters.Libraries == CxxLibraries.NoStdLibraries)
                booDeclarations.Add(string.Format("CL_StdInclude=\"\""));
            else
                booDeclarations.Add(string.Format("CL_StdInclude=string.Format(\"/I \\\"{{0}}\\\" /I \\\"{{1}}\\\"\", System.IO.Path.Combine(VisualCPath, \"include\"), System.IO.Path.Combine(PlatformSDKPath, \"include\"))"));
            #endregion
            #region Include Directories
            System.Text.StringBuilder includePaths=new System.Text.StringBuilder();
            foreach (string includePath in GetIncludePaths(env, parameters))
            {
                includePaths.Append(" /I ");
                includePaths.Append("\\\"");
                includePaths.Append( ContentFile.ConvertFilenameToBooString(TempFilesParameters.MakePathRelative(includePath, BuildConfig.PathRoot)) );
                includePaths.Append("\\\"");
            }
            booDeclarations.Add(string.Format("CL_Include=\"{0}\"", includePaths));
            #endregion
            #endregion
            #region Definitions
            importModules.Add("System.Text");
            booDefinitions.Add("def RunMsCl(target as string, source as string):");
            booDefinitions.Add(string.Format("\tif not TestForRebuild(target, source):"));
            booDefinitions.Add(string.Format("\t\tprint target,\"is up to date\""));
            booDefinitions.Add(string.Format("\t\treturn"));
            booDefinitions.Add(string.Format("\tprint \"Running CL.EXE\",target,source"));
            booDefinitions.Add(string.Format("\targs=System.Text.StringBuilder()"));
            booDefinitions.Add(string.Format("\targs.Append(\" /nologo /c \\\"\")"));
            booDefinitions.Add(string.Format("\targs.Append(source)"));
            booDefinitions.Add(string.Format("\targs.Append(\"\\\" /Fo\\\"\")"));
            booDefinitions.Add(string.Format("\targs.Append(target)"));
            booDefinitions.Add(string.Format("\targs.Append(\"\\\" \")"));
            booDefinitions.Add(string.Format("\targs.Append(CL_CodeGeneration)"));
            booDefinitions.Add(string.Format("\targs.Append(\" \")"));
            booDefinitions.Add(string.Format("\targs.Append(CL_SpecialParameters)"));
            booDefinitions.Add(string.Format("\targs.Append(\" \")"));
            booDefinitions.Add(string.Format("\targs.Append(CL_SpecialParameters)"));
            booDefinitions.Add(string.Format("\targs.Append(\" \")"));
            booDefinitions.Add(string.Format("\targs.Append(CL_Features)"));
            booDefinitions.Add(string.Format("\targs.Append(\" \")"));
            booDefinitions.Add(string.Format("\targs.Append(CL_StdInclude)"));
            booDefinitions.Add(string.Format("\targs.Append(\" \")"));
            booDefinitions.Add(string.Format("\targs.Append(CL_Include)"));
            booDefinitions.Add(string.Format("\targs.Append(\" \")"));
            booDefinitions.Add(string.Format("\targs.Append(CL_Language)"));
            booDefinitions.Add(string.Format("\targs.Append(\" \")"));
            booDefinitions.Add(string.Format("\targs.Append(CL_Exceptions)"));
            booDefinitions.Add(string.Format("\targs.Append(\" \")"));
            booDefinitions.Add(string.Format("\targs.Append(CL_Optimization)"));
            booDefinitions.Add(string.Format("\targs.Append(\" \")"));
            booDefinitions.Add(string.Format("\targs.Append(CL_Warnings)"));
            booDefinitions.Add(string.Format("\tstartinfo=System.Diagnostics.ProcessStartInfo()"));
            booDefinitions.Add(string.Format("\tstartinfo.FileName=\"{0}\"", ContentFile.ConvertFilenameToBooString(this.FileName)));
            booDefinitions.Add(string.Format("\tstartinfo.Arguments=args.ToString()"));
            booDefinitions.Add(string.Format("\tstartinfo.UseShellExecute=false"));
            booDefinitions.Add(string.Format("\tif VisualCEnvPath.Length > 0:"));
            booDefinitions.Add(string.Format("\t\tstartinfo.EnvironmentVariables[\"PATH\"] = VisualCEnvPath + \";\" + startinfo.EnvironmentVariables[\"PATH\"]"));
            booDefinitions.Add(string.Format("\tp=System.Diagnostics.Process.Start(startinfo)"));
            booDefinitions.Add(string.Format("\tp.WaitForExit()"));
            booDefinitions.Add(string.Format("\tif p.ExitCode!=0:"));
            booDefinitions.Add(string.Format("\t\traise System.Exception(\"Build action failed.\")"));
            #endregion
        }

        /// <summary>
        /// This method will create BOO source code and append this code to the provided text writer.
        /// </summary>
        /// <param name="env">This is an environment that different tools of the same family may use to exchange information.
        /// This store is typically used to save information on configuration files or thinsgs of that kind that will be
        /// shared among all tools of the same family.</param>
        /// <param name="booCode">The code that will actually build something. Each list entry will be a line of code in the resulting
        /// BOO program.</param>
        /// <param name="indention">A string that shall preceed all created lines. </param>
        /// <remarks>Refer to IBuildActionProvider.AppendToBooPreamble() for an example.</remarks>
        /// <exception cref="NotSupportedException">Will be thrown if this feature is not supported.</exception>
        public override void AppendBooCode(List<string> booCodeLines, string indention, BuildToolFamilyEnv env)
        {
            booCodeLines.Add(string.Format("{2}RunMsCl(\"{0}\", \"{1}\")", this.Target.FileNameAsBooString, this.Source.FileNameAsBooString, indention));
        }
        #endregion

        /// <summary>
        /// The target (object file) that shall be produced.
        /// </summary>
        public ContentFile Target { get { return this._target; } }

        /// <summary>
        /// The source file defining the code segment (either C or C++ file).
        /// </summary>
        public ContentFile Source { get { return this._source; } }

        /** <summary>Creates a collection of include paths from the provided parameters and environment.</summary>
         * <param name="env">The result will be read from key "INCLUDE" or, if not present, the result will be stored there.</param>
         * <param name="parameters">Include paths will be read from this argument (and the corresponding options) if not already stores.</param>
         * \c parameters may be \c null. In that case, this will consider the current standard parameter.
         */
        public CollectionOfIncludePaths GetIncludePaths(BuildToolFamilyEnv env, CxxParameters parameters)
        {
            if (parameters == null)
                parameters = (CxxParameters)BuildConfig.GetDefaultParameterOfType(typeof(CxxParameters));
            CollectionOfIncludePaths result=new CollectionOfIncludePaths();
            result.AddRange(parameters.IncludePaths);

            System.Collections.Specialized.StringDictionary familyEnv = (System.Collections.Specialized.StringDictionary)env[this];
            if (familyEnv == null)
            {
                // create a new store.
                familyEnv = new System.Collections.Specialized.StringDictionary();
                env[this] = familyEnv;
            }
            string includePaths = null;
            if (familyEnv.ContainsKey("INCLUDE"))
                includePaths = Environment.ExpandEnvironmentVariables(familyEnv["INCLUDE"]);
            else
                includePaths = Environment.GetEnvironmentVariable("INCLUDE");
            if (includePaths != null && includePaths.Length > 0)
            {
                foreach (string includePath in includePaths.Split(';'))
                {
                    if (includePath.Length > 0)
                    {
                        result.Add(includePath);
                    }
                }
            }
            return result;
        }

        #region IBuildProduct Member
        public override System.Diagnostics.ProcessStartInfo GetProgramStartInfo(BuildToolFamilyEnv env)
        {
            System.Diagnostics.ProcessStartInfo result = new System.Diagnostics.ProcessStartInfo();
            result.FileName = this.FileName;
            System.Text.StringBuilder cmdArgs = new System.Text.StringBuilder();
            cmdArgs.Append(" /nologo /c");
            cmdArgs.Append(" \"");
            cmdArgs.Append(this._source.FileName);
            cmdArgs.Append("\" /Fo\"");
            cmdArgs.Append(this._target.FileName);
            cmdArgs.Append("\"");

            CxxParameters parameters = (CxxParameters)BuildConfig.GetDefaultParameterOfType(typeof(CxxParameters));
            if (parameters.DebugInfo)
            {
                cmdArgs.Append(" /MDd /ZI /D _MT /D _DLL /D _DEBUG /D _CRTDBG_MAP_ALLOC");
            }
            else
            {
                cmdArgs.Append(" /MD /D _MT /D _DLL /D NDEBUG");
            }

            string specialParameters = parameters.GetOptions(this.Name);
            if (specialParameters != null)
            {
                cmdArgs.Append(" ");
                cmdArgs.Append(specialParameters);
            }
            if (parameters.Features != null)
            {
                foreach (string symbol in parameters.Features.EnabledSymbols)
                {
                    cmdArgs.AppendFormat(" /D {0}", symbol);
                }
            }
            if (parameters.Libraries != CxxLibraries.NoStdLibraries)
            {
                cmdArgs.Append(" /I \"");
                cmdArgs.Append(System.IO.Path.Combine(ToolProperties.GetVCPath(), "include"));
                cmdArgs.Append("\"");

                cmdArgs.Append(" /I \"");
                cmdArgs.Append(System.IO.Path.Combine(ToolProperties.GetPlatformSDK(), "include"));
                cmdArgs.Append("\"");
            }
            foreach (string includePath in GetIncludePaths(env, parameters))
            {
                cmdArgs.Append(" /I ");
                cmdArgs.Append("\"");
                cmdArgs.Append(includePath);
                cmdArgs.Append("\"");
            }
            if (parameters.CompileAsCxx)
                cmdArgs.Append(" /TP");
            else
                cmdArgs.Append(" /TC");
            switch (parameters.Optimization)
            {
                case CxxOptimization.CompactCode: cmdArgs.Append(" /O1"); break;
                case CxxOptimization.FastCode: cmdArgs.Append(" /O2"); break;
                case CxxOptimization.OverallOptimization: cmdArgs.Append(" /Ox"); break;
                case CxxOptimization.No: cmdArgs.Append(" /Od"); break;
            }
            if (parameters.EnableExceptions)
                cmdArgs.Append(" /EHsc");
            switch (parameters.WarningLevel)
            {
                case CxxWarningLevel.BasicWarnings: cmdArgs.Append(" /W1"); break;
                case CxxWarningLevel.ImportantWarnings: cmdArgs.Append(" /W2"); break;
                case CxxWarningLevel.QualityWarnings: cmdArgs.Append(" /W3"); break;
                case CxxWarningLevel.NoWarnings: cmdArgs.Append(" /w"); break;
            }
            if (BuildConfig.GetConfig().AbortOptions == AbortOptions.TreatWarningsAsErrors)
                cmdArgs.Append(" /WX");
            if (this._source.Type == ContentType.CCode)
                cmdArgs.Append(" /TC");
            else if (this._source.Type == ContentType.CPlusPlusCode)
                cmdArgs.Append(" /TP");

            result.Arguments = cmdArgs.ToString();
            string vsEnvDir = ToolProperties.GetEnvDir();
            if (vsEnvDir.Length > 0)
                result.EnvironmentVariables["PATH"] = vsEnvDir + ";" + result.EnvironmentVariables["PATH"];
            return result;
        }

        //@SET VSINSTALLDIR=C:\Programme\Microsoft Visual Studio 9.0
        //@SET VCINSTALLDIR=C:\Programme\Microsoft Visual Studio 9.0\VC
        //@set DevEnvDir=%VSINSTALLDIR%\Common7\IDE
        //@set PATH=%DevEnvDir%;%VCINSTALLDIR%\BIN;%VSINSTALLDIR%\Common7\Tools;%VSINSTALLDIR%\Common7\Tools\bin;%FrameworkDir%\%Framework35Version%;%FrameworkDir%\%Framework35Version%\Microsoft .NET Framework 3.5 (Pre-Release Version);%FrameworkDir%\%FrameworkVersion%;%VCINSTALLDIR%\VCPackages;%PATH%

        /// <summary>
        /// Executes <c>FileName</c> using the start info as produced by GetProgramStartInfo().
        /// </summary>
        /// <param name="env">Some data that tools of the same family may share.</param>
        /// <param name="validityOfBuildSystem">The validity stating when the build system (definition of the projects) have been changed.</param>
        /// <returns>True on successful build.</returns>
        public bool Execute(BuildToolFamilyEnv env, DateTime validityOfBuildSystem)
        {
            ErrorDataReceiver receiver = new ErrorDataReceiver(this);
            receiver.WarningClassifier = new System.Text.RegularExpressions.Regex(@"\swarning\s",
                System.Text.RegularExpressions.RegexOptions.Compiled
                | System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            receiver.ErrorClassifier = new System.Text.RegularExpressions.Regex(@"\serror\s",
                System.Text.RegularExpressions.RegexOptions.Compiled
                | System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            receiver.FilePosPattern = new System.Text.RegularExpressions.Regex(
                @"^(?<file>[^\(]+)\((?<line>\d+),(?<column>\d+)\)");
            wx.ProcessUtils.ProcessStarter starter = new wx.ProcessUtils.ProcessStarter(this.GetProgramStartInfo(env),
                new wx.ProcessUtils.MsgEventHandler(receiver.OnReceiveMsgEvent));
            System.Diagnostics.Process process = starter.Start();
            return process.ExitCode == 0;
        }

        public override ICollection<IBuildProduct> GetPrerequisites()
        {
            List<IBuildProduct> result = new List<IBuildProduct>();
            if (this._includeFiles != null && this._includeFiles.Count > 0)
                result.Add(this._includeFiles);
            if (this._source.Count > 0)
                result.Add(this._source);
            return result;
        }

        public override bool ContainsPrerequisite(IBuildProduct prereq)
        {
            if (this._source.Equals(prereq))
                return true;

            foreach (IBuildProduct includeFile in this._includeFiles)
            {
                if (includeFile.Equals(this._includeFiles))
                    return true;
            }
            return false;
        }

        public override ICollection<IBuildProduct> GetTargets()
        {
            List<IBuildProduct> target = new List<IBuildProduct>();
            target.Add(this._target);
            return target;
        }
        #endregion
    }

    /** <summary> Toolwrapper of the MS C/C++ linker as shipped with Visual Studio (Express Edition). </summary> */
    public class Link : BaseAction, IBuildActionProvider, IBuildAction
    {
        #region State
        ContentFiles _objects=null;
        ContentFiles _resources = null;
        ContentFiles _libs = null;
        ContentFile _output = null;
        #endregion

        #region CTor
        /** <summary> This creates an instance that serves as a build action provider. </summary> */
        public Link()
        {
        }
        #endregion

        #region BaseAction
        public override ICollection<IBuildProduct> GetPrerequisites()
        {
            ICollection<IBuildProduct> result = new List<IBuildProduct>();
            if (this._objects.Count > 0)
                result.Add(this._objects);
            if (this._resources.Count>0)
                result.Add(this._resources);
            if (this._libs.Count > 0)
                result.Add(this._libs);
            return result;
        }

        public override bool ContainsPrerequisite(IBuildProduct prereq)
        {
            foreach (ContentFile file in this._objects)
            {
                if (file.Equals(prereq))
                    return true;
            }
            foreach (ContentFile file in this._resources)
            {
                if (file.Equals(prereq))
                    return true;
            }
            foreach (ContentFile file in this._libs)
            {
                if (file.Equals(prereq))
                    return true;
            }
            return false;
        }

        public override ICollection<IBuildProduct> GetTargets()
        {
            ICollection<IBuildProduct> result = new List<IBuildProduct>();
            result.Add(this._output);
            return result;
        }
        #endregion

        #region IBuildActionProvider Member

        public ICollection<OperatingSystem> ApplicableOSs
        {
            get
            {
                List<OperatingSystem> os = new List<OperatingSystem>();
                os.Add(OperatingSystem.WinXP);
                return os;
            }
        }

        public override IDictionary<string, EnvironmentVarInfo> UsedVars
        {
            get
            {
                Dictionary<string, EnvironmentVarInfo> result = new Dictionary<string, EnvironmentVarInfo>();
                result.Add("PATH", new EnvironmentVarInfo("PATH", "Semicolon separated list of directories where CMD looks for executable programs.", typeof(DirectoryList)));
                result.Add("LIB", new EnvironmentVarInfo("LIB", "Semicolon separated list of directories where LINK.EXE looks for static libraries files.", typeof(DirectoryList)));
                result.Add("LINK", new EnvironmentVarInfo("LINK", "Additional options for the LINK.EXE compiler.", typeof(string)));
                result.Add("TMP", new EnvironmentVarInfo("TMP", "This directory will be used when linking of OMF- or RES-files.", typeof(DirectoryName)));
                return result;
            }
        }

        /** <summary> <c>link </c> .exe </summary> */
        public string Name
        {
            get { return "link.exe"; }
        }

        /** <summary> \c "MS VC" </summary> */
        public string ToolFamily
        {
            get { return "MS VC"; }
        }

        public string Description
        {
            get { return "The MS C/C++ linker."; }
        }

        /** <summary> The filename of the compiler. </summary> */
        public string FileName
        {
            get
            {
                string vcPath = ToolProperties.GetVCBinPath();
                string clFile = Path.Combine(vcPath, this.Name);
                return clFile;
            }
        }

        public bool IsAvailable
        {
            get
            {
               try {
                string vcPath = ToolProperties.GetVCBinPath();
                string vcvarsFile = Path.Combine(vcPath, "vcvars32.bat");
                return File.Exists(vcvarsFile) && File.Exists(this.FileName);
               } catch {
                 return false;
               }
            }
        }

        public bool MayContentFilePrerequisitesSuffice(ContentType target, ICollection<ContentType> prerequisites)
        {
            if (target.Implies(ContentType.WindowsDll))
            {
                // at least one prerequisite should be an object file
                // This is required because exported functions are defined in object files.
                foreach (ContentType prereqType in prerequisites)
                    if (prereqType.Implies(ContentType.VCCoffObj))
                        return true;
            }
            // the build system does currently not consider native executables.
            return false;
        }

        /** <summary> This currently supports only Windows DLLs. </summary> */
        public ICollection<ContentType> ContentFileTargets
        {
            get
            {
                List<ContentType> result = new List<ContentType>();
                result.Add(ContentType.WindowsDll);
                result.Add(ContentType.WindowsGuiDll);
                return result;
            }
        }

        public IBuildAction Create(BuildToolFamilyEnv env, IBuildProduct target, ICollection<IBuildProduct> prerequisites)
        {
            Link result = new Link();
            ContentFile fileTarget = (ContentFile)target;
            if (fileTarget.Type.Implies(ContentType.WindowsDll))
                result._output = fileTarget;
            else
                throw new Exception("Tool link.exe only produces Windows native DLLs.");
            result._objects = new ContentFiles(ContentType.VCCoffObj);
            result._resources = new ContentFiles(ContentType.ResFile);
            result._libs = new ContentFiles(ContentType.VCCoffLib);
            foreach (IBuildProduct prereq in prerequisites)
            {
                ContentFile prereqFile = prereq as ContentFile;
                if (prereqFile != null)
                {
                    if (prereqFile.Type.Implies(result._objects.Type))
                        result._objects.Add(prereqFile);
                    else if (prereqFile.Type.Implies(result._resources.Type))
                        result._resources.Add(prereqFile);
                    else if (prereqFile.Type.Implies(result._libs.Type))
                        result._libs.Add(prereqFile);
                }
            }

            return result;
        }
        #endregion

        #region IBuildAction Member

        /** <summary> This is its own action provider. </summary> */
        public IBuildActionProvider ActionProvider
        {
            get { return this; }
        }

        public ActionPriority Priority
        {
            get { return ActionPriority.Preferred; }
        }
        #endregion

        #region BOO export

        /// <summary>
        /// This will be called for any action provider before IBuildAction.AppendBooCode() is called.
        /// This provides action providers with the opportunity to import modules and create variables
        /// for global options.
        /// </summary>
        /// <param name="env">Environment containing status that can be shared among tools of the same family.</param>
        /// <param name="importModules">List of modules that shall be imported. Add required modules here. Each module
        /// will be imported exactly once (even if it occurs more than once in the list).</param>
        /// <param name="booDeclarations">Lines of code that will be added to the preamble of the BOO code.
        /// Please note, that each line may only appear once. All subsequent additions of this line of
        /// code will be ignored. These lines shall contain declarations of variables etc.</param>
        /// <param name="booDefinitions">Lines of code that that will be added before the code provided by
        /// the actions to build the system. Typically, this will contain the definition of functions
        /// that are used on building. Lines starting with "import" will only be added once to the final code. </param>
        /// <remarks>This will define a function <c>RunMsLink</c> receiving all objects that shall be linked.
        /// </remarks>
        public override void AppendToBooPreamble(BuildToolFamilyEnv env, List<string> importModules, List<string> booDeclarations, List<string> booDefinitions)
        {
            importModules.Add("System.Text");
            importModules.Add("System.IO");

            CxxParameters parameters = (CxxParameters)BuildConfig.GetDefaultParameterOfType(typeof(CxxParameters));
            booDeclarations.Add("# This variable defines those options of the MS link.exe that include debug information");
            booDeclarations.Add("# into the resulting code. Options of this category also toggle optimization.");
            if (parameters.DebugInfo)
                booDeclarations.Add("CL_LINK_DEBUG='/DEBUG' # '/OPT:REF'");
            else
            {
                if (parameters.Optimization != CxxOptimization.No)
                    booDeclarations.Add("CL_LINK_DEBUG='/OPT:REF' # '/DEBUG'");
                else
                    booDeclarations.Add("CL_LINK_DEBUG='' # '/OPT:REF /DEBUG'");
            }
            if (BuildConfig.GetConfig().AbortOptions == AbortOptions.TreatWarningsAsErrors)
                booDeclarations.Add("CL_LINK_ERRORS_WARNINGS='/WX' # Treat warnings as errors");
            else
                booDeclarations.Add("CL_LINK_ERRORS_WARNINGS='' # '/WX'");

            booDefinitions.Add(string.Format("def RunMsLink(targetFile as string, *objOrLibOrResFiles as (string)):"));
            booDefinitions.Add(string.Format("\tif not TestForRebuild(targetFile, *objOrLibOrResFiles):"));
            booDefinitions.Add(string.Format("\t\tprint \"${{targetFile}} is up to date.\""));
            booDefinitions.Add(string.Format("\t\treturn"));
            booDefinitions.Add(string.Format("\tprint \"MS link.exe creates\", targetFile"));
            booDefinitions.Add(string.Format("\tfilename=Path.Combine(VisualCPath, 'bin')"));
            booDefinitions.Add(string.Format("\tfilename=Path.Combine(filename, \"{0}\")", this.Name));
            TempFilesParameters tempPars=(TempFilesParameters)BuildConfig.GetDefaultParameterOfType(typeof(TempFilesParameters));
            string linkerOptionsFilename = tempPars.CreatePathFor("link.options", ContentType.TXT).FileNameAsBooString;
            booDefinitions.Add(string.Format("\targs=StreamWriter(\"{0}\")", linkerOptionsFilename));
            booDefinitions.Add(string.Format("\targs.Write(\"/DLL /VERBOSE:LIB /SUBSYSTEM:WINDOWS /MANIFEST /NOLOGO /OUT:\\\"${{targetFile}}\\\" /NODEFAULTLIB:LIBCMT.LIB\")"));
            booDefinitions.Add(string.Format("\targs.Write(\" /MANIFESTFILE:\\\"${{targetFile}}.manifest\\\"\")"));
            string specialParameters = parameters.GetOptions(this.Name);
            if (specialParameters != null)
                booDefinitions.Add(string.Format("\targs.Write(\" {0}\")", specialParameters.Replace("\\", "\\\\").Replace("\"", "\\\"")));
            booDefinitions.Add(string.Format("\tfor objOrLibOrResFile in objOrLibOrResFiles:"));
            booDefinitions.Add("\t\targs.Write(\" \\\"${objOrLibOrResFile}\\\"\")");
            if (parameters.Libraries == CxxLibraries.NoStdLibraries)
                booDefinitions.Add(string.Format("\targs.Write(' /NODEFAULTLIB')"));
            else
            {
                booDefinitions.Add(string.Format("\tVCLibPath=Path.Combine(VisualCPath, \"lib\")"));
                booDefinitions.Add(string.Format("\tPSDKLibPath=Path.Combine(PlatformSDKPath, \"lib\")"));
                booDefinitions.Add(string.Format("\targs.Write(\" /Libpath:\\\"${{VCLibPath}}\\\" /Libpath:\\\"${{PSDKLibPath}}\\\"\")"));
                if ((parameters.Libraries & CxxLibraries.GeneralOSLibraries) == CxxLibraries.GeneralOSLibraries)
                    booDefinitions.Add("\targs.Write(' kernel32.lib user32.lib shell32.lib advapi32.lib ole32.lib oleaut32.lib')");
                if ((parameters.Libraries & CxxLibraries.GDILibraries) == CxxLibraries.GDILibraries)
                    booDefinitions.Add("\targs.Write(' gdi32.lib gdiplus.lib comdlg32.lib comctl32.lib')");
                if ((parameters.Libraries & CxxLibraries.TcpAndRpcLibraries) == CxxLibraries.TcpAndRpcLibraries)
                    booDefinitions.Add("\targs.Write(' rpcrt4.lib wsock32.lib')");
            }
            booDefinitions.Add("\targs.Write(' ')");
            booDefinitions.Add("\targs.Write(CL_LINK_DEBUG)");
            booDefinitions.Add("\targs.Close()");

            booDefinitions.Add(string.Format("\tstartinfo=System.Diagnostics.ProcessStartInfo()"));
            booDefinitions.Add(string.Format("\tstartinfo.FileName=filename"));
            booDefinitions.Add(string.Format("\tstartinfo.Arguments=\"@{0}\"", linkerOptionsFilename));
            booDefinitions.Add(string.Format("\tstartinfo.UseShellExecute=false"));
            booDefinitions.Add(string.Format("\tif VisualCEnvPath.Length > 0:"));
            booDefinitions.Add(string.Format("\t\tstartinfo.EnvironmentVariables[\"PATH\"] = VisualCEnvPath + \";\" + startinfo.EnvironmentVariables[\"PATH\"]"));
            booDefinitions.Add(string.Format("\tp=System.Diagnostics.Process.Start(startinfo)"));
            booDefinitions.Add(string.Format("\tp.WaitForExit()"));
            booDefinitions.Add(string.Format("\tif p.ExitCode == 0:"));
            booDefinitions.Add(string.Format("\t\tfilename=Path.Combine(PlatformSDKPath, 'bin')"));
            booDefinitions.Add(string.Format("\t\tfilename=Path.Combine(filename, \"mt.exe\")"));
            booDefinitions.Add(string.Format("\t\tstartinfo.FileName=filename"));
            booDefinitions.Add(string.Format("\t\tstartinfo.Arguments=\"-manifest \\\"${{targetFile}}.manifest\\\" -outputresource:\\\"${{targetFile}}\\\";2\""));
            booDefinitions.Add(string.Format("\t\tp=System.Diagnostics.Process.Start(startinfo)"));
            booDefinitions.Add(string.Format("\t\tp.WaitForExit()"));
            booDefinitions.Add(string.Format("\tif p.ExitCode!=0:"));
            booDefinitions.Add(string.Format("\t\traise System.Exception(\"Build action failed.\")"));
        }

        /// <summary>
        /// This method will create BOO source code and append this code to the provided text writer.
        /// </summary>
        /// <param name="env">This is an environment that different tools of the same family may use to exchange information.
        /// This store is typically used to save information on configuration files or thinsgs of that kind that will be
        /// shared among all tools of the same family.</param>
        /// <param name="booCode">The code that will actually build something. Each list entry will be a line of code in the resulting
        /// BOO program.</param>
        /// <param name="indention">A string that shall preceed all created lines. </param>
        /// <remarks>Refer to IBuildActionProvider.AppendToBooPreamble() for an example.</remarks>
        /// <exception cref="NotSupportedException">Will be thrown if this feature is not supported.</exception>
        public override void AppendBooCode(List<string> booCodeLines, string indention, BuildToolFamilyEnv env)
        {
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            sb.AppendFormat("{0}RunMsLink(\"{1}\"", indention, this._output.FileNameAsBooString);

            if (this._objects != null)
                foreach (ContentFile obj in this._objects)
                    sb.AppendFormat(", \"{0}\"", obj.FileNameAsBooString);
            if (this._libs != null)
                foreach (ContentFile lib in this._libs)
                    sb.AppendFormat(", \"{0}\"", lib.FileNameAsBooString);
            if (this._resources != null)
                foreach (ContentFile res in this._resources)
                    sb.AppendFormat(", \"{0}\"", res.FileNameAsBooString);
            sb.Append(")");
            booCodeLines.Add(sb.ToString());
        }
        #endregion

        #region IBuildProduct Member
        public override System.Diagnostics.ProcessStartInfo GetProgramStartInfo(BuildToolFamilyEnv env)
        {
            System.Diagnostics.ProcessStartInfo result = new System.Diagnostics.ProcessStartInfo();
            result.FileName = this.FileName;
            TempFilesParameters tempFilesParam=(TempFilesParameters)BuildConfig.GetDefaultParameterOfType(typeof(TempFilesParameters));
            string tempFileName=tempFilesParam.CreatePathFor("link.txt", ContentType.TXT).FileName;
            System.IO.StreamWriter cmdArgs = new StreamWriter(tempFileName);
            cmdArgs.Write("/DLL /VERBOSE:LIB /SUBSYSTEM:WINDOWS /MANIFEST /NOLOGO /OUT:");
            cmdArgs.Write(this._output.FileName);
            cmdArgs.Write(string.Format(" /MANIFESTFILE:{0}.manifest", this._output.FileName));
            cmdArgs.Write(" /NODEFAULTLIB:LIBCMT.LIB"); // in case that some static libraries have not been built
                                                        // for use in DLLs.

            CxxParameters parameters = (CxxParameters)BuildConfig.GetDefaultParameterOfType(typeof(CxxParameters));
            string specialParameters = parameters.GetOptions(this.Name);
            if (specialParameters != null)
            {
                cmdArgs.Write(" ");
                cmdArgs.Write(specialParameters);
            }
            foreach (ContentFile objFile in this._objects)
            {
                cmdArgs.Write(" ");
                cmdArgs.Write(objFile.FileName);
            }
            if (parameters.Libraries == CxxLibraries.NoStdLibraries)
                cmdArgs.Write(" /NODEFAULTLIB");
            else
            {
                if (parameters.Libraries != CxxLibraries.NoStdLibraries)
                {
                    cmdArgs.Write(" /Libpath:\"");
                    cmdArgs.Write(System.IO.Path.Combine(ToolProperties.GetPlatformSDK(), "lib"));
                    cmdArgs.Write("\"");

                    cmdArgs.Write(" /Libpath:\"");
                    cmdArgs.Write(System.IO.Path.Combine(ToolProperties.GetVCPath(), "lib"));
                    cmdArgs.Write("\"");
                }
                if ((parameters.Libraries & CxxLibraries.GeneralOSLibraries) == CxxLibraries.GeneralOSLibraries)
                    cmdArgs.Write(" kernel32.lib user32.lib shell32.lib advapi32.lib ole32.lib oleaut32.lib");
                if ((parameters.Libraries & CxxLibraries.GDILibraries) == CxxLibraries.GDILibraries)
                    cmdArgs.Write(" gdi32.lib gdiplus.lib comdlg32.lib comctl32.lib");
                if ((parameters.Libraries & CxxLibraries.TcpAndRpcLibraries) == CxxLibraries.TcpAndRpcLibraries)
                    cmdArgs.Write(" rpcrt4.lib wsock32.lib");
            }
            foreach (ContentFile libFile in this._libs)
            {
                cmdArgs.Write(" ");
                cmdArgs.Write(libFile.FileName);
            }
            foreach (ContentFile resFile in this._resources)
            {
                cmdArgs.Write(" ");
                cmdArgs.Write(resFile.FileName);
            }

            if (parameters.DebugInfo)
            {
                cmdArgs.Write(" /DEBUG");
            }
            else
            {
                if (parameters.Optimization != CxxOptimization.No)
                {
                    cmdArgs.Write(" /OPT:REF");
                }
            }
            if (BuildConfig.GetConfig().AbortOptions == AbortOptions.TreatWarningsAsErrors)
                cmdArgs.Write(" /WX");
            cmdArgs.Close();
            result.Arguments = string.Format("@{0}", tempFileName);
            string vsEnvDir = ToolProperties.GetEnvDir();
            if (vsEnvDir.Length > 0)
                result.EnvironmentVariables["PATH"] = vsEnvDir + ";" + result.EnvironmentVariables["PATH"];
            return result;
        }

        public bool Execute(BuildToolFamilyEnv env, DateTime validityOfBuildSystem)
        {
            ErrorDataReceiver receiver = new ErrorDataReceiver(this);
            receiver.WarningClassifier = new System.Text.RegularExpressions.Regex(@"\swarning\s",
                System.Text.RegularExpressions.RegexOptions.Compiled
                | System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            receiver.ErrorClassifier = new System.Text.RegularExpressions.Regex(@"\serror\s",
                System.Text.RegularExpressions.RegexOptions.Compiled
                | System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            receiver.FilePosPattern = new System.Text.RegularExpressions.Regex(
                @"^(?<file>[^\(]+)\((?<line>\d+),(?<column>\d+)\)");
            wx.ProcessUtils.ProcessStarter starter = new wx.ProcessUtils.ProcessStarter(this.GetProgramStartInfo(env),
                new wx.ProcessUtils.MsgEventHandler(receiver.OnReceiveMsgEvent));
            System.Diagnostics.Process process = starter.Start();
            if (process.ExitCode == 0)
            {
                starter.StartInfo.FileName = System.IO.Path.Combine(ToolProperties.GetPlatformSDK(), "bin");
                starter.StartInfo.FileName = System.IO.Path.Combine(starter.StartInfo.FileName, "mt.exe");
                starter.StartInfo.WorkingDirectory = ToolProperties.GetPlatformSDK();
                starter.StartInfo.Arguments = string.Format("-manifest {0}.manifest -outputresource:{0};2", this._output.FileName);
                process = starter.Start();
            }
            return process.ExitCode == 0;            
        }

        #endregion
    }

    /** <summary>This is the wrapper around the RC.EXE resource compiler.
    * Within this framework, this tool will be used to compile *.rc files ContentType.RCFile
    * into *.res files ContentType.ResFile. Please note, that this class of tools is not portable.
    * So, all data provided by RC-files will only be used on Windows platforms.</summary>
    */
    public class RC : BaseAction, IBuildActionProvider, IBuildAction
    {
        #region State
        ContentFile _src= null;
        ContentFile _output = null;
        #endregion

        #region CTor
        /** <summary> This creates an instance that serves as a build action provider. </summary> */
        public RC()
        {
        }
        #endregion

        #region BaseAction
        public override ICollection<IBuildProduct> GetPrerequisites()
        {
            ICollection<IBuildProduct> result = new List<IBuildProduct>();
            if (this._src.Count > 0)
                result.Add(this._src);
            return result;
        }

        public override bool ContainsPrerequisite(IBuildProduct prereq)
        {
           return this._src.Equals(prereq);
        }

        public override ICollection<IBuildProduct> GetTargets()
        {
            ICollection<IBuildProduct> result = new List<IBuildProduct>();
            result.Add(this._output);
            return result;
        }
        #endregion

        #region IBuildActionProvider Member

        public ICollection<OperatingSystem> ApplicableOSs
        {
            get
            {
                List<OperatingSystem> os = new List<OperatingSystem>();
                os.Add(OperatingSystem.WinXP);
                return os;
            }
        }

        public override IDictionary<string, EnvironmentVarInfo> UsedVars
        {
            get
            {
                Dictionary<string, EnvironmentVarInfo> result = new Dictionary<string, EnvironmentVarInfo>();
                result.Add("PATH", new EnvironmentVarInfo("PATH", "Semicolon separated list of directories where CMD looks for executable programs.", typeof(DirectoryList)));
                result.Add("INCLUDE", new EnvironmentVarInfo("INCLUDE", "Semicolon separated list of directories where LINK.EXE looks for static libraries files.", typeof(DirectoryList)));
                return result;
            }
        }

        /** <summary> <c>rc </c> .exe </summary> */
        public string Name
        {
            get { return "rc.exe"; }
        }

        /** <summary> \c "MS VC" </summary> */
        public string ToolFamily
        {
            get { return "MS VC"; }
        }

        public string Description
        {
            get { return "The MS C/C++ resource compiler."; }
        }

        /** <summary> The filename of the compiler. </summary> */
        public string FileName
        {
            get
            {
              if (ToolProperties.IsRelevant)
              {
                string sdkPath = ToolProperties.GetPlatformSDK();
                sdkPath = Path.Combine(sdkPath, "bin");
                string clFile = Path.Combine(sdkPath, this.Name);
                return clFile;
              }
              else
                return "rc.exe";
            }
        }

        public bool IsAvailable
        {
            get
            {
               try {
                return File.Exists(this.FileName);
               } catch {
                 return false;
               }
            }
        }

        public bool MayContentFilePrerequisitesSuffice(ContentType target, ICollection<ContentType> prerequisites)
        {
            if (target.Implies(ContentType.ResFile))
            {
                // at least one prerequisite should be an rc file
                foreach (ContentType prereqType in prerequisites)
                    if (prereqType.Implies(ContentType.RCFile))
                        return true;
            }
            // the build system does currently not consider native executables.
            return false;
        }

        /** <summary> This creates files of type ContentType.ResFile. </summary> */
        public ICollection<ContentType> ContentFileTargets
        {
            get
            {
                return new ContentType[] {ContentType.ResFile};
            }
        }

        public IBuildAction Create(BuildToolFamilyEnv env, IBuildProduct target, ICollection<IBuildProduct> prerequisites)
        {
            RC result = new RC();
            ContentFile fileTarget = (ContentFile)target;
            if (fileTarget.Type.Contains(ContentType.ResFile))
                result._output = fileTarget;
            else
                throw new Exception("Tool rc.exe only produces Windows RES files.");
            foreach (IBuildProduct prereq in prerequisites)
            {
                ContentFile prereqFile = prereq as ContentFile;
                if (prereqFile != null)
                {
                    if (prereqFile.Type.Implies(ContentType.RCFile))
                    {
                        if (result._src == null)
                            result._src = prereqFile;
                        else
                            throw new Exception("Please provide exactly one RC file for each project. I cannot deal with a second or third RC file.");
                    }
                }
            }
            if (result._src == null)
                throw new Exception("Cannot create RC.EXE action without RC source.");
            return result;
        }

        #endregion

        #region IBuildAction Member

        /** <summary> This is its own action provider. </summary> */
        public IBuildActionProvider ActionProvider
        {
            get { return this; }
        }

        public ActionPriority Priority
        {
            get { return ActionPriority.Default; }
        }
        #endregion

        #region BOO Export
        /// <summary>
        /// This will be called for any action provider before IBuildAction.AppendBooCode() is called.
        /// This provides action providers with the opportunity to import modules and create variables
        /// for global options.
        /// </summary>
        /// <param name="env">Environment containing status that can be shared among tools of the same family.</param>
        /// <param name="importModules">List of modules that shall be imported. Add required modules here. Each module
        /// will be imported exactly once (even if it occurs more than once in the list).</param>
        /// <param name="booDeclarations">Lines of code that will be added to the preamble of the BOO code.
        /// Please note, that each line may only appear once. All subsequent additions of this line of
        /// code will be ignored. These lines shall contain declarations of variables etc.</param>
        /// <param name="booDefinitions">Lines of code that that will be added before the code provided by
        /// the actions to build the system. Typically, this will contain the definition of functions
        /// that are used on building. Lines starting with "import" will only be added once to the final code. </param>
        public override void AppendToBooPreamble(BuildToolFamilyEnv env, List<string> importModules, List<string> booDeclarations, List<string> booDefinitions)
        {
            #region Declarations
            CxxParameters parameters = (CxxParameters)BuildConfig.GetDefaultParameterOfType(typeof(CxxParameters));
            string specialParameters = parameters.GetOptions(this.Name);
            if (specialParameters == null)
            {
                booDeclarations.Add("CL_RC_SpecialParameters=\"\" # no special parameters declared");
            }
            else
            {
                booDeclarations.Add(string.Format("CL_RC_SpecialParameters=\"{0}\"", ContentFile.ConvertFilenameToBooString(specialParameters)));
            }
            System.Text.StringBuilder includes = new System.Text.StringBuilder();
            if (parameters.Libraries != CxxLibraries.NoStdLibraries)
            {
                includes.Append(" /I \\\"");
                includes.Append(ContentFile.ConvertFilenameToString(Path.Combine("${PlatformSDKPath}", "include")));
                includes.Append("\\\"");

                includes.Append(" /I \\\"");
                includes.Append(ContentFile.ConvertFilenameToString(Path.Combine("${VisualCPath}", "include")));
                includes.Append("\\\"");
            }
            foreach (string includeFile in parameters.IncludePaths)
            {
                includes.AppendFormat(" /I \\\"{0}\\\"", ContentFile.ConvertFilenameToString(includeFile));
            }
            booDeclarations.Add(string.Format("CL_RC_INCLUDES=\"{0}\"", includes));
            #endregion
            #region Definitions
            booDefinitions.Add(string.Format("def RunMsRcTool(targetFile as string, srcFile as string):"));
            booDefinitions.Add(string.Format("\tif not TestForRebuild(targetFile, srcFile): return"));
            booDefinitions.Add(string.Format("\tprint \"MS rc.exe creates\", targetFile"));
            booDefinitions.Add(string.Format("\tfilename=Path.Combine(PlatformSDKPath, 'bin')"));
            booDefinitions.Add(string.Format("\tfilename=Path.Combine(filename, '{0}')", this.Name));
            booDefinitions.Add(string.Format("\targs=StringBuilder()"));
            booDefinitions.Add(string.Format("\targs.Append(\"/fo \\\"${{targetFile}}\\\"\")"));
            booDefinitions.Add(string.Format("\targs.Append(\" ${{CL_RC_SpecialParameters}}\")"));
            booDefinitions.Add(string.Format("\targs.Append(\" ${{CL_RC_INCLUDES}}\")"));
            booDefinitions.Add(string.Format("\targs.Append(\" \\\"${{srcFile}}\\\"\")"));
            booDefinitions.Add(string.Format("\tstartinfo=System.Diagnostics.ProcessStartInfo()"));
            booDefinitions.Add(string.Format("\tstartinfo.FileName=filename"));
            booDefinitions.Add(string.Format("\tstartinfo.Arguments=args.ToString()"));
            booDefinitions.Add(string.Format("\tstartinfo.UseShellExecute=false"));
            booDefinitions.Add(string.Format("\tif VisualCEnvPath.Length > 0:"));
            booDefinitions.Add(string.Format("\t\tstartinfo.EnvironmentVariables[\"PATH\"] = VisualCEnvPath + \";\" + startinfo.EnvironmentVariables[\"PATH\"]"));
            booDefinitions.Add(string.Format("\tp=System.Diagnostics.Process.Start(startinfo)"));
            booDefinitions.Add(string.Format("\tp.WaitForExit()"));
            booDefinitions.Add(string.Format("\tif p.ExitCode!=0:"));
            booDefinitions.Add(string.Format("\t\traise System.Exception(\"Build action failed.\")"));
            #endregion
        }

        /// <summary>
        /// This method will create BOO source code and append this code to the provided text writer.
        /// </summary>
        /// <param name="env">This is an environment that different tools of the same family may use to exchange information.
        /// This store is typically used to save information on configuration files or thinsgs of that kind that will be
        /// shared among all tools of the same family.</param>
        /// <param name="booCodeLines">The code that will actually build something. Each list entry will be a line of code in the resulting
        /// BOO program.</param>
        /// <param name="indention">A string that shall preceed all created lines. </param>
        /// <remarks>Refer to IBuildActionProvider.AppendToBooPreamble() for an example.
        /// 
        /// This implementation will only provide
        /// </remarks>
        /// <exception cref="NotSupportedException">Will be thrown if this feature is not supported.</exception>
        public override void AppendBooCode(List<string> booCodeLines, string indention, BuildToolFamilyEnv env)
        {
            booCodeLines.Add(string.Format("{0}RunMsRcTool(\"{1}\", \"{2}\")", indention, this._output.FileNameAsBooString, this._src.FileNameAsBooString));
        }
        #endregion

        #region IBuildProduct Member
        public override System.Diagnostics.ProcessStartInfo GetProgramStartInfo(BuildToolFamilyEnv env)
        {
            System.Diagnostics.ProcessStartInfo result = new System.Diagnostics.ProcessStartInfo();
            result.FileName = this.FileName;
            System.Text.StringBuilder cmdArgs = new System.Text.StringBuilder();
            cmdArgs.AppendFormat("/fo {0}", this._output.FileName);

            CxxParameters parameters = (CxxParameters)BuildConfig.GetDefaultParameterOfType(typeof(CxxParameters));
            string specialParameters = parameters.GetOptions(this.Name);
            if (specialParameters != null)
            {
                cmdArgs.Append(" ");
                cmdArgs.Append(specialParameters);
            }
            if (parameters.Libraries != CxxLibraries.NoStdLibraries)
            {
                    cmdArgs.Append(" /I \"");
                    cmdArgs.Append(System.IO.Path.Combine(ToolProperties.GetPlatformSDK(), "include"));
                    cmdArgs.Append("\"");

                    cmdArgs.Append(" /I \"");
                    cmdArgs.Append(System.IO.Path.Combine(ToolProperties.GetVCPath(), "include"));
                    cmdArgs.Append("\"");
            }

            foreach (string includeFile in parameters.IncludePaths)
            {
                cmdArgs.AppendFormat(" /I \"{0}\"", includeFile);
            }
            cmdArgs.AppendFormat(" {0}", this._src.FileName);

            result.Arguments = cmdArgs.ToString();
            string vsEnvDir = ToolProperties.GetEnvDir();
            if (vsEnvDir.Length > 0)
                result.EnvironmentVariables["PATH"] = vsEnvDir + ";" + result.EnvironmentVariables["PATH"];
            return result;
        }

        public bool Execute(BuildToolFamilyEnv env, DateTime validityOfBuildSystem)
        {
            ErrorDataReceiver receiver = new ErrorDataReceiver(this);
            receiver.WarningClassifier = new System.Text.RegularExpressions.Regex(@"\swarning\s",
                System.Text.RegularExpressions.RegexOptions.Compiled
                | System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            receiver.ErrorClassifier = new System.Text.RegularExpressions.Regex(@"\serror\s",
                System.Text.RegularExpressions.RegexOptions.Compiled
                | System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            receiver.FilePosPattern = new System.Text.RegularExpressions.Regex(
                @"^(?<file>[^\(]+)\((?<line>\d+),(?<column>\d+)\)");
            wx.ProcessUtils.ProcessStarter starter = new wx.ProcessUtils.ProcessStarter(this.GetProgramStartInfo(env),
                new wx.ProcessUtils.MsgEventHandler(receiver.OnReceiveMsgEvent));
            System.Diagnostics.Process process = starter.Start();
            return process.ExitCode == 0;
        }

        #endregion
    }

}
