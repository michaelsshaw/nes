/** Build system for wx.NET.
 * 
 * This DLL contains basic implementations to build (compile and link) C/C++ programs,
 * compile .NET assemblies written in C#, sign them, and install them.
 * 
 * \file 
 *
 * Copyright 2009 Harald Meyer auf'm Hofe harald_meyer@users.sourceforge.net
 * 
 * Licensed under the wxWidgtes license, see LICENSE.txt for details.
 * 
 * $Id: CSharpCompiler.cs,v 1.12 2010/06/16 18:12:32 harald_meyer Exp $
 */



using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace wx.Build.Net
{
    /** <summary> Compiler option for tools on C# compilation.
     * Very much like <c>System </c> .CodeDom.Compiler.CompilerParameters but
     * reimplemented in order to provide support for runtimes that do
     * not implement System.CodeDom.
     * 
     * Note, that all properties on file input and output like referenced
     * assemblies and output assembly are missing here since they are defined
     * by the build action. </summary> */
    public class NetCompilerParameters : BuildParameters
    {
        /** <summary> Generate debug information. </summary> */
        public bool IncludeDebugInformation = false;

        /** <summary> Set the level at which the compiler 
         * should start displaying warnings. </summary> */
        public int WarningLevel = 3;
    
        /** <summary> Set compiler argument to optimize output. </summary> */
        public bool OptimizeOutput=true;

        /** <summary> Set this to <c>true </c>  (default) to enable <c>System </c> .diagnostics.Trace.
         * Set this to <c>false </c>  to disable trace log. With <c>true </c> , this will define <c>TRACE </c> . </summary> */
        public bool EnableTraceLog = true;

        /** <summary> Set a temporary files collection.
         * The TempFileCollection stores the temporary files
         * generated during a build in the current directory,
         * and does not delete them after compilation. </summary> */
        public System.CodeDom.Compiler.TempFileCollection TempFiles = new System.CodeDom.Compiler.TempFileCollection();

        public override BuildParameters Clone()
        {
            return (BuildParameters)this.MemberwiseClone();
        }

        /// <summary>
        /// Global features referring to .NET programs.
        /// These features have been added by the provider. Users of these
        /// features can read this list to determine whether the feature is
        /// available or not.
        /// </summary>
        public FeatureList Features = new FeatureList();
    }

    /// <summary> Base class of all .NET compilers creating an assembly from sources.
    /// </summary>
    public abstract class NetCodeProvider: BaseAction
    {
        #region State
        protected ContentFile _target;
        protected FileProducts _references = new FileProducts(ContentType.DotNetDll);
        protected FileProducts _icons = new FileProducts(ContentType.ICO);

        protected string _mainClass = null;
        #endregion

        #region CTor
        /** <summary> This is for inheritors that also implement IBuildActionClass. </summary> */
        protected NetCodeProvider()
        {
            this._target = null;
        }

        /** <summary> Creates an action building the specified target. </summary> */
        protected NetCodeProvider(ContentFile assemblyTarget)
        {
            if (assemblyTarget == null
                || !ContentType.DotNetDll.Contains(assemblyTarget.Type))
            {
                throw new ArgumentException("Actions of class CSharpCodeProvider only achieve the target of building assemblies.");
            }
            this._target = assemblyTarget;
        }
        #endregion

        #region Public Properties
        /** <summary> Returns a collection of referenced .NET DLLs.
         * ContentType.DotNetExe or types that contain this. </summary> */
        public IFileProducts References { get { return this._references; } }

        /** <summary> Returns the name of the assembly to be made. </summary> */
        public ContentFile TargetAssembly { get { return this._target; } }

        /** <summary> Get or set the name of the main class that contains the main program.
         * This will only be used compiling executables. This may be <c>null </c>  if not specified.
         * In that case it's up to the action to determine the <c>Main() </c>  method to be used to start
         * up the program. </summary> */
        public string MainClass { get { return this._mainClass; } }
        #endregion

        #region Internals
        /** <summary> This will be used by the appropriate projects to define the main program. </summary> */
        internal void SetMainClass(string mainClassName)
        {
            this._mainClass = mainClassName;
        }
        #endregion
    }

    /** <summary> Wrapper of the Microsoft.CSharp.CSharpCodeProvider class.
     * Microsoft .NET and Mono both implement the Microsoft.CSharp.CSharpCodeProvider as a wrapper of their
     * C# compilers. This build action uses this wrapper as interface to compile C# code. </summary> */
    public class CSharpCodeProvider : NetCodeProvider, IBuildActionProvider, IBuildAction
    {
        #region State
        FileProducts _csharpSources=new FileProducts(ContentType.CSharpCode);
        FileProducts _signatureFile = new FileProducts(ContentType.SnKeys);

        static bool _usePortableOptionsOnly = false;
        #endregion

        #region CTor
        /** <summary> This will be used by the internal framework to create an instance that will be asked for members of IBuildActionClass. </summary> */
        public CSharpCodeProvider()
        {
        }

        /** <summary> The compiler info on the used CS compiler. </summary> */
        public System.CodeDom.Compiler.CompilerInfo Info
        {
            get
            {
                return System.CodeDom.Compiler.CodeDomProvider.GetCompilerInfo("cs");
            }
        }

        /** <summary> The default parameters of the used compiler. </summary> */
        public System.CodeDom.Compiler.CompilerParameters DefaultParameters
        {
            get
            {
                System.CodeDom.Compiler.CompilerInfo info = this.Info;
                if (info == null)
                    return null;                
                return info.CreateDefaultCompilerParameters();
            }
        }

        public string Name
        {
            get
            {
                System.CodeDom.Compiler.CompilerInfo info = this.Info;
                if (info == null)
                    return this.GetType().Name;
                else
                    return info.CodeDomProviderType.Name;
            }
        }

        /** <summary> The same as <c>Name </c> . </summary> */
        public string ToolFamily
        {
            get
            {
                return this.Name;
            }
        }

        public string Description
        {
            get
            {
                string result="This tool uses classes of the System.CodeDom.Compiler namespace to compile .NET assemblies from C# sources.";
                System.CodeDom.Compiler.CompilerParameters defaultParameters = this.DefaultParameters;
                if (defaultParameters != null && defaultParameters.CompilerOptions != null)
                    result += "\nDefault options: " + defaultParameters.CompilerOptions.ToString();
                return result;
            }
        }

        /** <summary> Better use explicit calls of the compiler because we then know what it is. So: ActionPriority.Fallback. </summary> */
        public ActionPriority Priority
        {
            get
            {
                return ActionPriority.Fallback;
            }
        }

        /** <summary> This creates an operations.
         * First argument is the target. All sources will be used accourding to their content type.
         * Please note, that you must provide all CSharp-sources within the same instance of content files
         * and all referenced assemblies also with the same instance.
         * 
         * Please note, that the arguments MUST contain a non-empty bunch of CSharp sources. Otherwise, this will not
         * be applicable. </summary> */
        CSharpCodeProvider(ContentFile assemblyTarget, ICollection<IBuildProduct> prerequisites)
            : base(assemblyTarget)
        {
            if (prerequisites != null)
            {
                foreach (IBuildProduct prerequisite in prerequisites)
                {
                    IFileProducts file = prerequisite as IFileProducts;
                    if (file != null)
                    {
                        if (file.Type.Implies(ContentType.DotNetDll))
                            this._references.Add(file);
                        else if (file.Type.Implies(ContentType.CSharpCode))
                            this._csharpSources.Add(file);
                        else if (file.Type.Implies(ContentType.ICO))
                            this._icons.Add(file);
                        else if (file.Type.Implies(ContentType.SnKeys))
                            this._signatureFile.Add(file);
                    }
                }
                if (this._csharpSources.Count == 0)
                    throw new ArgumentException(string.Format("Tool {0} requires at least on C# source as input.", this.GetType().Name));
            }
        }
        #endregion

        #region IBuildActionClass Member
        /** <summary> Not constrained to a paricular operatin system. </summary> */
        public ICollection<OperatingSystem> ApplicableOSs
        {
            get { return null; }
        }

        /** <summary> This will try to refer to <c>System </c> .CodeDom.Compiler.CodeDomProvider.IsDefinedLanguage("cs"). 
         * This fails on the GNU implementation of the CLR. </summary> */
        public bool IsAvailable
        {
            get
            {
              if (BuildConfig.NotWindows)
                return false; // Code Provider does not seem to work on Mono and Linux.
              else
              {
                try
                {
                    return System.CodeDom.Compiler.CodeDomProvider.IsDefinedLanguage("cs");
                }
                catch (Exception exc)
                {
                    System.Diagnostics.Trace.WriteLine(string.Format("Caught {0} on testing availability of CSharpCodeProvider.", exc.Message));
                    return false;
                }
              }
            }
        }

        /** <summary> Returns true if <c>target </c>  is likely to be produced by an action of this type provided that the specified prerequisites are available.
         * If <c>prerequisites </c>  contains ContentType.CSharpCode, this will return <c>true </c> .
         * Signed targets also require a key file. </summary> */
        public bool MayContentFilePrerequisitesSuffice(ContentType target, ICollection<ContentType> prerequisites)
        {
            bool requiresSN = false;
            if (target.Implies(ContentType.SnDotNetDll))
                requiresSN = true;
            bool foundCSharp = false;
            bool foundSN = false;
            foreach(ContentType contentFile in prerequisites)
            {
                if (contentFile.Equals(ContentType.CSharpCode))
                    foundCSharp=true;
                if (contentFile.Equals(ContentType.SnKeys))
                    foundSN = true;
                bool ok = foundCSharp && (!requiresSN || foundSN);
                if (ok)
                    return true;
            }
            return false;
        }

        /** <summary> Produces ContentType.DotNetDll or ContentType.DotNetExe (unsigned) or signed assemblies. </summary> */
        public ICollection<ContentType> ContentFileTargets
        {
            get { return new ContentType[] { ContentType.DotNetDll, ContentType.DotNetExe, ContentType.SnDotNetDll, ContentType.SnDotNetExe }; }
        }

        /** <summary> Creates an action producing <c>assemblyTarget </c>  (an assembly file) from the <c>prerequisites </c> .
         * Please note, that this shall also work if <c>prerequisites </c>  contains too many files of files
         * of undesired type. </summary> */
        public IBuildAction Create(BuildToolFamilyEnv env, IBuildProduct assemblyTarget, ICollection<IBuildProduct> prerequisites)
        {
            return new CSharpCodeProvider((ContentFile)assemblyTarget, prerequisites);
        }
        #endregion

        #region IBuildAction Member
        /** <summary> Returns a list of sources and references. </summary> */
        public override ICollection<IBuildProduct> GetPrerequisites()
        {
            List<IBuildProduct> result = new List<IBuildProduct>();
            result.Add(this._csharpSources);
            result.Add(this._references);
            result.Add(this._icons);
            result.Add(this._signatureFile);
            return result;
        }

        public override bool ContainsPrerequisite(IBuildProduct prereq)
        {
            return this._csharpSources.Contains(prereq)
                || this._references.Contains(prereq)
                || this._icons.Contains(prereq)
                || this._signatureFile.Contains(prereq);
        }

        /** <summary> Returns a reference to the assembly file as ContentFile. </summary> */
        public override ICollection<IBuildProduct> GetTargets()
        {
            List<IBuildProduct> result = new List<IBuildProduct>();
            result.Add(this._target);
            return result;
        }

        /** <summary> Compile. </summary> */
        public bool Execute(BuildToolFamilyEnv env, DateTime validityOfBuildSystem)
        {
            return this.Execute(env, _usePortableOptionsOnly);
        }

        /** <summary> Compile.</summary><remarks>
         * \param usePortableOptionsOnly constrains this with <c>true </c>  to exclusively use parameter options which are known to be portable. </remarks> */
        public bool Execute(BuildToolFamilyEnv env, bool usePortableOptionsOnly)
        {
            System.CodeDom.Compiler.CodeDomProvider provider = System.CodeDom.Compiler.CodeDomProvider.CreateProvider("cs");
            System.CodeDom.Compiler.CompilerParameters parameters = this.GetParameters(usePortableOptionsOnly);
            System.CodeDom.Compiler.CompilerResults results = provider.CompileAssemblyFromFile(parameters, this.Sources.Files.Filenames);
            if (results.Errors==null || results.Errors.Count == 0)
                return true;

            if (!usePortableOptionsOnly && results.Errors.Count == 1 && results.Errors[0].ToString().Contains("CS2007"))
            {
                // the compiler complains about some unknown switches. Maybe we shall remove all questionable options.
                System.CodeDom.Compiler.CompilerError error = results.Errors[0];
                _usePortableOptionsOnly = true;
                BuildConfig.HandleErrorObject(new ErrorObject(ErrorObject.MessageType.Message, "Restarting with portable parameters only because of compiler error {0}.", error.ToString(), new ErrorObject.FilePos(error.FileName, error.Line, error.Column), ErrorObject.ErrorNumber.Create(error.ErrorNumber), this));
                parameters = this.GetParameters(true);
                results = provider.CompileAssemblyFromFile(parameters, this.Sources.Files.Filenames);
                if (results.Errors == null || results.Errors.Count == 0)
                    return true;
            }

            bool success = true;
            foreach (System.CodeDom.Compiler.CompilerError error in results.Errors)
            {
                ErrorObject.MessageType type = ErrorObject.MessageType.Error;
                if (error.IsWarning)
                    type = ErrorObject.MessageType.Warning;
                else
                    success = false;
                BuildConfig.HandleErrorObject(new ErrorObject(type, error.ToString(), new ErrorObject.FilePos(error.FileName, error.Line, error.Column), ErrorObject.ErrorNumber.Create(error.ErrorNumber), this));
            }
            return success;
        }

        /** <summary> This is its own action provider. </summary> */
        public IBuildActionProvider ActionProvider
        {
            get { return this; }
        }
        #endregion

        #region Public Methods and Properties
        /** <summary> Returns the compiler parameters as derived from the arguments and the current BuildConfig.</summary><remarks>
         * \param portable will only add portable options. This affects in particular those <c>CompilerOptions </c> 
         *  that are only supported for Microsoft.NET but will cause errors in MONO. </remarks> */
        public System.CodeDom.Compiler.CompilerParameters GetParameters(bool portable)
        {
            System.CodeDom.Compiler.CompilerParameters parameters = new System.CodeDom.Compiler.CompilerParameters();
            if (this.References.Count > 0)
                parameters.ReferencedAssemblies.AddRange(this.References.Files.Filenames);
            parameters.OutputAssembly = this._target.FileName;
            parameters.GenerateExecutable = this._target.Type.Implies(ContentType.DotNetExe);
            parameters.GenerateInMemory = false;
            NetCompilerParameters netParameters = (NetCompilerParameters)BuildConfig.GetDefaultParameterOfType(typeof(NetCompilerParameters));
            TempFilesParameters tmpParameters = (TempFilesParameters)BuildConfig.GetDefaultParameterOfType(typeof(TempFilesParameters));
            parameters.IncludeDebugInformation = netParameters.IncludeDebugInformation;
            if (this._mainClass != null)
                parameters.MainClass = this._mainClass;
            parameters.TempFiles = new System.CodeDom.Compiler.TempFileCollection(tmpParameters.GetDirectory(), tmpParameters.KeepFiles);
            parameters.TreatWarningsAsErrors = (BuildConfig.GetConfig().AbortOptions == AbortOptions.TreatWarningsAsErrors);
            parameters.WarningLevel = netParameters.WarningLevel;
            if (this._icons.Count > 0)
                parameters.Win32Resource = this._icons.Files.GetOneFileName();
            if (this._signatureFile.Count > 0)
                parameters.CompilerOptions += " -keyfile:" + this._signatureFile.Files.GetOneFileName();
            if (netParameters.OptimizeOutput)
                parameters.CompilerOptions += " -optimize";
            if (!portable)
            {
                if (this.Features.ContainsKey(CSharpAssemblyProject.PlatformX32))
                    parameters.CompilerOptions += " -platform:x86";
                else if (this.Features.ContainsKey(CSharpAssemblyProject.PlatformX64))
                    parameters.CompilerOptions += " -platform:x64";
            }
            foreach (string feature in this.Features
                        .Without(CSharpAssemblyProject.PlatformX32, CSharpAssemblyProject.PlatformX64)
                        .EnabledSymbols)
                parameters.CompilerOptions += " -define:" + feature;
            return parameters;
        }

        /** <summary> Returns the source files. </summary> */
        public IFileProducts Sources { get { return this._csharpSources; } }
        #endregion
    }
}
