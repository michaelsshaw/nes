﻿/** Build system for wx.NET.
 * 
 * This DLL contains basic implementations to build (compile and link) C/C++ programs,
 * compile .NET assemblies written in C#, sign them, and install them.
 * 
 * \file 
 *
 * Copyright 2009 Harald Meyer auf'm Hofe harald_meyer@users.sourceforge.net
 * 
 * Licensed under the wxWidgets license, see LICENSE.txt for details.
 * 
 * $Id: IBuildAction.cs,v 1.1 2010/06/06 09:00:04 harald_meyer Exp $
 */



using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Text;

namespace wx.Build
{
    /** <summary> Operating system. </summary> */
    public enum OperatingSystem
    {
        WinXP,
        Linux,
        MacOsX,
    }

    /** <summary> Instances of this type represent build objects that result from an action.
     * Build objects know a validity. Build objects shall be rebuilt if their validity is smaller than the latest
     * validity of their prerequisites.
     * Build objects also implement <c>Equals </c>  and <c>GetHashCode() </c>  since they are values. </summary> */
    public interface IBuildObject
    {
        /** <summary> Returns validity timstamp of this object.
         * Whenever this is equal or later than all prerequisites, this is considered consistent with the
         * prerequisites on rebuilding. </summary> */
        DateTime GetValidity();

        /** <summary> This is the counterpart of the <c>Validity </c> .
        * If this occurs as a prerequisite, this shall be compared with the Validity of the target in order to assess
        * whether rebuild is necessary or not.
        * </summary> */
        DateTime GetValidityDemand();
    }

    /** <summary>A build product is a build object that serves as a designator of a target or prerequisite in the build process.</summary>
     * <remarks>As a consequence, instances designating the same object shall be identical (w.r.t. System.Object.Equals() and System.Object.GetHashCode()).
     * The interface also requires implementations of System.IComparable in order to allow efficient comparison of
     * collections of object. Of course, <c>CompareTo()</c> shall be 0 if and only if \c Equals() is true. All instances implementing
     * this interface shall be comparable. So, you will have to order by use of the class name in case of incompatible classes (refer
     * to existing implementations).
     * <para>
     * Build products are used to represent the targets and prerequisites of build projects and actions.
     * </para>
     * </remarks>
    */
    public interface IBuildProduct : IBuildObject, IComparable, System.Xml.Serialization.IXmlSerializable
    {
        /** <summary> This is a collection of projects that build this target.
        * This may be empty or <c>null </c> .
        * This method will be used to determine interdependencies between projects. </summary> */
        ICollection<RefToProject> GetProjects();
    }

    /** <summary> Build actions will be created dynamically. Constants of this enumeration will be used by the actions to state, whether they have to be executed or not. </summary> */
    public enum ActionPriority
    {
        /** <summary> This has been prefered according to user input.
         * This is even more important than preference according to the static implementation (cf. <c>Preferred) </c> . </summary> */
        PreferredByUserInput,
        /** <summary> An action of this kind will be preferably used.
         * If this fails, alternatives will be searched (also of priority default). </summary> */
        Preferred,
        /** <summary> Actions of this kind will be used, if preferred actions are either not available or they failed. </summary> */
        Default,
        /** <summary> Actions of this kind will be used, if neither preferred nor default actions are available or they failed. </summary> */
        Fallback
    }

    /// <summary>
    /// A build action is an action presupposing particular symbolic targets and content files achieving symbolic targets
    /// and/or particular content files.
    /// Build actions implement a method Execute() that will test for the prerequisites and execute the actions on success.
    /// 
    /// Actions will usually be created by action providers (implementing wx.Build.IActionProvider). However, some actions
    /// will be directly called bythe projects.
    /// </summary>
    public interface IBuildAction : IBuildObject
    {
        /** <summary> The class that created this action.
         * This is often the action itself. </summary> */
        IBuildActionProvider ActionProvider { get; }

        /** <summary> The name of the action.
         * This is for messages and print outs. Usually, this is the name of the action provider.
         * However, projects do not have a provider but a name as member.
         *
         * Implementors must make sur that names only contain letters, digits and the dot '.'.
         * This is to ease serialization of build plans as batch files. </summary> */
        string Name { get; }

        /// <summary>
        /// The project that requested this action. the result may be <c>null</c> if this instance also
        /// implements IBuildActionProvider and this instance is meant to be a action provider and not
        /// an action. Note, that projects may be set only once. This will be done by the infrastructure.
        /// Thus, do not use the setter.
        /// </summary>
        BuildProject Project { get; set; }

        /** <summary> Provides access to the features of this action.
         * Features usually are defined by the project. The project will set this at the actions that it creates
         * to build the task. </summary> */
        FeatureList Features { get; }

        /** <summary> This is a collection of preconditions that have to be achieved before running this project.
         * <c>Preconds </c>  will be used by internal references to determine applicability of a project and to determine,
         * whether the project has to be rebuilt. Refer to <c>Targets </c> . </summary> */
        ICollection<IBuildProduct> GetPrerequisites();

        /** <summary> True iff <c>prereq </c>  is among the GetPrerequisites(). </summary> */
        bool ContainsPrerequisite(IBuildProduct prereq);

        /** <summary> True, if this action is not required to run because all targets are up to date.</summary><remarks>
         * \param validityOfBuildSystem indicates the last change of either this DLL or the assembly defining the project.
         *  So, all action will be repeated (even if rebuild is specified) if the project definition changes or the implementation
         *  of the build system has been enhanced since the final build. This argument will be computed and propagated by
         * the project. </remarks> */
        bool TargetsAreConsistent(DateTime validityOfBuildSystem);

        /** <summary> Priority of this action.
         * May be everything but user-defined. </summary> */
        ActionPriority Priority { get; }

        /** <summary> Returns a collection (typically an array) of relevant parameter types in the BuildConfig.
        * This may be empty or <c>null </c>  if instances of this class do not refer to parameter types. </summary> */
        ICollection<Type> ParameterTypes { get; }

        /** <summary> This returns a collection of those objects that are known to be generated or updated after this has been achieved.
         * This helps internal inferences. This may be <c>null </c>  if this project is not about files and other
         * reusable build targets.
         * 
         * The internal inference will refer to this propertiy in order to determine, which action to run for a specific
         * target. So, only mention targets, that are actually achieved running this action.
         * This collection will also be used to determine, whether this project has to be run again on rebuilding.
         * If the <c>Preconds </c>  have earlier validity than this, then the action will be omitted on rebuilding. </summary> */
        ICollection<IBuildProduct> GetTargets();

        /** <summary> If this action starts an external program via System.Diagnostics.Process, this will be the start info of the program to start.
        * The result is <c>null </c>  if this does not start a program as process. However, even actions that use process info
        * may return <c>null </c> . This information is not mandatory. </summary> */
        System.Diagnostics.ProcessStartInfo GetProgramStartInfo(BuildToolFamilyEnv env);

        /** <summary> This returns <c>null </c>  since useually shell variables are not used by actions. </summary> */
        IDictionary<string, EnvironmentVarInfo> UsedVars { get; }

        ///<summary> Execute the action and report errors, warnings, and other messages.
        ///This will start a build procedure either reusing results of previous builds (rebuild)
        /// or making everything from scratch. So, if the desired mode (refer to BuildConfig) is
        /// rebuild, this simply does nothing if this action already has been executed with the same
        /// prerequisites.
        /// <para>
        /// The build environment will pass an occasionally empty instance of class BuildToolFamilyEnv where this may retrieve or store
        /// information that other tools of the same family have created before or other tools of the same family may use later.
        /// Actions MUST ALSO WORK when started with an empty environment.</para> 
        /// </summary>
        /// <param name="validityOfBuildSystem">indicates the last change of either this DLL or the assembly defining the project.
        /// So, all action will be repeated (even if rebuild is specified) if the project definition changes or the implementation
        /// of the build system has been enhanced since the final build. This argument will be computed and propagated by
        /// the project.</param>
        /// <param name="env">Thsi is an environment that different tools of the same family may use to exchange information.
        /// This store is typically used to save information on configuration files or thinsgs of that kind that will be
        /// shared among all tools of the same family.</param>
        /// <returns>true on success and false on failure, that should however also be reported to the error handler.</returns>
        bool Execute(BuildToolFamilyEnv env, DateTime validityOfBuildSystem);

        /// <summary>
        /// This method will create BOO source code and append this code to the provided text writer.
        /// </summary>
        /// <param name="env">This is an environment that different tools of the same family may use to exchange information.
        /// This store is typically used to save information on configuration files or thinsgs of that kind that will be
        /// shared among all tools of the same family.</param>
        /// <param name="booCode">The code that will actually build something. Each list entry will be a line of code in the resulting
        /// BOO program.</param>
        /// <param name="indention">A string that shall preceed all created lines. </param>
        /// <remarks>Refer to IBuildActionProvider.AppendToBooPreamble() for an example.</remarks>
        /// <exception cref="NotSupportedException">Will be thrown if this feature is not supported.</exception>
        void AppendBooCode(List<string> booCodeLines, string indention, BuildToolFamilyEnv env);

        /// <summary>
        /// This method collects all choice points within this action. Choice points are represented by a name and a
        /// collection of alternatives. 
        /// </summary>
        /// <param name="collectionOfChoicePoints">The collection that will be extended by the choice points
        /// of this action. </param>
        /// <example>
        /// The current implementation provides a choice point for the compilation and linking of C/C++
        /// programs, "CppDevelopmentSystem" of the alternatives "GCC" and "MS VC". Thus, actions on C/C++
        /// compilation will add the following choice point:
        /// <code>
        /// if (!collectionOfChoicePoints.ContainsKey("CppDevelopmentSystem"))
        ///     collectionOfChoicePoints.Add("CppDevelopmentSystem", new List&lt;string&gt;());
        /// collectionOfChoicePoints["CppDevelopmentSystem"].Add("GCC");
        /// collectionOfChoicePoints["CppDevelopmentSystem"].Add("MS VC");
        /// </code>
        /// </example>
        void CollectChoicePoints(IDictionary<string, ICollection<string>> collectionOfChoicePoints);
    }

    /// <summary> Classes of build actions create objects that achieve certain build objects.
    /// Classes of build actions describe actions in term of symbolic targets and prerequisites
    /// as well as required content types and produced content types. These classes enable
    /// the runtime environment to investigate first, which actions are available to achieve
    /// content of a certain type.
    /// </summary>
    /// <remarks>
    /// The runtime will in fact implement a mixed fact/goal-oriented inference for
    /// the achievable goals. First, driven by the declared prerequisites, the runtime
    /// will infer the targets that are in principle achievable. The, for each of these
    /// targets, the runtime will generate a plan containing concrete build actions.
    /// <para> 
    /// Please implement a default constructor, so that the activator is able to create
    /// instances.
    /// </para>
    /// <para>
    /// These classes contain a Create() method that will create the build action for particular
    /// content files. Often, IBuildAction and IBuildActionClass will be implemented by the same class.
    /// </para></remarks>
    public interface IBuildActionProvider
    {
        ICollection<OperatingSystem> ApplicableOSs { get; }

        /// <summary> This returns a description of the used shell variables or a <c>null</c>.
        /// The key is the variable name. The value is a remark. So, the following sample provides
        /// the declaration of using shell variable \c path.
        /// <code>
        /// { "path" :
        ///   "This is a list of the directories containing executables that will be found without "
        ///  +"using the absolute path name. This tool will search these directories for ..."
        /// </code></summary>
        IDictionary<string, EnvironmentVarInfo> UsedVars { get; }

        /// <summary>The name of the action provider. This will be used in messages to the user.
        /// Please use exclusively alpha-numerical characters, the dot '.', or the underscore here.</summary> 
        string Name { get; }

        /** <summary> A name that some tools may share.
         * This will be treated like <c>Name </c>  when processing user input.
         * 
         * Tools belonging to the same family may share informations using the BuildToolFamilyEnv. </summary> */
        string ToolFamily { get; }

        /** <summary> A textual description of this class. </summary> */
        string Description { get; }

        /** <summary> This may be <c>false </c>  if actions of this class are note available (for some reasons that are not related to targets). </summary> */
        bool IsAvailable { get; }

        /** <summary> This returns <c>true </c>  iff the described action is likely to produce the specified target provided that the specified prerequisites are available. </summary> */
        bool MayContentFilePrerequisitesSuffice(ContentType target, ICollection<ContentType> prerequisites);

        /** <summary> Content files that may be created by an action of this kind.
         * This may be <c>null </c>  or empty. </summary> */
        ICollection<ContentType> ContentFileTargets { get; }

        /// <summary> Creates a particular build action achieving the provided targets provided that the specified prerequisites are known.
        /// This shall throw an System.ArgumentException if either targets or prerequisites do are not compatible with the declarations
        /// of this class or this class does not implement an actions providing the specified targets for some other reason.
        /// However, callers shall not rely on this.
        ///
        /// If this action provider is only able to create specific instances of the fiel types as declared in <c>ContentFileTargets </c> ,
        /// this method will return a <c>null </c> . In that case, this provider will be ignored silently.
        ///
        /// The build environment will pass an occasionally empty instance of class BuildToolFamilyEnv where this may retrieve or store
        /// information that other tools of the same family have created before or other tools of the same family may use later.
        /// Actions MUST ALSO WORK when started with an empty environment. </summary> */
        /// <param name="env">An opportunity for actions of the same family to share parameters.</param>
        /// <param name="prerequisites">This is a collection of maybe irrelevant build products that can be used by the action to create the target.</param>
        /// <param name="target">The target that shall be achieved by the action.</param>
        IBuildAction Create(BuildToolFamilyEnv env, IBuildProduct target, ICollection<IBuildProduct> prerequisites);

        #region BOO support
        /// <summary>
        /// This will be called for any action provider before IBuildAction.AppendBooCode() is called.
        /// This provides action providers with the opportunity to import modules and create variables
        /// for global options.
        /// </summary>
        /// <param name="env">Environment containing status that can be shared among tools of the same family.</param>
        /// <param name="importModules">List of modules that shall be imported. Add required modules here. Each module
        /// will be imported exactly once (even if it occurs more than once in the list).</param>
        /// <param name="booDeclarations">Lines of code that will be added to the preamble of the BOO code.
        /// Please note, that each line may only appear once. All subsequent additions of this line of
        /// code will be ignored. These lines shall contain declarations of variables etc.</param>
        /// <param name="booDefinitions">Lines of code that that will be added before the code provided by
        /// the actions to build the system. Typically, this will contain the definition of functions
        /// that are used on building. Lines starting with "import" will only be added once to the final code. </param>
        /// <remarks>A typical use is the import of modules that will be used in the later BOO code that
        /// builds the project. Please take care on possible side effects on the BOO code of other action providers
        /// when declaring BOO variables.
        /// <code>
        /// void AppendToBooPreamble(BuildToolFamilyEnv env, List&lt;string&gt; importModules, List&lt;string&gt; booDeclarations, List&lt;string&gt; booDefinitions)
        /// {
        ///     booDeclarations.Add("# This option refers to tool XY. Supported values are 1, 2, and 3.");
        ///     booDeclarations.Add("# However, this option actually does not have any effect. So you");
        ///     booDeclarations.Add("# may fill in here whatever you like.")
        ///     booDeclarations.Add("uselessOption = 1 # 1, 2, or 3")
        /// 
        ///     importModules.Add("System.Diagnostics");
        ///     booDefinitions.Add("def RunThisSampleTool(targetName as string, sourceName as string):");
        ///     booDefinitions.Add("  p=System.Diagnostics.Start(\"tool.exe\", \"-o \{targetName\} -i \{sourceName\} --option uselessOption\")");
        ///     booDefinitions.Add("  p.WaitforExit()");
        ///     boodefinitions.Add("");
        /// }
        /// </code>
        /// Now, imagine, that the action created by this provider implements the following BOO code creation (cf.
        /// IBuildAction.AppendBooCode()).
        /// <code>
        /// void AppendBooCode(List<string> booCodeLines, BuildToolFamilyEnv env)
        /// {
        ///     booCodeLines.Add(string.Format(\"RunThisSampleTool(\\\"\{0\}\\\", \\\"\{1\}\\\")\", this.Target.FileName, this.Source.FileName));
        /// }
        /// </code>
        /// This will result into the following code. Dots represent fragments that will be inserted by other action providers
        /// and actions. Declarations to be managed by the user of the resulting build program will be placed on top. The implementation
        /// of the build follows below.
        /// <code>
        ///     # This option refers to tool XY. Supported values are 1, 2, and 3.
        ///     # However, this option actually does not have any effect. So you
        ///     # may fill in here whatever you like.
        ///     uselessOption = 1 # 1, 2, or 3
        ///     ...
        ///     booDefinitions.Add("import System.Diagnostics"); // I do not yet trust BOOs builtins
        ///     def RunThisSampleTool(targetName as string, sourceName as string):
        ///       p=System.Diagnostics.Start("tool.exe", "-o {targetName} -i {sourceName} --option uselessOption")
        ///       p.WaitforExit()
        ///     
        ///     ...
        ///     RunThisSampleTool("ATargetFile.obj", "ASourceFile.src")
        /// </code>
        /// </remarks>
        void AppendToBooPreamble(BuildToolFamilyEnv env, List<string> importModules, List<string> booDeclarations, List<string> booDefinitions);
        #endregion
    }
}
