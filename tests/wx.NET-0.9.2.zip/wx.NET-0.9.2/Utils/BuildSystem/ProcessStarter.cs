﻿/** Utility encapsulating start of oricesses using class System.Diagnostic.Process.
 * 
 * \file 
 *
 * Copyright 2010 Harald Meyer auf'm Hofe harald_meyer@users.sourceforge.net
 * 
 * Licensed under the wxWidgtes license, see LICENSE.txt for details.
 * 
 * $Id: ProcessStarter.cs,v 1.2 2010/06/06 09:00:04 harald_meyer Exp $
 */

using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;

/** General utilities referring to System.Diagnostics.Process.
 */
namespace wx.ProcessUtils
{
    public enum MsgType
    {
        Error,
        Warning,
        Message,
    }

    /// <summary>
    /// Event distributing string data.
    /// </summary>
    public class MsgEventArgs : EventArgs
    {
        #region State
        MsgType _type=MsgType.Message;
        string _data;
        #endregion

        #region CTor
        public MsgEventArgs(MsgType type, string data)
        {
            this._data=data;
            this._type=type;
        }
        #endregion

        #region Properties
        /// <summary>
        /// The message type of the string.
        /// </summary>
        public MsgType Type { get { return this._type; } }

        /// <summary>
        /// The included message.
        /// </summary>
        public string Msg { get { return this._data; } }
        #endregion

        public override string ToString()
        {
 	         return string.Format("{0}: {1}", this._type, this._data);
        }
    }

    /// <summary>
    /// Handler or an event distributing strings.
    /// </summary>
    /// <param name="sender">The sender of the event.</param>
    /// <param name="evt">The data of the event.</param>
    public delegate void MsgEventHandler(object sender, MsgEventArgs evt);

    /// <summary>
    /// This is an event stating that the process terminated.
    /// </summary>
    public class ProcessTerminatedEvent : EventArgs
    {
        bool _success;
        internal ProcessTerminatedEvent(bool success)
            : base()
        {
            this._success = success;
        }

        /// <summary>
        /// True iff the process has been successful. If false, an unrecoverable error occured.
        /// </summary>
        public bool Success { get { return this._success; } }
    }

    /// <summary>
    /// This event will be raised if the process refers to a
    /// shell process (instance of System.Diagnostics.Process), e.g. to
    /// state that a process has been started running a build tool like
    /// a compiler.
    /// </summary>
    public class ShellProcessEvent : EventArgs
    {
        #region State
        System.Diagnostics.Process _process;
        bool _cancel = false;
        #endregion

        #region CTor
        internal ShellProcessEvent(System.Diagnostics.Process process)
            : base()
        {
            this._process = process;
        }
        #endregion

        #region Properties
        /// <summary>
        /// The process that has been started.
        /// </summary>
        public System.Diagnostics.Process Process { get { return this._process; } }

        /// <summary>
        /// True iff another handler has requested to cancel (kill) the process.
        /// </summary>
        public bool CancelRequest { get { return this._cancel; } }

        /// <summary>
        /// The start info of the process that has been started.
        /// </summary>
        public System.Diagnostics.ProcessStartInfo StartInfo { get { return this._process.StartInfo; } }
        #endregion

        #region Actions
        /// <summary>
        /// Call this to request a cancellation of this process.
        /// </summary>
        public void RequestCancellation()
        {
            this._cancel = true;
        }
        #endregion
    }

    /// <summary>
    /// Utility encapsulating start of oricesses using class System.Diagnostic.Process.
    /// Under Windows a process can be created using the ctor. However, under Unix this
    /// causes problems - and with MacOS maybe also. This class will use two modes:
    /// With Windows, this class will create a new instance of process and use the log events
    /// to enable external applications to analyse output on the output and error streams.
    /// On non-windows platforms, this will use the static methods for execution and
    /// raise the same events reading the output and error streams.
    /// </summary>
    public class ProcessStarter
    {
        #region Nested Types
        /// <summary>
        /// Defines some opportunities to configure the use of the System.Diagnostics.Process class.
        /// </summary>
        public enum Mode
        {
            /// <summary>
            /// The behaviour of this class will be determined with reference to the System.Environment.OSInfo.Platform
            /// property. Refer to the remarks on the class. This is the  default.
            /// </summary>
            UsePlatformID,

            /// <summary>
            /// Configures this class to use the static start method of the System.Diagnostics.Process class.
            /// </summary>
            UseStaticStart,

            /// <summary>
            /// This will start the process using the instance method System.Diagnostics.Process.Start().
            /// </summary>
            UseInstanceMethodStart,
        }

        public delegate void HandlerProcessRefersToShellProcess(ShellProcessEvent evt);
        public delegate void HandlerProcessTerminated(ProcessTerminatedEvent evt);
        #endregion

        #region State
        static Mode _mode = Mode.UsePlatformID;

        ProcessStartInfo _programToRun;
        MsgEventHandler _outputDataReceived;
        MsgEventHandler _errorDataReceived;
        #endregion

        #region CTor
        /// <summary>
        /// Creates an instance describing the program that shall be startet and providing event handlers
        /// for receiving output and error data.
        /// </summary>
        /// <param name="programToRun">Info to start the program</param>
        /// <param name="dataReceived">Event handler that will be called on receiving output or error data. Please note, that
        /// this might be emulated, i.e. all events will be raised AFTER the process ended. Use <c>null</c> here if
        /// you do not want to use this feature.</param>
        public ProcessStarter(ProcessStartInfo programToRun,
            MsgEventHandler dataReceived)
            : this(programToRun, dataReceived, dataReceived)
        {
        }

        /// <summary>
        /// Creates an instance describing the program that shall be startet and providing event handlers
        /// for receiving output and error data.
        /// </summary>
        /// <param name="programToRun">Info to start the program</param>
        /// <param name="outputDataReceived">Event handler that will be called on receiving output data. Please note, that
        /// this might be emulated, i.e. all events will be raised AFTER the process ended. Use <c>null</c> here if
        /// you do not want to use this feature.</param>
        /// <param name="errorDataReceived">Event handler that will be called on receiving error data. Please note, that
        /// this might be emulated, i.e. all events will be raised AFTER the process ended. Use <c>null</c> here if
        /// you do not want to use this feature.</param>
        public ProcessStarter(ProcessStartInfo programToRun,
            MsgEventHandler outputDataReceived,
            MsgEventHandler errorDataReceived)
        {
            this._programToRun = programToRun;
            this._errorDataReceived = errorDataReceived;
            this._outputDataReceived = outputDataReceived;
        }

        /// <summary>
        /// Creates an instance describing the program that shall be startet and providing event handlers
        /// for receiving output and error data.
        /// </summary>
        /// <param name="programToRun">Info to start the program</param>
        public ProcessStarter(ProcessStartInfo progrmToRun)
            : this(progrmToRun, null, null)
        {
        }
        #endregion

        #region Properties
        /// <summary>
        /// This is the mode that has been configured.
        /// </summary>
        public static Mode ConfiguredMode { get { return _mode; } set { _mode = value; } }

        /// <summary>
        /// This is the mode that will actually be used by the instances.
        /// This equals the configured mode with the exception of Mode.UsePlatformID 
        /// that will be replaced according to the current platform.
        /// </summary>
        public static Mode EffectiveMode
        {
            get
            {
                if (ConfiguredMode == Mode.UsePlatformID)
                {
                    if (wx.Build.BuildConfig.NotWindows)
                    {
                        return Mode.UseStaticStart;
                    }
                    else
                        return Mode.UseInstanceMethodStart;
                }
                else
                    return ConfiguredMode;
            }
        }

        /// <summary>
        /// Description of the program to run.
        /// </summary>
        public System.Diagnostics.ProcessStartInfo StartInfo { get { return this._programToRun; } }
        #endregion

        #region Interface to Build Processes
        /// <summary>
        /// This event will be raised immediately after the build process started a shell process e.g. in
        /// order to run a command tool like a compiler.
        /// </summary>
        public static event HandlerProcessRefersToShellProcess EvtStartedShellProcess;

        /// <summary>
        /// This event will be raised while a shell process runs 
        /// </summary>
        public static event HandlerProcessRefersToShellProcess EvtRunningShellProcess;

        /// <summary>
        /// This will be raised when the build process terminates.
        /// </summary>
        public static event HandlerProcessTerminated EvtProcessTerminated;

        /// <summary>
        /// This will post an event to all handlers registeredat <c>EvtProcessTerminated</c>.
        /// </summary>
        /// <param name="evt">The event that will be posted.</param>
        public static void PostProcessTerminated(ProcessTerminatedEvent evt)
        {
            if (EvtProcessTerminated != null)
                EvtProcessTerminated(evt);
        }

        /// <summary>
        /// This event will be raised after a shell process terminated successfully. 
        /// </summary>
        public static event HandlerProcessRefersToShellProcess EvtFinishedShellProcess;

        /// <summary>
        /// Raises a <c>EvtProcessTerminated</c> iff handlers are defined.
        /// </summary>
        /// <param name="success">Shall be true iff the termianted process has been successful.</param>
        internal static void RaiseProcessTerminated(bool success)
        {
            if (EvtProcessTerminated != null)
            {
                EvtProcessTerminated(new ProcessTerminatedEvent(success));
            }
        }

        /// <summary>
        /// Use this after starting a process when waiting for termination.
        /// This method will raise a <c>EvtStartedShellProcess</c> in order to inform
        /// interested parties and then call System.Diagnostics.Process.WaitForExit().
        /// </summary>
        /// <remarks>
        /// This method will also raise events of type <c>EvtRunningShellProcess</c> in order
        /// to provide user interfaces with an opportunity to cancel the process. Finally, if
        /// the process has not been killed, this method raises an <c>EvtFinishedShellProcess</c>.
        /// </remarks>
        /// <param name="process">Process that this trace shall wait for.</param>
        /// <returns>True if process succeeded (error code 0).</returns>
        public bool WaitForExit(System.Diagnostics.Process process)
        {
            try
            {
                if (EvtStartedShellProcess != null)
                {
                    ShellProcessEvent evt = new ShellProcessEvent(process);
                    EvtStartedShellProcess(evt);
                    if (evt.CancelRequest)
                    {
                        try
                        {
                            if (this._errorDataReceived != null)
                                this._errorDataReceived(this, new MsgEventArgs(MsgType.Warning, "I will kill this process due to user request."));
                            process.Kill();
                        }
                        catch (Exception exc)
                        {
                            if (this._errorDataReceived != null)
                                this._errorDataReceived(this, new MsgEventArgs(MsgType.Error, exc.Message));
                        }
                        return false; // process has been terminated by user => no success
                    }
                }

                if (EvtRunningShellProcess == null)
                    process.WaitForExit();
                else
                {
                    while (!process.HasExited)
                    {
                        System.Threading.Thread.Sleep(500);
                        ShellProcessEvent evt = new ShellProcessEvent(process);
                        EvtRunningShellProcess(evt);
                        if (evt.CancelRequest)
                        {
                            try
                            {
                                process.Kill();
                                if (this._errorDataReceived != null)
                                    this._errorDataReceived(this, new MsgEventArgs(MsgType.Warning,  "I killed this process due to user request."));
                                process.WaitForExit();
                            }
                            catch (Exception exc)
                            {
                                try
                                {
                                    if (this._errorDataReceived != null)
                                        this._errorDataReceived(this, new MsgEventArgs(MsgType.Error, exc.Message));
                                }
                                catch
                                {
                                }
                            }
                            return false; // process has been terminated by user => no success
                        }
                    }
                }
            }
            finally
            {
                if (EvtFinishedShellProcess != null)
                    EvtFinishedShellProcess(new ShellProcessEvent(process));
            }
            return true;
        }
        #endregion

        #region The Start Method
        /// <summary>
        /// This starts the program that has been configured by the start info passed to the ctor and
        /// this will also raise all output events.
        /// </summary>
        /// <returns>Returns the process, that has been used. The result may be null if</returns>
        public System.Diagnostics.Process Start()
        {
            System.Diagnostics.Process process = null;
            if (EffectiveMode == Mode.UseInstanceMethodStart)
            {
                #region Use Instance Method
                process = new System.Diagnostics.Process();
                process.StartInfo = this._programToRun;
                process.StartInfo.ErrorDialog = false;
                process.StartInfo.CreateNoWindow = true;
                process.StartInfo.UseShellExecute = false;
                process.StartInfo.RedirectStandardError = true;
                process.StartInfo.RedirectStandardOutput = true;
                if (this._errorDataReceived != null)
                {
                    process.ErrorDataReceived += delegate(object sender, DataReceivedEventArgs args)
                    {
                        this._errorDataReceived(this, new MsgEventArgs(MsgType.Error, args.Data));
                    };
                }
                if (this._outputDataReceived != null)
                {
                    process.OutputDataReceived += delegate(object sender, DataReceivedEventArgs args)
                    {
                        this._outputDataReceived(this, new MsgEventArgs(MsgType.Message, args.Data));
                    };
                }
                process.Start();
                process.BeginErrorReadLine();
                process.BeginOutputReadLine();
                this.WaitForExit(process);
                #endregion
            }
            else
            {
                this._programToRun.ErrorDialog = false;
                this._programToRun.CreateNoWindow = true;
                this._programToRun.UseShellExecute = false;
                this._programToRun.RedirectStandardError = true;
                this._programToRun.RedirectStandardOutput = true;
                process = Process.Start(this._programToRun);
                System.Threading.AutoResetEvent evtErr=new System.Threading.AutoResetEvent(false);
                System.Threading.AutoResetEvent evtOut=new System.Threading.AutoResetEvent(false);

                System.Threading.ThreadPool.QueueUserWorkItem(new System.Threading.WaitCallback(this.SimulateDataReceivedEvents),
                    new object[] {
                        process.StandardError,
                        MsgType.Error,
                        evtErr
                    });
                System.Threading.ThreadPool.QueueUserWorkItem(new System.Threading.WaitCallback(this.SimulateDataReceivedEvents),
                    new object[] {
                        process.StandardOutput,
                        MsgType.Message,
                        evtOut
                    });
                process.WaitForExit();
                System.Threading.WaitHandle.WaitAny(new System.Threading.WaitHandle[] { evtErr, evtOut });
            }
            return process;
        }

        /// <summary>
        /// Reads data from a stream writer until EOF has been read. Depending on a MsgType argument, this
        /// will raise either an <c>_errorDataReceived</c> or an <c>_outputDataReceived</c> event for
        /// each line. After reaching EOF, this will set a System.Threading.AutoResetEvent received as
        /// argument.
        /// </summary>
        /// <param name="args">An object array containing three objects: [0] is an instance of System.IO.StreamReader
        /// providing a text stream where this method will read from. [1] is a MsgType indicating whether to read
        /// errors or output from the text stream. [2] is an auto reset event that will be used to indicated
        /// that this method terminated.</param>
        void SimulateDataReceivedEvents(object args)
        {
            System.IO.StreamReader text = ((object[]) args)[0] as System.IO.StreamReader;
            MsgType msgType = (MsgType)((object[])args)[1];
            System.Threading.AutoResetEvent ewh = ((object[])args)[2] as System.Threading.AutoResetEvent;
            string line = null;
            do
            {
                line = text.ReadLine();
                if (msgType == MsgType.Error)
                    this._errorDataReceived(this, new MsgEventArgs(msgType, line));
                else
                    this._outputDataReceived(this, new MsgEventArgs(msgType, line));
            }
            while (line != null);
            ewh.Set();
        }
        #endregion
    }
}
