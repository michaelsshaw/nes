/** Build system for wx.NET.
 * 
 * This DLL contains basic implementations to build (compile and link) C/C++ programs,
 * compile .NET assemblies written in C#, sign them, and install them.
 * 
 * \file 
 *
 * Copyright 2009-2010 Harald Meyer auf'm Hofe harald_meyer@users.sourceforge.net
 * 
 * Licensed under the wxWidgets license, see LICENSE.txt for details.
 * 
 * $Id: BuildProjects.cs,v 1.30 2010/06/17 17:53:41 harald_meyer Exp $
 */



using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Text;
using System.IO;

namespace wx.Build
{
    /** <summary>These options control, which projects will be achieved during the build process.
     * Cf. BuildProject.Preference</summary>
     */
    public enum ProjectPreference
    {
        /** <summary>Projects of this kind will be achieved by default.
         * However, they may be deferred by user input.</summary>
         */
        Default,

        /** <summary>Projects of this kind wlll not be built by default but if the user desires this explicitely.</summary>
         */
        Optional,

        /** <summary>Projects of this kind will only be built if required by actions.
         * This projects will even not offered to the user for building.</summary>
         */
        DoNotOffer,
    }

    /// <summary> This class interprets command line options referring to BuildProject.Build.</summary>
    /// <remarks>
    /// <para>
    /// The CTor of this class receives command line options that usually have been passes to \c BuildProject.Build.
    /// The CTor will interpret these options. Options may be the name of tools/build actions or projects or features (represented
    /// by their symbol, cf. FeatureEntry), or you may use one or more of the
    /// options "/help", "/projects", "/targets", "/actions", "/configs", "/features",
    /// "/vars", "/cleanup", "/clearall", "/disable:ACTION", "/disable:PROJECT", "/disable:FEATURE",
    /// "/set:VARNAME=VALUE", "/append:VARNAME=VALUE" or "/config:CONFIGNAME".
    /// </para>
    /// The options "/help", "/projects", "/targets", "/actions", "/configs", "/features", and "/vars" provide info on the contained projects
    /// and actions.
    /// <list type="table">
    /// <listheader><term>Option</term><description>Description</description></listheader>
    /// <item><term>/help</term> <description>displays some text on the available options,</description></item>
    /// <item><term> /projects</term> <description>lists the defined projects,</description></item>
    /// <item><term> /targets</term> <description>lists the targets that may be produced,</description></item>
    /// <item><term> /actions</term> <description>lists the available action providers,</description></item>
    /// <item><term> /configs</term> <description>lists the available configurations,</description></item>
    /// <item><term> /clearall</term> <description>clears all results of previous builds before starting the new build,</description></item>
    /// <item><term> /features</term> <description>lists for each project the available feature and their default value before honouring the options
    ///     referring to explicit enabling or disabling of features,</description></item>
    /// <item><term> /vars</term> <description>lists the used environment variables.</description></item>
    /// <item><term> /set:VARNAME=VALUE</term><description>This will assign VALUE to environment variable VARNAME.</description></item>
    /// <item><term> /append:VARNAME=VALUE</term><description>This will append VALUE to the current value of environment variable VARNAME using a separator applicable to directory lists.
    /// Thsi is quite useful for filling lists of directories or paths with values.</description></item>
    /// <item><term> /log=logfilename</term> <description>will create a log file <tt>logfile.xml</tt>.</description></item>
    /// <item><term> /processStart=VALUE</term> <description>Configures class wx.ProcessUtils.ProcessStarter. Accepted values are
    /// PlatformID, StaticStart, and InstanceMethodStart. Refer to wx.ProcessUtils.ProcessStarter.Mode for a documentation of the
    /// modes.</description></item>
    /// <item><term> /disable:actionOrProject</term> <description>will disable any tool or project similar to <tt>actionOrProject</tt>.</description></item>
    /// <item><term> /prefer:action</term> <description>will prefer similarly named tools or tools of the family of the provided name.</description></item>
    /// <item><term> /prefer:project</term> <description>will prefer the spefied project. If at least one project is preferred, the build product will only conduct preferred projects or their prerequisites.</description></item>
    /// <item><term> -actionOrProject</term> <description>like <tt>/disable:actionOrProject</tt>.</description></item>
    /// <item><term> +actionOrProject</term> <description>like <tt>/prefer:actionOrProject</tt></description></item>
    /// <item><term> actionOrProject</term> <description>like <tt>/prefer:actionOrProject</tt> or <tt>+actionOrProject</tt></description></item>
    /// </list>
    /// <para>
    /// Example: An application to build the wx.NET project (main function <c>wx.Build.BuildProgram.Main</c>) called with
    /// options <tt>wx.NET /disable:wx-c gmcs /disable:csc.exe /append:PATH=C:\MyExeDir /config:Release</tt>.
    /// </para>
    /// <para>
    /// The first option will enable project <tt>wx.NET</tt> and disable all other projects that have not explicitely been enabled.
    /// So, the next option only demonstrates syntax but does not have additional effects. The options specifies that project
    /// <tt>wc-c</tt> shall be disabled. However, this project already is diabled since in contrast to \c wx.NET it is not
    /// explicitely enabled. Please note, that <tt>wx-c</tt> will nevertheless be achieved, since <tt>wx-c</tt> is a prerequisite of <tt>wx.NET</tt>.
    /// So, the build process assumes that this project has to be conducted in order to build <tt>wx.NET</tt>.
    /// </para>
    /// <para>
    /// The next option enables action <tt>gmcs</tt>, the Mono compiler. This action will be preferred according
    /// to user input. The next option disables action \c csc.exe, the Microsoft C# compiler. The compilation will fail
    /// <tt>csc.exe</tt> is the only applicable action to build an assembly. The last option will append "C:\MyExeDir" to the
    /// environment variable \c PATH. Some tools may use environment variables to provide information on paths or modes.
    /// You can ask the build system for information on used environment variables specifying option \c "/vars".
    /// Option <tt>"/help"</tt> will print out a short description of the options. <tt>"/cleanup"</tt> will clean up the project removing
    /// all temporary or intermediate files that are NOT targets of enabled projects or prerequisites of enabled projects.
    /// Option <tt>"/cleanall"</tt> will also remove all targets from the file system except installations.
    /// </para>
    /// <para>
    /// Finally, "/config:Release" will switch the default configuration to configuration named "Release" (refer to BuildConfig.DefaultConfig).
    /// </para>
    /// </remarks>
    /// <example>
    /// The following command line will build wx.NET. Release projects will be compiled for version 0.9.0.1:
    /// <code>
    /// C:\sf\wx.NET\Bin>wx.Net.Build.exe /log=wxbuild.xml /config:Release "wxNetBase=." BUILD_VERSION=0.9.0.1
    /// </code>
    /// </example>
    public class CommandLineOptions : BuildParameters
    {
        #region Nested Types
        /// <summary>
        /// Represents the requested build action.
        /// </summary>
        public enum RequestedActions
        {
            /// <summary>
            /// Build the project.
            /// </summary>
            Build,

            /// <summary>
            /// Create BOO code to build the project.
            /// </summary>
            CreatBooCode,
        }
        #endregion

        #region State
        SortedList<string, string> _preferred = new SortedList<string, string>();
        SortedList<string, string> _disabled = new SortedList<string, string>();

        List<string> _optionsOnVars = new List<string>();
        bool _cleanup = false;
        bool _clearall = false;

        bool _foundErrors = false;

        bool _runBuild = true;

        RequestedActions _requestedAction = RequestedActions.Build;
        /// <summary>
        /// This filename will be used in requested actions prodicing a file.
        /// </summary>
        string _filename = "";

        Dictionary<string, EnvironmentVarInfo> _vars = new Dictionary<string, EnvironmentVarInfo>();

        /// <summary>
        /// The assembly defining the projects.
        /// </summary>
        System.Reflection.Assembly _projectSrc;
        #endregion

        #region Properties
        /// <summary>
        /// The action that has been requested by the command lines.
        /// Teh default action is of course to build the project. However, users might
        /// also request a build program in BOO.
        /// </summary>
        public RequestedActions RequestedAction { get { return this._requestedAction; } }

        /// <summary>
        /// This is the filename if the requested action produces a file.
        /// </summary>
        /// <see cref="RequestedAction"/>
        public string Filename { get { return this._filename; } }

        /// <summary>Lists those projects and actions that are preferred by user input.
        /// This is empty if all defined projects shall be built. If this is non-empty,
        /// the user requested some projects explicitely. Only these and their prerequisites
        /// shall be made.
        /// </summary>
        public ICollection<string> Preferred { get { return this._preferred.Values; } }

        /// <summary>Lists those projects and actions that have been disabled by user input.
        /// </summary>
        public ICollection<string> Disabled
        {
            get { return this._disabled.Values; }
        }

        /// <summary>Use this to find out whether a tool or project is preferred or not.
        /// </summary>
        /// <param name="projectOrAction">Name of a tool family, a tool, or a project.</param>
        /// <returns>True if the action of the provided name is preferred.</returns>
        public bool IsPreferred(string projectOrAction)
        {
            if (projectOrAction == null)
                return false;
            return (this._preferred.ContainsKey(projectOrAction.ToLower())
                    || this._preferred.ContainsKey(projectOrAction.Replace(' ', '_').ToLower()))
                && !this.IsDisabled(projectOrAction);
        }

        /// <returns>True if the action or project of the provided name is disabled.</returns>
        public bool IsDisabled(string projectOrAction)
        {
            if (projectOrAction == null)
                return false;
            return this._disabled.ContainsKey(projectOrAction.ToLower())
                || this._disabled.ContainsKey(projectOrAction.Replace(' ', '_').ToLower());
        }

        /// <summary>This is a list of those options affecting environment variables.
        /// This is only an information since all listed options have already been evaluated
        /// running the CTor.</summary>
        public IList<string> OptionsOnVars { get { return this._optionsOnVars; } }

        /// <summary> True iff the <tt>/cleanup</tt> or the <tt>/clearall</tt> option have been evaluated.
        /// If these options have been specified, they have been conducted on running the CTor
        /// of this instance.</summary>
        public bool CleanUp { get { return this._cleanup; } }

        /** <summary> True iff the /clearall option have been evaluated.
         * If these options have been specified, they have been conducted on running the CTor
         * of this instance. </summary> */
        public bool ClearAll { get { return this._clearall; } }

        /** <summary> True if this found errors on construction.
         * Use this if you want to abort on errors in command arguments.
         * Note, that CTor will add errors to <c>messages </c>  iff this is true. </summary> */
        public bool FoundErrors { get { return this._foundErrors; } }
        #endregion

        #region CTor
        /// <summary> Copy-CTor</summary>
        /// <param name="src">The source that will be copied.</param>
        public CommandLineOptions(CommandLineOptions src)
        {
            foreach (string disabled in src._disabled.Values)
                this._disabled[disabled.ToLower()]=disabled;
            foreach (string preferred in src._preferred.Values)
                this._preferred[preferred.ToLower()]=preferred;
            this._optionsOnVars.AddRange(src._optionsOnVars);
            foreach (EnvironmentVarInfo varInfo in src._vars.Values)
                this._vars.Add(varInfo.Varname, varInfo);
            this._cleanup = src._cleanup;
            this._clearall = src._clearall;
            this._foundErrors = src._foundErrors;
            this._projectSrc = src._projectSrc;
        }

        /// <summary>This will interpret the arguments, set <c>Enabled</c> and <c>Disabled</c> and the environment variables.</summary>
        /// <param name="args">is the string list of arguments / program options.</param>
        /// <param name="projectSrc">is the assembly that defines the projects. Projects defined in this assembly will be listed.
        /// This may be <c>null</c>. In that case, this will refer to dynamically loaded assembles (by XML serialization).</param>
        public CommandLineOptions(System.Reflection.Assembly projectSrc, string[] args)
        {
            this._projectSrc = projectSrc;
            #region set path root
            if (BuildConfig.PathRootVariable != null
                && BuildConfig.PathRootVariable.Length > 0)
            {
                string pathRoot = null;
                string prefix = BuildConfig.PathRootVariable + "=";
                string prefix2 = "/set:" + prefix;
                foreach (string originalArg in args)
                {
                    string arg=originalArg;
                    if (arg.StartsWith("\"") && arg.EndsWith("\""))
                        arg=arg.Substring(1, arg.Length-2);
                    if (arg.StartsWith(prefix))
                        pathRoot = arg.Substring(prefix.Length);
                    else if (arg.StartsWith(prefix2))
                        pathRoot = arg.Substring(prefix2.Length);
                }
                EnvironmentVarInfo info=new EnvironmentVarInfo(BuildConfig.PathRootVariable, "Path root used for all non-rooted path names.", typeof(DirectoryName));
                this._vars[info.Varname] = info;
                if (pathRoot != null)
                    info.SafeSet(pathRoot);
            }
            #endregion
            #region Eval commands without exlpicit reference to projects before the projects will be created.
            // This is to prevent side-effects for instance between the choice of the default configuration and
            // the definition of the projects. Thus, these are cmds that must be executed before
            // all references to the roject definitions.
            List<string> cmdsWithRefToProject=new List<string>();
            foreach (string originalArg in args)
            {
                string arg = originalArg;
                if (arg.StartsWith("\"") && arg.EndsWith("\""))
                    arg = arg.Substring(1, arg.Length - 2);
                string arg2Lower = arg.ToLower();
                if (arg2Lower.Equals("/help") || arg2Lower.Contains("-help") || arg.Contains("?"))
                {
                    this._runBuild = false;
                    this.ShowHelp(BuildConfig.ConfiguredErrorHandler);
                }
                else if (arg2Lower.StartsWith("/log=") || arg2Lower.StartsWith("/log:"))
                {
                    string filename = arg.Substring(5);
                    if (!filename.EndsWith(".xml", StringComparison.InvariantCultureIgnoreCase))
                        filename += ".xml";
                    if (BuildConfig.PathRoot != null)
                        filename = System.IO.Path.Combine(BuildConfig.PathRoot, filename);
                    BuildConfig.XmlLogFileName = filename;
                }
                else if (arg2Lower.StartsWith("/processstart="))
                {
                    string option = arg.Substring(14);
                    option = "Use" + option;
                    try
                    {
                        ProcessUtils.ProcessStarter.ConfiguredMode = (ProcessUtils.ProcessStarter.Mode)Enum.Parse(typeof(ProcessUtils.ProcessStarter.Mode), option);
                    }
                    catch
                    {
                        BuildConfig.HandleErrorObject(new ErrorObject(ErrorObject.MessageType.Warning, "Cannot parse {0}. This option will be ignored.", arg));
                    }
                }
                else if (arg2Lower.Equals("/actions"))
                {
                    this._runBuild = false;
                    BuildConfig.HandleErrorObject(new ErrorObject(ErrorObject.MessageType.Message, "/actions"));
                    int i = 0;
                    foreach (IBuildActionProvider ac in BuildConfig.AllActionProviders)
                    {
                        BuildConfig.HandleErrorObject(new ErrorObject(ErrorObject.MessageType.Message, " {1}/{2} {3}", i, ac.Name, ac.ToolFamily, ac.Description));
                        ++i;
                    }
                }
                else if (arg2Lower.Equals("/configs"))
                {
                    this._runBuild = false;
                    foreach (string configName in BuildConfig.KnownConfigs)
                    {
                        BuildConfig.HandleErrorObject(new ErrorObject(ErrorObject.MessageType.Message, "Configuration {0}", configName));
                    }
                    BuildConfig.HandleMessageObject("Default configuration is {0}.", BuildConfig.DefaultConfig);
                }
                else if (arg2Lower.StartsWith("/config:"))
                {
                    string desiredConfigName = arg.Substring(8).Trim();
                    if (BuildConfig.KnowConfig(desiredConfigName))
                        BuildConfig.DefaultConfig = desiredConfigName;
                    else
                    {
                        BuildConfig.HandleErrorObject(new ErrorObject(ErrorObject.MessageType.Error, "I do not know configuration \"{0}\".", desiredConfigName));
                        this._foundErrors = true;
                        this._runBuild = false;
                    }
                }
                else if (arg2Lower.StartsWith("/boo:") || arg2Lower.StartsWith("/boo="))
                {
                    this._filename = arg.Substring(5).Trim();
                    this._requestedAction = RequestedActions.CreatBooCode;
                }
                else
                    cmdsWithRefToProject.Add(arg);
            }
            #endregion
            if (cmdsWithRefToProject.Count > 0)
            {
            #region set environment variables
            foreach (IBuildActionProvider ac in BuildConfig.AllActionProviders)
            {
                IDictionary<string, EnvironmentVarInfo> usedVars=ac.UsedVars;
                if (usedVars != null)
                {
                    foreach (EnvironmentVarInfo info in usedVars.Values)
                        this._vars[info.Varname] = info;
                }
            }
            List<ErrorObject> errorObjects=new List<ErrorObject>();
            ICollection<BuildProject> allProjects = BuildProject.GetAllProjectsDeclaredInAssembly(projectSrc, errorObjects);
            foreach(ErrorObject error in errorObjects)
            {
                if (error.Type == ErrorObject.MessageType.Error)
                   this._foundErrors=true;
            }
            foreach (BuildProject p in allProjects)
            {
                IDictionary<string, EnvironmentVarInfo> usedVars = p.UsedVars;
                if (usedVars != null)
                {
                    foreach (EnvironmentVarInfo info in usedVars.Values)
                        this._vars[info.Varname] = info;
                }
            }
            #endregion

            #region Execute cmds with reference to projects or variables
            foreach (string arg in cmdsWithRefToProject)
            {
                string arg2Lower = arg.ToLower();
                if (arg2Lower.Equals("/projects"))
                {
                    this._runBuild = false;
                    BuildConfig.HandleErrorObject(new ErrorObject(ErrorObject.MessageType.Message, "/projects in {0}", projectSrc));
                    int i = 0;
                    foreach (BuildProject project in allProjects)
                    {
                        BuildConfig.HandleErrorObject(new ErrorObject(ErrorObject.MessageType.Message, "{0}: Project {1}", i, project.Name));
                        ++i;
                    }
                }
                else if (arg2Lower.Equals("/targets"))
                {
                    this._runBuild = false;
                    BuildConfig.HandleErrorObject(new ErrorObject(ErrorObject.MessageType.Message, "/targets in {0}", projectSrc));
                    int i = 0;
                    foreach (BuildProject project in allProjects)
                    {
                        BuildConfig.HandleErrorObject(new ErrorObject(ErrorObject.MessageType.Message, "Project {0}", project.Name));
                        foreach (IBuildProduct target in project.GetTargets())
                        {
                            if (target is ContentFile)
                            {
                                ContentFile file = target as ContentFile;
                                BuildConfig.HandleErrorObject(new ErrorObject(ErrorObject.MessageType.Message, " File {1} {2]", i, file.FileName, file.Type));
                                ++i;
                            }
                        }
                    }
                }
                else if (arg2Lower.Equals("/features"))
                {
                    this._runBuild = false;
                    BuildConfig.HandleErrorObject(new ErrorObject(ErrorObject.MessageType.Message, "/features in {0}", projectSrc));
                    int i = 0;
                    foreach (BuildProject project in allProjects)
                    {
                        BuildConfig.HandleErrorObject(new ErrorObject(ErrorObject.MessageType.Message, "Project {1}", i, project.Name));
                        foreach (KeyValuePair<FeatureEntry, bool> feature in project.Features)
                        {
                            BuildConfig.HandleErrorObject(new ErrorObject(ErrorObject.MessageType.Message, " Feature {1} ({2}): {4} ({3})", i, feature.Key.Symbol, feature.Key.Displayname, feature.Key.Description, feature.Value));
                            ++i;
                        }
                    }
                }
                else if (arg2Lower.Equals("/vars"))
                {
                    this._runBuild = false;
                    // request for all projects in order to ensure that all messages on file path normalization
                    // have been printed.
                    foreach (IBuildActionProvider ac in BuildConfig.AllActionProviders)
                    {
                        IDictionary<string, wx.Build.EnvironmentVarInfo> usedVars=ac.UsedVars;
                        if (usedVars != null && usedVars.Count > 0)
                        {
                            BuildConfig.HandleErrorObject(new ErrorObject(ErrorObject.MessageType.Message, "Action provider {0}", ac.Name, ac));
                            foreach (EnvironmentVarInfo varInfo in ac.UsedVars.Values)
                                BuildConfig.HandleErrorObject(new ErrorObject(ErrorObject.MessageType.Message, varInfo.ToString(), varInfo));
                        }
                    }
                    foreach (BuildProject p in allProjects)
                    {
                        IDictionary<string, wx.Build.EnvironmentVarInfo> usedVars=p.UsedVars;
                        if (usedVars != null && usedVars.Count > 0)
                        {
                            BuildConfig.HandleErrorObject(new ErrorObject(ErrorObject.MessageType.Message, "Project {0}", p.Name, p));
                            foreach (EnvironmentVarInfo varInfo in p.UsedVars.Values)
                                BuildConfig.HandleErrorObject(new ErrorObject(ErrorObject.MessageType.Message, varInfo.ToString(), varInfo));
                        }
                    }
                }
                else if (arg2Lower.Equals("/cleanup") || arg2Lower.Equals("/clearall"))
                {
                    TempFilesParameters tmp = (TempFilesParameters)BuildConfig.GetDefaultParameterOfType(typeof(TempFilesParameters));
                    if (Directory.Exists(tmp.GetDirectory()))
                    {
                        foreach (string file in Directory.GetFiles(tmp.GetDirectory()))
                            File.Delete(file);
                    }
                    this._cleanup = true;

                    if (arg.Equals("/cleanall"))
                    {
                        this._clearall = true;
                        foreach (BuildProject project in allProjects)
                        {
                            foreach (IBuildProduct target in project.GetTargets())
                            {
                                if (target is IFileProducts)
                                {
                                    foreach (ContentFile filedesignator in ((IFileProducts)target).Files)
                                        if (File.Exists(filedesignator.FileName))
                                            File.Delete(filedesignator.FileName);
                                }
                            }
                        }
                    }
                }
                else if (arg2Lower.StartsWith("/set:"))
                {
                    string varname = arg.Substring(5).Trim();
                    int index = varname.IndexOf('=');
                    if (index <= 0)
                    {
                        this._foundErrors = true;
                        BuildConfig.HandleErrorObject(new ErrorObject(ErrorObject.MessageType.Error, "Expected assignment of a variable in {0}.", arg));
                    }
                    else
                    {
                        string valueString = varname.Substring(index + 1);
                        varname = varname.Substring(0, index);
                        if (this._vars.ContainsKey(varname))
                        {
                            EnvironmentVarInfo varInfo = this._vars[varname];
                            varInfo.SafeSet(valueString);
                        }
                        else
                        {
                            this._foundErrors = true;
                            BuildConfig.HandleErrorObject(new ErrorObject(ErrorObject.MessageType.Error, "Unknown variable {0}. Cannot assign value {1} to an unknown variable.", varname, valueString));
                        }
                    }
                }
                else if (arg2Lower.StartsWith("/append:"))
                {
                    string varname = arg.Substring(8).Trim();
                    int index = varname.IndexOf('=');
                    if (index <= 0)
                    {
                        this._foundErrors = true;
                        BuildConfig.HandleErrorObject(new ErrorObject(ErrorObject.MessageType.Error, "Expected assignment of a variable in {0}.", arg));
                    }
                    else
                    {
                        string valueString = varname.Substring(index + 1);
                        varname = varname.Substring(0, index);
                        if (this._vars.ContainsKey(varname))
                        {
                            EnvironmentVarInfo varInfo = this._vars[varname];
                            varInfo.Append(valueString);
                        }
                        else
                        {
                            this._foundErrors = true;
                            BuildConfig.HandleErrorObject(new ErrorObject(ErrorObject.MessageType.Error, "Unknown variable {0}.", varname));
                        }
                    }
                }
                else if (arg2Lower.StartsWith("/disable:"))
                {
                    string projectOrAction = arg.Substring(9).Trim();
                    this._disabled[projectOrAction.ToLower()] = projectOrAction;
                }
                else if (arg.StartsWith("-"))
                {
                    string projectOrAction = arg.Substring(1).Trim();
                    this._disabled[projectOrAction.ToLower()] = projectOrAction;
                }
                else if (arg.StartsWith("+"))
                {
                    string projectOrAction = arg.Substring(1).Trim();
                    this._preferred[projectOrAction.ToLower()] = projectOrAction;
                }
                else if (arg2Lower.StartsWith("/prefer:"))
                {
                    string projectOrAction = arg.Substring(8).Trim();
                    this._preferred[projectOrAction.ToLower()] = projectOrAction;
                }
                else if (arg.Contains("="))
                {
                    string varname = arg;
                    int index = varname.IndexOf('=');
                    if (index <= 0)
                    {
                        this._foundErrors = true;
                        BuildConfig.HandleErrorObject(new ErrorObject(ErrorObject.MessageType.Error, "Expected assignment of a variable in {0}.", arg));
                    }
                    else
                    {
                        string valueString = varname.Substring(index + 1);
                        varname = varname.Substring(0, index);
                        if (this._vars.ContainsKey(varname))
                        {
                            EnvironmentVarInfo varInfo = this._vars[varname];
                            varInfo.SafeSet(valueString);
                        }
                        else
                        {
                            this._foundErrors = true;
                            BuildConfig.HandleErrorObject(new ErrorObject(ErrorObject.MessageType.Error, "Unknown variable {0}.", varname));
                        }
                    }
                }
                else
                {
                    if (arg.StartsWith("/") || arg.Contains(":"))
                        BuildConfig.HandleErrorObject(new ErrorObject(ErrorObject.MessageType.Error, "I strongly suspect that you mispelled option \"{0}\".", arg));
                    else
                        this._preferred[arg.ToLower()] = arg;
                }
            }
            #endregion
            }
        }
        #endregion

        #region Actions
        /// <summary>
        /// Displays information on the available options on the provided destination.
        /// </summary>
        /// <param name="messages">Thsi is where the info shall be displayed.</param>
        public void ShowHelp(ErrorHandler messages)
        {
            messages(new ErrorObject(ErrorObject.MessageType.Message,
                "Synopsis: BUILD_PRG OPTIONS+\n"
                + "where options may be the name of tools/build actions or projects, or you may use one\n"
                + "or more of the options \"/help\", \"/vars\", \"/cleanup\", \"/cleanall\", \"/disable:ACTION\",\n"
                + "\"/projects\", \"/disable:PROJECT\", \"/set:VARNAME=VALUE\", \"/append:VARNAME=VALUE\",\n"
                + "\"/actions\", or \"/targets\"\n"
                + "/help will print out this string.\n"
                + "/boo:BOOFILE will cause the program to create BOO code to build the project instead of building it.\n"
                + "/log:LOGFILE will cause this program to log information in XML syntax in file LOGFILE.\n"
                + "/projects will print out the list of projects that can be built by this program.\n"
                + "/configs will list all available build configurations.\n"
                + "Use /config:CONFIGURATION_NAME to specify the configuration that hall be used.\n"
                + "/features will list for each project the available features and their default values\n"
                + "  before the application of options on features.\n"
                + "/targets lists the defined targets that may be produced.\n"
                + "/actions lists the known action providers.\n"
                + "/vars will print out a report on the environment variables that may be used by the available\n"
                + "  actions. These two options will exit the build program without any trial to build the projects.\n"
                + "/cleanup will clean up all intermediate files after building.\n"
                + "/cleanall will clean up all intermediate files AND TARGETS of build projects before achieving\n"
                + "  the specified targets. Use this to ensure proper rebuilds neglecting all previously achieved targets.\n"
                + "You may \"/disable\" projects and actions using option /disable:.\n"
                + "Mentioned project or actions without any prefix or suffix will select / prefer using or building of\n"
                + "these.\n"
                + "\"/set:\" and \"append:\" will modify environment variables. Use this is actions receive some\n"
                + "parameters from environment variables.\n"
                + "/targets will print out the targets that built be done and the projects that define these targets.\n"
                + "Paths will be interpreted w.r.t. \"{0}\"."
                + ((BuildConfig.PathRootVariable != null && BuildConfig.PathRootVariable.Length > 0)
                   ? " The root path is defined by environment variable \"{1}\"."
                   : "")
                , BuildConfig.PathRoot, BuildConfig.PathRootVariable));
        }

        /// <summary>
        /// Use this to return the list of the projects that shall be built according to user requests.
        /// This implements the semantic of preference and disabling of projects. If we have preferred projects,
        /// only these projects and their prerequisites (that may be missing in the result) shall be built.
        /// Otherwise, all non-disabled projects shall be made.
        /// </summary>
        /// <param name="errors">This method will add encountered errors to this argument if it is not <c>null</c>. </param>
        /// <returns>The collections of projects that shall be built according to user requests. Prerequisites
        /// of listed projects may be missing.
        /// </returns>
        public ICollection<BuildProject> GetRequestedProjects(ICollection<ErrorObject> errors)
        {
            if (this._runBuild)
            {
                ICollection<BuildProject> allProjects = BuildProject.GetAllProjectsDeclaredInAssembly(this._projectSrc, errors);
                if (this._disabled.Count == 0 && this._preferred.Count == 0)
                    return allProjects;
                List<BuildProject> nonDisabled = new List<BuildProject>();
                List<BuildProject> preferred = new List<BuildProject>();
                foreach (BuildProject p in allProjects)
                {
                    if (IsPreferred(p.Name))
                        preferred.Add(p);
                    if (!IsDisabled(p.Name))
                        nonDisabled.Add(p);
                }
                if (preferred.Count > 0)
                    return preferred;
                else
                    return nonDisabled;
            }
            else
                return new BuildProject[] { };
        }
        #endregion

        public override BuildParameters Clone()
        {
             return new CommandLineOptions(this);
        }
    }

    /// <summary>
    /// This interface will be implemented by those classes that will generally not be serialized with full data but as a reference to the full data.
    /// These classes are serializable but need an additional pair of methods to seriailze/deserialize their full data.
    /// 
    /// Typically, Xml-file creators will use these additional pair of methods to serialize/deserialize a collection of relevant
    /// instances first. Then, all references to these full data will be serialized/deserialized as a reference to one of
    /// these instances.
    /// 
    /// The classes implementing this interface are responsible to provide the means that the deserialization needs to find the
    /// full data related to a reference from XML.
    /// </summary>
    /// <seealso cref="RefDataSerializazer"/>
    public interface IXmlRefData : System.Xml.Serialization.IXmlSerializable
    {
        /// <summary>
        /// Write full data serialization to the provided writer.
        /// </summary>
        /// <param name="writer">The destination of the serialization.</param>
        void WriteDataXml(System.Xml.XmlWriter writer);

        /// <summary>
        /// Read full data from the serialization.
        /// </summary>
        /// <param name="reader"></param>
        void ReadDataXml(System.Xml.XmlReader reader);
    }

    /// <summary>
    /// A wrapper of an instance implementing IXmlRefData that serializes the full data instead of the reference.
    /// </summary>
    public class RefDataSerializazer : System.Xml.Serialization.IXmlSerializable
    {
        #region State
        IXmlRefData _data = null;
        #endregion
        /// <summary>
        /// Creates an instance serializing all properties of the argument.
        /// </summary>
        /// <param name="data"></param>
        public RefDataSerializazer(IXmlRefData data)
        {
            this._data = data;
        }

        /// <summary>
        /// Creates an instance with empty data. Use this to create an instanc e before
        /// using ReadXml().
        /// </summary>
        public RefDataSerializazer()
        {
        }

        /// <summary>
        /// The wrapped data.
        /// </summary>
        public IXmlRefData Data { get { return this._data; } }

        #region IXmlSerializable Member
        /// <summary>
        /// Returns <c>null</c>.
        /// </summary>
        public System.Xml.Schema.XmlSchema GetSchema()
        {
            return null;
        }

        /// <summary>
        /// This will read a full serialization of a IXmlRefData encaspulated into an "instance" 
        /// element providing assembly and type if the serialized data.
        /// This will read data as serialized by WriteXml().
        /// </summary>
        /// <param name="reader"></param>
        public void ReadXml(System.Xml.XmlReader reader)
        {
            if (reader.IsStartElement("instance"))
            {
                string assemblyName = reader.GetAttribute("assembly");
                string typeName = reader.GetAttribute("type");
                reader.Read();
                System.Reflection.Assembly assembly = typeof(Build.BuildProject).Assembly;
                if (assemblyName != null)
                    assembly = System.Reflection.Assembly.Load(assemblyName);
                Type t = assembly.GetType(typeName);
                this._data = (IXmlRefData) Activator.CreateInstance(t);
                this._data.ReadDataXml(reader);
                reader.ReadEndElement();
            }
            else
                reader.ReadStartElement("instance"); // this will produce an exception.
        }

        /// <summary>
        /// This will write an "instance" element including attributes for "assembly" and "type".
        /// This element will embed a full serialization of the contained IXmlRefData.
        /// </summary>
        /// <param name="writer">The destination of the serialization.</param>
        public void WriteXml(System.Xml.XmlWriter writer)
        {
            writer.WriteStartElement("instance");
            if (this._data.GetType().Assembly != typeof(Build.BuildProject).Assembly)
            {
                writer.WriteAttributeString("assembly", this._data.GetType().Assembly.FullName);
            }
            writer.WriteAttributeString("type", this._data.GetType().FullName);
            this._data.WriteDataXml(writer);
            writer.WriteEndElement();
        }

        #endregion
    }

    /** <summary> This is the base class of all build targets which form a project.</summary><remarks>
      
     Projects will be stored in a static DB of all projects. They cannot be removed.
     Projects will be identified by their name.
     
     Projects shall be defined in static methods of the core assembly e.g. like the following:
     \code
        public static wx.Build.Net.CSharpAssemblyProject WxNetProject
        {
            get
            {
                Net.CSharpAssemblyProject wxNetProject = new wx.Build.Net.CSharpAssemblyProject(ProjectPreference.Default,
                    "wx.NET",
                    "wx.NET.dll", "The managed part of the wx.NET implementation.");
                wxNetProject.CSharpSources = new FileSelector(ContentType.CSharpCode, "..\\Src\\wx.NET", "*.cs", "wx.NET C# source files.");
                wxNetProject.ReferencesAssemblies = new ContentFiles(ContentType.DotNetDll, ContentFileLocation.GlobalAssemblyCache,
                    "System.dll", "System.Drawing.dll", "System.Xml.dll");
                wxNetProject.Signature = new ContentFile(ContentType.SnKeys, "..\\Src\\wx.NET\\keys.snk");

                wxNetProject.Features.Add(new FeatureEntry("Styled Text Control", "Enables namespace wx.StyledText", "WXNET_STYLEDTEXTCTRL"), true);
                wxNetProject.Features.Add(new FeatureEntry("Display Access", "Enables class wx.Display", "WXNET_DISPLAY"), true);

                return wxNetProject.GetSingleton();
            }
        }
     \endcode
     A subsequent call to BuildProject.Build() will start the building of all projects that have been defined in static properties
     of type BuildProject.

     Please also note, that projects may have a strong relation to the build configuration (refer to class BuildConfig). Many
     projects require certain options to be enabled or disabled. Additionally, projects often share certain configuration.
     All project relying to configurations from a particular subclass of BuildParameters refer to the same instance of this class,
     since the build configuration is a singleton. This is to ensure that all options are used in a consistent manner. So, for instance,
     all project using a C++ compiler will use the same options referring to exception handling, packing structures and all those
     definitions that often produce link error if applied inconsistently.
     
     Immediately before starting the build process (calling BuildProject.Execute()) the build system will ask all project
     with BuildProject.AdoptConfig() to change the parameters in order to fit the own needs.

     Instance of BuildProject are te core of the build system. They are used to define the desired build targets and
     their implementations of method BuildProject.CreateActionPlan()
     produce the action plans that are actually used to create the build targets. </remarks>
     */
    public abstract class BuildProject : BaseAction, IComparable, System.Xml.Serialization.IXmlSerializable, ICloneable
    {
        #region State
        string _name;
        /// <summary>
        /// Guid of the project. Will be created if required.
        /// Do not use like an attribute in CompareTo, Equals, and GetHashCode.
        /// </summary>
        Guid _guid=Guid.Empty;
        ProjectPreference _preference;
        DateTime _validityOfDefiningAssemblies = DateTime.MinValue;
        FeatureList _features = new FeatureList();
        #endregion

        #region XML serialization support
        /// <summary>
        /// Helper for XML serialization of projects.
        /// This will use System.Xml.XmlWriter.WriteAttributeString to write the attributes "name" and "preference".
        /// Call this immediately after starting the root element of the serialized project. 
        /// </summary>
        /// <param name="writer">Destination</param>
        protected void WriteStdAttributes(System.Xml.XmlWriter writer)
        {
            writer.WriteAttributeString("name", this.Name);
            writer.WriteAttributeString("id", this.GetGuid().ToString());
            writer.WriteAttributeString("preference", this.Preference.ToString());
        }

        /// <summary>
        /// Helper for XML serialization of projects. Call this immediately after reading the root
        /// element of a serialized project to read the attributes stored by WriteStdAttributes().
        /// </summary>
        /// <param name="reader">The source where to read the serialization from.</param>
        protected void ReadStdAttributes(System.Xml.XmlReader reader)
        {
            this._name = reader.GetAttribute("name");
            this._guid = new Guid(reader.GetAttribute("id"));
            this._preference = (ProjectPreference)Enum.Parse(typeof(ProjectPreference), reader.GetAttribute("preference"));
        }
        #endregion

        #region Members like in BuildAction
        /** <summary> Projects always have a name.
         * This name will be used in dialogs or menus to explain available targets. </summary> */
        public string Name { get { return this._name; } }

        /// <summary>
        /// This is the Name but only consisting of letters, digits, and the underscore. Blancs will be replaced
        /// by underscores.
        /// </summary>
        public string NameAsSymbol
        {
            get
            {
                return StringAsSymbol(this.Name);
            }
        }

        /// <summary>
        /// Returns a version of the argument that may serve as a C/C++ or C# symbol.
        /// </summary>
        /// <param name="aName"></param>
        /// <returns></returns>
        public static string StringAsSymbol(string aName)
        {
            StringBuilder sb = new StringBuilder();
            if (aName.Length == 0 || Char.IsDigit(aName[0]))
                sb.Append("_");
            foreach (char c in aName)
            {
                if (c == '�')
                    sb.Append("ue");
                else if (c == '�')
                    sb.Append("Ue");
                else if (c == '�')
                    sb.Append("ae");
                else if (c == '�')
                    sb.Append("Ae");
                else if (c == '�')
                    sb.Append("oe");
                else if (c == '�')
                    sb.Append("Oe");
                else if (c == '�')
                    sb.Append("ss");
                else if (Char.IsLetterOrDigit(c) && ((int)c) < 128)
                    sb.Append(c);
                else if (c == ' ' || Char.IsPunctuation(c))
                    sb.Append("_");
            }
            return sb.ToString();
        }

        /// <summary>
        /// A unique identifier of the project.
        /// This will be used on serialization/deserialization to identify the project.
        /// This ID will be set on serialization. Not yet serialized projects will return an empty Guid.
        /// </summary>
        /// <seealso cref="GetGuild"/>
        public Guid Id { get { return this._guid; } }

        /// <summary>
        /// This stores the projects that have been created in order to provide a unique Guid to any project
        /// definition. This will be used to create unique IDs.
        /// </summary>
        static Dictionary<BuildProject, Guid> _projectGuids = new Dictionary<BuildProject, Guid>();

        /// <summary>
        /// This will return the <c>Id</c> but create one if not yet known.
        /// </summary>
        /// <see cref="Id"/>
        public Guid GetGuid()
        {
            if (this._guid.Equals(Guid.Empty))
            {
                if (_projectGuids.ContainsKey(this))
                    this._guid = _projectGuids[this];
                else
                {
                    this._guid = Guid.NewGuid();
                    _projectGuids[this] = this._guid;
                }
            }
            return this._guid;
        }

        /** <summary> Projects always have a descriptive text.
         * This description will be used in dialogs or menus to explain available targets. </summary> */
        public abstract string Description { get; }

        /** <summary> Returns the preference of this project.
         * This controls whether the targets of this project will be achieved or not. Some
         * projects will be accomplished only on user input. Some project may be hidden to the
         * end user since they will be achieved only during the build process if reuiqred by
         * other projects or actions. </summary> */
        public ProjectPreference Preference { get { return this._preference; } }

        /** <summary> For internal use only: Change the project's preference (e.g. to react on user input). </summary> */
        internal void SetPreference(ProjectPreference preference) { this._preference = preference; }

        /** <summary> Validity of the assemblies defining the project and implementing execution.
        * The assemblies defining the project and implementing tools and projects are standard
        * prerequisites of the target. Whenever we change one of these assemblies, we want all
        * targets to be rebuilt. This property returns a timestamp representing the validity
        * of these prerequisites. </summary> */
        public DateTime ValidityOfDefiningAssemblies
        {
            get { return this._validityOfDefiningAssemblies; }
        }

        static DateTime GetValidityOfAssembly(System.Reflection.Assembly assembly)
        {
            DateTime result = DateTime.MinValue;
#if ! DEBUG
            System.Uri uriOfAssembly = new Uri( assembly.CodeBase );
            if (uriOfAssembly.IsFile)
            {
                string filename=uriOfAssembly.LocalPath;
                if (System.IO.File.Exists(filename))
                    result = System.IO.File.GetLastWriteTime(filename);
            }
#endif
            return result;
        }

        static DateTime _validityOfExecutingAssembly=DateTime.MinValue;
        /** <summary> The validity (timestamp) of the assembly file containing this code (if this exists). </summary> */
        public static DateTime ValidityOfExecutingAssembly
        {
            get
            {
                if (_validityOfExecutingAssembly==DateTime.MinValue)
                {
                   // _validityOfExecutingAssembly = GetValidityOfAssembly(System.Reflection.Assembly.GetExecutingAssembly());
                }
                return _validityOfExecutingAssembly;
            }
        }

        public override DateTime GetValidity()
        {
            DateTime baseValidity = base.GetValidity();
            if (this.ValidityOfDefiningAssemblies > baseValidity)
                return this.ValidityOfDefiningAssemblies;
            else
                return baseValidity;
        }

        public override DateTime GetValidityDemand()
        {
            DateTime baseValidity = base.GetValidityDemand();
            if (this.ValidityOfDefiningAssemblies > baseValidity)
                return this.ValidityOfDefiningAssemblies;
            else
                return baseValidity;
        }

        /// <summary>
        /// The features of the project.
        /// </summary>
        public override FeatureList Features
        {
            get
            {
                return this._features;
            }
        }
        #endregion

        #region Prepare to be solved
        /// <summary>
        /// This is true iff the project can be built. Run GetSingleton() to make this true.
        /// </summary>
        public bool IsSingleton { get { return object.ReferenceEquals(GetKnownProject(this.Id), this); } }

        /// <summary>
        /// This will make the project instance ready to be solved.
        /// The build system will only use one project instance per target.
        /// Thus, projects will be registered. This will try to register this instance.
        /// If the database of registered project already contains a project instance
        /// for the targets of this instance, this will return this instance.
        /// </summary>
        /// <returns></returns>
        public BuildProject GetSingleton()
        {
            Guid guid = RegisterProjectTargets(this);
            if (guid == Guid.Empty || guid == this.Id)
            {
                AddKnownProject(this);
                return this;
            }
            else
            {
                BuildProject oldProject = GetKnownProject(guid);
                if (oldProject == null) // this should not happen
                    throw new Exception(string.Format("Cannot make project {0} ready and I have not found a similar project."));
                return oldProject;
            }
        }
        #endregion

        /// <summary>Creates a plan to achieve the GetTargets().
        /// </summary>
        /// <returns>Return actions to achieve the targets of this projects. The method shall return at most one action
        ///  to achieve the same target. However, a returned action might achieve more than one target. Thus, this returns as most
        /// as many action plans as targets are defined. Each returned plan must be executable independently.
        /// The result is \c null if this encounters errors that shall stop the build process.</returns>
        /// <remarks>
        /// The resulting actions may consist of instances of AlternativeBuildActions or SequenceOfBuildActions that represent
        /// alternative build actions or sequence of actions.
        /// <para>
        /// The result of this method will be considered as a collection of actions that all have to run to build all targets
        /// of the project. However, if this project is optional or hidden, the build process control will consider only those
        /// actions for execution that produce an actually required target.
        /// </para>
        /// <para>
        /// This will start a build procedure either reusing results of previous builds (rebuild)
        /// or making everything from scratch. So, is the desired mode (refer to BuildConfig) is
        /// rebuild, this simply does nothing if this action already has been executed with the same
        /// prerequisites.
        /// </para>
        /// </remarks>
        public abstract ICollection<IBuildAction> CreateActionPlan(BuildToolFamilyEnv env);

        #region CTor
        /** <summary> This will add the project to the DB using the provided name.
         * This will raise an exception, if a project of this name is already known.
         * <param name="preference">Preference of the project - is this mandatory or not. Refer to <c>Preference </c>.</param>
         * <param name="projectName">Refer to <c>Name </c> . The name of the project shall exclusively consist of alpha-numerical characters,
         *  the underscore '_', the dash '-', blanks ' ', '&amp;', '%', or the fullstop character '.'.</param>
         *  <param name="definingAssembly">Is the assembly defining the project. This will be used to compute a validity of the
         *  project definition. This may be <c>null</c>.</param>
         * </summary>
         */
        protected BuildProject(System.Reflection.Assembly definingAssembly, ProjectPreference preference, string projectName)
        {
            if (definingAssembly == null)
                this._validityOfDefiningAssemblies=DateTime.MinValue;
            else
                this._validityOfDefiningAssemblies = GetValidityOfAssembly(definingAssembly);
            if (this._validityOfDefiningAssemblies < ValidityOfExecutingAssembly)
                this._validityOfDefiningAssemblies = ValidityOfExecutingAssembly;
            this._preference=preference;
            this._name = projectName;
            foreach (char c in this._name)
            {
                if (!char.IsLetterOrDigit(c) && c != '.' && c != '_' && c != '-' && c!= ' ' && c!='&' && c != '%')
                    throw new Exception(string.Format("Illegal character {0} in project name {1}.", c, this._name));
            }
            Net.NetCompilerParameters netParams = (Net.NetCompilerParameters)BuildConfig.GetDefaultParameterOfType(typeof(Net.NetCompilerParameters));
            this._features.AddRange(netParams.Features);
        }

        #endregion

        #region Interface To BuildConfig
        /** <summary> Change the provided configuration of necessary in order to produce the targets.
        * \return is <c>true </c>  iff changes have been necessary.
        * This method will be called immediately before executing the project in order to create
        * a fixed point of the configuration. Apply only sparse changes. Returning <c>true </c>  on parameters
        * that have been changed by another project will stop the build process because of inconsistent
        * demands on the configuration.
        *
        * This default implementation will always return <c>false </c> . </summary> */
        public virtual bool AdoptConfig(BuildConfig config)
        {
            return false;
        }

        /// <summary>
        /// You may use this method to control the form of the file name that will be used to
        /// serialize this (the original filename). The argument is a path to an existing
        /// file or directory. This will strip a directory information from this path. After
        /// that, the original file name will change to something equivalent to the absolute
        /// filename (referring to the same file) but now relative to the directory as specified
        /// by the argument.
        /// 
        /// Use this method to prepare content file instance for serialization in such a way
        /// that all file names become relative to the same directory.
        /// </summary>
        /// <param name="nameOfAValidDirOrFile">The name of an existing file or directory. This name
        /// will - if relative - be expanded using the BuildConfig. If this is <c>null</c>, this
        /// method will return without any effect. This may also be the name of a not yet existing file.
        /// In that case, however, the directory name shall exist.</param>
        /// <seealso cref="OriginalFileName"/>
        /// <exception cref="System.ArgumentException">Will be raised if the argument is neither the path
        /// to an existing file nor directory.</exception>
        public virtual void NormalizeOriginalFileName(string nameOfAValidDirOrFile)
        {
            foreach (IBuildProduct p in this.GetPrerequisites())
            {
                if (p is IFileProducts)
                    ((IFileProducts)p).NormalizeOriginalFileName(nameOfAValidDirOrFile);
                else if (p is ResourceDesignator)
                    ((ResourceDesignator)p).ResourceFileProject.NormalizeOriginalFileName(nameOfAValidDirOrFile);
            }
            foreach (IBuildProduct t in this.GetTargets())
                if (t is IFileProducts)
                    ((IFileProducts)t).NormalizeOriginalFileName(nameOfAValidDirOrFile);
        }
        #endregion

        #region Creation Of A RefToProject
        /// <summary>
        /// This returns an instance of RefToProject encapsulating this.
        /// However, projects may return an instance of a more specific class
        /// here if appropriate.
        /// </summary>
        /// <returns></returns>
        public virtual RefToProject CreateRef()
        {
            return new RefToProject(this);
        }
        #endregion

        #region Static DB of Projects
        /** <summary> Adds all build projects from <c>listOfBuildProjects </c>  and their prerequisites to the <c>result </c>  (a set: value equals key). </summary> */
        public static ICollection<BuildProject> AddIncludedProjects(IDictionary<BuildProject, BuildProject> result,
            ICollection<IBuildProduct> listOfBuildProducts)
        {
            SortedDictionary<BuildProject, BuildProject> addedPrereqsForThis = new SortedDictionary<BuildProject, BuildProject>();
            List<IBuildProduct> agenda=new List<IBuildProduct>();
            agenda.AddRange(listOfBuildProducts);
            while (agenda.Count > 0)
            {
                IBuildProduct current = agenda[0];
                agenda.RemoveAt(0);

                if (current is BuildProject)
                {
                    BuildProject currentProject = (BuildProject)current;
                    result[currentProject]=currentProject;
                    if (!addedPrereqsForThis.ContainsKey((BuildProject)current))
                    {
                        addedPrereqsForThis.Add((BuildProject)current, (BuildProject)current);
                        foreach (IBuildProduct prereq in ((BuildProject)current).GetPrerequisites())
                            agenda.Add(prereq);
                    }
                }
                else if (current is FileProducts)
                {
                    foreach (IBuildProduct content in ((FileProducts)current).Contents)
                        agenda.Add(content);
                }
            }
            return result.Values;
        }

        /// At most one project per project type and target.
        static Dictionary<string, Dictionary<IBuildProduct, Guid>> _targetToProject = new Dictionary<string, Dictionary<IBuildProduct, Guid>>();

        /// <summary>
        /// Static factory methods creating projects will use this method to decide whether a new instance
        /// of the project is justified or probably a doublette.
        /// </summary>
        /// <param name="p">The project instance that shall be tested.</param>
        /// <returns>The Guid of a preexisting project producing at least on of p's targets and that is of the same type.
        /// The result will be the GUID of <c>p</c> if <c>p</c> can be used.</returns>
        static protected Guid RegisterProjectTargets(BuildProject p)
        {
            string typeKey = p.GetType().FullName;
            Dictionary<IBuildProduct, Guid> productToProject;
            if (_targetToProject.ContainsKey(typeKey))
            {
                productToProject = _targetToProject[typeKey];
                foreach (IBuildProduct target in p.GetTargets())
                {
                    if (productToProject.ContainsKey(target))
                    {
                        // well, atleast target can be created by another project of the same type.
                        // thus, we will return the GUID of this project. instance p must not be used.
                        return productToProject[target];
                    }
                }
            }
            else
            {
                productToProject = new Dictionary<IBuildProduct, Guid>();
                _targetToProject.Add(typeKey, productToProject);
            }

            foreach (IBuildProduct target in p.GetTargets())
            {
                productToProject[target] = p.GetGuid();
            }
            return p.GetGuid();
        }

        static Dictionary<Guid, BuildProject> _createdProjects = new Dictionary<Guid, BuildProject>();
        /// <summary>
        /// Returns the collection of projects that have been loaded from file.
        /// </summary>
        public static ICollection<BuildProject> GetKnownProjects()
        {
            return _createdProjects.Values;
        }

        /// <summary>
        /// Clear the loaded projects.
        /// </summary>
        public static void ClearKnownProjects()
        {
            _createdProjects.Clear();
            _targetToProject.Clear();
        }


        /// <summary>
        /// Returns the project of the provided ID.
        /// </summary>
        /// <param name="id">The ID of the desired project</param>
        /// <returns>The project of the desired name or <c>null</c> if this project is unknown.</returns>
        public static BuildProject GetKnownProject(Guid id)
        {
            if (_createdProjects.ContainsKey(id))
                return _createdProjects[id];
            else
                return null;
        }

        /// <summary>
        /// This will add the provided project to the collection of known projects.
        /// This method will create a GUID for the added project if not yet known.
        /// </summary>
        /// <param name="p">The project that shall be added.</param>
        public static void AddKnownProject(BuildProject p)
        {
            if (_createdProjects.ContainsKey(p.GetGuid()))
            {
                BuildProject existingP = _createdProjects[p.GetGuid()];
                if (object.ReferenceEquals(p, existingP)
                    || p.Equals(existingP))
                    return;
                throw new Exception(string.Format("Different project instances {0} and {1} but same GUID.", p.Name, existingP.Name));
            }
            Guid equalTargets = RegisterProjectTargets(p);
            if (equalTargets != p.Id)
                throw new Exception(string.Format("Projects {0} and {1} achieve the same target.", p.Name, _createdProjects[equalTargets].Name));
            _createdProjects.Add(p.Id, p);
        }

        /// <summary>
        /// Register this as a loaded project.
        /// The argument is the old Id of this project that it might have had before
        /// reading from a stream or <c>System.Guid.Empty</c> if the project instance
        /// did not have an Id before.
        /// </summary>
        /// <param name="oldGuid">The old Id of this instance or <c>System.Guid.Empty</c> if this did
        /// not have an Id before.</param>
        /// <remarks>
        /// This will remove this project from the collection of loaded projects if it has been
        /// registered before with Id <c>oldGuid</c>.
        /// </remarks>
        protected void SetAsKnownProject(Guid oldGuid)
        {
            if (oldGuid != Guid.Empty)
            {
                if (_createdProjects.Remove(oldGuid) && _targetToProject.ContainsKey(this.GetType().FullName))
                {
                    List<IBuildProduct> targetsToSet = new List<IBuildProduct>();
                    Dictionary<IBuildProduct, Guid> targetToProject = _targetToProject[this.GetType().FullName];
                    foreach (IBuildProduct target in this.GetTargets())
                    {
                        if (targetToProject.ContainsKey(target))
                        {
                            if (targetToProject[target] == oldGuid)
                                targetsToSet.Add(target); // OK, the target has been achieved by the old project that shall be replaced.
                            else
                                throw new Exception(string.Format("Target {0} is already achieved by a project. Cannot add project {1}.", target, this.Name));
                        }
                    }
                    foreach (IBuildProduct target in targetsToSet)
                        targetToProject[target] = this.GetGuid();
                }
            }
            AddKnownProject(this);
        }

        /// <summary> Returns a collection of all projects declared in the provided assembly.
        /// Projects are declared using the attributes BuildProjectAttribute.
        /// </summary>
        /// <param name="assembly">The assembly that contains the project definitions. This method will also accept
        /// <c>null</c>. In that case, this will return the GetLoadedProjects()</param>
        /// <param name="errors">This method will add encountered errors to this argument if it is not <c>null</c>. </param>
        public static ICollection<BuildProject> GetAllProjectsDeclaredInAssembly(System.Reflection.Assembly assembly, ICollection<ErrorObject> errors)
        {
            if (assembly == null)
                return GetKnownProjects();
            IDictionary<BuildProject, BuildProject> result=new Dictionary<BuildProject, BuildProject>();
            object[] buildProjectAttrs=assembly.GetCustomAttributes(typeof(BuildProjectAttribute), false);
            foreach (BuildProjectAttribute attr in buildProjectAttrs)
                result.Add(attr.Project, attr.Project);

            foreach (Type t in assembly.GetTypes())
            {
                if (t.IsClass)
                {
                    foreach (System.Reflection.PropertyInfo pi in t.GetProperties())
                    {
                        try
                        {
                            if (pi.GetGetMethod() != null
                                && pi.GetGetMethod().IsStatic
                                && typeof(BuildProject).IsAssignableFrom(pi.PropertyType))
                            {
                                try
                                {
                                    BuildProject newProject = (BuildProject)pi.GetValue(null, null);
                                    result.Add(newProject, newProject);
                                }
                                catch (System.Reflection.TargetInvocationException exc)
                                {
                                    ErrorObject error=new ErrorObject(ErrorObject.MessageType.Warning, exc.InnerException.Message, exc);
                                    if (errors != null)
                                        errors.Add(error);
                                    BuildConfig.HandleErrorObject(error);
                                }
                                catch (Exception exc)
                                {
                                    ErrorObject error = new ErrorObject(ErrorObject.MessageType.Warning, exc.Message, exc);
                                    if (errors != null)
                                        errors.Add(error);
                                    BuildConfig.HandleErrorObject(error);
                                }
                            }
                        }
                        catch (Exception exc)
                        {
                            if (exc.InnerException != null)
                                exc = exc.InnerException;
                            ErrorObject error = new ErrorObject(ErrorObject.MessageType.Warning, exc.Message);
                            if (errors != null)
                                errors.Add(error);
                            BuildConfig.HandleErrorObject(error);
                        }
                    }
                }
            }

            #region Project that are prerequisites are also projects to be made
            List<IBuildProduct> deps = new List<IBuildProduct>();
            foreach (BuildProject p in result.Values)
                deps.AddRange(p.GetPrerequisites());
            AddIncludedProjects(result, deps);
            #endregion
            return result.Values;
        }

        /// <summary>
        /// Creates a collection of all environment variables that are used either
        /// by project or actions.
        /// </summary>
        /// <param name="projectSrc">An assembly that contains project definitions. This may be null. In that case, 
        /// this will use all loaded problems.</param>
        /// <returns></returns>
        public static ICollection<EnvironmentVarInfo> GetUsedVariables(System.Reflection.Assembly projectSrc)
        {
            SortedList<string, EnvironmentVarInfo> result = new SortedList<string, EnvironmentVarInfo>();
            foreach (IBuildActionProvider ac in BuildConfig.AllActionProviders)
            {
                IDictionary<string, EnvironmentVarInfo> usedVars = ac.UsedVars;
                if (usedVars != null)
                {
                    foreach (EnvironmentVarInfo info in usedVars.Values)
                        result[info.Varname] = info;
                }
            }
            ICollection<BuildProject> allProjects = null;
            if (projectSrc != null)
                allProjects = BuildProject.GetAllProjectsDeclaredInAssembly(projectSrc, null);
            if (allProjects == null)
                allProjects = GetKnownProjects();
            foreach (BuildProject p in allProjects)
            {
                IDictionary<string, EnvironmentVarInfo> usedVars = p.UsedVars;
                if (usedVars != null)
                {
                    foreach (EnvironmentVarInfo info in usedVars.Values)
                        result[info.Varname] = info;
                }
            }
            return result.Values;
        }

        /// <summary>Builds projects regarding the provided options.
        /// Projects will be read from the Assembly.GetCallingAssembly.
        /// Output of errors and warnings on System.Console.</summary>
        /// <param name="programOpts">programOpts may be the name of tools/build actions or projects, or you may use one or more of the
        ///       options "/help", "/vars", "/targets", "/projects", "/clean", "/disable:ACTION", "/disable:PROJECT",
        ///       <tt>/set:VARNAME=VALUE</tt>, or <tt>/append:VARNAME=VALUE</tt>. Refer to class CommandLineOptions.</param>
        /// <returns>0 on success and 1 on failure, that should however also be reported to the error handler.</returns>
        /// <seealso cref="CommandLineOptions"/>
        public static int Build(string[] programOpts)
        {
            ErrorHandler handler = delegate(ErrorObject errObj)
            {
                System.Console.WriteLine(errObj);
            };
            return Build(handler, System.Reflection.Assembly.GetCallingAssembly(), programOpts);
        }

        /// <summary>Builds projects regarding the provided options.
        /// Projects will be read from the \c Assembly.GetCallingAssembly.</summary>
        /// <param name="handler">Output of errors and warnings using this handler.</param>
        /// <param name="programOpts">programOpts may be the name of tools/build actions or projects, or you may use one or more of the
        ///       options "/help", "/vars", "/targets", "/projects", "/clean", "/disable:ACTION", "/disable:PROJECT",
        ///       <tt>/set:VARNAME=VALUE</tt>, or <tt>/append:VARNAME=VALUE</tt>. Refer to class CommandLineOptions.</param>
        /// <returns>0 on success and 1 on failure, that should however also be reported to the error handler.</returns>
        /// <remarks>
        /// Refer to the remarks on class BuildProject for an example of a project definition.
        /// </remarks>
        public static int Build(ErrorHandler handler, string[] programOpts)
        {
            return Build(handler, System.Reflection.Assembly.GetCallingAssembly(), programOpts);
        }

        /// <summary>Put <c>projects</c> in such an order that they occur before all their prerequisites that are also projects.
        /// This will put the project into a certain order that allows later steps of processing to concatenate actions plans.
        /// </summary>
        /// <param name="projects">projects to schedule.</param>
        /// <returns>a list containig all \c projects and their prerequisites or \c null in case that no appropriate order exists.</returns>
        public static IList<BuildProject> ScheduleProjects(ICollection<BuildProject> projects)
        {
            if (projects == null || projects.Count == 0)
            {
                BuildConfig.HandleErrorObject(new ErrorObject(ErrorObject.MessageType.Error, "Cannot schedule empty set of projects."));
                return null;
            }
            
            Dictionary<Guid, BuildProject> notApplicableProjects=new Dictionary<Guid, BuildProject>();
            
            Stack<KeyValuePair<int, BuildProject>> agenda = new Stack<KeyValuePair<int, BuildProject>>();
            foreach (BuildProject projectOrig in projects)
            {
                BuildProject project = projectOrig;
                if (!project.IsSingleton)
                    project = project.GetSingleton();
                if (project.AreAllMandatoryVarsDefined())
                   agenda.Push(new KeyValuePair<int, BuildProject>(0, project));
                else
                {
                   BuildConfig.HandleErrorObject(ErrorObject.MessageType.Warning,
                    "Cannot build project \"{0}\" because some mandatory environment variables are not defined.",
                    project.Name);
                   notApplicableProjects[project.GetGuid()] = project;
                }
            }

            // sorted list of lists of build projects. defines an organisaton of the projects in layers.
            // layer n may depend on layer n+1 but never vice versa.
            SortedList<int, List<BuildProject>> ordering = new SortedList<int, List<BuildProject>>();
            // is the reversed representation of <ordering>. maps index of the layer (value) to the project (key).
            // thus, the count of this container is the number of yet analysed projects.
            // necessary if a project moves downwards in a deeper layer because of newly discovered
            // dependencies.
            Dictionary<BuildProject, int> orderingReversed = new Dictionary<BuildProject, int>();
            while (agenda.Count > 0)
            {
                KeyValuePair<int, BuildProject> current = agenda.Pop();
                if (!ordering.ContainsKey(current.Key))
                {
                    if (current.Key > orderingReversed.Count)
                    {
                        BuildConfig.HandleErrorObject(new ErrorObject(ErrorObject.MessageType.Error, "Circular dependencies of projects involving project {0}", current.Value.Name, current.Value));
                        return null;
                    }
                    else
                        ordering.Add(current.Key, new List<BuildProject>());
                }
                if (orderingReversed.ContainsKey(current.Value))
                {
                    int oldPrio = orderingReversed[current.Value];
                    if (oldPrio >= current.Key)
                        continue;
                    ordering[oldPrio].Remove(current.Value);
                }
                ordering[current.Key].Add(current.Value);
                orderingReversed[current.Value] = current.Key;

                foreach (IBuildProduct obj in current.Value.GetPrerequisites())
                {
                    if (obj is IBuildProduct)
                    {
                        ICollection<RefToProject> subProjects = ((IBuildProduct)obj).GetProjects();
                        if (subProjects != null)
                        {
                            foreach (RefToProject subProject in subProjects)
                            {
                                if (notApplicableProjects.ContainsKey(subProject.Project.GetGuid()))
                                {
                                   // Remove current from agenda because a prerequisite cannot be build.
                                   if (!notApplicableProjects.ContainsKey(current.Value.GetGuid()))
                                   {
                                      notApplicableProjects[current.Value.GetGuid()]=current.Value;
                                      BuildConfig.HandleErrorObject(new ErrorObject(ErrorObject.MessageType.Warning,
                                        "Cannot build {0} because this projects depends on project {1} that cannot be built.",
                                        current.Value.Name, subProject.Project.Name));
                                   }
                                }
                                else
                                   agenda.Push(new KeyValuePair<int, BuildProject>(current.Key + 1, subProject.Project));
                            }
                        }
                    }
                }
            }
            Dictionary<BuildProject, BuildProject> alreadyFound = new Dictionary<BuildProject, BuildProject>();
            List<BuildProject> result = new List<BuildProject>();
            foreach (KeyValuePair<int, List<BuildProject>> prioProjectPair in ordering)
            {
                foreach (BuildProject project in prioProjectPair.Value)
                {
                    if (!alreadyFound.ContainsKey(project))
                    {
                        result.Insert(0, project);
                        alreadyFound[project] = project;
                    }
                }
            }
            return result;
        }

        /// <summary> Builds projects regarding the provided options.</summary>
        /// <param name="handler">will be set as configured error handler in the BuildConfig. Output of errors and warnings via <c>handler </c> .</param>
        /// <param name="programOpts">programOpts may be the name of tools/build actions or projects, or you may use one or more of the
        ///       options "/help", "/vars", "/projects", "/actions", "/clean", "/disable:ACTION", "/disable:PROJECT",
        ///       /set:VARNAME=VALUE, or /append:VARNAME=VALUE. Refer to class CommandLineOptions.</param>
        /// <param name="projectSrc">The assembly containing the project definitions. This may be <c>null</c>.</param>
        /// <returns>0 on success and 1 on failure, that should however also be reported to the error handler.</returns>
        public static int Build(ErrorHandler handler, System.Reflection.Assembly projectSrc, string[] programOpts)
        {
            try
            {
                if (projectSrc != null && handler != null)
                   handler(new ErrorObject(ErrorObject.MessageType.Message, "Start building projects from \"{0}\".", projectSrc.CodeBase));
                if (handler != null && programOpts != null && programOpts.Length > 0)
                {
                   StringBuilder sb=new StringBuilder();
                   foreach(string opt in programOpts)
                   {
                     sb.Append(" ");
                     sb.Append(opt);
                   }
                   handler(new ErrorObject(ErrorObject.MessageType.Message, "Using options \"{0}\".", sb));
                }
                #region Initialize And Complete Configuration
                BuildConfig.ConfiguredErrorHandler = handler;
                CommandLineOptions options = new CommandLineOptions(projectSrc, programOpts);
                if (options.FoundErrors)
                    return 1;

                BuildConfig.HandleMessageObject("Interpreting none-rooted paths relatively to \"{0}\". Assign another root path to environment variable \"{1}\" to change this assumption.",
                  BuildConfig.PathRoot,
                  BuildConfig.PathRootVariable);

                BuildConfig.OpenXmlLogFile();
                BuildConfig.OpenSectionInXmlLogFile("init");
                BuildConfig current = BuildConfig.GetConfig(BuildConfig.DefaultConfig);
                current.AddOrReplace(options);
                if (options.CleanUp || options.ClearAll)
                    current.Mode = BuildMode.BuildNew;
                #endregion

                #region Schedule Projects
                List<ErrorObject> errors = new List<ErrorObject>();
                ICollection<BuildProject> requestedProjects = options.GetRequestedProjects(errors);
                if (requestedProjects == null || requestedProjects.Count == 0)
                    return 0;
                IList<BuildProject> scheduledProjects = ScheduleProjects(requestedProjects);
                if (scheduledProjects == null)
                {
                    return 1;
                }
                {
                    StringBuilder sb = new StringBuilder();
                    sb.AppendLine("Scheduled projects:");
                    int index = 0;
                    foreach (BuildProject p in scheduledProjects)
                    {
                        ++index;
                        sb.AppendFormat("{0}: {1}/ {2}\n", index.ToString(), p.Name, p.Description);
                    }
                }

                BuildConfig.CloseSectionInXmlLogFile();
                #endregion

                #region Adopt Configurations
                BuildConfig.OpenSectionInXmlLogFile("adopt_config");
                bool changedConfiguration = false;
                foreach (BuildProject project in scheduledProjects)
                {
                    if (project.AdoptConfig(current))
                    {
                        changedConfiguration = true;
                        BuildConfig.HandleErrorObject(ErrorObject.MessageType.Message, "Project {0} changed configurations.", project.Name, project);
                    }
                }
                if (changedConfiguration)
                {
                    // ensure consistency. call all project to adopt the configuration again.
                    // if a project makes changes, stop the build provcess because of inconsistent needs
                    // for configurations.
                    foreach (BuildProject project in scheduledProjects)
                    {
                        if (project.AdoptConfig(current))
                        {
                            BuildConfig.HandleErrorObject(ErrorObject.MessageType.Error, "Project {0} states inconsistent needs on the used configuration.", project.Name, project);
                            return 1;
                        }
                    }
                }
                BuildConfig.CloseSectionInXmlLogFile();
                #endregion

                #region Build the overall execution plan
                BuildConfig.OpenSectionInXmlLogFile("create_plan");
                DateTime validityOfBuildsystem = ValidityOfExecutingAssembly;
                CollectionOfBuildActions executionPlan = new CollectionOfBuildActions();
                BuildToolFamilyEnv env = new BuildToolFamilyEnv();
                bool success = true;
                foreach (BuildProject project in scheduledProjects)
                {
                    if (options.IsDisabled(project.Name))
                        continue;

                    if (project.Preference == ProjectPreference.Optional && options.IsPreferred(project.Name))
                        project.SetPreference(ProjectPreference.Default);

                    DateTime validityOfProjectDefinition = project.ValidityOfDefiningAssemblies;
                    if (validityOfProjectDefinition < validityOfBuildsystem)
                        validityOfBuildsystem = validityOfProjectDefinition;

                    BuildConfig.OpenProjectSectionInXmlLogFile(project, false);
                    try
                    {
                        if (handler != null)
                            handler(new ErrorObject(ErrorObject.MessageType.Message, "- Building project {0}.\n  {1}", project.Name, project.Description));
                        if (options.RequestedAction == CommandLineOptions.RequestedActions.Build
                            && BuildConfig.GetConfig().Mode == BuildMode.BuildMissingTargets
                            && project.TargetsAreConsistent(ValidityOfExecutingAssembly))
                        {
                            BuildConfig.HandleErrorObject(new ErrorObject(ErrorObject.MessageType.Message, "Project {0} is already up to date. Proceeding.", project.Name));
                            continue;
                        }

                        // dating up the feature list.
                        List<FeatureEntry> featureKeys = new List<FeatureEntry>();
                        featureKeys.AddRange(project.Features.Keys);
                        foreach (FeatureEntry feature in featureKeys)
                        {
                            if (options.IsPreferred(feature.Symbol) && !project.Features[feature])
                            {
                                project.Features[feature] = true;
                                BuildConfig.HandleErrorObject(new ErrorObject(ErrorObject.MessageType.Message, "Enabling feature {0}/{1} due to user choice.", feature.Displayname, feature.Symbol));
                            }
                            else if (options.IsDisabled(feature.Symbol))
                            {
                                project.Features[feature] = false;
                                BuildConfig.HandleErrorObject(new ErrorObject(ErrorObject.MessageType.Message, "Disabling feature {0}/{1} due to user choice.", feature.Displayname, feature.Symbol));
                            }
                        }
                        #region Test whether there are unknown but required environment variables.
                        IDictionary<string, EnvironmentVarInfo> usedVars = project.UsedVars;
                        if (usedVars != null && usedVars.Count > 0)
                        {
                            foreach (EnvironmentVarInfo vi in usedVars.Values)
                                if (vi.IsMandatory)
                                {
                                    try
                                    {
                                        vi.Get();
                                    }
                                    catch (Exception exc)
                                    {
                                        BuildConfig.HandleErrorObject(new ErrorObject(ErrorObject.MessageType.Error, exc.Message));
                                        BuildConfig.HandleErrorObject(new ErrorObject(ErrorObject.MessageType.Error, "Error building {0}.", project.Name));
                                        continue; // nex project
                                    }
                                }
                        }
                        #endregion
                        ICollection<IBuildAction> projectPlan = project.CreateActionPlan(env);
                        if (projectPlan == null)
                        {
                            ErrorObject errorObj=new ErrorObject(ErrorObject.MessageType.Error, "Building {0} failed.", project.Name, project);
                            BuildConfig.HandleErrorObject(errorObj);
                            errors.Add(errorObj);
                            break;
                        }
                        executionPlan.AddRange(projectPlan);
                    }
                    catch (Exception exc)
                    {
                        ErrorObject error = new ErrorObject(ErrorObject.MessageType.Error, exc.Message, exc);
                        BuildConfig.HandleErrorObject(error);
                        errors.Add(error);
                        success = false;
                    }
                    finally
                    {
                        BuildConfig.CloseSectionInXmlLogFile();
                    }
                }
                if (BuildConfig.IsOpenXmlLogFile)
                    BuildConfig.HandleErrorObject(ErrorObject.MessageType.Message, "Log action plan on file.");
                BuildConfig.CloseSectionInXmlLogFile();
                BuildConfig.LogActionsOnXmlLogFile(executionPlan);
                #endregion

                if (options.RequestedAction == CommandLineOptions.RequestedActions.Build)
                {
                    #region Execution of the plan
                    BuildConfig.OpenSectionInXmlLogFile("execute");
                    foreach (IBuildAction action in executionPlan)
                    {
                        BuildConfig.OpenBuildActionSectionInXmlLogFile(action, false);
                        try
                        {
                            ICollection<IBuildProduct> targets = action.GetTargets();
                            BuildConfig.HandleErrorObject(ErrorObject.MessageType.Message, "Executing {0}...", action.Name, targets);
                            foreach (IBuildProduct target in targets)
                            {
                                ContentFile filetarget = target as ContentFile;
                                if (filetarget != null && !System.IO.Directory.Exists(filetarget.DirectoryName))
                                {
                                    System.IO.Directory.CreateDirectory(filetarget.DirectoryName);
                                    BuildConfig.HandleMessageObject("Created directory {0} to hold targets of action {1}.", filetarget.DirectoryName, action.Name);
                                }
                            }
                            if (current.Mode != BuildMode.BuildNew && action.TargetsAreConsistent(validityOfBuildsystem))
                                BuildConfig.HandleMessageObject("Targets of action {0} are already consistent.", action.Name);
                            else
                            {
                                if (!action.Execute(env, validityOfBuildsystem))
                                {
                                    success = false;
                                    BuildConfig.HandleErrorObject(ErrorObject.MessageType.Error, "Action {0} failed.", action.Name);
                                }
                            }
                        }
                        finally
                        {
                            BuildConfig.CloseSectionInXmlLogFile();
                        }
                    }
                    BuildConfig.CloseSectionInXmlLogFile();
                    #endregion
                }
                else if (options.RequestedAction == CommandLineOptions.RequestedActions.CreatBooCode)
                {
                    #region Build BOO Code
                    string filename = options.Filename;
                    if (!filename.EndsWith(".boo"))
                        filename += ".boo";
                    BuildConfig.HandleMessageObject("Build BOO file {0}.", filename);
                    using (TextWriter dest = new StreamWriter(filename))
                    {
                        dest.WriteLine("# BOO script to build the wx.Buildsystem projects from assembly");
                        dest.WriteLine("# {0}.", projectSrc.FullName);
                        dest.WriteLine("# This program has been generated automatically by the wx.BuildSystem");
                        dest.WriteLine("# (c) 2010 Harald Meyer auf'm Hofe.");
                        dest.WriteLine("#");
                        dest.WriteLine("# The following lines will declare variables to configure the tools");
                        dest.WriteLine("# that are used to build the system. You may change these declarations");
                        dest.WriteLine("# if you know what you are doing.");
                        #region Create Declarations And Definitions
                        Dictionary<string, string> insertedDeclarationLines = new Dictionary<string, string>();
                        List<string> booImports = new List<string>();
                        List<string> booDeclarations = new List<string>();
                        List<string> booDefinitions = new List<string>();

                        booDeclarations.Add("# This is the root path of the project.");
                        booDeclarations.Add(string.Format("{0}='{1}'", BuildConfig.PathRootVariable, ContentFile.ConvertFilenameToString(BuildConfig.PathRoot)));
                        booDeclarations.Add(string.Format("System.IO.Directory.SetCurrentDirectory({0})", BuildConfig.PathRootVariable));
                        booDeclarations.Add("#\n# If true, then any target will be rebuild. If false, many build actions");
                        booDeclarations.Add("# will only rebuild targets if prerequisites are newer.");
                        booDeclarations.Add("Rebuild=false");
                        booDeclarations.Add("#\n# This is the directory containing all non-target files that will be created on building the targets.");
                        string buildDir = TempFilesParameters.BuildDir;
                        buildDir = TempFilesParameters.MakePathRelative(buildDir, BuildConfig.PathRoot);
                        booDeclarations.Add(string.Format("BuildDir='{0}'", ContentFile.ConvertFilenameToString(buildDir)));

                        foreach (IBuildActionProvider ac in BuildConfig.AllActionProviders)
                        {
                            List<string> localDesclarations=new List<string>();
                            List<string> localDefinitions=new List<string>();
                            if (ac.IsAvailable)
                            {
	                            ac.AppendToBooPreamble(env, booImports, localDesclarations, localDefinitions);
	                            if (localDesclarations.Count > 0)
	                            {
	                                booDeclarations.Add(string.Format("#################################################################"));
	                                booDeclarations.Add(string.Format("# These are the declarations of tool {0} of family {1}:", ac.Name, ac.ToolFamily));
	                                booDeclarations.Add(string.Format("# {0}", ac.Description));
	                                booDeclarations.AddRange(localDesclarations);
	                            }
	                            if (localDefinitions.Count > 0)
	                            {
	                                booDefinitions.Add(string.Format("#"));
	                                booDefinitions.Add(string.Format("# These are the definitions of tool {0} of family {1}:", ac.Name, ac.ToolFamily));
	                                booDefinitions.Add(string.Format("# {0}", ac.Description));
	                                booDefinitions.AddRange(localDefinitions);
	                            }
                            }
                        }
                        #region Create Lines Importing Modules
                        Dictionary<string, string> insertedImports=new Dictionary<string,string>();
                        string[] mandatoryDefinitions = new string[] {
                            "System.IO",
                            "System.Diagnostics",
                        };
                        booImports.AddRange(mandatoryDefinitions);
                        foreach (string booImport in booImports)
                        {
                            string fullImportString = "import " + booImport;
                            if (!insertedImports.ContainsKey(booImport))
                            {
                                dest.WriteLine(fullImportString);
                                insertedImports.Add(booImport, booImport);
                            }
                        }
                        #endregion

                        #region Features Of Projects
                        foreach (BuildProject p in scheduledProjects)
                        {
                            if (p.Features != null && p.Features.Count > 0)
                            {
                                dest.WriteLine("# Features of project " + p.Name + ": " + p.Description);
                                dest.WriteLine("Features_{0}=[]", p.NameAsSymbol);
                                foreach (KeyValuePair<FeatureEntry, bool> featureDesc in p.Features)
                                {
                                    if (!featureDesc.Value)
                                        dest.Write("#");
                                    dest.WriteLine("Features_{0}.Add(\"{1}\") # {2}: {3}", p.NameAsSymbol, featureDesc.Key.Symbol, featureDesc.Key.Displayname, featureDesc.Key.Description);
                                }
                                dest.WriteLine();
                            }
                        }
                        #endregion

                        #region Add Declaration Lines
                        foreach (string booDeclaration in booDeclarations)
                        {
                            if (booDeclaration.TrimStart().StartsWith("#") || !insertedDeclarationLines.ContainsKey(booDeclaration))
                            {
                                dest.WriteLine(booDeclaration);
                                insertedDeclarationLines[booDeclaration] = booDeclaration;
                            }
                        }
                        #endregion
                        #region Declare Choice Points
                        Dictionary<string, ICollection<string>> collectionOfChoicePoints=new Dictionary<string,ICollection<string>>();
                        foreach (IBuildAction action in executionPlan)
                            action.CollectChoicePoints(collectionOfChoicePoints);
                        if (collectionOfChoicePoints.Count > 0)
                        {
                            dest.WriteLine();
                            dest.WriteLine("#########################################################");
                            dest.WriteLine("# This section contains choice points- BOO variables that");
                            dest.WriteLine("# control which tools will be used. Assign one of the");
                            dest.WriteLine("# listed values to the choice points in order to select");
                            dest.WriteLine("# a particular tool. If this tool is not available, the");
                            dest.WriteLine("# program will automatically use an alternative.");
                            foreach(KeyValuePair<string, ICollection<string>> choicePoint in collectionOfChoicePoints)
                            {
                                dest.Write(choicePoint.Key);
                                dest.Write(" = ");
                                Dictionary<string, string> printedChoices = new Dictionary<string, string>();
                                foreach (string alt in choicePoint.Value)
                                {
                                    if (printedChoices.ContainsKey(alt))
                                        continue;
                                    if (printedChoices.Count == 0)
                                    {
                                        dest.Write("\"");
                                        dest.Write(alt);
                                        dest.Write("\" #");
                                    }
                                    dest.Write(" \"");
                                    dest.Write(alt);
                                    dest.Write("\"");
                                    printedChoices[alt] = alt;
                                }
                                dest.WriteLine();
                            }
                        }
                        #endregion
                        dest.WriteLine();
                        dest.WriteLine("#########################################################");
                        dest.WriteLine("# The section containing declarations ends here.");
                        dest.WriteLine("# Please refrain from changing the code from this position on.");
                        dest.WriteLine("# The code below will provide definitions of build functions and");
                        dest.WriteLine("# will use this functions afterwards to produce the build targets.");
                        dest.WriteLine("# However, you may want to disable build tools here by replacing");
                        dest.WriteLine("# the body of the corrsponding function with \"pass\".");
                        dest.WriteLine("def TestForRebuild(targetFile as  string, *sourceFiles as (object)):");
                        dest.WriteLine("\tif Rebuild: return true");
                        dest.WriteLine("\tif not System.IO.File.Exists(targetFile): return true");
                        dest.WriteLine("\tdTarget=System.IO.File.GetLastWriteTime(targetFile)");
                        dest.WriteLine("\tinlinedSources=[]");
                        dest.WriteLine("\tfor sourceFile in sourceFiles:");
                        dest.WriteLine("\t\tif sourceFile == null: continue");
                        dest.WriteLine("\t\tif sourceFile isa System.Array:");
                        dest.WriteLine("\t\t\tfor containedSource in cast(System.Array, sourceFile):");
                        dest.WriteLine("\t\t\t\tinlinedSources.Add(containedSource)");
                        dest.WriteLine("\t\telse:");
                        dest.WriteLine("\t\t\tinlinedSources.Add(sourceFile)");
                        dest.WriteLine("\tfor inlinedSource in inlinedSources:");
                        dest.WriteLine("\t\tdSource=System.IO.File.GetLastWriteTime(inlinedSource)");
                        dest.WriteLine("\t\tif dTarget < dSource: return true");
                        dest.WriteLine("\treturn false");
                        dest.WriteLine();
                        #region Add Definition Lines
                        foreach (string booDefinitionLine in booDefinitions)
                        {
                            dest.WriteLine(booDefinitionLine);
                        }
                        booDefinitions = null;
                        insertedDeclarationLines = null;
                        booDeclarations = null;
                        booImports = null;
                        insertedImports = null;
                        #endregion
                        #endregion

                        #region Add Build Code From the Actions
                        dest.WriteLine("#\n# This is the code that actually builds the projects.");
                        foreach (IBuildAction action in executionPlan)
                        {
                            List<string> booLines = new List<string>();
                            try
                            {
                                action.AppendBooCode(booLines, "", env);
                            }
                            catch (Exception exc)
                            {
                                booLines.Add(string.Format("print \"Caught exception creating code for action {0}.\"", action.Name.Replace("\"", "\\\"")));
                                booLines.Add(string.Format("print \"{0}\"", exc.Message.Replace("\"", "\\\"")));
                                BuildConfig.HandleErrorObject(ErrorObject.MessageType.Warning, "Caught exception creating code for action {0}: {1}.", action.Name, exc.Message);
                            }
                            foreach (string booLine in booLines)
                                dest.WriteLine(booLine);
                        }
                        #endregion
                    }
                    #endregion
                }
                wx.ProcessUtils.ProcessStarter.PostProcessTerminated(new wx.ProcessUtils.ProcessTerminatedEvent(success));
                if (success && errors.Count == 0)
                {
                    BuildConfig.HandleMessageObject("Finished building with success.");
                    return 0;
                }
                else
                {
                    BuildConfig.HandleMessageObject("Finished building with some problems. I have not been able to build everything.");
                    foreach (ErrorObject error in errors)
                        BuildConfig.HandleErrorObject(error);
                    return 1;
                }
            }
            catch (Exception exc)
            {
                try
                {
                    BuildConfig.HandleErrorObject(new ErrorObject(ErrorObject.MessageType.Error, exc.Message, exc));
                }
                catch
                {
                }
                wx.ProcessUtils.ProcessStarter.PostProcessTerminated(new wx.ProcessUtils.ProcessTerminatedEvent(false));
                return 1;
            }
            finally
            {
                BuildConfig.CloseXmlLogfile();
            }
        }
        #endregion

        #region Object Overrides
        public override string ToString()
        {
            if (this.Description.Length > 0)
                return string.Format("{0}: {1}", this.Name, this.Description);
            else
                return this.Name;
        }

        /** <summary>  </summary> */
        public override int GetHashCode()
        {
            int result = this.GetType().GetHashCode() ^ this.Preference.GetHashCode() ^  this.Name.GetHashCode();
            foreach (IBuildProduct objTarget in this.GetTargets())
            {
                result = result ^ objTarget.GetHashCode();
            }
            return result;
        }

        /** <summary> Comparison refers to the implementation of IComparable.CompareTo(). </summary> */
        public override bool Equals(object obj)
        {
            return this.CompareTo(obj)==0;
        }
        #endregion

        #region IComparable Member
        /// <summary>
        /// Compares all properties, targets, and dependencies of <c>this</c> and the <c>obj</c> if the argument
        /// is a project of the same class. If the argument is of another class, this compares the full class
        /// names.
        /// <para>
        /// This is virtual since inheritors may overload this. However, inheritors MUST take care, that their 
        /// implementation is symmetric to this one, i.e. must be of the form
        /// <code>
        /// if (obj.GetType().Equals(this.GetType())
        /// {
        ///     ...
        /// }
        /// else return this.GetType().FullName.CompareTo(obj.GetType().FullName);
        /// </code></para>
        /// </summary>
        /// <param name="obj">Object that will be compared with this.</param>
        /// <returns>-1, 0, or 1 like in all the other implementations of this method.</returns>
        public virtual int CompareTo(object obj)
        {
            if (object.ReferenceEquals(this, obj))
                return 0;
            if (obj.GetType().Equals(this.GetType()))
            {
                if (this.GetType() != obj.GetType())
                    return this.GetType().FullName.CompareTo(obj.GetType().FullName);
                BuildProject p = obj as BuildProject;
                // If the GUID is defined, we call compare on the GUID and nothing else
                if (this._guid != Guid.Empty && p._guid != Guid.Empty)
                    return this._guid.CompareTo(p._guid);

                if (this.Preference != p.Preference)
                    return this.Preference.CompareTo(p.Preference);
                if (this.Name != p.Name)
                    return this.Name.CompareTo(p.Name);

                SortedDictionary<IBuildProduct, IBuildProduct> argTargets = new SortedDictionary<IBuildProduct, IBuildProduct>();
                foreach (IBuildProduct t in p.GetTargets())
                    argTargets.Add(t, t);
                SortedDictionary<IBuildProduct, IBuildProduct> thisTargets = new SortedDictionary<IBuildProduct, IBuildProduct>();
                foreach (IBuildProduct t in this.GetTargets())
                    thisTargets.Add(t, t);
                if (!thisTargets.Count.Equals(argTargets.Count))
                    return thisTargets.Count.CompareTo(argTargets.Count);
                IEnumerator<IBuildProduct> iThisTarget = thisTargets.Values.GetEnumerator();
                IEnumerator<IBuildProduct> iArgTarget = argTargets.Values.GetEnumerator();
                while (iThisTarget.MoveNext() && iArgTarget.MoveNext())
                {
                    int cmp = iThisTarget.Current.CompareTo(iArgTarget.Current);
                    if (cmp != 0)
                        return cmp;
                }
                return 0;
            }
            else
                return this.GetType().FullName.CompareTo(obj.GetType().FullName);
        }

        #endregion

        #region IXmlSerializable Member
        /// <summary>
        /// Returns <c>null</c> as suggested by the .NET framework documentation.
        /// </summary>
        public System.Xml.Schema.XmlSchema GetSchema()
        {
            return null;
        }

        /// <summary>
        /// Reads a project whose properties are available by GetLoadedProject().
        /// </summary>
        /// <param name="reader">The source.</param>
        /// <exception cref="KeyNotFoundException">Raised if the read project cannot be found in the GetLoadedProject().</exception>
        public static BuildProject LoadRefFrom(System.Xml.XmlReader reader)
        {
            if (reader.IsStartElement("project"))
            {
                string name = reader.GetAttribute("name");
                string guidString = reader.GetAttribute("id");
                Guid guid = new Guid(guidString);
                BuildProject p = GetKnownProject(guid);
                if (p == null)
                    throw new KeyNotFoundException(name);
                reader.Read();
                reader.MoveToContent();
                return p;
            }
            else
                reader.ReadStartElement("project"); // this will produce an error exception
            return null;
        }

        /// <summary>
        /// Serializing only the name of the project. Read this using LoadRefFrom().
        /// </summary>
        /// <param name="writer">The destinaton</param>
        public void WriteRefXml(System.Xml.XmlWriter writer)
        {
            writer.WriteStartElement("project");
            writer.WriteAttributeString("name", this.Name);
            writer.WriteAttributeString("id", this.GetGuid().ToString());
            writer.WriteEndElement();
        }

        #endregion

        #region ICloneable Member

        /// <summary>
        /// Deep copy of this instance.
        /// </summary>
        public abstract object Clone();

        #endregion

        #region IXmlRefData Member
        /// <summary>
        /// Serialization of full data. This mus be written by each subclass of a project
        /// whereas the standard serialization is generic.
        /// </summary>
        /// <remarks>
        /// Do not forget to use WriteStdAttributes().
        /// </remarks>
        /// <param name="writer">The destination</param>
        public abstract void WriteXml(System.Xml.XmlWriter writer);

        /// <summary>
        /// Serialization of full data. This mus be written by each subclass of a project
        /// whereas the standard serialization is generic.
        /// </summary>
        /// <remarks>All Implementations of this project shall not forget to read the ReadStdAttributes()
        /// and add this instance to the loaded projects using  
        /// <code>
        /// System.Guid oldGuid=this.Id;
        /// wx.Build.BuildProject.ReadStdAttributes();
        /// this.SetAsLoadedProject(oldGuid);
        /// </code>
        /// </remarks>
        /// <param name="reader">The source</param>
        public abstract void ReadXml(System.Xml.XmlReader reader);

        #endregion
    }

    /// <summary>
    /// This is a build project producing files.
    /// </summary>
    public abstract class FileProject : BuildProject
    {
        /** <summary> This will add the project to the DB using the provided name.
         * This will raise an exception, if a project of this name is already known.
         * <param name="preference">Preference of the project - is this mandatory or not. Refer to <c>Preference </c>.</param>
         * <param name="projectName">Refer to <c>Name </c> . The name of the project shall exclusively consist of alpha-numerical characters,
         *  the underscore '_', the dash '-', blanks ' ', '&amp;', '%', or the fullstop character '.'.</param>
         *  <param name="definingAssembly">Is the assembly defining the project. This will be used to compute a validity of the
         *  project definition. This may be <c>null</c>.</param>
         * </summary>
         */
        public FileProject(System.Reflection.Assembly definingAssembly, ProjectPreference preference, string name)
            : base(definingAssembly, preference, name)
        {
        }

        /// <summary>
        /// Returns an instance of RefToFileProject.
        /// </summary>
        /// <returns></returns>
        public override RefToProject CreateRef()
        {
            return this.CreateRefToFileProject();
        }

        public virtual RefToFileProject CreateRefToFileProject()
        {
            return new RefToFileProject(this);
        }

        public static implicit operator FileProject(RefToFileProject refToProject)
        {
            return (FileProject)refToProject.Project;
        }
    }

    /// <summary>
    /// This is a build project producing a single file.
    /// </summary>
    public abstract class SingleFileProject : FileProject
    {
        /** <summary> This will add the project to the DB using the provided name.
         * This will raise an exception, if a project of this name is already known.
         * <param name="preference">Preference of the project - is this mandatory or not. Refer to <c>Preference </c>.</param>
         * <param name="projectName">Refer to <c>Name </c> . The name of the project shall exclusively consist of alpha-numerical characters,
         *  the underscore '_', the dash '-', blanks ' ', '&amp;', '%', or the fullstop character '.'.</param>
         *  <param name="definingAssembly">Is the assembly defining the project. This will be used to compute a validity of the
         *  project definition. This may be <c>null</c>.</param>
         * </summary>
         */
        public SingleFileProject(System.Reflection.Assembly definingAssembly, ProjectPreference preference, string name)
            : base(definingAssembly, preference, name)
        {
        }

        /// <summary>
        /// Returns an instance of RefToFileProject.
        /// </summary>
        /// <returns></returns>
        public override RefToProject CreateRef()
        {
            return this.CreateRefToSingleFileProject();
        }

        /// <summary>
        /// Returns an instance of RefToFileProject.
        /// </summary>
        /// <returns></returns>
        public override RefToFileProject CreateRefToFileProject()
        {
            return this.CreateRefToSingleFileProject();
        }

        public RefToSingleFileProject CreateRefToSingleFileProject()
        {
            return new RefToSingleFileProject(this);
        }

        public static implicit operator SingleFileProject(RefToSingleFileProject refToProject)
        {
            return (SingleFileProject)refToProject.Project;
        }
    }

    /// <summary>
    /// This is a wrapper around a BuildProject that makes this instance a build product.
    /// Projects often refer to another project as prerequisite - projects can be build
    /// products. This wrapper turns a project into a build product.
    /// 
    /// Why using a wrapper? A project shall be stred only once. In contrast, references
    /// to a project may occur more than once. 
    /// </summary>
    public class RefToProject : IBuildProduct
    {
        #region State
        BuildProject _project;
        #endregion

        #region CTor
        /// <summary>
        /// Use this only to create an instance for ReadXml().
        /// </summary>
        public RefToProject()
        {
            this._project = null;
        }

        public RefToProject(BuildProject p)
        {
            if (!p.IsSingleton)
                p = p.GetSingleton();

            this._project = p;
        }
        #endregion

        /// <summary>
        /// Implicitely converts a project into a ref to a project creating a reference to the project.
        /// </summary>
        /// <param name="p">The project that shall be referenced</param>
        /// <returns>A reference to the project.</returns>
        public static implicit operator RefToProject(BuildProject p)
        {
            return p.CreateRef();
        }

        /// <summary>
        /// This is the encapsulated project.
        /// </summary>
        public BuildProject Project { get { return this._project; } }

        #region IBuildObject Member

        public DateTime GetValidity()
        {
            return this._project.GetValidity();
        }

        public DateTime GetValidityDemand()
        {
            return this._project.GetValidityDemand();
        }

        /// <summary>
        /// Returns a collection including exclusively the wrapped project.
        /// </summary>
        /// <returns></returns>
        public ICollection<RefToProject> GetProjects()
        {
            return new RefToProject[] { this };
        }

        #endregion

        #region IComparable Member
        /// <summary>
        /// Compares w.r.t. the encaspulated project if both are of class RefToProject.
        /// </summary>
        /// <param name="obj">The object that will be compared</param>
        /// <returns>-1 if this is smaller than the argument, 0 if both equal, 1 if the argument is larger.</returns>
        public int CompareTo(object obj)
        {
            if (obj is RefToProject)
            {
                return this.Project.CompareTo(((RefToProject)obj).Project);
            }
            else
                return this.GetType().FullName.CompareTo(obj.GetType().FullName);
        }

        #endregion

        #region IXmlSerializable Member

        public System.Xml.Schema.XmlSchema GetSchema()
        {
            return null;
        }

        /// <summary>
        /// Will create a project using BuildProject.LoadRefFrom(reader).
        /// </summary>
        /// <param name="reader">The source where the XML serialization will be read from.</param>
        public void ReadXml(System.Xml.XmlReader reader)
        {
            this._project = BuildProject.LoadRefFrom(reader);
        }

        /// <summary>
        /// Calls BuildProject.WriteRefXml().
        /// </summary>
        /// <param name="writer">the destination where the XML serialization will be written to.</param>
        public void WriteXml(System.Xml.XmlWriter writer)
        {
            this.Project.WriteRefXml(writer);
        }

        #endregion

        #region Overrides
        public override bool Equals(object obj)
        {
            if (obj is RefToProject)
                return this.Project.Equals(((RefToProject)obj).Project);
            else
                return false;
        }

        /// <summary>
        /// This is the hash of the encapsulated project.
        /// </summary>
        /// <returns></returns>
        public override int GetHashCode()
        {
            return this.Project.GetHashCode();
        }

        public override string ToString()
        {
            return "^" + this.Project.Name;
        }
        #endregion
    }

    /// <summary>
    /// This is a wrapper of projects that produce files.
    /// Projects producing more than one file shall return an instance of this class as BuildProject.Ref.
    /// Project producing a single file shall return RefToSingleFileProject instead.
    /// </summary>
    public class RefToFileProject : RefToProject, IFileProducts
    {
        #region State
        ContentFiles _files = null;
        #endregion

        /// <summary>
        /// Use this only to create an instance for ReadXml().
        /// </summary>
        public RefToFileProject()
            : base()
        {
        }

        public RefToFileProject(FileProject aProject)
            : base(aProject)
        {
        }
        /// <summary>
        /// Implicit conversion of a project into an instance of this class.
        /// This works using BuildProject.CreateRefToFileProject().
        /// </summary>
        /// <param name="p">The project that shall be referenced</param>
        /// <returns>A reference to the project.</returns>
        public static implicit operator RefToFileProject(FileProject p)
        {
            return p.CreateRefToFileProject();
        }

        #region IFileProducts Member

        public ContentFiles Files
        {
            get
            {
                if (this._files == null)
                {
                    foreach (IBuildProduct p in this.Project.GetTargets())
                    {
                        if (p is ContentFile)
                        {
                            ContentFile f = (ContentFile)p;
                            if (this._files == null)
                                this._files = new ContentFiles(f.Type);
                            else
                            {
                                if (!this._files.Type.Contains(f.Type))
                                {
                                    foreach (ContentType implied in this._files.Type.GetAllImpliedTypes())
                                    {
                                        if (implied.Contains(f.Type))
                                        {
                                            this._files.Type = implied;
                                            break;
                                        }
                                    }
                                }
                            }
                            this._files.Add((ContentFile)p);
                        }
                    }
                }
                return this._files;
            }
        }

        /// <summary>
        /// A collection of contained files that are addressed explicitely as instances of ContentFiles or ContentFile.
        /// </summary>
        public ContentFiles ExplicitFiles
        {
            get
            {
                return new ContentFiles();
            }
        }

        /// <summary>
        /// True if the argument equals this (refers to the same project) or the argument is contained by <c>Files</c>.
        /// </summary>
        /// <param name="file">The file or project that is searched by the caller.</param>
        /// <returns></returns>
        public bool Contains(IBuildProduct file)
        {
            return this.Equals(file)
                    || this.Files.Contains(file);
        }

        public ContentType Type
        {
            get { return this.Files.Type; }
        }

        public int Count
        {
            get { return this.Files.Count; }
        }

        public IFileProducts Replace(IFileProducts oldInstance, IFileProducts replacement)
        {
            if (this.Equals(oldInstance))
                return replacement;
            return this;
        }

        /// <summary>
        /// You may use this method to control the form of the file name that will be used to
        /// serialize this (the original filename). The argument is a path to an existing
        /// file or directory. This will strip a directory information from this path. After
        /// that, the original file name will change to something equivalent to the absolute
        /// filename (referring to the same file) but now relative to the directory as specified
        /// by the argument.
        /// 
        /// Use this method to prepare content file instance for serialization in such a way
        /// that all file names become relative to the same directory.
        /// </summary>
        /// <param name="nameOfAValidDirOrFile">The name of an existing file or directory. This name
        /// will - if relative - be expanded using the BuildConfig. If this is <c>null</c>, this
        /// method will return without any effect. This may also be the name of a not yet existing file.
        /// In that case, however, the directory name shall exist.</param>
        /// <seealso cref="OriginalFileName"/>
        /// <exception cref="System.ArgumentException">Will be raised if the argument is neither the path
        /// to an existing file nor directory.</exception>
        public virtual void NormalizeOriginalFileName(string nameOfAValidDirOrFile)
        {
            this.Project.NormalizeOriginalFileName(nameOfAValidDirOrFile);
        }
        #endregion

        #region ICloneable Member

        public virtual object Clone()
        {
            return new RefToFileProject((FileProject)this);
        }

        #endregion
    }

    /// <summary>
    /// This is a wrapper of projects that produce a single file.
    /// Projects producing a single file shall return an instance of this class as BuildProject.Ref.
    /// </summary>
    public class RefToSingleFileProject : RefToFileProject, IFileProducts, ISingleFileProduct
    {
        #region State
        ContentFile _target = null;
        #endregion

        /// <summary>
        /// Use this only to create an instance for ReadXml().
        /// </summary>
        public RefToSingleFileProject()
        {
        }

        public RefToSingleFileProject(SingleFileProject aProjectProducingASingleFile)
            : base(aProjectProducingASingleFile)
        {
        }
        /// <summary>
        /// Explicit conversion of a project into an instance of this class.
        /// This works using BuildProject.CreateRefToSingleFileProject().
        /// </summary>
        /// <param name="p">The project that shall be referenced</param>
        /// <returns>A reference to the project.</returns>
        public static explicit operator RefToSingleFileProject(SingleFileProject p)
        {
            return p.CreateRefToSingleFileProject();
        }

        #region ICloneable Member

        public override object Clone()
        {
            return new RefToSingleFileProject((SingleFileProject)this.Project);
        }

        #endregion

        #region ISingleFileProduct Member

        public ContentFile File
        {
            get
            {
                if (this._target == null)
                {
                    this._target=this.Files.GetOneFile();
                }
                return this._target;
            }
        }
        #endregion
    }

    /** <summary> BuildProject.Build() can be called without any arguments. In that case, project defined by this attributes will be built.</summary><remarks>
     * Using this attributes turns an assembly into a collection of build projects.
     * The main method can use BuildProject.Build() to build these projects.
     * 
     * You may alternatively define static properties returning instances of type BuildProject.
     * So, both samples below are equivalent:
     * \code
     [assembly:BuildProject(new BlablaProject())]
     
     public class BuildProgram
     {
        public static int Main(string[] args)
        {
            return BuildProject.Build(args);
        }
     }
     \endcode
     * and
     \code
     public class BuildProgram
     {
        public static BuildProject BlablaProject
        {
            get
            {
                return new BlablaProject();
            }
        }
        public static int Main(string[] args)
        {
            return BuildProject.Build(args);
        }
     }
     \endcode </remarks> */
    [AttributeUsage(AttributeTargets.Assembly, AllowMultiple=true)]
    public class BuildProjectAttribute : Attribute
    {
        #region State
        BuildProject _project;
        #endregion

        #region CTor
        /** <summary> Specifies the project to be built. </summary> */
        public BuildProjectAttribute(BuildProject project)
        {
            this._project = project;
        }
        #endregion

        #region Properties
        /** <summary> Returns the project. </summary> */
        public BuildProject Project { get { return this._project; } }
        #endregion
    }
}

/** <summary> A namespace containing projects ans actions to produce NET assemblies. </summary> */
namespace wx.Build.Net
{
    /** <summary> This will produce a .Net assembly file from sources.
     * Note, that currently only C# sources are supported.
     * 
     * All properties are writeable (except AssemblyFile) but
     * may never change after being specified once.
     * 
     * This creates one target of type <c>ContentType.DotNetDll </c>  or <c>ContentType.DotNetExe </c> 
     * (determined according to the file name extension of the target) or <c>ContentType.SignedDll </c>  or <c>ContentType.SignedExe</c>,
     * respectively (if a key file is provided). Also <c>ContentType.DotNetModule</c> can be built.
     * </summary> 
     */
    public class CSharpAssemblyProject : SingleFileProject
    {
        #region State
        ContentFile _assemblyFile;
        IFileProducts _referencedAssemblies=null;
        IFileProducts _csharpsources = null;
        IFileProducts _winIcon = null;
        ISingleFileProduct _signature = null;
        ICollection<ResourceDesignator> _resources = null;
        IFileProducts _pInvokeDependencies = null;
        ICollection<ResourceDesignator> _externalResources = null;
        string _mainClass = null;
        string _description;
        #endregion

        #region CTor
        /// <summary>
        /// Use only for XML serialization before ReadXml(). This will initialize an empty project of empty name
        /// that will not be offered.
        /// </summary>
        public CSharpAssemblyProject() : base(null, ProjectPreference.DoNotOffer, "") 
        {
        }

        /// <summary>
        /// Copy CTor
        /// </summary>
        /// <param name="src">the source</param>
        public CSharpAssemblyProject(CSharpAssemblyProject src)
            : base(null, src.Preference, src.Name)
        {
            this._assemblyFile = new ContentFile(src._assemblyFile);
            if (src._csharpsources != null)
                this._csharpsources = (IFileProducts)src._csharpsources.Clone();
            this._description = src._description;
            if (src._externalResources != null)
            {
                this._externalResources = new List<ResourceDesignator>();
                foreach (ResourceDesignator r in src._externalResources)
                    this._externalResources.Add(r);
            }
            this._mainClass = src._mainClass;
            if (src._pInvokeDependencies != null)
                this._pInvokeDependencies = (IFileProducts)src._pInvokeDependencies.Clone();
            if (src._referencedAssemblies != null)
                this._referencedAssemblies = (IFileProducts)src._referencedAssemblies.Clone();
            if (src._resources != null)
            {
                this._resources = new List<ResourceDesignator>();
                foreach (ResourceDesignator r in src._resources)
                    this._resources.Add(r);
            }
            if (src._signature != null)
                this._signature = (ISingleFileProduct)src._signature.Clone();
            if (src._winIcon != null)
                this._winIcon = (IFileProducts)src._winIcon.Clone();
        }

        public override object Clone()
        {
            return new CSharpAssemblyProject(this);
        }

        /// <summary>
        /// Creates an instance deriving the content type of the assembly file from the extension of the provided file name.
        /// Please note, that this CTor can distinguish DLLs from programs (extensions <c>.dll</c> and <c>.exe</c>) but fails
        /// to distinguish signed from unsigned assemblies.
        /// </summary>
        /// <param name="preference">Preference of the project</param>
        /// <param name="name">Name of the project. Will occur in user information and error strings.</param>
        /// <param name="assemblyFileToBeBuilt">Filename of the result. Names ending with <c>.exe</c> will create programs.
        /// Names ending with ".mod", ".module", or ".netmodule" will create .NET modules.</param>
        /// <param name="description">Text description of the project - for user information.</param>
        public CSharpAssemblyProject(ProjectPreference preference, string name, string assemblyFileToBeBuilt, string description)
            : base(System.Reflection.Assembly.GetCallingAssembly(), preference, name)
        {
            this._description = description;
            ContentType contentType = ContentType.DotNetDll;
            string lowerCase = assemblyFileToBeBuilt.ToLower();
            if (lowerCase.EndsWith(".exe"))
                contentType = ContentType.DotNetExe;
            else if (lowerCase.EndsWith(".mod") || lowerCase.EndsWith(".module") || lowerCase.EndsWith(".netmodule"))
                contentType = ContentType.DotNetModule;
            else if (!lowerCase.EndsWith(".dll"))
                throw new ArgumentException("Cannot derive desired content type from filename.");
            this._assemblyFile = new ContentFile(contentType, assemblyFileToBeBuilt);
        }

        /// <summary>
        /// Creates an instance deriving the content type of the assembly file from the extension of the provided file name.
        /// </summary>
        /// <param name="preference">Preference of the project</param>
        /// <param name="name">Name of the project. Will occur in user information and error strings.</param>
        /// <param name="assemblyFileToBeBuilt">Filename of the result. The content type of this file must imply ContentType.DotNetDll or ContentType.DotNetModule.</param>
        /// <param name="description">Text description of the project - for user information.</param>
        /// <exception cref="System.ArgumentException">Will be thrown if the content type of the <c>assemblyFileToBeBuilt</c>
        /// does not imply ContentType.DorNetDll.</exception>
        public CSharpAssemblyProject(ProjectPreference preference, string name, ContentFile assemblyFileToBeBuilt, string description)
            : base(System.Reflection.Assembly.GetCallingAssembly(), preference, name)
        {
            this._description = description;
            this._assemblyFile = assemblyFileToBeBuilt;
            if (!this._assemblyFile.Type.Implies(ContentType.DotNetDll)
                && !this._assemblyFile.Type.Implies(ContentType.DotNetModule))
                throw new ArgumentException("A CSharpAssemblyProject can only create managed dlls or executable programs.");
        }
        #endregion

        #region Public Properties
        /** <summary> A descriptive text on the project.
         * This will be used whenever the system explains the purpose of the project to the user.
         * This is read-only. </summary> */
        public override string Description
        {
            get { return this._description; }
        }

        /** <summary> The name of the main class that holds the main program if this project if this creates an executable.
         * Use this to get or set this property. </summary> */
        public string MainClass
        {
            get { return this._mainClass; }
            set { this._mainClass = value; }
        }

        public IFileProducts WinIcon
        {
            get
            {
                return this._winIcon;
            }
            set
            {
                this._winIcon = value;
            }
        }

        /** <summary> Use this to get or set the type of the assembly to be built.
        * This will return or accept one of the content types mentioned below.
        * Setting another type will result into an argument exception. </summary> */
        public ContentType Type
        {
            get
            {
                if (this._assemblyFile.Type.Implies(ContentType.SnDotNetDll))
                    return this._assemblyFile.Type;
                if (ContentType.SnDotNetDll.Implies(this._assemblyFile.Type)
                    && this._signature != null
                    && this._signature.Count > 0)
                {
                    // this usually creates a strongly named assembly but this feature has been disabled.
                    ContentType newT = ContentType.DotNetDll;
                    if (ContentType.DotNetShellExe.Implies(this._assemblyFile.Type))
                        newT = ContentType.DotNetShellExe;
                    else if (ContentType.DotNetExe.Implies(this._assemblyFile.Type))
                        newT = ContentType.DotNetExe;
                    else if (ContentType.DotNetModule.Implies(this._assemblyFile.Type))
                        newT = ContentType.DotNetModule;
                    return newT;
                }
                else
                    return this._assemblyFile.Type;
            }
            set
            {
                if (ContentType.DotNetDll.Contains(value) || ContentType.DotNetModule.Contains(value))
                {
                    if (this._assemblyFile.Type != value)
                        this._assemblyFile = new ContentFile(value, this._assemblyFile.FileName);
                }
                else
                    throw new ArgumentException(string.Format("Cannot set {0} as a target type of a project producing assemblie.", value));
            }
        }

        /** <summary> Returns the descriptor of the assembly file that will be created.
         * This will also take feature "SN" <c>StrongNameFeature </c>  into account. </summary> */
        public ContentFile AssemblyFile
        {
            get
            {
                return this._assemblyFile;
            }
        }

        /** <summary> Returns a collection of all affected files (that exist if this has been done).
         * This is read only. </summary> */
        public override ICollection<IBuildProduct> GetTargets()
        {
            ICollection<IBuildProduct> result = new List<IBuildProduct>();
            result.Add(this.AssemblyFile);
            return result;
        }

        /** <summary> Returns a collection containing the input files.
         * Signature, sources, icons, references assemblies. </summary> */
        public override ICollection<IBuildProduct> GetPrerequisites()
        {
            ICollection<IBuildProduct> result = new List<IBuildProduct>();
            if (this._csharpsources != null)
                result.Add(this._csharpsources);
            if (this._referencedAssemblies != null)
                result.Add(this._referencedAssemblies);
            if (this._pInvokeDependencies != null)
                result.Add(this._pInvokeDependencies);
            if (this._signature != null)
                result.Add(this._signature);
            if (this._winIcon != null)
                result.Add(this._winIcon);
            if (this._resources != null)
                foreach (ResourceDesignator rd in this._resources)
                    result.Add(rd);
            if (this._externalResources != null)
                foreach (ResourceDesignator rd in this._externalResources)
                    result.Add(rd);
            return result;
        }

        public override bool ContainsPrerequisite(IBuildProduct prereq)
        {
            if (base.ContainsPrerequisite(prereq)
                || (this._csharpsources != null && this._csharpsources.Contains(prereq))
                || (this._referencedAssemblies != null && this._referencedAssemblies.Contains(prereq))
                || (this._signature != null && this._signature.Equals(prereq))
                || (this._winIcon != null && this._winIcon.Contains(prereq)))
                return true;
            if (this._resources != null)
            {
                foreach (ResourceDesignator fd in this._resources)
                    if (fd.Equals(prereq))
                        return true;
            }
            if (this._externalResources != null)
            {
                foreach (ResourceDesignator fd in this._externalResources)
                    if (fd.Equals(prereq))
                        return true;
            }
            return false;
        }

        /** <summary> CSharp sources of the project (content type ContentType.CSharpCode).
         * This will raise a <c>System </c> .Argument exception if the content type of assigned sources is unexpected. </summary> */
        public IFileProducts CSharpSources
        {
            get
            {
                return this._csharpsources;
            }
            set
            {
                if (!value.Type.Equals(ContentType.CSharpCode))
                    throw new ArgumentException("Expect CSharp sources here.");
                this._csharpsources = value;
            }
        }

        /** <summary> CSharp sources of the project (content type ContentType.DotNetDll).
         * This will raise a <c>System </c> .Argument exception if the content type of assigned sources is unexpected. </summary> */
        public IFileProducts ReferencesAssemblies
        {
            get
            {
                return this._referencedAssemblies;
            }
            set
            {
                if (!value.Type.Implies(ContentType.DotNetDll))
                    throw new ArgumentException("Expect managed DLLs here.");
                this._referencedAssemblies = value;
            }
        }

        /// <summary>
        /// Resources will be linked into the assembly.
        /// </summary>
        public ICollection<ResourceDesignator> Resources
        {
            get
            {
                return this._resources;
            }
            set
            {
                this._resources = value;
            }
        }

        /// <summary>
        /// Assign those projects producing files that have to be built before this here.
        /// This property declares dependencies to projects producing native DLLs that are referenced
        /// e.g. by the P-Invoke interface.
        /// <para>
        /// Only assign file products concerning ContentFileProperties.NativeDLL to this property.
        /// </para>
        /// </summary>
        public IFileProducts PInvokeDependencies
        {
            get
            {
                return this._pInvokeDependencies;
            }
            set
            {
                if ((value.Type.Properties & ContentFileProperties.NativeDLL) != ContentFileProperties.NativeDLL)
                    throw new Exception(string.Format("Only assign native DLLs to {0}.PInvokeDependencies.", this.Name));
                this._pInvokeDependencies = value;
            }
        }

        /// <summary>
        /// Assign file products to this member (that is <c>null</c> by defaults) to declare external resources.
        /// These resources will not be linked into the assembly but shall be available side by side to the created DLL or program.
        /// The internal name will be interpreted as a relative path that will be used to compute the desired position of the resource
        /// relatively to the created program or DLL. This will raise an error if the internal name of the resource can be interpreted
        /// as a rooted filename.
        /// </summary>
        public ICollection<ResourceDesignator> ExternalResources
        {
            get
            {
                return this._externalResources;
            }
            set
            {
                foreach(ResourceDesignator rd in value)
                    if (rd.Name.Length == 0 || System.IO.Path.IsPathRooted(rd.Name))
                        throw new Exception(string.Format("Illegal name \"{0}\" of an internal resource.", rd.Name));
                this._externalResources = value;
            }
        }

        /// <summary>
        /// Adds the provided resources to the list of external resources. 
        /// These resources will not be linked into the assembly but shall be available side by side to the created DLL or program.
        /// The internal name will be interpreted as a relative path that will be used to compute the desired position of the resource
        /// relatively to the created program or DLL. This will raise an error if the internal name of the resource can be interpreted
        /// as a rooted filename.
        /// </summary>
        /// <param name="resources">A collection of resources, e.g. created by ResourceDesignator.SelectExternalResources().</param>
        /// <see cref="ExternalResources"/>
        public void AddExternalResources(ICollection<ResourceDesignator> resources)
        {
            foreach (ResourceDesignator rd in resources)
                if (rd.Name.Length == 0 || System.IO.Path.IsPathRooted(rd.Name))
                    throw new Exception(string.Format("Illegal name \"{0}\" of an internal resource.", rd.Name));
            List<ResourceDesignator> newResources = new List<ResourceDesignator>();
            if (this._externalResources != null)
                newResources.AddRange(this._externalResources);
            newResources.AddRange(resources);
            this._externalResources = newResources;
        }

        /** \name Predefined Festures
        */
        //@{
        public static readonly FeatureEntry PlatformX32 = new FeatureEntry("Platform 32 bit", "Defines a 32 bit processor architecture. This will take effect on the platform descriptor when using MS .NET tools.", "X32");
        public static readonly FeatureEntry PlatformX64 = new FeatureEntry("Platform 64 bit", "Defines a 64 bit processor architecture. This will take effect on the platform descriptor when using MS .NET tools.", "X64");
        //@}

        /// <summary>Gets or defines the signature to be used to sign the assembly after building.
        /// The file must contain type "application/sn-keys" ContentType.SnKeys.
        /// This may be <c>null</c> if this does not create a signed assembly. 
        /// If set, this will turn the content type of the target from ContentType.DotNetDll
        /// to ContentType.SnDll, or from ContentType.DotNetExe to ContentType.SnExe, respectively.</summary>
        public ISingleFileProduct Signature
        {
            get
            {
                return this._signature;
            }
            set
            {
                if (value.Type != ContentType.SnKeys)
                    throw new ArithmeticException("Expect application/sn-keys here.");
                this._signature = value;
                if (this._assemblyFile.Type == ContentType.DotNetDll)
                    this._assemblyFile = new ContentFile(ContentType.SnDotNetDll, this._assemblyFile.FileName);
                else if (this._assemblyFile.Type == ContentType.DotNetExe)
                    this._assemblyFile = new ContentFile(ContentType.SnDotNetExe, this._assemblyFile.FileName);
            }
        }
        #endregion

        /// <summary>
        /// This will make the project instance ready to be solved.
        /// The build system will only use one project instance per target.
        /// Thus, projects will be registered. This will try to register this instance.
        /// If the database of registered project already contains a project instance
        /// for the targets of this instance, this will return this instance.
        /// </summary>
        /// <remarks>
        /// After calling this method, all calls to modifiers are allowed to throw errors.
        /// </remarks>
        /// <returns></returns>
        public new CSharpAssemblyProject GetSingleton()
        {
            return (CSharpAssemblyProject)((BuildProject) this).GetSingleton();
        }

        /** <summary> Looks for an applicable action to compile, link resources, and sign up.
         * Will try to make the assembly first. Then linking and signing.
         * \result is a collection of actions that achieve the targets or <c>null </c>  in case of errors that shall stop the build process. </summary> */
        public override ICollection<IBuildAction> CreateActionPlan(BuildToolFamilyEnv env)
        {
            CollectionOfBuildActions actions = BuildConfig.ActionsProducing(this, env, this.AssemblyFile, this.GetPrerequisites());
            if (actions.Count == 0)
            {
                BuildConfig.HandleErrorObject(ErrorObject.MessageType.Error, "Could not find an applicable action to create {0}.", this._assemblyFile);
                return null;
            }

            // all actions must at least receive all CSharp source files.
            CollectionOfBuildActions.ActionSelector selector = delegate(IBuildAction action)
            {
                foreach (ContentFile csharpFile in this._csharpsources.Files)
                {
                    if (!action.ContainsPrerequisite(csharpFile))
                        return true;
                }
                return false;
            };
            actions.Remove(selector);
            ICollection<IBuildAction> buildActions = null;
            if (actions.Count == 0)
            {
                BuildConfig.HandleErrorObject(new ErrorObject(ErrorObject.MessageType.Error, "Can not create {0}.", this._assemblyFile));
                return null;
            }
            else if (actions.Count == 1)
            {
                buildActions= new IBuildAction[] { actions.GetOneAction() };
            }
            else
            {
                buildActions= new IBuildAction[] { new AlternativeBuildActions("CSHARP_COMPILER", this._assemblyFile, actions) };
            }

            #region Create copy actions for external resources
            if (this.ExternalResources == null)
                return buildActions;

            SequenceOfBuildActions copySeq = new SequenceOfBuildActions();
            #region Create copy actions that will copy the required files using the internal name as path information.
            foreach (ResourceDesignator rd in this._externalResources)
            {
                if (rd.ResourceFileProject is ContentFile
                    && !System.IO.Path.IsPathRooted(rd.Name))
                {
                    string destinationPath = System.IO.Path.Combine(this._assemblyFile.DirectoryName, rd.Name);
                    copySeq.Add(new Release.CopyFileAction(rd.ResourceFile.Type, rd.ResourceFile.FileName, destinationPath));
                }
                else
                    BuildConfig.HandleErrorObject(ErrorObject.MessageType.Error, "Ignored external resource {0}.", rd);
            }
            #endregion
            #region Search for side-by-side assemblies among the specified references.
            foreach (ContentFile assemblyFile in this.ReferencesAssemblies.ExplicitFiles)
            {
                if (assemblyFile.Location == ContentFileLocation.LocalFileSystem)
                {
                    string destinationPath = System.IO.Path.Combine(this._assemblyFile.DirectoryName, assemblyFile.BaseFileName);
                    copySeq.Add(new Release.CopyFileAction(assemblyFile.Type, assemblyFile.FileName, destinationPath));
                }
            }
            #endregion
            if (copySeq.Count==0)
                return buildActions;

            List<IBuildAction> fullResult=new List<IBuildAction>();
            foreach(IBuildAction buildAction in buildActions)
            {
                SequenceOfBuildActions fullSeq=new SequenceOfBuildActions(copySeq);
                fullSeq.Add(buildAction);
                fullResult.Add(fullSeq);
            }
            return fullResult;
            #endregion
        }

        #region XML serialization
        /// <summary>
        /// Reads an XML serialization that has been written by WriteXml().
        /// </summary>
        /// <param name="reader">The source where the serialization will be read from.</param>
        public override void ReadXml(System.Xml.XmlReader reader)
        {
            reader.IsStartElement("csharp-assembly-project");
            Guid oldGuid = this.Id;
            this.ReadStdAttributes(reader);
            reader.Read();
            this._description = reader.ReadElementString("description");
            this.ReadProject(reader);

            this._mainClass=null;
            if (reader.IsStartElement("main-class"))
            {
                this._mainClass = reader.ReadElementString("main-class");
            }
            this._winIcon = (IFileProducts)ReadSerializable(reader, "win-icon");
            this._assemblyFile = (ContentFile)ReadSerializable(reader, "target");
            this._csharpsources = (IFileProducts)ReadSerializable(reader, "csharp-sources");
            this._referencedAssemblies = (IFileProducts)ReadSerializable(reader, "references");
            this._pInvokeDependencies = (IFileProducts)ReadSerializable(reader, "pinvoke-references");
            this._resources=new List<ResourceDesignator>();
            AdderSerializable adderresources=delegate(System.Xml.Serialization.IXmlSerializable newelem)
            {
                this._resources.Add((ResourceDesignator)newelem);
            };
            if (!ReadCollection(reader, adderresources, "resources", "resource"))
                this._resources=null;
            this._externalResources=new List<ResourceDesignator>();
            AdderSerializable adderextresources=delegate(System.Xml.Serialization.IXmlSerializable newelem)
            {
                this._externalResources.Add((ResourceDesignator)newelem);
            };
            if (!ReadCollection(reader, adderextresources, "referenced-resources", "resource"))
                this._externalResources=null;

            this._signature=(ISingleFileProduct)ReadSerializable(reader, "signature");
            reader.ReadEndElement();
            this.SetAsKnownProject(oldGuid);
        }

        /// <summary>
        /// Write an XML serialization to the provided XML writer that can be read by ReadXml().
        /// </summary>
        /// <param name="writer">This will write the serialization to this destination.</param>
        public override void WriteXml(System.Xml.XmlWriter writer)
        {
            writer.WriteStartElement("csharp-assembly-project");
            this.WriteStdAttributes(writer);
            writer.WriteElementString("description", this._description);
            this.WriteProject(writer);

            if (this._mainClass != null)
            {
                writer.WriteElementString("main-class", this._mainClass);
            }
            WriteSerializable(writer, this._winIcon, "win-icon");
            WriteSerializable(writer, this._assemblyFile, "target");
            WriteSerializable(writer, this._csharpsources, "csharp-sources");
            WriteSerializable(writer, this._referencedAssemblies, "references");
            WriteSerializable(writer, this._pInvokeDependencies, "pinvoke-references");
            WriteCollectionOfSerializables(writer, this._resources, "resources", "resource");
            WriteCollectionOfSerializables(writer, this._externalResources, "referenced-resources", "resource");
            WriteSerializable(writer, this._signature, "signature"); 
            writer.WriteEndElement();
        }
        #endregion
    }
}

namespace wx.Build.Cxx
{
    /// <summary>This project creates a dynamically linkable program library in that standard according to the content type of the target definition.
    /// Targets may be of the type ContentType.Elf, ContentType.WindowsDll, or ContentType.WindowsGuiDll.</summary>
    /// <remarks>Please note, that this project creates alternative plans for each content type with
    /// ContentFileProperties.NativeCodeObject.</remarks>
    public class DynamicLibraryProject : SingleFileProject
    {
        #region State
        ContentFile _target;
        string _description;

        FileProducts _cSourceFiles = new FileProducts(ContentType.CCode);
        FileProducts _cppSourceFiles = new FileProducts(ContentType.CPlusPlusCode);
        FileProducts _headerFiles = new FileProducts(ContentType.CCPlusPlusInclude);

        FileProducts _rcFiles = new FileProducts(ContentType.RCFile);

        FileProducts _staticLibraries = new FileProducts(ContentType.StaticLib);

        IBuildAction _actions = null;
        #endregion

        #region CTor
        /// <summary>
        /// Creates an empty project without a name that will not be offered to the user.
        /// Use this only in conjunction with <c>ReadXml()</c> to create an isntance that
        /// afterwards reads its content from an XML stream.
        /// </summary>
        public DynamicLibraryProject() : base(null, ProjectPreference.DoNotOffer, "")
        {
        }

        /// <summary>
        /// Copy CTor.
        /// </summary>
        /// <param name="src">The source</param>
        public DynamicLibraryProject(DynamicLibraryProject src) : base(null, src.Preference, src.Name)
        {
            this._cppSourceFiles = new FileProducts(src._cppSourceFiles);
            this._cSourceFiles = new FileProducts(src._cSourceFiles);
            this._headerFiles = new FileProducts(src._headerFiles);
            this._description = src._description;
            this._rcFiles = new FileProducts(src._rcFiles);
            this._staticLibraries = new FileProducts(this._staticLibraries);
            this._target = new ContentFile(src._target);
        }

        /// <summary>Creates a project to build a file of the provided basename <c>dllBaseName</c>.
        /// This CTor will derive a type depending on the
        /// current platform. On Windows, this project will produce an ContentType.WindowsGuiDll file on an empty type.
        /// </summary>
        /// <param name="name">is the name of the project and will be used whenever the build system asks the user for a decision.</param>
        /// <param name="outputDir">is the directory where this project will put out its targets.</param>
        /// <param name="dllBaseName"> is the basename of the file that shall be created without extension or prefixes like "lib" etc.
        /// This name will be expanded to the name of the target referring to the desired content \c type.</param>
        /// <param name="description">is a descriptive text that will be displayed to users of the system to explain the purpose of this project.</param>
        public DynamicLibraryProject(ProjectPreference preference, string name, string outputDir, string dllBaseName, string description)
            : this(preference, name, null, outputDir, dllBaseName, description)
        {
        }

        /// <summary>
        /// Reads the platform independent basename of a DLL from a dll filename.
        /// </summary>
        /// <remarks>Examples:
        /// <list type="table">
        /// <listheader><term>Argument</term><description>Result</description></listheader>
        /// <item><term>wx-c.dll</term><description>wx-c</description></item>
        /// <item><term>wx-c.dylib</term><description>wx-c</description></item>
        /// <item><term>libwx-c.so</term><description>wx-c</description></item>
        /// <item><term>wx-c</term><description>wx-c</description></item>
        /// </list>
        /// </remarks>
        /// <param name="filename">Either a filename denoting a DLL or ELF library or already platform independent basename.</param>
        /// <returns>The platform independent basename that may be used e.g. in <c>DllImport</c> statements.</returns>
        public static string GetDllBasename(string filename)
        {
            string testFilename = filename.ToLower();
            if (testFilename.EndsWith(".dll"))
                return filename.Substring(0, filename.Length - 4);
            else if (testFilename.EndsWith(".dylib"))
                return filename.Substring(0, filename.Length - 6);
            else if (testFilename.EndsWith(".so") && testFilename.StartsWith("lib"))
                return filename.Substring(3, filename.Length - 6);
            else
                return filename;
        }

        /// <summary>Creates a project to build a file of the provided basename \c dllBaseName.</summary>
        /// <param name="name"> is the name of the project and will be used whenever the build system asks the user for a decision.</param>
        /// <param name="type"> is the content type of the desired target. This may be either ContentType.Elf, ContentType.WindowsDll.
        ///        ContentType.WindowsGuiDll, or \c null. If this type is \c null, this CTor will derive a type depending on the
        ///        current platform. On Windows, this project will produce an ContentType.WindowsGuiDll file on an empty type.</param>
        /// <param name="outputDir"> is the directory where this project will put out its targets.</params>
        /// <param name="dllBaseName"> is the basename of the file that shall be created without extension or prefixes like "lib" etc.
        ///        This name will be expanded to the name of the target referring to the desired content \c type.
        ///        <para>This may also be a filename of the form "wx-c.lib", "wx-c.dylib", or "libwx-c.so" that are used
        ///        as platform specific filenames for dynamic libraries. In such cases, the basename will be extracted.</para>
        ///        </param>
        /// <param name="description"> is a descriptive text that will be displayed to users of the system to explain the purpose
        ///        of this project.</param>
        public DynamicLibraryProject(ProjectPreference preference, string name, ContentType type, string outputDir, string dllBaseName, string description)
            : base(System.Reflection.Assembly.GetCallingAssembly(), preference, name)
        {
            this._description = description;
            if (type == null)
            {
                if (BuildConfig.IsWindows)
                    type = ContentType.WindowsGuiDll;
                else if (BuildConfig.IsMacOsX)
                    type = ContentType.MacDylib;
                else
                    type = ContentType.Elf;
            }

            dllBaseName = GetDllBasename(dllBaseName);

            string targetname=System.IO.Path.Combine(outputDir, dllBaseName);
            if (type == ContentType.Elf)
                targetname = System.IO.Path.Combine(outputDir, string.Format("lib{0}.so", dllBaseName));
            else if (type == ContentType.MacDylib)
                targetname = targetname + ".dylib";
            else
                targetname = targetname + ".dll";
            this._target = new ContentFile(type, targetname);
        }

        /// <summary> This will add the arguments to the collection of files that will be compiled in C++ mode.
        /// Please note, that exceptions will be raised on incompatible content types.</summary>
        /// <param name="src">Collection of content files that shall be of ContentType.CPlusPlusCode.</param>
        public void AddCPlusPlusSources(IFileProducts src)
        {
            if (src != null)
                this._cppSourceFiles.Add(src);
        }

        /// <summary> This will add the arguments to the collection of files that will be compiled in C mode.
        /// Please note, that exceptions will be raised on incompatible content types.</summary>
        /// <param name="src">Collection of content files that shall be of ContentType.CCode.</param>
        public void AddCSources(IFileProducts src)
        {
            if (src != null)
                this._cSourceFiles.Add(src);
        }

        /// <summary>
        /// Thsi will add the arguments to the collections of files that will be distributed with all other 
        /// sources of the project as C/C++ header files. You will have to set this in order to produce
        /// compilable project packages.
        /// </summary>
        /// <param name="src">Collection of content files that shall be of ContentType.CCPlusPlusInclude.</param>
        public void AddHeaderFiles(IFileProducts src)
        {
            if (src != null)
                this._headerFiles.Add(src);
        }

        /// <summary> Use this method to add all static library files that are required by this project.</summary>
        /// <remarks> Please note, that you have to add files for all compilers that are supported.
        /// Otherwise, linker errors referring to undefined symbols will result, if the build
        /// system uses a compiler/linker where some of  the required libraries are unknown.
        ///
        /// The term "static library" here means files that are passed to the linker in order to
        /// link object files and libraries to an application program. In this sence, ELF libraries
        /// are also static libraries since they are passed directly to the linker that creates stubs
        /// for the functions provided by the ELF library.
        ///
        /// Typically, classes of static libraries will be bundled as targets of project like
        /// wx.Build.Cxx.wxWidgets. Such projects typically supply all known formats of static
        /// libraries as targets.
        /// </remarks>
        public void AddStaticLibrary(IFileProducts src)
        {
            if (src != null)
                this._staticLibraries.Add(src);
        }

        /// <summary> Adds a ContentType.RCFile to the sources of this project.</summary>
        /// <remarks>Please note, that these sources will only be used with Windows executables.
        /// So, users have to take care that either the content of this files is optional (like version
        /// information to be displayed in the Windows file explorer) or the mandatory input is replaced
        /// by other sources when compiling the code on other platforms.
        /// </remarks>
        public void AddRCFile(IFileProducts src)
        {
            if (src != null)
                this._rcFiles.Add(src);
        }
        #endregion

        #region BuildProject
        public override string Description
        {
            get { return this._description; }
        }

        /// <summary> The target of this project.</summary>
        /// <remarks> This is a content file of type wx.BuildSystem.ContentType.WindowsDll or related types.</remarks>
        public ContentFile Target
        {
            get
            {
                return this._target;
            }
        }

        /// <summary>
        /// Creates an action plan (a collection of alternative actions) that can be taken to create the targets of this project.
        /// </summary>
        /// <param name="env">Parameters that are shared between tools of the same family.</param>
        /// <returns></returns>
        /// <remarks>Please note, that this project creates alternative plans for each content type with
        /// ContentFileProperties.NativeCodeObject.</remarks>
        public override ICollection<IBuildAction> CreateActionPlan(BuildToolFamilyEnv env)
        {
            if (this._actions == null)
            {
                TempFilesParameters tempFile = (TempFilesParameters)BuildConfig.GetDefaultParameterOfType(typeof(TempFilesParameters));
                Dictionary<ContentFile, IBuildAction> rcObjToSource = new Dictionary<ContentFile, IBuildAction>();
                if (BuildConfig.IsWindows && this.RCFiles.Count > 0)
                {
                    ICollection<ContentType> typesOfWinRes = ContentType.FindContentTypes(ContentFileProperties.WindowsResourceObject);
                    foreach (ContentType typeOfWinRes in typesOfWinRes)
                    {
                        foreach (ContentFile rcFile in this.RCFiles)
                        {
                            ContentFile resFile = tempFile.CreatePathFor(rcFile.FileName, typeOfWinRes);
                            CollectionOfBuildActions rcCompiler = BuildConfig.ActionsProducing(this, env, resFile, new IBuildProduct[] { rcFile });
                            if (rcCompiler.Count == 1)
                                rcObjToSource[resFile] = rcCompiler.GetOneAction();
                            else
                                rcObjToSource[resFile] = new AlternativeBuildActions(resFile, rcCompiler);
                        }
                    }
                }

                CollectionOfBuildActions actions = new CollectionOfBuildActions();
                List<ContentFile> sources = new List<ContentFile>();
                sources.AddRange(this.CPlusPlusSources);
                sources.AddRange(this.CSources);

                string nameOfAlternative=null;

                ICollection<ContentType> typesOfObjects = ContentType.FindContentTypes(ContentFileProperties.NativeCodeObject);
                foreach (ContentType typeOfObjects in typesOfObjects)
                {
                    ActionPriority prioOverallAction = ActionPriority.Fallback;
                    SequenceOfBuildActions overallAction = new SequenceOfBuildActions();
                    List<IBuildProduct> objfiles = new List<IBuildProduct>();
                    foreach (ContentFile src in sources)
                    {
                        ContentFile obj = tempFile.CreatePathFor(src.FileName, typeOfObjects);
                        objfiles.Add(obj);
                        CollectionOfBuildActions compiler = BuildConfig.ActionsProducing(this, env, obj, new IBuildProduct[] { src });
                        if (compiler.Count == 0)
                        {
                            BuildConfig.HandleErrorObject(new ErrorObject(ErrorObject.MessageType.Message, "Can not find an applicable compiler to create {0} from {1}.", obj, src));
                            overallAction = null;
                            break;
                        }
                        if (compiler.Count == 1)
                            overallAction.Add(compiler.GetOneAction());
                        else
                            overallAction.Add(new AlternativeBuildActions(obj, compiler));
                        ActionPriority prioCompiler=compiler.MostImportantPriority;
                        if (prioCompiler < prioOverallAction)
                            prioOverallAction = prioCompiler;
                    }
                    if (overallAction != null)
                    {
                        if (this._staticLibraries != null)
                        {
                            foreach (ContentFile staticLib in this._staticLibraries.Files)
                            {
                                if (staticLib.Type.Contains(ContentType.StaticLib))
                                    throw new Exception(string.Format("On static library {0} only type info {1} is known. Linkers will not know whether to apply this file or not. Try to be more specific assigning a type to this file.", staticLib.FileName, staticLib.Type));
                                objfiles.Add(staticLib);
                            }
                        }
                        
                        if (rcObjToSource.Count > 0)
                        {
                            foreach(ContentFile resFile in rcObjToSource.Keys)
                                objfiles.Add(resFile);
                        }
                        CollectionOfBuildActions linker = BuildConfig.ActionsProducing(this, env, this._target, objfiles);
                        if (linker.Count == 0)
                        {
                            BuildConfig.HandleErrorObject(new ErrorObject(ErrorObject.MessageType.Error, "Can not find an applicable linker to create {0} from {1}.", this._target, typeOfObjects));
                            overallAction = null;
                        }
                        else if (BuildConfig.IsWindows && this.RCFiles.Count > 0)
                        {
                            #region Add Actions to compile resources
                            foreach(ActionPriority prioLinker in linker.ActionPriorities)
                                foreach (IBuildAction linkerAction in linker[prioLinker])
                                {
                                    SequenceOfBuildActions rcCompilation = new SequenceOfBuildActions();
                                    foreach (IBuildProduct prereq in linkerAction.GetPrerequisites())
                                    {
                                        if (prereq is IFileProducts)
                                        {
                                            foreach (ContentFile filePrereq in ((IFileProducts)prereq).Files)
                                            {
                                                if (rcObjToSource.ContainsKey(filePrereq))
                                                    rcCompilation.Add(rcObjToSource[filePrereq]);
                                            }
                                        }
                                    }
                                    if (rcCompilation.Count == 0)
                                        overallAction.Add(linkerAction);
                                    else
                                    {
                                        rcCompilation.Add(linkerAction);
                                        overallAction.Add(rcCompilation);
                                    }
                                    if (prioLinker < prioOverallAction)
                                        prioOverallAction = prioLinker;
                                }
                            #endregion 
                        }
                        #region Add the linker without any kind of RC compilation
                        else if (linker.Count == 1)
                        {
                            IBuildAction oneLinker = linker.GetOneAction();
                            overallAction.Add(oneLinker);
                        }
                        else
                            overallAction.Add(new AlternativeBuildActions(this._target, linker));
                        #endregion

                        #region Set name of alternative
                        if (linker.Count > 0)
                            nameOfAlternative = linker.GetOneAction().ActionProvider.ToolFamily;
                        else
                            nameOfAlternative = null;
                        #endregion
                    }
                    if (overallAction != null)
                    {
                        if (nameOfAlternative == null)
                        {
                            if (overallAction.Count == 1)
                                actions.Add(overallAction[0]);
                            else
                                actions.Add(prioOverallAction, overallAction);
                        }
                        else
                        {
                            IBuildAction namedAction = null;
                            if (overallAction.Count == 1)
                            {
                                namedAction = new NamedAction(nameOfAlternative, overallAction[0]);
                                actions.Add(namedAction);
                            }
                            else
                            {
                                namedAction = new NamedAction(nameOfAlternative, overallAction);
                                actions.Add(prioOverallAction, namedAction);
                            }
                        }
                    }
                }
                if (actions.Count == 0)
                    BuildConfig.HandleErrorObject(ErrorObject.MessageType.Error, "Project {0} failed to create plan for {1}.", this.Name, this._target.FileName);
                else if (actions.Count == 1)
                    this._actions = actions.GetOneAction();
                else
                    this._actions = new AlternativeBuildActions("CppDevelopmentSystem", this._target, actions);
            }

            if (this._actions == null)
               return null;
            return new IBuildAction[] { this._actions };
        }

        public override ICollection<IBuildProduct> GetTargets()
        {
            List<IBuildProduct> result = new List<IBuildProduct>();
            result.Add(this._target);
            return result;
        }

        public override ICollection<IBuildProduct> GetPrerequisites()
        {
            List<IBuildProduct> result = new List<IBuildProduct>();
            result.Add(this._cppSourceFiles);
            result.Add(this._cSourceFiles);
            result.Add(this._headerFiles);
            result.Add(this._rcFiles);
            result.Add(this._staticLibraries);
            return result;
        }

        /// <summary>
        /// This will make the project instance ready to be solved.
        /// The build system will only use one project instance per target.
        /// Thus, projects will be registered. This will try to register this instance.
        /// If the database of registered project already contains a project instance
        /// for the targets of this instance, this will return this instance.
        /// </summary>
        /// <returns></returns>
        public new DynamicLibraryProject GetSingleton()
        {
            return (DynamicLibraryProject)((BuildProject)this).GetSingleton();
        }
        #endregion

        #region Prerequisites
        /// <summary>
        /// Returns the collection of C++ source files.
        /// </summary>
        public ContentFiles CPlusPlusSources { get { return this._cppSourceFiles.Files; } }

        /// <summary> Returns the collection of C source files.</summary>
        public ContentFiles CSources { get { return this._cSourceFiles.Files; } }

        /// <summary>
        /// Collection of C/C++ header files that will be distributed together with the other
        /// sources of this project.
        /// </summary>
        public ContentFiles CCPlusPlusHeaders { get { return this._headerFiles.Files; } }

        /// <summary> Returns required static libraries.</summary>
        /// <remarks> Please note, that this will return all static libraries built for all known compilers if they
        /// are required by this project. Refer to the content type to analyze the format of the returned
        /// file designators.
        /// </remarks>
        public ContentFiles StaticLibraries { get { return this._staticLibraries.Files; } }

        /// <summary> A collection of RC files that have been provided to this project to define Windows version information or Windows binary resources.</summary>
        /// <remarks> Please note, that these sources will only be used with Windows. Those parts of the system that are built of these sources
        /// shall either be optional or must be replaced by other (conditionally compiled) sources when compiling for other platforms.</remarks>
        public ContentFiles RCFiles { get { return this._rcFiles.Files; } }
        #endregion

        #region Overloads of Xml-serialization
        public override void ReadXml(System.Xml.XmlReader reader)
        {
            this._actions = null;
            reader.IsStartElement("native-dll-project");
            Guid oldGuid = this.Id;
            this.ReadStdAttributes(reader);
            reader.Read();

            this._description = reader.ReadElementString("description");
            reader.ReadStartElement("target");
            this._target = new ContentFile();
            this._target.ReadXml(reader);
            reader.ReadEndElement();
            this.ReadProject(reader);
            this._cppSourceFiles = (FileProducts)ReadSerializable(reader, "cpp-sources");
            this._cSourceFiles = (FileProducts)ReadSerializable(reader, "c-sources");
            this._headerFiles = (FileProducts)ReadSerializable(reader, "c-cpp-headers");
            this._rcFiles = (FileProducts)ReadSerializable(reader, "rc-files");
            this._staticLibraries = (FileProducts)ReadSerializable(reader, "libs");
            reader.ReadEndElement();

            this.SetAsKnownProject(oldGuid);
        }

        public override void WriteXml(System.Xml.XmlWriter writer)
        {
            writer.WriteStartElement("native-dll-project");
            this.WriteStdAttributes(writer);
            writer.WriteElementString("description", this._description);
            writer.WriteStartElement("target");
            this._target.WriteXml(writer);
            writer.WriteEndElement();
            this.WriteProject(writer);
            WriteSerializable(writer, this._cppSourceFiles, "cpp-sources");
            WriteSerializable(writer, this._cSourceFiles, "c-sources");
            WriteSerializable(writer, this._headerFiles, "c-cpp-headers");
            WriteSerializable(writer, this._rcFiles, "rc-files");
            WriteSerializable(writer, this._staticLibraries, "libs");
            writer.WriteEndElement();
        }
        #endregion

        public override object Clone()
        {
            return new DynamicLibraryProject(this);
        }
    }
}

