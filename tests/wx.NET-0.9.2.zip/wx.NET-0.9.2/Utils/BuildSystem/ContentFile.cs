/** Build system for wx.NET.
 * 
 * This DLL contains basic implementations to build (compile and link) C/C++ programs,
 * compile .NET assemblies written in C#, sign them, and install them.
 * 
 * \file 
 *
 * Copyright 2009 Harald Meyer auf'm Hofe harald_meyer@users.sourceforge.net
 * 
 * Licensed under the wxWidgets license, see LICENSE.txt for details.
 * 
 * $Id: ContentFile.cs,v 1.17 2010/06/06 09:00:04 harald_meyer Exp $
 */

using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Text;

namespace wx.Build
{
    /** <summary> Represents the location of a ContentFile. </summary> */
    public enum ContentFileLocation
    {
        /** <summary> The file name exists in the local file system.
         * The file name will be normalized to a full path name.
         * Validity will be determined according the last write access
         * to the file. </summary> */
        LocalFileSystem,

        /** <summary> The file name is considered to denote an assembly from the global assembly cache.
         * The validity will be mapped to the version of the assembly that will be read with
         * <c>System </c> .Runtime.Assembly.LoadFile(). </summary> */
        GlobalAssemblyCache,

        /** <summary> The filename is relative to a configured directory.
         * This option is for instance required providing static libs to linkers as simple filenames.
         * Such files will typically be searched in configured directories.
         * 
         * All services of this instance referring to properties of the file on the local file
         * system are not available if this is used. </summary> */
        InConfiguredDirectories,
    }

    /** <summary> Designates a build object consisting of a file comprising content of a particular type.
     * 
     * This is of course also a ISingleFileProduct where nothing has to be done in order to create
     * the ContentFile.
     * 
     * Typically, this assumes the designated file to exist and to be located in the local file system.
     * However, you may define some other locations. This will take effect expecially on the <c>Validity</c>.
     * </summary>
     */
    public class ContentFile : ISingleFileProduct, System.Xml.Serialization.IXmlSerializable, ICloneable
    {
        #region State
        ContentType _type;
        string _filename;
        string _originalFilename;
        ContentFileLocation _location;
        #endregion

        #region CTor
        /// <summary>
        /// Copy-CTor
        /// </summary>
        /// <param name="src">The source.</param>
        public ContentFile(ContentFile src)
        {
            this._filename = src._filename;
            this._location = src._location;
            this._originalFilename = src._originalFilename;
            this._type = src._type;
        }

        /** <summary> This will create an instance designating a file at the provided location.
         * </summary>
         * <param name="type">is the content type of the described file.</param>
         * <param name="filename"> is the path to the designated file in the local filesystem.</param>
         * <param name="location"> provides the location of the file, i.e. whether the file is in the local filesystem, the GAC
         * or an installation package.</param>
         */
        public ContentFile(ContentType type, ContentFileLocation location, string filename)
        {
            this._type = type;
            this._location = location;
            this._originalFilename = filename;
            if (this._location == ContentFileLocation.LocalFileSystem)
                this._filename = BuildConfig.GetFullPathname(filename);
            else
                this._filename = filename;
        }

        /** <summary> This will create an instance designating a local file.
         * </summary>
         * <param name="type">is the content type of the described file.</param>
         * <param name="filename"> is the path to the designated file in the local filesystem.</param>
         * <seealso cref="ContentFileLocation.LocalFileSystem"/>
         */
        public ContentFile(ContentType type, string filename)
            : this(type, ContentFileLocation.LocalFileSystem, filename)
        {
        }

        /// <summary>
        /// Default CTor. User only with ReadXml().
        /// </summary>
        /// <seealso cref="ReadXml"/>
        public ContentFile()
        {
            this._location = ContentFileLocation.LocalFileSystem;
            this._type = null;
            this._filename = null;
            this._originalFilename = null;
        }

        /// <summary>
        /// Creates an instance. Reads all properties from the argument.
        /// This source of information shall have been written by WriteXml().
        /// </summary>
        /// <param name="reader">The source</param>
        /// <seealso cref="ReadXml"/>
        public ContentFile(System.Xml.XmlReader reader) : this()
        {
            this.ReadXml(reader);
        }


        #endregion

        #region Public Properties
        /// <summary>
        /// A location classifier: Specifies whether this is on the local file system or another data source like the internet
        /// or the global assembly space.
        /// </summary>
        public ContentFileLocation Location { get { return this._location; } }

        /// <summary>
        /// The type of the content file.
        /// </summary>
        public ContentType Type { get { return this._type; } }

        /// <summary>
        /// The filename (in fact the root filename including full directory path information).
        /// </summary>
        public string FileName { get { return this._filename; } }

        /// <summary>
        /// Returns an array of directory names. This will collect all basenames of directory names of the argument.
        /// </summary>
        /// <param name="pathName">The original path that will be divided.</param>
        /// <returns></returns>
        /// <example>
        /// Argument "/basedir/subdir/filename.ext" will result into
        /// ["basedir", "subdir"]
        /// </example>
        public static string[] GetDirectories(string fileName)
        {
            fileName = BuildConfig.GetFullPathname(fileName);
            List<string> result = new List<string>();
            string dirName=System.IO.Path.GetDirectoryName(fileName);
            do
            {
                string thisDirName = System.IO.Path.GetFileName(dirName);
                if (thisDirName.Length == 0)
                    break;
                result.Insert(0, thisDirName);
                dirName = System.IO.Path.GetDirectoryName(dirName);
            }
            while (dirName != null && dirName.Length > 0);
            return result.ToArray();
        }

        /// <summary>
        /// Returns a list of directories designating the deepest common directory
        /// containing the files from the argument list.
        /// </summary>
        /// <param name="fileName1">The first file defining common directories</param>
        /// <param name="fileName2">The second file defining common dierctories</param>
        /// <example>
        /// This will return \c ["basdir", "subdir"] to the files \c "\basedir\subdir\subsubdir1\file.ext" and
        /// \c "\basedir\subdir\subsubdir2\file.ext".
        /// 
        /// The result to the files "C:\basedir\subdir\subsubdir1\file.ext" and
        /// \c "D:\basedir\subdir\subsubdir2\file.ext" will be empty.
        /// </example>
        /// <returns></returns>
        public static string[] GetCommonDirectories(string fileName1, string fileName2)
        {
            string[] dirs1 = GetDirectories(fileName1);
            string[] dirs2 = GetDirectories(fileName2);
            List<string> result = new List<string>();
            for(int i=0; i < dirs1.Length && i < dirs2.Length; ++i)
            {
                if (dirs1[i].Equals(dirs2[i]))
                    result.Add(dirs1[i]);
                else
                    break;
            }
            return result.ToArray();
        }

        /// <summary>
        /// True iff the result of GetCommonDirectories() is not empty.
        /// </summary>
        /// <param name="fileName1">The first file defining common directories</param>
        /// <param name="fileName2">The second file defining common dierctories</param>
        /// <see cref="GetCommonDirectories"/>
        /// <returns></returns>
        public static bool HasCommonDirectories(string fileName1, string fileName2)
        {
            if (BuildConfig.NotWindows)
            {
                return GetCommonDirectories(fileName1, fileName2).Length > 0;
            }
            else
                // We will not count the volume descriptor. Otherwise all files
                // within the same volume would share a common directory.
                return GetCommonDirectories(fileName1, fileName2).Length > 1;
        }

        /// <summary>
        /// Returns the provided filename as string. All contained backslashes and double quotes will be
        /// backquoted.
        /// </summary>
        /// <param name="filename">The filename that shall be converted.</param>
        /// <returns></returns>
        public static string ConvertFilenameToBooString(string filename)
        {
            if (filename.StartsWith(TempFilesParameters.BuildDir))
                filename = "${BuildDir}" + filename.Substring(TempFilesParameters.BuildDir.Length);
            else if (filename.StartsWith(BuildConfig.PathRoot))
                filename = string.Format("${{{0}}}{1}", BuildConfig.PathRootVariable, filename.Substring(BuildConfig.PathRoot.Length));
            return ConvertFilenameToString(filename);
        }

        /// <summary>
        /// Returns the provided filename as string. All contained backslashes and double quotes will be
        /// backquoted.
        /// </summary>
        /// <param name="filename">The filename that shall be converted.</param>
        /// <returns></returns>
        public static string ConvertFilenameToString(string filename)
        {
            string result = filename;
            result = result.Replace("\\", "\\\\");
            result = result.Replace("\"", "\\\"");
            return result;
        }

        /// <summary>
        /// Returns the original filename as a string that can be used in the BOO export. All contained backslashes and double quotes will be
        /// backquoted.
        /// </summary>
        public string FileNameAsBooString
        {
            get
            {
                if (this.Location == ContentFileLocation.GlobalAssemblyCache)
                    return this._originalFilename;
                else
                    return ConvertFilenameToBooString(this._originalFilename);
            }
        }

        /// <summary>
        /// This will quote the argument in such a way that ist can be passed as an option to programs started via the locally used shell interpreter.
        /// </summary>
        /// <param name="filename">The filename that will be quoted.</param>
        /// <returns>A string that contains the argument but quoted according to conventions related to the current platform.</returns>
        public static string QuoteFileName(string filename)
        {
            if (BuildConfig.NotWindows)
            {
                return filename.Replace("\\", "\\\\")
                    .Replace(" ", "\\ ");
            }
            else
                return string.Format("\"{0}\"", filename);
        }

        /// <summary>
        /// Returns the filename in a form suitable to be passed as part of an option to a program via the relevant shell command.
        /// This depends of cource on the current platform.
        /// </summary>
        public string QuotedFileName
        {
            get
            {
                return QuoteFileName(this._filename);
            }
        }

        /// <summary>
        /// The directory name of the filename as returned by System.IO.Path.GetDirectoryName().
        /// </summary>
        public string DirectoryName { get { return System.IO.Path.GetDirectoryName(this._filename); } }

        /// <summary>
        /// The base filename of this content file as returned by System.IO.GetFileName().
        /// </summary>
        public string BaseFileName
        {
            get
            {
                return System.IO.Path.GetFileName(this._filename);
            }
        }

        /// <summary>
        /// The original filename that has been passed to the CTor. The original filename is
        /// usually relative to the project directory. When serializing this, the
        /// original filename will be stored (in contrast to the absolute one).
        /// </summary>
        /// <seealso cref="NormalizeOriginalFileName"/>
        public string OriginalFileName { get { return this._originalFilename; } }

        /// <summary>
        /// This helper is used to implement variants of the NormalizeOriginalFileName() method.
        /// </summary>
        /// <param name="fullFilename">The full pathname that will be normalized.</param>
        /// <param name="nameOfAValidDirOrFile">This is the base of the normalization</param>
        /// <returns></returns>
        internal static string NormalizedFilename(string fullFilename, string nameOfAValidDirOrFile)
        {
            if (nameOfAValidDirOrFile != null)
            {
                nameOfAValidDirOrFile = BuildConfig.GetFullPathname(nameOfAValidDirOrFile);
                if (System.IO.File.Exists(nameOfAValidDirOrFile))
                    nameOfAValidDirOrFile = System.IO.Path.GetDirectoryName(nameOfAValidDirOrFile);
                else if (!System.IO.Directory.Exists(nameOfAValidDirOrFile))
                {
                    // nameOfAValidFileOrDirectory may be a file to be written. So, test the directory.
                    nameOfAValidDirOrFile = System.IO.Path.GetDirectoryName(nameOfAValidDirOrFile);
                    if (!System.IO.Directory.Exists(nameOfAValidDirOrFile))
                        throw new ArgumentException("Cannot normalize with unknown directory path.");
                }
                return TempFilesParameters.MakePathRelative(fullFilename, nameOfAValidDirOrFile);
            }
            return fullFilename;
        }

        /// <summary>
        /// You may use this method to control the form of the file name that will be used to
        /// serialize this (the original filename). The argument is a path to an existing
        /// file or directory. This will strip a directory information from this path. After
        /// that, the original file name will change to something equivalent to the absolute
        /// filename (referring to the same file) but now relative to the directory as specified
        /// by the argument.
        /// 
        /// Use this method to prepare content file instance for serialization in such a way
        /// that all file names become relative to the same directory.
        /// </summary>
        /// <param name="nameOfAValidDirOrFile">The name of an existing file or directory. This name
        /// will - if relative - be expanded using the BuildConfig. If this is <c>null</c>, this
        /// method will return without any effect. This may also be the name of a not yet existing file.
        /// In that case, however, the directory name shall exist.</param>
        /// <seealso cref="OriginalFileName"/>
        /// <exception cref="System.ArgumentException">Will be raised if the argument is neither the path
        /// to an existing file nor directory.</exception>
        public void NormalizeOriginalFileName(string nameOfAValidDirOrFile)
        {
            if (nameOfAValidDirOrFile != null)
            {
                nameOfAValidDirOrFile = BuildConfig.GetFullPathname(nameOfAValidDirOrFile);
                if (System.IO.File.Exists(nameOfAValidDirOrFile))
                    nameOfAValidDirOrFile = System.IO.Path.GetDirectoryName(nameOfAValidDirOrFile);
                else if (!System.IO.Directory.Exists(nameOfAValidDirOrFile))
                {
                    // nameOfAValidFileOrDirectory may be a file to be written. So, test the directory.
                    nameOfAValidDirOrFile = System.IO.Path.GetDirectoryName(nameOfAValidDirOrFile);
                    if (!System.IO.Directory.Exists(nameOfAValidDirOrFile))
                        throw new ArgumentException("Cannot normalize with unknown directory path.");
                }
                this._originalFilename = TempFilesParameters.MakePathRelative(this.FileName, nameOfAValidDirOrFile);
            }
        }

        /// <summary>
        /// Returns last write time or DateTime.MinValue if this does not exist.
        /// </summary>
        public DateTime GetValidity()
        {
            if (this._location == ContentFileLocation.LocalFileSystem)
            {
                if (System.IO.File.Exists(this._filename))
                    return System.IO.File.GetLastWriteTime(this._filename);
                else if (System.IO.Directory.Exists(this._filename))
                    return System.IO.Directory.GetLastWriteTime(this._filename);
                else
                    return DateTime.MinValue;
            }
            else
                return DateTime.MinValue;
        }

        /** <summary> Returns last write time or <c>DateTime </c> .MinValue if this does not exist. </summary> */
        public DateTime GetValidityDemand()
        {
            if (this._location == ContentFileLocation.LocalFileSystem)
            {
                if (System.IO.File.Exists(this._filename))
                    return System.IO.File.GetLastWriteTime(this._filename);
                else if (System.IO.Directory.Exists(this._filename))
                    return System.IO.Directory.GetLastWriteTime(this._filename);
                else
                    return DateTime.MaxValue;
            }
            else
                return DateTime.MaxValue;
        }

        /** <summary> If this is ContentFileLocation.LocalFileSystem, the result is <c>true </c>  iff the designated file exists.
        * Otherwise, this is undefined. </summary> */
        public bool Exists
        {
            get
            {
                if (this.Location == ContentFileLocation.LocalFileSystem)
                {
                    if (this.Type.Implies(ContentType.Directory))
                        return System.IO.Directory.Exists(this.FileName);
                    else
                        return System.IO.File.Exists(this.FileName);
                }
                return true;
            }
        }
        #endregion

        #region Overrides
        public int CompareTo(object o)
        {
            ContentFile arg = o as ContentFile;
            if (arg != null)
            {
                int cmp = 0;
                if (cmp == 0)
                    cmp = this.Type.CompareTo(arg.Type);
                if (cmp == 0)
                    cmp = this.FileName.CompareTo(arg.FileName);
                if (cmp == 0)
                    cmp = this._location.CompareTo(arg._location);
                return cmp;
            }
            else
                return this.GetType().FullName.CompareTo(o.GetType().FullName);
        }

        public override bool Equals(object obj)
        {
            if (obj is ContentFile)
            {
                ContentFile objFile = (ContentFile)obj;
                return this._filename.Equals(objFile.FileName) && this._type.Equals(objFile.Type) && this._location.Equals(objFile._location);
            }
            else
                return false;
        }

        public override int GetHashCode()
        {
            return this._filename.GetHashCode() ^ this._location.GetHashCode() ^ this._type.GetHashCode();
        }

        /// <summary>
        /// Compare referring to FileName, Type, and Location.
        /// </summary>
        /// <param name="f1">File descriptor 1</param>
        /// <param name="f2">File descriptor 2</param>
        /// <returns></returns>
        public static bool operator ==(ContentFile f1, ContentFile f2)
        {
            if (((object)f1) == null) return ((object)f2) == null;
            if (((object)f2) == null) return false;
            return f1.Equals(f2);
        }

        /// <summary>
        /// Compare referring to FileName, Type, and Location.
        /// </summary>
        /// <param name="f1">File descriptor 1</param>
        /// <param name="f2">File descriptor 2</param>
        /// <returns></returns>
        public static bool operator !=(ContentFile f1, ContentFile f2)
        {
            return !(f1 == f2);
        }

        public override string ToString()
        {
            if (this._location==ContentFileLocation.LocalFileSystem)
                return string.Format("File({0}:{1}/{2})", this._filename, this._type.Primary, this._type.Secondary);
            else
                return string.Format("{3}({0}:{1}/{2})", this._filename, this._type.Primary, this._type.Secondary, this._location);
        }
        #endregion

        #region ISingleFileProduct Member

        /** <summary> This returns <c>this </c>  ... this is its own file target. </summary> */
        public ContentFile File
        {
            get { return this; }
        }

        /** <summary> Returns <c>File </c> . </summary> */
        public ContentFiles Files
        {
            get { ContentFiles result = new ContentFiles(this.Type); result.Add(this.File); return result; }
        }

        /// <summary>
        /// A collection of contained files that are addressed explicitely as instances of ContentFiles or ContentFile.
        /// </summary>
        public ContentFiles ExplicitFiles
        {
            get
            {
                return this.Files;
            }
        }

        /// <summary>
        /// True if this equals or the provided build product.
        /// </summary>
        /// <param name="arg">The build product that will be searched</param>
        public bool Contains(IBuildProduct file)
        {
            return this.Equals(file);
        }

        /** <summary> This is always 1. </summary> */
        public int Count
        {
            get
            {
                return 1;
            }
        }

        public IFileProducts Replace(IFileProducts oldInstance, IFileProducts replacement)
        {
            if (this.Equals(oldInstance))
                return replacement;
            else
                return this;
        }
        #endregion

        #region IBuildProduct Member
        /** <summary> This instance is the target. </summary> */
        public ICollection<IBuildProduct> GetTargets()
        {
            List<IBuildProduct> result = new List<IBuildProduct>();
            result.Add(this);
            return result;
        }

        /** <summary> This returns <c>null </c>  because this does not imply build projects. </summary> */
        public ICollection<RefToProject> GetProjects()
        {
            return null;
        }

        /** <summary> Simply does nothing because the result, this instance, is not associated with a building step. </summary> */
        public bool Execute(BuildToolFamilyEnv env, DateTime validityOfBuildSystem)
        {
            return true;
        }

        #endregion

        #region IXmlSerializable Member
        /// <summary>
        /// Returns <c>null</c> as suggested by the framework documentation.
        /// </summary>
        /// <returns>null</returns>
        public System.Xml.Schema.XmlSchema GetSchema()
        {
            return null;
        }

        /// <summary>
        /// Reads all data from the argument stream.
        /// </summary>
        /// <param name="reader">The data source</param>
        /// <seealso cref="WriteXml"/>
        /// <exception cref="#FormatException">Will b raise on unexpected format.</exception>
        public void ReadXml(System.Xml.XmlReader reader)
        {
            if (!reader.IsStartElement() || reader.Name != "content_file")
                throw new FormatException("Expected content_file.");
            if (reader.HasAttributes)
            {
                string location=reader.GetAttribute("location");
                this._location = (ContentFileLocation)Enum.Parse(typeof(ContentFileLocation), location);
            }
            reader.Read();
            while (reader.IsStartElement())
            {
                string name=reader.Name;
                if (name == "content-type")
                {
                    this._type = ContentType.FromXml(reader);
                }
                else if (name == "filename")
                {
                    this._originalFilename = reader.ReadElementContentAsString();
                    this._filename = BuildConfig.GetFullPathname(this._originalFilename);
                }
                else
                {
                    // an attribute that we do not need
                    reader.ReadElementContentAsString();
                }
            }
            reader.ReadEndElement();
            if (this._filename == null)
                throw new FormatException("Missing filename reading content_file.");
            if (this._type == null)
                throw new FormatException("Missing content type reading content_file.");
            if (this._originalFilename == null)
                this._originalFilename = this._filename;
        }

        /// <summary>
        /// Writes the complete internal state into the argument.
        /// </summary>
        /// <param name="writer">the destination of the output.</param>
        /// <seealso cref="ReadXml"/>
        public void WriteXml(System.Xml.XmlWriter writer)
        {
            writer.WriteStartElement("content_file");
            writer.WriteAttributeString("location", this.Location.ToString());
            this.Type.WriteRefXml(writer);
            writer.WriteElementString("filename", this.OriginalFileName);
            writer.WriteEndElement();
        }

        #endregion

        #region ICloneable Member

        public object Clone()
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Static Utilities
        /// <summary>
        /// Returns the list of path components.
        /// </summary>
        /// <example>
        /// Argument "C:/root_directory/subdirectory/filename.ext" will be divided
        /// into the result "root_directory", "subdirectory", "filename.ext".
        /// </example>
        /// <param name="pathname">Pathname whose components will be inserted into the list.</param>
        /// <returns></returns>
        static IList<string> GetListOfPathComponents(string pathname)
        {
            pathname=BuildConfig.GetFullPathname(pathname);
            List<string> result = new List<string>();
            while (pathname != null && pathname.Length > 0)
            {
                string fn = System.IO.Path.GetFileName(pathname);
                pathname = System.IO.Path.GetDirectoryName(pathname);
                if (fn.Length > 0)
                    result.Insert(0, fn);
            }
            return result;
        }

        /// <summary>
        /// Returns the common base directory of both paths.
        /// Relative paths will be made absolute using the BuildConfig.RootPath.
        /// </summary>
        /// <param name="p1">Relative or absolute path.</param>
        /// <param name="p2">Relative or absolute path.</param>
        /// <returns></returns>
        static public string GetCommonBasePath(string p1, string p2)
        {
            string result="\\";
            IList<string> l1 = GetListOfPathComponents(p1);
            IList<string> l2 = GetListOfPathComponents(p2);
            IEnumerator<string> i1 = l1.GetEnumerator();
            IEnumerator<string> i2 = l2.GetEnumerator();
            while (i1.MoveNext() && i2.MoveNext())
            {
                if (i1.Current == i2.Current)
                    result = System.IO.Path.Combine(result, i1.Current);
                else
                    break;
            }
            return result;
        }

        /// <summary>
        /// All occurances of rooted path names will be made relative to the project root
        /// if possible. This will quote all backslashes and double quotes. Thus, you may
        /// use the result as a C# or BOO string constant.
        /// </summary>
        /// <param name="stringWithFiles">A string containing paths that shall be made relative.</param>
        /// <returns></returns>
        static public string ReplaceRootedPaths(string stringWithFiles)
        {
            string replPath = BuildConfig.PathRoot;
            string relPath = ".";
            while (replPath != null && replPath.Length > 0)
            {
                stringWithFiles = stringWithFiles.Replace(replPath, relPath);
                replPath = System.IO.Path.GetDirectoryName(replPath);
                if (relPath == ".")
                    relPath = "..";
                else
                    relPath = System.IO.Path.Combine("..", relPath);
            }
            stringWithFiles = stringWithFiles.Replace("\\", "\\\\");
            stringWithFiles = stringWithFiles.Replace("\"", "\\\"");
            return stringWithFiles;
        }
        #endregion
    }


    ///<summary> Designates a whole bunch of content files sharing the same content type.
    /// This is for instance useful in projects on linking that link objects from a whole number of sources together.
    /// This collection allows the declaration of projects that receive a whole number of files of the same type but
    /// of unknown number.
    /// </summary>
    /// <remarks>
    /// This always returns the least validity of a contained file. This, if only one contained file is missing, the
    /// validity will be \c DateTime.MinValue.
    /// <para>
    ///  Please note, that this container will preserve the order in which the items have been
    /// added. This is important for many purposes. For instance, the GCC as linker requires the user to specify
    /// libraries in an order that reflects dependencies between them. Otherwise, the linker will fail to resolve all
    /// symbols.
    /// </para>
    /// <para>
    /// Once created you may set this to be read-only. However, you will never set this to be writable again once it
    /// is for reading only. If this is read-only, all modifier will create exceptions.
    /// </para>
    /// <para>
    /// This is also a IFileProducts that returns this content files as target without being associated with a 
    /// building action.
    /// </para>
    /// </remarks>
    public class ContentFiles : IFileProducts, ICollection<ContentFile>, IEnumerable<ContentFile>, ICloneable
    {
        #region State
        ContentType _type;
        StringCollection _filenames = new StringCollection();
        StringCollection _originalFilenames = new StringCollection();
        List<ContentFileLocation> _locations = new List<ContentFileLocation>();
        /** <summary> Types of the contained files might be more specific than <c>_type </c> . </summary> */
        List<ContentType> _types = new List<ContentType>();
        bool _isReadOnly = false;
        #endregion

        #region CTor
        /// <summary>
        /// Use this to create an instance before using ReadXml().
        /// </summary>
        public ContentFiles() : this(ContentType.DotNetExe)
        {
        }

        /** <summary> This produces a collection of file designators on the local file system ContentFileLocation
         * .LocalFileSystem.</summary><remarks>
         * \param type is the common content type of all designated files. Please note, that this parameter will
         *    not take any effect if this is called without <c>files</c>.
         * \param files is a sequence of file names of type <c>type </c> . The file names may be relative to the directory
         *        of the entry assembly (not the current working directory). </remarks> */
        public ContentFiles(ContentType type, params string[] files) :
            this(type, ContentFileLocation.LocalFileSystem, files)
        {
        }

        /** <summary> This produces a collection of file designators on the local file system ContentFileLocation.LocalFileSystem.</summary><remarks>
         * \param type is the common content type of all designated files.
         * \param location specifies the location of the designated files. Usually, this will describe files in the
         *        local file system. However, content files may also be part of the globale assembly cache and other places.
         * \param files is a sequence of file names of type <c>type </c> . If the local file system holds the designated files,
         *        the file names may be relative to the directory
         *        of the entry assembly (not the current working directory). </remarks> */
        public ContentFiles(ContentType type, ContentFileLocation location, params string[] files)
        {
            this._type = type;
            if (files != null)
            {
                foreach (string file in files)
                {
                    if (location == ContentFileLocation.LocalFileSystem)
                        this._filenames.Add(BuildConfig.GetFullPathname(file));
                    else
                        this._filenames.Add(file);
                    this._originalFilenames.Add(file);
                    this._locations.Add(location);
                    this._types.Add(type);
                }
            }
        }

        /// <summary>
        /// Copy CTor
        /// </summary>
        /// <param name="src">Source</param>
        public ContentFiles(ContentFiles src)
        {
            this._type = src._type;
            this._isReadOnly = src._isReadOnly;
            foreach (ContentType t in src._types)
                this._types.Add(t);
            foreach (string name in src._filenames)
                this._filenames.Add(name);
            foreach (string name in src._originalFilenames)
                this._originalFilenames.Add(name);
            foreach (ContentFileLocation l in src._locations)
                this._locations.Add(l);
        }
        #endregion

        #region Public Properties
        /** <summary> Returns the collection locations of the contained files.
         * In arbitrary order. Each location appears at most once. </summary> */
        public ICollection<ContentFileLocation> Locations
        {
            get
            {
                Dictionary<ContentFileLocation, ContentFileLocation> locations = new Dictionary<ContentFileLocation, ContentFileLocation>();
                foreach (ContentFileLocation location in this._locations)
                {
                    locations[location] = location;
                }
                return locations.Values;
            }
        }

        /** <summary> The content type associated with the contained files.
         * This is in fact the least specific type that is guaranteed for all contained files.
         * The files may have more specific types. 
         * 
         * You may also set this type. However, the new type always shall contain the old one.
         * This is useful if you want to add a file that is not contained be the current type.
         * In that case, you may search for a type that implied the current type of this collection
         * and contains the type of the file you want to add. If you found such a type, you may
         * set it.
         * </summary>
         */
        public ContentType Type
        {
            get { return this._type; }
            set
            {
                if (this._type.Implies(value))
                {
                    this._type = value;
                }
                else
                {
                    throw new Exception(string.Format("Cannot replace {0} by {1} in collection of content files.", this._type.Name, value.Name));
                }
            }
        }

        /** <summary> A collection of the contained file names.
         * This is in fact a copy of the containes filenames in order to prevent undesired side effects. </summary> */
        public string[] Filenames
        {
            get
            {
                if (this.Count == 0)
                    return null;
                string[] result = new string[this.Count];
                int index = 0;
                foreach (string file in this._filenames)
                {
                    result[index]=file;
                    ++index;
                }
                return result;
            }
        }

        /** <summary> Returns the least significant validity of a contained file.
         * If only one of the contained files is missing, this will return <c>DateTime </c> .MinValue; </summary> */
        public DateTime GetValidity()
        {
            DateTime result = DateTime.MaxValue;
            for (int index = 0; index < this.Count; ++index)
            {
                string file = this._filenames[index];
                if (System.IO.File.Exists(file))
                {
                    if (this._locations[index] == ContentFileLocation.LocalFileSystem)
                    {
                        DateTime thisValidity = System.IO.File.GetLastWriteTime(file);
                        if (thisValidity < result)
                            result = thisValidity;
                    }
                    else
                        return DateTime.MinValue;
                }
                else
                    return DateTime.MinValue; // This can be returned directly.
            }
            return result;
        }

        /** <summary> Returns the most significant validity of a contained file.
         * If only one of the contained files is missing, this will return <c>DateTime </c> .MaxValue; </summary> */
        public DateTime GetValidityDemand()
        {
            DateTime result = DateTime.MinValue;
            for (int index = 0; index < this.Count; ++index)
            {
                string file = this._filenames[index];
                if (System.IO.File.Exists(file))
                {
                    if (this._locations[index] == ContentFileLocation.LocalFileSystem)
                    {
                        DateTime thisValidity = System.IO.File.GetLastWriteTime(file);
                        if (thisValidity > result)
                            result = thisValidity;
                    }
                    else
                        return DateTime.MinValue;
                }
                else
                    return DateTime.MinValue; // This can be returned directly.
            }
            return result;
        }
        #endregion

        #region ICollection<ContentFile> Member
        /** <summary>Adds the argument to the contained files.
         * This will raise an System.ArgumentException if this is read-only and a System.ArgumentException if
         * the content type of the argument is inconsistent (not equal or containaed by to Type).
         * Please note, that a file will appear twice in this list of it has been added twice.</summary>
         */
        public void Add(ContentFile item)
        {
            if (this._isReadOnly)
                throw new ArgumentException("Try to add to a read-only instance of ContentFiles.");
            if (!this._type.Contains(item.Type))
                throw new ArgumentException("Refusing to add file of inconsistent content to an instance of ContentFiles.");
            this._filenames.Add(item.FileName);
            this._originalFilenames.Add(item.OriginalFileName);
            this._locations.Add(item.Location);
            this._types.Add(item.Type);
        }

        /** <summary>Adds the designated file assuming consistent content type and a location in the local file system.
         * This will raise an System.ArgumentException if this is read-only.
         * Please note, that a file will appear twice in this list of it has been added twice.</summary>
         */
        public void Add(string filename)
        {
            if (this._isReadOnly)
                throw new ArgumentException("Try to add to a read-only instance of ContentFiles.");
            this._filenames.Add(BuildConfig.GetFullPathname(filename));
            this._originalFilenames.Add(filename);
            this._locations.Add(ContentFileLocation.LocalFileSystem);
            this._types.Add(this._type);
        }

        /** <summary>Adds all members of the argument.</summary>
         */
        public void AddRange(ICollection<ContentFile> files)
        {
            foreach (ContentFile file in files)
                this.Add(file);
        }

        /** <summary>Turns this into read-only mode.
         * You may run this on already read-only instances. In this cases, this will be a NOP.</summary>
         */
        public void SetReadOnly()
        {
            this._isReadOnly = true;
        }

        /** <summary> </summary>After this this collection does not contain any filename.
         * This will raise an System.ArgumentException if this is read-only.</summary> </summary> */
        public void Clear()
        {
            if (this._isReadOnly)
                throw new ArgumentException("Try to add to a read-only instance of ContentFiles.");
            this._filenames.Clear();
            this._originalFilenames.Clear();
            this._locations.Clear();
            this._types.Clear();
        }

        /** <summary>True if this contains a file of the provided name of the provided content type.</summary>
         */
        public bool Contains(ContentFile item)
        {
            if (this.Type.Equals(item.Type))
            {
                int index=this._filenames.IndexOf(item.FileName);
                if (index >= 0)
                    return this._locations[index]==item.Location;
                else
                    return false;
            }
            return false;
        }

        /** <summary>True iff this contains a file of the provided name at location ContentFileLocation.LocalFileSystem.</summary>
         */
        public bool Contains(string filename)
        {
            int index = this._filenames.IndexOf(filename);
            if (index >= 0)
                return this._locations[index] == ContentFileLocation.LocalFileSystem;
            else
                return false;
        }

        public void CopyTo(ContentFile[] array, int arrayIndex)
        {
            int index = 0;
            foreach (string file in this._originalFilenames)
            {
                if (arrayIndex >= array.Length)
                    break;
                array[arrayIndex] = new ContentFile(this._types[index], this._locations[index], file);
                ++arrayIndex;
                ++index;
            }
        }

        /** <summary>Returns the number of containes files.</summary>
         */
        public int Count
        {
            get { return this._filenames.Count; }
        }

        /** <summary>True iff this is readonly and all modifiers will raise an \c System.ApplicationException.</summary>
         */
        public bool IsReadOnly
        {
            get { return this._isReadOnly; }
        }

        /** <summary>Removes <c>item</c> from the containes file names if the content type of <c>item</c> complies.
         * Throws an System.ApplicationException, if this is read-only.</summary>
         * <returns> true if an item has been removed.</returns>
         */
        public bool Remove(ContentFile item)
        {
            if (this._isReadOnly)
                throw new ArgumentException("Try to add to a read-only instance of ContentFiles.");
            if (item.Type.Implies(this.Type))
            {
                int index = this._filenames.IndexOf(item.FileName);
                if (index != 0 && this._locations[index]==item.Location)
                {
                    this._filenames.RemoveAt(index);
                    this._locations.RemoveAt(index);
                    this._types.RemoveAt(index);
                    return true;
                }
                else
                    return false;
            }
            return false;
        }

        #endregion

        #region Public Methods

        /** <summary>This is one file that is contained.
         * If this is empty, te result is <c>null</c>.
         * Typically, this is the first filename that has been added.</summary>
         */
        public string GetOneFileName()
        {
            if (this._filenames.Count > 0)
                return this._filenames[0];
            else
                return null;
        }

        /** <summary>^This returns one of the contained files as ContentFile.
         * </summary>
         * <seealso cref="GetOneFileName"/>
         */
        public ContentFile GetOneFile()
        {
            return new ContentFile(this.Type, this._locations[0], this.GetOneFileName());
        }

        /** <summary>Returns a representation of this as list of content files.</summary>
         */
        public List<ContentFile> ToList()
        {
            List<ContentFile> result = new List<ContentFile>();
            for (int index=0; index < this.Count; ++index)
            {
                result.Add(new ContentFile(this._types[index], this._locations[index], this._originalFilenames[index]));
            }
            return result;
        }
        #endregion

        #region IEnumerable<ContentFile> Member
        public IEnumerator<ContentFile> GetEnumerator()
        {
            return this.ToList().GetEnumerator();
        }

        #endregion

        #region IEnumerable Member

        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            return this.GetEnumerator();
        }

        #endregion

        #region IFileProducts Member

        /** <summary>This return <c>this</c> ... this itself is the target.</summary>
         */
        public ContentFiles Files
        {
            get { return this; }
        }

        /// <summary>
        /// A collection of contained files that are addressed explicitely as instances of ContentFiles or ContentFile.
        /// </summary>
        public ContentFiles ExplicitFiles
        {
            get
            {
                return this;
            }
        }

        /// <summary>
        /// True if this equals or the provided build product or the product is among its targets.
        /// </summary>
        /// <param name="arg">The build product that will be searched</param>
        public bool Contains(IBuildProduct file)
        {
            if (file is ContentFiles)
                return this.Equals(file);
            if (file is ContentFile)
                return this.Contains((ContentFile)file);
            else
                return false;
        }

        public IFileProducts Replace(IFileProducts oldInstance, IFileProducts replacement)
        {
            if (this.Equals(oldInstance))
                return replacement;
            else if (this.Contains(oldInstance))
            {
                ContentFiles result = new ContentFiles(this.Type);
                foreach (ContentFile f in this)
                {
                    if (f.Equals(oldInstance))
                    {
                        if (replacement != null)
                            result.Add((ContentFile)replacement);
                    }
                    else
                        result.Add(f);
                }
                return result;
            }
            else
                return this;
        }

        /// <summary>
        /// You may use this method to control the form of the file name that will be used to
        /// serialize this (the original filename). The argument is a path to an existing
        /// file or directory. This will strip a directory information from this path. After
        /// that, the original file name will change to something equivalent to the absolute
        /// filename (referring to the same file) but now relative to the directory as specified
        /// by the argument.
        /// 
        /// Use this method to prepare content file instance for serialization in such a way
        /// that all file names become relative to the same directory.
        /// </summary>
        /// <param name="nameOfAValidDirOrFile">The name of an existing file or directory. This name
        /// will - if relative - be expanded using the BuildConfig. If this is <c>null</c>, this
        /// method will return without any effect. This may also be the name of a not yet existing file.
        /// In that case, however, the directory name shall exist.</param>
        /// <seealso cref="OriginalFileName"/>
        /// <exception cref="System.ArgumentException">Will be raised if the argument is neither the path
        /// to an existing file nor directory.</exception>
        public void NormalizeOriginalFileName(string nameOfAValidDirOrFile)
        {
            for (int i = 0; i < this._filenames.Count; ++i)
            {
                this._originalFilenames[i] = ContentFile.NormalizedFilename(this._filenames[i], nameOfAValidDirOrFile);
            }
        }
        #endregion

        #region IBuildProduct Member

        /** <summary>Creates a collection of build objects that is equivalent to the represented files.
         * This is useful when building collections of targets and preconditions.</summary>
         */
        public ICollection<IBuildProduct> GetTargets()
        {
            List<IBuildProduct> result = new List<IBuildProduct>();
            for (int index = 0; index < this.Count; ++index)
            {
                result.Add(new ContentFile(this._types[index], this._locations[index], this._originalFilenames[index]));
            }
            return result;
        }

        /** <summary>This returns <c>null</c> because this does not imply build projects.</summary>
        */
        public ICollection<RefToProject> GetProjects()
        {
            return null;
        }

        /** <summary>Simply does nothing.
         * Always reports success.</summary>
         */
        public bool Execute(BuildToolFamilyEnv env, DateTime validityOfBuildSystem)
        {
            return true;
        }

        #endregion

        #region Overrides
        public override bool Equals(object obj)
        {
            return this.CompareTo(obj) == 0;
        }

        public override int GetHashCode()
        {
            int result = 0;
            foreach (string filename in this._filenames)
                result = result ^ filename.GetHashCode();
            return result;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < this._filenames.Count; ++i)
            {
                if (sb.Length > 0)
                    sb.Append(",");

                if (this._locations[i] != ContentFileLocation.LocalFileSystem)
                {
                    sb.Append(this._locations[i].ToString());
                    sb.Append(":");
                }
                sb.Append(this._filenames[i]);
                if (this._types[i] != this.Type)
                    sb.AppendFormat(" : {0}.{1}", this._types[i].Primary, this._types[i].Secondary);
            }
            return sb.ToString();
        }

        public int CompareTo(object o)
        {
            if (o is ContentFiles)
            {
                ContentFiles arg = (ContentFiles)o;
                if (this.Count != arg.Count)
                    return this.Count.CompareTo(arg.Count);
                SortedDictionary<ContentFileLocation, SortedDictionary<string, int>> sortedThis = new SortedDictionary<ContentFileLocation, SortedDictionary<string, int>>();
                for (int i = 0; i < this.Count; ++i)
                {
                    if (!sortedThis.ContainsKey(this._locations[i]))
                        sortedThis.Add(this._locations[i], new SortedDictionary<string, int>());
                    sortedThis[this._locations[i]].Add(this._filenames[i], i);
                }
                SortedDictionary<ContentFileLocation, SortedDictionary<string, int>> sortedArg = new SortedDictionary<ContentFileLocation, SortedDictionary<string, int>>();
                for (int i = 0; i < arg.Count; ++i)
                {
                    if (!sortedThis.ContainsKey(arg._locations[i]))
                        sortedThis.Add(arg._locations[i], new SortedDictionary<string, int>());
                    sortedThis[arg._locations[i]][arg._filenames[i]]= i;
                }

                SortedDictionary<ContentFileLocation, SortedDictionary<string, int>>.Enumerator iThis = sortedThis.GetEnumerator();
                SortedDictionary<ContentFileLocation, SortedDictionary<string, int>>.Enumerator iArg = sortedArg.GetEnumerator();
                while (iThis.MoveNext() && iArg.MoveNext())
                {
                    if (iThis.Current.Key != iArg.Current.Key)
                        return iThis.Current.Key.CompareTo(iArg.Current.Key);
                    if (iThis.Current.Value.Count != iArg.Current.Value.Count)
                        return iThis.Current.Value.Count.CompareTo(iArg.Current.Value.Count);
                    SortedDictionary<string, int>.Enumerator iThisElem = iThis.Current.Value.GetEnumerator();
                    SortedDictionary<string, int>.Enumerator iArgElem = iArg.Current.Value.GetEnumerator();
                    while (iThisElem.MoveNext() && iArgElem.MoveNext())
                    {
                        int cmp = iThisElem.Current.Key.CompareTo(iArgElem.Current.Key);
                        if (cmp != 0)
                            return cmp;
                        cmp = this._types[iThisElem.Current.Value].CompareTo(arg._types[iArgElem.Current.Value]);
                        if (cmp != 0)
                            return cmp;
                    }
                }
                return 0;
            }
            else
                return this.GetType().FullName.CompareTo(o.GetType().FullName);
        }
        #endregion

        #region IXmlSerializable Member

        public System.Xml.Schema.XmlSchema GetSchema()
        {
            return null;
        }

        public void ReadXml(System.Xml.XmlReader reader)
        {
            this.Clear();
            reader.ReadStartElement("content-files");
            this._type = ContentType.FromXml(reader);
            while (reader.IsStartElement())
            {
                reader.ReadStartElement("file");
                string filename = reader.ReadElementString("name");
                ContentFileLocation l = (ContentFileLocation)Enum.Parse(typeof(ContentFileLocation), reader.ReadElementString("location"));
                ContentType t=ContentType.FromXml(reader);
                this.Add(new ContentFile(t, l, filename));
                reader.ReadEndElement();
            }
            reader.ReadEndElement();
        }

        public void WriteXml(System.Xml.XmlWriter writer)
        {
            writer.WriteStartElement("content-files");
            this._type.WriteRefXml(writer);
            for(int i=0; i < this._originalFilenames.Count; ++i)
            {
                string filename = this._originalFilenames[i];
                ContentType t = this._types[i];
                ContentFileLocation l = this._locations[i];

                writer.WriteStartElement("file");
                writer.WriteElementString("name", filename);
                writer.WriteElementString("location", l.ToString());
                t.WriteRefXml(writer);
                writer.WriteEndElement();
            }
            writer.WriteEndElement();
        }

        #endregion

        #region ICloneable Member

        public object Clone()
        {
            return new ContentFiles(this);
        }

        #endregion
    }
}
