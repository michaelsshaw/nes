/** Build system for wx.NET.
 * 
 * This DLL contains basic implementations to build (compile and link) C/C++ programs,
 * compile .NET assemblies written in C#, sign them, and install them.
 * 
 * \file 
 *
 * Copyright 2009-2010 Harald Meyer auf'm Hofe harald_meyer@users.sourceforge.net
 * 
 * Licensed under the wxWidges license, see LICENSE.txt for details.
 * 
 * $Id: MsNetTools.cs,v 1.23 2010/06/16 18:12:32 harald_meyer Exp $
 */



using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Win32;

/** Contains wrappers around Microsoft's .NET framework and SDK tools.
 */
namespace wx.Build.MS
{
    /** <summary> This class contains some methods to load properties of the installed MS .NET Framework if there is one installed. </summary> */
    public class ToolProperties
    {
        /// <summary>
        /// True if this is relevant. Do not use this class if false.
        /// </summary>
        static public bool IsRelevant
        {
          get { return BuildConfig.IsWindows; }
        }
    
        /** <summary> <c>HLM </c> \SOFTWARE\Microsoft\.NETFramework.
         * this is <c>null</c> if not relevant.
         * </summary> */
        static RegistryKey DotNetBaseKey
        {
            get
            {
              if (IsRelevant)
              {
                RegistryKey result=Registry.LocalMachine.OpenSubKey("SOFTWARE");
                if (result != null)
                    result=result.OpenSubKey("Microsoft");
                if (result != null)
                    result=result.OpenSubKey(".NETFramework"); 
                return result;
              }
              else
                return null;
            }
        }


        /** <summary> <c>HLM </c> \SOFTWARE\Microsoft\Microsoft SDKs\Windows or
         * <c>HLM </c> \SOFTWARE\Microsoft\MicrosoftSDK\InstalledSDKs. </summary> */
        static RegistryKey SDKsBaseKey 
        {
            get
            {
              if (IsRelevant)
              {
                RegistryKey result=Registry.LocalMachine.OpenSubKey("SOFTWARE");
                if (result != null)
                    result=result.OpenSubKey("Microsoft");
                if (result != null)
                    result=result.OpenSubKey("Microsoft SDKs"); 
                if (result != null)
                    result=result.OpenSubKey("Windows");
                if (result == null)
                {
                    result = Registry.LocalMachine.OpenSubKey("SOFTWARE");
                    if (result != null)
                        result = result.OpenSubKey("Microsoft");
                    if (result != null)
                        result = result.OpenSubKey("MicrosoftSDK");
                    if (result != null)
                        result = result.OpenSubKey("InstalledSDKs");
                }
                return result;
              }
              else
                return null;
            }
        }

        /** <summary> <c>HLM </c> \SOFTWARE\Microsoft\Microsoft SDKs\.NETFramework. </summary> */
        static RegistryKey FrameworkSDKsBaseKey
        {
            get
            {
                RegistryKey result = Registry.LocalMachine.OpenSubKey("SOFTWARE");
                if (result != null)
                    result = result.OpenSubKey("Microsoft");
                if (result != null)
                    result = result.OpenSubKey("Microsoft SDKs");
                if (result != null)
                    result = result.OpenSubKey(".NETFramework");
                return result;
            }
        }

        /** <summary> Reads the path to the .NET framework from the registry entries.
         * Typical result is \c "c:\WINDOWS\Microsoft.NET\Framework\". The result is <c>null </c>  if 
         * the framework is not installed (e.g. this runs on mono). </summary> */
        public static string GetPathToFramework()
        {
          if (IsRelevant)
          {
            try
            {
                RegistryKey dotNetBaseKey = DotNetBaseKey;
                if (dotNetBaseKey == null)
                    return null;
                return (string)dotNetBaseKey.GetValue("InstallRoot");
            }
            catch (Exception)
            {
                return null;
            }
          }
          else
            return null;
        }

        /** <summary> Reads the path to the .NET 2.0 SDK base.
         * Typical result are \c "C:\Programme\Microsoft.NET\SDK\v2.0\" or "C:\Programme\Microsoft Visual Studio 8\SDK\". </summary> */
        public static string GetPathToSDK20()
        {
          if (IsRelevant)
            return (string)DotNetBaseKey.GetValue("sdkInstallRootv2.0");
          else
            return null;
        }

        /** <summary> This is a dictionary of the installed framework SDKs.
         * These are the entries under <c>HLM </c> \SOFTWARE\Microsoft\MicrosoftSDK\InstalledSDKs\vX.X\InstallationFolder.
         * Typical result is a dictionary where "v2.0" is a key and a path like \c "C:\Programme\Microsoft.NET\SDK\v2.0\"
         * is the value. </summary> */
        public static IDictionary<string, string> GetFrameworkSDKs()
        {
            SortedList<string, string> result = new SortedList<string, string>();
            if (IsRelevant)
            {
            try
            {
                RegistryKey dotNetFrameworkBase = FrameworkSDKsBaseKey;
                if (dotNetFrameworkBase == null)
                {
                    return result;
                }
                foreach (string version in dotNetFrameworkBase.GetSubKeyNames())
                {
                    RegistryKey versionKey = dotNetFrameworkBase.OpenSubKey(version);
                    result.Add(version, (string)versionKey.GetValue("InstallationFolder"));
                }
                return result;
            }
            catch (Exception)
            {
                return result;
            }
            }
            else
              return result;
        }

        /** <summary> Returns a path to a framework using <c>FrameworkSDKs </c>  or <c>PathToSDK20() </c>  of highest version or <c>null </c> . </summary> */
        public static string GetPathToFrameworkSDK()
        {
            try
            {
                KeyValuePair<string, string>? found = null;
                IDictionary<string, string> frameworkSDKs = GetFrameworkSDKs();
                foreach (KeyValuePair<string, string> pair in frameworkSDKs)
                {
                    if (found == null)
                        found = pair;
                    else if (found.Value.Key.CompareTo(pair.Key) < 0)
                        found = pair;
                }
                if (found != null)
                    return found.Value.Value;
                return GetPathToSDK20();
            }
            catch (Exception)
            {
                return null;
            }
        }

        /** <summary> Returns paths to the installed SDKs (native code compilation).
         * These are the entries under <c>HLM </c> \SOFTWARE\Microsoft\MicrosoftSDK\InstalledSDKs\*\InstallationFolder.
         * Typical results are ["C:\Programme\Microsoft SDKs\Windows\v6.0A\", "C:\Programme\Microsoft SDKs\Windows\v6.1\"]. </summary> */
        public static string[] GetPlatformSDKs()
        {
            List<string> result = new List<string>();
            if (IsRelevant)
            {
            try
            {
                RegistryKey sdksBaseKey = SDKsBaseKey;
                if (sdksBaseKey != null)
                {
                    foreach (string subkey in sdksBaseKey.GetSubKeyNames())
                    {
                        RegistryKey sdkKey = sdksBaseKey.OpenSubKey(subkey);
                        result.Add((string)sdkKey.GetValue("InstallationFolder"));
                    }
                }
            }
            catch (Exception)
            {
            }
            }
            return result.ToArray();
        }

        /// <summary> Returns path to one of the installed SDKs (native code compilation).
        /// These are the entries under <tt>HLM/SOFTWARE/Microsoft/MicrosoftSDK/InstalledSDKs/*/InstallationFolder</tt>.
        /// Typical result is <tt>"C:/Programme/Microsoft SDKs/Windows/v6.1/"</tt>.
        /// <para>
        /// This will raise an exception if this is not able to find registry entries of a platform SDK installation.
        /// </para></summary>
        public static string GetPlatformSDK()
        {
            try
            {
                RegistryKey sdksBaseKey = SDKsBaseKey;
                if (sdksBaseKey != null)
                {
                    List<string> subKeys = new List<string>();
                    subKeys.AddRange(sdksBaseKey.GetSubKeyNames());
                    subKeys.Sort();
                    subKeys.Reverse();
                    RegistryKey sdkKey = sdksBaseKey.OpenSubKey(subKeys[0]);
                    return (string)sdkKey.GetValue("InstallationFolder");
                }
            }
            catch (Exception)
            {
            }
            throw new Exception("Cannot find Microsoft platform SDK.");
        }

        /// <summary> Returns the path to the VisualStudio VC files.
        /// This looks in the registry for 
        /// <tt>HLM/SOFTWARE/Microsoft/VisualStudio/SxS/8.0</tt> or later entries. Typical result is
        /// <tt>C:/Programme/Microsoft Visual Studio 8/VC/</tt>
        /// <para>
        /// The result may be empty if we didn't find a path. In that case we trust the PATH variable.
        /// </para></summary>
        public static string GetVCPath()
        {
          if (IsRelevant)
          {
            try
            {
                RegistryKey regKey = Registry.LocalMachine.OpenSubKey("SOFTWARE");
                if (regKey != null)
                    regKey = regKey.OpenSubKey("Microsoft");
                if (regKey != null)
                    regKey = regKey.OpenSubKey("VisualStudio");
                if (regKey != null)
                    regKey = regKey.OpenSubKey("SxS");
                if (regKey != null)
                {
                    List<string> versionNames = new List<string>();
                    versionNames.AddRange(regKey.GetSubKeyNames());
                    versionNames.Sort();
                    versionNames.Reverse();
                    foreach (string versionName in versionNames)
                    {
                        if (versionName.StartsWith("VC"))
                        {
                            RegistryKey vcKey = regKey.OpenSubKey(versionName);
                            object o = vcKey.GetValue(vcKey.GetValueNames()[0]);
                            if (o is string)
                                return (string)o;
                        }
                    }
                }
            }
            catch (Exception exc)
            {
                BuildConfig.HandleErrorObject(ErrorObject.MessageType.Message, "MS Tools: "+exc.Message);
            }
          }
          return "";
        }

        /** <summary> Get path to the VisualStudio VC path containing compiler and linker.
         * This is subdir <c>bin </c>  of the GetVCPath() or empty if GetVCPath failed. </summary> */
        public static string GetVCBinPath()
        {
            string result = GetVCPath();
            if (result.Length == 0)
                return result;
            else
                return System.IO.Path.Combine(result, "bin");
        }

        /// <summary> Returns the path to the VisualStudio files.
        /// This looks in the registry for 
        /// <tt> HLM/SOFTWARE/Microsoft/VisualStudio/SxS/8.0</tt> or later entries. Typical result is
        /// <tt> C:/Programme/Microsoft Visual Studio 8/</tt>.
        /// <para>
        /// The result may be empty if we didn't find a path. In that case we trust the PATH variable.
        /// </para></summary>
        public static string GetVSPath()
        {
          if (IsRelevant)
          {
            try
            {
                RegistryKey regKey = Registry.LocalMachine.OpenSubKey("SOFTWARE");
                if (regKey != null)
                    regKey = regKey.OpenSubKey("Microsoft");
                if (regKey != null)
                    regKey = regKey.OpenSubKey("VisualStudio");
                if (regKey != null)
                    regKey = regKey.OpenSubKey("SxS");
                if (regKey != null)
                {
                    List<string> versionNames = new List<string>();
                    versionNames.AddRange(regKey.GetSubKeyNames());
                    versionNames.Sort();
                    versionNames.Reverse();
                    foreach (string versionName in versionNames)
                    {
                        if (versionName.StartsWith("VS"))
                        {
                            RegistryKey vsKey = regKey.OpenSubKey(versionName);
                            object o = vsKey.GetValue(vsKey.GetValueNames()[0]);
                            if (o is string)
                                return (string)o;
                        }
                    }
                }
            }
            catch (Exception exc)
            {
                BuildConfig.HandleErrorObject(ErrorObject.MessageType.Message, "MS Tools: " + exc.Message);
            }
          }
          return "";
        }
        
        /// <summary> Returns the directory of the Visual Studio development environment.
        /// This is <c> GetVSPath() + "\\Common7\\IDE"</c>.
        /// </summary>
        public static string GetEnvDir()
        {
            string result=GetVSPath();
            if (result.Length > 0)
            {
                result = System.IO.Path.Combine(result, "Common7");
                result = System.IO.Path.Combine(result, "IDE");
            }
            return result;
        }

        /// <summary>Reports all findings on the installed Microsoft .NET framework and SDKs on the destination destination.</summary>
        /// <param name="dest">The destination of the report.</param>
        public static void Report(System.IO.TextWriter dest)
        {
            string pathToFramework=GetPathToFramework();
            if (pathToFramework == null)
                dest.WriteLine("No MS .NET framework installed.");
            else
                dest.WriteLine("MS .NET Framework installed at {0}.", pathToFramework);
            foreach (KeyValuePair<string, string> versionPathPair in GetFrameworkSDKs())
                dest.WriteLine(".NET SDK Version {0} installed at {1}.", versionPathPair.Key, versionPathPair.Value);
            foreach (string path in GetPlatformSDKs())
            {
                dest.WriteLine("Platform SDK installed at {0}.", path);
            }
            string vcPath = GetVCPath();
            if (vcPath.Length > 0)
                dest.WriteLine("Visual Studio (Express) VC is installed at {0}.", vcPath);
            string vsPath = GetEnvDir();
            if (vsPath.Length > 0)
                dest.WriteLine("Visual Studio (Express) development environment is installed at {0}.", vsPath);
        }

        /** <summary> Searches installations of the .NET framework for a tool named <c>toolFileName </c>  (e.g. \c "al.exe").
         * Result is <c>null </c>  if the tool could not be found. </summary> */
        public static string GetPathToFrameworkTool(string toolFileName)
        {
            try
            {
                string basePath = GetPathToFramework();
                if (basePath == null)
                   return null;
                List<string> directories = new List<string>();
                directories.AddRange(System.IO.Directory.GetDirectories(basePath, "v*"));
                directories.Reverse();
                foreach (string dir in directories)
                {
                    string dirFullPath = System.IO.Path.Combine(basePath, dir);
                    string toolFullPath = System.IO.Path.Combine(dirFullPath, toolFileName);
                    if (System.IO.File.Exists(toolFullPath))
                        return toolFullPath;
                }
            }
            catch
            {
            }
            return null;
        }

        /** <summary> Searches installations of the .NET SDK for a tool named <c>toolFileName </c>  (e.g. \c "sn.exe").
         * Result is <c>null </c>  if the tool could not be found. </summary> */
        public static string GetPathToFrameworkSDKTool(string toolFileName)
        {
            string sdkPath = GetPathToFrameworkSDK();
            if (sdkPath == null)
                return null;
            sdkPath = System.IO.Path.Combine(sdkPath, "Bin");
            sdkPath = System.IO.Path.Combine(sdkPath, toolFileName);
            if (System.IO.File.Exists(sdkPath))
                return sdkPath;
            return null;
        }
    }

    /** <summary> Wrapper around the <c>csc </c> .exe compiler shipped with the .NET framework.
     * Availability of this action enable users to explicitely choose the compiler.
     * There is another more generic tool using the System.CodeDom.Compiler namespace:
     * wx.Build.Net.NetCodeProvider.
     * 
     * This tool will add __MS_CSC__ to the defined symbols for conditional compilation. </summary> */
    public class Csc : BaseAction, IBuildActionProvider, IBuildAction
    {
        #region State
        protected ContentFile _target;
        protected FileProducts _sources = new FileProducts(ContentType.CSharpCode);
        protected FileProducts _references = new FileProducts(ContentType.DotNetDll);
        protected FileProducts _icons = new FileProducts(ContentType.ICO);
        protected FileProducts _signatureFile = new FileProducts(ContentType.SnKeys);

        protected string _mainClass = null;
        #endregion

        #region CTor
        /** <summary> This creates an isntance without data to be used as <c>IBuildActionClass </c> . </summary> */
        public Csc()
        {
            this._target = null;
        }
        #endregion

        #region Overrides
        public override ICollection<IBuildProduct> GetPrerequisites()
        {
            List<IBuildProduct> result = new List<IBuildProduct>();
            foreach (IBuildProduct src in this._sources.Files)
                result.Add(src);
            foreach (IBuildProduct reference in this._references.Files)
                result.Add(reference);
            foreach (IBuildProduct icon in this._icons.Files)
                result.Add(icon);
            foreach (IBuildProduct signature in this._signatureFile.Files)
                result.Add(signature);
            return result;
        }

        public override bool ContainsPrerequisite(IBuildProduct prereq)
        {
            return this._sources.Contains(prereq)
                || this._references.Contains(prereq)
                || this._icons.Contains(prereq)
                || this._signatureFile.Contains(prereq);
        }

        public override ICollection<IBuildProduct> GetTargets()
        {
            List<IBuildProduct> result = new List<IBuildProduct>();
            result.Add(this._target);
            return result;
        }
        #endregion

        #region IBuildActionProvider Member
        /** <summary> Only available on Windows Systems. </summary> */
        public ICollection<OperatingSystem> ApplicableOSs
        {
            get
            {
                List<OperatingSystem> result = new List<OperatingSystem>();
                result.Add(OperatingSystem.WinXP);
                return result;
            }
        }

        /** <summary> "csc.exe" </summary> */
        public string Name
        {
            get { return "csc.exe"; }
        }

        /** <summary> Groupname is "MSNET". </summary> */
        public string ToolFamily
        {
            get { return "MSNET"; }
        }

        /** <summary> Returns the filename of the tool. </summary> */
        public string FileName
        {
            get
            {
                return ToolProperties.GetPathToFrameworkTool(this.Name);
            }
        }

        public string Description
        {
            get { return string.Format("{0}: The C# compiler of the MS .NET framework.", this.FileName); }
        }

        public bool IsAvailable
        {
            get
            {
                // This is part of the .NET framework.
                try {
                return ToolProperties.GetPathToFrameworkTool(this.Name) != null;
                } catch {
                return false;
                }
            }
        }

        /** <summary> This requires a signature key file to produce strong named assemblies. </summary> */
        public bool MayContentFilePrerequisitesSuffice(ContentType target, ICollection<ContentType> prerequisites)
        {
            bool requiresSN = false;
            if (target.Implies(ContentType.SnDotNetDll))
                requiresSN = true;
            bool foundCSharp = false;
            bool foundSN = false;
            foreach (ContentType contentFile in prerequisites)
            {
                if (contentFile.Equals(ContentType.CSharpCode))
                    foundCSharp = true;
                if (contentFile.Equals(ContentType.SnKeys))
                    foundSN = true;
                bool ok = foundCSharp && (!requiresSN || foundSN);
                if (ok)
                    return true;
            }
            return false;
        }

        public ICollection<ContentType> ContentFileTargets
        {
            get { return new ContentType[] { ContentType.DotNetModule, ContentType.DotNetDll, ContentType.DotNetExe, ContentType.SnDotNetDll, ContentType.SnDotNetExe, ContentType.SnDotNetShellExe }; }
        }

        /** <summary> This will create an action from the provided file objects.
         * This will deal with IFileProducts of the </summary> */
        public IBuildAction Create(BuildToolFamilyEnv env, IBuildProduct target, ICollection<IBuildProduct> prerequisites)
        {
            Csc result = new Csc();
            ContentFile assemblyTarget = target as ContentFile;
            if (assemblyTarget == null
                || (!ContentType.DotNetDll.Contains(assemblyTarget.Type)
                    && !ContentType.DotNetModule.Contains(assemblyTarget.Type)))
            {
                throw new ArgumentException("Csc.exe is for building assemblies. Creation with wrong kind of build target.");
            }
            result._target = assemblyTarget;

            foreach (IBuildProduct prerequisite in prerequisites)
            {
                IFileProducts file = prerequisite as IFileProducts;
                if (file != null)
                {
                    if (file.Type.Implies(ContentType.DotNetDll))
                        result._references.Add(file);
                    else if (file.Type.Implies(ContentType.CSharpCode))
                        result._sources.Add(file);
                    else if (file.Type.Implies(ContentType.ICO))
                        result._icons.Add(file);
                    else if (file.Type.Implies(ContentType.SnKeys))
                        result._signatureFile.Add(file);
                }
            }
            if (result._sources.Count == 0)
                throw new ArgumentException(string.Format("Csc.exe requires at least on C# source as input."));
            return result;
        }

        #endregion

        #region IBuildAction Member
        /** <summary> <c>this </c>  is its own action provider. </summary> */
        public IBuildActionProvider ActionProvider
        {
            get { return this; }
        }

        /** <summary> This is preferred if available. </summary> */
        public ActionPriority Priority
        {
            get
            {
                return ActionPriority.Preferred;
            }
        }

        public override ICollection<Type> ParameterTypes
        {
            get
            {
                return new Type[] { typeof(wx.Build.Net.NetCompilerParameters) };
            }
        }
        #endregion

        #region BOO Export
        /// <summary>
        /// This will be called for any action provider before IBuildAction.AppendBooCode() is called.
        /// This provides action providers with the opportunity to import modules and create variables
        /// for global options.
        /// </summary>
        /// <param name="env">Environment containing status that can be shared among tools of the same family.</param>
        /// <param name="importModules">List of modules that shall be imported. Add required modules here. Each module
        /// will be imported exactly once (even if it occurs more than once in the list).</param>
        /// <param name="booDeclarations">Lines of code that will be added to the preamble of the BOO code.
        /// Please note, that each line may only appear once. All subsequent additions of this line of
        /// code will be ignored. These lines shall contain declarations of variables etc.</param>
        /// <param name="booDefinitions">Lines of code that that will be added before the code provided by
        /// the actions to build the system. Typically, this will contain the definition of functions
        /// that are used on building. Lines starting with "import" will only be added once to the final code. </param>
        public override void AppendToBooPreamble(BuildToolFamilyEnv env, List<string> importModules, List<string> booDeclarations, List<string> booDefinitions)
        {
            importModules.Add("System.Text");
            importModules.Add("System.IO");

            booDeclarations.Add("# This variable is the path to the CSC compiler that will be used.");
            booDeclarations.Add("MS_CSC=\"" + ContentFile.ConvertFilenameToBooString( this.FileName ) + "\"");

            wx.Build.Net.NetCompilerParameters parameters = (wx.Build.Net.NetCompilerParameters)BuildConfig.GetDefaultParameterOfType(typeof(wx.Build.Net.NetCompilerParameters));
            booDeclarations.Add("# This option defines whether to compile with debug information or not");
            if (parameters.IncludeDebugInformation)
                booDeclarations.Add("MS_CSC_OPTIONS='/debug'");
            else
                booDeclarations.Add("MS_CSC_OPTIONS='' # '/debug'");
            booDeclarations.Add("# This option turns on optimization");
            if (parameters.OptimizeOutput)
                booDeclarations.Add("MS_CSC_OPTIONS+=' /optimize'");
            else
                booDeclarations.Add("#MS_CSC_OPTIONS+=' /optimize'");
            booDeclarations.Add("# This option defines the warning level");
            if (parameters.WarningLevel >= 0)
                booDeclarations.Add(string.Format("MS_CSC_OPTIONS+=' /warn:{0}'", parameters.WarningLevel));
            else
                booDeclarations.Add("#MS_CSC_OPTIONS+=' /warn:3'");
            booDeclarations.Add("MS_CSC_OPTIONS+=' /fullpaths'");
            if (BuildConfig.GetConfig().AbortOptions == AbortOptions.TreatWarningsAsErrors)
                booDeclarations.Add("MS_CSC_OPTIONS+=' /warnaserror' # treats warnings as errors");
            else
                booDeclarations.Add("#MS_CSC_OPTIONS+=' /warnaserror' # treats warnings as errors");
            booDeclarations.Add("MS_CSC_OPTIONS+=' /define:__MS_CSC__' # identifies the compiler");
            if (parameters.EnableTraceLog)
                booDeclarations.Add("MS_CSC_OPTIONS+=' /define:TRACE' # enables trace log");

            booDefinitions.Add(string.Format("def RunMsCsc(targettype as string, target as string, w32icon as string, signature as string, mainclass as string, references as (string), sources as (string), features):"));
            booDefinitions.Add(string.Format("\tif not TestForRebuild(target, w32icon, signature, references, sources):"));
            booDefinitions.Add(string.Format("\t\tprint target,\"is up to date\""));
            booDefinitions.Add(string.Format("\t\treturn"));
            booDefinitions.Add(string.Format("\tprint \"MS csc.exe creates\", target"));
            TempFilesParameters tempPars = (TempFilesParameters)BuildConfig.GetDefaultParameterOfType(typeof(TempFilesParameters));
            string cscOptionsFilename = tempPars.CreatePathFor("csc.options", ContentType.TXT).FileNameAsBooString;
            booDefinitions.Add(string.Format("\targs=StreamWriter(\"{0}\")", cscOptionsFilename));
            booDefinitions.Add(string.Format("\targs.Write(\"/out:${{target}} /target:${{targettype}}\")"));
            booDefinitions.Add(string.Format("\tfor feature in features:"));
            booDefinitions.Add(string.Format("\t\tif feature==\"{0}\":", wx.Build.Net.CSharpAssemblyProject.PlatformX32.Symbol));
            booDefinitions.Add(string.Format("\t\t\targs.Write(' /platform:x86')"));
            booDefinitions.Add(string.Format("\t\telif feature==\"{0}\":", wx.Build.Net.CSharpAssemblyProject.PlatformX64.Symbol));
            booDefinitions.Add(string.Format("\t\t\targs.Write(' /platform:x64')"));
            booDefinitions.Add(string.Format("\t\telse:"));
            booDefinitions.Add(string.Format("\t\t\targs.Write(' /define:')"));
            booDefinitions.Add(string.Format("\t\t\targs.Write(feature)"));
            booDefinitions.Add(string.Format("\tfor reference in references:"));
            booDefinitions.Add(string.Format("\t\targs.Write(\" /reference:\\\"${{reference}}\\\"\")"));
            booDefinitions.Add(string.Format("\tif signature != null:"));
            booDefinitions.Add(string.Format("\t\targs.Write(\" /keyfile:\\\"${{signature}}\\\"\")"));
            booDefinitions.Add(string.Format("\tif w32icon != null:"));
            booDefinitions.Add(string.Format("\t\targs.Write(\" /win32icon:\\\"${{w32icon}}\\\"\")"));
            booDefinitions.Add(string.Format("\tif mainclass != null:"));
            booDefinitions.Add(string.Format("\t\targs.Write(\" /main:${{mainclass}}\")"));
            booDefinitions.Add(string.Format("\targs.Write(' ')"));
            booDefinitions.Add(string.Format("\targs.Write(MS_CSC_OPTIONS)"));
            booDefinitions.Add(string.Format("\tfor source in sources:"));
            booDefinitions.Add(string.Format("\t\targs.Write(\" \\\"${{source}}\\\"\")"));
            booDefinitions.Add("\targs.Close()");
            booDefinitions.Add(string.Format("\tstartinfo=System.Diagnostics.ProcessStartInfo()"));
            booDefinitions.Add(string.Format("\tstartinfo.FileName=MS_CSC"));
            booDefinitions.Add(string.Format("\tstartinfo.Arguments=\"@{0}\"", cscOptionsFilename));
            booDefinitions.Add(string.Format("\tstartinfo.UseShellExecute=false"));
            booDefinitions.Add(string.Format("\tp=System.Diagnostics.Process.Start(startinfo)"));
            booDefinitions.Add(string.Format("\tp.WaitForExit()"));
            booDefinitions.Add(string.Format("\tif p.ExitCode!=0:"));
            booDefinitions.Add(string.Format("\t\traise System.Exception(\"Build action failed.\")"));
        }

        /// <summary>
        /// This method will create BOO source code and append this code to the provided text writer.
        /// </summary>
        /// <param name="env">This is an environment that different tools of the same family may use to exchange information.
        /// This store is typically used to save information on configuration files or thinsgs of that kind that will be
        /// shared among all tools of the same family.</param>
        /// <param name="booCodeLines">The code that will actually build something. Each list entry will be a line of code in the resulting
        /// BOO program.</param>
        /// <param name="indention">A string that shall preceed all created lines. </param>
        /// <remarks>Refer to IBuildActionProvider.AppendToBooPreamble() for an example.
        /// 
        /// This implementation will only provide
        /// </remarks>
        /// <exception cref="NotSupportedException">Will be thrown if this feature is not supported.</exception>
        public override void AppendBooCode(List<string> booCodeLines, string indention, BuildToolFamilyEnv env)
        {
            System.Text.StringBuilder line = new System.Text.StringBuilder();
            line.Append(indention);
            line.Append("RunMsCsc(");
            if (ContentType.DotNetShellExe.Contains(this._target.Type))
                line.Append("'exe'");
            else if (ContentType.DotNetExe.Contains(this._target.Type))
                line.Append("'winexe'");
            else if (ContentType.DotNetModule.Contains(this._target.Type))
                line.Append("'module'");
            else
                line.Append("'library'");
            line.Append(", \"");
            line.Append(this._target.FileNameAsBooString);
            line.Append("\"");
            if (this._icons.Files.Count > 0)
            {
                ContentFile file = this._icons.Files.GetOneFile();
                if (!file.Type.Implies(ContentType.ICO))
                    throw new Exception(string.Format("Cannot use {0} of type {1} as win32 icon.", file, file.Type));
                line.Append(", \"" + file.FileNameAsBooString + "\"");
            }
            else
                line.Append(", null");
            if (this._signatureFile.Count > 0)
            {
                line.Append(", \"" + this._signatureFile.Files.GetOneFile().FileNameAsBooString + "\"");
            }
            else
                line.Append(", null");
            if (this._mainClass != null && this._mainClass.Length > 0)
                line.Append(", " + this._mainClass);
            else
                line.Append(", null");
            {
                line.Append(", (");
                bool isfirst = true;
                foreach (ContentFile assemblyLink in this._references.Files)
                {
                    if (!isfirst) line.Append(", ");
                    line.Append("\"" + assemblyLink.FileNameAsBooString + "\"");
                    isfirst = false;
                }
                if (this._references.Files.Count < 2)
                    line.Append(",");
                line.Append(")");
            }
            {
                line.Append(", (");
                bool isfirst = true;
                foreach (ContentFile source in this._sources.Files)
                {
                    if (!isfirst) line.Append(", ");
                    line.Append("\"" + source.FileNameAsBooString + "\"");
                    isfirst = false;
                }
                if (this._sources.Files.Count < 2)
                    line.Append(",");
                line.Append(")");
            }
            line.Append(", ");
            if (this.Project != null && this.Project.Features != null && this.Features.Count > 0)
                line.Append("Features_" + this.Project.NameAsSymbol);
            else
                line.Append("[]");
            line.Append(")");
            booCodeLines.Add(line.ToString());
        }
        #endregion

        #region IBuildProduct Member

        public override System.Diagnostics.ProcessStartInfo GetProgramStartInfo(BuildToolFamilyEnv env)
        {
            System.Diagnostics.ProcessStartInfo result = new System.Diagnostics.ProcessStartInfo();
            result.FileName = this.FileName;

            System.Text.StringBuilder cmd = new System.Text.StringBuilder();
            cmd.Append(" \"/out:" + this._target.FileName+"\"");
            if (ContentType.DotNetShellExe.Contains(this._target.Type))
                cmd.Append(" /target:exe");
            else if (ContentType.DotNetExe.Contains(this._target.Type))
                cmd.Append(" /target:winexe");
            else if (ContentType.DotNetModule.Contains(this._target.Type))
                cmd.Append(" /target:module");
            else
                cmd.Append(" /target:library");
            foreach (ContentFile assemblyLink in this._references.Files)
            {
                cmd.Append(" \"/reference:" + assemblyLink.FileName+"\"");
            }
            if (this._signatureFile.Count > 0)
            {
                cmd.Append(" \"/keyfile:" + this._signatureFile.Files.GetOneFileName()+"\"");
            }
            foreach (ContentFile file in this._icons.Files)
            {
                if (!file.Type.Implies(ContentType.ICO))
                    throw new Exception(string.Format("Cannot use {0} of type {1} as win32 icon.", file, file.Type));
                cmd.Append(" \"/win32icon:" + file.FileName+"\"");
            }

            wx.Build.Net.NetCompilerParameters netParameters = (wx.Build.Net.NetCompilerParameters)BuildConfig.GetDefaultParameterOfType(typeof(wx.Build.Net.NetCompilerParameters));
            if (netParameters.Features.ContainsKey(wx.Build.Net.CSharpAssemblyProject.PlatformX32))
                cmd.Append(" /platform:x86");
            else if (netParameters.Features.ContainsKey(wx.Build.Net.CSharpAssemblyProject.PlatformX64))
                cmd.Append(" /platform:x64");
            if (this._mainClass != null && this._mainClass.Length > 0)
                cmd.Append(" /main:" + this._mainClass);

            if (netParameters.IncludeDebugInformation)
                cmd.Append(" /debug");
            if (netParameters.OptimizeOutput)
                cmd.Append(" /optimize");
            if (netParameters.WarningLevel >= 0)
                cmd.Append(" /warn:" + netParameters.WarningLevel);
            cmd.Append(" /fullpaths");
            if (BuildConfig.GetConfig().AbortOptions == AbortOptions.TreatWarningsAsErrors)
                cmd.Append(" /warnaserror");
            cmd.Append(" /define:__MS_CSC__");
            if (netParameters.EnableTraceLog)
                cmd.Append(" /define:TRACE");

            foreach (string feature in this.Features.Without(
                wx.Build.Net.CSharpAssemblyProject.PlatformX32, wx.Build.Net.CSharpAssemblyProject.PlatformX64)
                .EnabledSymbols)
                cmd.Append(" /define:" + feature);

            foreach (ContentFile file in this._sources.Files)
            {
                cmd.Append(" \"");
                cmd.Append(file.FileName);
                cmd.Append("\"");
            }
            result.Arguments = cmd.ToString();
            return result;
        }

        /** <summary> This will start the <c>csc </c> .exe of the newest installed framework. </summary> */
        public bool Execute(BuildToolFamilyEnv env, DateTime validityOfBuildSystem)
        {
            ErrorDataReceiver receiver=new ErrorDataReceiver(this);
            receiver.WarningClassifier = new System.Text.RegularExpressions.Regex(@"\swarning\s",
                System.Text.RegularExpressions.RegexOptions.Compiled
                | System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            receiver.ErrorClassifier = new System.Text.RegularExpressions.Regex(@"\serror\s",
                System.Text.RegularExpressions.RegexOptions.Compiled
                | System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            receiver.FilePosPattern = new System.Text.RegularExpressions.Regex(
                @"^(?<file>[^\(]+)\((?<line>\d+),(?<column>\d+)\)");
            wx.ProcessUtils.ProcessStarter starter = new wx.ProcessUtils.ProcessStarter(this.GetProgramStartInfo(env),
                new wx.ProcessUtils.MsgEventHandler(receiver.OnReceiveMsgEvent));
            System.Diagnostics.Process process = starter.Start();
            return process.ExitCode == 0;
        }

        #endregion
    }

    /** <summary> Wrapper around the assembly linker.
     * You may provide any kind of file as a resource file as ResourceDesignator.
     * Instances of ContentFile will be accessible by a standard name: FILENAME.EXT => FILENAME_EXT.
     * </summary> */
    public class Al : BaseAction, IBuildActionProvider, IBuildAction
    {
        #region State
        string _al_exe_path = null;
        #endregion

        #region CTor
        /** <summary> Creates an instance without target and prerequisites.
         * This is meant to be an action provider. </summary> */
        public Al()
        {
        }
        #endregion 

        #region IBuildActionClass Member

        public ICollection<OperatingSystem> ApplicableOSs
        {
            get
            {
                List<OperatingSystem> result = new List<OperatingSystem>();
                result.Add(OperatingSystem.WinXP);
                return result;
            }
        }

        /** <summary> "al.exe" </summary> */
        public string Name
        {
            get { return "al.exe"; }
        }

        /** <summary> Groupname is "MSNET". </summary> */
        public string ToolFamily
        {
            get { return "MSNET"; }
        }

        public string Description
        {
            get { return string.Format("{0}: The assembly linker of the MS .NET framework.", AlExePath); }
        }

        /** <summary> Path to <c>al </c> .exe. </summary> */
        public string AlExePath
        {
            get
            {
                if (this._al_exe_path == null)
                {
                    this._al_exe_path = ToolProperties.GetPathToFrameworkTool("al.exe");
                }
                return this._al_exe_path;
            }
        }

        public bool IsAvailable
        {
            get
            {
              try {
                return this.AlExePath != null;
              } catch {
                return false;
              }
            }
        }

        public bool MayContentFilePrerequisitesSuffice(ContentType target, ICollection<ContentType> prerequisites)
        {

            return false;
        }

        /** <summary> This is to create assemblies. </summary> */
        public ICollection<ContentType> ContentFileTargets
        {
            get
            {
                List<ContentType> result=new List<ContentType>();
                result.Add(ContentType.DotNetDll);
                result.Add(ContentType.DotNetExe);
                result.Add(ContentType.DotNetShellExe);
                result.Add(ContentType.SnDotNetDll);
                result.Add(ContentType.SnDotNetExe);
                result.Add(ContentType.SnDotNetShellExe);
                return result;
            }
        }

        public IBuildAction Create(BuildToolFamilyEnv env, IBuildProduct target, ICollection<IBuildProduct> prerequisites)
        {
            Al result=new Al();
            return result;
        }

        #endregion

        #region IBuildAction Member

        public IBuildActionProvider ActionProvider
        {
            get { return this; }
        }

        public ActionPriority Priority
        {
            get { return ActionPriority.Default; }
        }

        #endregion

        #region IBuildProduct Member


        public bool Execute(BuildToolFamilyEnv env, DateTime validityOfBuildSystem)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        #endregion

        public override ICollection<IBuildProduct> GetPrerequisites()
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public override ICollection<IBuildProduct> GetTargets()
        {
            throw new Exception("The method or operation is not implemented.");
        }
    }
}
