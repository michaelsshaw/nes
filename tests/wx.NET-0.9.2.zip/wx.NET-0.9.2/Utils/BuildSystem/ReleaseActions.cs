/** Build system for wx.NET.
 * 
 * This DLL contains basic implementations to build (compile and link) C/C++ programs,
 * compile .NET assemblies written in C#, sign them, and install them.
 *
 * This file contains build actions that are used to replace the release version
 * in RC files and C# sources.
 * 
 * \file 
 *
 * Copyright 2009 Harald Meyer auf'm Hofe harald_meyer@users.sourceforge.net
 * 
 * Licensed under the wxWidgets license, see LICENSE.txt for details.
 * 
 * $Id: ReleaseActions.cs,v 1.13 2010/06/06 09:00:04 harald_meyer Exp $
 */

using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.IO;

/** This namespace contains classes for creating releases.
 * This namespace contains a project for the creation of releases and actions to convert RC files and C# sources.
 * </summary>
 */
namespace wx.Build.Release
{
    /// <summary>
    /// This class is a wrapper around other projects that will produce the targets of wrapped projects but with references to a build version according to variable BUILD_VERSION.
    /// This project supports the build of new releases.
    /// Release consist of files. These files are the prerequisites of the release.
    /// The new instance will analyse the received projects and create new ones (copies) relying on possibly transformed
    /// source files. This project may receive instances of wx.Build.Net.CSharpAssemblyProject, wx.Build.Cxx.DynamicLibraryProject,
    /// or other projects implementing wx.Build.IFileProducts as original part descriptions.
    /// The sources of those projects building assemblies or native DLLs will be modified in the following way:
    /// <list type="bullet">
    /// <item>In RC-files and C# sources version info will be set to environment variable <c>BUILD_VERSION</c>.</item>
    /// <item>All native DLLs that are part of the reelase will change their name in such a way that the version of the 
    ///   file can be deduced from the new filename. Sample: <c>dynamic.dll</c> with BUILD_VERSION "1.2.3.4" will change to
    ///   <c>dynamic-1-2-3-4.dll</c></item>
    /// <item>Additionally, P-INVOKE calls to those contained native DLLs will changed in such a way that they refer to the new
    ///   filenames containing version information.</item>
    /// </list>
    /// The release will build assemblies and native DLLs from these transformed sources into subdirectories of those directories holding the
    /// original targets. Example: The released version of <code>/home/wxnet/p/Bin/libwx-c.so</code> will be stored into
    /// <code>/home/wxnet/p/Bin/release-1-2-3-4/libwx-c-1-2-3-4.so</code>. The targets of all project that implement
    /// wx.Build.IFileProducts but produce neither natove nor managed DLLs will simply be copied into subdirectories according
    /// to the release version info as described above.
    /// </summary>
    /// <remarks> As a result, this will create sources and project specifications referring to this sources in such a way that the output
    /// can be installed in GAC and system32 directory (or GAC and /usr/local/lib on UNIX systems) without interfering with other
    /// versions of the released project.
    ///
    /// Please note, that variable BUILD_VERSION is mandatory. The value of this variable shall be a string form of a
    /// System.Version value, a string of 4 numbers separated by dots ('.') representing major and minor release number, build
    /// number and revision.
    /// </remarks>
    public class MakeReleaseProject : BuildProject
    {
        #region State
        Dictionary<ContentFile, Net.CSharpAssemblyProject> _assemblyProjects = new Dictionary<ContentFile, wx.Build.Net.CSharpAssemblyProject>();
        Dictionary<ContentFile, Cxx.DynamicLibraryProject> _nativeDllProjects = new Dictionary<ContentFile, Cxx.DynamicLibraryProject>();
        List<IFileProducts> _otherProjects = new List<IFileProducts>();
        SortedDictionary<ContentFile, ContentFile> _originalFileToReleasedFile = null;
        #endregion

        #region Conversion Of Filename - Release Numbers in Filenames.
        /// <summary>
        /// Public helper that defines how to code version info into the filename of a native dll file.
        /// </summary>
        /// <param name="filename">The filename of a DLL like <c>wx-c.dll</c> or <c>libwx-c.so</c>.</param>
        /// <param name="version">Version info like 1.0.0.1</param>
        /// <returns>A filename depending on the arguments like wx-c-1-0-0-1.dll or libwx-c-1-0-0-1.so</returns>
        public static string ConversionFilenameToFilenameWithVersion(string filename, Version version)
        {
            string ext = Path.GetExtension(filename);
            string basename = Path.GetFileNameWithoutExtension(filename);
            return string.Format("{0}-{1}-{2}-{3}-{4}{5}",
                basename, version.Major, version.Minor, version.Build, version.Revision, ext);
        }

        /// <summary>
        /// Creates the name of the directory name that will contain those parts of the release <c>version</c> that
        /// would originally be stored in directory <c>path</c>.
        /// </summary>
        /// <param name="path">Is the path to the original file</param>
        /// <param name="version"> Is the version information of the release to be built.</param>
        /// <return>Is a subdir of <c>path</c> that will be used to hold parts of release <c>version</c>.</return>
        public static string ConversionPathToPathWithVersion(string path, Version version)
        {
            return Path.Combine(path, string.Format("release-{0}-{1}-{2}-{3}", version.Major, version.Minor, version.Build, version.Revision));
        }

        /// <summary>
        /// This will use ConversionPathToPathWithVersion() to return a full filename (containing info on the directory of
        /// the file)
        /// where a copy of <c>originalTarget</c> will be placed that is part of the <c>releaseVersion</c>.
        /// </summary>
        /// <param name="isTarget">indicates with <c>true</c> that the resulting file is a target. Usually, files
        /// will be created just like temporary files. In contrast, targets will be created in a subdir
        /// of the directory, where the original lies.</param>
        public static ContentFile ConversionFullFilenameToFullFilenameWithVersion(ContentFile originalTarget, Version releaseVersion, bool isTarget)
        {
            string dirName = Path.GetDirectoryName(originalTarget.FileName);
            string fileName = Path.GetFileName(originalTarget.FileName);
            dirName = ConversionPathToPathWithVersion(dirName, releaseVersion);
            if ((originalTarget.Type.Properties & ContentFileProperties.NativeDLL) == ContentFileProperties.NativeDLL)
                fileName = ConversionFilenameToFilenameWithVersion(fileName, releaseVersion);
            fileName=Path.Combine(dirName, fileName);
            if (!isTarget)
            {
                TempFilesParameters t = (TempFilesParameters)BuildConfig.GetDefaultParameterOfType(typeof(TempFilesParameters));
                return t.CreatePathFor(fileName, originalTarget.Type);
            }
            else
                return new ContentFile(originalTarget.Type, fileName);
        }

        /// <summary>
        /// This will return a dictionary mapping content files with version info coded into the filename to the originals
        /// without filenames reflecting the release version. Conversion is according to AmendFilenameWithVersion().
        /// The mapped / versioned filenames will be created using TempFilesParameters.
        /// </summary>
        /// <param name="version">The version info that shall be coded into the mapped filenames.</param>
        /// <returns>A mapping of unversioned filenames of included native DLLs to filenames reflecting the release.</returns>
        public IDictionary<ContentFile, ContentFile> GetDllConversionScheme(Version version)
        {
            SortedDictionary<ContentFile, ContentFile> result = new SortedDictionary<ContentFile, ContentFile>();
            TempFilesParameters temp=(TempFilesParameters) BuildConfig.GetDefaultParameterOfType(typeof(TempFilesParameters));
            foreach(Cxx.DynamicLibraryProject dllProject in this._nativeDllProjects.Values)
            {
                string fullFilename = dllProject.Target.FileName;
                string dir=Path.GetDirectoryName(fullFilename);
                string filename=Path.GetFileName(fullFilename);
                string newFilename=ConversionFilenameToFilenameWithVersion(filename, version);
                string newDir=ConversionPathToPathWithVersion(dir, version);
                ContentFile newFile = temp.CreatePathFor(Path.Combine(newDir, newFilename), dllProject.Target.Type);
                result[new ContentFile(dllProject.Target.Type, fullFilename)] = newFile;
            }
            return result;
        }
        #endregion

        #region CTor
        readonly static Version DefaultVersion = new Version(0, 0, 0, 1);

        /// <summary>
        /// this is a helper method that will fill _originalFileToReleasedFile if this is <c>null</c>.
        /// </summary>
        void UpdateOriginalFileToReleasedFile()
        {
            if (this._originalFileToReleasedFile == null)
            {
                this._originalFileToReleasedFile = new SortedDictionary<ContentFile, ContentFile>();
                Version buildVersion = (Version)BuildVersionVariable.Get(DefaultVersion);
                foreach (Cxx.DynamicLibraryProject p in this._nativeDllProjects.Values)
                    this._originalFileToReleasedFile[p.Target] = ConversionFullFilenameToFullFilenameWithVersion(p.Target, buildVersion, true);
                foreach (Net.CSharpAssemblyProject p in this._assemblyProjects.Values)
                    this._originalFileToReleasedFile[p.AssemblyFile] = ConversionFullFilenameToFullFilenameWithVersion(p.AssemblyFile, buildVersion, true);
                foreach (IFileProducts p in this._otherProjects)
                    foreach (ContentFile file in p.Files)
                        this._originalFileToReleasedFile[file] = ConversionFullFilenameToFullFilenameWithVersion(file, buildVersion, true);
            }
        }

        /// <summary>
        /// Creates an empty project. 
        /// Use this only in conjunction with ReadXml() to create an instance whose properties will be loaded from an XML stream.
        /// </summary>
        public MakeReleaseProject()
            : base(null, ProjectPreference.DoNotOffer, "empty project")
        {
            this.InitOnChangeEnvVarHandler();
        }

        /// <summary>
        /// Creates an instance of the provided name including the targets of the provided projects.
        /// </summary>
        /// <remarks>Note, that projects of this type always are optional since they require environment <c>BUILD_VERSION</c>
        /// to be set. Otherwise, all build programs providing this project will require users to define a build version
        /// in order to build anything.</remarks>
        /// <param name="name">Name of the resulting project release. this will be used in user interfaces.</param>
        /// <param name="originalProjects">Instances of wx.Build.Net.CSharpAssemblyProject and wx.Build.Cxx.DynamicLibraryProject or projects implementing wx.Build.IFileProducts.</param>
        public MakeReleaseProject(string name, params BuildProject[] originalProjects)
            : base(System.Reflection.Assembly.GetCallingAssembly(), ProjectPreference.Optional, name)
        {
            if (originalProjects == null || originalProjects.Length == 0)
                throw new Exception("Cannot make empty release project \"" + name + "\".");
            foreach (BuildProject p in originalProjects)
            {
                if (p is Net.CSharpAssemblyProject)
                {
                    Net.CSharpAssemblyProject netP=(Net.CSharpAssemblyProject) p;
                    this._assemblyProjects[netP.AssemblyFile]=netP;
                }
                else if (p is Cxx.DynamicLibraryProject)
                {
                    Cxx.DynamicLibraryProject dllP = (Cxx.DynamicLibraryProject)p;
                    this._nativeDllProjects[dllP.Target]=dllP;
                }
                else if (p is IFileProducts)
                {
                    IFileProducts fileP = (IFileProducts)p;
                    this._otherProjects.Add(fileP);
                }
                else
                    throw new Exception("Cannot use project \"" + p.Name + "\" as part of a release (project \"" + name + "\").");
            }
            this.InitOnChangeEnvVarHandler();
        }

        /// <summary>
        /// Deep copy
        /// </summary>
        /// <param name="src">The source</param>
        public MakeReleaseProject(MakeReleaseProject src) : base(null, src.Preference, src.Name)
        {
            foreach (KeyValuePair<ContentFile, Build.Net.CSharpAssemblyProject> pair in src._assemblyProjects)
                this._assemblyProjects.Add(pair.Key, pair.Value);
            foreach (KeyValuePair<ContentFile, Build.Cxx.DynamicLibraryProject> pair in src._nativeDllProjects)
                this._nativeDllProjects.Add(pair.Key, pair.Value);
            foreach(IFileProducts otherProject in src._otherProjects)
                this._otherProjects.Add((IFileProducts)otherProject.Clone());
            this.InitOnChangeEnvVarHandler();
        }


        #endregion

        #region Event Management
        event EnvironmentVarInfo.EventHandler _onChangeEnvVarHandler = null;

        void InitOnChangeEnvVarHandler()
        {
            this._onChangeEnvVarHandler += new EnvironmentVarInfo.EventHandler(this.OnChangeEnvVar);
        }

        void OnChangeEnvVar(EnvironmentVarInfo var)
        {
            if (var.Varname == this.BuildVersionVariable.Varname)
            {
                this._shadowCSharpProjects = null;
                this._shadowDllProjects = null;
            }
        }
        #endregion

        #region BuildProject Overrides
        /// <summary>
        /// Description of the project.
        /// Currently: "A release composed of the projects ..."
        /// </summary>
        public override string Description
        {
            get
            {
                StringBuilder sb = new StringBuilder();
                sb.Append("A release composed of the projects ");
                bool first = true;
                foreach (BuildProject p in this._assemblyProjects.Values)
                {
                    if (!first)
                        sb.Append(",");
                    sb.Append(p.Name);
                    first = false;
                }
                foreach (BuildProject p in this._nativeDllProjects.Values)
                {
                    if (!first)
                        sb.Append(",");
                    sb.Append(p.Name);
                    first = false;
                }
                foreach (BuildProject p in this._otherProjects)
                {
                    if (!first)
                        sb.Append(",");
                    sb.Append(p.Name);
                    first = false;
                }
                sb.Append(".");
                return sb.ToString();
            }
        }

        /// <summary>
        /// This will make the project instance ready to be solved.
        /// The build system will only use one project instance per target.
        /// Thus, projects will be registered. This will try to register this instance.
        /// If the database of registered project already contains a project instance
        /// for the targets of this instance, this will return this instance.
        /// </summary>
        /// <returns></returns>
        public new MakeReleaseProject GetSingleton()
        {
            return (MakeReleaseProject)((BuildProject)this).GetSingleton();
        }

        #region Shadow Projects
        List<KeyValuePair<Cxx.DynamicLibraryProject, Cxx.DynamicLibraryProject>> _shadowDllProjects = null;
        /// <summary>
        /// All projects building native Dlls that will be part of the release will be transformed:
        /// Occasionally, contained version info will be changed. Additionally, the resulting DLL will
        /// be changed. This collection contains the transformations of the original native DLL projects
        /// reflecting these changes.
        /// <para>
        /// This collection will contain pairs of the original project as key value and the transformed project as
        /// value.
        /// </para>
        /// <para>
        /// Do not change the result. Consider the result to be read-only.
        /// </para>
        /// </summary>
        public ICollection<KeyValuePair<Cxx.DynamicLibraryProject,Cxx.DynamicLibraryProject>> ShadowDllProjects
        {
            get
            {
                if (this._shadowDllProjects == null)
                {
                    BuildConfig.OpenSectionInXmlLogFile("shadow_projects");
                    try
                    {
                        Version buildVersion = (Version)this.BuildVersionVariable.Get(DefaultVersion);
                        this._shadowDllProjects = new List<KeyValuePair<Cxx.DynamicLibraryProject, Cxx.DynamicLibraryProject>>();
                        foreach (Cxx.DynamicLibraryProject dllProject in this._nativeDllProjects.Values)
                        {
                            Cxx.DynamicLibraryProject shadowProject = new wx.Build.Cxx.DynamicLibraryProject(this.Preference,
                                this.Name+" "+dllProject.Name,
                                ConversionPathToPathWithVersion(dllProject.Target.DirectoryName, buildVersion),
                                ConversionFilenameToFilenameWithVersion(dllProject.Target.BaseFileName, buildVersion),
                                "Created automatically as part of a release. Currently, this can only be built together with the release project. " +
                                dllProject.Description);
                            #region Prepare the sources of RC files first.
                            if (dllProject.RCFiles != null)
                            {
                                foreach (ContentFile rcfile in dllProject.RCFiles)
                                {
                                    ContentFile newRCFile = ConversionFullFilenameToFullFilenameWithVersion(rcfile, buildVersion, false);
                                    shadowProject.AddRCFile(newRCFile);
                                }
                            }
                            #endregion
                            shadowProject.AddStaticLibrary(dllProject.StaticLibraries);
                            shadowProject.AddCSources(dllProject.CSources);
                            shadowProject.AddCPlusPlusSources(dllProject.CPlusPlusSources);
                            this._shadowDllProjects.Add(new KeyValuePair<Cxx.DynamicLibraryProject, Cxx.DynamicLibraryProject>(dllProject, shadowProject));
                            BuildConfig.LogProjectOnXmlLogFile(dllProject, true);

                            shadowProject.GetSingleton();
                        }
                    }
                    finally
                    {
                        BuildConfig.CloseSectionInXmlLogFile();
                    }
                }
                return this._shadowDllProjects;
            }
        }

        SortedList<ContentFile, ICollection<ReplaceVersionInCSharpFile>> _actionsToProduceSourcesOfShadowCSharpProjects = null;
        List<KeyValuePair<Net.CSharpAssemblyProject, Net.CSharpAssemblyProject>> _shadowCSharpProjects = null;
        /// <summary>
        /// Helper method to derive the CSharp projects that produce those managed DLLs that actually will be included
        /// into the release and those actions that are necessary to convert sources.
        /// </summary>
        void MakeShadowCSharpProjects()
        {
            BuildConfig.OpenSectionInXmlLogFile("shadow_projects");
            try
            {
                Version buildVersion = (Version)this.BuildVersionVariable.Get(DefaultVersion);
                this._shadowCSharpProjects = new List<KeyValuePair<Net.CSharpAssemblyProject, Net.CSharpAssemblyProject>>();
                this._actionsToProduceSourcesOfShadowCSharpProjects = new SortedList<ContentFile, ICollection<ReplaceVersionInCSharpFile>>();
                foreach (Net.CSharpAssemblyProject dllProject in this._assemblyProjects.Values)
                {
                    Net.CSharpAssemblyProject shadowProject = new wx.Build.Net.CSharpAssemblyProject(this.Preference,
                        this.Name + " " + dllProject.Name,
                        ConversionFullFilenameToFullFilenameWithVersion(dllProject.AssemblyFile, buildVersion, true),
                        "Created automatically as part of a release. Currently, this can only be built together with the release project.\n"+
                        dllProject.Description);
                    if (dllProject.Signature != null) // this must be done here because this will change the type of the assembly project.
                        shadowProject.Signature = dllProject.Signature;
                    this._actionsToProduceSourcesOfShadowCSharpProjects[shadowProject.AssemblyFile] = new List<ReplaceVersionInCSharpFile>();
                    #region Prepare the C# sources first.
                    if (dllProject.CSharpSources != null)
                    {
                        List<string> files = new List<string>();
                        bool foundVersionInfo = false;
                        bool foundProjectDescr = false;
                        bool foundProjectName = false;
                        foreach (ContentFile csharpFile in dllProject.CSharpSources.Files)
                        {
                            ContentFile newCSharpFile = ConversionFullFilenameToFullFilenameWithVersion(csharpFile, buildVersion, false);
                            ReplaceVersionInCSharpFile action = new ReplaceVersionInCSharpFile(this.GetDllConversionScheme(buildVersion),
                                csharpFile, newCSharpFile);
                            ReplaceVersionInCSharpFile.ActionDescr actionDescr = action.ProbableActions();
                            if ((actionDescr & ReplaceVersionInCSharpFile.ActionDescr.FoundAssemblyTitle) == ReplaceVersionInCSharpFile.ActionDescr.FoundAssemblyTitle)
                                foundProjectName = true;
                            if ((actionDescr & ReplaceVersionInCSharpFile.ActionDescr.FoundAssemblyDescription) == ReplaceVersionInCSharpFile.ActionDescr.FoundAssemblyDescription)
                                foundProjectDescr = true;
                            if ((actionDescr & ReplaceVersionInCSharpFile.ActionDescr.ChangeVersionInfo) == ReplaceVersionInCSharpFile.ActionDescr.ChangeVersionInfo)
                                foundVersionInfo = true;
                            if ((actionDescr | ReplaceVersionInCSharpFile.ActionDescr.AllActions) == ReplaceVersionInCSharpFile.ActionDescr.None)
                                files.Add(csharpFile.FileName);
                            else
                            {
                                files.Add(newCSharpFile.FileName);
                                this._actionsToProduceSourcesOfShadowCSharpProjects[shadowProject.AssemblyFile].Add(action);
                            }
                        }
                        #region Create missing version information
                        if (!foundProjectDescr || !foundProjectName || !foundVersionInfo)
                        {
                            TempFilesParameters temp = (TempFilesParameters)BuildConfig.GetDefaultParameterOfType(typeof(TempFilesParameters));
                            string newFilename = temp.CreatePathFor(System.IO.Path.Combine(System.IO.Path.Combine(this.Name, dllProject.Name), "ReleaseAssemblyInfo.dll"), ContentType.CSharpCode).FileName;
                            if (!Directory.Exists(Path.GetDirectoryName(newFilename)))
                                Directory.CreateDirectory(Path.GetDirectoryName(newFilename));
                            using (System.IO.StreamWriter newFile = new StreamWriter(newFilename))
                            {
                                newFile.WriteLine("/** <summary> This file has been created by wx.Build.Release.MakeReleaseProject {0}", this.Name);
                                newFile.WriteLine("  * to hold version information for project {0}.", dllProject.Name);
                                newFile.WriteLine("  * All changes to this file will be overridden on rebuilding.");
                                newFile.WriteLine("  * \file");
                                newFile.WriteLine(" </summary> */");
                                newFile.WriteLine("using System.Reflection;");
                                newFile.WriteLine("using System.Runtime.InteropServices;");
                                if (!foundProjectName)
                                    newFile.WriteLine("[assembly:AssemblyTitle(\"{0}\")]", dllProject.Name.Replace("\\", "\\\\").Replace("\"", "\\\""));
                                if (!foundProjectDescr)
                                    newFile.WriteLine("[assembly:AssemblyDescription(\"{0}\")]", dllProject.Description.Replace("\\", "\\\\").Replace("\"", "\\\""));
                                if (!foundVersionInfo)
                                    newFile.WriteLine("[assembly:AssemblyVersion(\"{0}\")]", buildVersion.ToString());
                            }
                            BuildConfig.HandleMessageObject("Created file {0} to define missing version info for project {1}.", newFilename, dllProject.Name);
                            files.Add(newFilename);
                        }
                        #endregion
                        shadowProject.CSharpSources = new ContentFiles(ContentType.CSharpCode, files.ToArray());
                    }
                    shadowProject.ReferencesAssemblies = dllProject.ReferencesAssemblies;
                    if (dllProject.PInvokeDependencies != null && this._shadowDllProjects != null)
                    {
                        shadowProject.PInvokeDependencies = dllProject.PInvokeDependencies;
                        foreach (KeyValuePair<Cxx.DynamicLibraryProject, Cxx.DynamicLibraryProject> projectPair in this._shadowDllProjects)
                        {
                            shadowProject.PInvokeDependencies = shadowProject.PInvokeDependencies.Replace(projectPair.Key.CreateRefToFileProject(), projectPair.Value.CreateRefToFileProject());
                            shadowProject.PInvokeDependencies = shadowProject.PInvokeDependencies.Replace(projectPair.Key.Target, projectPair.Value.Target);
                        }
                    }
                    if (dllProject.ExternalResources != null)
                        shadowProject.ExternalResources = dllProject.ExternalResources;
                    if (dllProject.Resources != null)
                        shadowProject.Resources = dllProject.Resources;
                    if (dllProject.MainClass != null)
                        shadowProject.MainClass = dllProject.MainClass;
                    if (dllProject.Features != null)
                        shadowProject.Features.AddRange(dllProject.Features);
                    if (dllProject.WinIcon != null)
                        shadowProject.WinIcon = dllProject.WinIcon;
                    #endregion
                    this._shadowCSharpProjects.Add(new KeyValuePair<Net.CSharpAssemblyProject, Net.CSharpAssemblyProject>(dllProject, shadowProject));
                }
                #region After creating the shadow C# projects, we have to change occasionally specified references among them
                foreach (KeyValuePair<Net.CSharpAssemblyProject, Net.CSharpAssemblyProject> projectPair in this._shadowCSharpProjects)
                {
                    // unfortunately, this is quadratic with the number of contained project
                    Net.CSharpAssemblyProject shadowP = projectPair.Value;
                    if (shadowP.ReferencesAssemblies != null)
                    {
                        foreach (KeyValuePair<Net.CSharpAssemblyProject, Net.CSharpAssemblyProject> replacementPair in this._shadowCSharpProjects)
                        {
                            Net.CSharpAssemblyProject oldP = replacementPair.Key;
                            Net.CSharpAssemblyProject newP = replacementPair.Value;
                            shadowP.ReferencesAssemblies = shadowP.ReferencesAssemblies.Replace(oldP.CreateRefToFileProject(), newP.CreateRefToFileProject());
                            shadowP.ReferencesAssemblies = shadowP.ReferencesAssemblies.Replace(oldP.AssemblyFile, newP.AssemblyFile);
                        }
                    }
                    shadowP.GetSingleton();
                    BuildConfig.LogProjectOnXmlLogFile(shadowP, true);
                }
                #endregion
            }
            finally
            {
                BuildConfig.CloseSectionInXmlLogFile();
            }
        }

        /// <summary>
        /// All projects building managed Dlls and executables from C# sources that will be part of the release
        /// will be transformed:
        /// Occasionally, contained version info will be changed. Additionally, included P-Invoke references
        /// to native DLLs that are also part of the release will change.
        /// <para>
        /// This collection will contain pairs of the original project as key value and the transformed project as
        /// value.
        /// </para>
        /// <para>
        /// Do not change the result. Consider the result to be read-only.
        /// </para>
        /// </summary>
        public ICollection<KeyValuePair<Net.CSharpAssemblyProject, Net.CSharpAssemblyProject>> ShadowCSharpProjects
        {
            get
            {
                if (this._shadowCSharpProjects == null || this._actionsToProduceSourcesOfShadowCSharpProjects == null)
                    this.MakeShadowCSharpProjects();
                return this._shadowCSharpProjects;
            }
        }

        /// <summary>
        /// A dictionary containing collections of actions that are necessary to prepare the sources of a contained C# assembly project.
        /// Assume, that <c>p</c> is a project to produce managed assembly <tt>wx.NET</tt>. Then the result of this method
        /// contains a collection for key content file <tt>"wx.NET"</tt> comprising a number of actions of class
        /// ReplaceVersionInCSharpFile that have to run to adopt the original sources of <tt>"wx.NET"</tt> to the new release.
        /// </summary>
        public IDictionary<ContentFile, ICollection<ReplaceVersionInCSharpFile>> ActionsToProduceSourcesForCSharpShadowProjects
        {
            get
            {
                if (this._actionsToProduceSourcesOfShadowCSharpProjects == null)
                    this.MakeShadowCSharpProjects();
                return this._actionsToProduceSourcesOfShadowCSharpProjects;
            }
        }
        #endregion

        /// <summary>
        /// You may use this method to control the form of the file name that will be used to
        /// serialize this (the original filename). The argument is a path to an existing
        /// file or directory. This will strip a directory information from this path. After
        /// that, the original file name will change to something equivalent to the absolute
        /// filename (referring to the same file) but now relative to the directory as specified
        /// by the argument.
        /// 
        /// Use this method to prepare content file instance for serialization in such a way
        /// that all file names become relative to the same directory.
        /// </summary>
        /// <param name="nameOfAValidDirOrFile">The name of an existing file or directory. This name
        /// will - if relative - be expanded using the BuildConfig. If this is <c>null</c>, this
        /// method will return without any effect. This may also be the name of a not yet existing file.
        /// In that case, however, the directory name shall exist.</param>
        /// <seealso cref="OriginalFileName"/>
        /// <exception cref="System.ArgumentException">Will be raised if the argument is neither the path
        /// to an existing file nor directory.</exception>
        public override void NormalizeOriginalFileName(string nameOfAValidDirOrFile)
        {
            // do the base procedure.
            base.NormalizeOriginalFileName(nameOfAValidDirOrFile);

            // if known, also normalize the shadow projects.
            if (this._shadowDllProjects != null && this._shadowDllProjects.Count > 0)
            {
                foreach (KeyValuePair<Net.CSharpAssemblyProject, Net.CSharpAssemblyProject> pPair in this._shadowCSharpProjects)
                {
                    pPair.Key.NormalizeOriginalFileName(nameOfAValidDirOrFile);
                    pPair.Value.NormalizeOriginalFileName(nameOfAValidDirOrFile);
                }
            }
            if (this._shadowDllProjects != null && this._shadowDllProjects.Count > 0)
            {
                foreach (KeyValuePair<Cxx.DynamicLibraryProject, Cxx.DynamicLibraryProject> pPair in this._shadowDllProjects)
                {
                    pPair.Key.NormalizeOriginalFileName(nameOfAValidDirOrFile);
                    pPair.Value.NormalizeOriginalFileName(nameOfAValidDirOrFile);
                }
            }
        }

        /// <summary>This will use actions of the classes CopyFileAction in order to
        /// copy files into the release directory. Actions of class ReplaceVersionInCSharpFile will be
        /// used to adopt C# sources, ReplaceVersionInRCFile will be used to change RC-files if they
        /// contain version information of a native Windoes DLL that is part of the project.
        /// Sources of contained Dll-Projects and managed executables will be adopted (using approrpiate
        /// actions). Sources of native DLLs will also be adopted as described above. Additionally, 
        /// native DLLs will be renamed. All P-Invoke references to the renamed DLLs will be changed.
        /// </summary>
        public override ICollection<IBuildAction> CreateActionPlan(BuildToolFamilyEnv env)
        {
            Version buildVersion = (Version)this.BuildVersionVariable.Get(DefaultVersion);
            // result will contain an action for each of the targets.
            List<IBuildAction> result = new List<IBuildAction>();
            #region Native DLL projects
            foreach (KeyValuePair<Cxx.DynamicLibraryProject,Cxx.DynamicLibraryProject> dllProjectPair in this.ShadowDllProjects)
            {
                Cxx.DynamicLibraryProject originalProject = dllProjectPair.Key;
                Cxx.DynamicLibraryProject transformedProject = dllProjectPair.Value;
                SequenceOfBuildActions actionForThisProject = new SequenceOfBuildActions();
                #region Add actions transforming RC-files
                foreach (ContentFile rcfile in originalProject.RCFiles)
                {
                    ContentFile newRCFile = ConversionFullFilenameToFullFilenameWithVersion(rcfile, buildVersion, false);
                    ReplaceVersionInRCFile newaction = new ReplaceVersionInRCFile(rcfile, newRCFile);
                    actionForThisProject.Add(newaction);
                }
                #endregion

                #region Add actions to build the shadow project
                foreach (IBuildAction action in transformedProject.CreateActionPlan(env))
                {
                    actionForThisProject.Add(action);
                    break; // only one action since we have only one goal.
                }
                #endregion
                result.Add(actionForThisProject);
            }
            #endregion

            #region C# Projects
            foreach (KeyValuePair<Net.CSharpAssemblyProject, Net.CSharpAssemblyProject> projectPair in this.ShadowCSharpProjects)
            {
                Net.CSharpAssemblyProject releasedProject=projectPair.Value;
                SequenceOfBuildActions actionForThisProject = new SequenceOfBuildActions();
                #region Actions to prepare the sources of the released project.
                foreach (ReplaceVersionInCSharpFile action in this.ActionsToProduceSourcesForCSharpShadowProjects[releasedProject.AssemblyFile])
                {
                    actionForThisProject.Add(action);
                }
                #endregion

                #region Include the actions to produce the shadow project.
                ICollection<IBuildAction> actions = releasedProject.CreateActionPlan(env);
                if (actions != null)
                {
                    foreach (IBuildAction action in actions)
                    {
                        actionForThisProject.Add(action);
                        break; // only one action since we have only one goal.
                    }
                }
                #endregion
                result.Add(actionForThisProject);
            }
            #endregion

            #region All Other Projects: Produce Copy Actions
            foreach (IFileProducts files in this._otherProjects)
            {
                foreach (ContentFile file in files.Files)
                {
                    ContentFile newFile = ConversionFullFilenameToFullFilenameWithVersion(file, buildVersion, true);
                    CopyFileAction newAction = new CopyFileAction(file.Type, file.FileName, newFile.FileName);
                    result.Add(newAction);
                }
            }
            #endregion
            return result;
        }

        /// <returns>The list of prerequisites that are required to build the release.</returns>
        /// <summary>This project requires all sources of those projects on native and managed DLLs
        /// and executable programs that are part of the release. Additionally, this type of project
        /// also requires all targets of other contained project producing content files (implementing
        /// wx.Build.IFileProducts).
        /// </summary>
        public override ICollection<IBuildProduct> GetPrerequisites()
        {
            List<IBuildProduct> depsToTest = new List<IBuildProduct>();
            foreach (BuildProject p in this._assemblyProjects.Values)
                foreach (IBuildProduct t in p.GetPrerequisites())
                {
                    depsToTest.Add(t);
                }
            foreach (BuildProject p in this._nativeDllProjects.Values)
                foreach (IBuildProduct t in p.GetPrerequisites())
                    depsToTest.Add(t);
            // well, p might contain prerequisites with correspondents in the release.
            // test this here. we do not need all original prereqs here. sample:
            // wx-c.dll is a prereq of the wx.NET.dll. however, a released version
            // of the wx-c.dll is also part of the release. thus, do not add wx-c.dll as
            // a prereq here.
            List<IBuildProduct> result = new List<IBuildProduct>();
            foreach (IBuildProduct prereq in depsToTest)
            {
                IBuildProduct testedPrereq = prereq;
                if (testedPrereq is IFileProducts)
                {
                    foreach (FileProject p in this._nativeDllProjects.Values)
                    {
                        if (testedPrereq == null)
                            break;
                        testedPrereq = ((IFileProducts)testedPrereq).Replace(p.CreateRefToFileProject(), null);
                    }
                    foreach (FileProject p in this._assemblyProjects.Values)
                    {
                        if (testedPrereq == null)
                            break;
                        testedPrereq = ((IFileProducts)testedPrereq).Replace(p.CreateRefToFileProject(), null);
                    }
                }
                if (testedPrereq != null)
                    result.Add(testedPrereq);
            }
            foreach (IFileProducts p in this._otherProjects)
                result.Add(p);
            return result;
        }

        EnvironmentVarInfo _buildVersionVariable = null;
        /// <summary>
        /// The variable info for variable BUILD_VERSION.
        /// </summary>
        public EnvironmentVarInfo BuildVersionVariable
        {
            get
            {
                if (this._buildVersionVariable == null)
                    this._buildVersionVariable = new EnvironmentVarInfo("BUILD_VERSION", "The release version", typeof(System.Version), true);
                return this._buildVersionVariable;
            }
        }

        /// <summary>This project requires variable BUILD_VERSION to be set.</summary>
        /// <remarks> Variable BUILD_VERSION must have a System.Version string as value.
        /// </remarks>
        public override IDictionary<string, EnvironmentVarInfo> UsedVars
        {
            get
            {
                SortedList<string, EnvironmentVarInfo> result = new SortedList<string, EnvironmentVarInfo>();
                result[BuildVersionVariable.Varname] = BuildVersionVariable;
                return result;
            }
        }

        /// <returns>A collection of the files that will be rebuild (with new version information), renamed, or copied
        /// from the original projects.</returns>
        public override ICollection<IBuildProduct> GetTargets()
        {
            List<IBuildProduct> result = new List<IBuildProduct>();
            this.UpdateOriginalFileToReleasedFile();
            foreach (ContentFile f in this._originalFileToReleasedFile.Values)
                result.Add(f);
            return result;
        }
        #endregion

        #region Object/IComparable Overrides
        /// <summary>
        /// This comparison relies on the projects that are contained if both - this and the argument - are of the same type.
        /// Otherwise, the result is the comparison of the full type name of this and the argument - as required by the 
        /// specification of BuildProject.CompareTo().
        /// </summary>
        /// <param name="obj">The object that will be compared to this instance.</param>
        /// <returns>-1, 0, or 1 like in all the other implementations of this method.</returns>
        public override int CompareTo(object obj)
        {
            if (obj.GetType().Equals(this.GetType()))
            {
                if (Object.ReferenceEquals(this, obj))
                    return 0;
                SortedDictionary<IComparable, IComparable> pThis = new SortedDictionary<IComparable, IComparable>();
                SortedDictionary<IComparable, IComparable> pArg = new SortedDictionary<IComparable, IComparable>();
                MakeReleaseProject arg = (MakeReleaseProject)obj;
                #region Comparison: Do both instances have the different numbers of CSharp, native DLL, or other projects
                int cmp = this._nativeDllProjects.Count.CompareTo(arg._nativeDllProjects.Count);
                if (cmp != 0)
                    return cmp;
                cmp = this._assemblyProjects.Count.CompareTo(arg._assemblyProjects.Count);
                if (cmp != 0)
                    return cmp;
                cmp = this._otherProjects.Count.CompareTo(arg._otherProjects.Count);
                if (cmp != 0)
                    return cmp;
                #endregion
                #region The number of projects is the same. Put them into a normalized order and compare.
                foreach (Cxx.DynamicLibraryProject p in this._nativeDllProjects.Values)
                        pThis[p] = p;
                foreach (Cxx.DynamicLibraryProject p in arg._nativeDllProjects.Values)
                    pArg[p] = p;
                foreach (Net.CSharpAssemblyProject p in this._assemblyProjects.Values)
                    pThis[p] = p;
                foreach (Net.CSharpAssemblyProject p in arg._assemblyProjects.Values)
                    pArg[p] = p;
                foreach (IFileProducts p in this._otherProjects)
                    pThis[p] = p;
                foreach (IFileProducts p in arg._otherProjects)
                    pArg[p] = p;

                #region Comparison of contained projects.
                IEnumerator<KeyValuePair<IComparable, IComparable>> iThis = pThis.GetEnumerator();
                IEnumerator<KeyValuePair<IComparable, IComparable>> iArg  =  pArg.GetEnumerator();
                while (iThis.MoveNext() && iArg.MoveNext())
                {
                    cmp = iThis.Current.Key.CompareTo(iArg.Current.Key);
                    if (cmp != 0)
                        return cmp;
                }
                #endregion
                #endregion
                return 0; // no difference found
            }
            else
                return this.GetType().FullName.CompareTo(obj.GetType().FullName);
        }

        public override int GetHashCode()
        {
            int result = 0;
            foreach (Net.CSharpAssemblyProject p in this._assemblyProjects.Values)
                result = result ^ p.AssemblyFile.GetHashCode();
            foreach (Cxx.DynamicLibraryProject p in this._nativeDllProjects.Values)
                result = result ^ p.Target.GetHashCode();
            return result;
        }
        #endregion

        #region XML serialization overrides
        /// <summary>
        /// Reading a project from an XML stream.
        /// Please note, that this method requires all contained projects to be already part of the loaded projects.
        /// </summary>
        /// <param name="reader"></param>
        public override void ReadXml(System.Xml.XmlReader reader)
        {
            this._actionsToProduceSourcesOfShadowCSharpProjects = null;
            this._buildVersionVariable = null;
            this._originalFileToReleasedFile=null;
            this._shadowCSharpProjects = null;
            this._shadowDllProjects = null;
            reader.IsStartElement("make-release-project");
            Guid oldGuid = this.Id;
            this.ReadStdAttributes(reader);
            reader.Read();
            this.ReadProject(reader);
            reader.ReadStartElement("release-files");
            if (reader.IsStartElement("csharp-assembly-projects"))
            {
                reader.ReadStartElement("csharp-assembly-projects");
                while (reader.IsStartElement("csharp-assembly-project"))
                {
                    Net.CSharpAssemblyProject p = new Net.CSharpAssemblyProject();
                    p.ReadXml(reader);
                    this._assemblyProjects.Add(p.CreateRefToSingleFileProject().File, p);
                }
                reader.ReadEndElement();
            }
            if (reader.IsStartElement("native-dll-projects"))
            {
                reader.ReadStartElement("native-dll-projects");
                while (reader.IsStartElement("native-dll-project"))
                {
                    Cxx.DynamicLibraryProject p = new wx.Build.Cxx.DynamicLibraryProject();
                    p.ReadXml(reader);
                    this._nativeDllProjects.Add(p.Target, p);
                }
                reader.ReadEndElement();
            }
            if (reader.IsStartElement("other-projects"))
            {
                reader.ReadStartElement("other-projects");
                while (reader.IsStartElement("project"))
                {
                    this._otherProjects.Add((IFileProducts)BuildProject.ReadSerializable(reader, "project"));
                }
                reader.ReadEndElement();
            }
            reader.ReadEndElement();
            this.SetAsKnownProject(oldGuid);
        }

        /// <summary>
        /// Serializes all properties of this project. Please note, that this will only write
        /// references of the contained projects. So, make sure that this runs after serializing
        /// all contained projects.
        /// </summary>
        /// <param name="writer"></param>
        public override void WriteXml(System.Xml.XmlWriter writer)
        {
            writer.WriteStartElement("make-release-project");
            this.WriteStdAttributes(writer);
            this.WriteProject(writer);
            writer.WriteStartElement("release-files");
            if (this._assemblyProjects != null)
            {
                writer.WriteStartElement("csharp-assembly-projects");
                foreach (Net.CSharpAssemblyProject p in this._assemblyProjects.Values)
                    p.WriteXml(writer);
                writer.WriteEndElement();
            }
            if (this._nativeDllProjects != null)
            {
                writer.WriteStartElement("native-dll-projects");
                foreach (Cxx.DynamicLibraryProject p in this._nativeDllProjects.Values)
                    p.WriteXml(writer);
                writer.WriteEndElement();
            }
            if (this._otherProjects != null)
            {
                writer.WriteStartElement("other-projects");
                foreach (IFileProducts p in this._otherProjects)
                    BuildProject.WriteSerializable(writer, p, "project");
                writer.WriteEndElement();
            }
            writer.WriteEndElement();
            writer.WriteEndElement();
        }
        #endregion

        public override object Clone()
        {
            return new MakeReleaseProject(this);
        }
    }

    /// <summary>
    /// This action receives an RC file ContentType.RCFile and produces one. The file version and project version descriptor will be replaced according to variable <c>BUILD_VERSION</c>.
    /// </summary>
    public class ReplaceVersionInRCFile : BaseAction, IBuildAction, System.Xml.Serialization.IXmlSerializable, ICloneable
    {
        #region State
        ContentFile _src=null;
        ContentFile _target = null;
        #endregion

        #region CTor
        /// <summary> This creates an instance of this action.
        /// Parameters are source file and target file both of type ContentType.RCFile.</summary>
        internal ReplaceVersionInRCFile(ContentFile src, ContentFile target)
        {
            this._src = src;
            this._target = target;
            if (!this._src.Type.Implies(ContentType.RCFile))
                throw new Exception("Cannot replace RC file version in "+this._src.FileName+" since this is not a RC file.");
            if (!this._target.Type.Implies(ContentType.RCFile))
                throw new Exception("Cannot produce " + this._target.FileName + " since this is not a RC file.");
        }

        public ReplaceVersionInRCFile(ReplaceVersionInRCFile src)
        {
            this._src = new ContentFile(src._src);
            this._target = new ContentFile(src._target);
        }
        #endregion

        #region IBuildAction Member
        /// <summary>
        /// This is currently used directly by the MakeReleaseProject without using a factory.
        /// </summary>
        public IBuildActionProvider ActionProvider
        {
            get { return null; }
        }

        public string Name
        {
            get { return "RCFileVersion"; }
        }

        public ActionPriority Priority
        {
            get { return ActionPriority.Default; }
        }

        EnvironmentVarInfo _buildVersionVariable = null;
        /// <summary>
        /// The variable info for variable BUILD_VERSION.
        /// </summary>
        public EnvironmentVarInfo BuildVersionVariable
        {
            get
            {
                if (this._buildVersionVariable == null)
                    this._buildVersionVariable = new EnvironmentVarInfo("BUILD_VERSION", "The release version", typeof(System.Version), true);
                return this._buildVersionVariable;
            }
        }

        /// <summary>This tool requires variable BUILD_VERSION to be set.
        /// Variable BUILD_VERSION must have a System.Version string as value.</summary>
        public override IDictionary<string, EnvironmentVarInfo> UsedVars
        {
            get
            {
                SortedList<string, EnvironmentVarInfo> result = new SortedList<string, EnvironmentVarInfo>();
                result["BUILD_VERSION"] = this.BuildVersionVariable;
                return result;
            }
        }

        string ReplaceStringVersion(string itemName, string rcText)
        {
            System.Text.RegularExpressions.Regex regex = new System.Text.RegularExpressions.Regex(
                "VS_VERSION[\\w\\W]*VALUE[\\s]*\\\""+itemName+"\\\"[\\s]*,[\\s]\\\"(?<version_info>[^\\\"]*)\\\"");
            string newValue = this.BuildVersionVariable.Get().ToString();
            int position = 0;
            System.Text.RegularExpressions.Match m = regex.Match(rcText);
            while (m.Success)
            {
                Group vsGroup = m.Groups["version_info"];
                if (vsGroup.Success)
                {
                    string oldValue = vsGroup.Value;
                    int fromPos = vsGroup.Index;
                    rcText = rcText.Substring(0, fromPos)
                        + newValue
                        + rcText.Substring(fromPos + oldValue.Length);
                    position = fromPos + newValue.Length;
                    m = regex.Match(rcText, position);
                }
            }
            return rcText;
        }

        string ReplaceIntVersion(string itemName, string rcText)
        {
            System.Text.RegularExpressions.Regex regex = new System.Text.RegularExpressions.Regex(
                "VS_VERSION[\\w\\W]*" + itemName + "[\\s]*(?<version_info>.*)");
            string newValue = this.BuildVersionVariable.Get().ToString();
            newValue = newValue.Replace('.', ',');
            int position = 0;
            System.Text.RegularExpressions.Match m = regex.Match(rcText);
            while (m.Success)
            {
                Group vsGroup = m.Groups["version_info"];
                if (vsGroup.Success)
                {
                    string oldValue = vsGroup.Value;
                    int fromPos = vsGroup.Index;
                    rcText = rcText.Substring(0, fromPos)
                        + newValue
                        + rcText.Substring(fromPos + oldValue.Length);
                    position = fromPos + newValue.Length;
                    m = regex.Match(rcText, position);
                }
            }
            return rcText;
        }

        /// <summary>
        /// Searches the input file for a version information and stores a copy with replaces version info at the target.
        /// This will report an error if either the source does not exist or environment variable BUILD_VERSION is undefined or unknown.
        /// </summary>
        /// <param name="env">The execution environment shared by all tools of the same family.</param>
        /// <param name="validityOfBuildSystem">The time stamp when the implementation of the build system changed.</param>
        /// <returns>true on success, false on failure (that will also be reported to the error handler)</returns>
        public bool Execute(BuildToolFamilyEnv env, DateTime validityOfBuildSystem)
        {
            if (!this._src.Exists)
            {
                BuildConfig.HandleErrorObject(ErrorObject.MessageType.Error, "Missing rc file {0}.", this._src.FileName);
                return false;
            }
            if (this.BuildVersionVariable.IsEmpty())
            {
                BuildConfig.HandleErrorObject(ErrorObject.MessageType.Error, "Variable BUILD_VERSION must be set.");
                return false;
            }
            using (StreamReader src = new StreamReader(this._src.FileName))
            {
                string rcText = src.ReadToEnd();
                rcText = this.ReplaceStringVersion("FileVersion", rcText);
                rcText = this.ReplaceStringVersion("ProductVersion", rcText);
                rcText = this.ReplaceIntVersion("FILEVERSION", rcText);
                rcText = this.ReplaceIntVersion("PRODUCTVERSION", rcText);
                using (StreamWriter target = new StreamWriter(this._target.FileName))
                {
                    target.Write(rcText);
                }
            }
            BuildConfig.HandleMessageObject("Action \"ReplaceVersionInRCFile\" created {1} to replace {0}.", this._src.FileName, this._target.FileName);
            return true;
        }

        /// <summary>
        /// This implementation will look for a program start info that implements this actions.
        /// If program start info is <c>null</c>, this implementation will raise an exception.
        /// Overload this if you have to create another implementation providing this feature.
        /// </summary>
        /// <param name="env">This is an environment that different tools of the same family may use to exchange information.
        /// This store is typically used to save information on configuration files or thinsgs of that kind that will be
        /// shared among all tools of the same family.</param>
        /// <param name="booCodeLines">The code that will actually build something will be appended to this writer.</param>
        /// <param name="indention">A string that shall preceed all created lines. </param>
        /// <exception cref="NotSupportedException">Will be thrown if this feature is not supported.</exception>
        /// <seealso cref="GetProgrammStartInfo"/>
        public override void AppendBooCode(List<string> booCodeLines, string indention, BuildToolFamilyEnv env)
        {
            throw new NotSupportedException("Replacement of version strings in RC not supported with BOO.");
        }
        #endregion

        #region IComparable Member

        public int CompareTo(object obj)
        {
            if (obj is ReplaceVersionInRCFile)
            {
                ReplaceVersionInRCFile arg = (ReplaceVersionInRCFile)obj;
                int result=0;
                if (result==0)
                    result = this._src.CompareTo(arg._src);
                if (result == 0)
                    result = this._target.CompareTo(arg._target);
                return result;
            }
            else
                return this.GetType().FullName.CompareTo(obj.GetType().FullName);
        }

        #endregion

        #region BaseAction Overrides
        /// <summary>
        /// The only prerequisite of actions of this kind as a ContentType.RCFile.
        /// </summary>
        /// <returns>Contains an array of exactly one entry.</returns>
        public override ICollection<IBuildProduct> GetPrerequisites()
        {
            return new IBuildProduct[] { this._src };
        }

        /// <summary>
        /// The target is a single file of ContentType.RCFile where the release version declared in the source has been replaced. 
        /// </summary>
        /// <returns>An array contining a single ContentFile of type ContentType.RCFile</returns>
        public override ICollection<IBuildProduct> GetTargets()
        {
            return new IBuildProduct[] { this._target };
        }
        #endregion

        #region IXmlSerializable Member

        public System.Xml.Schema.XmlSchema GetSchema()
        {
            return null;
        }

        public void ReadXml(System.Xml.XmlReader reader)
        {
            reader.ReadStartElement("action-replace-version-in-rc");
            reader.ReadStartElement("source");
            this._src = new ContentFile();
            this._src.ReadXml(reader);
            reader.ReadEndElement();
            reader.ReadStartElement("target");
            this._target = new ContentFile();
            this._target.ReadXml(reader);
            reader.ReadEndElement();
            reader.ReadEndElement();
        }

        public void WriteXml(System.Xml.XmlWriter writer)
        {
            writer.WriteStartElement("action-replace-version-in-rc");
            writer.WriteStartElement("source");
            this._src.WriteXml(writer);
            writer.WriteEndElement();
            writer.WriteStartElement("target");
            this._target.WriteXml(writer);
            writer.WriteEndElement();
            writer.WriteEndElement();
        }

        #endregion

        #region ICloneable Member

        public object Clone()
        {
            return new ReplaceVersionInRCFile(this);
        }

        #endregion
    }

    /// <summary>
    /// This class implements actions transforming C# files into C# sources that respect a release version.
    /// Release versions are defined by projects of class MakeReleaseProject using version information from environment
    /// variable <tt>BUILD_VERSION</tt>. These projects directly create
    /// actions of this kind (without using factories implementing IBuildActionProvider). These action will carry out
    /// 2 tasks:
    /// <list type="number">
    /// <item>Version information provided by the properties <c>AssemblyVersion</c> and <c>AssemblyFileVersion</c>
    /// will change to the new build version as set in <tt>BUILD_VERSION</tt>.</item>
    /// <item>This action will receive a dictionary containing all DLL files that also belong to the new release.
    /// This action will transform all PInvoke references to these DLLs (attribute <c>DllImport</c>) in such a way that
    /// they refer to file names reflecting the version of the new release.</item>
    /// </list>
    /// </summary>
    public class ReplaceVersionInCSharpFile : BaseAction, IBuildAction, ICloneable
    {
        #region State
        Dictionary<string, string> _filenameToFilenameWithVersion = new Dictionary<string, string>();
        ContentFile _src;
        ContentFile _target;
        #endregion

        #region CTor
        /// <summary>
        /// This will be called by project MakeReleaseVersion. 
        /// </summary>
        /// <param name="filenameToFilenameWithVersion"> Describes the conversion of filenames of DLLs.
        /// This argument defines which P-Invoke references will be renamed.</param>
        /// <param name="src">Must be of ContentType.CSharp. the source that will be converted.</param>
        /// <param name="target">Is the new file that will be created.</param>
        internal ReplaceVersionInCSharpFile(IDictionary<ContentFile, ContentFile> filenameToFilenameWithVersion,
            ContentFile src, ContentFile target)
        {
            foreach (KeyValuePair<ContentFile, ContentFile> pair in filenameToFilenameWithVersion)
            {
                string srcDllBasename = Path.GetFileNameWithoutExtension(pair.Key.FileName);
                if (pair.Key.Type.Implies(ContentType.Elf) && srcDllBasename.StartsWith("lib"))
                    srcDllBasename = srcDllBasename.Substring(3);
                string targetDllBasename = Path.GetFileNameWithoutExtension(pair.Value.FileName);
                if (pair.Value.Type.Implies(ContentType.Elf) && targetDllBasename.StartsWith("lib"))
                    targetDllBasename = targetDllBasename.Substring(3);

                this._filenameToFilenameWithVersion[srcDllBasename] = targetDllBasename;
            }
            this._src = src;
            this._target = target;
        }

        /// <summary>
        /// Copy CTor
        /// </summary>
        /// <param name="src">Source</param>
        public ReplaceVersionInCSharpFile(ReplaceVersionInCSharpFile src)
        {
            foreach (KeyValuePair<string, string> pair in src._filenameToFilenameWithVersion)
                this._filenameToFilenameWithVersion.Add(pair.Key, pair.Value);
            this._src = new ContentFile(src._src);
            this._target = new ContentFile(src._target);
        }
        #endregion

        #region Special Services
        /// <summary>
        /// Bit-Vektor for the specification of those actions that instances of this class may execute.
        /// </summary>
        [Flags]
        public enum ActionDescr
        {
            /// <summary>
            /// No action. If this equals a bit vector with AND mask AllActions, you can be sure, that
            /// this is a no operation.
            /// </summary>
            None = 0,
            /// <summary>
            /// Occurs if this changes the assembly version or assembly file version.
            /// </summary>
            ChangeVersionInfo=1,
            /// <summary>
            /// Occurs, if this changes a DllImportAttribute.
            /// </summary>
            ChangeDllImport = 2,
            /// <summary>
            /// Occurs if an assembly title attribute has been found.
            /// </summary>
            FoundAssemblyTitle = 4,
            /// <summary>
            /// Occurs, if an assembly description attribute has been found.
            /// </summary>
            FoundAssemblyDescription = 8,

            /// <summary>
            /// Mask containing all actions.
            /// </summary>
            AllActions=3,

            /// <summary>
            /// Mask containing all flags, actions and flags indicating a proven property of the analysed source file.
            /// </summary>
            AllFlags=15,
        }

        /// <summary>
        /// This resutns a specification of the actions that will presumably executed when executing this instance.
        /// Return value ActionDescr.None ensures that this is a no operation. This method may for reasons of efficiency
        /// in rare cases return actions that will in fact not be executed. However, if this mehtod does not return an
        /// action, it will definitely not be executed running this instance.
        /// </summary>
        /// <remarks>
        /// This will simply search the lines of the source file for version information and filenames of
        /// DLLs.
        /// </remarks>
        public ActionDescr ProbableActions()
        {
            ActionDescr result = ActionDescr.None;
            if (this._src.Exists)
            {
                TextReader reader=new StreamReader(this._src.FileName);
                string line=reader.ReadLine();
                while (line != null)
                {
                    if (line.IndexOf("AssemblyFileVersion") >= 0
                        || line.IndexOf("AssemblyVersion") >= 0)
                        result = result | ActionDescr.ChangeVersionInfo;
                    if (line.IndexOf("AssemblyTitle") >= 0)
                        result = result | ActionDescr.FoundAssemblyTitle;
                    if (line.IndexOf("AssemblyDescription") >= 0)
                        result = result | ActionDescr.FoundAssemblyDescription;
                    if (this._filenameToFilenameWithVersion != null)
                    {
                        foreach (string dllFilename in this._filenameToFilenameWithVersion.Keys)
                        {
                            string searchPattern = string.Format("\"{0}", dllFilename);
                            if (line.IndexOf(searchPattern) >= 0)
                            {
                                result = result | ActionDescr.ChangeDllImport;
                                break;
                            }
                        }
                    }
                    if (result==ActionDescr.AllFlags) // all actions
                        break;
                    line = reader.ReadLine();
                }
                return result;
            }
            else
                return result;
        }
        #endregion

        #region BaseAction overrides
        /// <summary> This returns the C# source as content file.</summary>
        public override ICollection<IBuildProduct> GetPrerequisites()
        {
            return new IBuildProduct[] { this._src };
        }

        /// <summary> This returns the C# source as content file.</summary>
        public override ICollection<IBuildProduct> GetTargets()
        {
            return new IBuildProduct[] { this._target };
        }
        #endregion

        #region IBuildAction Member
        /// <summary>
        /// This does not have a provide. Thus, this is <c>null</c> always.
        /// </summary>
        public IBuildActionProvider ActionProvider
        {
            get { return null; }
        }

        /// <summary>
        /// This is <c>"CSharpFileVersion"</c>.
        /// </summary>
        public string Name
        {
            get { return "CSharpFileVersion"; }
        }

        /// <summary>
        /// This property will not be used since this action cannot be replaced by an alternative action.
        /// This is always ActionPriority.Default.
        /// </summary>
        public ActionPriority Priority
        {
            get { return ActionPriority.Default; }
        }

        EnvironmentVarInfo _buildVersionVariable = null;
        /// <summary>
        /// The variable info for variable BUILD_VERSION.
        /// </summary>
        public EnvironmentVarInfo BuildVersionVariable
        {
            get
            {
                if (this._buildVersionVariable == null)
                    this._buildVersionVariable = new EnvironmentVarInfo("BUILD_VERSION", "The release version", typeof(System.Version), true);
                return this._buildVersionVariable;
            }
        }

        /// <summary>This tool requires variable BUILD_VERSION to be set.
        /// Variable BUILD_VERSION must have a System.Version string as value.</summary>
        public override IDictionary<string, EnvironmentVarInfo> UsedVars
        {
            get
            {
                SortedList<string, EnvironmentVarInfo> result = new SortedList<string, EnvironmentVarInfo>();
                result["BUILD_VERSION"] = this.BuildVersionVariable;
                return result;
            }
        }

        const string VersionPattern = "\\[\\W*assembly:\\W*Assembly(File)?Version\\W*\\(\\s*\"(?<versionString>[^\"]*)\"\\s*\\)\\s*\\]";
        const string DllImportPattern = "\\[\\W*DllImport\\W*\\([^\"]*\"(?<DllFilename>[^\"]*)\"\\W*\\]";

        /// <summary>
        /// This will do the transformation: Replace references to the DLLs and replace version in
        /// <c>AssemblyFileVersion</c> and <c>AssemblyVersion</c>.
        /// </summary>
        public bool Execute(BuildToolFamilyEnv env, DateTime validityOfBuildSystem)
        {
            // \[\W*assembly:\W*Assembly(File)?Version\W*\([^"]*(?<version>[^\)]*)\)
            // \[\W*DllImport\W*\([^"]*"(?<DllFilename>[^"]*)"\W*\]
            if (!this._src.Exists)
            {
                BuildConfig.HandleErrorObject(ErrorObject.MessageType.Error, "Missing rc file {0}.", this._src.FileName);
                return false;
            }
            if (this.BuildVersionVariable.IsEmpty())
            {
                BuildConfig.HandleErrorObject(ErrorObject.MessageType.Error, "Variable BUILD_VERSION must be set.");
                return false;
            }
            using (StreamReader src = new StreamReader(this._src.FileName))
            {
                string srcText = src.ReadToEnd();
                #region Replace Assembly Version Attribute if it exists
                System.Text.RegularExpressions.Regex regex = new System.Text.RegularExpressions.Regex(VersionPattern);
                string newVersionString = this.BuildVersionVariable.Get().ToString();
                int position = 0;
                System.Text.RegularExpressions.Match m = regex.Match(srcText);
                while (m.Success)
                {
                    Group vsGroup = m.Groups["versionString"];
                    if (vsGroup.Success)
                    {
                        string oldValue = vsGroup.Value;
                        int fromPos = vsGroup.Index;
                        srcText = srcText.Substring(0, fromPos)
                            + newVersionString
                            + srcText.Substring(fromPos + oldValue.Length);
                        position = fromPos + newVersionString.Length;
                        m = regex.Match(srcText, position);
                    }
                }
                #endregion
                #region Replace DllImport Reference to a Dll that is part of the release
                regex = new Regex(DllImportPattern);
                position = 0;
                m = regex.Match(srcText);
                while (m.Success)
                {
                    Group dllGroup = m.Groups["DllFilename"];
                    if (dllGroup.Success)
                    {
                        string oldValue = dllGroup.Value;
                        if (this._filenameToFilenameWithVersion.ContainsKey(oldValue))
                        {
                            int fromPos = dllGroup.Index;
                            srcText = srcText.Substring(0, fromPos)
                                + this._filenameToFilenameWithVersion[oldValue]
                                + srcText.Substring(fromPos + oldValue.Length);
                            position = fromPos + newVersionString.Length;
                        }
                        else
                            position += oldValue.Length;
                    }
                    m = regex.Match(srcText, position);
                }
                #endregion
                using (StreamWriter target = new StreamWriter(this._target.FileName))
                {
                    target.Write(srcText);
                }
                BuildConfig.HandleMessageObject("Action \"ReplaceVersionInCSharpFile\" created {1} to replace {0}.", this._src.FileName, this._target.FileName);
            }
            return true;            
        }

        #endregion

        #region IComparable Member

        public int CompareTo(object obj)
        {
            if (obj is ReplaceVersionInCSharpFile)
            {
                ReplaceVersionInCSharpFile arg = (ReplaceVersionInCSharpFile)obj;
                int cmp = 0;
                if (cmp == 0)
                    cmp = this._src.CompareTo(arg._src);
                if (cmp == 0)
                    cmp = this._target.CompareTo(arg._target);
                return cmp;
            }
            else
                return this.GetType().FullName.CompareTo(obj.GetType().FullName);
        }

        public override bool Equals(object obj)
        {
            return this.CompareTo(obj)==0;
        }

        public override int GetHashCode()
        {
            return this._src.GetHashCode()^this._target.GetHashCode();
        }
        #endregion

        #region IXmlSerializable Member

        public System.Xml.Schema.XmlSchema GetSchema()
        {
            return null;
        }

        public void ReadXml(System.Xml.XmlReader reader)
        {
            reader.ReadStartElement("action-replace-version-in-csharp");
            reader.ReadStartElement("source");
            this._filenameToFilenameWithVersion.Clear();
            reader.ReadStartElement("pinvoke-conversions");
            while (reader.IsStartElement("conversion"))
            {
                reader.ReadStartElement();
                string src = reader.ReadElementString("source");
                string target = reader.ReadElementString("target");
                this._filenameToFilenameWithVersion.Add(src, target);
                reader.ReadEndElement();
            }
            reader.ReadEndElement();
            this._src = new ContentFile();
            this._src.ReadXml(reader);
            reader.ReadEndElement();
            reader.ReadStartElement("target");
            this._target = new ContentFile();
            this._target.ReadXml(reader);
            reader.ReadEndElement();
            reader.ReadEndElement();
        }

        public void WriteXml(System.Xml.XmlWriter writer)
        {
            writer.WriteStartElement("action-replace-version-in-csharp");
            writer.WriteStartElement("pinvoke-conversions");
            foreach (KeyValuePair<string, string> conversion in this._filenameToFilenameWithVersion)
            {
                writer.WriteStartElement("conversion");
                writer.WriteElementString("source", conversion.Key);
                writer.WriteElementString("target", conversion.Value);
                writer.WriteEndElement();
            }
            writer.WriteEndElement();
            writer.WriteStartElement("source");
            this._src.WriteXml(writer);
            writer.WriteEndElement();
            writer.WriteStartElement("target");
            this._target.WriteXml(writer);
            writer.WriteEndElement();
            writer.WriteEndElement();
        }

        #endregion

        #region ICloneable Member

        public object Clone()
        {
            return new ReplaceVersionInCSharpFile(this);
        }

        #endregion
    }

    /// <summary>
    /// This class of actions simply copies a file to another destination (filename).
    /// This will be created directly by those projects needing this (e.g. the MakeReleaseProject).
    /// Thus, this actions do not need an action provider. This will set the modification time of the source file
    /// to the resulting copy.
    /// </summary>
    public class CopyFileAction : BaseAction, IBuildAction, System.Xml.Serialization.IXmlSerializable, ICloneable
    {
        #region State
        ContentFile _src;
        ContentFile _target;
        #endregion

        #region CTor
        /// <summary>
        /// Creates an instance of this action copying a source file to a target destination.
        /// </summary>
        /// <param name="t">The type of the source file and the target copy.</param>
        /// <param name="srcFilename">The filename of the original source file.</param>
        /// <param name="targetFilename">The filename of the resulting target file.</param>
        public CopyFileAction(ContentType t, string srcFilename, string targetFilename)
        {
            this._src = new ContentFile(t, srcFilename);
            this._target = new ContentFile(t, targetFilename);
        }

        /// <summary>
        /// Copy CTor
        /// </summary>
        /// <param name="src">Source</param>
        public CopyFileAction(CopyFileAction src)
        {
            this._src = new ContentFile(src._src);
            this._target = new ContentFile(src._target);
        }
        #endregion

        #region BaseAction Overrides
        /// <summary>
        /// Returns the prerequisites that are necessary to conduct the action. These will be used
        /// to decide whether the action has to run again to update the target even if a target file exists.
        /// </summary>
        /// <returns>An array continaing solely the source file.</returns>
        public override ICollection<IBuildProduct> GetPrerequisites()
        {
            return new IBuildProduct[] { this._src };
        }

        /// <summary>
        /// The targets of the action that will be produced.
        /// </summary>
        /// <returns>The wx.Build.ContentFile representing the copy to be created.</returns>
        public override ICollection<IBuildProduct> GetTargets()
        {
            return new IBuildProduct[] { this._target };
        }
        #endregion

        #region IBuildAction Member
        /// <summary>
        /// This always is <c>null</c> since these actions will be created directly be the projects.
        /// </summary>
        public IBuildActionProvider ActionProvider
        {
            get { return null; }
        }

        /// <summary>
        /// Returns <c>"COPY"</c>
        /// </summary>
        public string Name
        {
            get { return "COPY"; }
        }

        /// <summary>
        /// This is of default priority.
        /// </summary>
        public ActionPriority Priority
        {
            get { return ActionPriority.Default; }
        }

        /// <summary>
        /// This will create the copy of necessary.
        /// Errors will be reported on failed actions and missing source.
        /// </summary>
        /// <returns>True on success.</returns>
        public bool Execute(BuildToolFamilyEnv env, DateTime validityOfBuildSystem)
        {
            if (this._src.Exists)
            {
                if (this._src.GetValidity() <= this._target.GetValidity())
                {
                    BuildConfig.HandleMessageObject("Copy {0} of {1} is up to date.", this._target.FileName, this._src.FileName, this._target, this._src);
                }
                else
                {
                    System.IO.File.Copy(this._src.FileName, this._target.FileName, true);
                    System.IO.File.SetLastWriteTime(this._target.FileName, System.IO.File.GetLastWriteTime(this._src.FileName));
                }
                return true;
            }
            else
            {
                BuildConfig.HandleErrorObject(ErrorObject.MessageType.Error, "Missing source file {0}.", this._src);
                return false;
            }
        }

        /// <summary>
        /// This implementation will look for a program start info that implements this actions.
        /// If program start info is <c>null</c>, this implementation will raise an exception.
        /// Overload this if you have to create another implementation providing this feature.
        /// </summary>
        /// <param name="env">This is an environment that different tools of the same family may use to exchange information.
        /// This store is typically used to save information on configuration files or thinsgs of that kind that will be
        /// shared among all tools of the same family.</param>
        /// <param name="booCodeLines">The code that will actually build something will be appended to this writer.</param>
        /// <param name="indention">A string that shall preceed all created lines. </param>
        /// <exception cref="NotSupportedException">Will be thrown if this feature is not supported.</exception>
        /// <seealso cref="GetProgrammStartInfo"/>
        public override void AppendBooCode(List<string> booCodeLines, string indention, BuildToolFamilyEnv env)
        {
            if (this._src != this._target)
            {
                booCodeLines.Add(string.Format("{0}System.IO.File.Copy(\"{1}\", \"{2}\", true)", indention, this._src.FileNameAsBooString, this._target.FileNameAsBooString));
                booCodeLines.Add(string.Format("{0}System.IO.File.SetLastWriteTime(\"{1}\", System.IO.File.GetLastWriteTime(\"{2}\"))", indention, this._target.FileNameAsBooString, this._src.FileNameAsBooString));
            }
        }
        #endregion

        #region IComparable Member

        public int CompareTo(object obj)
        {
            if (obj is CopyFileAction)
            {
                CopyFileAction arg = (CopyFileAction)obj;
                int cmp=this._src.CompareTo(arg._src);
                if (cmp==0)
                    cmp= this._target.CompareTo(arg._target);
                return cmp;
            }
            else
                return this.GetType().FullName.CompareTo(obj.GetType().FullName);
        }

        public override bool Equals(object obj)
        {
            return this.CompareTo(obj)==0;
        }

        public override int GetHashCode()
        {
            return this._src.GetHashCode() ^ this._target.GetHashCode();
        }
        #endregion

        #region IXmlSerializable Member
        /// <summary>
        /// Returns <c>null</c> as suggested by the .NET framework doc.
        /// </summary>
        public System.Xml.Schema.XmlSchema GetSchema()
        {
            return null;
        }

        public void ReadXml(System.Xml.XmlReader reader)
        {
            reader.ReadStartElement("copy-file");
            reader.ReadStartElement("src");
            this._src = new ContentFile();
            this._src.ReadXml(reader);
            reader.ReadEndElement();
            reader.ReadStartElement("target");
            this._target = new ContentFile();
            this._target.ReadXml(reader);
            reader.ReadEndElement();
            reader.ReadEndElement();
        }

        public void WriteXml(System.Xml.XmlWriter writer)
        {
            writer.WriteStartElement("copy-file");
            writer.WriteStartElement("src");
            this._src.WriteXml(writer);
            writer.WriteEndElement();
            writer.WriteStartElement("target");
            this._target.WriteXml(writer);
            writer.WriteEndElement();
            writer.WriteEndElement();
        }

        #endregion

        #region IXmlSerializable Member

        System.Xml.Schema.XmlSchema System.Xml.Serialization.IXmlSerializable.GetSchema()
        {
            throw new NotImplementedException();
        }

        void System.Xml.Serialization.IXmlSerializable.ReadXml(System.Xml.XmlReader reader)
        {
            throw new NotImplementedException();
        }

        void System.Xml.Serialization.IXmlSerializable.WriteXml(System.Xml.XmlWriter writer)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region ICloneable Member

        public object Clone()
        {
            return new CopyFileAction(this);
        }

        #endregion
    }
}
