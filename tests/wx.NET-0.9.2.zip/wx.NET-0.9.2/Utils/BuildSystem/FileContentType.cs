/** Build system for wx.NET.
 * 
 * This DLL contains basic implementations to build (compile and link) C/C++ programs,
 * compile .NET assemblies written in C#, sign them, and install them.
 * 
 * \file 
 *
 * Copyright 2009 Harald Meyer auf'm Hofe harald_meyer@users.sourceforge.net
 * 
 * Licensed under the wxWidgets license, see LICENSE.txt for details.
 * 
 * $Id: FileContentType.cs,v 1.16 2010/04/23 17:39:26 harald_meyer Exp $
 */


using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace wx.Build
{
    /** <summary> A bit vector representing several properties of content files that are relevant to the build process.
     * A type inherits all properties from those types that are contained. </summary> */
    [Flags]
    public enum ContentFileProperties
    {
        /** <summary> Constant to represent that files do not exhibit remarkable properties. </summary> */
        None = 0,

        /** <summary> The file is a .NET assembly (linkable) </summary> */
        NetAssembly = 0x20001,

        /** <summary> This is among the properties, if this contains an assembly of a strong name. </summary> */
        StrongNameAssembly = 0x20003,

        /** <summary> File contains a DLL containing native code. </summary> */
        NativeDLL = 0x10004,

        /** <summary> File contains a statically linkable library of native code objects.
         * Files of this kind may be used to build programs but not to contain DLL entries. </summary> */
        NativeStaticLib = 0x10008,

        /** <summary> File contains statically linkable code objects also maybe DLL entries.
         * All files of this property result from a compiler and may serve as input of linkers. </summary> */
        NativeCodeObject = 0x10010,

        /** <summary> True if file is a stream of characters. </summary> */
        PlainText = 0x20,

        /** <summary> True, if file is a stream of UTF8 characters. </summary> */
        UTF8Text = 0x21,

        /** <summary> True, if file is a stream of UTF16 characters. </summary> */
        UTF16Text = 0x22,

        /** <summary> True, if file is a stream of ISO-8859-1 characters. </summary> */
        Latin1Text = 0x24,

        /** <summary> True, if file is a stream of ASCII 8-bit characters but not using 128-255. </summary> */
        ASCIIText = 0x28,

        /** <summary> This is plain text containing source code to be compiled into a code object. </summary> */
        CodeObjectSrc = 0x060,

        /** <summary> This is a plain text that is not meant to be compiled to a code object but containing declarations and macros or code to be inlined. </summary> */
        InlinedCodeSrc = 0x0a0,

        /** <summary> This property specifies that files of this type have been compressed by an appropriate algorithm.
         * If this holds true, some actions might choose not to run another compression since this is, because
         * of this property, assumed to have no effect. </summary> */
        Compressed = 0x100,

        /** <summary> This is an executable program. </summary> */
        Executable = 0x1000,

        /** <summary> This is an executabl program requiring the .NET runtime environment to work. </summary> */
        NetExecutable = 0x21001,

        /** <summary> This is an executable program containing native code. </summary> */
        NativeCodeExecutable = 0x11004,

        /** <summary> Contains RES-files and alternatives for other linkers.
         * Everything that can be built from RC-files. 
         * wx.Build.Cxx.DynamicDllProject will identify all types of files that are appropriate to
         * contain Windows resources by this flag.
         * </summary> */
        WindowsResourceObject = 0x2000,

        /// <summary>
        /// Text in XML syntax.
        /// This may also describe project files or data serializations as loong as the result can be parsed
        /// as XML.
        /// </summary>
        XMLText = 0x4020,

        /// <summary>
        /// A resource that can be linked into a .NET executable.
        /// </summary>
        NetRessource = 0x8000,

        /// <summary>
        /// This is valid if files of this type may only be used on computers running a particular
        /// OS and a particular processor architecture. This is e.g. true for all native executables
        /// and code libraries.
        /// </summary>
        DependsOnOSAndProcessor = 0x10000,

        /// <summary>
        /// This is valid for all files containing .NET code. This is a property of those files that
        /// have been created by a .NET framework.
        /// </summary>
        NetCodeObj = 0x20000,
    }

    /** <summary> Classification of a content (mime) type.
     * Consists of a primary and secondary type name in lower case letters.
     * Example "text/cpp".
     *
     * Please note, that only one instance is allowed for each type. This is to
     * avoid the use of ambiguous type specifications.
     * 
     * User query for a description rather than creating one. This knows constants
     * for frequently used data types. </summary> */
    public class ContentType : IComparable, System.Xml.Serialization.IXmlSerializable
    {
        #region State
        string _primaryTypeName;
        string _secondaryTypeName;
        string _description;
        List<string> _suffixes = new List<string>();
        Dictionary<ContentType, ContentType> _implies = new Dictionary<ContentType, ContentType>();
        ContentType _compressedContent = null;

        ContentFileProperties _properties;
        #endregion

        #region Gettext Hack
        /// <summary>
        /// Use <c>__("a text to be translated")</c> to mark a text for translation by
        /// gettext. This method is a NOP and will return the argument as received.
        /// </summary>
        /// <remarks>
        /// Use case:
        /// <code>
        /// xgettext -C -k__ -o FileContentType.pot FileContentType.cs
        /// </code>
        /// This line will produce a gettext file for translation named <c>FileContentType.pot</c>
        /// containing all those string constants used in conjunction with this method. 
        /// You may produce a translation repository using this sources and translate these
        /// strings elsewhere in the system e.g. when presenting mime type descriptions to the 
        /// user.
        /// </remarks>
        /// <param name="text">Text that shall be marked for translation.</param>
        /// <returns>The argument without any change</returns>
        static string __(string text) { return text; }
        #endregion

        #region Static DB
        static Dictionary<string, ContentType> _db = new Dictionary<string, ContentType>();
        #endregion

        #region Private CTor
        /// <summary>
        /// Creates an empty instance
        /// </summary>
        internal ContentType()
        {
        }

        /// <summary>
        /// Reads a content type from the XML stream and adds it to the collection of known types.
        /// The result will be the new type. If the type from the XML stream is already known, 
        /// the type from the stream will be ignored silently. This, this can either deal with
        /// references to known type as serialized by WriteRefXml() or by full exports by WriteXml().
        /// </summary>
        /// <param name="reader">The data source</param>
        /// <returns>The type from the stream or, if this exists, a previously known type of the same name.</returns>
        static public ContentType FromXml(System.Xml.XmlReader reader)
        {
            ContentType result = new ContentType();
            result.ReadXml(reader);
            if (ContentType._db.ContainsKey(result.Name))
                result = _db[result.Name];
            else
                ContentType._db[result.Name] = result;
            return result;
        }

        /** <summary> Creates an instance representing the content type "primary"/"secondary".
        * Please note, that this will raise an exception, if the build system already knows a content type
        * of this name, since this can result in ambiguous representations of the type. </summary> */
        ContentType(ContentType compressedContent, string primary, string secondary, string description, ContentFileProperties properties, params object[] suffixesOrImpliedTypes)
            : this(primary, secondary, description, properties|ContentFileProperties.Compressed, suffixesOrImpliedTypes)
        {
            this._compressedContent = compressedContent;
        }

        /** <summary> Creates an instance representing the content type "primary"/"secondary".
        * Please note, that this will raise an exception, if the build system already knows a content type
        * of this name, since this can result in ambiguous representations of the type. </summary> */
        ContentType(string primary, string secondary, string description, ContentFileProperties properties, params object[] suffixesOrImliedTypes)
            : this(primary, secondary)
        {
            this._description = description;
            this._properties = properties;
            if (suffixesOrImliedTypes != null)
            {
                foreach (object suffixOrImpliedType in suffixesOrImliedTypes)
                {
                    if (suffixOrImpliedType is string)
                        this.AddSuffix((string)suffixOrImpliedType);
                    else if (suffixOrImpliedType is ContentType)
                        this._implies[(ContentType)suffixOrImpliedType] = (ContentType)suffixOrImpliedType;
                    else
                        throw new InvalidCastException("Cannot derive included content type or file extension from argument to content type ctor.");
                }
            }
        }

        /** <summary> Creates an instance representing the content type "primary"/"secondary".
        * Please note, that this will raise an exception, if the build system already knows a content type
        * of this name, since this can result in ambiguous representations of the type. </summary> */
        ContentType(string primary, string secondary)
        {
            if (primary == null)
                primary = "application";
            this._primaryTypeName = primary.ToLower();
            this._secondaryTypeName = secondary.ToLower();
            if (_db.ContainsKey(this.Name))
                throw new ApplicationException(string.Format("Content type {0}/{1} already exists.", primary, secondary));
            else
                _db.Add(this.Name, this);
        }
        #endregion

        #region Public Properties
        /** <summary> Primary content type name. Read only.
         * Strings like "application" or "text", "audio", "video", "image", "binary". </summary> */
        public string Primary { get { return this._primaryTypeName; } }

        /** <summary> Secondary content type name. Read only.
         * Letters plus dots '.' plus numbers. First character is a letter. </summary> */
        public string Secondary { get { return this._secondaryTypeName; } }

        /** <summary>The full name: primary name '/' secondary name.</summary>
        */
        public string Name { get { return this.Primary + "/" + this.Secondary; } }

        /** <summary> Read/Write access to the description.
         * </summary> */
        public string Description { get { return this._description; } }

        /** <summary> Read only access to the frequently used suffixes.
         * This may be empty. Use AddSuffix() to add a new suffix.
         * 
         * This is in fact a file name pattern where the asterisk * stands for the base name.
         * This usually contains strings like "*.cxx" or "*.cs", but may also contain things like
         * "lib*.so" (for creating the name of a dynamic ELF library from a base name).
         * </summary> */
        public string[] Suffix { get { return this._suffixes.ToArray(); } }

        /** <summary> Returns the properties of files of this type.
         * This will also ask the contained file types for their properties.
         * </summary> */
        public ContentFileProperties Properties
        {
            get
            {
                ContentFileProperties result = this._properties;
                foreach (ContentType t in this._implies.Values)
                    result = result | t.Properties;
                return result;
            }
        }

        /** <summary> This is usually <c>null </c>  but in case of a zipped or compressed file, this is the type of the compressed content. </summary> */
        public ContentType CompressedContent { get { return this._compressedContent; } }

        /** <summary> True iff <c>ContentFileProperties </c> .Compressed is among the <c>Properties </c> . </summary> */
        public bool IsCompressed { get { return (this.Properties & ContentFileProperties.Compressed) == ContentFileProperties.Compressed; } }

        /** <summary> True iff <c>ContentFileProperties </c> .StrongNameAssembly is among the <c>Properties </c> . </summary> */
        public bool IsStrongNameAssembly { get { return (this.Properties & ContentFileProperties.StrongNameAssembly) == ContentFileProperties.StrongNameAssembly; } }
        #endregion

        #region Public Operations
        /** <summary> Adds a viable suffix characterizing files of thedescribed content type.
         * Is <c>suffix </c>  does not contain an asterisk, the string will be interpreted as a suffix
         * separated by a dot (.). So, "cs" will be translated into "*.cs". You may also add
         * patterns like "lib*.so" containing an asterisk representing a base name. </summary> */
        public void AddSuffix(string suffix)
        {
            if (suffix.Contains("*"))
                this._suffixes.Add(suffix);
            else
                this._suffixes.Add("*." + suffix);
        }

        /// <summary>
        /// This is a string listing all suffixes of this content type.
        /// </summary>
        public string SuffixString
        {
            get
            {
                StringBuilder result = new StringBuilder();
                foreach (string suffix in this._suffixes)
                {
                    if (result.Length > 0)
                        result.Append(", ");
                    result.Append(suffix);
                }
                return result.ToString();
            }
        }

        /// <summary>
        /// This will create a collection of types that match the provided filename.
        /// </summary>
        /// <param name="filename">This method finds possible content type for this file.</param>
        /// <returns>Collection of types matching the provided filename.</returns>
        /// <seealso cref="Match"/>
        /// <seealso cref="GetOneMatchingType"/>
        public static ICollection<ContentType> GetMatchingTypes(string filename)
        {
            List<ContentType> result=new List<ContentType>();
            if (System.IO.Directory.Exists(filename))
                result.Add(Directory);
            else
            {
                foreach (ContentType t in _db.Values)
                {
                    string m = t.Match(filename);
                    if (m != null)
                        result.Add(t);
                }
            }
            return result;
        }

        /// <summary>
        /// This will return one content type matching the provided filename if such a type exists.
        /// The method returns <c>null</c> if filename does not match any type.
        /// </summary>
        /// <param name="filename">This method finds possible content type for this file.</param>
        /// <returns>A content type matching the provided filename or <c>null</c>.</returns>
        /// <seealso cref="Match"/>
        /// <seealso cref="GetMatchingTypes"/>
        public static ContentType GetOneMatchingType(string filename)
        {
            foreach (ContentType t in _db.Values)
            {
                string m = t.Match(filename);
                if (m != null)
                    return t;
            }
            return null;
        }

        /** <summary> Returns the basename according to the first matching suffix.</summary><remarks>
         * \param filename is the name of a file.
         * If this finds a sufix matching with <c>filename </c>, this will return the supposed basename.
         * If this fails to find a match, the result is <c>null </c> .
         * 
         * \li filename "Program.cs" and suffix "*.cs" match with basename "Program".
         * \li filename "libwx-c.so" and suffix "lib*.so" match with basename "wx-c". </remarks> */
        public string Match(string filename)
        {
            filename = Path.GetFileName(filename);
            foreach (string pattern in this._suffixes)
            {
                int posAsterisk = pattern.IndexOf('*');
                if (posAsterisk >= 0)
                {
                    // we have a prefix
                    string prefix = pattern.Substring(0, posAsterisk);
                    if (filename.StartsWith(prefix))
                        filename = filename.Substring(posAsterisk);
                    else
                        continue; // next suffix. this does not match.
                }
                if (posAsterisk < pattern.Length - 1)
                {
                    // we have a real suffix.
                    string suffix = pattern.Substring(posAsterisk + 1);
                    if (filename.EndsWith(suffix))
                        filename = filename.Substring(0, filename.Length - suffix.Length);
                    else
                        continue; // next suffix. this does not match
                }
                return filename; // return first match.
            }
            return null; // no match found.
        }

        string FilenameFromBasename(string suffix, string basename)
        {
            return suffix.Replace("*", basename);
        }

        /** <summary> This will return a filename complying with the provided basename and the first suffix.
         * If this does not know a suffix, then this will return the basename. </summary> */
        public string FilenameFromBasename(string basename)
        {
            if (this._suffixes.Count > 0)
                return this.FilenameFromBasename(this._suffixes[0], basename);
            else
                return basename;
        }

        /** <summary> Returns the filenames that can be created combining the provided basename with the suffixes known to this content type.
         * If this does not know suffixes, this will return the <c>basename </c> . </summary> */
        public ICollection<string> FilenamesFromBasename(string basename)
        {
            List<string> result = new List<string>();
            foreach (string suffix in this._suffixes)
            {
                result.Add(this.FilenameFromBasename(suffix, basename));
            }
            if (result.Count == 0)
                result.Add(basename);
            return result;
        }

        /** <summary> Return <c>true </c>  if the suffix of <c>filename </c>  complies with one of the associated suffixes. </summary> */
        public bool SuffixComplies(string filename)
        {
            filename=filename.ToLower();
            foreach (string suffix in this._suffixes)
            {
                System.Text.RegularExpressions.Regex test = new System.Text.RegularExpressions.Regex(suffix.ToLower().Replace(".", "\\.").Replace("*", ".*"));
                if (test.Match(filename).Success)
                    return true;
            }
            return false;
        }

        /// <summary>
        /// True iff this type implies more general content types.
        /// This criterion is for instance used to select the description
        /// for the file dialog wildcard.
        /// </summary>
        public bool ImpliesMoreGeneralTypes
        {
            get
            {
                return this._implies.Count > 0;
            }
        }

        /// <summary>
        /// This is a collection of all directly implied types.
        /// Refer to GetAllImpliedTypes() for a collection of all implied types.
        /// </summary>
        public ICollection<ContentType> ImpliedTypes
        {
            get
            {
                return this._implies.Values;
            }
        }

        /// <summary>
        /// This will create a new collection of all types that are implied by this type, or in other words,
        /// contain this. This may be empty.
        /// Directly implied types are in front of the resulting collections. Types implied by implied types
        /// follow later.
        /// </summary>
        /// <returns></returns>
        public ICollection<ContentType> GetAllImpliedTypes()
        {
            Dictionary<ContentType, ContentType> testetTypes=new Dictionary<ContentType,ContentType>();
            List<ContentType> result = new List<ContentType>();
            Queue<ContentType> agenda = new Queue<ContentType>();
            if (this.ImpliesMoreGeneralTypes)
            {
                foreach (ContentType t in this.ImpliedTypes)
                    agenda.Enqueue(t);
            }
            while (agenda.Count > 0)
            {
                ContentType current = agenda.Dequeue();
                if (!testetTypes.ContainsKey(current))
                {
                    testetTypes.Add(current, current);
                    result.Add(current);
                    if (current.ImpliesMoreGeneralTypes)
                    {
                        foreach (ContentType t in current.ImpliedTypes)
                            agenda.Enqueue(t);
                    }
                }
            }
            return result;
        }

        /** <summary> True if this equals <c>t </c>  or a contained type does so. </summary> */
        public bool Implies(ContentType t)
        {
            if (this.Equals(t))
                return true;
            foreach (ContentType implied in this._implies.Values)
                if (implied.Implies(t))
                    return true;
            return false;
        }

        /** <summary> True if the argument implies this. </summary> */
        public bool Contains(ContentType t)
        {
            return t.Implies(this);
        }
        #endregion

        #region Comparison
        /** <summary> Comparison based on <c>Equals() </c> .
         * Can also deal with <c>null </c> . </summary> */
        static public bool operator ==(ContentType t1, ContentType t2)
        {
            if ((object)t1 == null)
                return ((object)t2) == null;
            if ((object)t2 == null)
                return false;
            return t1.Equals(t2);
        }

        /** <summary> Comparison based on negation of <c>Equals() </c> .
         * Can also deal with <c>null </c> . </summary> */
        static public bool operator !=(ContentType t1, ContentType t2)
        {
            return !(t1 == t2);
        }
        #endregion

        #region Static Services
        /// <summary>
        /// Creates a file dialog wildcard containing the files of the provided types.
        /// </summary>
        /// <param name="types">List of types that shall appear in the wildcard</param>
        public static string CreateFileDialogWildcard(ICollection<ContentType> types)
        {
            return CreateFileDialogWildcard(types, null);
        }

        /// <summary>
        /// Used to provide CreateFileDialogWildcard() with means to translate English standard descriptions.
        /// </summary>
        /// <param name="arg">String to be translated</param>
        /// <returns>Translation</returns>
        public delegate string Translator(string arg);

        /// <summary>
        /// Creates a file dialog wildcard containing the files of the provided types.
        /// </summary>
        /// <param name="types">List of types that shall appear in the wildcard</param>
        /// <param name="translator">If not <c>null</c>, this delegate will be used to translate
        /// the description of the mime type.</param>
        public static string CreateFileDialogWildcard(ICollection<ContentType> types, Translator translator)
        {
            SortedList<string, string> extToDescription = new SortedList<string, string>();
            foreach (ContentType t in types)
            {
                foreach (string ext in t.Suffix)
                {
                    if (extToDescription.ContainsKey(ext))
                    {
                        if (!t.ImpliesMoreGeneralTypes)
                            extToDescription[ext] = t.Description;
                    }
                    else
                        extToDescription[ext] = t.Description;
                }
            }
            StringBuilder sb = new StringBuilder();
            foreach (KeyValuePair<string, string> extDescrPair in extToDescription)
            {
                if (sb.Length > 0)
                    sb.Append("|");
                string translatedDescription = extDescrPair.Value;
                if (translator != null) // translate description here directly before producing the output string.
                    translatedDescription = translator(translatedDescription);
                sb.AppendFormat("{0} ({1})|{1}", translatedDescription, extDescrPair.Key);
            }
            return sb.ToString();
        }
        #endregion

        #region Public Statics (DB of Content Types)
        /** <summary> Find the content type description due to the provided type names or create one. </summary> */
        public static ContentType FindOrCreate(string primaryTypeName, string secondaryTypeName)
        {
            string fullName = primaryTypeName + "/" + secondaryTypeName;
            if (!_db.ContainsKey(fullName))
            {
                ContentType query = new ContentType(primaryTypeName, secondaryTypeName);
                _db[query.Name] = query;
            }
            return _db[fullName];
        }

        /** <summary> Find the content type description due to the provided type names or create one. </summary> */
        public static ContentType FindOrCreate(string fullTypeName)
        {
            if (!_db.ContainsKey(fullTypeName))
            {
                string[] primAndSecName = fullTypeName.Split('/');
                ContentType newInstance = new ContentType(primAndSecName[0], primAndSecName[1]);
                _db[fullTypeName] = newInstance;
            }
            return _db[fullTypeName];
        }

        /** <summary> Returns the collection of all content types that exhibit all provided properties. </summary> */
        public static ICollection<ContentType> FindContentTypes(ContentFileProperties properties)
        {
            List<ContentType> result = new List<ContentType>();
            foreach (ContentType t in AllContentTypes)
            {
                if ((t.Properties & properties) == properties)
                    result.Add(t);
            }
            return result;
        }

        /** <summary> The collection of all content types. </summary> */
        public static ICollection<ContentType> AllContentTypes { get { return _db.Values; } }

        /** <summary> "text/csharp": Source file containing C# code. </summary> */
        public static readonly ContentType CSharpCode = new ContentType("text", "csharp", __("Source file containing C# code."), ContentFileProperties.CodeObjectSrc, "cs");

        /** <summary> "text/cplusplus": Source file containing C++ code. </summary> */
        public static readonly ContentType CPlusPlusCode = new ContentType("text", "cplusplus", __("Source file containing C++ code."), ContentFileProperties.CodeObjectSrc, "cpp", "cxx", "c++", "cc");

        /** <summary> "text/c": Source file containing C code. </summary> */
        public static readonly ContentType CCode = new ContentType("text", "c", __("Source file containing C code."), ContentFileProperties.CodeObjectSrc, "c");

        /** <summary> "text/c-cplusplus-header": C or C++ header files which contain C or C++ code but will not be compiled directly.
         * This is usually the type of header files found by tools for dependency checking.
         * At least in those cases, it is unknown whether the contained code shall be compiled in C or C++ mode (with or without
         * mangled symbols). </summary> */
        public static readonly ContentType CCPlusPlusInclude = new ContentType("text", "c-cplusplus-header", __("Header file containing C or C++ code."), ContentFileProperties.InlinedCodeSrc, "hpp", "hxx", "h++", "hh", "h");

        /** <summary>"text/c-header": Header file containing C code.</summary>
         */
        public static readonly ContentType CInclude = new ContentType("text", "c-header", __("Header file containing C code."), ContentFileProperties.InlinedCodeSrc, "h", CCPlusPlusInclude);

        /** <summary>"text/cplusplus-header": C++ header files which contain C++ code but will not be compiled directly.</summary>
         */
        public static readonly ContentType CPlusPlusInclude = new ContentType("text", "cplusplus-header", __("Header file containing C++ code."), ContentFileProperties.InlinedCodeSrc, "hpp", "hxx", "h++", "hh", "h", CCPlusPlusInclude);

        /** <summary> "text/wxGlade": wxGlade resource file.</summary>
         */
        public static readonly ContentType wxGladeFile = new ContentType("text", "wxGlade", __("wxGlade resource file."), ContentFileProperties.PlainText, "wxg");

        /** <summary> "text/xrc-file": wxWidgets resouce definition file.</summary>
         */
        public static readonly ContentType XRCFile = new ContentType("text", "xrc-file", __("wxWidgets resource definition file."), ContentFileProperties.PlainText, "xrc");

        /** <summary>"text/rc-file": Windows resouce definition file.</summary>
         */
        public static readonly ContentType RCFile = new ContentType("text", "rc-file", __("Windows resource definition file."), ContentFileProperties.PlainText, "rc");

        /** <summary>"binary/res-file": Compiled Windows resources.</summary>
         */
        public static readonly ContentType ResFile = new ContentType("binary", "res-file", __("Compiled Windows resources."), ContentFileProperties.WindowsResourceObject, "res");

        public static readonly ContentType GccResObj = new ContentType("application", "gcc-resobj", __("Binary WINDOWS resources compiled into an GCC object file."), ContentFileProperties.WindowsResourceObject, "rc.o");

        /** <summary>"binary/dotnet-module": .NET CLS module that may serve as input for the assembly linker.</summary>
         */
        public static readonly ContentType DotNetModule = new ContentType("binary", "dotnet-module", __("Statically linkable program module requiring a .NET environent."), ContentFileProperties.NetCodeObj, "module", "netmodule", "mod");

        /** <summary>"binary/dotnet-dll": Dynamically linkable program library requiring a .NET environent.</summary>
         */
        public static readonly ContentType DotNetDll = new ContentType("binary", "dotnet-dll", __("Dynamically linkable program library requiring a .NET environent."), ContentFileProperties.NetAssembly, "dll");

        /** <summary>"binary/dotnet-executable": Executable program requiring a .NET runtime environment. Containing ContentType.DotNetDll.</summary>
         */
        public static readonly ContentType DotNetExe = new ContentType("binary", "dotnet-executable", __("Executable program requiring a .NET runtime environment"), ContentFileProperties.NetExecutable, "exe", DotNetDll);

        /** <summary>"binary/dotnet-shell-exe": Executable program requiring a .NET runtime environment and using a shell like \c cmd.exe for input/output. Containing ContentType.DotNetExe.</summary>
         */
        public static readonly ContentType DotNetShellExe = new ContentType("binary", "dotnet-shell-exe", __("Executable program requiring a .NET runtime environment and using a shell like cmd.exe for input/output"), ContentFileProperties.NetExecutable, "exe", DotNetDll);

        /** <summary>"binary/signed-dll": Dynamically linkable and strongly named (signed by \c sn.exe) program library requiring a .NET environent. Containing ContentType.DotNetDll.</summary>
         */
        public static readonly ContentType SnDotNetDll = new ContentType("binary", "signed-dll",
            __("Dynamically linkable and strongly named program library requiring a .NET environent."),
            ContentFileProperties.StrongNameAssembly, "dll", DotNetDll);

        /** <summary>"binary/signed-executable": Executable strongly named (signed by \c sn.exe) program requiring a .NET runtime environment. Containing ContentType.SnDll and ContentType.DotNetExe.</summary>
         */
        public static readonly ContentType SnDotNetExe = new ContentType("binary", "signed-executable", 
            __("Executable strongly named program requiring a .NET runtime environment"),
            ContentFileProperties.StrongNameAssembly | ContentFileProperties.NetAssembly | ContentFileProperties.Executable, "exe", SnDotNetDll, DotNetExe);

        /** <summary>"binary/signed-shell-exe": Executable strongly named (signed by \c sn.exe) program requiring a .NET runtime environment and using a shell like \c cmd.exe for input/output. Containing ContentType.DotNetCmdExe and ContentType.SnDll.</summary>
         */
        public static readonly ContentType SnDotNetShellExe = new ContentType("binary", "signed-shell-exe",
            __("Executable strongly named .NET console program"),
            ContentFileProperties.NetExecutable, "exe", SnDotNetDll, DotNetShellExe);

        /// <summary>
        /// application/wxbuild-project: .NET assembly containing wx.Build project definitions.
        /// </summary>
        public static readonly ContentType wxBuildProject = new ContentType("application", "wxbuild-project", ".NET assembly containing wx.Build project definitions.", ContentFileProperties.NetAssembly, ContentType.DotNetDll, "dll", "exe");

        /// <summary>
        /// application/packagebuilder-package: Package built by the package builder containing source files, compiled files, and project definitions.
        /// </summary>
        public static readonly ContentType PackageBuilderPackage = new ContentType("application", "packagebuilder-package", "Package built by the PackageBuilder containing source files, compiled files, and project definitions.", ContentFileProperties.NetRessource, "package");

        /// <summary>
        /// "application/packagebuilder-project: PackageBuilder project containing a layout for building packages and installers.
        /// </summary>
        public static readonly ContentType PackageBuilderProject = new ContentType("application", "packagebuilder-project", "PackageBuilder project containing a layout for building packages and installers.", ContentFileProperties.XMLText, "pkgproj");

        /** <summary>"application/sn-keys": A file containing a key pair for signing up using \c sn.exe.</summary>
         */
        public static readonly ContentType SnKeys = new ContentType("application", "sn-keys", 
            __("A file containing a key pair for signing up using sn.exe"), ContentFileProperties.None, "snk");

        /** <summary>"application/static-lib" contains all supported forms of static libraries.</summary>
        */
        public static readonly ContentType StaticLib = new ContentType("application", "static-lib", 
            __("Static library containing native code but of unspecified format."),
            ContentFileProperties.NativeStaticLib, "lib");

        /** <summary>"application/msvc-coff-obj": Visual Studio C COFF file of the Microsoft \c cl.exe compiler.</summary>
         */
        public static readonly ContentType VCCoffObj = new ContentType("application", "msvc-coff-obj",
            __("COFF (Common Object File Format) file."),
            ContentFileProperties.NativeCodeObject, "obj");

        /** <summary>"application/msvc-coff-lib": Static library of COFF objects.</summary>
         */
        public static readonly ContentType VCCoffLib = new ContentType("application", "msvc-coff-lib",
            __("Static library of COFF (Common Object File Format) files."),
            ContentFileProperties.NativeStaticLib, "lib", StaticLib);

        /** <summary>"application/gcc-o": Object file of the GNU GCC compiler.</summary>
         */
        public static readonly ContentType GccObj = new ContentType("application", "gcc-o",
            __("Object file of the GNU GCC compiler."),
            ContentFileProperties.NativeCodeObject, "o");

        /** <summary>"application/gcc-lib": Object file of the GNU GCC compiler.</summary>
         */
        public static readonly ContentType GccLib = new ContentType("application", "gcc-lib",
            __("Static library of GNU GCC objects."),
            ContentFileProperties.NativeStaticLib, "lib", StaticLib);

        /** <summary>"binary/windows-dll": Dynamically linkable program library in native code that runs on Windows.</summary>
         */
        public static readonly ContentType WindowsDll = new ContentType("binary", "windows-dll",
            __("Dynamically linkable program library in native code that runs on Windows."),
            ContentFileProperties.NativeDLL, "exe");

        /** <summary>"binary/windows-gui-dll": Dynamically linkable program library in native code that runs on Windows presupposing MSVCRT.DLL.</summary>
         */
        public static readonly ContentType WindowsGuiDll = new ContentType("binary", "windows-gui-dll",
            __("Dynamically linkable Windows program library presupposing MSVCRT.DLL."),
            ContentFileProperties.NativeDLL, "exe", WindowsDll);

        /** <summary>"binary/elf": ELF library containing i386 code.</summary>
         * <remarks> Since LD is able to link ELF libraries directly to a program - in contrast to MS link.exe
         * that requires a stub library - ELF libs are declared to be also static libraries.
         * </remarks>
         */
        public static readonly ContentType Elf = new ContentType("binary", "elf",
            __("Dynamically linkable program library in ELF standard containing native code."),
            ContentFileProperties.NativeDLL, "lib*.so", StaticLib);

        /** <summary>"binary/osx-dylib": MAC OS X dynamic library.</summary>
         */
        public static readonly ContentType MacDylib = new ContentType("binary", "osx-dylib",
            __("MAC OS X dynamic library."),
            ContentFileProperties.NativeDLL, "dylib");

        /** <summary>"text/csv": comma separated list</summary>
         */
        public static readonly ContentType CSV = new ContentType("text", "csv",
            __("Comma separated list in local character encoding."),
            ContentFileProperties.PlainText | ContentFileProperties.Latin1Text, "csv");

        /** <summary>"text/plain": TXT</summary>
         */
        public static readonly ContentType TXT = new ContentType("text", "plain",
            __("Text of byte strings in unknown coding (will be displayed in currently used locale)."),
            ContentFileProperties.PlainText | ContentFileProperties.Latin1Text, "txt");

        /** <summary>"text/html": HTML</summary>
         */
        public static readonly ContentType HTML = new ContentType("text", "html", 
            __("Hyper text markup language."),
            ContentFileProperties.PlainText, "html", "htm");

        /** <summary>"text/xml": XML</summary>
         */
        public static readonly ContentType XML = new ContentType("text", "xml",
            __("Extendable markup language."),
            ContentFileProperties.PlainText | ContentFileProperties.XMLText, "xml");

        /** <summary>"text/po": Gettext Translation Repositorium</summary>
         */
        public static readonly ContentType PO = new ContentType("text", "gettext-po", 
            __("Gettext Translation Repositorium."), ContentFileProperties.PlainText, "po");

        /** <summary>"text/po": Gettext Translation Module</summary>
         */
        public static readonly ContentType MO = new ContentType("application", "gettext-mo", 
            __("Gettext Translation Module."), ContentFileProperties.None, "mo");

        /** <summary>"image/gif"</summary>
         */
        public static readonly ContentType BMP = new ContentType("image", "bmp",
            __("Windows Bitmap."), ContentFileProperties.None, "bmp");

        /** <summary>"image/gif"</summary>
         */
        public static readonly ContentType GIF = new ContentType("image", "gif",
            __("Graphics interchange format."), ContentFileProperties.Compressed, "gif");

        /** <summary>"image/png": Portable network graphics</summary>
         */
        public static readonly ContentType PNG = new ContentType("image", "png",
            __("Portable network graphics."), ContentFileProperties.Compressed, "png");

        /** <summary> "image/xpm": X pixmap files </summary> */
        public static readonly ContentType XPM = new ContentType("image", "xpm", __("X pixmap files."),
            ContentFileProperties.PlainText, "xpm");

        /** <summary> "image/ico": Windows Icon Image </summary> */
        public static readonly ContentType ICO = new ContentType("image", "ico", 
            __("Windows Icon Image."),
            ContentFileProperties.Compressed, "ico");

        /** <summary> "image/jpeg": JPEG image file </summary> */
        public static readonly ContentType JPEG = new ContentType("image", "jpeg", "JPEG image file.", ContentFileProperties.Compressed, "jpg", "jpeg");

        /** <summary> "application/doxygen-config": Configuration for Doxygen </summary> */
        public static readonly ContentType DoxygenConfig = new ContentType("application", "doxygen-config",
            __("Configuration for Doxygen."),
            ContentFileProperties.PlainText, "dox", "doxygen");

        /** <summary> "application/hhp": Help Workshop Project </summary> */
        public static readonly ContentType HHP = new ContentType("application", "hhp",
            __("Help Workshop Project."),
            ContentFileProperties.PlainText, "hhp");

        /** <summary> "application/hhk": Help Workshop Keywords </summary> */
        public static readonly ContentType HHK = new ContentType("application", "hhk",
            __("Help Workshop Keywords."),
            ContentFileProperties.PlainText, "hhk");

        /** <summary> "application/hhc": Help Workshop Contents </summary> */
        public static readonly ContentType HHC = new ContentType("application", "hhc",
            __("Help Workshop Contents."),
            ContentFileProperties.PlainText, "hhc");

        /** <summary> "application/htb": Hyper Text Book </summary> */
        public static readonly ContentType HTB = new ContentType("application", "htb", 
            __("Hyper Text Book."),
            ContentFileProperties.Compressed, "htb");

        /** <summary> "application/zipped-resource": Zipped resource system file. </summary> */
        public static readonly ContentType ZippedResource = new ContentType("application", "zipped-resource",
            __("Zipped resource system file."),
            ContentFileProperties.Compressed, "zrs");

        /** <summary> "application/nmake": <c>nmake </c> .exe program. </summary> */
        public static readonly ContentType NMake = new ContentType("application", "nmake",
            __("NMake program."),
            ContentFileProperties.PlainText, "vc", "mak");

        /** <summary> "application/gnu-make": GNU Make program. </summary> */
        public static readonly ContentType GMake = new ContentType("application", "gnu-make",
            __("GNU Make program."),
            ContentFileProperties.PlainText, "Make*");

        /** <summary> "application/premake": Premake program (refer to "http://premake.sourceforge.net)" </summary> */
        public static readonly ContentType Premake = new ContentType("application", "premake",
            __("Premake program."),
            ContentFileProperties.PlainText, "premake", "lua");

        /// <summary>
        /// Visual Basic source code.
        /// </summary>
        public static readonly ContentType VisualBasic = new ContentType("text", "vbasic",
            __("Visual Basic source code."),
            ContentFileProperties.PlainText, "vb");

        /// <summary>
        /// MS solution file - the data file of Visual Studio.
        /// </summary>
        public static readonly ContentType MSSolution = new ContentType("application", "visual-studio",
            __("MS solution file - the data file of Visual Studio."),
            ContentFileProperties.PlainText | ContentFileProperties.XMLText, "sln");

        /// <summary>
        /// MS Visual Studio C++ Project.
        /// </summary>
        public static readonly ContentType VCProject = new ContentType("application", "vc-project",
            __("MS Visual Studio C++ Project."), ContentFileProperties.PlainText | ContentFileProperties.XMLText, "vcproj");
        /// <summary>
        /// MS Visual Studio C# Project.
        /// </summary>
        public static readonly ContentType VSProject = new ContentType("application", "vs-project",
            __("MS Visual Studio C# Project."), ContentFileProperties.PlainText | ContentFileProperties.XMLText, "vsproj");
        /// <summary>
        /// MS Visual Studio VB.NET Project.
        /// </summary>
        public static readonly ContentType VBProject = new ContentType("application", "vb-project",
            __("MS Visual Studio VB.NET Project."), ContentFileProperties.PlainText | ContentFileProperties.XMLText, "vbproj");

        /** <summary> GZipped files. </summary> */
        //@{
        /** <summary> GZipped ContentType.CSharpCode. </summary> */
        public static readonly ContentType GZ_CSharpCode = new ContentType(CSharpCode, "gzipped", "csharp",
            __("GZipped C# code file."),
            ContentFileProperties.Compressed, "cs.gz");

        /** <summary> GZipped ContentType.CPlusPlusCode. </summary> */
        public static readonly ContentType GZ_CPlusPlusCode = new ContentType(CPlusPlusCode, "gzipped", "cplusplus",
            __("GZipped C++ code file."),
            ContentFileProperties.Compressed, "cpp.gz", "cc.gz", "c++.gz", "cxx.gz");
        /** <summary> GZipped ContentType.CPlusPlusInclude. </summary> */
        public static readonly ContentType GZ_CPlusPlusInclude = new ContentType(CPlusPlusInclude, "gzipped", "cplusplus-include",
            __("GZipped C++ include file."),
            ContentFileProperties.Compressed, "h.gz", "hh.gz", "hpp.gz", "hxx.gz", "h++.gz");
        /** <summary> GZipped ContentType.CCode. </summary> */
        public static readonly ContentType GZ_CCode = new ContentType(CCode, "gzipped", "c",
            __("GZipped C code file."),
            ContentFileProperties.Compressed, "h.gz");
        /** <summary> GZipped ContentType.CInclude. </summary> */
        public static readonly ContentType GZ_CInclude = new ContentType(CInclude, "gzipped", "c-include",
            __("GZipped C inlude file."),
            ContentFileProperties.Compressed, "h.gz");
        /** <summary> GZipped ContentType.DotNetDll. </summary> */
        public static readonly ContentType GZ_DotNetDll = new ContentType(DotNetDll, "gzipped", "dotnet-dll",
            __("GZipped .NET dynamically linkable program library."),
            ContentFileProperties.Compressed, "h.gz");
        /** <summary> GZipped ContentType.DotNetExe. </summary> */
        public static readonly ContentType GZ_DotNetExe = new ContentType(DotNetExe, "gzipped", "dotnet-executable",
            __("GZipped .NET executable."),
            ContentFileProperties.Compressed, "h.gz");
        //@}
        #endregion

        /** <summary> Directories or file folders etc. </summary> */
        public static readonly ContentType Directory = new ContentType("application", "directory", 
            __("Directory that may contain files."),
            ContentFileProperties.None);

        #region IComparable Member

        public int CompareTo(object obj)
        {
            int cmp = this.Primary.CompareTo(((ContentType)obj).Primary);
            if (cmp==0)
                cmp = this.Secondary.CompareTo(((ContentType)obj).Secondary);
            return cmp;
        }

        #endregion

        #region Overrides
        /** <summary> Please note, that equality only is defined wrt. primary and secondary type name. </summary> */
        public override bool Equals(object obj)
        {
            if (obj is ContentType)
            {
                ContentType arg = (ContentType)obj;
                return arg.Primary == this.Primary && arg.Secondary == this.Secondary;
            }
            else
                return false;
        }

        public override int GetHashCode()
        {
            return this.Primary.GetHashCode() ^ this.Secondary.GetHashCode();
        }

        /** <summary> The output only reflects primary and secondary typename (separated by a /). </summary> */
        public override string ToString()
        {
            return string.Format("{0}/{1}", this.Primary, this.Secondary);
        }
        #endregion

        #region IXmlSerializable Member
        /// <summary>
        /// Returns <c>null</c> as suggeted by  the framework documentation.
        /// </summary>
        /// <returns>null</returns>
        public System.Xml.Schema.XmlSchema GetSchema()
        {
            return null;
        }

        /// <summary>
        /// Reads a content type from the argument stream expecting the current position to point
        /// at the start of element "content-type".
        /// </summary>
        /// <param name="reader">The source.</param>
        public void ReadXml(System.Xml.XmlReader reader)
        {
            if (reader.IsStartElement("content-type"))
            {
                bool hasSubnotes = !reader.IsEmptyElement;
                #region Attributes
                if (reader.HasAttributes)
                {
                    reader.MoveToFirstAttribute();
                    do
                    {
                        string attrname = reader.Name;
                        if (attrname == "name" && reader.ReadAttributeValue())
                        {
                            string[] names = reader.Value.Split('/');
                            if (names.Length != 2)
                                throw new FormatException("Illegal mime type name: Missing / separator.");
                            this._primaryTypeName = names[0];
                            this._secondaryTypeName = names[1];
                        }
                        else if (attrname == "description" && reader.ReadAttributeValue())
                        {
                            this._description = reader.Value;
                        }
                    }
                    while (reader.MoveToNextAttribute());
                }
                else
                    throw new FormatException("Missing mandatory \"name\" attribut in \"content-type\".");
                #endregion

                #region Subnodes
                reader.Read();
                if (hasSubnotes)
                {
                    while (reader.IsStartElement())
                    {
                        string elementName = reader.Name;
                        reader.Read();
                        if (elementName == "properties")
                        {
                            string propString = reader.ReadContentAsString();
                            this._properties = (ContentFileProperties)Enum.Parse(typeof(ContentFileProperties), propString);
                        }
                        else if (elementName == "compressing")
                        {
                            ContentType compressed = ContentType.FromXml(reader);
                            this._compressedContent=compressed;
                        }
                        else if (elementName == "suffix")
                        {
                            string suffix = reader.ReadContentAsString();
                            this.AddSuffix(suffix);
                        }
                        else if (elementName == "implies")
                        {
                            ContentType implied = ContentType.FromXml(reader);
                            this._implies[implied] = implied;
                        }
                        reader.ReadEndElement();
                    }
                    reader.ReadEndElement();
                }
                #endregion
            }
            else
                throw new FormatException("Expected a content type XML-serialization.");
        }

        /// <summary>
        /// Only writes the name to the XML stream.
        /// Use this to write references to a content type whose data is already known.
        /// </summary>
        /// <param name="writer">The destination of the export.</param>
        public void WriteRefXml(System.Xml.XmlWriter writer)
        {
            writer.WriteStartElement("content-type");
            writer.WriteAttributeString("name", this.Name);
            writer.WriteEndElement();
        }

        /// <summary>
        /// Writes all properties into the provided XML stream.
        /// Please note, that a system can only load at most one type of the same name.
        /// All other occurances of the type, even if they have different properties,
        /// will be ignored silently.
        /// </summary>
        /// <param name="writer">The destination of the output.</param>
        public void WriteXml(System.Xml.XmlWriter writer)
        {
            writer.WriteStartElement("content-type");
            writer.WriteAttributeString("name", this.Name);
            writer.WriteAttributeString("description", this.Description);
            if (this.Properties != ContentFileProperties.None)
                writer.WriteElementString("properties", this.Properties.ToString());
            if (this._compressedContent != null)
            {
                writer.WriteStartElement("compressing");
                this.CompressedContent.WriteRefXml(writer);
                writer.WriteEndElement();
            }
            foreach(string suffix in this._suffixes)
                writer.WriteElementString("suffix", suffix);
            foreach (ContentType implied in this._implies.Values)
            {
                writer.WriteStartElement("implies");
                implied.WriteRefXml(writer);
                writer.WriteEndElement();
            }
            writer.WriteEndElement();
        }

        #endregion
    }
}
