/** Build system for wx.NET.
 * 
 * This DLL contains basic implementations to build (compile and link) C/C++ programs,
 * compile .NET assemblies written in C#, sign them, and install them.
 * 
 * \file 
 *
 * Copyright 2009-2010 Harald Meyer auf'm Hofe harald_meyer@users.sourceforge.net
 * 
 * Licensed under the wxWidgets license, see LICENSE.txt for details.
 * 
 * $Id: BuildActions.cs,v 1.22 2010/06/17 17:53:41 harald_meyer Exp $
 */



using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Text;

/** Utilities of the \e wx.NET build system.
 * The \e wx.NET build system consists of basic building actions like encapsulations of C# and C++ compilers.
 * Basic actions are often of constrained applicability. They often require external tools, certain operating
 * systems etc.
 * 
 * Main classes are BuildConfig where you can manipulate the configuration to be used for building and
 * class BuildProject. Create an instance of a BuildProject and call BuildProject.CreateActionPlan() or BuildProject.Build().
 */
namespace wx.Build
{
    /** <summary>A feature entry describes a feature of an implementation.</summary>
     * <remarks> Features are for instance used as input for conditional compilation.
     * Features have a display name, an internal name (symbol) that only consists of upper case letters, digits, and the underscrore, where
     * the first character must be a letter, and a description. </remarks>
     */
    public class FeatureEntry : IComparable, System.Xml.Serialization.IXmlSerializable
    {
        #region State
        string _displayname;
        string _description;
        string _symbol;
        #endregion

        #region Privates
        /** <summary> This will assign <c>newValue </c>  to <c>_symbol </c>  if the new value meets the syntactical requirements.
         * Otherwise, this will throw an <c>System </c> .ArgumentException. </summary> */
        void SetSymbol(string newValue)
        {
            if (newValue.Length == 0 || (!char.IsUpper(newValue[0]) && newValue[0] != '_'))
                throw new ArgumentException("Feature symbols must start with an upper case letter or the underscore.");
            foreach (char c in newValue)
            {
                if (char.IsUpper(c) || char.IsDigit(c) || c == '_')
                {
                    // OK
                }
                else
                {
                    throw new ArgumentException("Illeagal feature symbol.");
                }
            }
            this._symbol = newValue;
        }
        #endregion

        #region CTor
        /** <summary> This creates a new feature entry.</summary><remarks>
         * \param displayname will be the display name.
         * \param description is the description of the feature that will be used in user interfaces.
         * \param symbol is a non-empty string that will be used in code bases to identify the feature for instance as symbol in conditional compilation.
         *        This must consist exclusively of upper case letters, digits, or the underscore, where the first character is either a letter or
         *        the underscore. This will throw a System.ArgumentException if this is empty or incompatible with the abovementioned requirements.
         *        The symbol will also be used to identify the feature in CommandLineOptions. </remarks> */
        public FeatureEntry(string displayname, string description, string symbol)
        {
            this._displayname = displayname;
            this._description = description;
            this.SetSymbol(symbol);
        }
        #endregion

        #region Public Properties
        /** <summary> The display name in user interfaces. </summary> */
        public string Displayname { get { return this._displayname; } }

        /** <summary> The description is the description of the feature that will be used in user interfaces. </summary> */
        public string Description { get { return this._description; } }

        /** <summary> A non-empty string that will be used in code bases to identify the feature for instance as symbol in conditional compilation. </summary> */
        public string Symbol { get { return this._symbol; } }
        #endregion

        #region IComparable Member

        public int CompareTo(object obj)
        {
            FeatureEntry objEntry = obj as FeatureEntry;
            int cmp = 0;
            if (cmp == 0)
                cmp = this.Displayname.CompareTo(objEntry.Displayname);
            if (cmp == 0)
                cmp = this.Symbol.CompareTo(objEntry.Symbol);
            if (cmp == 0)
                cmp = this.Description.CompareTo(objEntry.Description);
            return cmp;
        }

        #endregion

        #region Overrides
        public override bool Equals(object obj)
        {
            if (obj is FeatureEntry)
                return this.CompareTo(obj) == 0;
            else
                return false;
        }

        public override int GetHashCode()
        {
            return this.Symbol.GetHashCode();
        }

        public override string ToString()
        {
            return string.Format("{0} ({2}): {1}", this.Displayname, this.Description, this.Symbol);
        }
        #endregion

        #region IXmlSerializable Member

        public System.Xml.Schema.XmlSchema GetSchema()
        {
            return null;
        }

        public void ReadXml(System.Xml.XmlReader reader)
        {
            if (reader.IsStartElement("feature-entry"))
            {
                this._symbol = reader.GetAttribute("symbol");
                reader.Read();
                this._displayname = reader.ReadElementString("display-name");
                this._description = reader.ReadElementString("description");
                reader.ReadEndElement();
            }
            else
                reader.ReadStartElement("feature-entry"); // produce an error
        }

        public void WriteXml(System.Xml.XmlWriter writer)
        {
            writer.WriteStartElement("feature-entry");
            writer.WriteAttributeString("symbol", this._symbol);
            writer.WriteElementString("display-name", this._displayname);
            writer.WriteElementString("description", this._description);
            writer.WriteEndElement();
        }

        #endregion
    }

    /** <summary> A feature list is a list of feature entries that may be activated or not.
     * Featurelists occur as build objects representing variants of the software product. </summary> */
    public class FeatureList : IBuildProduct, IDictionary<FeatureEntry, bool>, System.Xml.Serialization.IXmlSerializable
    {
        #region State
        SortedList<FeatureEntry, bool> _data = new SortedList<FeatureEntry, bool>();
        IDictionary<string, FeatureEntry> _symbols = new Dictionary<string, FeatureEntry>();
        #endregion

        #region CTor
        /** <summary> This will create a list containing the provided enabled features. </summary> */
        public FeatureList(params FeatureEntry[] features)
        {
            if (features != null)
                foreach (FeatureEntry feature in features)
                    this.Add(feature, true);
        }
        #endregion

        #region IDictionary<FeatureEntry,bool> Member
        /** <summary> Adds a new feature entry. 
         * This will raise an argument exception, if the new feature entry refers to an already used symbol. </summary> */
        public void Add(FeatureEntry key, bool value)
        {
            this._data[key]=value;
            this._symbols[key.Symbol]=key;
        }

        /** <summary> This will add all features from the argument to this.
         * This will raise an <c>System </c> .ArgumentException if this already defines at least one of
         * the features fromr <c>features </c> . </summary> */
        public void AddRange(FeatureList features)
        {
            if (features != null)
            {
                foreach (KeyValuePair<FeatureEntry, bool> entry in features)
                    this.Add(entry);
            }
        }

        /** <summary> True iff this already has a feature referring to the provided feature symbol. </summary> */
        public bool ContainsSymbol(string symbol)
        {
            return this._symbols.ContainsKey(symbol);
        }
        /** <summary> True iff this already refers to the feature symbol of the provided feature key. </summary> */
        public bool ContainsSymbol(FeatureEntry featureEntry)
        {
            return this.ContainsSymbol(featureEntry.Symbol);
        }

        public bool ContainsKey(FeatureEntry key)
        {
            return this._data.ContainsKey(key);
        }

        public ICollection<FeatureEntry> Keys
        {
            get { return this._data.Keys; }
        }

        public bool Remove(FeatureEntry key)
        {
            if (this._data.Remove(key))
            {
                this._symbols.Remove(key.Symbol);
                return true;
            }
            else
                return false;
        }

        public bool TryGetValue(FeatureEntry key, out bool value)
        {
            return this._data.TryGetValue(key, out value);
        }


        /** <summary> A collection of all explicitely used activation states. </summary> */
        public ICollection<bool> Values
        {
            get { return this._data.Values; }
        }

        /** <summary> A collection of all enabled feature symbols. </summary> */
        public ICollection<string> EnabledSymbols
        {
            get
            {
                List<string> result = new List<string>();
                foreach (KeyValuePair<FeatureEntry, bool> pair in this)
                    if (pair.Value)
                        result.Add(pair.Key.Symbol);
                return result;
            }
        }

        /** <summary> Returns this list of features without those mentioned in the argumetns. </summary> */
        public FeatureList Without(params FeatureEntry[] features)
        {
            SortedDictionary<FeatureEntry, FeatureEntry> filter = new SortedDictionary<FeatureEntry, FeatureEntry>();
            foreach (FeatureEntry filterEntry in features)
                filter[filterEntry] = filterEntry;

            FeatureList result = new FeatureList();
            foreach (KeyValuePair<FeatureEntry, bool> pair in this)
            {
                if (!filter.ContainsKey(pair.Key))
                    result.Add(pair);
            }
            return result;
        }

        /** <summary> A collection of all enabled feature symbols.
         * This is a collextion of explicitely disabled symbols, i.e. symbols that are contained but associated with value <c>false </c> . </summary> */
        public ICollection<string> DisabledSymbols
        {
            get
            {
                List<string> result = new List<string>();
                foreach (KeyValuePair<FeatureEntry, bool> pair in this)
                    if (!pair.Value)
                        result.Add(pair.Key.Symbol);
                return result;
            }
        }

        /** <summary> Read or set the activation state of the feature designated by <c>key </c> .
         * If this is <c>true </c> , the feature is enabled. If this is <c>false </c> , the feature is disabled.
         * Features that are not part of this list will return <c>false </c> .
         * 
         * If you set this, keep in mind, that this will raise an System.IndexOutOfRangeException,
         * if <c>key </c>  is a new feature referring to an already used feature symbol. </summary> */
        public bool this[FeatureEntry key]
        {
            get
            {
                if (this._data.ContainsKey(key))
                    return this._data[key];
                else
                    return false;
            }
            set
            {
                if (this._symbols.ContainsKey(key.Symbol) && !this._data.ContainsKey(key))
                    throw new IndexOutOfRangeException("Assigning to this feature entry in the feature list will lead to ambigious use of symbols.");
                this._data[key] = value;
                this._symbols[key.Symbol] = key;
            }
        }

        /** <summary> Get the value associated with the provided symbol.
         * This will first determine the feature associated with the provided symbol and then look for the value of this feature.
         * This will return <c>false </c>  also on unknown symbols. </summary> */
        public bool this[string symbol]
        {
            get
            {
                if (this._symbols.ContainsKey(symbol))
                    return this[this._symbols[symbol]];
                else
                    return false;
            }
        }
        #endregion

        #region ICollection<KeyValuePair<FeatureEntry,bool>> Member

        public void Add(KeyValuePair<FeatureEntry, bool> item)
        {
            this.Add(item.Key, item.Value);
        }

        public void Clear()
        {
            this._data.Clear();
            this._symbols.Clear();
        }

        public bool Contains(KeyValuePair<FeatureEntry, bool> item)
        {
            return this._data.ContainsKey(item.Key) && this[item.Key] == item.Value;
        }

        public void CopyTo(KeyValuePair<FeatureEntry, bool>[] array, int arrayIndex)
        {
            foreach(FeatureEntry key in this.Keys)
            {
                array[arrayIndex] = new KeyValuePair<FeatureEntry, bool>(key, this._data[key]);
                ++arrayIndex;
            }
        }

        public int Count
        {
            get { return this._data.Count; }
        }

        public bool IsReadOnly
        {
            get { return false; }
        }

        public bool Remove(KeyValuePair<FeatureEntry, bool> item)
        {
            if (this.Contains(item))
                return this.Remove(item.Key);
            return false;
        }

        #endregion

        #region IEnumerable<KeyValuePair<FeatureEntry,bool>> Member

        public IEnumerator<KeyValuePair<FeatureEntry, bool>> GetEnumerator()
        {
            return this._data.GetEnumerator();
        }

        #endregion

        #region IEnumerable Member

        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            return this._data.GetEnumerator();
        }

        #endregion

        #region IBuildProduct Member
        /** <summary> This will return itself. </summary> */
        public ICollection<IBuildProduct> GetTargets()
        {
            throw new Exception("The method or operation is not implemented.");
        }

        /** <summary> This returns <c>null </c>  because this does not imply build projects. </summary> */
        public ICollection<RefToProject> GetProjects()
        {
            return null;
        }

        /** <summary> Does nothing and states success.
         * Override this to implement an action that determines the features. </summary> */
        public virtual bool Execute(BuildToolFamilyEnv env, DateTime validityOfBuildSystem)
        {
            return true;
        }

        #endregion

        #region IBuildProduct Member
        /** <summary> Like created in the beginning of times and never changed since then.
         * Override this to implement an action that determines the features. </summary> */
        public virtual DateTime GetValidity()
        {
            return DateTime.MinValue;
        }

        /** <summary> Requires rebuild. </summary> */
        public virtual DateTime GetValidityDemand()
        {
            return DateTime.MaxValue;
        }
        #endregion

        #region Overrides
        public override bool Equals(object obj)
        {
            if (obj is FeatureList)
            {
                if (this._data.Count != ((FeatureList)obj)._data.Count)
                    return false;
                IEnumerator<KeyValuePair<FeatureEntry, bool>> iThis = this._data.GetEnumerator();
                IEnumerator<KeyValuePair<FeatureEntry, bool>> iObj = ((FeatureList)obj)._data.GetEnumerator();
                while (iThis.MoveNext() && iObj.MoveNext())
                {
                    if (!iThis.Current.Key.Equals(iObj.Current.Key))
                        return false;
                    if (!iThis.Current.Value.Equals(iObj.Current.Value))
                        return false;
                }
                return true;
            }
            else
                return false;
        }

        public override int GetHashCode()
        {
            int result = 0;
            foreach (FeatureEntry entry in this._data.Keys)
                result = result ^ entry.GetHashCode();
            return result;
        }

        public override string ToString()
        {
            if (this._data.Count == 0)
            {
                return "empty feature list";
            }
            else
            {
                StringBuilder sb = new StringBuilder();
                foreach (KeyValuePair<FeatureEntry, bool> pair in this._data)
                {
                    if (sb.Length > 0)
                        sb.Append(",");
                    sb.AppendFormat("{0}:{1}", pair.Key.Displayname, pair.Value);
                }
                return sb.ToString();
            }
        }
        #endregion

        #region IComparable Member

        public int CompareTo(object obj)
        {
            if (obj is FeatureList)
            {
                if (this._data.Count != ((FeatureList)obj)._data.Count)
                    return this._data.Count.CompareTo(((FeatureList)obj)._data);
                IEnumerator<KeyValuePair<FeatureEntry, bool>> iThis = this._data.GetEnumerator();
                IEnumerator<KeyValuePair<FeatureEntry, bool>> iObj = ((FeatureList)obj)._data.GetEnumerator();
                while (iThis.MoveNext() && iObj.MoveNext())
                {
                    int cmp = iThis.Current.Key.CompareTo(iObj.Current.Key);
                    if (cmp != 0)
                        return cmp;
                    cmp = iThis.Current.Value.CompareTo(iObj.Current.Value);
                    if (cmp != 0)
                        return cmp;                    
                }
                return 0;
            }
            else
                return this.GetType().FullName.CompareTo(obj.GetType().FullName);
        }

        #endregion

        #region IXmlSerializable Member

        public System.Xml.Schema.XmlSchema GetSchema()
        {
            return null;
        }

        public void ReadXml(System.Xml.XmlReader reader)
        {
            this.Clear();
            bool isEmpty = reader.IsEmptyElement;
            reader.ReadStartElement("feature-list");
            if (!isEmpty)
            {
                while (reader.IsStartElement("feature"))
                {
                    bool enable = Convert.ToBoolean(reader.GetAttribute("enabled"));
                    reader.Read();
                    FeatureEntry feature = new FeatureEntry("", "", "DEBUG");
                    feature.ReadXml(reader);
                    this.Add(feature, enable);
                    reader.ReadEndElement();
                }
                reader.ReadEndElement();
            }
        }

        public void WriteXml(System.Xml.XmlWriter writer)
        {
            writer.WriteStartElement("feature-list");
            foreach(KeyValuePair<FeatureEntry, bool> enableFeaturePair in this._data)
            {
                writer.WriteStartElement("feature");
                writer.WriteAttributeString("enabled", enableFeaturePair.Value.ToString());
                enableFeaturePair.Key.WriteXml(writer);
                writer.WriteEndElement();
            }
            writer.WriteEndElement();
        }

        #endregion
    }

    /** <summary> An error object simply consists of a classification, a string pattern, and a sequence of objects that may be inserted into the error message pattern.
     * 
     * Objects of this class represent an error in a ErrorHandler. </summary> */
    public class ErrorObject
    {
        #region Public Types
        public enum MessageType
        {
            Error,
            Warning,
            Message,
        }

        /** <summary> This class is to declare position in a file within an error object. </summary> */
        public class FilePos
        {
            public string Filename;
            public int Line;
            public int Column;

            /** <summary> All arguments as string. </summary> */
            public FilePos(string filename, string line, string column)
            {
                this.Filename = filename.Trim();
                line = line.Trim();
                if (line.Length > 0)
                    this.Line = Convert.ToInt32(line);
                else
                    this.Line = -1;
                column = column.Trim();
                if (column.Length > 0)
                    this.Column = Convert.ToInt32(column);
                else
                    this.Column = -1;
            }

            public FilePos(string filename, int line, int column)
            {
                this.Filename = filename.Trim();
                this.Line=line;
                this.Column=column;
            }

            public FilePos(string filename, int line)
                : this(filename, line, -1)
            {
            }

            /** <summary> True iff this does not contain any info.
             * True if file name is empty and both, line and column, are illegal indices lower than 0. </summary> */
            public bool IsEmpty
            {
                get
                {
                    return this.Filename.Length == 0 && this.Line < 0 && this.Column < 0;
                }
            }

            public override bool Equals(object obj)
            {
                if (obj is FilePos)
                {
                    FilePos pos = (FilePos)obj;
                    return pos.Filename == this.Filename && pos.Line == this.Line && pos.Column == this.Column;
                }
                else
                    return false;
            }

            public override int GetHashCode()
            {
                return this.Filename.GetHashCode() ^ this.Line ^ this.Column;
            }

            public override string ToString()
            {
                if (this.Line > 0 && this.Column >= 0)
                    return string.Format("{0}({1},{2})", this.Filename, this.Line, this.Column);
                else if (this.Line > 0)
                    return string.Format("{0}({1})", this.Filename, this.Line);
                else
                    return this.Filename;
            }
        }

        /** <summary> A wrapper of the error number. 
         * So you may find this in the object list of error messages. </summary> */
        public class ErrorNumber
        {
            public string Value;
            ErrorNumber(string value)
            {
                this.Value = value;
            }

            /** <summary> Creates a new instance.
             * If the argument is <c>null </c> , the reauls will also be <c>null </c> .
             * </summary> */
            public static ErrorNumber Create(string value)
            {
                if (value==null)
                    return null;
                else
                    return new ErrorNumber(value);
            }

            public override string ToString()
            {
                return this.Value;
            }
        }
        #endregion

        #region State
        MessageType _type;
        string _messagepattern;
        object[] _errorobjects;
        #endregion

        #region CTor
        /// <summary>
        /// Converts a text message into an error object.
        /// </summary>
        /// <param name="msg">The text message.</param>
        public ErrorObject(wx.ProcessUtils.MsgEventArgs msg)
        {
            switch (msg.Type)
            {
                case wx.ProcessUtils.MsgType.Error: this._type = ErrorObject.MessageType.Error; break;
                case wx.ProcessUtils.MsgType.Message: this._type = ErrorObject.MessageType.Message; break;
                case wx.ProcessUtils.MsgType.Warning: this._type = ErrorObject.MessageType.Warning; break;
            }
            this._messagepattern = msg.Msg;
            this._errorobjects = new object[0];
        }

        /// <summary> Creates an instance of an error object.</summary>
        /// <param name="type">is the type of the message.
        /// </param>
        /// <param name="pattern">is a string pattern like "Object {0} is inconsistent".</param>
        /// <param name="errorobjets">is an array of objects that have to be inserted into the pattern if required.
        /// Collections of build projects contained by  this array will be printed as comma separated list.</param>
        public ErrorObject(MessageType type, string pattern, params object[] errorobjets)
        {
            this._type = type;
            this._messagepattern = pattern;
            this._errorobjects = errorobjets;
        }
        #endregion

        #region Public Properties
        public MessageType Type { get { return this._type; } }
        public string MessagePattern
        {
            get
            {
                if (this._messagepattern==null)
                    return "";
                else
                    return this._messagepattern;
            }
        }
        public object[] ErrorObjects { get { return this._errorobjects; } }

        /** <summary> Returns the error object of the specified type if it exists.
         * Otherwise, this will return <c>null </c> . </summary> */
        public object GetErrorObject(Type typeOfErrorObject)
        {
            foreach (object obj in this._errorobjects)
                if (typeOfErrorObject.IsInstanceOfType(obj))
                    return obj;
            return null;
        }
        #endregion

        #region Overrides
        public override string ToString()
        {
            ErrorNumber errorNumber = (ErrorNumber) this.GetErrorObject(typeof(ErrorNumber));
            IBuildAction causedByAction = (IBuildAction)this.GetErrorObject(typeof(IBuildAction));

            string prefix = "";
            if (this._type != MessageType.Message)
                prefix+=this._type.ToString();
            if (causedByAction != null)
            {
                if (prefix.Length > 0)
                    prefix += " ";
                prefix += causedByAction.Name;
            }
            if (errorNumber != null)
                prefix += "/" + errorNumber.ToString();
            if (prefix.Length > 0)
                prefix += ": ";
            if (this._errorobjects == null || this._errorobjects.Length==0)
                return string.Format("{0}{1}", prefix, this.MessagePattern);
            else
            {
                try
                {
                    // clone the error objects and replace collections by a comma separated list of elements
                    object[] errorObjectsClone = new object[this._errorobjects.Length];
                    for (int i=0; i < this._errorobjects.Length; ++i)
                    {
                        object errorObject=this._errorobjects[i];
                        if (errorObject is ICollection<IBuildProduct>)
                        {
                            StringBuilder printOut = new StringBuilder();
                            bool first = true;
                            foreach (IBuildProduct p in ((ICollection<IBuildProduct>)errorObject))
                            {
                                if (!first)
                                    printOut.Append(",");
                                printOut.Append(p.ToString());
                                first = false;
                            }
                            errorObjectsClone[i] = printOut;
                        }
                        else
                            errorObjectsClone[i] = errorObject;
                    }
                    return string.Format("{0}{1}", prefix, string.Format(this.MessagePattern, this._errorobjects));
                }
                catch
                {
                    return string.Format("{0}{1}", prefix, this.MessagePattern);
                }
            }
        }
        #endregion
    }

    /** <summary> Type for means to produce output on errors and warnings.
     * Refer to ErrorDataReceiver if you want to use error handlers with <c>System </c> .Diagnostics.Process. </summary> */
    public delegate void ErrorHandler(ErrorObject errorObject);

    ///<summary> This class is a utility to use the ErrorHandler in \c System.Diagnostics.Process.Start().
    /// Shell commands are typically executed by the <c>System.Diagnostics.Process.Start()</c> command. Build tools
    /// will usually do this specifying a \c System.Diagnostics.Process.StartInfo disabling use of the command
    /// shell but redirecting output of errors and messages.
    /// </summary>
    /// <remarks> This handler may be used as asynchron receiver of messages from the error stream that redirects this
    /// output to an ErrorHandler.
    /// Sample code:
    /// <code>
    /// System.Diagnostics.Process process = new System.Diagnostics.Process();
    /// process.StartInfo.FileName="commandToRun.exe";
    /// process.StartInfo.ErrorDialog = false;
    /// process.StartInfo.CreateNoWindow = false;
    /// process.StartInfo.UseShellExecute = false;
    /// process.StartInfo.RedirectStandardError = true;
    /// process.StartInfo.RedirectStandardOutput = true;
    /// ErrorDataReceiver receiver=new ErrorDataReceiver(this.Name, messages);
    /// process.ErrorDataReceived += new System.Diagnostics.DataReceivedEventHandler(receiver.OnReceiveErrorStreamData);
    /// process.Start();
    /// process.BeginErrorReadLine();
    /// process.BeginOutputReadLine();
    /// process.WaitForExit();
    /// bool success=process.ExitCode == 0;
    /// </code>
    /// </remarks>
    public class ErrorDataReceiver
    {
        #region State
        IBuildAction _processedAction;
        ErrorHandler _handler;

        System.Text.RegularExpressions.Regex _warningClassifiers = null;
        System.Text.RegularExpressions.Regex _errorClassifier = null;

        System.Text.RegularExpressions.Regex _filePosPattern = null;

        bool _enableErrorObjects = true;
        #endregion

        #region Public Properties
        /** <summary> If a message line complies with this expression, this will be classified as ErrorObject.MessageType warning. </summary> */
        public System.Text.RegularExpressions.Regex WarningClassifier { get { return this._warningClassifiers; } set { this._warningClassifiers = value; } }

        /** <summary> If a message line complies with this expression, this message will be classified as MessageType error. </summary> */
        public System.Text.RegularExpressions.Regex ErrorClassifier { get { return this._errorClassifier; } set { this._errorClassifier = value; } }

        /** <summary> Pattern defining print out of ErrorObject.FilePos in the received error lines.
         * This may be <c>null </c>  if not known. This pattern may identify the groups "file", "line", and "column". </summary> */
        public System.Text.RegularExpressions.Regex FilePosPattern { get { return this._filePosPattern; } set { this._filePosPattern = value; } }
        #endregion

        /** <summary> Creates an instance.</summary><remarks>
         * \param processedAction is the action that caused the message or <c>null </c>  if this is unknown.
         * \param handler is the receiver of all messages. <c>null </c>  is allowed here and will tell this
         *        receiver to use the standard procedure in BuildConfig to handle error objects including
         *        logging on XML file if configured.
         * Note, that instances created by this CTor will enable error objects. </remarks> */
        public ErrorDataReceiver(IBuildAction processedAction, ErrorHandler handler) :
            this(processedAction, handler, true)
        {
        }

        /** <summary> Creates an instance sending errors and messages to the configured error handler.</summary><remarks>
         * \param processedAction is the action that caused the message or <c>null </c>  if this is unknown. </remarks> */
        public ErrorDataReceiver(IBuildAction processedAction)
            : this(processedAction, null)
        {
        }

        /** <summary> Creates an instance.</summary><remarks>
         * \param processedAction is the action that caused the message or <c>null </c>  if this is unknown.
         * \param handler is the receiver of all messages. <c>null </c>  is allowed here and will tell this
         *        receiver to use the standard procedure in BuildConfig to handle error objects including
         *        logging on XML file if configured.
         * \param enableErrorObjects will enable the detection of file positions as error objects.
         *        Some tools throw error messages that cannot be used as format strings. In that case,
         *        the use of error objects shall be disabled. </remarks> */
        public ErrorDataReceiver(IBuildAction processedAction, ErrorHandler handler, bool enableErrorObjects)
        {
            this._processedAction = processedAction;
            this._handler = handler;
            this._enableErrorObjects = enableErrorObjects;
        }

        List<object> ProduceErrorObjectData(string line)
        {
            List<object> filePositions = new List<object>();
            if (this._enableErrorObjects)
            {
                if (this._processedAction != null)
                    filePositions.Add(this._processedAction);
                if (this._filePosPattern != null)
                {
                    System.Text.RegularExpressions.MatchCollection matches = this._filePosPattern.Matches(line);
                    foreach (System.Text.RegularExpressions.Match match in matches)
                    {
                        ErrorObject.FilePos newFilePos = new ErrorObject.FilePos(match.Groups["file"].Value,
                            match.Groups["line"].Value, match.Groups["column"].Value);
                        if (!newFilePos.IsEmpty)
                            filePositions.Add(newFilePos);
                    }
                }
            }
            return filePositions;
        }

        /// <summary>
        /// Normalization: Turns compiler or linker message into a format string.
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        string ConvertMessageToFormatString(string message)
        {
            return message.Replace("{", "{{").Replace("}", "}}");
        }

        /** <summary> This always produces errors. </summary> */
        public void OnReceiveErrorStreamData(object sender, System.Diagnostics.DataReceivedEventArgs evt)
        {
            if (!string.IsNullOrEmpty(evt.Data))
            {
                ErrorObject obj = new ErrorObject(ErrorObject.MessageType.Error, this.ConvertMessageToFormatString(evt.Data), ProduceErrorObjectData(evt.Data).ToArray());
                if (this._handler == null)
                    BuildConfig.HandleErrorObject(obj);
                else
                    this._handler(obj);
            }
        }

        /// <summary>
        /// This is appropriate to create wx.Utils.MsgEventHandler.
        /// </summary>
        /// <param name="sender">sender of the event. Unused.</param>
        /// <param name="evt">The event encapsulating a string and a message type.</param>
        public void OnReceiveMsgEvent(object sender, wx.ProcessUtils.MsgEventArgs evt)
        {
            if (!string.IsNullOrEmpty(evt.Msg))
            {
                ErrorObject obj = new ErrorObject(evt);
                if (this._handler == null)
                    BuildConfig.HandleErrorObject(obj);
                else
                    this._handler(obj);
            }
        }

        /** <summary> This tries to classify output according to the set classifiers. </summary> */
        public void OnReceiveOutputStreamData(object sender, System.Diagnostics.DataReceivedEventArgs evt)
        {
            if (!string.IsNullOrEmpty(evt.Data))
            {
                ErrorObject.MessageType type = ErrorObject.MessageType.Message;
                if (this._errorClassifier != null && this._errorClassifier.IsMatch(evt.Data))
                {
                    type = ErrorObject.MessageType.Error;
                }
                else if (this._warningClassifiers != null && this._warningClassifiers.IsMatch(evt.Data))
                {
                    type = ErrorObject.MessageType.Warning;
                }

                ErrorObject obj = new ErrorObject(type, this.ConvertMessageToFormatString(evt.Data), ProduceErrorObjectData(evt.Data).ToArray());
                if (this._handler == null)
                    BuildConfig.HandleErrorObject(obj);
                else
                    this._handler(obj);
            }
        }

    }

    /// <summary> Some helpers that may be useful implementing wx.Build.IBuildAction.</summary>
    public abstract class BaseAction
    {
        #region State
        BuildProject _project=null;
        #endregion

        /// <summary> Returns the features that are associated with this action.
        /// This feature list usually comes from the BuildProject that created this action.
        /// Overload this for projects!!!
        /// </summary>
        public virtual FeatureList Features
        {
            get
            {
                if (this._project == null)
                    return new FeatureList();
                return this._project.Features;
            }
        }

        /// <summary>
        /// The project that requested this action.
        /// </summary>
        public BuildProject Project { get { return this._project; }
            set
            {
                if (this._project != null)
                    throw new NotSupportedException("IBuildAction.BuildProject can be set only once.");
                this._project = value;
            }
        }

        /** <summary> This returns <c>null </c>  since useually shell variables are not used by actions. </summary>
         * <remarks></remarks>
         */
        virtual public IDictionary<string, EnvironmentVarInfo> UsedVars { get { return null; } }

        /// <summary>
        /// True iff all mandatory environment variables are defined. The project cannot be made
        /// if this is false.
        /// </summary>
        public bool AreAllMandatoryVarsDefined()
        {
           IDictionary<string, EnvironmentVarInfo> usedVars=this.UsedVars;
           if (usedVars != null)
           {
              foreach ( EnvironmentVarInfo varInfo in usedVars.Values )
              {
                 if (varInfo.IsMandatory && varInfo.IsEmpty())
                    return false;
              }
           }
           return true;
        }

        /** <summary>Collection of the prerequisites of this action.</summary>
         */
        abstract public ICollection<IBuildProduct> GetPrerequisites();

        /** <summary> </summary>True iff <c>prereq</c> is among the GetPrerequisites().</summary> </summary> */
        virtual public bool ContainsPrerequisite(IBuildProduct prereq)
        {
            return this.GetPrerequisites().Contains(prereq);
        }

        /** <summary>Collection of the targets or products of this action.</summary>
         */
        abstract public ICollection<IBuildProduct> GetTargets();

        /** <summary>This is the timestamp representing how current the prerequisites are.
         * The standard implementation will use be the latest validity of a prerequisite.</summary>
         */
        public virtual DateTime GetValidity()
        {
            DateTime validityPrereq = DateTime.MinValue;
            ICollection<IBuildProduct> prerequisites = GetPrerequisites();
            if (prerequisites == null)
                return validityPrereq;
            foreach (IBuildProduct prerequisite in prerequisites)
            {
                DateTime validity = prerequisite.GetValidity();
                if (validity > validityPrereq)
                    validityPrereq = validity;
            }
            return validityPrereq;
        }

        /** <summary> This is the timestamp representing the latest change of a prerequisite.
         * The standard implementation will use be the latest validity of a prerequisite. </summary> */
        public virtual DateTime GetValidityDemand()
        {
            DateTime validityPrereq = DateTime.MinValue;
            ICollection<IBuildProduct> prerequisites = GetPrerequisites();
            if (prerequisites == null)
                return validityPrereq;
            foreach (IBuildProduct prerequisite in prerequisites)
            {
                DateTime validity = prerequisite.GetValidityDemand();
                if (validity > validityPrereq)
                    validityPrereq = validity;
            }
            return validityPrereq;
        }

        /** <summary> This is the earliest validiy of a target. </summary> */
        public DateTime GetValidityTargets()
        {
            ICollection<IBuildProduct> targets = GetTargets();
            DateTime validityTargets = DateTime.MaxValue;
            if (targets == null)
                return validityTargets;
            foreach (IBuildProduct target in targets)
            {
                DateTime validity = target.GetValidity();
                if (validity < validityTargets)
                    validityTargets = validity;
            }
            return validityTargets;
        }

        /** <summary> This simply tests whether the oldest validity of the targets is equal to or more current than the validity of the prerequisites.</summary>
         * <param name="validityOfBuildSystem">indicates the last change of either this DLL or the assembly defining the project.
         * changes to the build system or the project definition affect of course the validity of the produced targets.
         * Use System.DateTime.MinValue if you do not know or want this to be neglected.</param>
         */
        public virtual bool TargetsAreConsistent(DateTime validityOfBuildSystem)
        {
            DateTime validityOfTargets=this.GetValidityTargets();
            return validityOfTargets >= validityOfBuildSystem && validityOfTargets >= this.GetValidityDemand();
        }

        /** <summary> Returns a collection (typically an array) of relevant parameter types in the BuildConfig.
        * This may be empty or <c>null </c>  if instances of this class do not refer to parameter types.
        * The return value of this implementation is <c>null </c> . </summary> */
        public virtual ICollection<Type> ParameterTypes { get { return null; } }

        /** <summary> This simply returns <c>null </c>  and may serve as standard implementation of those actions that do not use System.Diagnostics.Process. </summary> */
        public virtual System.Diagnostics.ProcessStartInfo GetProgramStartInfo(BuildToolFamilyEnv env)
        {
            return null;
        }

        /// <summary>
        /// This method collects all choice points within this action. Choice points are represented by a name and a
        /// collection of alternatives. 
        /// </summary>
        /// <param name="collectionOfChoicePoints">The collection that will be extended by the choice points
        /// of this action. </param>
        /// <example>
        /// The current implementation provides a choice point for the compilation and linking of C/C++
        /// programs, "CppDevelopmentSystem" of the alternatives "GCC" and "MS VC". Thus, actions on C/C++
        /// compilation will add the following choice point:
        /// <code>
        /// if (!collectionOfChoicePoints.ContainsKey("CppDevelopmentSystem"))
        ///     collectionOfChoicePoints.Add("CppDevelopmentSystem", new List&lt;string&gt;());
        /// collectionOfChoicePoints["CppDevelopmentSystem"].Add("GCC");
        /// collectionOfChoicePoints["CppDevelopmentSystem"].Add("MS VC");
        /// </code>
        /// </example>
        public void CollectChoicePoints(IDictionary<string, ICollection<string>> collectionOfChoicePoints)
        {
        }

        #region BOO support
        /// <summary>
        /// This will be called for any action provider before IBuildAction.AppendBooCode() is called.
        /// This provides action providers with the opportunity to import modules and create variables
        /// for global options.
        /// </summary>
        /// <param name="importModules">List of modules that shall be imported. Add required modules here. Each module
        /// will be imported exactly once (even if it occurs more than once in the list).</param>
        /// <param name="env">This is an environment that different tools of the same family may use to exchange information.
        /// This store is typically used to save information on configuration files or thinsgs of that kind that will be
        /// shared among all tools of the same family.</param>
        /// <remarks>A typical use is the import of modules that will be used in the later BOO code that
        /// builds the project.
        /// <code>
        /// void AppendToBooPreamble(System.IO.TextWriter booCodeLines)
        /// {
        ///     booCodeLines.Add("import System.Diagnostics");
        ///     booCodeLines.Add("Process=System.Diagnostics.Process");
        /// }
        /// </code>
        /// </remarks>
        public virtual void AppendToBooPreamble(BuildToolFamilyEnv env, List<string> importModules, List<string> booDeclarations, List<string> booDefinitions)
        {
            importModules.Add("System.Diagnostics");
        }

        /// <summary>
        /// This implementation will look for a program start info that implements this actions.
        /// If program start info is <c>null</c>, this implementation will raise an exception.
        /// Overload this if you have to create another implementation providing this feature.
        /// </summary>
        /// <param name="env">This is an environment that different tools of the same family may use to exchange information.
        /// This store is typically used to save information on configuration files or thinsgs of that kind that will be
        /// shared among all tools of the same family.</param>
        /// <param name="booCodeLines">The code that will actually build something will be appended to this writer.</param>
        /// <param name="indention">A string that shall preceed all created lines. </param>
        /// <exception cref="NotSupportedException">Will be thrown if this feature is not supported.</exception>
        /// <seealso cref="GetProgrammStartInfo"/>
        public virtual void AppendBooCode(List<string> booCodeLines, string indention, BuildToolFamilyEnv env)
        {
            System.Diagnostics.ProcessStartInfo call=this.GetProgramStartInfo(env);
            if (call == null)
                throw new NotSupportedException(string.Format("BOO code creation is not supported by action {0}.", this));
            string args = call.Arguments;
            string replPath = BuildConfig.PathRoot;
            string relPath=".";
            while (replPath != null && replPath.Length > 0)
            {
                args = args.Replace(replPath, relPath);
                replPath = System.IO.Path.GetDirectoryName(replPath);
                if (relPath == ".")
                    relPath = "..";
                else
                    relPath = System.IO.Path.Combine("..", relPath);
            }
            args = args.Replace("\\", "\\\\");
            args = args.Replace("\"", "\\\"");

            string filename = call.FileName;
            filename = filename.Replace("\\", "\\\\");
            filename = filename.Replace("\"", "\\\"");
            booCodeLines.Add(string.Format("{2}System.Diagnostics.Process.Start(\"{0}\", \"{1}\")", filename, args, indention));
        }
        #endregion

        #region Helpers for XML Serialization
        /// <summary>
        /// This will serialize the feature list in an XML element "feature-list".
        /// </summary>
        /// <param name="writer">Destination of serialized data.</param>
        protected void WriteProject(System.Xml.XmlWriter writer)
        {
            if (this._project != null)
                this._project.WriteRefXml(writer);
        }

        /// <summary>
        /// Reads the features as serialized by WriteFeatures(). 
        /// </summary>
        /// <param name="reader">The source of serialized data</param>
        protected void ReadProject(System.Xml.XmlReader reader)
        {
            this._project = null;
            if (reader.IsStartElement("project"))
            {
                RefToProject refToP = new RefToProject();
                refToP.ReadXml(reader);
                this._project=refToP.Project;
            }
        }

        /// <summary>
        /// Helper to serialize objects of unknown class.
        /// This will create an element of the provided element name and attach attributes "assembly" and
        /// "type" to this element. These elements will describe the type of the object to serialize.
        /// Then, embedded into this new element, the object will be asked to place its serialization.
        /// </summary>
        /// <param name="obj">The object that shall be serialized. May be <c>null</c></param>
        /// <param name="elementName">Name of the XML element that will be created.</param>
        /// <param name="writer">The information will be written to this destination.</param>
        /// <remarks>
        /// Use this method to serialize member variables of unknown type like e.g. wx.Build.IFileProducts.
        /// Often, projects refer to members where the only known information is: This implements wx.Build.IFileProducts.
        /// The project does not need to know more facts with one exception: When deserializing a XML serialization,
        /// the project needs to know the exact class because an object instance has to be created.
        /// This method will serialize the corresponding information in such a form, that ReadSerializable()
        /// can be used to read the written instance.
        /// </remarks>
        public static void WriteSerializable(System.Xml.XmlWriter writer, System.Xml.Serialization.IXmlSerializable obj, string elementName)
        {
            if (obj != null)
            {
                writer.WriteStartElement(elementName);
                if (obj.GetType().Assembly != typeof(BuildProject).Assembly)
                    writer.WriteAttributeString("assembly", obj.GetType().Assembly.FullName);
                writer.WriteAttributeString("type", obj.GetType().FullName);
                obj.WriteXml(writer);
                writer.WriteEndElement();
            }
        }

        /// <summary>
        /// This reads a serilization that has been created by WriteSerializable().
        /// This only works if an instance of the serialized obejct can be created without arguments.
        /// </summary>
        /// <param name="reader">The serialization will be read from this source.</param>
        /// <param name="elementName">Name of the XML element that encapsulates the serialization.</param>
        /// <returns>The object instance that has been created from the serialized information.</returns>
        /// <see cref="WriteSerializable"/>
        public static System.Xml.Serialization.IXmlSerializable ReadSerializable(System.Xml.XmlReader reader, string elementName)
        {
            if (reader.IsStartElement(elementName))
            {
                string assemblyName = reader.GetAttribute("assembly");
                System.Reflection.Assembly assembly=typeof(wx.Build.BuildProject).Assembly;
                if (assemblyName != null)
                    assembly=System.Reflection.Assembly.Load(assemblyName);
                System.Type t=assembly.GetType(reader.GetAttribute("type"));
                reader.ReadStartElement();
                System.Xml.Serialization.IXmlSerializable result = (System.Xml.Serialization.IXmlSerializable)Activator.CreateInstance(t);
                result.ReadXml(reader);
                reader.ReadEndElement();
                return result;
            }
            else
                return null;
        }

        /// <summary>
        /// Serializes a collection of serializable objects.
        /// </summary>
        /// <param name="writer">This method will write the serialization to this destination.</param>
        /// <param name="serializables">The collection of object to serialize. All objects must implement System.Xml.Serialization.IXmlSerializable.</param>
        /// <param name="outerElementName">name of the XML element that will embrace all elements.</param>
        /// <param name="innerElementName">Name of the XML element that contains the information of a single serialized object.</param>
        public static void WriteCollectionOfSerializables(System.Xml.XmlWriter writer, System.Collections.IEnumerable serializables, string outerElementName, string innerElementName)
        {
            if (serializables != null)
            {
                writer.WriteStartElement(outerElementName);
                foreach (System.Xml.Serialization.IXmlSerializable obj in serializables)
                {
                    WriteSerializable(writer, obj, innerElementName);
                }
                writer.WriteEndElement();
            }
        }

        /// <summary>
        /// Will be called in ReadCollection() if a new object has been found.
        /// </summary>
        /// <param name="arg">The object that has been found.</param>
        public delegate void AdderSerializable(System.Xml.Serialization.IXmlSerializable arg);

        /// <summary>
        /// Reads a collection of serializable objects from the provided XML source.
        /// </summary>
        /// <param name="reader">XML source</param>
        /// <param name="collectorForResults">This will add the created results to this collection.</param>
        /// <param name="outerElementName">name of the XML element that will embrace all elements.</param>
        /// <param name="innerElementName">Name of the XML element that contains the information of a single serialized object.</param>
        /// <returns>True if the outer element name has been found. False if this has not been able to parse a term
        /// complying with the expected content.</returns>
        public static bool ReadCollection(System.Xml.XmlReader reader, AdderSerializable collectorForResults, string outerElementName, string innerElementName)
        {
            if (reader.IsStartElement(outerElementName))
            {
                reader.ReadStartElement();
                while (reader.IsStartElement(innerElementName))
                {
                    System.Xml.Serialization.IXmlSerializable obj = ReadSerializable(reader, innerElementName);
                    collectorForResults(obj);
                }
                reader.ReadEndElement();
                return true;
            }
            else
                return false;
        }
        #endregion
    }

    /** <summary> This is a string that represents a directory. </summary> */
    public class DirectoryName
    {
        #region State
        string _pathname;
        #endregion

        public DirectoryName(string pathname)
        {
            this._pathname = pathname.Trim();
        }

        public bool Exists
        {
            get
            {
                return System.IO.Directory.Exists(this._pathname);
            }
        }

        public string Pathname
        {
            get
            {
                return this._pathname;
            }
        }

        /** <summary> Returns the combination of this and the argument. </summary> */
        public DirectoryName Combine(DirectoryName appendix)
        {
            return new DirectoryName(System.IO.Path.Combine(this.Pathname, appendix.Pathname));
        }

        public bool IsRoot
        {
            get
            {
                return this._pathname.Length==0
                    || (System.IO.Path.IsPathRooted(this._pathname)
                        && System.IO.Path.GetPathRoot(this._pathname).Equals(this._pathname));
            }
        }

        public bool IsRooted
        {
            get
            {
                return this._pathname.Length==0 || System.IO.Path.IsPathRooted(this._pathname);
            }
        }

        public string Name
        {
            get
            {
                return System.IO.Path.GetFileName(this._pathname);
            }
        }

        /** <summary> Returns the parent of this directory.
        * The parent of the root directory is itself. </summary> */
        public DirectoryName Parent
        {
            get
            {
                if (this.IsRoot)
                    return this;
                else
                    return new DirectoryName(System.IO.Path.GetDirectoryName(this._pathname));
            }
        }
    }

    /** <summary> Often, environment variable contain a semicolon separated list (on unix: colon separated) of directory names. Use this as value type in such cases. </summary> */
    public class DirectoryList
    {
        #region State
        List<DirectoryName> _directories=new List<DirectoryName>();
        #endregion

        #region CTor
        public DirectoryList(string semicolonSeparatedListOfDirectories)
        {
            char separator = ';';
            if (BuildConfig.IsUnix)
                separator = ':';
            string[] vals = semicolonSeparatedListOfDirectories.Split(separator);
            foreach (string val in vals)
            {
                string trimmedVal = val.Trim();
                if (trimmedVal.Length > 0)
                    this._directories.Add(new DirectoryName(trimmedVal));
            }
        }
        #endregion

        #region Properties
        public IList<DirectoryName> Directories { get { return this._directories; } }

        /// <summary>
        /// True iff all contained directories exist.
        /// </summary>
        public bool ExistAll
        {
            get
            {
                foreach (DirectoryName dir in this._directories)
                {
                    if (!dir.Exists)
                        return false;
                }
                return true;
            }
        }
        #endregion
    }

    /** <summary> Instances of this class describle the use of environment variables in IBuildActionClass.
     * Instances of this class appear in IBuildActionClass.UsedVars.
     * They declare the name of an environment variable that is used by a action, provide
     * a text documentation, and a type object. </summary> */
    public class EnvironmentVarInfo : System.Xml.Serialization.IXmlSerializable
    {
        #region State
        string _varname;
        string _description;
        Type _t;

        bool _mandatory = false;
        #endregion

        #region CTor
        /** <summary> Creates an instance.</summary><remarks>
         * \param varname is the name of the environment variable.
         * \param description is a text description.
         * \param t is a supported type object. Values will be converted into this type.
         *        Currently supported types are System.Int32, system.Boolean, System.String, wy.Build.DirectoryName, and enumerations.
         *        This will raise an System.ArgumentException on all incompatible types.
         * \param isMandatory specifies that a valeu of this variable is required in order to produce the targets of those
         *        projects declaring this variable. </remarks> */
        public EnvironmentVarInfo(string varname, string description, Type t, bool isMandatory)
            : this(varname, description, t)
        {
            this._mandatory = isMandatory;
        }

        /** <summary> Creates an instance.</summary><remarks>
         * \param varname is the name of the environment variable.
         * \param description is a text description.
         * \param t is a supported type object. Values will be converted into this type.
         *        Currently supported types are System.Int32, system.Boolean, System.String, wy.Build.DirectoryName, and enumerations.
         *        This will raise an System.ArgumentException on all incompatible types. </remarks> */
        public EnvironmentVarInfo(string varname, string description, Type t)
        {
            this._varname = varname;
            this._description = description;
            if (t == typeof(string)
                || t == typeof(int)
                || t == typeof(DirectoryName)
                || t == typeof(DirectoryList)
                || t == typeof(bool)
                || t == typeof(System.Version)
                || t.IsEnum)
            {
                _t = t;
            }
            else
                throw new ArgumentException("Cannot use "+t.Namespace+"."+t.Name+" as type of an environment variable.");
        }
        #endregion

        #region Events
        public delegate void EventHandler(EnvironmentVarInfo affectedVariable);
        /// <summary>
        /// Will be raised after changing an environment variable using Set().
        /// </summary>
        public static event EventHandler OnEnvVarChanged;
        #endregion

        #region Actions
        /** <summary> Assign <c>valueString </c>  to the represented environment variable.
         * This method will refuse to accept an assignment that cannot be parsed by Get()
         * and raise an exception.
         * </summary>
         */
        public void Set(string valueString)
        {
            Environment.SetEnvironmentVariable(this._varname, valueString);
            this.Get();
            if (EnvironmentVarInfo.OnEnvVarChanged != null)
                EnvironmentVarInfo.OnEnvVarChanged(this);
        }

        /** <summary> Assign <c>valueString </c>  to the represented environment variable.
         * This method will refuse to accept an assignment that cannot be parsed by Get().
         * In that case this will return false and the value of the variable will remain
         * to be the old one.
         * This is exception safe.
         * </summary>
         */
        public bool SafeSet(string valueString)
        {
            string oldValue = Environment.GetEnvironmentVariable(this.Varname);
            Environment.SetEnvironmentVariable(this._varname, valueString);
            try
            {
                this.Get();
                if (EnvironmentVarInfo.OnEnvVarChanged != null)
                    EnvironmentVarInfo.OnEnvVarChanged(this);
                return true;
            }
            catch
            {
                Environment.SetEnvironmentVariable(this._varname, oldValue);
                return false;
            }
        }

        /// <summary>
        /// Assigns the provided value to the environment. The value shall comply with the type
        /// of this variable. If this is not able to parse value after setting, the assignment
        /// will be made undone.
        /// </summary>
        /// <param name="value">The new value of the variable</param>
        public bool SafeSet(object value)
        {
            string original = Environment.GetEnvironmentVariable(this.Varname);
            try
            {
                Environment.SetEnvironmentVariable(this._varname, value.ToString());
                if (!this.Get().Equals(value))
                    new Exception();
            }
            catch
            {
                Environment.SetEnvironmentVariable(this._varname, original);
                return false;
            }
            if (EnvironmentVarInfo.OnEnvVarChanged != null)
                EnvironmentVarInfo.OnEnvVarChanged(this);
            return true;
        }

        /** <summary> Append <c>valueString </c>  to the represented environment variable separated by a semicolon ';' or colon ':' (dependeing on platform). </summary> */
        public void Append(string valueString)
        {
            string separator = ";";
            if (BuildConfig.IsUnix)
                separator = ":";
            string oldVal = Environment.GetEnvironmentVariable(this.Varname);
            oldVal = oldVal.Trim();
            if (oldVal.Length > 0)
                oldVal += separator;
            Environment.SetEnvironmentVariable(this._varname, oldVal+valueString);
            if (EnvironmentVarInfo.OnEnvVarChanged != null)
                EnvironmentVarInfo.OnEnvVarChanged(this);
        }

        /** <summary> True iff this variabel is either not defined or has an empty value.
        * This also works for mandatory variables without exception. </summary> */
        public bool IsEmpty()
        {
            string valString = Environment.GetEnvironmentVariable(this._varname);
            return valString == null || valString.Length == 0;
        }

        /// <summary>
        /// Returns the current value of this variable as string.
        /// Result will be an empty  string (nut <c>null</c>) if the variable is undefined.
        /// </summary>
        public string GetAsString()
        {
            string result = Environment.GetEnvironmentVariable(this._varname);
            if (result == null)
                return "";
            else
                return result;
        }

        /// <summary>
        /// Returns the content of the environment variable.
        /// </summary>
        /// <param name="defaultValue">If the variable is not defined, this value will be returned.</param>
        public object Get(object defaultValue)
        {
            Getter(ref defaultValue);
            return defaultValue;
        }

        /** <summary>Reads the value of this variable.
         * Returns this as instance of \c ValueType.
         * This will return \c null if the variable does not exist unless this is not mandatory.
         * On mandatory variables, this will throw an exception on empty variables,
         * If you want to avoid this exception, run IsEmpty().</summary>
         */
        public object Get()
        {
            object result=null;
            if (Getter(ref result))
                return result;
            else if (this.IsMandatory)
                throw new Exception("Mandatory variable " + this.Varname + " is undefined.");
            else
                return null;
        }

        /// <summary>
        /// Helper for the get-variants.
        /// </summary>
        /// <param name="value">The read value will be assigned to this. If this returns false, the value will remain untouched</param>
        /// <returns>True iff we have found a value. False otherwise.</returns>
        bool Getter(ref object value)
        {
            string valString = Environment.GetEnvironmentVariable(this._varname);
            if (valString == null || valString.Length==0)
            {
                return false;
            }
            if (this._t.IsEnum)
                value= Enum.Parse(this._t, valString);
            else if (this._t.IsAssignableFrom(typeof(int)))
                value= Convert.ToInt32(valString);
            else if (this._t.IsAssignableFrom(typeof(System.Version)))
            {
                value = new Version(valString);
            }
            else if (this._t.IsAssignableFrom(typeof(bool)))
            {
                if (valString.ToLower() == "true")
                    value = true;
                else if (valString.ToLower() == "false")
                    value = false;
                else
                {
                    try
                    {
                        value = Convert.ToInt32(valString) > 0;
                    }
                    catch (FormatException)
                    {
                        value = Convert.ToBoolean(valString);
                    }
                }
            }
            else if (this._t.IsAssignableFrom(typeof(DirectoryName)))
            {
                if (!System.IO.Directory.Exists(valString))
                    throw new System.IO.FileNotFoundException();
                value = new DirectoryName(valString);
            }
            else if (this._t.IsAssignableFrom(typeof(DirectoryList)))
            {
                DirectoryList newVal = new DirectoryList(valString);
                if (newVal.ExistAll)
                    value = newVal;
                else
                    throw new System.IO.FileNotFoundException();
            }
            else
                value = valString;
            return true;
        }
        #endregion

        #region Properties
        public string Varname { get { return this._varname; } }
        public string Description { get { return this._description; } }

        /** <summary> This is the type that will be used in tools parsing the variable value.
         * Supported values are currently <c>string </c> , <c>int </c> , and enumerations. </summary> */
        public Type ValueType { get { return this._t; } }

        /** <summary> True iff this variable needs to have a value in order to enable certain tools.
         * This will, for instance, be true if a tool gets some required path information from
         * a variable. </summary> */
        public bool IsMandatory { get { return this._mandatory; } }
        #endregion

        #region Overrides
        public override bool Equals(object obj)
        {
            if (obj is EnvironmentVarInfo)
            {
                EnvironmentVarInfo arg = (EnvironmentVarInfo)obj;
                return this._varname == arg._varname && this._description == arg._description && this._t == arg._t && this._mandatory==arg._mandatory;
            }
            else
                return false;
        }

        public override int GetHashCode()
        {
            return this._varname.GetHashCode();
        }

        public override string ToString()
        {
            string result = string.Format("{0} : {1}.{2} ({3})", this._varname, this._t.Namespace, this._t.Name, this._description);
            if (this.IsMandatory)
                result += " is mandatory";
            return result;
        }
        #endregion

        #region IXmlSerializable Member
        /// <summary>
        /// Returns <c>null</c> as suggested by the framework doc.
        /// </summary>
        /// <returns></returns>
        public System.Xml.Schema.XmlSchema GetSchema()
        {
            return null;
        }

        public void ReadXml(System.Xml.XmlReader reader)
        {
            reader.ReadStartElement("env-var");
            this._varname = reader.GetAttribute("name");
            System.Reflection.Assembly assembly = typeof(int).Assembly;
            string assemblyName = reader.GetAttribute("assembly");
            if (assemblyName != null)
                assembly = System.Reflection.Assembly.Load(assemblyName);
            this._t=assembly.GetType(reader.GetAttribute("type"));
            reader.MoveToContent();
            this._description = reader.ReadString();
            reader.ReadEndElement();
        }

        public void WriteXml(System.Xml.XmlWriter writer)
        {
            writer.WriteStartElement("env-var");
            writer.WriteAttributeString("name", this._varname);
            if (this._t.Assembly != typeof(int).Assembly)
                writer.WriteAttributeString("assembly", this._t.Assembly.FullName);
            writer.WriteAttributeString("type", this._t.FullName);
            writer.WriteAttributeString("mandatory", this._mandatory.ToString());
            writer.WriteString(this._description);
            writer.WriteEndElement();
        }

        #endregion
    }

    /** <summary>This is a collection of processes.
     * Actions may store processes here to reuse them within the same tool family.
     * This simply is a dictionary using the tool family of a IBuildActionClass as a key.
     * 
     * Side effects between different actions MUST NOT BE FUNCTIONAL. All building actions must also
     * run without sharing this information.
     * </summary>
     */
    public class BuildToolFamilyEnv
    {
        #region State
        Dictionary<string, object> _data = new Dictionary<string, object>();
        #endregion

        #region CTor
        public BuildToolFamilyEnv()
        {
        }
        #endregion

        #region Public Properties
        /** <summary>Store or retrieve data referring to the tool family of \c key.
         * If nothing has been stored for the tool, the result of the <c>get</c>-method will be null (this does not raise an exception).
         * </summary>
         */
        public object this[IBuildActionProvider key]
        {
            get
            {
                if (this._data.ContainsKey(key.ToolFamily))
                    return this._data[key.ToolFamily];
                else
                    return null;
            }
            set
            {
                this._data[key.ToolFamily] = value;
            }
        }

        /** <summary>Store or retrieve data referring to the tool family <c>nameOfToolFamily</c>.
         * If nothing has been stored for the tool, the result of the <c>get</c>-method will be <c>null</c> (this does not raise an exception).
         * </summary>
         */
        public object this[string nameOfToolFamily]
        {
            get
            {
                if (this._data.ContainsKey(nameOfToolFamily))
                    return this._data[nameOfToolFamily];
                else
                    return null;
            }
            set
            {
                this._data[nameOfToolFamily] = value;
            }
        }
        #endregion
    }

    /// <summary>
    /// This class represents a collection of alternative build actions.
    /// Executing this collections means: Executing one of the mostly preferred actions. However, if this action fails
    /// at runtime, one of the next preferred actions will be tried.
    /// You may associate this alternative with a name. This serves as a hint in user guided building system.
    /// In such implementations of the build process, the user will be confronted with the name and
    /// a description of the avilable alternatives and asked for a decision.
    /// Alternatives without a name will not offer interactive services.
    /// </summary>
    public class AlternativeBuildActions : IBuildAction
    {
        #region State
        string _name;
        IBuildProduct _target;
        CollectionOfBuildActions _alternatives = new CollectionOfBuildActions();
        int _instance;

        static int _noOfInstance = 0;
        #endregion

        #region CTor
        /// <summary>
        /// Creates an instance containing those actions in <c>alternatives </c>  achieving <c>target</c> but
        /// without a name. Thus, interactive services cannot be provided.
        /// </summary>
        /// <param name="target">The target that will be achieved by each of the contained actions. Some actions my achieve
        /// additional or more spevific targets. But this target will be achieved by all contained alternative actions.</param>
        /// <param name="alternatives">A collection of alternative actions sorted by priority. Please note, that
        /// instances of NamedAction will be used to associate an alternative with a name.</param>
        public AlternativeBuildActions(IBuildProduct target, CollectionOfBuildActions alternatives)
            : this("", target, alternatives)
        {
        }

        /// <summary>
        /// Creates an instance containing those actions in <c>alternatives </c>  achieving <c>target</c> .
        /// </summary>
        /// <param name="name">This shall be a spelling name designating the choice among the available alternatives.
        /// For instance, a C/C++ project supporting various compilers and linkers may produce alternatives
        /// for each supported compiler/linker. The choice among this alternatives could be something like "CCppCompiler".
        /// Different alternatives may share the same name. However, in that case the alternatives should be
        /// named consistently (refer to NamedAction). This property is currently used e.g. to produce BOO code.</param>
        /// <param name="target">The target that will be achieved by each of the contained actions. Some actions my achieve
        /// additional or more spevific targets. But this target will be achieved by all contained alternative actions.</param>
        /// <param name="alternatives">A collection of alternative actions sorted by priority. Please note, that
        /// instances of NamedAction will be used to associate an alternative with a name.</param>
        public AlternativeBuildActions(string name, IBuildProduct target, CollectionOfBuildActions alternatives)
        {
            this._instance = _noOfInstance++;
            this._name = name;
            this._target = target;
            foreach (ActionPriority p in Enum.GetValues(typeof(ActionPriority)))
            {
                ICollection<IBuildAction> actions = alternatives[p];
                if (actions != null)
                {
                    foreach (IBuildAction action in actions)
                        if (action.GetTargets().Contains(this._target))
                            this._alternatives.Add(p, action);
                }
            }
        }
        #endregion

        #region Public Properties
        /** <summary> Index of the instance.
        * This will be used to create unique name. This will NOT be used to determine whether 2 actions are equivalent. </summary> */
        public int NoOfInstance { get { return this._instance; } }
        #endregion

        #region IBuildAction Member

        public IBuildActionProvider ActionProvider
        {
            get { throw new Exception("A collection of alternative actions is not created by a provider."); }
        }

        /// <summary>
        /// This shall be a spelling name designating the choice among the available alternatives.
        /// For instance, a C/C++ project supporting various compilers and linkers may produce alternatives
        /// for each supported compiler/linker. The choice among this alternatives could be something like "CCppCompiler".
        /// Different alternatives may share the same name. However, in that case the alternatives should be
        /// named consistently (refer to NamedAction). This property is currently used e.g. to produce BOO code.
        /// 
        /// This can be empty of this alternative is not named.
        /// </summary>
        public string Name
        {
            get
            {
                if (this._name == null || this._name.Length == 0)
                {
                    StringBuilder result = new StringBuilder();
                    int index = 0;
                    foreach (IBuildAction action in this._alternatives)
                    {
                        if (index > 2)
                        {
                            result.Append("..");
                            break;
                        }
                        if (index > 0)
                            result.Append("|");
                        result.Append(action.Name);
                        ++index;
                    }
                    result.Append("#");
                    result.Append(this._instance.ToString());
                    return result.ToString();
                }
                else
                    return this._name;
            }
        }

        /** <summary> All features of a contained action. </summary> */
        public FeatureList Features
        {
            get
            {
                FeatureList result = new FeatureList();
                foreach (IBuildAction action in this._alternatives)
                {
                    result.AddRange(action.Features);
                }
                return result;
            }
        }

        /// <summary>
        /// This will read the project from the alternatives. The setter is a NOP.
        /// </summary>
        public BuildProject Project
        {
            get
            {
                foreach (IBuildAction action in this._alternatives)
                    if (action.Project != null)
                        return action.Project;
                return null;
            }
            set { }
        }

        public ICollection<Type> ParameterTypes
        {
            get
            {
                return null;
            }
        }

        /** <summary> Collection of all prerequisites of all contained actions.
         * Note: Do not use this on rebuild to determine whether to start this or not.
         * You may omit this on rebuild of the target is consistent with the prerequisite of at least ONE
         * contained action, not ALL. TargetsAreConsistent() observes this. </summary> */
        public ICollection<IBuildProduct> GetPrerequisites()
        {
            SortedDictionary<IBuildProduct,IBuildProduct> result = new SortedDictionary<IBuildProduct,IBuildProduct>();
            foreach (IBuildAction action in this._alternatives)
                foreach (IBuildProduct prereq in action.GetPrerequisites())
                    result[prereq]= prereq;
            return result.Values;
        }

        public bool ContainsPrerequisite(IBuildProduct prereq)
        {
            foreach (IBuildAction action in this._alternatives)
            {
                if (action.ContainsPrerequisite(prereq))
                    return true;
            }
            return false;
        }

        /** <summary> This returns <c>true </c>  if at least one contained action is consistent.</summary><remarks>
         * \param validityOfBuildSystem indicates the last change of either this DLL or the assembly defining the project.
         *  So, all action will be repeated (even if rebuild is specified) if the project definition changes or the implementation
         *  of the build system has been enhanced since the final build. This argument will be computed and propagated by
         * the project. </remarks> */
        public virtual bool TargetsAreConsistent(DateTime validityOfBuildSystem)
        {
            foreach (IBuildAction action in this._alternatives)
            {
                if (action.TargetsAreConsistent(validityOfBuildSystem))
                    return true;
            }
            return false;
        }

        /** <summary> This returns the most important included priority. </summary> */
        public ActionPriority Priority
        {
            get
            {
                return this._alternatives.MostImportantPriority;
            }
        }

        /// <summary>
        /// This method collects all choice points within this action. Choice points are represented by a name and a
        /// collection of alternatives. 
        /// </summary>
        /// <param name="collectionOfChoicePoints">The collection that will be extended by the choice points
        /// of this action. </param>
        /// <example>
        /// The current implementation provides a choice point for the compilation and linking of C/C++
        /// programs, "CppDevelopmentSystem" of the alternatives "GCC" and "MS VC". Thus, actions on C/C++
        /// compilation will add the following choice point:
        /// <code>
        /// if (!collectionOfChoicePoints.ContainsKey("CppDevelopmentSystem"))
        ///     collectionOfChoicePoints.Add("CppDevelopmentSystem", new List&lt;string&gt;());
        /// collectionOfChoicePoints["CppDevelopmentSystem"].Add("GCC");
        /// collectionOfChoicePoints["CppDevelopmentSystem"].Add("MS VC");
        /// </code>
        /// </example>
        public void CollectChoicePoints(IDictionary<string, ICollection<string>> collectionOfChoicePoints)
        {
            foreach (IBuildAction action in this._alternatives.GetActions())
                action.CollectChoicePoints(collectionOfChoicePoints);
            if (this._name != null && this._name.Length > 0)
            {
                if (!collectionOfChoicePoints.ContainsKey(this._name))
                    collectionOfChoicePoints.Add(this._name, new List<string>());
                foreach (IBuildAction action in this._alternatives.GetActions())
                    collectionOfChoicePoints[this._name].Add(action.Name);
            }
        }

        /// <summary>
        /// This method will create BOO source code and append this code to the provided text writer.
        /// </summary>
        /// <param name="env">This is an environment that different tools of the same family may use to exchange information.
        /// This store is typically used to save information on configuration files or thinsgs of that kind that will be
        /// shared among all tools of the same family.</param>
        /// <param name="booCodeLines">The code that will actually build something. Each list entry will be a line of code in the resulting
        /// BOO program.</param>
        /// <param name="indention">A string that shall preceed all created lines. </param>
        /// <remarks>Refer to IBuildActionProvider.AppendToBooPreamble() for an example.
        /// 
        /// This implementation will only provide
        /// </remarks>
        /// <exception cref="NotSupportedException">Will be thrown if this feature is not supported.</exception>
        public void AppendBooCode(List<string> booCodeLines, string indention, BuildToolFamilyEnv env)
        {
            if (this._name != null && this._name.Length > 0 && this._alternatives.Count > 1)
            {
                booCodeLines.Add(string.Format("{1}print \"Choices for alternative \\\"{0}\\\".\"", this._name, indention));
                IBuildAction defaultAction = null;
                bool firstAlternative = true;
                foreach (IBuildAction action in this._alternatives)
                {
                    if (defaultAction == null)
                        defaultAction = action;
                    else
                    {
                        string conditional = "elif";
                        if (firstAlternative)
                            conditional = "if";
                        booCodeLines.Add(string.Format("{2}{3} {0} == \"{1}\":", this._name, action.Name, indention, conditional));
                        try
                        {
                            if (!(action is NamedAction))
                                booCodeLines.Add(string.Format("{0}\tprint 'Executing {1}'", indention, action.Name));
                            action.AppendBooCode(booCodeLines, indention + "\t", env);
                        }
                        catch (Exception exc)
                        {
                            booCodeLines.Add(string.Format("{1}\tprint \"Caught exception creating code for action {0}.\"", action.Name.Replace("\"", "\\\""), indention));
                            booCodeLines.Add(string.Format("{1}\tprint \"{0}\"", exc.Message.Replace("\"", "\\\""), indention));
                            BuildConfig.HandleErrorObject(ErrorObject.MessageType.Warning, "Caught exception creating code for action {0}: {1}.", action.Name, exc.Message);
                        }
                        firstAlternative = false;
                    }
                }
                booCodeLines.Add(string.Format("{0}else: # {1} == \"{2}\"", indention, this._name, defaultAction.Name));
                try
                {
                    if (!(defaultAction is NamedAction))
                        booCodeLines.Add(string.Format("{0}\tprint 'Executing {1}'", indention, defaultAction.Name));
                    defaultAction.AppendBooCode(booCodeLines, indention + "\t", env);
                }
                catch (Exception exc)
                {
                    booCodeLines.Add(string.Format("{1}\tprint \"Caught exception creating code for action {0}.\"", defaultAction.Name.Replace("\"", "\\\""), indention));
                    booCodeLines.Add(string.Format("{1}\tprint \"{0}\"", exc.Message.Replace("\"", "\\\""), indention));
                    BuildConfig.HandleErrorObject(ErrorObject.MessageType.Warning, "Caught exception creating code for action {0}: {1}.", defaultAction.Name, exc.Message);
                }
            }
            else
            {
                this._alternatives.GetOneAction().AppendBooCode(booCodeLines, indention, env);
            }
        }
        #endregion
        
        #region IBuildProduct Member
        /** <summary> This returns only the target passed to the CTor.
         * All other targets are considered to be optional. They may be achieved if the corresponding action is taken.
         * They may be missed on choosing different alternatives. </summary> */
        public ICollection<IBuildProduct> GetTargets()
        {
            return new IBuildProduct[] { this._target };
        }

        /** <summary> This returns <c>null </c>  because this does not imply build projects. </summary> */
        public ICollection<RefToProject> GetProjects()
        {
            return null;
        }

        /** <summary> Returns <c>null </c>  since this will not use the process class on execution. </summary> */
        public System.Diagnostics.ProcessStartInfo GetProgramStartInfo(BuildToolFamilyEnv env)
        {
            return null;
        }

        /** <summary> Execute the actions in the order of their priority and stop after first success.
         * On rebuiding test whether targets are consistent. Do nothing, if consistent. </summary> */
        public bool Execute(BuildToolFamilyEnv env, DateTime validityOfBuildSystem)
        {
            if (BuildConfig.GetConfig().Mode == BuildMode.BuildMissingTargets && this.TargetsAreConsistent(BuildProject.ValidityOfExecutingAssembly))
                return true;
            foreach (IBuildAction action in this._alternatives)
            {
                IDictionary<string, EnvironmentVarInfo> usedVars = action.UsedVars;
                if (usedVars != null)
                    foreach (EnvironmentVarInfo vi in usedVars.Values)
                        if (vi.IsMandatory && vi.IsEmpty())
                            continue;
                BuildConfig.OpenBuildActionSectionInXmlLogFile(action, false);
                try
                {
                    BuildConfig.HandleErrorObject(ErrorObject.MessageType.Message, "Executing {0}...", action.Name, this.Target);
                    bool result = action.Execute(env, validityOfBuildSystem);
                    if (result)
                        return true;
                    BuildConfig.HandleErrorObject(ErrorObject.MessageType.Message, "Action {0} failed. Looking for next option.", action.Name);
                }
                finally
                {
                    BuildConfig.CloseSectionInXmlLogFile();
                }
            }
            return false;
        }

        /** <summary> All variables used by at least one contained action.
        * If a variable is mandatory for one action but not required by another, the
        * result will state that the variable is not required. </summary> */
        public IDictionary<string, EnvironmentVarInfo> UsedVars
        {
            get
            {
                Dictionary<string, EnvironmentVarInfo> result = new Dictionary<string, EnvironmentVarInfo>();
                foreach (IBuildAction action in this._alternatives)
                {
                    if (action.UsedVars != null)
                    {
                        foreach (EnvironmentVarInfo vi in action.UsedVars.Values)
                            if (!vi.IsMandatory || !result.ContainsKey(vi.Varname))
                                result[vi.Varname] = vi;
                    }
                }
                return result;
            }
        }
        #endregion

        #region IBuildProduct Member

        /** <summary> The latest validity of a contained action. </summary> */
        public DateTime GetValidity()
        {
            DateTime result = DateTime.MinValue;
            foreach (IBuildAction action in this._alternatives)
            {
                DateTime actionValidity = action.GetValidity();
                if (actionValidity > result)
                {
                    result = actionValidity;
                    if (result == DateTime.MaxValue)
                        break;
                }
            }
            return result;
        }

        /** <summary> The latest validity of a contained action. </summary> */
        public DateTime GetValidityDemand()
        {
            DateTime result = DateTime.MinValue;
            foreach (IBuildAction action in this._alternatives)
            {
                DateTime actionValidity = action.GetValidityDemand();
                if (actionValidity > result)
                {
                    result = actionValidity;
                    if (result == DateTime.MaxValue)
                        break;
                }
            }
            return result;
        }

        #endregion

        #region Properties
        /** <summary> The only target of this combined action. </summary> */
        public IBuildProduct Target { get { return this._target; } }

        /** <summary> The collection of alternative actions that may be used to achieve the target. </summary> */
        public CollectionOfBuildActions Alternatives { get { return this._alternatives; } }
        #endregion
    }

    /** <summary> A sequence of build actions is a build action itself but also a list of build actions.
     * The list contains the actions in the order that shall be used for execution.
     * 
     * Sequences do not have a provider. They result from projects.
     * 
     * Instances of this class may be made read-only. In that case, all modifiers will cause
     * exceptions. </summary> */
    public class SequenceOfBuildActions : IBuildAction, IList<IBuildAction>, ICloneable
    {
        #region State
        List<IBuildAction> _actions = new List<IBuildAction>();
        bool _isReadOnly = false;
        int _instance;

        static int _noOfInstances=0;
        #endregion

        #region CTor
        public SequenceOfBuildActions(params IBuildAction[] actions)
        {
            this._instance = _noOfInstances++;
            if (actions != null)
                foreach(IBuildAction action in actions)
                    this._actions.Add(action);
        }

        /// <summary>
        /// Copy-CTor
        /// </summary>
        /// <param name="src">The source whose contents will be copied.</param>
        public SequenceOfBuildActions(SequenceOfBuildActions src)
        {
            this._instance = _noOfInstances++;
            foreach (IBuildAction action in src._actions)
                this._actions.Add(action);
        }
        #endregion 
    
        #region Public Properties
        /** <summary> Index of the instance.
        * This will be used to create unique name. This will NOT be used to determine whether 2 actions are equivalent. </summary> */
        public int NoOfInstance { get { return this._instance; } }
        #endregion

        #region IBuildAction Member

        public IBuildActionProvider ActionProvider
        {
            get { throw new NotSupportedException("Sequences of build actions do not have a provider."); }
        }

        public string Name
        {
            get
            {
                StringBuilder result=new StringBuilder();
                int index=0;
                foreach (IBuildAction action in this._actions)
                {
                    if (index > 2)
                    {
                        result.Append("..");
                        break;
                    }
                    if (index > 0)
                        result.Append(";");
                    result.Append(action.Name);
                    ++index;
                }
                result.Append("#");
                result.Append(this._instance.ToString());
                return result.ToString();
            }
        }

        public FeatureList Features
        {
            get
            {
                FeatureList result = new FeatureList();
                foreach (IBuildAction action in this._actions)
                {
                    result.AddRange(action.Features);
                }
                return result;
            }
        }

        /// <summary>
        /// This getter will return the first encountered project of a contained action.
        /// The setter is a NOP.
        /// </summary>
        public BuildProject Project
        {
            set { }
            get
            {
                foreach (IBuildAction action in this._actions)
                    if (action.Project != null)
                        return action.Project;
                return null;
            }
        }

        public ICollection<Type> ParameterTypes
        {
            get
            {
                return null;
            }
        }

        public ICollection<IBuildProduct> GetPrerequisites()
        {
            Dictionary<IBuildProduct,IBuildProduct> result=new Dictionary<IBuildProduct,IBuildProduct>();
            Dictionary<IBuildProduct, IBuildProduct> intermediateTargets = new Dictionary<IBuildProduct, IBuildProduct>();
            foreach (IBuildAction action in this._actions)
            {
                foreach (IBuildProduct prereq in action.GetPrerequisites())
                {
                    if (!intermediateTargets.ContainsKey(prereq))
                        result[prereq]=prereq;
                }
                foreach (IBuildProduct target in action.GetTargets())
                    intermediateTargets[target]=target;
            }
            return result.Values;
        }

        public bool ContainsPrerequisite(IBuildProduct prereq)
        {
            foreach (IBuildAction action in this._actions)
            {
                if (action.ContainsPrerequisite(prereq))
                    return true;
                foreach (IBuildProduct target in action.GetTargets())
                    if (target == prereq)
                        return false;
            }
            return false;
        }

        /** <summary> Checks whether all contained actions are consistent.</summary><remarks>
         * \param validityOfBuildSystem indicates the last change of either this DLL or the assembly defining the project.
         *  So, all action will be repeated (even if rebuild is specified) if the project definition changes or the implementation
         *  of the build system has been enhanced since the final build. This argument will be computed and propagated by
         * the project. </remarks> */
        public bool TargetsAreConsistent(DateTime validityOfBuildSystem)
        {
            foreach (IBuildAction action in this._actions)
            {
                if (!action.TargetsAreConsistent(validityOfBuildSystem))
                    return false;
            }
            return true;
        }

        /** <summary> The least important priority of a contained action. </summary> */
        public ActionPriority Priority
        {
            get
            {
                ActionPriority result = ActionPriority.PreferredByUserInput;
                foreach (IBuildAction action in this._actions)
                {
                    if (action.Priority < result)
                        result = action.Priority;
                }
                return result;
            }
        }


        /// <summary>
        /// This method collects all choice points within this action. Choice points are represented by a name and a
        /// collection of alternatives. 
        /// </summary>
        /// <param name="collectionOfChoicePoints">The collection that will be extended by the choice points
        /// of this action. </param>
        /// <example>
        /// The current implementation provides a choice point for the compilation and linking of C/C++
        /// programs, "CppDevelopmentSystem" of the alternatives "GCC" and "MS VC". Thus, actions on C/C++
        /// compilation will add the following choice point:
        /// <code>
        /// if (!collectionOfChoicePoints.ContainsKey("CppDevelopmentSystem"))
        ///     collectionOfChoicePoints.Add("CppDevelopmentSystem", new List&lt;string&gt;());
        /// collectionOfChoicePoints["CppDevelopmentSystem"].Add("GCC");
        /// collectionOfChoicePoints["CppDevelopmentSystem"].Add("MS VC");
        /// </code>
        /// </example>
        public void CollectChoicePoints(IDictionary<string, ICollection<string>> collectionOfChoicePoints)
        {
            foreach (IBuildAction action in this._actions)
                action.CollectChoicePoints(collectionOfChoicePoints);
        }
        #endregion

        #region IBuildProduct Member

        /** <summary> The collection of all targets of contained actions. </summary> */
        public ICollection<IBuildProduct> GetTargets()
        {
            List<IBuildProduct> result = new List<IBuildProduct>();
            foreach (IBuildAction action in this._actions)
                result.AddRange(action.GetTargets());
            return result;
        }

        /** <summary> This returns <c>null </c>  because this does not imply build projects. </summary> */
        public ICollection<RefToProject> GetProjects()
        {
            return null;
        }

        /** <summary> All variables used by at least one contained action.
        * If a variable is mandatory for one action but not required by another, the
        * result will state that the variable is also mandatory for this action. </summary> */
        public IDictionary<string, EnvironmentVarInfo> UsedVars
        {
            get
            {
                Dictionary<string, EnvironmentVarInfo> result = new Dictionary<string, EnvironmentVarInfo>();
                foreach (IBuildAction action in this._actions)
                {
                    if (action.UsedVars != null)
                    {
                        foreach (EnvironmentVarInfo vi in action.UsedVars.Values)
                            if (vi.IsMandatory || !result.ContainsKey(vi.Varname))
                                result[vi.Varname] = vi;
                    }
                }
                return result;
            }
        }


        /** <summary> Returns <c>null </c>  since this will not use the process class on execution. </summary> */
        public System.Diagnostics.ProcessStartInfo GetProgramStartInfo(BuildToolFamilyEnv env)
        {
            return null;
        }

        /** <summary> Execute all actions in the provided order.
         * If BuildConfig.Mode of the current configuration is BuildMode.Rebuild, this
         * will omitt all actions of consistent targets. </summary> */
        public bool Execute(BuildToolFamilyEnv env, DateTime validityOfBuildSystem)
        {
            bool buildNew = BuildConfig.GetConfig().Mode != BuildMode.BuildMissingTargets;
            foreach (IBuildAction action in this._actions)
            {
                if (buildNew || !action.TargetsAreConsistent(BuildProject.ValidityOfExecutingAssembly))
                {
                    bool result = false;
                    try
                    {
                        BuildConfig.OpenBuildActionSectionInXmlLogFile(action, false);
                        result = action.Execute(env, validityOfBuildSystem);
                    }
                    finally
                    {
                        BuildConfig.CloseSectionInXmlLogFile();
                    }
                    if (!result)
                    {
                        BuildConfig.HandleErrorObject(ErrorObject.MessageType.Error, "Action {0} failed in sequence.", action.Name);
                        return false;
                    }
                }
            }
            return true;
        }

        /** <summary> The earliest validity of a contained action. </summary> */
        public DateTime GetValidity()
        {
            DateTime result = DateTime.MaxValue;
            foreach (IBuildAction action in this._actions)
            {
                DateTime actionValidity = action.GetValidity();
                if (actionValidity < result)
                {
                    result = actionValidity;
                    if (result == DateTime.MinValue)
                        break;
                }
            }
            return result;
        }

        /** <summary> The latest validity of a contained action. </summary> */
        public DateTime GetValidityDemand()
        {
            DateTime result = DateTime.MinValue;
            foreach (IBuildAction action in this._actions)
            {
                DateTime actionValidity = action.GetValidityDemand();
                if (actionValidity > result)
                {
                    result = actionValidity;
                    if (result == DateTime.MaxValue)
                        break;
                }
            }
            return result;
        }
        #endregion

        #region IList<IBuildAction> Member
        public int IndexOf(IBuildAction item)
        {
            return this._actions.IndexOf(item);
        }

        public void Insert(int index, IBuildAction item)
        {
            if (this.IsReadOnly)
                throw new ApplicationException("Do not call modifiers on readonly collections.");
            this._actions.Insert(index, item);
        }

        public void RemoveAt(int index)
        {
            if (this.IsReadOnly)
                throw new ApplicationException("Do not call modifiers on readonly collections.");
            this._actions.RemoveAt(index);
        }

        public IBuildAction this[int index]
        {
            get
            {
                return this._actions[index];
            }
            set
            {
                if (this.IsReadOnly)
                    throw new ApplicationException("Do not call modifiers on readonly collections.");
                this._actions[index] = value;
            }
        }

        /// <summary>
        /// This method will create BOO source code and append this code to the provided text writer.
        /// </summary>
        /// <param name="env">This is an environment that different tools of the same family may use to exchange information.
        /// This store is typically used to save information on configuration files or thinsgs of that kind that will be
        /// shared among all tools of the same family.</param>
        /// <param name="booCode">The code that will actually build something. Each list entry will be a line of code in the resulting
        /// BOO program.</param>
        /// <param name="indention">A string that shall preceed all created lines. </param>
        /// <remarks>Refer to IBuildActionProvider.AppendToBooPreamble() for an example.</remarks>
        /// <exception cref="NotSupportedException">Will be thrown if this feature is not supported.</exception>
        public void AppendBooCode(List<string> booCodeLines, string indention, BuildToolFamilyEnv env)
        {
            foreach (IBuildAction action in this._actions)
            {
                action.AppendBooCode(booCodeLines, indention, env);
            }
        }
        #endregion

        #region ICollection<IBuildAction> Member
        /** <summary> Adds a new action at the end of the sequence. </summary> */
        public void Add(IBuildAction item)
        {
            if (this.IsReadOnly)
                throw new ApplicationException("Do not call modifiers on readonly collections.");
            if (item == null)
            {
                // do nothing
            }
            else if (item is SequenceOfBuildActions)
            {
                foreach (IBuildAction singleAction in ((SequenceOfBuildActions)item))
                    this._actions.Add(singleAction);
            }
            else
                this._actions.Add(item);
        }

        /** <summary> Adds a new action at the beginning of the sequence.
        * Use this method if you have to add an action in order to build one of the prerequisites required
        * by already contained actions. </summary> */
        public void AddFront(IBuildAction item)
        {
            if (this.IsReadOnly)
                throw new ApplicationException("Do not call modifiers on readonly collections.");
            if (item == null)
            {
               // do nothing
            }
            else if (item is SequenceOfBuildActions)
            {
                int pos = 0;
                foreach (IBuildAction singleAction in ((SequenceOfBuildActions)item))
                {
                    this._actions.Insert(pos, singleAction);
                    pos += 1;
                }
            }
            else
                this._actions.Insert(0, item);
        }

        public void Clear()
        {
            if (this.IsReadOnly)
                throw new ApplicationException("Do not call modifiers on readonly collections.");
            this._actions.Clear();
        }

        public bool Contains(IBuildAction item)
        {
            return this._actions.Contains(item);
        }

        public void CopyTo(IBuildAction[] array, int arrayIndex)
        {
            this._actions.CopyTo(array, arrayIndex);
        }

        public int Count
        {
            get { return this._actions.Count; }
        }

        /** <summary> Makes this read-only.
         * As a consequence, all modifiers will raise exceptions. </summary> */
        public void SetReadOnly()
        {
            this._isReadOnly = true;
        }

        /** <summary> Returns <c>true </c>  iff this has been made read-only (by MakeReadOnly()). </summary> */
        public bool IsReadOnly
        {
            get { return this._isReadOnly; }
        }

        public bool Remove(IBuildAction item)
        {
            if (this.IsReadOnly)
                throw new ApplicationException("Do not call modifiers on readonly collections.");
            return this._actions.Remove(item);
        }

        #endregion

        #region IEnumerable<IBuildAction> Member

        public IEnumerator<IBuildAction> GetEnumerator()
        {
            return this._actions.GetEnumerator();
        }

        #endregion

        #region IEnumerable Member

        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            return this._actions.GetEnumerator();
        }

        #endregion

        #region ICloneable Member
        /// <summary>
        /// Returns new instance that is a copy (contains all actions).
        /// </summary>
        public object Clone()
        {
            return new SequenceOfBuildActions(this);
        }

        #endregion
    }

    /// <summary>
    /// This class of actions simply associates an action with a name.
    /// This name will be printed in the log file on execution.
    /// This may be especially useful in conjunction with collections of build actions and
    /// BOO code creation: Collections provide BOO code enabling to define the actually
    /// chosen alternative action providing the name.
    /// </summary>
    /// <example>
    /// <code>
    /// CollectionOfBuildActions alternativeActions=new CollectionOfBuildActions();
    /// alternativeActions.Add(new NamedAction("option 1", ...));
    /// alternativeActions.Add(new NamedAction("option 2", ...));
    /// AlternativeBuildActions alternatives=new AlternativeBuildActions("choice", target, alternativeActions); 
    /// </code>
    /// This will result into the following BOO code when running <c>alternatives.AppendBooCode(..)</c>:
    /// <code>
    /// alternatives=new System.Collection.Generic.
    /// </code>
    /// </example>
    public class NamedAction : IBuildAction
    {
        #region State
        string _name;
        IBuildAction _action;
        #endregion

        #region CTor
        public NamedAction(string name, IBuildAction action)
        {
            this._action = action;
            this._name = name;
        }
        #endregion

        #region Properties
        /// <summary>
        /// The name of the action.
        /// </summary>
        public string Name { get { return this._name; } }

        /** <summary> This returns <c>null </c>  since useually shell variables are not used by actions. </summary> */
        public IDictionary<string, EnvironmentVarInfo> UsedVars { get { return null; } }


        /// <summary>
        /// This is the action that will actually be executed.
        /// </summary>
        public IBuildAction Action { get { return this._action; } }
        #endregion

        #region IBuildAction Member
        /// <summary>
        /// This action is created directly using the CTor.
        /// </summary>
        public IBuildActionProvider ActionProvider
        {
            get { return null; }
        }

        /// <summary>
        /// the features of the contained action are my features.
        /// </summary>
        public FeatureList Features
        {
            get { return this._action.Features; }
        }

        /// <summary>
        /// The getter returns the project of the encapsulated action. the setter is a NOP.
        /// </summary>
        public BuildProject Project
        {
            set { }
            get
            {
                return this._action.Project;
            }
        }

        public ICollection<IBuildProduct> GetPrerequisites()
        {
            return this._action.GetPrerequisites();
        }

        public bool ContainsPrerequisite(IBuildProduct prereq)
        {
            return this._action.ContainsPrerequisite(prereq);
        }

        public bool TargetsAreConsistent(DateTime validityOfBuildSystem)
        {
            return this._action.TargetsAreConsistent(validityOfBuildSystem);
        }

        public ActionPriority Priority
        {
            get { return this._action.Priority; }
        }

        public ICollection<Type> ParameterTypes
        {
            get { return null; }
        }

        public ICollection<IBuildProduct> GetTargets()
        {
            return this._action.GetTargets();
        }


        /// <summary>
        /// This method collects all choice points within this action. Choice points are represented by a name and a
        /// collection of alternatives. 
        /// </summary>
        /// <param name="collectionOfChoicePoints">The collection that will be extended by the choice points
        /// of this action. </param>
        /// <example>
        /// The current implementation provides a choice point for the compilation and linking of C/C++
        /// programs, "CppDevelopmentSystem" of the alternatives "GCC" and "MS VC". Thus, actions on C/C++
        /// compilation will add the following choice point:
        /// <code>
        /// if (!collectionOfChoicePoints.ContainsKey("CppDevelopmentSystem"))
        ///     collectionOfChoicePoints.Add("CppDevelopmentSystem", new List&lt;string&gt;());
        /// collectionOfChoicePoints["CppDevelopmentSystem"].Add("GCC");
        /// collectionOfChoicePoints["CppDevelopmentSystem"].Add("MS VC");
        /// </code>
        /// </example>
        public void CollectChoicePoints(IDictionary<string, ICollection<string>> collectionOfChoicePoints)
        {
            this._action.CollectChoicePoints(collectionOfChoicePoints);
        }

        public System.Diagnostics.ProcessStartInfo GetProgramStartInfo(BuildToolFamilyEnv env)
        {
            return null;
        }

        public bool Execute(BuildToolFamilyEnv env, DateTime validityOfBuildSystem)
        {
            BuildConfig.HandleMessageObject("Enter \"{0}\" to build \"{1}\".", this._name, this.GetTargets());
            bool result = this._action.Execute(env, validityOfBuildSystem);
            BuildConfig.HandleMessageObject("Leave \"{0}\".", this._name);
            return result;
        }

        public void AppendBooCode(List<string> booCodeLines, string indention, BuildToolFamilyEnv env)
        {
            booCodeLines.Add(string.Format("{1}print \"Enter {0}\"", this._name, indention));
            this._action.AppendBooCode(booCodeLines, indention, env);
            booCodeLines.Add(string.Format("{1}print \"Leave {0}\"", this._name, indention));
        }

        #endregion

        #region IBuildObject Member

        public DateTime GetValidity()
        {
            return this._action.GetValidity();
        }

        public DateTime GetValidityDemand()
        {
            return this._action.GetValidityDemand();
        }

        #endregion
    }

    /** <summary> This is a collection of actions sorted by priority. </summary> */
    public class CollectionOfBuildActions : ICollection<IBuildAction>, IEnumerable<IBuildAction>
    {
        #region State
        SortedList<ActionPriority, List<IBuildAction>> _data = new SortedList<ActionPriority, List<IBuildAction>>();
        bool _readonly = false;
        SortedDictionary<IBuildProduct, IBuildProduct> _prerequisites = null;
        #endregion

        #region CTor
        public CollectionOfBuildActions()
        {
        }
        #endregion

        #region public Methods
        /// <summary>
        /// This is a collection of priorities that this instance actially maps to at least one action.
        /// The priorities will be sorted. So, you may use this method in cooperation with the indexer
        /// to enumerate all actions w.r.t. their assigned priority.
        /// </summary>
        /// <example>
        /// <code>
        /// CollectionOfBuildActions c=...;
        /// foreach(ActionPriority p in c.ActionPriorities)
        ///    foreach(IBuildAction action in c[0])
        ///       System.Console.WriteLine("Action {0} has priority {1}.", action.Name, p);
        /// </code>
        /// </example>
        public ICollection<ActionPriority> ActionPriorities
        {
            get
            {
                return this._data.Keys;
            }
        }

        /** <summary>Returns the collection of actions stored for the secified priority.
         * Return <c>null</c> if this does not hold an action of this priority.</summary>
         * <seealso cref="ActionPriorities"/>
         */
        public ICollection<IBuildAction> this[ActionPriority p]
        {
            get
            {
                if (this._data.ContainsKey(p))
                    return this._data[p];
                else
                    return null;
            }
        }

        /** <summary>Returns the most important priority of a contained action.
         * If this is empty, the result is ActionPriority.Fallback.</summary>
         */
        public ActionPriority MostImportantPriority
        {
            get
            {
                if (this._data.Count == 0)
                    return ActionPriority.Fallback;
                else
                    return this._data.Keys[0];
            }
        }

        /** <summary>Returns the least important priority of a contained action.
         * If this is empty, the result is ActionPriority.PreferredByUserInput.</summary>
         */
        public ActionPriority LeastImportantPriority
        {
            get
            {
                if (this._data.Count == 0)
                    return ActionPriority.PreferredByUserInput;
                else
                    return this._data.Keys[this._data.Count - 1];
            }
        }

        /** <summary>After calling this method all modifiers will throw an exception.</summary>
         */
        public void SetReadOnly()
        {
            this._readonly = true;
        }

        /** <summary>Returns a collection of actions.
         * If you enumerate this, this will be in the order according to the priority.</summary>
         */
        public ICollection<IBuildAction> GetActions()
        {
            if (this._data.Count == 0)
                return new List<IBuildAction>();
            else if (this._data.Count == 1)
                return this._data.Values[0];
            else
            {
                List<IBuildAction> result = new List<IBuildAction>();
                foreach (List<IBuildAction> actionList in this._data.Values)
                    result.AddRange(actionList);
                return result;
            }
        }

        /** <summary>Returns one of the most prioritized actions if there are any or <c>null</c> if this is <c>null</c>.</summary>
        */
        public IBuildAction GetOneAction()
        {
            foreach (IBuildAction action in this)
                return action;
            return null;
        }

        /** <summary>This will be used to define subsets of actions.</summary>
         */
        public delegate bool ActionSelector(IBuildAction action);

        /** <summary>This will remove those actions where <c>selector</c> returns <c>true</c>.</summary>
         */
        public void Remove(ActionSelector selector)
        {
            if (this._readonly)
                throw new ApplicationException();
            this._prerequisites = null;
            SortedList<ActionPriority, List<IBuildAction>> data = new SortedList<ActionPriority, List<IBuildAction>>();
            foreach (ActionPriority p in this._data.Keys)
            {
                List<IBuildAction> remainingActions = new List<IBuildAction>();
                foreach (IBuildAction action in this._data[p])
                {
                    if (!selector(action))
                        remainingActions.Add(action);
                }
                if (remainingActions.Count > 0)
                    data.Add(p, remainingActions);
            }
            this._data = data;
        }

        #endregion

        #region ICollection<IBuildAction> Member
        /** <summary> Adds the provided actions.
         * This will read the <c>wx </c> .Build.IBuildAction.Priority of <c>item </c>  to determine its priority. </summary> */
        public void Add(IBuildAction item)
        {
            if (this._readonly)
                throw new ApplicationException();
            if (item==null)
                return;
            if (!this._data.ContainsKey(item.Priority))
                this._data.Add(item.Priority, new List<IBuildAction>());
            this._prerequisites = null;
            this._data[item.Priority].Add(item);
        }

        /** <summary> This will explicitely add the <c>item </c>  to the actions of priority <c>p </c> .
         * Regardless of <c>wx </c> .Build.IBuildAction.Priority. </summary> */
        public void Add(ActionPriority p, IBuildAction item)
        {
            if (this._readonly)
                throw new ApplicationException();
            if (item==null)
                return;
            this._prerequisites = null;
            if (!this._data.ContainsKey(p))
                this._data.Add(p, new List<IBuildAction>());
            this._data[p].Add(item);
        }

        /** <summary> This will add all actions in <c>actions </c>  with default priority. </summary> */
        public void AddRange(ICollection<IBuildAction> actions)
        {
            this.AddRange(ActionPriority.Default, actions);
        }

        /** <summary> This will add all actions in <c>actions </c>  with the provided priority. </summary> */
        public void AddRange(ActionPriority p, ICollection<IBuildAction> actions)
        {
            if (this._readonly)
                throw new ApplicationException();
            this._prerequisites = null;
            if (!this._data.ContainsKey(p))
                this._data.Add(p, new List<IBuildAction>());
            this._data[p].AddRange(actions);
        }

        public void Clear()
        {
            this._data.Clear();
        }

        public bool Contains(IBuildAction item)
        {
            foreach (List<IBuildAction> actionList in this._data.Values)
                if (actionList.Contains(item))
                    return true;
            return false;
        }

        public void CopyTo(IBuildAction[] array, int arrayIndex)
        {
            foreach (List<IBuildAction> actionList in this._data.Values)
            {
                actionList.CopyTo(array, arrayIndex);
                arrayIndex += actionList.Count;
            }
        }

        public int Count
        {
            get
            {
                int result = 0;
                foreach (List<IBuildAction> actionList in this._data.Values)
                    result += actionList.Count;
                return result;
            }
        }

        public bool IsReadOnly
        {
            get { return this._readonly; }
        }

        public ICollection<IBuildProduct> GetPrerequisites()
        {
            if (this._prerequisites == null)
            {
                this._prerequisites = new SortedDictionary<IBuildProduct, IBuildProduct>();
                foreach (ActionPriority p in this._data.Keys)
                    foreach (IBuildAction action in this._data[p])
                        foreach (IBuildProduct prereq in action.GetPrerequisites())
                            this._prerequisites[prereq] = prereq;
            }
            return this._prerequisites.Keys;
        }

        public bool ContainsPrerequisite(IBuildProduct prereq)
        {
            foreach (ActionPriority p in this._data.Keys)
                foreach (IBuildAction action in this._data[p])
                    if (action.ContainsPrerequisite(prereq))
                        return true;
            return false;
        }

        public bool Remove(IBuildAction item)
        {
            if (this._readonly)
                throw new ApplicationException();
            this._prerequisites = null;
            bool result = false;
            foreach (ActionPriority p in this._data.Keys)
            {
                List<IBuildAction> actionList = this._data[p];
                if (actionList.Remove(item))
                    result = true;
            }
            return result;
        }

        #endregion

        #region IEnumerable<IBuildAction> Member

        public IEnumerator<IBuildAction> GetEnumerator()
        {
            return this.GetActions().GetEnumerator();
        }

        #endregion

        #region IEnumerable Member

        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            return this.GetEnumerator();
        }

        #endregion

        #region Overrides
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            foreach (ActionPriority p in this._data.Keys)
            {
                sb.AppendLine(p.ToString() + ":");
                foreach (IBuildAction a in this._data[p])
                {
                    sb.Append("- ");
                    if (a==null)
                       sb.Append("null");
                    else
                       sb.Append(a.ToString());
                }
            }
            return sb.ToString();
        }
        #endregion
    }

    /** <summary>A dummy build action that only tests availability of files.
    * This action shall be used by those projects that refer to targets that
    * will not be built but have to be available. These are all projects that
    * encapsulate libraries or software components that have to be preinstalled.
    * This action will fail if one of the required files cannot be found.
    * </summary>
    */
    public class FileTestAction : BaseAction, IBuildAction
    {
        #region State
        ICollection<ContentFiles> _referredFiles;
        #endregion

        #region CTor
        /** <summary>Creates an instance that returns the designated files as targets and, thus, checks for theit availability on execution.</summary>
        */
        public FileTestAction(params ContentFiles[] referredFiles)
        {
            this._referredFiles = referredFiles;
        }
        #endregion

        #region Properties
        /** <summary> Returns a collection of those files of occasionally different types that will be tested by this action. </summary> */
        public ICollection<ContentFiles> ReferredFiles { get { return this._referredFiles; } }
        #endregion

        #region IBuildAction Member
        /** <summary> This will not be created by a provider.
        * Actions of this kind will be created explicitely by those projects that
        * use them. </summary> */
        public IBuildActionProvider ActionProvider
        {
            get { throw null; }
        }

        public string Name
        {
            get { return "Test "+this._referredFiles.ToString(); }
        }

        public ActionPriority Priority
        {
            get { return ActionPriority.Fallback; }
        }

        /** <summary>This will raise errors on missing files.</summary>
        * <returns> true iff all files to be tested by this instance have been found.</returns>
        */
        public bool Execute(BuildToolFamilyEnv env, DateTime validityOfBuildSystem)
        {
            bool result = true;
            foreach (ContentFiles bunchOfFiles in this._referredFiles)
                foreach (ContentFile file in bunchOfFiles)
                    if (!file.Exists)
                    {
                        result = false;
                        BuildConfig.HandleErrorObject(ErrorObject.MessageType.Error, "File {0} is required but missing.", file);
                    }
            return result;
        }

        /// <summary>
        /// This implementation will simply do nothing.
        /// </summary>
        /// <param name="env">This is an environment that different tools of the same family may use to exchange information.
        /// This store is typically used to save information on configuration files or thinsgs of that kind that will be
        /// shared among all tools of the same family.</param>
        /// <param name="booCodeLines">The code that will actually build something will be appended to this writer.</param>
        /// <param name="indention">A string that shall preceed all created lines. </param>
        /// <exception cref="NotSupportedException">Will be thrown if this feature is not supported.</exception>
        /// <seealso cref="GetProgrammStartInfo"/>
        public override void AppendBooCode(List<string> booCodeLines, string indention, BuildToolFamilyEnv env)
        {
        }
        #endregion

        #region Overrides
        public override ICollection<IBuildProduct> GetTargets()
        {
            List<IBuildProduct> result=new List<IBuildProduct>();
            foreach (ContentFiles bunchOfFiles in this._referredFiles)
                foreach (ContentFile file in bunchOfFiles)
                    result.Add(file);
            return result;
        }

        public override ICollection<IBuildProduct> GetPrerequisites()
        {
            return null;
        }
        #endregion
    }
}
