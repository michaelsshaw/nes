/** Build system for wx.NET.
 * 
 * This DLL contains basic implementations to build (compile and link) C/C++ programs,
 * compile .NET assemblies written in C#, sign them, and install them.
 * 
 * This file contains the wrappers of the mono-tools.
 * 
 * \file 
 *
 * Copyright 2009-2010 Harald Meyer auf'm Hofe harald_meyer@users.sourceforge.net
 * 
 * Licensed under the wxWidgtes license, see LICENSE.txt for details.
 * 
 * $Id: GnuCxxTools.cs,v 1.4 2010/06/11 18:37:25 harald_meyer Exp $
 */

using System;
using System.Collections.Generic;
using System.IO;
using System.Diagnostics;

/** <summary>This namspace contains wraps the tools of the GNU C Compiler (GCC).
 * This namespace contians classes that are available using MinGW distributions as well as Linux
 * systems. If this shall use MinGW, the distribution is expected to reside in C:\MinGW.
 * </summary>
 */
namespace wx.Build.Cxx.GCC
{
    /// <summary>
    /// This class wrapps the GCC as compiler (in contrast to GccAsLinker that uses the GCC as linker).
    /// This wrapper works with MinGW as well as in Linux distributions.
    /// </summary>
    /// <remarks>
    /// This will use System.Environment.OSVersion.Platform to identify whether this is MingW. Everything except
    /// System.PlatformID.Linux will trigger the MinGW settings. 
    /// </remarks>
    public class GccAsCompiler: BaseAction, IBuildAction, IBuildActionProvider
    {
        #region State
        ContentFile _target = null;
        ContentFile _source = null;
        ContentFiles _includeFiles = new ContentFiles(ContentType.CCPlusPlusInclude);
        #endregion

        #region CTor
        /// <summary>
        /// Creates an instance that can be used as IBuildActionProvider.
        /// </summary>
        public GccAsCompiler()
        {
        }
        #endregion

        #region IBuildActionProvider Member
        /// <summary>
        /// OperatingSystem.Linux, OperatingSystem.MacOsX, OperatingSystem.WinXP.
        /// </summary>
        public ICollection<OperatingSystem> ApplicableOSs
        {
            get { return new OperatingSystem[] { OperatingSystem.Linux, OperatingSystem.MacOsX, OperatingSystem.WinXP }; }
        }

        public static readonly string ToolFamilyName="GNU";

        /// <summary>
        /// "GNU"
        /// </summary>
        public string ToolFamily
        {
            get { return ToolFamilyName; }
        }

        public string Description
        {
            get { return "The GNU C/C++ Compiler."; }
        }

        readonly static internal EnvironmentVarInfo _gccCPathVar = new EnvironmentVarInfo("CPATH", "A list of directories to be searched as if specified with -I. Use semicolon ; to separate directories on Windows and colons : otherwise.", typeof(DirectoryName));
        readonly static internal EnvironmentVarInfo _gccBinPathVar = new EnvironmentVarInfo("GCC_BINPATH", "Path to the directory of the compiler program. If this is empty, gcc[.exe] must reside in one of the PATH directories.", typeof(DirectoryName));
        readonly static internal EnvironmentVarInfo _gccLibPathVar = new EnvironmentVarInfo("LIBRARY_PATH", "is a colon-separated list of directories, much like PATH. When configured as a native compiler, GCC tries the directories thus specified when searching for special linker files, if it can? find them using GCC_EXEC_PREFIX. Linking using GCC also uses these directories when searching for ordinary libraries for the -l option (but directories specified with -L come first).", typeof(DirectoryList));
        /// <summary>
        /// This uses the following variables:
        /// <list type="table">
        /// <listheader><term>Variable</term><description>Description</description></listheader>
        /// <item><term>GCC_BINPATH</term><description>Path to the directory of the compiler program. If this is empty, gcc[.exe] must reside in one of the PATH directories.</description></item>
        /// <item><term>CPATH</term><description>A list of directories to be searched as if specified with -I. Use semicolon ; to separate directories on Windows and colons : otherwise.</description></item>
        /// </list>
        /// </summary>
        public override IDictionary<string, EnvironmentVarInfo> UsedVars
        {
            get
            {
                Dictionary<string, EnvironmentVarInfo> result = new Dictionary<string, EnvironmentVarInfo>();
                result.Add("CPATH", _gccCPathVar);
                result.Add(_gccBinPathVar.Varname, _gccBinPathVar);
                result.Add(_gccLibPathVar.Varname, _gccLibPathVar);
                return result;
            }
        }


        #region Internal Helpers to Find Out Whether And Where GCC Is Available.
        /// <summary>
        /// Path to the GCC/MinGW include directory. This may be <c>null</c> if unknown or not available.
        /// You may omitt this if you specified the CPATH variable. This will be set relatively to the GCC_BINPATH
        /// variable if defined.
        /// </summary>
        /// <returns></returns>
        internal static string GetGCCIncludePath()
        {
            if (!_gccBinPathVar.IsEmpty() && System.IO.Directory.Exists((string)_gccBinPathVar.Get()))
            {
                string binPath = (string)_gccBinPathVar.Get();
                if (binPath.EndsWith("bin"))
                    return binPath.Substring(0, binPath.Length - 3) + "include";
            }
            if (BuildConfig.IsWindows && Directory.Exists("C:\\MinGW\\include"))
            {
                return "C:\\MinGW\\include";
            }
            return null;
        }

        /// <summary>
        /// Path to the GCC bin directory. This may be <c>null</c> if unknown or not available.
        /// </summary>
        /// <returns></returns>
        internal static string GetGCCBinPath()
        {
            if (!_gccBinPathVar.IsEmpty() && System.IO.Directory.Exists((string)_gccBinPathVar.Get()))
                return (string)_gccBinPathVar.Get();
            else if (BuildConfig.IsWindows && Directory.Exists("C:\\MinGW\\bin"))
                return "C:\\MinGW\\bin";
            return null;
        }

        static string _programFilename = null;
        /// <summary>
        /// Internal function to find out the place of the GCC program.
        /// </summary>
        /// <returns>The file of the GCC program</returns>
        internal static string GetGCCFileName()
        {
            if (_programFilename == null)
            {
                _programFilename = "g++";
                if (BuildConfig.IsWindows)
                {
                    // Windows.
                    _programFilename += ".exe";
                }
                // do we have path info by the variable.
                if (!_gccBinPathVar.IsEmpty()
                    && File.Exists(Path.Combine((string)_gccBinPathVar.Get(), _programFilename)))
                {
                    _programFilename = Path.Combine((string)_gccBinPathVar.Get(), _programFilename);
                }
                else if (BuildConfig.IsWindows)
                {
                    // fallback on window. search 
                    if (File.Exists("C:\\MinGW\\bin\\g++.exe"))
                    {
                        _programFilename = "C:\\MinGW\\bin\\g++.exe";
                    }
                }
            }
            return _programFilename;
        }

        static bool _foundProgram = true;
        /// <summary>
        /// Method to find out whether GCC is available or not.
        /// </summary>
        /// <returns>True iff GCC is available.</returns>
        internal static bool IsGCCAvailable()
        {
            if (_programFilename == null && !_foundProgram)
            {
                try
                {
                    ProcessStartInfo p = new ProcessStartInfo();
                    p.FileName = GccAsCompiler.GetGCCFileName();
                    p.Arguments = "-v";
                    p.UseShellExecute=false;
                    Process process=Process.Start(p);
                    process.WaitForExit();
                    _foundProgram = process.ExitCode == 0;
                }
                catch (Exception exc)
                {
                    BuildConfig.HandleMessageObject(exc.Message, exc);
                    _foundProgram = false;
                }
            }
            return _foundProgram;
        }
        #endregion

        /// <summary>
        /// The filename ofthe GCC command thaz will be used.
        /// </summary>
        public string FileName
        {
            get
            {
                return GetGCCFileName();
            }
        }

        /// <summary>
        /// True if the tool is available.
        /// This will test, whether a GCC command is available and can be startet.
        /// </summary>
        public bool IsAvailable
        {
            get
            {
                return IsGCCAvailable();
            }
        }

        public bool MayContentFilePrerequisitesSuffice(ContentType target, ICollection<ContentType> prerequisites)
        {
            foreach (ContentType t in prerequisites)
                if (t.Implies(ContentType.CCode)
                    || t.Implies(ContentType.CPlusPlusCode))
                    return true;
            return false;
        }

        /// <summary>
        /// This compiles objects of type ContentType.GccObj.
        /// </summary>
        public ICollection<ContentType> ContentFileTargets
        {
            get { return new ContentType[] { ContentType.GccObj}; }
        }

        /** <summary>Creates a collection of include paths from the provided parameters and environment.</summary>
          * <param name="env">The result will be read from key "INCLUDE" or, if not present, the result will be stored there.</param>
          * <param name="parameters">Include paths will be read from this argument (and the corresponding options) if not already stores.</param>
          * \c parameters may be \c null. In that case, this will consider the current standard parameter.
          */
        public CollectionOfIncludePaths GetIncludePaths(BuildToolFamilyEnv env, CxxParameters parameters)
        {
            if (parameters == null)
                parameters = (CxxParameters)BuildConfig.GetDefaultParameterOfType(typeof(CxxParameters));
            CollectionOfIncludePaths result = new CollectionOfIncludePaths();
            result.AddRange(parameters.IncludePaths);

            System.Collections.Specialized.StringDictionary familyEnv = (System.Collections.Specialized.StringDictionary)env[this];
            if (familyEnv == null)
            {
                // create a new store.
                familyEnv = new System.Collections.Specialized.StringDictionary();
                env[this] = familyEnv;
            }
            string includePaths = null;
            if (familyEnv.ContainsKey("INCLUDE"))
                includePaths = Environment.ExpandEnvironmentVariables(familyEnv["INCLUDE"]);
            else
                includePaths = Environment.GetEnvironmentVariable("CPATH");
            if (includePaths != null && includePaths.Length > 0)
            {
                char separator=';';
                if (BuildConfig.NotWindows)
                    separator = ':';
                foreach (string includePath in includePaths.Split(separator))
                {
                    if (includePath.Length > 0)
                    {
                        result.Add(includePath);
                    }
                }
            }
            return result;
        }

        /// <summary>
        /// This will create an action producing the provided target presupposing a subset of the provided prerequisite.
        /// </summary>
        /// <param name="env">A collection of key/value-pairs that will be shared among all the tools of the same family.</param>
        /// <param name="target">The target that shall be produced</param>
        /// <param name="prerequisites">The prerequisites that can be assumed to be given before running the action.</param>
        /// <returns></returns>
        public IBuildAction Create(BuildToolFamilyEnv env, IBuildProduct target, ICollection<IBuildProduct> prerequisites)
        {
            ContentFile fileTarget=target as ContentFile;
            if (fileTarget==null 
                || !fileTarget.Type.Implies(ContentType.GccObj))
            {
                BuildConfig.HandleErrorObject(ErrorObject.MessageType.Error, string.Format("Cannot use GCC to build {0}.", target));
                return null;
            }
            GccAsCompiler action = new GccAsCompiler();
            action._target=fileTarget;
            CollectionOfIncludePaths includePaths = this.GetIncludePaths(env, null);
            foreach (IBuildProduct p in prerequisites)
            {
                IFileProducts f=p as IFileProducts;
                if (f != null)
                {
                    ContentFiles ff = f.Files;
                    if (ff.Type.Implies(ContentType.CPlusPlusCode)
                        || ff.Type.Implies(ContentType.CCode))
                    {
                        foreach (ContentFile fff in ff.Files)
                        {
                            if (Path.GetFileNameWithoutExtension(fff.FileName)
                                == Path.GetFileNameWithoutExtension(fileTarget.FileName))
                            {
                                action._source = fff;
                                ContentFiles newIncludes = includePaths.GetPathToIncludes(fff.FileName);
                                if (this._includeFiles == null)
                                    this._includeFiles = newIncludes;
                                else
                                    this._includeFiles.AddRange(newIncludes);
                            }
                        }
                    }
                }
            }
            return action;
        }

        #endregion

        #region BaseAction Overrides
        /// <summary>
        /// Returns the target in a collection.
        /// </summary>
        override public ICollection<IBuildProduct> GetTargets()
        {
            return new Build.IBuildProduct[] { this._target };
        }

        /** <summary>Collection of the prerequisites of this action. This will contain include files and the source.</summary>
         */
        override public ICollection<IBuildProduct> GetPrerequisites()
        {
            List<IBuildProduct> result = new List<IBuildProduct>();
            result.Add(this._source);
            foreach(ContentFile includeFile in this._includeFiles)
                result.Add(includeFile);
            return result;
        }
        #endregion

        #region BOO Export
        /// <summary>
        /// This will be called for any action provider before IBuildAction.AppendBooCode() is called.
        /// This provides action providers with the opportunity to import modules and create variables
        /// for global options.
        /// </summary>
        /// <param name="env">Environment containing status that can be shared among tools of the same family.</param>
        /// <param name="importModules">List of modules that shall be imported. Add required modules here. Each module
        /// will be imported exactly once (even if it occurs more than once in the list).</param>
        /// <param name="booDeclarations">Lines of code that will be added to the preamble of the BOO code.
        /// Please note, that each line may only appear once. All subsequent additions of this line of
        /// code will be ignored. These lines shall contain declarations of variables etc.</param>
        /// <param name="booDefinitions">Lines of code that that will be added before the code provided by
        /// the actions to build the system. Typically, this will contain the definition of functions
        /// that are used on building. Lines starting with "import" will only be added once to the final code. </param>
        /// <remarks>This will define a function <c>RunMsLink</c> receiving all objects that shall be linked.
        /// </remarks>
        public override void AppendToBooPreamble(BuildToolFamilyEnv env, List<string> importModules, List<string> booDeclarations, List<string> booDefinitions)
        {
            importModules.Add("System.Text");
            importModules.Add("System.IO");

            booDeclarations.Add("# Path to the compiler");
            booDeclarations.Add(string.Format("GCC_FILENAME=\"{0}\"", ContentFile.ConvertFilenameToString(this.FileName)));
            booDeclarations.Add(string.Format("# Options of the GCC as compiler."));
            booDeclarations.Add(string.Format("GCC_OPTIONS=''"));
            CxxParameters parameters = (CxxParameters)BuildConfig.GetDefaultParameterOfType(typeof(CxxParameters));
            booDeclarations.Add("# Turning compilation in debug mode on or off.");
            if (parameters.DebugInfo)
            {
                booDeclarations.Add(string.Format("GCC_OPTIONS+=' -ggdb -D_DEBUG' # compiles code with debugging information"));
                booDeclarations.Add(string.Format("#GCC_OPTIONS+=' -DNDEBUG' # use this to turn off compilation with debugging information"));
            }
            else
            {
                booDeclarations.Add(string.Format("#GCC_OPTIONS+=' -ggdb -D_DEBUG' # compiles code with debugging information"));
                booDeclarations.Add(string.Format("GCC_OPTIONS+=' -DNDEBUG' # use this to turn off compilation with debugging information"));
            }
            #region Special Parameters
            booDeclarations.Add("# Special options that have been added in particular for this tool");
            string specialParameters = parameters.GetOptions(this.Name);
            if (specialParameters != null)
            {
                booDeclarations.Add(string.Format("GCC_OPTIONS+=\" {0}\"", ContentFile.ConvertFilenameToBooString( specialParameters)));
            }
            #endregion
            #region Features
            booDeclarations.Add("# Features");
            if (parameters.Features != null)
            {
                foreach (KeyValuePair<FeatureEntry, bool> featureEntry in parameters.Features)
                {
                    booDeclarations.Add(string.Format("{3}GCC_OPTIONS+=' -D{0}' # Feature {1}: {2}", featureEntry.Key.Symbol, featureEntry.Key.Displayname, featureEntry.Key.Description, featureEntry.Value ? "": "#"));
                }
            }
            #endregion
            #region Includes
            booDeclarations.Add("# Include directories referring to OS or used libraries.");
            foreach (string includePath in GetIncludePaths(env, parameters))
            {
                booDeclarations.Add(string.Format("GCC_OPTIONS+=\" -I {0}\"", ContentFile.ConvertFilenameToBooString(includePath)));
            }
            string gccIncludePath = GetGCCIncludePath();
            if (gccIncludePath != null)
            {
                booDeclarations.Add("# Include directories referring to the compiler and libraries shipped with the compiler.");
                booDeclarations.Add(string.Format("GCC_OPTIONS+=\" -I {0}\"", ContentFile.ConvertFilenameToBooString(gccIncludePath)));
            }
            booDeclarations.Add("# Options for optimization.");
            switch (parameters.Optimization)
            {
                case CxxOptimization.CompactCode: booDeclarations.Add("GCC_OPTIONS+=' -Os' # alternatives: -O2, -O3, -O0"); break;
                case CxxOptimization.FastCode: booDeclarations.Add("GCC_OPTIONS+=' -O2' # alternatives: -Os, -O3, -O0"); break;
                case CxxOptimization.OverallOptimization: booDeclarations.Add("GCC_OPTIONS+=' -O3' # alternatives: -Os, -O2, -O0"); break;
                case CxxOptimization.No: booDeclarations.Add("GCC_OPTIONS+=' -O0' # alternatives: -Os, -O2, -O3"); break;
            }
            #endregion
            #region Exceptions
            booDeclarations.Add("# Exceptions");
            if (BuildConfig.NotWindows)
                booDeclarations.Add(string.Format("{0}GCC_OPTIONS+=' -fPIC -fexceptions'", parameters.EnableExceptions ? "": "#"));
            else
                booDeclarations.Add(string.Format("{0}GCC_OPTIONS+=' -mthreads -fexceptions'", parameters.EnableExceptions ? "": "#"));
            #endregion
            #region Warnings
            booDeclarations.Add("# Warnings");
            switch (parameters.WarningLevel)
            {
                case CxxWarningLevel.BasicWarnings: booDeclarations.Add("#GCC_OPTIONS+= one of -Wall -w"); break;
                case CxxWarningLevel.ImportantWarnings: booDeclarations.Add("#GCC_OPTIONS+= one of -Wall -w"); break;
                case CxxWarningLevel.QualityWarnings: booDeclarations.Add("GCC_OPTIONS+=' -Wall' # or ' -w' or emtpy"); break;
                case CxxWarningLevel.NoWarnings: booDeclarations.Add("GCC_OPTIONS+=' -w' # or ' -Wall' or emtpy"); break;
            }
            booDeclarations.Add(string.Format("{0}GCC_OPTIONS+=' -Werror' # treat warnings as errors", BuildConfig.GetConfig().AbortOptions == AbortOptions.TreatWarningsAsErrors ? "" : "#"));
            #endregion

            #region Definitions
            booDefinitions.Add(string.Format("def RunGccAsCompiler(target as string, source as string):"));
            booDefinitions.Add(string.Format("\tif not TestForRebuild(target, source):"));
            booDefinitions.Add(string.Format("\t\tprint target,\"is up to date\""));
            booDefinitions.Add(string.Format("\t\treturn"));
            booDefinitions.Add(string.Format("\tprint \"GCC creates\", target"));
            booDefinitions.Add(string.Format("\ttargetDir=System.IO.Path.GetDirectoryName(target)"));
            booDefinitions.Add(string.Format("\tif not System.IO.Directory.Exists(targetDir):"));
            booDefinitions.Add(string.Format("\t\tSystem.IO.Directory.CreateDirectory(targetDir)"));
            if (parameters.CompileAsCxx || this._source.Type == ContentType.CCPlusPlusInclude)
                booDefinitions.Add("\tcmdArgs='-xc++'");
            else
                booDefinitions.Add("\tcmdArgs='-xc'");
            booDefinitions.Add(string.Format("\tcmdArgs+=\" -c \\\"${{source}}\\\" -o \\\"${{target}}\\\"\""));
            booDefinitions.Add(string.Format("\tcmdArgs+=GCC_OPTIONS"));
            booDefinitions.Add(string.Format("\tstartinfo=System.Diagnostics.ProcessStartInfo()"));
            booDefinitions.Add(string.Format("\tstartinfo.FileName=GCC_FILENAME"));
            booDefinitions.Add(string.Format("\tstartinfo.Arguments=cmdArgs"));
            string vsEnvDir = _gccCPathVar.GetAsString();
            if (vsEnvDir.Length > 0)
                booDefinitions.Add(string.Format("\tstartinfo.EnvironmentVariables[\"CPATH\"] = {0}", ContentFile.ConvertFilenameToString(vsEnvDir)));
            booDefinitions.Add(string.Format("\tstartinfo.UseShellExecute=false"));
            booDefinitions.Add(string.Format("\tp=System.Diagnostics.Process.Start(startinfo)"));
            booDefinitions.Add(string.Format("\tp.WaitForExit()"));
            booDefinitions.Add(string.Format("\tif p.ExitCode!=0:"));
            booDefinitions.Add(string.Format("\t\traise System.Exception(\"Build action failed.\")"));
            
            #endregion
        }

        /// <summary>
        /// This method will create BOO source code and append this code to the provided text writer.
        /// </summary>
        /// <param name="env">This is an environment that different tools of the same family may use to exchange information.
        /// This store is typically used to save information on configuration files or thinsgs of that kind that will be
        /// shared among all tools of the same family.</param>
        /// <param name="booCode">The code that will actually build something. Each list entry will be a line of code in the resulting
        /// BOO program.</param>
        /// <param name="indention">A string that shall preceed all created lines. </param>
        /// <remarks>Refer to IBuildActionProvider.AppendToBooPreamble() for an example.</remarks>
        /// <exception cref="NotSupportedException">Will be thrown if this feature is not supported.</exception>
        public override void AppendBooCode(List<string> booCodeLines, string indention, BuildToolFamilyEnv env)
        {
            booCodeLines.Add(string.Format("{2}RunGccAsCompiler(\"{0}\", \"{1}\")", this._target.FileNameAsBooString, this._source.FileNameAsBooString, indention));
        }
        #endregion

        #region IBuildAction Member

        /// <summary>
        /// Creates the call of the GCC as compiler.
        /// </summary>
        /// <param name="env">Data structure that allows tools of the same family to share information.</param>
        /// <returns></returns>
        public override ProcessStartInfo GetProgramStartInfo(BuildToolFamilyEnv env)
        {
            System.Diagnostics.ProcessStartInfo result = new System.Diagnostics.ProcessStartInfo();
            result.FileName = this.FileName;
            System.Text.StringBuilder cmdArgs = new System.Text.StringBuilder();
            cmdArgs.Append(" -c");
            CxxParameters parameters = (CxxParameters)BuildConfig.GetDefaultParameterOfType(typeof(CxxParameters));
            if (parameters.CompileAsCxx || this._source.Type == ContentType.CCPlusPlusInclude)
                cmdArgs.Append(" -xc++");
            else
                cmdArgs.Append(" -xc");
            cmdArgs.Append(" ");
            cmdArgs.Append(this._source.QuotedFileName);
            cmdArgs.Append(" -o");
            cmdArgs.Append(this._target.QuotedFileName);

            if (parameters.DebugInfo)
                cmdArgs.Append(" -ggdb -D_DEBUG");
            else
                cmdArgs.Append(" -DNDEBUG");

            string specialParameters = parameters.GetOptions(this.Name);
            if (specialParameters != null)
            {
                cmdArgs.Append(" ");
                cmdArgs.Append(specialParameters);
            }
            if (parameters.Features != null)
            {
                foreach (string symbol in parameters.Features.EnabledSymbols)
                {
                    cmdArgs.AppendFormat(" -D{0}", symbol);
                }
            }
            foreach (string includePath in GetIncludePaths(env, parameters))
            {
                cmdArgs.Append(" -I ");
                cmdArgs.Append(ContentFile.QuoteFileName(includePath));
            }
            string gccIncludePath = GetGCCIncludePath();
            if (gccIncludePath != null)
            {
                cmdArgs.Append(" -I ");
                cmdArgs.Append(ContentFile.QuoteFileName(gccIncludePath));
            }
            switch (parameters.Optimization)
            {
                case CxxOptimization.CompactCode: cmdArgs.Append(" -Os"); break;
                case CxxOptimization.FastCode: cmdArgs.Append(" -O2"); break;
                case CxxOptimization.OverallOptimization: cmdArgs.Append(" -O3"); break;
                case CxxOptimization.No: cmdArgs.Append(" -O0"); break;
            }
            if (parameters.EnableExceptions)
            {
                if (BuildConfig.NotWindows)
                {
                    cmdArgs.Append(" -fPIC");
                }
                else
                {
                    cmdArgs.Append(" -mthreads");
                }
                cmdArgs.Append(" -fexceptions");
            }
            switch (parameters.WarningLevel)
            {
                case CxxWarningLevel.BasicWarnings: cmdArgs.Append(""); break;
                case CxxWarningLevel.ImportantWarnings: cmdArgs.Append(""); break;
                case CxxWarningLevel.QualityWarnings: cmdArgs.Append(" -Wall"); break;
                case CxxWarningLevel.NoWarnings: cmdArgs.Append(" -w"); break;
            }
            if (BuildConfig.GetConfig().AbortOptions == AbortOptions.TreatWarningsAsErrors)
                cmdArgs.Append(" -Werror");

            result.Arguments = cmdArgs.ToString();
            string vsEnvDir = _gccCPathVar.GetAsString();
            if (vsEnvDir.Length > 0)
                result.EnvironmentVariables["CPATH"] = vsEnvDir;
            return result;
        }

        /// <summary>
        /// The action may serve also as action provider.
        /// </summary>
        public IBuildActionProvider ActionProvider
        {
            get { return this; }
        }

        public static readonly string ToolName="gcc-c";

        /// <summary>
        /// The name of this tool is "gcc-c" to indicate that gcc will be used as compiler but not for linking.
        /// </summary>
        public string Name
        {
            get { return ToolName; }
        }

        /// <summary>
        /// This is of ActionPriority.Default priority.
        /// </summary>
        public ActionPriority Priority
        {
            get { return ActionPriority.Default; }
        }

        /// <summary>
        /// Executes <c>FileName</c> using the start info as produced by GetProgramStartInfo().
        /// </summary>
        /// <param name="env">Some data that tools of the same family may share.</param>
        /// <param name="validityOfBuildSystem">The validity stating when the build system (definition of the projects) have been changed.</param>
        /// <returns>True on successful build.</returns>
        public bool Execute(BuildToolFamilyEnv env, DateTime validityOfBuildSystem)
        {
            BuildConfig.HandleMessageObject("Start GCC as a compiler to build {0}.", this._target.FileName);
            ErrorDataReceiver receiver = new ErrorDataReceiver(this);
            receiver.WarningClassifier = new System.Text.RegularExpressions.Regex(@"\swarning\s",
                System.Text.RegularExpressions.RegexOptions.Compiled
                | System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            receiver.ErrorClassifier = new System.Text.RegularExpressions.Regex(@"\serror\s",
                System.Text.RegularExpressions.RegexOptions.Compiled
                | System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            receiver.FilePosPattern = new System.Text.RegularExpressions.Regex(
                @"^(?<file>((\w:)?(/|\\)[^:]+)):(?<line>[\d]+):");
            wx.ProcessUtils.ProcessStarter starter = new wx.ProcessUtils.ProcessStarter(this.GetProgramStartInfo(env),
                new wx.ProcessUtils.MsgEventHandler(receiver.OnReceiveMsgEvent));
            Process process = starter.Start();
            return process.ExitCode == 0;
        }
        #endregion
    }

    /// <summary>
    /// This class wrapps the GCC as linker (in contrast to GccAsCompiler that uses the GCC as compiler).
    /// This wrapper works with MinGW as well as in Linux distributions.
    /// </summary>
    /// <remarks>
    /// This will use System.Environment.OSVersion.Platform to identify whether this is MinGW. Everything except
    /// System.PlatformID.Linux will trigger the MinGW settings. 
    /// </remarks>
    public class GccAsLinker : BaseAction, IBuildAction, IBuildActionProvider
    {
        #region State
        ContentFile _output = null;
        ContentFiles _objects = null;
        ContentFiles _resources = null;
        ContentFiles _libs = null;
        ContentFiles _elfLibs=null;
        #endregion

        #region BaseAction Overloads
        /// <summary>
        /// Returns object files and static libraries, on Windows also RES files.
        /// </summary>
        public override ICollection<IBuildProduct> GetPrerequisites()
        {
            List<IBuildProduct> result = new List<IBuildProduct>();
            if (this._objects != null)
                foreach (ContentFile obj in this._objects)
                    result.Add(obj);
            if (this._libs != null)
                foreach (ContentFile lib in this._libs)
                    result.Add(lib);
            if (this._elfLibs != null)
                foreach (ContentFile lib in this._elfLibs)
                    result.Add(lib);
            if (this._resources != null)
                foreach (ContentFile res in this._resources)
                    result.Add(res);
            return result;
        }

        /// <summary>
        /// Returns the target of this project.
        /// </summary>
        public override ICollection<IBuildProduct> GetTargets()
        {
            return new IBuildProduct[] { this._output };
        }
        #endregion

        #region IBuildActionProvider Member

        /// <summary>
        /// OperatingSystem.Linux, OperatingSystem.MacOsX, OperatingSystem.WinXP.
        /// </summary>
        public ICollection<OperatingSystem> ApplicableOSs
        {
            get { return new OperatingSystem[] { OperatingSystem.Linux, OperatingSystem.MacOsX, OperatingSystem.WinXP }; }
        }

        public static readonly string ToolFamilyName = GccAsCompiler.ToolFamilyName;

        /// <summary>
        /// "GNU"
        /// </summary>
        public string ToolFamily
        {
            get { return ToolFamilyName; }
        }

        public string Description
        {
            get { return "The GNU C/C++ Compiler As Linker."; }
        }

        /// <summary>
        /// The filename ofthe GCC command thaz will be used.
        /// </summary>
        public string FileName
        {
            get
            {
                return GccAsCompiler.GetGCCFileName();
            }
        }

        /// <summary>
        /// True if the tool is available.
        /// This will test, whether a GCC command is available and can be startet.
        /// </summary>
        public bool IsAvailable
        {
            get
            {
                return GccAsCompiler.IsGCCAvailable();
            }
        }

        /// <summary>
        /// True if the argumetns contain at least one file of ContentType.GccObj.
        /// </summary>
        /// <param name="target">currentla irrelevant since this only produces one target.</param>
        /// <param name="prerequisites">A collection of types that can be considered to be available before conducting this action.</param>
        /// <returns>True if the arguments provide sufficient information to produce the target.</returns>
        public bool MayContentFilePrerequisitesSuffice(ContentType target, ICollection<ContentType> prerequisites)
        {
            foreach (ContentType t in prerequisites)
                if (t.Implies(ContentType.GccObj))
                    return true;
            return false;
        }

        /// <summary>
        /// Depending on the current platform this either produces ContentType.Elf, ContentType.MacDylib, or ContentType.WindowsDll and ContentType.WindowsGuiDll.
        /// </summary>
        public ICollection<ContentType> ContentFileTargets
        {
            get
            {
                if (BuildConfig.IsUnix)
                    return new ContentType[] { ContentType.Elf };
                else if (BuildConfig.IsMacOsX)
                    return new ContentType[] { ContentType.MacDylib };
                else
                    return new ContentType[] { ContentType.WindowsDll, ContentType.WindowsGuiDll };
            }
        }

        public IBuildAction Create(BuildToolFamilyEnv env, IBuildProduct target, ICollection<IBuildProduct> prerequisites)
        {
            GccAsLinker result = new GccAsLinker();
            ContentFile fileTarget = (ContentFile)target;
            if (BuildConfig.IsUnix && fileTarget.Type.Implies(ContentType.Elf))
                result._output = fileTarget;
            else if (BuildConfig.IsMacOsX && fileTarget.Type.Implies(ContentType.MacDylib))
                result._output = fileTarget;
            else if (fileTarget.Type.Implies(ContentType.WindowsDll))
                result._output = fileTarget;
            else
                throw new Exception("Tool GCC only produces native DLLs / ELFs as linker.");
            result._objects = new ContentFiles(ContentType.GccObj);
            result._resources = new ContentFiles(ContentType.GccResObj);
            result._libs = new ContentFiles(ContentType.GccLib);
            result._elfLibs=new ContentFiles(ContentType.Elf);
            foreach (IBuildProduct prereq in prerequisites)
            {
                ContentFile prereqFile = prereq as ContentFile;
                if (prereqFile != null)
                {
                    if (prereqFile.Type.Implies(result._objects.Type))
                        result._objects.Add(prereqFile);
                    else if (prereqFile.Type.Implies(result._resources.Type))
                        result._resources.Add(prereqFile);
                    else if (prereqFile.Type.Implies(result._libs.Type))
                        result._libs.Add(prereqFile);
                    else if (prereqFile.Type.Implies(result._elfLibs.Type))
                        result._elfLibs.Add(prereqFile);
                }
            }

            return result;
        }

        #endregion

        #region Static Helpers
        /// <summary>
        /// Path to the GCC/MinGW include directory. This may be <c>null</c> if unknown or not available.
        /// You may omitt this if you specified the CPATH variable. This will be set relatively to the GCC_BINPATH
        /// variable if defined.
        /// </summary>
        /// <returns></returns>
        internal static string GetGCCLibPath()
        {
            if (!GccAsCompiler._gccBinPathVar.IsEmpty() && System.IO.Directory.Exists((string)GccAsCompiler._gccBinPathVar.Get()))
            {
                string binPath = (string)GccAsCompiler._gccBinPathVar.Get();
                if (binPath.EndsWith("bin"))
                    return binPath.Substring(0, binPath.Length - 3) + "include";
            }
            if (BuildConfig.IsWindows && Directory.Exists("C:\\MinGW\\lib"))
            {
                return "C:\\MinGW\\lib";
            }
            return null;
        }
        #endregion

        #region Export to BOO
        /// <summary>
        /// This will be called for any action provider before IBuildAction.AppendBooCode() is called.
        /// This provides action providers with the opportunity to import modules and create variables
        /// for global options.
        /// </summary>
        /// <param name="env">Environment containing status that can be shared among tools of the same family.</param>
        /// <param name="importModules">List of modules that shall be imported. Add required modules here. Each module
        /// will be imported exactly once (even if it occurs more than once in the list).</param>
        /// <param name="booDeclarations">Lines of code that will be added to the preamble of the BOO code.
        /// Please note, that each line may only appear once. All subsequent additions of this line of
        /// code will be ignored. These lines shall contain declarations of variables etc.</param>
        /// <param name="booDefinitions">Lines of code that that will be added before the code provided by
        /// the actions to build the system. Typically, this will contain the definition of functions
        /// that are used on building. Lines starting with "import" will only be added once to the final code. </param>
        public override void AppendToBooPreamble(BuildToolFamilyEnv env, List<string> importModules, List<string> booDeclarations, List<string> booDefinitions)
        {
            #region Declarations
            booDeclarations.Add("# Path to the compiler");
            booDeclarations.Add(string.Format("GCC_LINKER_FILENAME=\"{0}\"", ContentFile.ConvertFilenameToString(this.FileName)));
            booDeclarations.Add(string.Format("# Options of the GCC as linker."));
            booDeclarations.Add(string.Format("GCC_LINK_OPTIONS='-shared'"));
            if (Environment.OSVersion.Platform == PlatformID.MacOSX)
                booDeclarations.Add(string.Format("GCC_LINK_OPTIONS+=' -dynamiclib -flat_namespace'"));
            if (BuildConfig.IsWindows)
            {
                booDeclarations.Add(string.Format("GCC_LINK_OPTIONS+=' -mthreads'")); // this is MinGW only
            }
            CxxParameters parameters = (CxxParameters)BuildConfig.GetDefaultParameterOfType(typeof(CxxParameters));
            if (parameters.DebugInfo)
                booDeclarations.Add(string.Format("GCC_LINK_OPTIONS+=' -ggdb' # Include debugging info. Use -s in rlease mode."));
            else
                booDeclarations.Add(string.Format("GCC_LINK_OPTIONS+=' -s' # Use -ggdb instead to include debug information."));
            
            switch (parameters.Optimization)
            {
                case CxxOptimization.CompactCode: booDeclarations.Add(string.Format("GCC_LINK_OPTIONS+=' -Os' # Optimization: Alterntive options are -Os -O2, -O3, or -O0")); break;
                case CxxOptimization.FastCode: booDeclarations.Add(string.Format("GCC_LINK_OPTIONS+=' -O2' # Optimization: Alterntive options are -Os, -O2, -O3, or -O0")); break;
                case CxxOptimization.OverallOptimization: booDeclarations.Add(string.Format("GCC_LINK_OPTIONS+=' -O3' # Optimization: Alterntive options are -Os, -O2, -O3, or -O0")); break;
                case CxxOptimization.No: booDeclarations.Add(string.Format("GCC_LINK_OPTIONS+=' -O0' # Optimization: Alterntive options are -Os, -O2, -O3, or -O0")); break;
            }
            switch (parameters.WarningLevel)
            {
                case CxxWarningLevel.BasicWarnings: booDeclarations.Add(string.Format("GCC_LINK_OPTIONS+='' # warning level: Alterntive options are -pedantic, -Wall, -w, or leave this empty to request basic warning level")); break;
                case CxxWarningLevel.ImportantWarnings: booDeclarations.Add(string.Format("GCC_LINK_OPTIONS+=' -pedantic' # warning level: Alterntive options are -pedantic, -Wall, -w, or leave this empty to request basic warning level")); break;
                case CxxWarningLevel.QualityWarnings: booDeclarations.Add(string.Format("GCC_LINK_OPTIONS+=' -Wall' # warning level: Alterntive options are -pedantic, -Wall, -w, or leave this empty to request basic warning level")); break;
                case CxxWarningLevel.NoWarnings: booDeclarations.Add(string.Format("GCC_LINK_OPTIONS+=' -w' # warning level: Alterntive options are -pedantic, -Wall, -w, or leave this empty to request basic warning level")); break;
            }
            string treatErrorsAsWarnings="#";
            if (BuildConfig.GetConfig().AbortOptions == AbortOptions.TreatWarningsAsErrors)
                treatErrorsAsWarnings="";
            booDeclarations.Add(string.Format("{0}GCC_LINK_OPTIONS+=' -Werror' # This option will cause the linker to treat warning as errors.", treatErrorsAsWarnings));

            string libPath = GetGCCLibPath();
            if (libPath != null)
                booDeclarations.Add(string.Format("GCC_LINK_OPTIONS+=\" -L\\\"{0}\\\"\"", ContentFile.ConvertFilenameToBooString(libPath)));

            // special parameters my contain references to dynamic libraries and
            // shall be placed after the object files.
            string specialParameters = parameters.GetOptions(this.Name);
            if (specialParameters != null && specialParameters.Length > 0)
            {
                booDeclarations.Add("# These are special options particular for this tool.");
                booDeclarations.Add("GCC_LINK_OPTIONS+=\" "+ContentFile.ConvertFilenameToString(specialParameters+"\""));
            }
            string nostdlibs="#";
            if (parameters.Libraries == CxxLibraries.NoStdLibraries)
                nostdlibs="";
            booDeclarations.Add(string.Format("{0}GCC_LINK_OPTIONS+=\" -nostdlib\"", nostdlibs));
            booDeclarations.Add("GCC_LINK_OPTIONS+=' -o $TARGET $OBJECTS $LIBOPTS' # placeholders");
            if (BuildConfig.IsWindows)
            {
                booDeclarations.Add("GCC_LINK_OPTIONS+=' -Wl,--subsystem,windows -mwindows' # standard options for windows");
                if ((parameters.Libraries & CxxLibraries.GeneralOSLibraries) == CxxLibraries.GeneralOSLibraries)
                    booDeclarations.Add("GCC_LINK_OPTIONS+=' -lkernel32 -luser32 -lshell32 -ladvapi32 -lole32 -loleaut32 -lwinspool -lwinmm -luuid' # general windows libraries");
                if ((parameters.Libraries & CxxLibraries.GDILibraries) == CxxLibraries.GDILibraries)
                    booDeclarations.Add("GCC_LINK_OPTIONS+=' -lgdi32 -lcomdlg32 -lcomctl32' # windows GDI libraries");
                if ((parameters.Libraries & CxxLibraries.TcpAndRpcLibraries) == CxxLibraries.TcpAndRpcLibraries)
                    booDeclarations.Add("GCC_LINK_OPTIONS+=' -lrpcrt4 -lwsock32' # windows TCP and RPC libraries");
            }
            #endregion

            #region Definitions
            booDefinitions.Add(string.Format("def RunGccAsLinker(targetFile as string, libOpts as string, *objects as (string)):"));
            booDefinitions.Add(string.Format("\tif not TestForRebuild(targetFile, *objects):"));
            booDefinitions.Add(string.Format("\t\tprint \"${{targetFile}} is up to date.\""));
            booDefinitions.Add(string.Format("\t\treturn"));
            booDefinitions.Add(string.Format("\tprint \"GNU GCC creates\", targetFile"));
            booDefinitions.Add(string.Format("\tstartinfo=System.Diagnostics.ProcessStartInfo()"));
            booDefinitions.Add(string.Format("\tstartinfo.FileName=GCC_LINKER_FILENAME"));
            booDefinitions.Add(string.Format("\targs=GCC_LINK_OPTIONS"));
            booDefinitions.Add(string.Format("\targs=args.Replace('$TARGET', \"\\\"\"+targetFile+\"\\\"\")"));
            booDefinitions.Add("\targs=args.Replace('$LIBOPTS', libOpts)");
            booDefinitions.Add("\tobjectsStr=''");
            booDefinitions.Add("\tfor obj in objects:");
            booDefinitions.Add("\t\tobjectsStr+=' \"'+obj+'\"'");
            booDefinitions.Add("\targs=args.Replace('$OBJECTS', objectsStr)");
            booDefinitions.Add("\tprint GCC_LINKER_FILENAME,args");
            booDefinitions.Add(string.Format("\tstartinfo.Arguments=args"));
            booDefinitions.Add(string.Format("\tstartinfo.UseShellExecute=false"));
            string vsEnvDir = GccAsCompiler._gccCPathVar.GetAsString();
            if (vsEnvDir.Length > 0)
                booDefinitions.Add(string.Format("\t\tstartinfo.EnvironmentVariables[\"CPATH\"] = \"{0}\"", vsEnvDir));
            booDefinitions.Add(string.Format("\tp=System.Diagnostics.Process.Start(startinfo)"));
            booDefinitions.Add(string.Format("\tp.WaitForExit()"));
            booDefinitions.Add(string.Format("\tif p.ExitCode!=0:"));
            booDefinitions.Add(string.Format("\t\traise System.Exception(\"Build action failed.\")"));
            #endregion
        }

        /// <summary>
        /// This method will create BOO source code and append this code to the provided text writer.
        /// </summary>
        /// <param name="env">This is an environment that different tools of the same family may use to exchange information.
        /// This store is typically used to save information on configuration files or thinsgs of that kind that will be
        /// shared among all tools of the same family.</param>
        /// <param name="booCodeLines">The code that will actually build something. Each list entry will be a line of code in the resulting
        /// BOO program.</param>
        /// <param name="indention">A string that shall preceed all created lines. </param>
        /// <remarks>Refer to IBuildActionProvider.AppendToBooPreamble() for an example.
        /// 
        /// This implementation will only provide
        /// </remarks>
        /// <exception cref="NotSupportedException">Will be thrown if this feature is not supported.</exception>
        public override void AppendBooCode(List<string> booCodeLines, string indention, BuildToolFamilyEnv env)
        {
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            sb.Append(indention);
            sb.Append("RunGccAsLinker(\"");
            sb.Append(this._output.FileNameAsBooString);
            sb.Append("\", \"");

            // finally, refer to the libraries. these shall be placed at the end
            // because we here know the undefined systems that will be searched in the
            // libraries.
            if (this._libs != null)
            {
                foreach (ContentFile libFile in this._libs)
                {
                    sb.Append(" \\\"");
                    sb.Append(libFile.FileNameAsBooString);
                    sb.Append("\\\"");
                }
            }
            if (this._elfLibs != null)
            {
                foreach (ContentFile libFile in this._elfLibs)
                {
                    sb.Append(" ");
                    if (libFile.Location == ContentFileLocation.LocalFileSystem)
                    {
                        sb.Append("\\\"");
                        sb.Append(libFile.FileNameAsBooString);
                        sb.Append("\\\"");
                    }
                    else if (libFile.Type.Implies(ContentType.Elf))
                    {
                        string liboption = System.IO.Path.GetFileNameWithoutExtension(libFile.FileName);
                        if (liboption.StartsWith("lib"))
                            liboption = liboption.Substring(3);
                        sb.AppendFormat("-l{0}", liboption);
                    }
                }
            }
            sb.Append("\"");
            if (this._resources != null)
            {
                foreach (ContentFile resFile in this._resources)
                {
                    sb.Append(", \"");
                    sb.Append(resFile.FileNameAsBooString);
                    sb.Append("\"");
                }
            }

            // list objects early since they shall be mentioned before any reference to a library.
            if (this._objects != null)
            {
                foreach (ContentFile objFile in this._objects)
                {
                    sb.Append(", \"");
                    sb.Append(objFile.FileNameAsBooString);
                    sb.Append("\"");
                }
            }
            sb.Append(")");
            booCodeLines.Add(sb.ToString());
        }
        #endregion

        #region IBuildAction Member

        /// <summary>
        /// Creates the call of the GCC as compiler.
        /// </summary>
        /// <param name="env"></param>
        /// <returns></returns>
        public override ProcessStartInfo GetProgramStartInfo(BuildToolFamilyEnv env)
        {
            System.Diagnostics.ProcessStartInfo result = new System.Diagnostics.ProcessStartInfo();
            result.FileName = this.FileName;
            System.Text.StringBuilder cmdArgs = new System.Text.StringBuilder();
            if (Environment.OSVersion.Platform == PlatformID.Unix)
                cmdArgs.Append(" -shared");
            else if (Environment.OSVersion.Platform == PlatformID.MacOSX)
                cmdArgs.Append(" -shared -dynamiclib -flat_namespace");
            else
                cmdArgs.Append(" -shared");
            cmdArgs.Append(" -o");
            cmdArgs.Append(this._output.QuotedFileName);

            if (BuildConfig.IsUnix)
            {
            }
            else if (BuildConfig.IsMacOsX)
            {
            }
            else
            {
                cmdArgs.Append(" -mthreads"); // this is MinGW only
            }

            CxxParameters parameters = (CxxParameters)BuildConfig.GetDefaultParameterOfType(typeof(CxxParameters));
            if (parameters.DebugInfo)
                cmdArgs.Append(" -ggdb");
            else
                cmdArgs.Append(" -s");

            switch (parameters.Optimization)
            {
                case CxxOptimization.CompactCode: cmdArgs.Append(" -Os"); break;
                case CxxOptimization.FastCode: cmdArgs.Append(" -O2"); break;
                case CxxOptimization.OverallOptimization: cmdArgs.Append(" -O3"); break;
                case CxxOptimization.No: cmdArgs.Append(" -O0"); break;
            }
            switch (parameters.WarningLevel)
            {
                case CxxWarningLevel.BasicWarnings: cmdArgs.Append(""); break;
                case CxxWarningLevel.ImportantWarnings: cmdArgs.Append(" -pedantic"); break;
                case CxxWarningLevel.QualityWarnings: cmdArgs.Append(" -Wall"); break;
                case CxxWarningLevel.NoWarnings: cmdArgs.Append(" -w"); break;
            }
            if (BuildConfig.GetConfig().AbortOptions == AbortOptions.TreatWarningsAsErrors)
                cmdArgs.Append(" -Werror");

            string libPath = GetGCCLibPath();
            if (libPath != null)
                cmdArgs.Append(" -L" + ContentFile.QuoteFileName(libPath));

            if (this._resources != null)
            {
                foreach (ContentFile resFile in this._resources)
                {
                    cmdArgs.Append(" ");
                    cmdArgs.Append(resFile.QuotedFileName);
                }
            }

            // list objects early since they shall be mentioned before any reference to a library.
            if (this._objects != null)
            {
                foreach (ContentFile objFile in this._objects)
                {
                    cmdArgs.Append(" ");
                    cmdArgs.Append(objFile.QuotedFileName);
                }
            }

            // special parameters my contain references to dynamic libraries and
            // shall be placed after the object files.
            string specialParameters = parameters.GetOptions(this.Name);
            if (specialParameters != null)
            {
                cmdArgs.Append(" ");
                cmdArgs.Append(specialParameters);
            }

            // finally, refer to the libraries. these shall be placed at the end
            // because we here know the undefined systems that will be searched in the
            // libraries.
            if (this._libs != null)
            {
                foreach (ContentFile libFile in this._libs)
                {
                    cmdArgs.Append(" ");
                    cmdArgs.Append(libFile.QuotedFileName);
                }
            }
            if (this._elfLibs != null)
            {
                foreach (ContentFile libFile in this._elfLibs)
                {
                    cmdArgs.Append(" ");
                    if (libFile.Location == ContentFileLocation.LocalFileSystem)
                        cmdArgs.Append(libFile.QuotedFileName);
                    else if (libFile.Type.Implies(ContentType.Elf))
                    {
                        string liboption = System.IO.Path.GetFileNameWithoutExtension(libFile.FileName);
                        if (liboption.StartsWith("lib"))
                            liboption = liboption.Substring(3);
                        cmdArgs.AppendFormat("-l{0}", liboption);
                    }
                }
            }
            if (parameters.Libraries == CxxLibraries.NoStdLibraries)
            {
                cmdArgs.Append(" -nostdlib");
            }
            if (BuildConfig.IsWindows)
            {
                cmdArgs.Append(" -Wl,--subsystem,windows -mwindows");
                if ((parameters.Libraries & CxxLibraries.GeneralOSLibraries) == CxxLibraries.GeneralOSLibraries)
                    cmdArgs.Append(" -lkernel32 -luser32 -lshell32 -ladvapi32 -lole32 -loleaut32 -lwinspool -lwinmm -luuid");
                if ((parameters.Libraries & CxxLibraries.GDILibraries) == CxxLibraries.GDILibraries)
                    cmdArgs.Append(" -lgdi32 -lcomdlg32 -lcomctl32");
                if ((parameters.Libraries & CxxLibraries.TcpAndRpcLibraries) == CxxLibraries.TcpAndRpcLibraries)
                    cmdArgs.Append(" -lrpcrt4 -lwsock32");
            }
            result.Arguments = cmdArgs.ToString();
            string vsEnvDir = GccAsCompiler._gccCPathVar.GetAsString();
            if (vsEnvDir.Length > 0)
                result.EnvironmentVariables["CPATH"] = vsEnvDir;
            return result;
        }

        /// <summary>
        /// The action may serve also as action provider.
        /// </summary>
        public IBuildActionProvider ActionProvider
        {
            get { return this; }
        }

        public static readonly string ToolName="gcc-L";

        /// <summary>
        /// The name of this tool is "gcc-c" to indicate that gcc will be used as compiler but not for linking.
        /// </summary>
        public string Name
        {
            get { return ToolName; }
        }

        /// <summary>
        /// This is of ActionPriority.Default priority.
        /// </summary>
        public ActionPriority Priority
        {
            get { return ActionPriority.Default; }
        }

        /// <summary>
        /// Executes <c>FileName</c> using the start info as produced by GetProgramStartInfo().
        /// </summary>
        /// <param name="env">Some data that tools of the same family may share.</param>
        /// <param name="validityOfBuildSystem">The validity stating when the build system (definition of the projects) have been changed.</param>
        /// <returns>True on successful build.</returns>
        public bool Execute(BuildToolFamilyEnv env, DateTime validityOfBuildSystem)
        {
            BuildConfig.HandleMessageObject("Start GCC as a linker to build {0}.", this._output.FileName);
            ErrorDataReceiver receiver = new ErrorDataReceiver(this);
            receiver.WarningClassifier = new System.Text.RegularExpressions.Regex(@"\swarning\s",
                System.Text.RegularExpressions.RegexOptions.Compiled
                | System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            receiver.ErrorClassifier = new System.Text.RegularExpressions.Regex(@"\serror\s",
                System.Text.RegularExpressions.RegexOptions.Compiled
                | System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            receiver.FilePosPattern = new System.Text.RegularExpressions.Regex(
                @"^(?<file>((\w:)?(/|\\)[^:]+)):(?<line>[\d]+):");
            wx.ProcessUtils.ProcessStarter starter = new wx.ProcessUtils.ProcessStarter(this.GetProgramStartInfo(env),
                new wx.ProcessUtils.MsgEventHandler(receiver.OnReceiveMsgEvent));
            Process process = starter.Start();
            return process.ExitCode == 0;
        }
        #endregion
    }


    /** <summary>This is the wrapper around the WINDRES.EXE resource compiler of the MinGW distribution.
    * Within this framework, this tool will be used to compile *.rc files ContentType.RCFile
    * into *.res files ContentType.ResFile. Please note, that this class of tools is not portable.
    * So, all data provided by RC-files will only be used on Windows platforms.</summary>
    */
    public class WindRes : BaseAction, IBuildActionProvider, IBuildAction
    {
        #region State
        ContentFile _src = null;
        ContentFile _output = null;
        #endregion

        #region CTor
        /** <summary>This creates an instance that serves as a build action provider.</summary>
         */
        public WindRes()
        {
        }
        #endregion

        #region BaseAction
        public override ICollection<IBuildProduct> GetPrerequisites()
        {
            ICollection<IBuildProduct> result = new List<IBuildProduct>();
            if (this._src.Count > 0)
                result.Add(this._src);
            return result;
        }

        public override bool ContainsPrerequisite(IBuildProduct prereq)
        {
            return this._src.Equals(prereq);
        }

        public override ICollection<IBuildProduct> GetTargets()
        {
            ICollection<IBuildProduct> result = new List<IBuildProduct>();
            result.Add(this._output);
            return result;
        }
        #endregion

        #region IBuildActionProvider Member

        public ICollection<OperatingSystem> ApplicableOSs
        {
            get
            {
                List<OperatingSystem> os = new List<OperatingSystem>();
                os.Add(OperatingSystem.WinXP);
                return os;
            }
        }

        /// <summary>
        /// In contrast to wx.Build.MS.RC, this does not use any variables.
        /// </summary>
        public override IDictionary<string, EnvironmentVarInfo> UsedVars
        {
            get
            {
                return null;
            }
        }

        /** <summary><c>WindRes</c></summary>
         */
        public string Name
        {
            get { return "WindRes"; }
        }

        /** <summary><c>"GNU"</c></summary>
         */
        public string ToolFamily
        {
            get { return "GNU"; }
        }

        public string Description
        {
            get { return "The COFF resource compiler shiped with MinGW."; }
        }

        /** <summary>The filename of the compiler.</summary>
         */
        public string FileName
        {
            get
            {
                string path = GccAsCompiler.GetGCCBinPath();
                if (path != null)
                    return Path.Combine(path, "windres.exe");
                else
                    return "windres.exe";
            }
        }

        /// <summary>
        /// True, if <c>FileName</c> exists.
        /// </summary>
        public bool IsAvailable
        {
            get
            {
                return File.Exists(this.FileName);
            }
        }

        public bool MayContentFilePrerequisitesSuffice(ContentType target, ICollection<ContentType> prerequisites)
        {
            if (target.Implies(ContentType.GccResObj))
            {
                // at least one prerequisite should be an rc file
                foreach (ContentType prereqType in prerequisites)
                    if (prereqType.Implies(ContentType.RCFile))
                        return true;
            }
            // the build system does currently not consider native executables.
            return false;
        }

        /** <summary> This creates files of type ContentType.ResFile. </summary> */
        public ICollection<ContentType> ContentFileTargets
        {
            get
            {
                return new ContentType[] { ContentType.GccResObj };
            }
        }

        public IBuildAction Create(BuildToolFamilyEnv env, IBuildProduct target, ICollection<IBuildProduct> prerequisites)
        {
            WindRes result = new WindRes();
            ContentFile fileTarget = (ContentFile)target;
            if (fileTarget.Type.Contains(ContentType.GccResObj))
                result._output = fileTarget;
            else
                throw new Exception("Tool windres.exe only produces COFF OBJ files.");
            foreach (IBuildProduct prereq in prerequisites)
            {
                ContentFile prereqFile = prereq as ContentFile;
                if (prereqFile != null)
                {
                    if (prereqFile.Type.Implies(ContentType.RCFile))
                    {
                        if (result._src == null)
                            result._src = prereqFile;
                        else
                            throw new Exception("Please provide exactly one RC file for each project. I cannot deal with a second or third RC file.");
                    }
                }
            }
            if (result._src == null)
                throw new Exception("Cannot create WINDRES.EXE action without RC source.");
            return result;
        }

        #endregion

        #region IBuildAction Member

        /** <summary> This is its own action provider. </summary> */
        public IBuildActionProvider ActionProvider
        {
            get { return this; }
        }

        public ActionPriority Priority
        {
            get { return ActionPriority.Default; }
        }

        public bool Execute(BuildToolFamilyEnv env, DateTime validityOfBuildSystem)
        {
            ErrorDataReceiver receiver = new ErrorDataReceiver(this);
            receiver.WarningClassifier = new System.Text.RegularExpressions.Regex(@"\swarning\s",
                System.Text.RegularExpressions.RegexOptions.Compiled
                | System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            receiver.ErrorClassifier = new System.Text.RegularExpressions.Regex(@"\serror\s",
                System.Text.RegularExpressions.RegexOptions.Compiled
                | System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            receiver.FilePosPattern = new System.Text.RegularExpressions.Regex(
                @"^(?<file>[^\(]+)\((?<line>\d+),(?<column>\d+)\)");
            wx.ProcessUtils.ProcessStarter starter = new wx.ProcessUtils.ProcessStarter(this.GetProgramStartInfo(env),
                new wx.ProcessUtils.MsgEventHandler(receiver.OnReceiveMsgEvent));
            Process process = starter.Start();
            return process.ExitCode == 0;
        }

        public override System.Diagnostics.ProcessStartInfo GetProgramStartInfo(BuildToolFamilyEnv env)
        {
            System.Diagnostics.ProcessStartInfo result = new System.Diagnostics.ProcessStartInfo();
            result.FileName = this.FileName;
            System.Text.StringBuilder cmdArgs = new System.Text.StringBuilder();

            CxxParameters parameters = (CxxParameters)BuildConfig.GetDefaultParameterOfType(typeof(CxxParameters));
            string specialParameters = parameters.GetOptions(this.Name);
            if (specialParameters != null)
            {
                cmdArgs.Append(" ");
                cmdArgs.Append(specialParameters);
            }
            foreach (string includeFile in parameters.IncludePaths)
            {
                cmdArgs.AppendFormat(" -I \"{0}\"", includeFile);
            }
            cmdArgs.AppendFormat(" {0} {1}", this._src.QuotedFileName, this._output.QuotedFileName);

            result.Arguments = cmdArgs.ToString();
            return result;
        }
        #endregion

        #region Export to BOO
        /// <summary>
        /// This will be called for any action provider before IBuildAction.AppendBooCode() is called.
        /// This provides action providers with the opportunity to import modules and create variables
        /// for global options.
        /// </summary>
        /// <param name="env">Environment containing status that can be shared among tools of the same family.</param>
        /// <param name="importModules">List of modules that shall be imported. Add required modules here. Each module
        /// will be imported exactly once (even if it occurs more than once in the list).</param>
        /// <param name="booDeclarations">Lines of code that will be added to the preamble of the BOO code.
        /// Please note, that each line may only appear once. All subsequent additions of this line of
        /// code will be ignored. These lines shall contain declarations of variables etc.</param>
        /// <param name="booDefinitions">Lines of code that that will be added before the code provided by
        /// the actions to build the system. Typically, this will contain the definition of functions
        /// that are used on building. Lines starting with "import" will only be added once to the final code. </param>
        public override void AppendToBooPreamble(BuildToolFamilyEnv env, List<string> importModules, List<string> booDeclarations, List<string> booDefinitions)
        {
            #region Declarations
            booDeclarations.Add("# Options of the MinGW WindRes.exe resource compiler");
            booDeclarations.Add(string.Format("WindResTool=\"{0}\"", ContentFile.ConvertFilenameToString(this.FileName)));
            booDeclarations.Add("WindResOptions=''");
            CxxParameters parameters = (CxxParameters)BuildConfig.GetDefaultParameterOfType(typeof(CxxParameters));
            string specialParameters = parameters.GetOptions(this.Name);
            if (specialParameters != null)
            {
                booDeclarations.Add("# these are some special options that have been declared in particular for this tool.");
                booDeclarations.Add(string.Format("WindResOptions+=\"{0}\"",ContentFile.ConvertFilenameToString( specialParameters)));
            }
            booDeclarations.Add("# Include paths are also relevant to the compilation of resources.");
            foreach (string includeFile in parameters.IncludePaths)
            {
                booDeclarations.Add(string.Format("WindResOptions+=\"  -I \\\"{0}\\\"\"", ContentFile.ConvertFilenameToBooString(includeFile)));
            }
            #endregion

            #region Definitions
            booDefinitions.Add(string.Format("def RunMinGWWindRes(target as string, source as string):"));
            booDefinitions.Add(string.Format("\tif not TestForRebuild(target, source):"));
            booDefinitions.Add(string.Format("\t\tprint target,\"is up to date\""));
            booDefinitions.Add(string.Format("\t\treturn"));
            booDefinitions.Add(string.Format("\tprint \"MinGW WindRes.exe creates\", target"));
            booDefinitions.Add(string.Format("\tstartinfo=System.Diagnostics.ProcessStartInfo()"));
            booDefinitions.Add(string.Format("\tstartinfo.FileName=WindResTool"));
            booDefinitions.Add(string.Format("\tstartinfo.Arguments=\"${{WindResOptions}} \\\"${{source}}\\\" \\\"${{target}}\\\"\""));
            booDefinitions.Add(string.Format("\tstartinfo.UseShellExecute=false"));
            booDefinitions.Add(string.Format("\tp=System.Diagnostics.Process.Start(startinfo)"));
            booDefinitions.Add(string.Format("\tp.WaitForExit()"));
            booDefinitions.Add(string.Format("\tif p.ExitCode!=0:"));
            booDefinitions.Add(string.Format("\t\traise System.Exception(\"Build action failed.\")"));
            #endregion
        }

        /// <summary>
        /// This method will create BOO source code and append this code to the provided text writer.
        /// </summary>
        /// <param name="env">This is an environment that different tools of the same family may use to exchange information.
        /// This store is typically used to save information on configuration files or thinsgs of that kind that will be
        /// shared among all tools of the same family.</param>
        /// <param name="booCodeLines">The code that will actually build something. Each list entry will be a line of code in the resulting
        /// BOO program.</param>
        /// <param name="indention">A string that shall preceed all created lines. </param>
        /// <remarks>Refer to IBuildActionProvider.AppendToBooPreamble() for an example.
        /// 
        /// This implementation will only provide
        /// </remarks>
        /// <exception cref="NotSupportedException">Will be thrown if this feature is not supported.</exception>
        public override void AppendBooCode(List<string> booCodeLines, string indention, BuildToolFamilyEnv env)
        {
            booCodeLines.Add(string.Format("{2}RunMinGWWindRes(\"{0}\", \"{1}\")", this._output.FileNameAsBooString, this._src.FileNameAsBooString, indention));
        }
        #endregion
    }

}
