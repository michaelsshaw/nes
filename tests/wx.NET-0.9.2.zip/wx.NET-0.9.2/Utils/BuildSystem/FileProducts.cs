/** Build system for wx.NET.
 * 
 * This DLL contains basic implementations to build (compile and link) C/C++ programs,
 * compile .NET assemblies written in C#, sign them, and install them.
 * 
 * \file 
 *
 * Copyright 2009 Harald Meyer auf'm Hofe harald_meyer@users.sourceforge.net
 * 
 * Licensed under the wxWidgtes license, see LICENSE.txt for details.
 * 
 * $Id: FileProducts.cs,v 1.13 2010/06/06 09:00:04 harald_meyer Exp $
 */

using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Text;
using System.IO;

namespace wx.Build
{
    /// <summary>
    /// Represents a collection of files occasionally resulting from a build step of the same ContentType.
    /// </summary>
    public interface IFileProducts : IBuildProduct, IComparable, ICloneable
    {
        /// <summary>
        /// The collection of files resulting from the bilding step.
        /// </summary>
        ContentFiles Files { get; }

        /// <summary>
        /// A collection of contained files that are addressed explicitely as instances of ContentFiles or ContentFile.
        /// </summary>
        ContentFiles ExplicitFiles { get; }

        /// <summary>
        /// True if this equals or the provided build product or the product is among its targets.
        /// </summary>
        /// <param name="arg">The build product that will be searched</param>
        bool Contains(IBuildProduct file);

        /// <summary>
        /// The type of the files resulting from this building step.
        /// </summary>
        ContentType Type { get; }

        /// <summary>
        /// The number of contained files.
        /// </summary>
        int Count { get; }

        /// <summary>
        /// Creates a copy where contained file descriptors have been changed. This will be used when
        /// projects are transformed e.g. to make a release (c.f. wx.Build.Release.MakeReleaseProject).
        /// <para>
        /// A special case occurs if <c>replacement</c> is <c>null</c>. This method can be used in this configuration
        /// to remove occurances of a file product term.
        /// </para>
        /// </summary>
        /// <exception cref="System.Exception">May occur, if the replacement is not of the same class as the old instance.</exception>
        /// <param name="oldInstance">The file descriptor that shall be replaced. If the <c>replacement</c> is <c>null</c>,
        /// all occurances of this descriptor will be removed.</param>
        /// <param name="replacemant">The file descriptor that shall be used instead of <c>oldInstance</c>. This may be <c>null</c>.
        /// In that case, all occurances of <c>oldInstance</c> will be removed.</param>
        /// <returns>A copy of this instance where all occurances of <c>oldInstance</c> have been replaced by <c>replacement</c>.
        /// The result may be <c>replacement</c> if this instance is equal to <c>oldInstance</c>.
        /// The result may be this instance if this is neither equal to <c>oldInstance</c> nor this is a container
        /// containing <c>oldInstance</c>.
        /// <para>
        /// The result is <c>null</c> if this equals <c>oldInstance</c> and the <c>replacement</c> is <c>null</c>.
        /// </para>
        /// </returns>
        IFileProducts Replace(IFileProducts oldInstance, IFileProducts replacement);

        /// <summary>
        /// You may use this method to control the form of the file name that will be used to
        /// serialize this (the original filename). The argument is a path to an existing
        /// file or directory. This will strip a directory information from this path. After
        /// that, the original file name will change to something equivalent to the absolute
        /// filename (referring to the same file) but now relative to the directory as specified
        /// by the argument.
        /// 
        /// Use this method to prepare content file instance for serialization in such a way
        /// that all file names become relative to the same directory.
        /// </summary>
        /// <param name="nameOfAValidDirOrFile">The name of an existing file or directory. This name
        /// will - if relative - be expanded using the BuildConfig. If this is <c>null</c>, this
        /// method will return without any effect. This may also be the name of a not yet existing file.
        /// In that case, however, the directory name shall exist.</param>
        /// <seealso cref="OriginalFileName"/>
        /// <exception cref="System.ArgumentException">Will be raised if the argument is neither the path
        /// to an existing file nor directory.</exception>
        void NormalizeOriginalFileName(string nameOfAValidDirOrFile);
    }

    /** <summary> Represents a single file occasionally resulting from a build step. </summary> */
    public interface ISingleFileProduct : IBuildProduct, IFileProducts
    {
        /** <summary> The file resulting from the bilding step. </summary> */
        ContentFile File { get; }
    }

    /** <summary> A simple project selecting the files in a specified directory.
     * Various projects receive all files of a particular file name extension as prerequisites
     * (for instance as source files). Use this sub-project to represent this demand. </summary> */
    public class FileSelector : IFileProducts, System.Xml.Serialization.IXmlSerializable, ICloneable
    {
        #region State
        string _description;

        ContentType _type;
        string _filter;
        string _directory;
        string _originalDirectory;
        #endregion

        #region CTor
        /// <summary>
        /// Selector of all executables as .NET programs.
        /// Use only to create an instance for ReadXml().
        /// </summary>
        public FileSelector() : this(ContentType.DotNetExe, ".", "*.exe", ".NET programs.")
        {
        }

        /** <summary> Creates a selector "producing" all files within a certain directory that comply with the specified filter expression.</summary><remarks>
         * \param type is the content type that will be assumed for the selected files.
         * \param directory is the path to a directory. This may be a relative path name. Relative path names
         *        will be combined with the path name of the entry assembly's directory.
         * \param filter is a file filter expression containing wildcards * and ?. Do not use ".." here. Refer to <c>System </c> .Directory.GetFiles().
         * \param description is a descriptive text on the selected files. </remarks> */
        public FileSelector(ContentType type, string directory, string filter, string description)
        {
            this._type = type;
            this._originalDirectory = directory;
            this._directory = BuildConfig.GetFullPathname(directory);
            this._filter = filter;
            this._description = description;
        }

        /// <summary>
        /// Copy CTor
        /// </summary>
        /// <param name="src">The source</param>
        public FileSelector(FileSelector src)
            : this(src._type, src._directory, src._filter, src._description)
        {
        }
        #endregion

        /** <summary> Derived from the directory and the filter expression. </summary> */
        public string Name
        {
            get { return System.IO.Path.Combine(this._directory, this._filter); }
        }

        public string Description
        {
            get { return this._description; }
        }

        /** <summary> This will produce an error if the directory does not exist.
         * \return true on success and false on failure, that should however also be reported to the error handler. </summary> */
        public bool Execute(BuildToolFamilyEnv env, DateTime validityOfBuildSystem)
        {
            if (!System.IO.Directory.Exists(this._directory))
            {
                BuildConfig.HandleErrorObject(new ErrorObject(ErrorObject.MessageType.Error, "Expect {0} to be a directory.", this._directory));
                return false;
            }
            else
                return true;
        }

        public ICollection<IBuildProduct> GetTargets()
        {
            return this.Files.GetTargets();
        }

        /** <summary> This returns <c>null </c>  because this does not imply build projects. </summary> */
        public ICollection<RefToProject> GetProjects()
        {
            return null;
        }


        #region IFileProducts Member

        public ContentFiles Files
        {
            get
            {
                string[] filenames = System.IO.Directory.GetFiles(this._directory, this._filter);
                ContentFiles result = new ContentFiles(this.Type);
                foreach (string selFilename in filenames)
                {
                    string filename=Path.GetFileName(selFilename);
                    filename = Path.Combine(this._originalDirectory, filename);
                    result.Add(new ContentFile(this._type, filename));
                }
                return result;
            }
        }

        /// <summary>
        /// A collection of contained files that are addressed explicitely as instances of ContentFiles or ContentFile.
        /// </summary>
        public ContentFiles ExplicitFiles
        {
            get
            {
                return this.Files;
            }
        }

        /// <summary>
        /// True if this equals or the provided build product or the product is among its targets.
        /// </summary>
        /// <param name="arg">The build product that will be searched</param>
        public bool Contains(IBuildProduct file)
        {
            if (this.Equals(file))
                return true;
            if (file is ContentFile)
                return ((ContentFile)file).FileName.StartsWith(this._directory);
            else
                return false;
        }

        public int Count
        {
            get
            {
                return this.Files.Count;
            }
        }

        /** <summary> The type of the produced files. </summary> */
        public ContentType Type
        {
            get
            {
                return this._type;
            }
        }

        /// <summary>
        /// A helper for those projects that implement IFileProduct.
        /// </summary>
        /// <param name="oldInstance">This is a file descriptor that shall be replaced.</param>
        /// <param name="replacement">This is a file descriptor that shall be used instead.</param>
        /// <returns>The <c>replacement</c> if this equals <c>oldInstance</c> or <c>this</c> if otherwise this
        /// implements IFileProducts or <c>null</c>.</returns>
        public IFileProducts Replace(IFileProducts oldInstance, IFileProducts replacement)
        {
            if (this.Equals(oldInstance))
                return replacement;
            else
                return this as IFileProducts;
        }

        /// <summary>
        /// You may use this method to control the form of the file name that will be used to
        /// serialize this (the original filename). The argument is a path to an existing
        /// file or directory. This will strip a directory information from this path. After
        /// that, the original file name will change to something equivalent to the absolute
        /// filename (referring to the same file) but now relative to the directory as specified
        /// by the argument.
        /// 
        /// Use this method to prepare content file instance for serialization in such a way
        /// that all file names become relative to the same directory.
        /// </summary>
        /// <param name="nameOfAValidDirOrFile">The name of an existing file or directory. This name
        /// will - if relative - be expanded using the BuildConfig. If this is <c>null</c>, this
        /// method will return without any effect. This may also be the name of a not yet existing file.
        /// In that case, however, the directory name shall exist.</param>
        /// <seealso cref="OriginalFileName"/>
        /// <exception cref="System.ArgumentException">Will be raised if the argument is neither the path
        /// to an existing file nor directory.</exception>
        public void NormalizeOriginalFileName(string nameOfAValidDirOrFile)
        {
            this._originalDirectory=ContentFile.NormalizedFilename(this._directory, nameOfAValidDirOrFile);
        }
        #endregion

        #region IBuildProduct Member

        public DateTime GetValidity()
        {
            return this.Files.GetValidity();
        }

        public DateTime GetValidityDemand()
        {
            return this.Files.GetValidityDemand();
        }

        #endregion

        #region Overrides
        public override bool Equals(object obj)
        {
            return this.CompareTo(obj)==0;
        }

        public override int GetHashCode()
        {
            return this._directory.GetHashCode() ^ this._filter.GetHashCode();
        }

        public override string ToString()
        {
            return string.Format("{0}:{1}/{2} ({3})", this._type, this._directory, this._filter, this._description);
        }
        #endregion

        #region IComparable Member

        public int CompareTo(object obj)
        {
            if (obj is FileSelector)
            {
                FileSelector arg = (FileSelector)obj;
                int cmp = 0;
                if (cmp == 0)
                    cmp = this._directory.CompareTo(arg._directory);
                if (cmp == 0)
                    cmp = this._filter.CompareTo(arg._filter);
                if (cmp == 0)
                    cmp = this._type.CompareTo(arg._type);
                return cmp;
            }
            else
                return this.GetType().FullName.CompareTo(obj.GetType().FullName);
        }

        #endregion

        #region IXmlSerializable Member

        public System.Xml.Schema.XmlSchema GetSchema()
        {
            return null;
        }

        public void ReadXml(System.Xml.XmlReader reader)
        {
            reader.ReadStartElement("file-selector");
            this._description=reader.ReadElementString("description");
            this._originalDirectory = reader.ReadElementString("directory");
            this._directory = BuildConfig.GetFullPathname(this._originalDirectory);
            this._filter = reader.ReadElementString("filter");
            this._type = ContentType.FromXml(reader);
            reader.ReadEndElement();
        }

        public void WriteXml(System.Xml.XmlWriter writer)
        {
            writer.WriteStartElement("file-selector");
            writer.WriteElementString("description", this._description);
            writer.WriteElementString("directory", this._originalDirectory);
            writer.WriteElementString("filter", this._filter);
            this._type.WriteRefXml(writer);
            writer.WriteEndElement();
        }

        #endregion

        #region ICloneable Member

        public object Clone()
        {
            return new FileSelector(this);
        }

        #endregion
    }

    /// <summary> This is a collection of instances of IFileProduct that itself is an implementation of IFileProducts.
    /// You will need this class when specifying dependencies of projects that, for instance, on the one hand are content
    /// files and on the other hand targets of other projects.
    /// </summary>
    public class FileProducts : IFileProducts, IComparable, System.Xml.Serialization.IXmlSerializable, ICloneable
    {
        #region State
        List<IFileProducts> _collection = new List<IFileProducts>();
        ContentType _type;
        #endregion

        #region CTor
        /// <summary>
        /// Default CTor. Do not use except for the preparation of ReadXml().
        /// </summary>
        public FileProducts()
        {
            this._type = ContentType.DotNetExe;
        }

        /** <summary> Creates an instance enumerating files of the provided type. </summary> */
        public FileProducts(ContentType type)
        {
            this._type = type;
        }

        public FileProducts(FileProducts src) : this(src.Type)
        {
            foreach (IFileProducts products in src._collection)
                this.Add((IFileProducts)products.Clone());
        }

        /** <summary> Creates an instance enumerating files of the provided type. </summary> */
        public FileProducts(ContentType type, params IFileProducts[] initialProducts)
            : this(type)
        {
            foreach (IFileProducts products in initialProducts)
                this.Add(products);
        }
        #endregion

        #region Public Methods
        /** <summary> Adds <c>fileDesignator </c> .
         * <c>Files </c>  and <c>GetTargets </c>  will also return all files contained by <c>fileDesignator </c> .
         * This will raise an <c>ArgumentException </c>  if the content type of the files in <c>fileDesignator </c> 
         * is not contained by this type. </summary> */
        public void Add(IFileProducts fileDesignator)
        {
            if (this.Type.Contains(fileDesignator.Type))
            {
                if (fileDesignator is FileProducts)
                    this._collection.AddRange(((FileProducts)fileDesignator)._collection);
                else
                    this._collection.Add(fileDesignator);
            }
            else
                throw new ArgumentException(string.Format("Cannot add files of type {1} to a collection of type {0}.", this.Type, fileDesignator.Type));
        }

        public ICollection<IFileProducts> Contents
        {
            get { return this._collection; }
        }
        #endregion

        #region IFileProducts Member

        public ContentFiles Files
        {
            get
            {
                ContentFiles result = new ContentFiles(this.Type);
                foreach (IFileProducts files in this._collection)
                    result.AddRange(files.Files);
                return result;
            }
        }

        /// <summary>
        /// A collection of contained files that are addressed explicitely as instances of ContentFiles or ContentFile.
        /// </summary>
        public ContentFiles ExplicitFiles
        {
            get
            {
                ContentFiles result = new ContentFiles(this.Type);
                foreach (IFileProducts files in this._collection)
                    result.AddRange(files.ExplicitFiles);
                return result;
            }
        }

        /// <summary>
        /// True if this equals or the provided build product or the product is among its targets.
        /// </summary>
        /// <param name="arg">The build product that will be searched</param>
        public bool Contains(IBuildProduct file)
        {
            if (this.Equals(file))
                return true;
            if (file is ContentFile)
            {
                foreach (IFileProducts files in this._collection)
                    if (files.Contains(file))
                        return true;
            }
            return false;
        }

        public int Count
        {
            get
            {
                int result = 0;
                foreach (IFileProducts files in this._collection)
                    result += files.Count;
                return result;
            }
        }

        public ContentType Type
        {
            get { return this._type; }
        }


        /// <summary>
        /// A helper for those projects that implement IFileProduct.
        /// </summary>
        /// <param name="oldInstance">This is a file descriptor that shall be replaced.</param>
        /// <param name="replacement">This is a file descriptor that shall be used instead.</param>
        /// <returns>The <c>replacement</c> if this equals <c>oldInstance</c> or <c>this</c> if otherwise this
        /// implements IFileProducts or <c>null</c>.</returns>
        public IFileProducts Replace(IFileProducts oldInstance, IFileProducts replacement)
        {
            if (this.Equals(oldInstance))
                return replacement;
            else
            {
                bool changed=false;
                FileProducts result = new FileProducts(this.Type);
                foreach (IFileProducts fd in this._collection)
                {
                    if (fd.Contains(oldInstance))
                    {
                        changed = true;
                        IFileProducts newFd = fd.Replace(oldInstance, replacement);
                        if (newFd != null)
                            result.Add(newFd);
                    }
                    else
                        result.Add(fd);
                }
                if (changed)
                {
                    if (result.Count == 0)
                        return null;
                    else if (result.Count == 1)
                        return result._collection[0];
                    else
                        return result;
                }
                else
                    return this;
            }
        }

        /// <summary>
        /// You may use this method to control the form of the file name that will be used to
        /// serialize this (the original filename). The argument is a path to an existing
        /// file or directory. This will strip a directory information from this path. After
        /// that, the original file name will change to something equivalent to the absolute
        /// filename (referring to the same file) but now relative to the directory as specified
        /// by the argument.
        /// 
        /// Use this method to prepare content file instance for serialization in such a way
        /// that all file names become relative to the same directory.
        /// </summary>
        /// <param name="nameOfAValidDirOrFile">The name of an existing file or directory. This name
        /// will - if relative - be expanded using the BuildConfig. If this is <c>null</c>, this
        /// method will return without any effect. This may also be the name of a not yet existing file.
        /// In that case, however, the directory name shall exist.</param>
        /// <seealso cref="OriginalFileName"/>
        /// <exception cref="System.ArgumentException">Will be raised if the argument is neither the path
        /// to an existing file nor directory.</exception>
        public void NormalizeOriginalFileName(string nameOfAValidDirOrFile)
        {
            foreach (IFileProducts p in this._collection)
                p.NormalizeOriginalFileName(nameOfAValidDirOrFile);
        }
        #endregion

        #region IBuildProduct Member

        /** <summary> This returns <c>null </c>  because this does not imply build projects. </summary> */
        public ICollection<RefToProject> GetProjects()
        {
            List<RefToProject> result = new List<RefToProject>();
            foreach (IFileProducts fileProject in this._collection)
            {
                ICollection<RefToProject> subProjects = fileProject.GetProjects();
                if (subProjects != null)
                    result.AddRange(subProjects);
            }
            return result;
        }
 
        /** <summary> The earliest validity of a contained file. </summary> */
        public DateTime GetValidity()
        {
            DateTime result = DateTime.MaxValue;
            foreach (IFileProducts files in this._collection)
            {
                DateTime thisResult = files.GetValidity();
                if (thisResult < result)
                    result = thisResult;
            }
            return result;
        }

        /** <summary> The latest validity of a contained file. </summary> */
        public DateTime GetValidityDemand()
        {
            DateTime result = DateTime.MinValue;
            foreach (IFileProducts files in this._collection)
            {
                DateTime thisResult = files.GetValidityDemand();
                if (thisResult > result)
                    result = thisResult;
            }
            return result;
        }

        #endregion

        #region Overrides
        public override int GetHashCode()
        {
            int result = this._type.GetHashCode();
            foreach (IFileProducts contained in this._collection)
                result = result ^ contained.GetHashCode();
            return result;
        }

        public override bool Equals(object obj)
        {
            return this.CompareTo(obj)==0;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            foreach (IFileProducts contained in this._collection)
            {
                if (sb.Length > 0)
                    sb.Append(",");
                sb.Append(contained.ToString());
            }
            return sb.ToString();
        }
        #endregion

        #region IComparable Member

        public int CompareTo(object obj)
        {
            if (obj is FileProducts)
            {
                int argcount = ((FileProducts)obj).Count;
                if (this._collection.Count != argcount)
                    return this._collection.Count.CompareTo(argcount);

                SortedDictionary<IBuildProduct, IBuildProduct> thiscollection = new SortedDictionary<IBuildProduct, IBuildProduct>();
                foreach (IBuildProduct fp in this._collection)
                    thiscollection.Add(fp, fp);
                SortedDictionary<IBuildProduct, IBuildProduct> argcollection = new SortedDictionary<IBuildProduct, IBuildProduct>();
                foreach (IBuildProduct fp in ((FileProducts)obj)._collection)
                    argcollection.Add(fp, fp);

                IEnumerator<IBuildProduct> iThisElem = thiscollection.Keys.GetEnumerator();
                IEnumerator<IBuildProduct> iArgElem = argcollection.Keys.GetEnumerator();
                while (iThisElem.MoveNext() && iArgElem.MoveNext())
                {
                    int cmp = iThisElem.Current.CompareTo(iArgElem.Current);
                    if (cmp != 0)
                        return cmp;
                }
                return 0;
            }
            else
                return this.GetType().FullName.CompareTo(obj.GetType().FullName);
        }

        #endregion

        #region IXmlSerializable Member

        public System.Xml.Schema.XmlSchema GetSchema()
        {
            return null;
        }

        public void ReadXml(System.Xml.XmlReader reader)
        {
            this._collection.Clear();
            reader.ReadStartElement("file-products");
            this._type=ContentType.FromXml(reader);
            while (reader.IsStartElement())
            {
                string assemblyName = reader.GetAttribute("assembly");
                string typeName = reader.GetAttribute("type");
                System.Reflection.Assembly assembly = typeof(BuildProject).Assembly;
                if (assemblyName != null)
                    assembly = System.Reflection.Assembly.Load(assemblyName);
                System.Type t = assembly.GetType(typeName);
                reader.ReadStartElement("element");
                IFileProducts elem = (IFileProducts)System.Activator.CreateInstance(t);
                elem.ReadXml(reader);
                reader.ReadEndElement();
                this._collection.Add(elem);
            }
            reader.ReadEndElement();
        }

        public void WriteXml(System.Xml.XmlWriter writer)
        {
            writer.WriteStartElement("file-products");
            this._type.WriteRefXml(writer);
            foreach (IFileProducts elem in this._collection)
            {
                writer.WriteStartElement("element");
                if (elem.GetType().Assembly != typeof(Build.BuildProject).Assembly)
                    writer.WriteAttributeString("assembly", elem.GetType().Assembly.FullName);
                writer.WriteAttributeString("type", elem.GetType().FullName);
                elem.WriteXml(writer);
                writer.WriteEndElement();
            }
            writer.WriteEndElement();
        }

        #endregion

        #region ICloneable Member

        public object Clone()
        {
            return new FileProducts(this);
        }

        #endregion
    }
}
