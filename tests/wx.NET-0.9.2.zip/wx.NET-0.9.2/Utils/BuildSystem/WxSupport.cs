  /** Build system for wx.NET.
  * 
  * Provides means to use \e wxWidgets.
  * 
  * \file 
  *
  * Copyright 2009 Harald Meyer auf'm Hofe harald_meyer@users.sourceforge.net
  * 
  * Licensed under the wxWidgets license, see LICENSE.txt for details.
  * 
  * $Id: WxSupport.cs,v 1.17 2010/06/19 13:44:37 harald_meyer Exp $
  */
  
  using System;
  using System.Collections.Generic;
  using System.IO;
  using System.Diagnostics;
  
  using wx.Build;
  
  /** <summary> This namespace provides components for the support of wxWidgets. </summary> */
  namespace wx.Build.Cxx
  {
  
      /** <summary>Bit-vektor of options of the \e wxWidgets library.</summary>
      */
      [Flags]
      public enum wxStyles
      {
          /** <summary>Use this if you do not want to specify something explicitely.</summary>
          */
          Unspecified = 0,
  
          /** <summary>This will enforce use of the libraries supporting Unicode.
          * Please note, that this can be overloaded by defining variable WXUNICODE.</summary>
          */
          Use_Unicode = 1,
  
          /** <summary>This will include the contributed STC implementation.</summary>
          */
          Use_StyledtextControl = 2,
  
          /** <summary>Tells the project to include GCC libraries.
          * Users are not obliged to specify this style. It will be specified implicitely, if nothing
          * in <c>Platform_Constraints</c> has been defined. </summary>
          */
          Use_GccLibraries = 4,
  
          /** <summary>Tells the project to include libraries that fit the MS VC++ compiler and linker.
          * Users are not obliged to specify this style. It will be specified implicitely, if nothing
          * in <c>Platform_Constraints</c> has been defined. </summary>
          */
          Use_CoffLibraries = 8,
  
          /// <summary>
          /// Under Linux this tells this module to use static libs.
          /// This corresponds to <c>wx-config --static=yes</c>.
          /// Please note, that wxWidgets by default consists of position dependant
          /// code when compiled to a static lib. You must explicitely add -fPIC
          /// to the CXX_FLAGS if you use this feature since libwx-c.so must be a dynamic
          /// library that must be position independant.
          /// </summary>
          Use_StaticLibs = 16,
          
          /** <summary>This is the combination of all bits referring to the platform.
          * Use this if you expect  that the wxWidgets installation has been compiled for
          * any supported platform.</summary>
          */
          Platform_Constraints = Use_GccLibraries | Use_CoffLibraries,
  
          /** Use this if you suspect the wxWidgets installation to be compiled with optimal features.
          * This currently assumes Unicode use and STC support.
          */
          Features = Use_Unicode | Use_StyledtextControl
      }
  
      /** <summary>Use this tool to refer to a prebuilt instance of the \e wxWidgets libraries.
      * This tool is intended to build the \e wxWidgets system is necessary. However, this is currently not 
      * supported. This action will raise an exception if \e wxWidgets cannot be found.
      * </summary>
      * <remarks> 
      * However, this tool also provides means to adopt parameters for C++ compilation and linking, and its
      * target shall be used as input to any native code project that uses \e wxWidgets.
      * This build action uses environment variable \c WXWIN to point at the currently relevant instance
      * of the library. If this variable is not defined, this will search for an appropriate installation at
      * the commonly used directories "C:\wxWidgets-2.8.9", "C:\wxWidgets-2.8.8", etc. 
      * </remarks>
      */
      public class wxWidgets : FileProject
      {
          #region State
          wxStyles _styles;
          #endregion
  
          #region Static Helpers
          /// <summary>
          /// Base names of the libraries of wxWidgets.
          /// The array is organized in rows of 4 columns.
          /// The first column contains the base name of the library. The second on
          /// some postfix addition like "_html". The third one contains an empty string
          /// or "u" if the library can be linked in a version containing UTF support.
          /// The last column contains the name of a feature if the library is only
          /// relevant to the system if a certein feature is required.
          /// 
          /// The libraries mut be presented in an order that allows the GCC to link
          /// them. If a library requires implementations from other libraries, it
          /// must be placed before them.
          /// </summary>
          static readonly string[] LibsBasenames = new string[] { "wxmsw28", "_xrc", "u", "", "wxmsw28", "_adv", "u", "", "wxmsw28", "_aui",
          "u", "", "wxmsw28", "_html", "u", "", "wxmsw28", "_media", "u", "",
          "wxmsw28", "_qa", "u", "", "wxmsw28", "_richtext", "u", "", "wxmsw28", "_stc",
          "u", "WXNET_STYLEDTEXTCTRL", "wxmsw28", "_core", "u", "", "wxbase28", "_net", "u", "",
          "wxbase28", "_xml", "u", "", "wxbase28", "", "u", "", "wxregex", "",
          "u", "", "wxexpat", "", "", "", "wxjpeg", "", "", "",
          "wxpng", "", "", "", "wxtiff", "", "", "", "wxzlib", "",
          "", "" };
  
          /// <summary>
          /// The option that will be passed to wx-config (on building with Unix)
          /// to define the wxWidgets version to be used.
          /// </summary>
          static readonly string _wxConfigVersion="--version=2.8 ";
          
          /// <summary>
          /// This method will call wx-config for the version according to <c>_wxConfigVersion</c>
          /// and return the resulting ouput as string.
          /// </summary>
          /// <param name="flag">
          /// This is the argument for wx-config like <c>--cxxflags</c>.
          /// </param>
          /// <param name="debugMode">indicates with true that a debug configuration shall be used.
          /// </param>
          /// <param name="styles">Describe the flavour of wxwidgets that shall be used. </param>
          /// <returns>An array of strings with 2 elements: Element 0 is the output on the output
          /// stream. Element 1 is the output on the error stream.</returns>
          static string[] GetWxConfigOutput(bool debugMode, wxStyles styles, string flag)
          {
              ProcessStartInfo wxConfigCall=new ProcessStartInfo("wx-config");
              string wxConfigPath=BaseDir;
              if (wxConfigPath != null)
                  wxConfigCall.WorkingDirectory=wxConfigPath;
              System.Text.StringBuilder args=new System.Text.StringBuilder();
              args.Append(_wxConfigVersion);
              if (debugMode)
                  args.Append("--debug ");
              if ((styles & wxStyles.Use_Unicode)==wxStyles.Use_Unicode)
              {
                  args.Append("--unicode ");
              }
              if ((styles & wxStyles.Use_StaticLibs)==wxStyles.Use_StaticLibs)
                  args.Append("--static=yes ");
              args.Append(flag);
              wxConfigCall.Arguments=args.ToString();
              System.Text.StringBuilder errorInfo=new System.Text.StringBuilder();
              System.Text.StringBuilder output=new System.Text.StringBuilder();
              wx.ProcessUtils.ProcessStarter starter=new wx.ProcessUtils.ProcessStarter(wxConfigCall,
                delegate (object sender, wx.ProcessUtils.MsgEventArgs evt)
                {
                   output.AppendLine(evt.Msg);
                },
                delegate (object sender, wx.ProcessUtils.MsgEventArgs evt)
                {
                   errorInfo.Append(evt.Msg);
                });
              Process p=starter.Start();
              if (p.ExitCode != 0)
              {
                  throw new Exception("I could not find wx-config or the following arguments returned an error: "+args.ToString()+".");
              }
              return new string[] {output.ToString(), errorInfo.ToString().Trim(' ', '\n', '\r', 't')};
          }
          
          /// <summary>
          /// Creates the reference to the library files-
          /// </summary>
          /// <param name="debugMode">
          /// Defines with <c>true</c> to use a debug version of wxWidgets.
          /// </param>
          /// <param name="styles">
          /// A <see cref="wxStyles"/>. Defines the version f wxWidgets to be used.
          /// </param>
          /// <returns>
          /// A <see cref="ContentFiles"/>
          /// </returns>
          static ContentFiles GetGccTargets (bool debugMode, wxStyles styles)
          {
              if (BuildConfig.NotWindows)
              {
                  #region Linux procedure: Run wx-config. However, use BaseDir as path to this program
                  string output=GetWxConfigOutput(debugMode, styles, "--libs")[0];
                  ContentFiles result=new ContentFiles(
                      ((styles&wxStyles.Use_StaticLibs)==wxStyles.Use_StaticLibs)
                      ? ContentType.GccLib
                      : ContentType.Elf);
                  foreach(string option in output.Split(' '))
                  {
                      string trimmedOption=option.Trim();
                      if (trimmedOption.StartsWith("-lwx"))
                      {
                          ContentFile newFile;
                          if ((styles&wxStyles.Use_StaticLibs)==wxStyles.Use_StaticLibs)
                              newFile = new ContentFile(result.Type, ContentFileLocation.InConfiguredDirectories, string.Format("lib{0}.a", trimmedOption.Substring(2)));
                          else
                              newFile = new ContentFile(result.Type, ContentFileLocation.InConfiguredDirectories, string.Format("lib{0}.so", trimmedOption.Substring(2)));
                          result.Add(newFile);
                      }
                  }
                  if ((styles&wxStyles.Use_StyledtextControl)==wxStyles.Use_StyledtextControl)
                  {
                      string unicodeFlag="";
                      if ((styles&wxStyles.Use_Unicode)==wxStyles.Use_Unicode)
                          unicodeFlag="u";
                      string debugFlag="";
                      if (debugMode)
                          debugFlag="d";
                      
                      string suffix=".so";
                      if ((styles&wxStyles.Use_StaticLibs)==wxStyles.Use_StaticLibs)
                          suffix=".a";
                      result.Add(new ContentFile(result.Type, ContentFileLocation.InConfiguredDirectories, string.Format("libwx_gtk2{0}{1}_stc-2.8{2}", unicodeFlag, debugFlag, suffix)));
                  }
                  return result;
                  #endregion
              }
              else
              {
                  #region Procedure for Windows: Search for a wxWidgets directory
                  string wxLibBase = BaseDir;
                  if (wxLibBase != null) {
                      wxLibBase = System.IO.Path.Combine (wxLibBase, "lib");
                      wxLibBase = System.IO.Path.Combine (wxLibBase, "gcc_lib");
                  }
                  ContentFiles result = new ContentFiles (ContentType.GccLib);
                  for (int i = 0; i < LibsBasenames.Length; i += 4) {
                      string filename = "lib" + LibsBasenames[i];
                      if (LibsBasenames[i + 1] == "_stc" && (styles & wxStyles.Use_StyledtextControl) != wxStyles.Use_StyledtextControl)
                          continue;
                      // STC not enabled
                      if ((styles & wxStyles.Use_Unicode) == wxStyles.Use_Unicode && LibsBasenames[i + 2].Contains ("u"))
                          filename += "u";
                      if (debugMode)
                          filename += "d";
                      filename += LibsBasenames[i + 1];
                      filename += ".a";
                      if (wxLibBase != null)
                          filename = System.IO.Path.Combine (wxLibBase, filename);
                      result.Add (new ContentFile (ContentType.GccLib, ContentFileLocation.InConfiguredDirectories, filename));
                  }
                  return result;
                  #endregion
              }
          }
  
          static ContentFiles GetMSVCTargets (bool debugMode, wxStyles styles)
          {
              string wxLibBase = BaseDir;
              if (wxLibBase != null) {
                  wxLibBase = System.IO.Path.Combine (wxLibBase, "lib");
                  wxLibBase = System.IO.Path.Combine (wxLibBase, "vc_lib");
              }
              ContentFiles result = new ContentFiles (ContentType.VCCoffLib);
              for (int i = 0; i < LibsBasenames.Length; i += 4) {
                  string filename = LibsBasenames[i];
                  if (LibsBasenames[i + 1] == "_stc" && (styles & wxStyles.Use_StyledtextControl) != wxStyles.Use_StyledtextControl)
                      continue;
                  // STC not enabled
                  if ((styles & wxStyles.Use_Unicode) == wxStyles.Use_Unicode && LibsBasenames[i + 2].Contains ("u"))
                      filename += "u";
                  if (debugMode)
                      filename += "d";
                  filename += LibsBasenames[i + 1];
                  filename += ".lib";
                  if (wxLibBase != null)
                      filename = System.IO.Path.Combine (wxLibBase, filename);
                  result.Add (new ContentFile (ContentType.VCCoffLib, filename));
              }
              return result;
          }
          #endregion
  
          #region CTor
          /// <summary>
          /// Creates a project with unspecific style.
          /// </summary>
          public wxWidgets () : this(wxStyles.Unspecified)
          {
              if (!_unicodeVar.IsEmpty ()) {
                  if ((bool)_unicodeVar.Get ())
                      this._styles = this._styles | wxStyles.Use_Unicode;
                  else
                      this._styles = this._styles & ~wxStyles.Use_Unicode;
              }
          }
  
          /** <summary>Creates the project presupposing the properties as specified by the provided style flags.
          * The current implementation will not check whether the current wxWidgets installation provides
          * all the specified features. Nevertheless, the styles will be used to refer to the correct library
          * and setup files.
          * </summary>
          * <remarks>
          * Please note, that MS VC platform will be removed from the specification if the build process
          * runs Unix/Linux.
          * 
          * Since this project does not need modifiers, this will be made ready automatically on instance
          * creation (cf. BuildProject.GetSingleton()).
          * </remarks>
          * <example>
          * <code>
          * wx.Build.Cxx.wxWidgets wxProject = new wx.Build.Cxx.wxWidgets(wx.Build.Cxx.wxStyles.Use_StyledtextControl
          *   // The Unicode style below is recommended but not required. You may remove it.
          *   | wx.Build.Cxx.wxStyles.Use_Unicode);
          * Cxx.DynamicLibraryProject wxcProject = new wx.Build.Cxx.DynamicLibraryProject(ProjectPreference.Default,
          *   "wx-c",
          *   ".", "wx-c",
          *   "The native code of the wx.NET project.");
          * wxcProject.AddStaticLibrary(wxProject.CreateRefToFileProject());
          * wxcProject.AddCPlusPlusSources(new FileSelector(ContentType.CPlusPlusCode, "..\\Src\\wx-c", "*.cxx", "wx.NET C++ sources."));
          * wxcProject.AddHeaderFiles(new FileSelector(ContentType.CCPlusPlusInclude, "..\\Src\\wx-c", "*.h", "wx.NET C++ includes."));
          * wxcProject.AddRCFile(new ContentFile(ContentType.RCFile, "..\\Src\\wx-c\\windows.rc"));
          * return wxcProject.GetSingleton();
          * </code>
          * </example>
          */
          public wxWidgets (wxStyles styles) : base(System.Reflection.Assembly.GetCallingAssembly (), ProjectPreference.DoNotOffer, "wxWidgets")
          {
              this._styles = styles;
              // If the argumetn does not contain any specifications regarding the platform,
              // we assume all available platforms to be viable.
              if ((this._styles & wxStyles.Platform_Constraints) == wxStyles.Unspecified)
                  this._styles = this._styles | wxStyles.Platform_Constraints;
              if (Environment.OSVersion.Platform == PlatformID.Unix)
                  this._styles = (this._styles & ~wxStyles.Use_CoffLibraries);
              
              if (!_unicodeVar.IsEmpty ()) {
                  if ((bool)_unicodeVar.Get ())
                      this._styles = this._styles | wxStyles.Use_Unicode;
                  else
                      this._styles = this._styles & ~wxStyles.Use_Unicode;
              }
          }
          #endregion
  
          #region BuildProject overrides
        /** <summary>This will modify the argument in such a way that users of \e wxWidgets can be compiled.</summary>
          */
          public override bool AdoptConfig (BuildConfig buildConfig)
          {
              bool changed = false;
              CxxParameters stdParam = (CxxParameters)buildConfig[typeof(CxxParameters)];
              Net.NetCompilerParameters netParam = (Net.NetCompilerParameters)buildConfig[typeof(Net.NetCompilerParameters)];
              CxxLibraries originalLibraries = stdParam.Libraries;
              stdParam.Libraries |= CxxLibraries.BasicCLibraries | CxxLibraries.BasicCPlusPlusLibraries;
              stdParam.Libraries |= CxxLibraries.GeneralOSLibraries;
              stdParam.Libraries |= CxxLibraries.GDILibraries;
              stdParam.Libraries |= CxxLibraries.TcpAndRpcLibraries;
              if (stdParam.Libraries != originalLibraries) {
                  BuildConfig.HandleMessageObject ("Project {0} added standard libraries to the C++ parameters.", this.Name, this);
                  changed = true;
              }
              if (!netParam.Features.ContainsSymbol ("WXWIN_COMPATIBILITY_2_6"))
              {
                  netParam.Features.Add(new FeatureEntry("WXWIN_COMPATIBILITY_2_6", "Use wxWidgets in compatibility mode with version 2.6.", "WXWIN_COMPATIBILITY_2_6"), true);
                  BuildConfig.HandleMessageObject ("Project {0} adds new C# feature WXWIN_COMPATIBILITY_2_6.", this.Name, this);
                  changed = true;
              }
              if (!stdParam.Features.ContainsSymbol ("WXWIN_COMPATIBILITY_2_6"))
              {
                  stdParam.Features.Add(new FeatureEntry("WXWIN_COMPATIBILITY_2_6", "Use wxWidgets in compatibility mode with version 2.6.", "WXWIN_COMPATIBILITY_2_6"), true);
                  BuildConfig.HandleMessageObject ("Project {0} adds new C++ feature WXWIN_COMPATIBILITY_2_6.", this.Name, this);
                  changed = true;
              }
              if (!netParam.Features.ContainsSymbol("WXNET_DISPLAY"))
              {
                  netParam.Features.Add(new FeatureEntry("WXNET_DISPLAY", "Use wxWidgets display interface.", "WXNET_DISPLAY"), true);
                  BuildConfig.HandleMessageObject ("Project {0} adds new C# feature WXNET_DISPLAY.", this.Name, this);
                  changed = true;
              }
              if (!stdParam.Features.ContainsSymbol("WXNET_DISPLAY"))
              {
                  stdParam.Features.Add(new FeatureEntry("WXNET_DISPLAY", "Use wxWidgets display interface.", "WXNET_DISPLAY"), true);
                  BuildConfig.HandleMessageObject ("Project {0} adds new C++ feature WXNET_DISPLAY.", this.Name, this);
                  changed = true;
              }
              if ((this._styles & wxStyles.Use_StyledtextControl) == wxStyles.Use_StyledtextControl && !netParam.Features.ContainsSymbol("WXNET_STYLEDTEXTCTRL"))
              {
                  netParam.Features.Add(new FeatureEntry("WXNET_STYLEDTEXTCTRL", "Use styled text control.", "WXNET_STYLEDTEXTCTRL"), true);
                  BuildConfig.HandleMessageObject ("Project {0} adds new C# feature WXNET_STYLEDTEXTCTRL.", this.Name, this);
                  changed = true;
              }
              if ((this._styles & wxStyles.Use_StyledtextControl) == wxStyles.Use_StyledtextControl && !stdParam.Features.ContainsSymbol("WXNET_STYLEDTEXTCTRL"))
              {
                  stdParam.Features.Add(new FeatureEntry("WXNET_STYLEDTEXTCTRL", "Use styled text control.", "WXNET_STYLEDTEXTCTRL"), true);
                  BuildConfig.HandleMessageObject ("Project {0} adds new C++ feature WXNET_STYLEDTEXTCTRL.", this.Name, this);
                  changed = true;
              }
              
              if (BuildConfig.NotWindows)
              {
                  string knownOptions=stdParam.GetOptions(GCC.GccAsCompiler.ToolName);
                  string cxxoptions=GetWxConfigOutput(stdParam.DebugInfo, this._styles, "--cxxflags")[0];
                  foreach(string cxxoption in cxxoptions.Split(' '))
                  {
                      if (cxxoption == null || cxxoption.Length == 0)
                         continue;
                      if (!knownOptions.Contains(cxxoption))
                      {
                           BuildConfig.HandleMessageObject("Project {0} added gcc-c option {1}.", this.Name, cxxoption);
                           changed=true;
                           stdParam.AddOptions(GCC.GccAsCompiler.ToolName, cxxoption);
                      }
                  }
                  
                  knownOptions=stdParam.GetOptions(GCC.GccAsLinker.ToolName);
                  string linkoptions=GetWxConfigOutput(stdParam.DebugInfo, this._styles,"--libs")[0];
                  foreach(string linkoption in linkoptions.Split(' ', '\n'))
                  {
                      if (linkoption == null || linkoption.Length == 0 || linkoption.StartsWith("-lwx"))
                         continue;
                      if (!knownOptions.Contains(linkoption))
                      {
                           BuildConfig.HandleMessageObject("Project {0} added gcc-L option {1}.", this.Name, linkoption);
                           changed=true;
                           stdParam.AddOptions(GCC.GccAsLinker.ToolName, linkoption);
                      }
                  }
              }
              else
              {
	              string baseDir = BaseDir;
	              if (baseDir == null)
	                  throw new Exception ("Cannot find wxWidgets installation in standard direkctories. Please set WXWIN to the directory of the wxWidgets installation.");
	              string newIncludePath = System.IO.Path.Combine (BaseDir, "include");
	              if (!stdParam.IncludePaths.Contains (newIncludePath)) {
	                  stdParam.IncludePaths.Add (newIncludePath);
	                  BuildConfig.HandleMessageObject ("Project {0} adds new include path {2}.", this.Name, this, newIncludePath);
	                  changed = true;
	              }
	              
	              if ((this._styles & wxStyles.Use_StyledtextControl) == wxStyles.Use_StyledtextControl)
	              {
	                  string stcIncludePath = System.IO.Path.Combine (BaseDir, "contrib");
	                  stcIncludePath = System.IO.Path.Combine (stcIncludePath, "include");
	                  if (!stdParam.IncludePaths.Contains (stcIncludePath)) {
	                      stdParam.IncludePaths.Add (stcIncludePath);
	                      changed = true;
	                  }
	              }
	              
	              string mswLibDir = BaseDir + "\\lib\\vc_lib";
	              if (BuildConfig.IsWindows)
                  {
	                  string cfgDir = "msw";
	                  if ((this._styles & wxStyles.Use_Unicode) == wxStyles.Use_Unicode)
	                      cfgDir += "u";
	                  if (stdParam.DebugInfo)
	                      cfgDir += "d";
	                  
	                  string mswCfgDir = mswLibDir + "\\" + cfgDir;
	                  string includeMSWDir = "/I " + ContentFile.QuoteFileName (mswCfgDir);
	                  if (!stdParam.GetOptions ("cl.exe").Contains (includeMSWDir)) {
	                      stdParam.AddOptions ("cl.exe", includeMSWDir);
	                      BuildConfig.HandleMessageObject ("Project {0} adds new option to tool cl.exe: {1}.", this.Name, includeMSWDir);
	                      changed = true;
	                  }
	                  string gccLibDir = BaseDir + "\\lib\\gcc_lib\\" + cfgDir;
	                  string includeGCCDir = "-I " + ContentFile.QuoteFileName (gccLibDir);
	                  if (!stdParam.GetOptions (GCC.GccAsCompiler.ToolName).Contains (includeGCCDir)) {
	                      stdParam.AddOptions (GCC.GccAsCompiler.ToolName, includeGCCDir);
	                      BuildConfig.HandleMessageObject ("Project {0} adds new option to tool gcc-c: {1}.", this.Name, includeGCCDir);
	                      changed = true;
	                  }
	              }
	              if (!stdParam.GetOptions ("cl.exe").Contains ("wxUSE_GUI=1")) {
	                  stdParam.AddOptions ("cl.exe", "/D \"wxUSE_GUI=1\"");
	                  changed = true;
	              }
	              string linkLibPath = "/Libpath:" + ContentFile.QuoteFileName (mswLibDir);
	              if (!stdParam.GetOptions ("link.exe").Contains (linkLibPath)) {
	                  stdParam.AddOptions ("link.exe", linkLibPath);
	              }
	              string unicodeOption = "/D _UNICODE";
	              if ((this._styles & wxStyles.Use_Unicode) == wxStyles.Use_Unicode)
                  {
                      if (!stdParam.GetOptions("cl.exe").Contains(unicodeOption))
                      {
                          stdParam.AddOptions("cl.exe", unicodeOption);
                          BuildConfig.HandleMessageObject("Project {0} adds new option to tool cl.exe: {1}.", this.Name, unicodeOption);
                          changed = true;
                      }
                      if (!stdParam.GetOptions("cl.exe").Contains("wxUSE_UNICODE"))
                      {
                          stdParam.AddOptions("cl.exe", "/D wxUSE_UNICODE");
                          BuildConfig.HandleMessageObject("Project {0} defines new symbol for compiler cl.exe: wxUSE_UNICODE.", this.Name);
                          changed = true;
                      }
                      if (!stdParam.GetOptions("gcc-c").Contains("wxUSE_UNICODE"))
                      {
                          stdParam.AddOptions("gcc-c", "-DwxUSE_UNICODE");
                          BuildConfig.HandleMessageObject("Project {0} defines new symbol for compiler gcc-c: wxUSE_UNICODE.", this.Name);
                          changed = true;
                      }
                  }
              }
              return changed;
          }
          #endregion
  
          #region IBuildActionProvider Member
          /// <summary>
          /// Currently only implemented for OperatingSystem.Linux and OperatingSystem.WinXP
          /// </summary>
          public ICollection<OperatingSystem> ApplicableOSs {
              get { return new OperatingSystem[] { OperatingSystem.Linux, OperatingSystem.WinXP }; }
          }
  
          /// <summary>
          /// The Unicode Variable.
          /// </summary>
          static readonly EnvironmentVarInfo _unicodeVar = new EnvironmentVarInfo ("WXUNICODE", "Turning this on will enforce this project to use wxWidgets libraries with built in Unicode support.", typeof(bool));
  
          /// <summary>
          /// Variable WXWIN enables users on platforms (not Unix/Linux) to configure where the wxWidgets
          /// main directory is. The Boolean variable WXUNICODE may be used to turn use of Unicode build on or off.
          /// </summary>
          public override IDictionary<string, EnvironmentVarInfo> UsedVars {
              get {
                  Dictionary<string, EnvironmentVarInfo> result = new Dictionary<string, EnvironmentVarInfo> ();
                  if (Environment.OSVersion.Platform != PlatformID.Unix) {
                      result.Add ("WXWIN", new EnvironmentVarInfo ("WXWIN", "Main directory of the wxWidgets sources (typically something like C:\\wxWidgets-2.8.10.", typeof(DirectoryName)));
                  }
                  result.Add (_unicodeVar.Varname, _unicodeVar);
                  return result;
              }
          }
  
          public string ToolFamily {
              get { return "wx"; }
          }
  
          public override string Description {
              get { return "Handle of the wxWidgets libraries. This can not yet build the library from source but will do its best to detect it and adopt C++ parameters to use this library."; }
          }
  
          /** <summary>If the env var WXWIN is not set, the tool will search these directories for \e wxWidgets (MS Windows).
          * This is irrelevant on Unix since on this platform this implementation will expect program <c>wx-config</c>
          * to be in the path of executable programs.</summary>
          */
          static readonly string[] WxDirs = { "wxWidgets-2.8.10", "wxWidgets-2.8.9", "wxWidgets-2.8.8", "wxWidgets-2.8.7", "wxWidgets-2.8.6", "wxWidgets-2.8.5", "wxWidgets-2.8.4", "wxWidgets-2.8.3", "wxWidgets-2.8.2", "wxWidgets-2.8.1" };
  
          /** <summary>The base directory of the recognized wxWidgets installation.
          * If this is <c>null</c>, then this is not able to find a wxWidgets installation.</summary>
          */
          public static string BaseDir {
              get {
                  string result = System.Environment.GetEnvironmentVariable ("WXWIN");
                  if (BuildConfig.IsWindows)
                  {
                      if (result == null || result.Length == 0) {
                          foreach (string logicalDrive in System.Environment.GetLogicalDrives ()) {
                              foreach (string wxDir in WxDirs) {
                                  result = System.IO.Path.Combine (logicalDrive, wxDir);
                                  if (!System.IO.Directory.Exists (result))
                                      result = null;
                                  // test for wx/defs.h to prove that there are headers.
                                  if (result != null) {
                                      string defsPath = System.IO.Path.Combine (result, "include\\wx\\defs.h");
                                      if (!System.IO.File.Exists (defsPath))
                                          result = null;
                                  }
                                  // we will not check for libs here since those will have to be created for each compiler separately.
                                  // So, let's stop here if we are all right.
                                  if (result != null)
                                      break;
                              }
                              if (result != null)
                                  break;
                          }
                          if (result != null) {
                              System.Environment.SetEnvironmentVariable ("WXWIN", result);
                          }
                      }
                  }
                  return result;
              }
          }
  
          /** <summary>ContentType.CoffLib and ContentType.GccLib</summary>
          */
          public ICollection<ContentType> ContentFileTargets {
              get {
                  List<ContentType> result = new List<ContentType> ();
                  if ((this._styles & wxStyles.Use_CoffLibraries) == wxStyles.Use_CoffLibraries)
                      result.Add (ContentType.VCCoffLib);
                  if ((this._styles & wxStyles.Use_GccLibraries) == wxStyles.Use_GccLibraries)
                      result.Add (ContentType.GccLib);
                  return result;
              }
          }
          #endregion
  
          #region IBuildAction Member
  /** <summary> This does not contain prerequisites. </summary> */		
                  public override ICollection<IBuildProduct> GetPrerequisites ()
          {
              return new IBuildProduct[] {  };
          }
  
          /** <summary> This does not contain prerequisites. </summary> */
          public override bool ContainsPrerequisite (IBuildProduct prereq)
          {
              return false;
          }
  
          /** <summary> Since this currently can not build any wxWidgets library, this is true iff all targets already exist. </summary> */
          public override bool TargetsAreConsistent (DateTime validityOfBuildSystem)
          {
              CxxParameters stdParam = (CxxParameters)BuildConfig.GetDefaultParameterOfType (typeof(CxxParameters));
              if ((this._styles & wxStyles.Use_CoffLibraries) == wxStyles.Use_CoffLibraries) {
                  foreach (ContentFile file in GetMSVCTargets (stdParam.DebugInfo, this._styles))
                      if (!file.Exists)
                          return false;
              }
              if ((this._styles & wxStyles.Use_GccLibraries) == wxStyles.Use_GccLibraries) {
                  foreach (ContentFile file in GetGccTargets (stdParam.DebugInfo, this._styles))
                      if (!file.Exists)
                          return false;
              }
              return true;
          }
  
          public ActionPriority Priority {
              get { return ActionPriority.Fallback; }
          }
  
          public override ICollection<Type> ParameterTypes {
              get { return null; }
          }
  
          #endregion
  
          #region IBuildProduct Member
          /// <summary>
          /// The library files of wxWidgets either applicable to GCC linker or MS VC linker.
          /// </summary>
          public override ICollection<IBuildProduct> GetTargets ()
          {
              CxxParameters stdParam = (CxxParameters)BuildConfig.GetDefaultParameterOfType (typeof(CxxParameters));
              List<IBuildProduct> result = new List<IBuildProduct> ();
              if ((this._styles & wxStyles.Use_CoffLibraries) == wxStyles.Use_CoffLibraries) {
                  foreach (ContentFile file in GetMSVCTargets (stdParam.DebugInfo, this._styles))
                      result.Add (file);
              }
              if ((this._styles & wxStyles.Use_GccLibraries) == wxStyles.Use_GccLibraries) {
                  foreach (ContentFile file in GetGccTargets (stdParam.DebugInfo, this._styles))
                      result.Add (file);
              }
              return result;
          }
  
          public override DateTime GetValidity ()
          {
              return DateTime.MinValue;
          }
  
          public override DateTime GetValidityDemand ()
          {
              return DateTime.MinValue;
          }
  
          /** <summary>This will create a collection of instances of FileTestAction.
          * This creates separated actions for either ContentType.CoffLib targets and
          * ContentType.GccLib targets. Thus, later steps of linking may either refer
          * to different actions.
          *
          * To increase efficiency, this will only create actions for those files that
          * really exist.
          * </summary>
          */
          public override ICollection<IBuildAction> CreateActionPlan (BuildToolFamilyEnv env)
          {
              List<IBuildAction> result = new List<IBuildAction> ();
              CxxParameters stdParam = (CxxParameters)BuildConfig.GetDefaultParameterOfType (typeof(CxxParameters));
              if (BuildConfig.NotWindows)
              {
                  // we definitely have an empty action plan. but we will test here vor the
                  // availability of a selected version.
                  string[] output=GetWxConfigOutput(stdParam.DebugInfo, this._styles, "--selected-config");
                  if (output[0]==null || output[0].Trim().Length==0)
                     BuildConfig.HandleErrorObject (ErrorObject.MessageType.Message, output[1]);
              }
              else
              {
	              if ((this._styles & wxStyles.Use_CoffLibraries) == wxStyles.Use_CoffLibraries) {
	                  ContentFiles libs = GetMSVCTargets (stdParam.DebugInfo, this._styles);
	                  bool allAvailable = true;
	                  foreach (ContentFile file in libs)
	                      if (!file.Exists) {
	                          allAvailable = false;
	                          break;
	                      }
	                  if (allAvailable)
	                      result.Add (new FileTestAction (libs));
	              }
	              if ((this._styles & wxStyles.Use_GccLibraries) == wxStyles.Use_GccLibraries) {
	                  ContentFiles libs = GetGccTargets (stdParam.DebugInfo, this._styles);
	                  bool allAvailable = true;
	                  foreach (ContentFile file in libs)
	                      if (!file.Exists) {
	                          allAvailable = false;
	                          break;
	                      }
	                  if (allAvailable)
	                      result.Add (new FileTestAction (libs));
	              }
	              if (result.Count == 0) {
	                  BuildConfig.HandleErrorObject (ErrorObject.MessageType.Error, "Cannot make {1}. Please build the wxWidgets library for at least one supported compiler.", this, this.Name);
	                  if ((this._styles & wxStyles.Use_Unicode) == wxStyles.Use_Unicode)
	                      BuildConfig.HandleErrorObject (ErrorObject.MessageType.Message, "I only searched for wxWidgets libraries built with UNICODE support. Libraries in ANSI mode have been ignored. You may change this changing variable WXUNICODE.");
	                  else
	                      BuildConfig.HandleErrorObject (ErrorObject.MessageType.Message, "I only searched for wxWidgets libraries built in ANSI mode without UNICODE support. Libraries in UNICODE mode have been ignored. You may change this changing variable WXUNICODE.");
	                  return null;
	              }
              }
              return result;
          }
  
          #endregion
  
          #region IXmlSerializable Member
  
          public override void ReadXml (System.Xml.XmlReader reader)
          {
              this._styles = wxStyles.Unspecified;
              if (reader.IsStartElement ("wxwidgets")) {
                  bool isEmpty = reader.IsEmptyElement;
                  Guid oldGuid = this.Id;
                  ReadStdAttributes (reader);
                  this.SetAsKnownProject(oldGuid);
                  reader.Read ();
                  reader.MoveToContent ();
                  if (!isEmpty) {
                      while (reader.IsStartElement ()) {
                          string styleName = reader.ReadElementString ("style");
                          this._styles = this._styles | (wxStyles)Enum.Parse (typeof(wxStyles), styleName);
                      }
                      reader.ReadEndElement ();
                  }
                  if (!_unicodeVar.IsEmpty ()) {
                      if ((bool)_unicodeVar.Get ())
                          this._styles = this._styles | wxStyles.Use_Unicode;
                      else
                          this._styles = this._styles & ~wxStyles.Use_Unicode;
                  }
              } else
                  reader.ReadStartElement ("wxwidgets");
              // produce an error
          }
  
          public override void WriteXml (System.Xml.XmlWriter writer)
          {
              writer.WriteStartElement ("wxwidgets");
              WriteStdAttributes (writer);
              if ((this._styles & wxStyles.Use_CoffLibraries) == wxStyles.Use_CoffLibraries)
                  writer.WriteElementString ("style", wxStyles.Use_CoffLibraries.ToString ());
              if ((this._styles & wxStyles.Use_GccLibraries) == wxStyles.Use_GccLibraries)
                  writer.WriteElementString ("style", wxStyles.Use_GccLibraries.ToString ());
              if ((this._styles & wxStyles.Use_StyledtextControl) == wxStyles.Use_StyledtextControl)
                  writer.WriteElementString ("style", wxStyles.Use_StyledtextControl.ToString ());
              if ((this._styles & wxStyles.Use_Unicode) == wxStyles.Use_Unicode)
                  writer.WriteElementString ("style", wxStyles.Use_Unicode.ToString ());
              writer.WriteEndElement ();
          }
  
          #endregion
  
          public override object Clone ()
          {
              return new wxWidgets (this._styles);
          }
      }
  }
