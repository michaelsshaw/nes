/** Build system for wx.NET.
 * 
 * This DLL contains basic implementations to build (compile and link) C/C++ programs,
 * compile .NET assemblies written in C#, sign them, and install them.
 * 
 * \file 
 *
 * Copyright 2009-2010 Harald Meyer auf'm Hofe harald_meyer@users.sourceforge.net
 * 
 * Licensed under the wxWidgets license, see LICENSE.txt for details.
 * 
 * $Id: BuildConfiguration.cs,v 1.21 2010/06/16 18:12:32 harald_meyer Exp $
 */


using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

/** \mainpage

This is the source code documentation of the \e wx.NET build system. In fact, this is not part of the \e wx.NET code,
but this has originally been developed to be used in this project.
The system consists of the assembly \c wx.BuildSystem.dll. The system provides means to define build projects, which
are instances of predefined classes, and implement programs for building the targets of these projects or to create
BOO source files of programs that can build the targets of the projects. The latter service enables users of the
system with uncommon or unsupported build environment to adopt standard build processes to their needs.

One advice in advance: Please avoid to use blank spaces (' ') in names of files or directories because some tools
may have problems to access these files.
 
\c wx.Build aims at providing a modular and platform independent build environment based on .NET. There are many
obvious relations to systems like \e ant, the MS build system, or other MAKE- and Meta-MAKE systems. The main
difference lies in two points:
\li The implemented functions put a focus on building, deployment, and installation. Installation systems like
    the Windows Installer (for MSI files) apply the main idea of the original MAKE system: They create a plan for
    installation (or building a system respectively) exploiting information on dependencies between relevant
    installation or build targets. So, the idea is to attack both tasks - building and installation- by the same code base.
    Of course, the needs of the \e wx.NET project is very limited w.r.t. to the required functions. Thus, the envisioned
    extend of the implementation may rather be considered as a study than a system for general use. However, the intended
    modular structure of the code base enables necessary extension for other purposes.
\li All cited systems infer sequences of actions for installation and planning. However, their capabilities concerning the inference
    of such schedules are very limited. \c wx.Build separates clearly between targets of the build process, classes of projects
    that implement \e portable sceleton plans to achieve targets, and the available actions. Actions are created using action
    providers. The system can be extended by the definition of new file types and new actions to produce such files. 

This build system consists of build actions, that are wrappers of compilers and linkers - like in ANT. Additionally, this
system comprises build projects, that define the actual targets of a build.
Providers of code define such projects in a .NET assembly. Refer to the remarks on the projects wx.Build.Net.CSharpAssemblyProject
and wx.Build.Cxx.DynamicLibraryProject.
These classes create plans comprising build actions that actually build the projects. 
The projects are able to identify alternative sets of tools, like e.g. the MS cl.exe compiler and link.exe on the one hand to build
C/C++ DLLs or the MinGW distribution of the GCC compiler on the other hand. 
The schedule that will be created by the build project uses all supported tools that are installed. Thus, if the MS cl.exe
compiler fails to compile a file, the build system will try to use alternative tools like the MinGW compiler and linker.

However, in many situations, users want to configure the building process by hand. Maybe, some tools are not installed
in standard directories or the build process runs in an unsupported environment. For this reason, the Build process is able
to produce a BOO file that builds the targets. This file has a structure that is easy to change and acts like a make file.

However, the current implementation is more or less a proof-of-concept implementation, since it only provides wrappers for
those tools and implements those types of projects that are required to build wx.NET.
 
Refer to page \ref wx_build_typical_use for remarks on how to use build programs that are based on this library.

 
\page wx_build_typical_use Typical Use
  
Typically, programs using the build system define projects as static properties of the main class. The main program typically simply
starts wx.Build.BuildProject.Build(string[]). This method interprets command line options as described in the documentation
of class wx.Build.CommandLineOptions.

Some excerpts from the wx.NET build program may exemplify this.

First, you need a class defining the projects as static properties.
\code
    public class BuildProgram
    {
\endcode
The following sniplet defines a native code DLL <c>wx-c.dll</c>, or ELF library <c>libwx-c.so</c> respectively.
\code
        static wx.Build.Cxx.DynamicLibraryProject _wxCProject = null;
        public static Cxx.DynamicLibraryProject WxCProject
        {
            get
            {
                if (_wxCProject == null)
                {
                    _wxCProject = new Cxx.DynamicLibraryProject(ProjectPreference.Default,
                        "wx-c",
                        ".", "wx-c",
                        "The native code of the wx.NET project.");
                    _wxCProject.AddStaticLibrary(wxProject.CreateRefToFileProject()); // Reference to the project providing the wxWidgets libraries
                    _wxCProject.AddCPlusPlusSources(new FileSelector(ContentType.CPlusPlusCode, "../Src/wx-c", "*.cxx", "wx.NET C++ sources."));
                    _wxCProject.AddHeaderFiles(new FileSelector(ContentType.CCPlusPlusInclude, "../Src/wx-c", "*.h", "wx.NET C++ includes."));
                    _wxCProject.AddRCFile(new ContentFile(ContentType.RCFile, "../Src/wx-c/windows.rc"));
                }
                return _wxCProject;
            }
        }
    
\endcode
One advantage of using C# to define build projects: IntelliSense will assist you.

Projects may depend on each other. The \c wx-c.dll depends on the wxWidgets libraries. The next project will build
the wx.NET.dll providing the managed part of the wx.NET project. Thsi project is of the second important type for building
managed code from C# sources.

\code
        static wx.Build.Net.CSharpAssemblyProject _wxNetProject=null;
        public static Net.CSharpAssemblyProject WxNetProject
        {
            get
            {
                if (_wxNetProject==null)
                {
                _wxNetProject = new Net.CSharpAssemblyProject(ProjectPreference.Default,
                    "wx.NET",
                    "wx.NET.dll", "The managed part of the wx.NET implementation.");
                _wxNetProject.CSharpSources = new FileSelector(ContentType.CSharpCode, "../Src/wx.NET", "*.cs", "wx.NET C# source files.");
                _wxNetProject.ReferencesAssemblies = new ContentFiles(ContentType.DotNetDll, ContentFileLocation.GlobalAssemblyCache,
                    "System.dll", "System.Drawing.dll", "System.Xml.dll");
                _wxNetProject.PInvokeDependencies = WxCProject.CreateRefToSingleFileProject();
                _wxNetProject.Signature = new ContentFile(ContentType.SnKeys, "../Src/wx.NET/keys.snk");

                _wxNetProject.Features.Add(new FeatureEntry("Styled Text Control", "Enables namespace wx.StyledText", "WXNET_STYLEDTEXTCTRL"), true);
                _wxNetProject.Features.Add(new FeatureEntry("Display Access", "Enables class wx.Display", "WXNET_DISPLAY"), true);
                }
                return _wxNetProject;
            }
        }
\endcode

This project exhibits some features: Services of the resulting program that are optional. 

The next step is usually the definition of at least one project building a program. The \e wx.NET
provides several programs - samples as well as utilities. The following sniplet will define the project
to build the \c controls.exe program demonstrating the contained controls.

\code
        public static .Net.CSharpAssemblyProject SampleControls
        {
            get
            {
                Net.CSharpAssemblyProject project = new Net.CSharpAssemblyProject(ProjectPreference.Default,
                    "Controls Demo",
                    "controls.exe",
                    "wx.NET sample program on controls.");
                project.CSharpSources = new FileSelector(ContentType.CSharpCode, "../Samples/Controls", "*.cs", "C# Sources of controls.exe.");
                project.ReferencesAssemblies = new FileProducts(ContentType.DotNetDll,
                    new ContentFiles(ContentType.DotNetDll, ContentFileLocation.GlobalAssemblyCache,
                        "System.dll", "System.Drawing.dll"),
                    WxNetProject.CreateRefToFileProject());
                project.Signature = new ContentFile(ContentType.SnKeys, "../Src/wx.NET/keys.snk");
                project.WinIcon = new ContentFile(ContentType.ICO, "../Src/wx.NET/mondrian.ico");
                ICollection<ResourceDesignator> externalResources = ResourceDesignator.SelectExternalResources(ContentType.XPM, "../Samples/Controls/Icons", "*.xpm", "../Samples/Controls/Icons");
                externalResources.Add(new ResourceDesignator(ContentType.PNG, "../Samples/Controls/mondrian.png", "../Samples/Controls/mondrian.png"));
                project.ExternalResources = externalResources;

                #region Additionally, we want the soruces to be copied
                project.AddExternalResources(ResourceDesignator.SelectExternalResources(ContentType.CSharpCode, "../Samples/Controls", "*.cs", "../Samples/Controls"));
                #endregion
            }
        }
\endcode

Finally, you will need a main function running the actual build program. wx.Build provides some static functions
with class wx.Build.BuildProject to build all projects defined in an assembly. These functions will enumerate
all classes defined by these assemblies and look for static properties providing instances of class wx.Build.BuildProject.
The properties, that we defined above, provide such build projects since wx.Build.Net.CSharpAssemblyProject and
wx.Build.Cxx.DynamicLibraryProject extend this class. 
You can enable the user to configre the build using options provided in the argument list of the build program and
environment variables. wx.Build provides a standard parser for program options by class wx.Build.CommandLineOptions.
Refer to the remarks on this class for the options that cen be parsed.
Another class wx.Build.BuildConfig is meant to manage configurations of the build process. Such configurations
can be named. Two configurations are predefined: "Release" (default) and "Debug". Another important property of
this class is \c wx.Build.BuildConfig.PathRootVariable. This variable defines the name of an environment variable 
that holds the base path of the build program. The base path is tha path that will be used to complete all
relative paths that occur in the parameters of build projects.
out build program will user this parser. Therefore, we will use a static functions of wx.Build.BuildProject that
expects program options as arguments and will conduct the build process.

\code
        public static int Main(string[] args)
        {
            BuildConfig.PathRootVariable = "wxNetBase";
            return BuildProject.Build(args);
        }
    }
}
\endcode

That's all. Now we can compile this program let's say into a program \c "wxSampleBuild.exe" and start a build process e.g.
using the following call within a command shell:
\verbatim
> wxSampleBuild.exe /log=aLogFileName 
\endverbatim

\page using_boo_exports Export build programs as BOO source code

Assume, that we have implemented a build program following the hints of section \ref wx_build_typical_use.
This program can be used to create a BOO program source code for producing the targets of the build projects.
This program will not use the assembly \c wx.BuildSystem.dll but implement all calls of the available tools 
directly.

The resulting program will refer to all those tools that have been available when the build program has been
ran.
In the following, we will inspect the structure of a build program that has been created on a Windows installation.
Microsoft's VC and VS express editions for building C/C++ and C# programs, the GNU MinGW edition for building C/C++
programs and the MONO tools for building C# programs have been available.

Type the following line into the command shell:
\verbatim
> wxSampleBuild.exe /boo=aBooFileName 
\endverbatim

This file will create a file \c aBooFileName.boo containing a BOO program that builds the targets of the original
build program in a manner similar to the well-known MAKE systems.
This BOO program does nothing more than the original program. The purpose of this export to BOO is to enable
users of the system to adopt the build system to their specific needs if unusual or unsupported build
environments are used.
Thus, the BOO code is designed for manual changes.
The code consists of 3 sections.

\section using_boo_exports_declarations The declaration section

This sections contains the declaration of BOO variables for options and file names.
This is the section that users of the build system will edit to adopt the build system to specific needs.
 
This section contains several subsections.
the first section will import some required namespaces and declare features of some projects. Features define symbols that
are used for conditional compilation. The features here define optional parts of the \e wx.NET system: The styled text control
(STC) and the interface to the display:
\code
# BOO script to build the wx.Buildsystem projects from assembly
# wx.Net.Build, Version=0.9.0.0, Culture=neutral, PublicKeyToken=c5f483f7e93d2714.
# This program has been generated automatically by the wx.BuildSystem
# (c) 2010 Harald Meyer auf'm Hofe.
#
# The following lines will declare variables to configure the tools
# that are used to build the system. You may change these declarations
# if you know what you are doing.
import System.Text
import System.IO
import System.Diagnostics
# Features of project wx.NET: The managed part of the wx.NET implementation.
Features_wx_NET=[]
Features_wx_NET.Add("WXNET_DISPLAY") # Display Access: Enables class wx.Display
Features_wx_NET.Add("WXNET_STYLEDTEXTCTRL") # Styled Text Control: Enables namespace wx.StyledText
\endcode

In the following, the base path will be defined, that will be used to complete all local paths in the build program. 
Additionally, the build mode (rebuild or reuse of existing build results) and the target directory containing all
internal build projects will be declared here.
\code
# This is the root path of the project.
wxNetBase='c:\\sf\\wx.NET\\Bin'
System.IO.Directory.SetCurrentDirectory(wxNetBase)
#
# If true, then any target will be rebuild. If false, many build actions
# will only rebuild targets if prerequisites are newer.
Rebuild=false
#
# This is the directory containing all non-target files that will be created on building the targets.
BuildDir='Build\\Debug'
\endcode

The following sections will provide definitions of files and options 
for each avaiable tool. The following listing presents the section defining options for the CSC.EXE C# compiler
of Microsoft's .NET framework.

\code
#################################################################
# These are the declarations of tool csc.exe of family MSNET:
# c:\WINDOWS\Microsoft.NET\Framework\v3.5\csc.exe: The C# compiler of the MS .NET framework.
# This variable is the path to the CSC compiler that will be used.
MS_CSC="c:\\WINDOWS\\Microsoft.NET\\Framework\\v3.5\\csc.exe"
# This option defines whether to compile with debug information or not
MS_CSC_OPTIONS='/debug'
# This option turns on optimization
#MS_CSC_OPTIONS+=' /optimize'
# This option defines the warning level
MS_CSC_OPTIONS+=' /warn:3'
MS_CSC_OPTIONS+=' /fullpaths'
#MS_CSC_OPTIONS+=' /warnaserror' # treats warnings as errors
MS_CSC_OPTIONS+=' /define:__MS_CSC__' # identifies the compiler
MS_CSC_OPTIONS+=' /define:TRACE' # enables trace log
#################################################################
\endcode

The final section defines so-called choice points. Since the build program uses all available build tools,
there may be alternative paths to achieve certain targets. The workstation that created this BOO program
has been fully equipped with VC Express and GNU MinGW to build C/C++ subsystems, VS Express and MONO to build
C# subsystems. Thus, the user of the build system has the choice. The following choice points enable the user
to make this choice.

\code
#########################################################
# This section contains choice points- BOO variables that
# control which tools will be used. Assign one of the
# listed values to the choice points in order to select
# a particular tool. If this tool is not available, the
# program will automatically use an alternative.
CppDevelopmentSystem = "MS VC" # "MS VC" "GNU"
CSHARP_COMPILER = "csc.exe" # "csc.exe" "gmcs" "CSharpCodeProvider"
\endcode

\section using_boo_exports_definitions The section defining the build programs

The next section implements the wrapper functions that will be called to run the build tools.
Users of the build system are not required to know them. However, the following sections shows
the function calling the CSC.EXE compiler for all those that like to know how things work.

\code
#########################################################
# The section containing declarations ends here.
# Please refrain from changing the code from this position on.
# The code below will provide definitions of build functions and
# will use this functions afterwards to produce the build targets.
# However, you may want to disable build tools here by replacing
# the body of the corrsponding function with "pass".
def TestForRebuild(targetFile as  string, *sourceFiles as (object)):
	if Rebuild: return true
	if not System.IO.File.Exists(targetFile): return true
	dTarget=System.IO.File.GetLastWriteTime(targetFile)
	inlinedSources=[]
	for sourceFile in sourceFiles:
		if sourceFile == null: continue
		if sourceFile isa System.Array:
			for containedSource in cast(System.Array, sourceFile):
				inlinedSources.Add(containedSource)
		else:
			inlinedSources.Add(sourceFile)
	for inlinedSource in inlinedSources:
		dSource=System.IO.File.GetLastWriteTime(inlinedSource)
		if dTarget < dSource: return true
	return false
#
# These are the definitions of tool csc.exe of family MSNET:
# c:\WINDOWS\Microsoft.NET\Framework\v3.5\csc.exe: The C# compiler of the MS .NET framework.
def RunMsCsc(targettype as string, target as string, w32icon as string, signature as string, mainclass as string, references as (string), sources as (string), features):
	if not TestForRebuild(target, w32icon, signature, references, sources):
		print target,"is up to date"
		return
	print "MS csc.exe creates", target
	args=StreamWriter("${BuildDir}\\plain\\csc.txt")
	args.Write("/out:${target} /target:${targettype}")
	for feature in features:
		if feature=="X32":
			args.Write(' /platform:x86')
		elif feature=="X64":
			args.Write(' /platform:x64')
		else:
			args.Write(' /define:')
			args.Write(feature)
	for reference in references:
		args.Write(" /reference:\"${reference}\"")
	if signature != null:
		args.Write(" /keyfile:\"${signature}\"")
	if w32icon != null:
		args.Write(" /win32icon:\"${w32icon}\"")
	if mainclass != null:
		args.Write(" /main:${mainclass}")
	args.Write(' ')
	args.Write(MS_CSC_OPTIONS)
	for source in sources:
		args.Write(" \"${source}\"")
	args.Close()
	startinfo=System.Diagnostics.ProcessStartInfo()
	startinfo.FileName=MS_CSC
	startinfo.Arguments="@${BuildDir}\\plain\\csc.txt"
	startinfo.UseShellExecute=false
	p=System.Diagnostics.Process.Start(startinfo)
	p.WaitForExit()
	if p.ExitCode!=0:
		raise System.Exception("Build action failed.")
\endcode

\section using_boo_exports_building The section actually building the desired targets

The final section uses the wrapper functions defined in the previous section to actually build the
build targets.

This is the code producing the \c controls.exe programm.
\code
if CSHARP_COMPILER == "gmcs":
	print 'Executing gmcs'
	RunMonoGmcs("winexe", "${wxNetBase}\\controls.exe", ("../Samples/Controls\\Controls.cs", ), ("System.dll", "System.Drawing.dll", "${wxNetBase}\\wx.NET.dll", ), "c:\\sf\\wx.NET\\Src\\wx.NET\\mondrian.ico", "c:\\sf\\wx.NET\\Src\\wx.NET\\keys.snk", null, [])
elif CSHARP_COMPILER == "CSharpCodeProvider":
	print 'Executing CSharpCodeProvider'
	print "Caught exception creating code for action CSharpCodeProvider."
	print "BOO code creation is not supported by action wx.Build.Net.CSharpCodeProvider."
else: # CSHARP_COMPILER == "csc.exe"
	print 'Executing csc.exe'
	RunMsCsc('winexe', "${wxNetBase}\\controls.exe", "c:\\sf\\wx.NET\\Src\\wx.NET\\mondrian.ico", "c:\\sf\\wx.NET\\Src\\wx.NET\\keys.snk", null, ("System.dll", "System.Drawing.dll", "${wxNetBase}\\wx.NET.dll"), ("../Samples/Controls\\Controls.cs",), [])
\endcode


\page notes_for_contributers Notes for  Contributors
 
\li Build processes shall run in diverse system environments - for instance as shell commands or within the
    package builder or the windows forms GUI of the installer. Therefore, all text output shall be done using
    the delegate implementing the error handler.
\li Most build tools will use System.Diagnostics.Process to run a shell command. Please refer to existing 
    tool wrappers like wx.Build.Mono.Gmcs for examples. Please note, that several user interfaces of the build
    system need the opportunity to stop te process. Thus, call wx.Build.BuildConfig.WaitForExit(Process) when waiting
    for the termination of a process running a build command. This method will raise an event enabling external
    event handlers to prepare for user input requesting a stop of the build process.
 
*/

/** <summary> The main namespace containing the generic parts of the build system.
 * Refer to \ref wx_build_typical_use.
 * </summary> */
namespace wx.Build
{
    /** <summary> Options to abort an action.
     * This will usually be part of the build parameters.
     * These will be interpreted by the actions. However, the intention is to define
     * an overall valid rule to abort the build process w.r.t. several incidents. </summary> */
    public enum AbortOptions
    {
        /** <summary> Abort build process on warnings.
         * This ensures accurat builds. However, what will we do in case of warnings. </summary> */
        TreatWarningsAsErrors,

        /** <summary> Each compiler will abort on errors. Also missing data will stop the actions. </summary> */
        AbortOnErrorsAndMissingData,

        /** <summary> Will even refuse to abort the build process if usually required data is missing as long as the product will have a least standard quality.
         * .NET action will for instance proceed on building even if a specified signature is missing or a specified Win32 icon cannot be found etc. </summary> */
        AlwaysTryToProduceASomehowUsefulTarget,
    }

    /** <summary> Symbols to control the reuse of previous build operations.
     * This will be set globally in the configuration. </summary> */
    public enum BuildMode
    {
        /** <summary> Do not reuse results of previous builds. </summary> */
        BuildNew,
        /** <summary> Reuse results from previous builds as long as they are consistent.
         * Use IBuildProduct.Validity to assess consistency. </summary> */
        BuildMissingTargets
    }

    /** <summary> This is a class that makes tool specific options avaiable.
    * The keys are names of actions. The values provide sequences of options specific to that tool.
    * Please note, that all modifiers of this class will raise an excpetion "not supported operation". </summary> */
    public class ToolSpecificOptionsCollection : IDictionary<string, string>
    {
        #region State
        IDictionary<string, string> _original;
        #endregion

        #region CTor
        internal ToolSpecificOptionsCollection(IDictionary<string, string> original)
        {
            this._original = original;
        }
        #endregion

        #region IDictionary<string,sting> Member

        public void Add(string key, string value)
        {
            throw new NotSupportedException();
        }

        public bool ContainsKey(string key)
        {
            return this._original.ContainsKey(key);
        }

        public ICollection<string> Keys
        {
            get { return this._original.Keys; }
        }

        public bool Remove(string key)
        {
            throw new NotSupportedException();
        }

        public bool TryGetValue(string key, out string value)
        {
            return this._original.TryGetValue(key, out value);
        }

        public ICollection<string> Values
        {
            get { return this._original.Values; }
        }

        public string this[string key]
        {
            get
            {
                return this._original[key];
            }
            set
            {
                throw new NotSupportedException();
            }
        }

        #endregion

        #region ICollection<KeyValuePair<string,sting>> Member

        public void Add(KeyValuePair<string, string> item)
        {
            throw new NotSupportedException();
        }

        public void Clear()
        {
            throw new NotSupportedException();
        }

        public bool Contains(KeyValuePair<string, string> item)
        {
            return this._original.Contains(item);
        }

        public void CopyTo(KeyValuePair<string, string>[] array, int arrayIndex)
        {
            this._original.CopyTo(array, arrayIndex);
        }

        public int Count
        {
            get { return this._original.Count; }
        }

        public bool IsReadOnly
        {
            get { return true; }
        }

        public bool Remove(KeyValuePair<string, string> item)
        {
            throw new NotSupportedException();
        }

        #endregion

        #region IEnumerable<KeyValuePair<string,sting>> Member

        public IEnumerator<KeyValuePair<string, string>> GetEnumerator()
        {
            return this._original.GetEnumerator();
        }

        #endregion

        #region IEnumerable Member

        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            return this._original.GetEnumerator();
        }

        #endregion

        #region Overrides
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            foreach (KeyValuePair<string, string> pair in this)
            {
                sb.AppendFormat(" {0} : {1}\n", pair.Key, pair.Value);
            }
            return sb.ToString();
        }
        #endregion
    }

    /** <summary> Base class of options or other configurations that will be passed to build actions.
     * Parameters are prerequisites without a validity timestamp. Actions will refer to parameters
     * via a BuildConfiguration. So, all actions will use the same parameters. </summary> */
    public abstract class BuildParameters
    {
        /** <summary> This creates a clone of the argument. </summary> */
        public abstract BuildParameters Clone();

        /** <summary> Helper function for AdditionalInfoToXml(): Output of values that occur in parameters. </summary> */
        static string ParameterValueToString(object parameterValue)
        {
            if (parameterValue == null)
                return "";
            else
                return parameterValue.ToString();
        }

        /** <summary> This prints all public properties and fields on the provided destination.
        * This may be overloaded by subclasses. </summary> */
        public virtual void AdditionalInfoToXML(System.Xml.XmlWriter destination)
        {
            destination.WriteStartElement("parameters");
            destination.WriteAttributeString("type", this.GetType().FullName);
            foreach (System.Reflection.PropertyInfo pi in this.GetType().GetProperties())
            {
                destination.WriteStartElement(pi.Name);
                destination.WriteAttributeString("type", pi.PropertyType.FullName);
                destination.WriteString(ParameterValueToString(pi.GetValue(this, null)));
                destination.WriteEndElement();
            }
            foreach (System.Reflection.FieldInfo fi in this.GetType().GetFields())
            {
                destination.WriteStartElement(fi.Name);
                destination.WriteAttributeString("type", fi.FieldType.FullName);
                destination.WriteString(ParameterValueToString(fi.GetValue(this)));
                destination.WriteEndElement();
            }
            destination.WriteEndElement();
        }

    }

    /** <summary> A standard parameter specifying some standard properties regarding temporary files. </summary> */
    public class TempFilesParameters : BuildParameters
    {
        #region State
        public bool KeepFiles = false;
        #endregion

        #region CTor
        public TempFilesParameters()
        {
        }
        #endregion

        #region Public Properties and Methods
        public override BuildParameters Clone()
        {
            TempFilesParameters result = new TempFilesParameters();
            result.KeepFiles = this.KeepFiles;
            return result;
        }

        /** <summary> Returns a path to the standard directory of temporary files for the current default configuration. </summary> */
        public string GetDirectory()
        {
            return this.GetDirectory(null);
        }

        /// <summary>Derive a temporary filename from the <c>srcFilename</c> for content of type <c>targetType</c>.
        /// <c>targetType</c> will be the type of the result. The filename will be derived from <c>srcFilename</c>
        /// using GetDirectory() and an appropriate filename extension.</summary>
        /// <param name="srcFilename">The filename that will be used as reference to produce a temporary file.</param>
        /// <param name="targetType">the type of the resulting file. This may be used to produce the filename of the temporary file.</param>
        /// <returns>Descriptor of a content file of the provided type that is in a subdir of all temporary files.
        /// The filename of the result will contain underscores '_' instead of blanks ' '.</returns>
        public ContentFile CreatePathFor(string srcFilename, ContentType targetType)
        {
            string basename = Path.GetFileNameWithoutExtension(srcFilename);
            string dir = Path.GetDirectoryName(srcFilename);
            dir = Path.Combine(dir, targetType.Secondary);
            dir = GetDirectory(dir);
            string filename=targetType.FilenameFromBasename(basename);
            filename = Path.Combine(dir, filename).Replace(" ", "_");
            ContentFile result=new ContentFile(targetType, filename);
            return result;
        }

        /// <summary>
        /// Utility to turn the first path into an equivalent (referring to the same file) that is, however,
        /// relative to the second path.
        /// </summary>
        /// <param name="toBeMakeRelative">The result will be equivalent to this but relative to the argument.</param>
        /// <param name="theBasePath">The result will be relative to this.</param>
        /// <example>
        /// <code>
        /// System.Console.WriteLine(wx.Build.TempFilesParameters(
        ///    "C:\ADirectory\toBeMadeRelative", 
        ///    "C:\ADirectory\theBasePath");
        /// </code>
        /// The sniplet above will cause the following ouput on the console:
        /// <code>
        /// "..\toBeMadeRelative"
        /// </code>
        /// </example>
        public static string MakePathRelative(string toBeMadeRelative, string theBasePath)
        {
            toBeMadeRelative = BuildConfig.GetFullPathname(toBeMadeRelative);
            theBasePath = BuildConfig.GetFullPathname(theBasePath);
            if (toBeMadeRelative.Equals(theBasePath))
                toBeMadeRelative = "";
            else
            {
                string prefix = "";
                while (theBasePath != null && theBasePath.Length > 1)
                {
                    if (toBeMadeRelative.StartsWith(theBasePath))
                    {
                        toBeMadeRelative = toBeMadeRelative.Substring(theBasePath.Length);
                        if (System.IO.Path.IsPathRooted(toBeMadeRelative))
                            toBeMadeRelative = toBeMadeRelative.Substring(1);
                        break;
                    }
                    theBasePath = Path.GetDirectoryName(theBasePath);
                    if (prefix.Length == 0)
                        prefix = "..";
                    else
                        prefix += string.Format("{0}..", System.IO.Path.DirectorySeparatorChar);
                }
                if (prefix.Length > 0)
                    toBeMadeRelative = System.IO.Path.Combine(prefix, toBeMadeRelative);
            }
            return toBeMadeRelative;
        }

        static string _buildDir = null;
        /// <summary>
        /// The base path of all non-target files that will be created building the targets.
        /// </summary>
        public static string BuildDir
        {
            get
            {
                if (_buildDir == null)
                    _buildDir = Path.Combine(Path.Combine(BuildConfig.PathRoot, "Build"), BuildConfig.DefaultConfig);
                return _buildDir;
            }
        }

        /** <summary> Returns the path to a temporary directory and creates it if this does not exist.
         * This accepts the <c>null</c>  argument and will create a path to the base path of temporary
         * files for the current default configuration.
         * </summary>
         */
        public virtual string GetDirectory(string subPath)
        {
            if (Path.IsPathRooted(subPath))
            {
                // cut all leading paths common to the location of the project
                string prefixDir = BuildConfig.PathRoot;
                prefixDir = BuildConfig.GetFullPathname(prefixDir);
                if (subPath.Equals(prefixDir))
                    subPath = "";
                else
                {
                    while (prefixDir != null && prefixDir.Length > 1)
                    {
                        if (subPath.StartsWith(prefixDir))
                        {
                            subPath = subPath.Substring(prefixDir.Length + 1);
                            break;
                        }
                        prefixDir = Path.GetDirectoryName(prefixDir);
                    }
                }
            }
            string result = BuildDir;
            if (subPath != null && subPath.Length>0)
                result=Path.Combine(result, subPath);
            if (!Directory.Exists(result))
                Directory.CreateDirectory(result);
            return result;
        }
        #endregion
    }

    /// <summary>
    /// This is an event stating that the build process terminated.
    /// </summary>
    public class BuildProcessTerminated : EventArgs
    {
        bool _success;
        internal BuildProcessTerminated(bool success)
            : base()
        {
            this._success = success;
        }

        /// <summary>
        /// True iff the process has been successful. If false, an unrecoverable error occured.
        /// </summary>
        public bool Success { get { return this._success; } }
    }

    /// <summary>
    /// This event will be raised if the build process refers to a
    /// shell process (instance of System.Diagnostics.Process), e.g. to
    /// state that a process has been started running a build tool like
    /// a compiler.
    /// </summary>
    public class BuildProcessRefersToShellProcess : EventArgs
    {
        #region State
        System.Diagnostics.Process _process;
        bool _cancel = false;
        #endregion

        #region CTor
        internal BuildProcessRefersToShellProcess(System.Diagnostics.Process process)
            : base()
        {
            this._process = process;
        }
        #endregion

        #region Properties
        /// <summary>
        /// The process that has been started.
        /// </summary>
        public System.Diagnostics.Process Process { get { return this._process; } }

        /// <summary>
        /// True iff another handler has requested to cancel (kill) the process.
        /// </summary>
        public bool CancelRequest { get { return this._cancel; } }

        /// <summary>
        /// The start info of the process that has been started.
        /// </summary>
        public System.Diagnostics.ProcessStartInfo StartInfo { get { return this._process.StartInfo; } }
        #endregion

        #region Actions
        /// <summary>
        /// Call this to request a cancellation of this process.
        /// </summary>
        public void RequestCancellation()
        {
            this._cancel = true;
        }
        #endregion
    }

    /** <summary> A configuration is a named collection of BuildParameters.
     * This configuration holds at most one parameterset of a type.
     * Properties and methods fall into two groups: The state of an instance consists of a named collection of
     * BuildParameters - the configuration. All build actions will use the same build configuration. So, ensure
     * that this configuration holds an instance for each required parameter class.
     * 
     * The second group embraces (static) class properties and (static) class methods. These implement a database
     * of configurations where one is defined to be the default. Before conducting build actions, users may be asked
     * to choose a configuration. The default will be used, if the user uses standard. Each build program may redefine
     * this.
     * 
     * Two configurations will be created by standard: "Debug" and "Release", where "Release" is the default </summary> */
    public class BuildConfig
    {
        #region Members
        #region State
        string _name;
        IDictionary<Type, BuildParameters> _params = new Dictionary<Type, BuildParameters>();
        #endregion

        #region Privates and Internals
        BuildConfig(string name, params BuildParameters[] paramArray)
        {
            this._name = name;
            foreach (BuildParameters param in paramArray)
            {
                this._params.Add(param.GetType(), param);
            }
        }
        #endregion

        #region Public Properties
        /** <summary> Adds a parameter set to the configuration.
         * This will raise an exception if a parameter of this class is already known to the configuration.
         * </summary>
         * <param name="param">Parameters to be set.</param>
         */
        public void Add(BuildParameters param)
        {
            this._params.Add(param.GetType(), param);
        }

        /// <summary>
        /// Adds the provided parameters to this configuration like Add(). However,
        /// if this already contains a parameter set of this class, this pre-existing
        /// parameters will be removed silently.
        /// </summary>
        /// <param name="param">Parameters to be set.</param>
        public void AddOrReplace(BuildParameters param)
        {
            this._params[param.GetType()] = param;
        }

        /** <summary> This returns a collection of all contained parameters.
         * </summary>
         */
        public ICollection<BuildParameters> AllParams { get { return this._params.Values; } }

        /** <summary> This is the name of the configuration. </summary> */
        public string Name { get { return this._name; } }

        /** <summary> True iff this contains a parameter of the provided class. </summary> */
        public bool Contains(Type parameterType)
        {
            return this._params.ContainsKey(parameterType);
        }

        /** <summary> This returns the parameter of the provided class if one exists.
         * If the parameter is missing, the system will try to generate one using the default CTor.
         * If this also fails, the result will be an System.IndexOutOfRangeException. </summary> */
        public BuildParameters this[Type parameterType]
        {
            get
            {
                if (this._params.ContainsKey(parameterType))
                    return this._params[parameterType];
                else
                {
                    try
                    {
                        BuildParameters result = (BuildParameters)System.Activator.CreateInstance(parameterType);
                        this._params[parameterType] = result;
                        return result;
                    }
                    catch
                    {
                        throw new System.IndexOutOfRangeException("BuildConfig does not contain a parameter of the desired class.");
                    }
                }
            }
        }
        #endregion
        #endregion

        #region Static Services
        /// <summary>
        /// True iff this is a Unix machine - concluded from the OS version of the environment.
        /// </summary>
        public static bool IsUnix
        {
            get { return Environment.OSVersion.Platform == PlatformID.Unix; }
        }

        /// <summary>
        /// True iff this is a Mac OS X system. This compares the platform specifier of
        /// the OS version with "MaxOSX" - in order to prevent compilation problems with mono.
        /// </summary>
        public static bool IsMacOsX
        {
            get
            {
                return Environment.OSVersion.Platform.ToString().Contains("MacOSX");
            }
        }

        /// <summary>
        /// If this is neither Unix nor Max OS X, then this is a Windows derivate.
        /// </summary>
        public static bool IsWindows
        {
            get { return !IsUnix && !IsMacOsX; }
        }

        /// <summary>
        /// True if this is not Windows.
        /// </summary>
        public static bool NotWindows
        {
            get { return IsUnix || IsMacOsX; }
        }
        #endregion

        #region Static
        #region State
        static string _defaultParam = "Release";
        static IDictionary<string, BuildConfig> _configs = new Dictionary<string, BuildConfig>();

        BuildMode _mode=BuildMode.BuildMissingTargets;

        static string _pathRootVariable = "";

        static ErrorHandler _errorHandler = null;
        static System.Xml.XmlWriter _xmlLogFile = null;
        static string _xmlLogFileName = null;
        #endregion

        #region Public Methods and Properties
        /** <summary>Returns the mode that shall be used by the tools and actions.</summary>
         */
        public BuildMode Mode { get { return _mode; } set { _mode = value; } }

        /** <summary>Returns or defines the name of the XML log file that will be created on OpenXmlLogFile().</summary>
        */
        public static string XmlLogFileName
        {
            get
            {
                return _xmlLogFileName;
            }
            set
            {
                _xmlLogFileName = value;
            }
        }

        ///<summary> Is an <c>XmlLogFileName</c> has been configured, this will create a new protocol file of this name and initialize for writing.
        /// </summary>
        public static void OpenXmlLogFile()
        {
            try
            {
                if (_xmlLogFileName == null)
                    _xmlLogFile = null;
                else
                {
                    System.IO.FileStream stream = new System.IO.FileStream(_xmlLogFileName, FileMode.Create);
                    _xmlLogFile = new System.Xml.XmlTextWriter(stream, System.Text.Encoding.UTF8);
                    ((System.Xml.XmlTextWriter)_xmlLogFile).Formatting = System.Xml.Formatting.Indented;
                    _xmlLogFile.WriteStartElement("build"); // create root node
                    _xmlLogFile.WriteAttributeString("time", DateTime.Now.ToString("s"));
                    _xmlLogFile.WriteAttributeString("creator", System.Reflection.Assembly.GetExecutingAssembly().FullName);
                    _xmlLogFile.WriteAttributeString("validity", BuildProject.ValidityOfExecutingAssembly.ToString("s"));
                    _xmlLogFile.WriteAttributeString("config", BuildConfig.DefaultConfig);
                    _xmlLogFile.WriteAttributeString("build_system", System.Reflection.Assembly.GetExecutingAssembly().FullName);
                }
            }
            catch
            {
                _xmlLogFileName = null;
                _xmlLogFile = null;
            }
        }

        /// <summary>
        /// True iff the XML log file is open and active.
        /// </summary>
        public static bool IsOpenXmlLogFile
        {
            get
            {
                return _xmlLogFile != null;
            }
        }

        /** <summary>This will close the XML log file if one has been opened.</summary>
        */
        public static void CloseXmlLogfile()
        {
            if (_xmlLogFile != null)
            {
                _xmlLogFile.Close();
                _xmlLogFile = null;
            }
        }

        /** <summary>This will open a new section (XML subnode) in the XML log file if one has been opened.</summary>
        */
        public static void OpenSectionInXmlLogFile(string sectionName)
        {
            if (_xmlLogFile != null)
            {
                _xmlLogFile.WriteStartElement(sectionName);
                _xmlLogFile.WriteAttributeString("time", DateTime.Now.ToString("s"));
            }
        }

        /** <summary>This will close the deepest open section (XML node) on the XML logfile. </summary>
        */
        public static void CloseSectionInXmlLogFile()
        {
            if (_xmlLogFile != null)
            {
                try
                {
                    _xmlLogFile.WriteEndElement();
                    _xmlLogFile.Flush();
                }
                catch
                {
                }
            }
        }

        /** <summary>Creates an entry in the XML log file of one has been opened.</summary>
        */
        public static void LogOnXmlFile(ErrorObject obj)
        {
            if (_xmlLogFile != null)
            {
                switch (obj.Type)
                {
                    case ErrorObject.MessageType.Error: _xmlLogFile.WriteStartElement("error"); break;
                    case ErrorObject.MessageType.Warning: _xmlLogFile.WriteStartElement("warning"); break;
                    default: _xmlLogFile.WriteStartElement("message"); break;
                }
                _xmlLogFile.WriteAttributeString("time", DateTime.Now.ToString("s"));
                ErrorObject.ErrorNumber errNo = (ErrorObject.ErrorNumber)obj.GetErrorObject(typeof(ErrorObject.ErrorNumber));
                if (errNo != null)
                {
                    _xmlLogFile.WriteAttributeString("error_no", errNo.Value);
                }
                ErrorObject.FilePos filePos=(ErrorObject.FilePos)obj.GetErrorObject(typeof(ErrorObject.FilePos));
                if (filePos != null)
                {
                    if (filePos.Filename.Length > 0)
                        _xmlLogFile.WriteAttributeString("file", filePos.Filename);
                    if (filePos.Line >= 0)
                        _xmlLogFile.WriteAttributeString("line", filePos.Line.ToString());
                    if (filePos.Column >= 0)
                        _xmlLogFile.WriteAttributeString("column", filePos.Column.ToString());
                }
                _xmlLogFile.WriteString(obj.ToString());
                _xmlLogFile.WriteEndElement();
            }
        }

        public static void LogContentFileOnXmlFile(ContentFile file)
        {
            if (_xmlLogFile != null)
            {
                DateTime validityDemand = file.GetValidityDemand();
                _xmlLogFile.WriteStartElement("file");
                _xmlLogFile.WriteAttributeString("type", file.Type.ToString());
                if (validityDemand > DateTime.MinValue && validityDemand < DateTime.MaxValue)
                    _xmlLogFile.WriteAttributeString("validity", validityDemand.ToString("s"));
                _xmlLogFile.WriteString(file.FileName);
                _xmlLogFile.WriteEndElement();
            }
        }

        public static void LogContentFilesOnXmlFile(IFileProducts fileProducts)
        {
            if (_xmlLogFile != null)
            {
                foreach (ContentFile file in fileProducts.Files)
                    LogContentFileOnXmlFile(file);
            }
        }

        public static void LogResourceDesignatorOnXmlFile(ResourceDesignator rd)
        {
            if (_xmlLogFile != null)
            {
                _xmlLogFile.WriteStartElement("resource");
                _xmlLogFile.WriteAttributeString("internal_name", rd.Name);
                LogContentFileOnXmlFile(rd.ResourceFile);
                _xmlLogFile.WriteEndElement();
            }
        }

        public static void LogBuildProductOnXmlFiles(IBuildProduct buildProduct)
        {
            if (buildProduct is IFileProducts)
                LogContentFilesOnXmlFile((IFileProducts)buildProduct);
            else if (buildProduct is ResourceDesignator)
                LogResourceDesignatorOnXmlFile((ResourceDesignator)buildProduct);
            else
            {
                _xmlLogFile.WriteStartElement("build_object");
                _xmlLogFile.WriteAttributeString("validity", buildProduct.GetValidityDemand().ToString("s"));
                ICollection<RefToProject> projects = buildProduct.GetProjects();
                if (projects != null)
                {
                    foreach (RefToProject p in projects)
                    {
                        OpenProjectSectionInXmlLogFile(p.Project, false);
                        CloseSectionInXmlLogFile();
                    }
                }
                _xmlLogFile.WriteEndElement();
            }
        }


        public static void LogFeaturesOnXmlLog(FeatureList list)
        {
            if (_xmlLogFile != null && list.Count > 0)
            {
                _xmlLogFile.WriteStartElement("features");
                foreach (KeyValuePair<FeatureEntry, bool> pair in list)
                {
                    _xmlLogFile.WriteStartElement("feature");
                    _xmlLogFile.WriteAttributeString("symbol", pair.Key.Symbol);
                    _xmlLogFile.WriteAttributeString("name", pair.Key.Displayname);
                    _xmlLogFile.WriteAttributeString("valid", pair.Value.ToString());
                    _xmlLogFile.WriteString(pair.Key.Description);
                    _xmlLogFile.WriteEndElement();
                }
                _xmlLogFile.WriteEndElement();
            }
        }

        /** <summary>This will open a section on the provided project.
        * Close thiw like any other section with CloseSectionInXmlLog().</summary>
        */
        public static void OpenProjectSectionInXmlLogFile(BuildProject project, bool fullLog)
        {
            if (_xmlLogFile != null)
            {
                _xmlLogFile.WriteStartElement("project");
                _xmlLogFile.WriteAttributeString("name", project.Name);
                _xmlLogFile.WriteAttributeString("description", project.Description);
                //DateTime validityDemand=project.GetValidityDemand();
                //_xmlLogFile.WriteElementString("validity", validityDemand.ToString("s"));
                //DateTime validityDefiningAssemblies = project.ValidityOfDefiningAssemblies;
                //_xmlLogFile.WriteElementString("validity_defining_assemblies", validityDefiningAssemblies.ToString("s"));
                //DateTime validityTargets = project.GetValidityTargets();
                //_xmlLogFile.WriteElementString("validity_targets", validityTargets.ToString("s"));
                //bool targetsAreConsistent = project.TargetsAreConsistent(project.ValidityOfDefiningAssemblies);
                //_xmlLogFile.WriteElementString("consistency", targetsAreConsistent.ToString());
                if (fullLog)
                {
                    _xmlLogFile.WriteStartElement("targets");
                    ICollection<IBuildProduct> targets = project.GetTargets();
                    if (targets != null)
                    {
                        foreach (IBuildProduct target in targets)
                        {
                            LogBuildProductOnXmlFiles(target);
                        }
                    }
                    _xmlLogFile.WriteEndElement();
                    _xmlLogFile.WriteStartElement("prereq");
                    ICollection<IBuildProduct> prereqs = project.GetPrerequisites();
                    if (prereqs != null)
                    {
                        foreach (IBuildProduct prereq in prereqs)
                        {
                            LogBuildProductOnXmlFiles(prereq);
                        }
                    }
                    _xmlLogFile.WriteEndElement();
                }
            }
        }

        public static void LogStartInfoOnXmlLogFile(System.Diagnostics.ProcessStartInfo startInfo)
        {
            _xmlLogFile.WriteStartElement("startinfo");
            _xmlLogFile.WriteElementString("filename", startInfo.FileName);
            if (startInfo.Arguments != null)
            {
                _xmlLogFile.WriteStartElement("arguments");
                string[] lines = startInfo.Arguments.Split(' ');
                bool inQuotedString=false;
                bool firstLine = true;
                foreach (string line in lines)
                {
                    if (inQuotedString)
                        _xmlLogFile.WriteString(" ");
                    else if (!firstLine)
                        _xmlLogFile.WriteString("\n     ");
                    firstLine = false;
                    _xmlLogFile.WriteString(line);
                    int startIndex = 0;
                    while (startIndex >= 0)
                    {
                        startIndex = line.IndexOf('"', startIndex);
                        if (startIndex >= 0)
                        {
                            inQuotedString = !inQuotedString;
                            startIndex += 1;
                        }
                    }
                }
                _xmlLogFile.WriteEndElement();
            }
            _xmlLogFile.WriteEndElement();
        }

        public static void LogActionsOnXmlLogFile(ICollection<IBuildAction> actions)
        {
            if (_xmlLogFile != null)
            {
                _xmlLogFile.WriteStartElement("plan");
                foreach (IBuildAction action in actions)
                {
                    OpenBuildActionSectionInXmlLogFile(action, true);
                    CloseSectionInXmlLogFile();
                }
                _xmlLogFile.WriteEndElement();
            }
        }

        public static void LogProjectOnXmlLogFile(BuildProject project, bool fullLog)
        {
            if (_xmlLogFile != null)
            {
                OpenProjectSectionInXmlLogFile(project, fullLog);
                CloseSectionInXmlLogFile();
            }
        }

        public static void OpenBuildActionSectionInXmlLogFile(IBuildAction action, bool fullLog)
        {
            if (_xmlLogFile != null)
            {
                _xmlLogFile.WriteStartElement("action");
                _xmlLogFile.WriteAttributeString("name", action.Name);
                _xmlLogFile.WriteAttributeString("priority", action.Priority.ToString());
                //_xmlLogFile.WriteAttributeString("validity", action.GetValidityDemand().ToString("s"));
                //_xmlLogFile.WriteAttributeString("consistency", action.TargetsAreConsistent(DateTime.MinValue).ToString());
                if (action.Features != null && action.Features.Count > 0)
                {
                    LogFeaturesOnXmlLog(action.Features);
                }
                if (action is wx.Build.Release.CopyFileAction
                    || action is wx.Build.Release.ReplaceVersionInCSharpFile
                    || action is wx.Build.Release.ReplaceVersionInRCFile)
                {
                    fullLog = true;
                }
                if (fullLog && !(action is SequenceOfBuildActions) && !(action is AlternativeBuildActions))
                {
                    _xmlLogFile.WriteStartElement("targets");
                    ICollection<IBuildProduct> targets = action.GetTargets();
                    if (targets != null)
                    {
                        foreach (IBuildProduct target in targets)
                        {
                            LogBuildProductOnXmlFiles(target);
                        }
                    }
                    _xmlLogFile.WriteEndElement();
                }
                try
                {
                    System.Diagnostics.ProcessStartInfo startInfo = action.GetProgramStartInfo(new BuildToolFamilyEnv());
                    if (startInfo != null)
                        LogStartInfoOnXmlLogFile(startInfo);
                }
                catch
                { 
                }
                if (fullLog && !(action is SequenceOfBuildActions) && !(action is AlternativeBuildActions))
                {
                    _xmlLogFile.WriteStartElement("prereq");
                    ICollection<IBuildProduct> prereqs = action.GetPrerequisites();
                    if (prereqs != null)
                    {
                        foreach (IBuildProduct prereq in prereqs)
                        {
                            LogBuildProductOnXmlFiles(prereq);
                        }
                    }
                    _xmlLogFile.WriteEndElement();
                }
                ICollection<Type> parameterTypes=action.ParameterTypes;
                if (parameterTypes != null && parameterTypes.Count > 0)
                {
                    _xmlLogFile.WriteStartElement("param");
                    foreach(Type ptype in parameterTypes)
                    {
                        wx.Build.BuildParameters bparam=(wx.Build.BuildParameters)BuildConfig.GetDefaultParameterOfType(ptype);
                        if (bparam != null)
                            bparam.AdditionalInfoToXML(_xmlLogFile);
                    }
                    _xmlLogFile.WriteEndElement();
                }
                if (action is AlternativeBuildActions)
                {
                    _xmlLogFile.WriteStartElement("alternatives");
                    AlternativeBuildActions alt = (AlternativeBuildActions)action;
                    foreach (IBuildAction altaction in alt.Alternatives)
                    {
                        OpenBuildActionSectionInXmlLogFile(altaction, false);
                        CloseSectionInXmlLogFile();
                    }
                    _xmlLogFile.WriteEndElement();
                }
                else if (action is SequenceOfBuildActions)
                {
                    _xmlLogFile.WriteStartElement("sequence");
                    SequenceOfBuildActions seq = (SequenceOfBuildActions)action;
                    foreach(IBuildAction seqaction in seq)
                    {
                        OpenBuildActionSectionInXmlLogFile(seqaction, false);
                        CloseSectionInXmlLogFile();
                    }
                    _xmlLogFile.WriteEndElement();
                }
            }
        }

        /** <summary>The globally used error handler.
        * This may be \c null. In that case, the build program didn't specify an error handler.
        * Thus, all operations will be conducted silently.</summary>
        */
        public static ErrorHandler ConfiguredErrorHandler
        {
            get { return _errorHandler; }
            set { _errorHandler = value; }
        }

        /** <summary>Call this to handle an error obejct by the configures error handler.
        * This is a NOP if the build program didn't configure an error handler.</summary>
        */
        public static void HandleErrorObject(ErrorObject obj)
        {
            if (_errorHandler != null)
                _errorHandler(obj);
            LogOnXmlFile(obj);
        }

        /** <summary>Convenience function creating an ErrorObject and handing it to the configured error handler.
        * This is a NOP if the build program didn't configure an error handler.</summary>
        */
        public static void HandleErrorObject(ErrorObject.MessageType messageType, string msg, params object[] objects)
        {
            if (_errorHandler != null || _xmlLogFile != null)
                HandleErrorObject(new ErrorObject(messageType, msg, objects));
        }

        /** <summary>This is the name of the environment variable that will be used to determine the path root of all non-rootet local pathnames. </summary>
        * <remarks>Refer to \c PathRoot. The standard value here is empty (no effect). However, build programs may change this.</remarks>
        */
        public static string PathRootVariable
        {
            get { return _pathRootVariable; }
            set { _pathRootVariable = value; }
        }

        /// <summary>This returns or sets a base directory that will be used in instances of ContentFiles and
        /// FileSelector as base of non-rootet path names. Assigning a value to this property will cause 
        /// ContentFile.NormalizeOriginalFileName() actions in all known projects.
        /// </summary>
        /// <remarks>
        /// Typically, this is the directory of the entry assembly, i.e. the place of the build program. However, for those
        /// cases, where the build program is not securely located relatively to the code base of the project, you may
        /// alternatively specify an environment variable (property \c PathRootVariable). By default, the name of this
        /// variable is the name of the pathroot variable
        /// </remarks>
        public static string PathRoot
        {
            get
            {
                string result = null;
                if (PathRootVariable != null && PathRootVariable.Length > 0)
                {
                    result=System.Environment.GetEnvironmentVariable(PathRootVariable);
                    if (result != null)
                        result = System.IO.Path.GetFullPath(result);
                }
                if (result == null || result.Length == 0 || !System.IO.Directory.Exists(result))
                {
                    string codeBase = System.Reflection.Assembly.GetEntryAssembly().CodeBase;
                    Uri codeBaseUri = new Uri(codeBase);
                    codeBase = codeBaseUri.LocalPath;
                    result = System.IO.Path.GetDirectoryName(codeBase);
                    result = System.IO.Path.GetFullPath(result);
                }
                return result;
            }
            set
            {
                value=GetFullPathname(value);
                if (PathRootVariable == null || PathRootVariable.Length == 0)
                    PathRootVariable = "WXBUILDROOT";
                Environment.SetEnvironmentVariable(PathRootVariable, value);
                foreach (BuildProject p in BuildProject.GetKnownProjects())
                {
                    p.NormalizeOriginalFileName(value);
                }
            }
        }

        /// <summary>
        /// Returns the argument as full pathname. However, relative paths will be interpreted relatively to
        /// the <c>PathRoot</c> rather than to the current working directory.
        /// </summary>
        public static string GetFullPathname(string pathname)
        {
            if (System.IO.Path.IsPathRooted(pathname))
                return System.IO.Path.GetFullPath(pathname); // this completion is not redundant under windows because
                                                            // also paths without volume descriptor are rooted. however,
                                                           // this system relies on really complete path descriptors.
            else
            {
                string pathRoot=PathRoot;
                string fullName = System.IO.Path.Combine(pathRoot, pathname);
                fullName = System.IO.Path.GetFullPath(fullName);
                //HandleErrorObject(ErrorObject.MessageType.Message, "Deriving {0} from original pathname {1} presupposing root path {2}.", fullName, pathname, pathRoot);
                return fullName;
            }
        }

        /** <summary>Set whether to treat all warnings as errors.</summary>
         */
        public AbortOptions AbortOptions = AbortOptions.AlwaysTryToProduceASomehowUsefulTarget;

        /** <summary>Returns the name of all confirgurations.</summary>
         */
        public static ICollection<string> KnownConfigs { get { return _configs.Keys; } }

        /** <summary>Is true iff the name is the name of a known configuration.</summary>
         * <param name="name">The suspected name of a configuration.</param>
         */
        public static bool KnowConfig(string name)
        {
            return _configs.ContainsKey(name);
        }

        /** <summary>Returns the properties of the BuildConfig.DefaultConfig.</summary>
         */
        public static BuildConfig GetConfig()
        {
            return BuildConfig.GetConfig(BuildConfig.DefaultConfig);
        }

        /** <summary>Returns the designated configuration.
         * This throws an System.ArgumentOutOfRangeException() if the configuration
         * is not known.
         *
         * Predefined configurations are "release", "debug".</summary>
         */
        public static BuildConfig GetConfig(string name)
        {
            if (_configs.ContainsKey(name))
                return _configs[name];
            else
                throw new ArgumentOutOfRangeException("Try to read unknown build configuration.");
        }

        /** <summary>Defines the default configuration.
         * Read this to find out the name of the default configuration.
         * If you set a new default configuration, please use an already known configuration name, since this 
         * will raise an System.ArgumentOutOfRangeException() if the new name is yet unknown.
         * <para>
         * If the new configuration contains a PreferredModeParameter, the mode of the operation will be
         * changed accordingly.
         * </para></summary>
         * 
         */
        public static string DefaultConfig
        {
            get
            {
                return _defaultParam;
            }
            set
            {
                if (!_configs.ContainsKey(value))
                    throw new ArgumentOutOfRangeException("Cannot set unknown configuration as default.");
                _defaultParam = value;
            }
        }

        /** <summary>Returns an instance of the argument type from the currently selected default parameters.
         * The most convenient accessor for parameters. Reads the default configuration. Reads the parameter 
         * of the provided type from this parameter set and returns it if this exists. Otherwise, calls
         * default CTor on the provided type.</summary>
         */
        public static BuildParameters GetDefaultParameterOfType(Type parameterType)
        {
            BuildConfig currentConfig = BuildConfig.GetConfig(BuildConfig.DefaultConfig);
            if (currentConfig.Contains(parameterType))
                return currentConfig[parameterType];
            BuildParameters result = (BuildParameters)System.Activator.CreateInstance(parameterType);
            return result;
        }

        /** <summary>Creates a new configuration that contains the same parameters as the argument. </summary>
         */
        public static void NewConfigFrom(string nameOfTheNewConfiguration, string existingConfig)
        {
            BuildConfig newConfig = (BuildConfig)GetConfig(existingConfig).MemberwiseClone();
            newConfig._name = nameOfTheNewConfiguration;
            _configs[nameOfTheNewConfiguration] = newConfig;
        }

        /** <summary>Creates a new configuration that contains the same parameters as the argument and makes it the default one of specified. </summary>
         */
        public static void NewConfigFrom(string nameOfTheNewConfiguration, string existingConfig, bool makeDefault)
        {
            NewConfigFrom(nameOfTheNewConfiguration, existingConfig);
            if (makeDefault)
                DefaultConfig = nameOfTheNewConfiguration;
        }

        /** <summary>Remove the named configuration if it exists and return \c true. If is does not exist, return <c>false</c>.</summary>
         */
        public static bool RemoveConfig(string nameOfTheConfigToRemove)
        {
            if (_configs.ContainsKey(nameOfTheConfigToRemove))
            {
                _configs.Remove(nameOfTheConfigToRemove);
                return true;
            }
            else
                return false;
        }
        #endregion

        #region CTor
        /** <summary> The static CTor will create the standard configurations.
         * Standard configurations are "Release" and "Debug". </summary> */
        static BuildConfig()
        {
            Net.NetCompilerParameters netDebugParams=new wx.Build.Net.NetCompilerParameters();
            netDebugParams.OptimizeOutput=false;
            netDebugParams.IncludeDebugInformation=true;
            Cxx.CxxParameters cxxDebugParams = new wx.Build.Cxx.CxxParameters();
            cxxDebugParams.DebugInfo = true;
            cxxDebugParams.Incremental = true;
            cxxDebugParams.WarningLevel = Cxx.CxxWarningLevel.QualityWarnings;
            cxxDebugParams.Optimization = Cxx.CxxOptimization.No;
            cxxDebugParams.AddOptions("cl.exe", "/FD"); // minimale Neuerstellung
            cxxDebugParams.AddOptions("link.exe", "/OPT:NOREF /OPT:NOICF");
            cxxDebugParams.AddOptions("link.exe", "/DYNAMICBASE:NO"); // Mit dieser Option wird der Header einer ausf�hrbaren Datei ge�ndert, um anzugeben, ob f�r die Anwendung zur Ladezeit nach dem Zufallsprinzip ein Rebase-Vorgang ausgef�hrt werden soll.
                // Address Space Layout Randomization wird nur unter Windows Vista und sp�teren Betriebssystemen unterst�tzt.
            BuildConfig debugConfig=new BuildConfig("Debug", netDebugParams, new TempFilesParameters(), cxxDebugParams);
            debugConfig.Mode = BuildMode.BuildMissingTargets;
            _configs.Add("Debug", debugConfig);

            BuildConfig releaseConfig = new BuildConfig("Release", new Net.NetCompilerParameters(), new TempFilesParameters());
            //releaseConfig.Mode = BuildMode.BuildNew;
            _configs.Add("Release", releaseConfig);
        }
        #endregion

        #region Access of Tools
        static IBuildActionProvider[] _allActionClasses = null;
        /** <summary>All available action providers.</summary>
         */
        public static IBuildActionProvider[] AllActionProviders
        {
            get
            {
                if (_allActionClasses == null)
                {
                    List<IBuildActionProvider> result = new List<IBuildActionProvider>();
                    foreach (Type type in System.Reflection.Assembly.GetExecutingAssembly().GetTypes())
                    {
                        if (type.GetInterface(typeof(IBuildActionProvider).Name) != null)
                            result.Add((IBuildActionProvider)Activator.CreateInstance(type));
                    }
                    _allActionClasses = result.ToArray();
                }
                return _allActionClasses;
            }
        }

        /** <summary> Pass a message on the configured error.</summary><remarks>
         * \param message is the message where wild cards like {0} will be expanded by the corresponding item of <c>objects </c> .
         * \param objects is an arrayof error objects that might be used in the <c>message </c>  format string. </remarks> */
        static public void HandleMessageObject(string message, params object[] objects)
        {
            if (_errorHandler != null)
            {
                ErrorObject messageObject = new ErrorObject(ErrorObject.MessageType.Message, message, objects);
                _errorHandler(messageObject);
            }
        }

        /** <summary> All action providers producing files of type <c>target </c> .</summary><remarks>
         * \param target is the desired type of contents. </remarks> */
        static List<IBuildActionProvider> ListOfActionProvidersProducing(ContentType target)
        {
            List<IBuildActionProvider> result = new List<IBuildActionProvider>();
            foreach (IBuildActionProvider actionProvider in AllActionProviders)
            {
                if (actionProvider.IsAvailable)
                {
                    ICollection<ContentType> targets = actionProvider.ContentFileTargets;
                    if (targets.Contains(target))
                    {
                        result.Add(actionProvider);
                    }
                    else
                    {
                        // However, the action provider might produce a more special type (containing the target).
                        foreach (ContentType actionTarget in targets)
                        {
                            if (actionTarget.Implies(target))
                            {
                                result.Add(actionProvider);
                                break;
                            }
                        }
                    }
                }
            }
            return result;
        }

        /** <summary> All action providers producing files of type <c>target </c> .</summary><remarks>
         * \param target is the desired type of contents. </remarks> */
        public static ICollection<IBuildActionProvider> ActionProvidersProducing(ContentType target)
        {
            return ListOfActionProvidersProducing(target);
        }

        /// <returns>All action providers producing files of type <c>target</c> that only have prereqs from <c>acceptablePrereqs</c>.
        /// </returns>.
        /// <param name="target">is the type of file that shall be produced conducting the requested action</param>
        /// <param name="acceptablePrereqs">may be <c>null</c> in order to state that all providers of <c>target</c> are welcome.</param>
        public static ICollection<IBuildActionProvider> ActionProvidersProducing(ContentType target, ICollection<ContentType> acceptablePrereqs)
        {
            CommandLineOptions options = (CommandLineOptions) BuildConfig.GetDefaultParameterOfType(typeof(CommandLineOptions));
            List<IBuildActionProvider> result = ListOfActionProvidersProducing(target);
            Stack<int> toRemove = new Stack<int>();
            for (int index=0; index < result.Count; ++index)
            {
                IBuildActionProvider actionProvider=result[index];
                if (acceptablePrereqs != null && !actionProvider.MayContentFilePrerequisitesSuffice(target, acceptablePrereqs))
                    toRemove.Push(index);
                else if (options != null && (options.IsDisabled(actionProvider.Name)))
                    toRemove.Push(index);
                else if (options != null && actionProvider.ToolFamily!= null && options.IsDisabled(actionProvider.ToolFamily))
                    toRemove.Push(index);
            }
            if (toRemove.Count > 0)
            {
                while (toRemove.Count > 0)
                {
                    int indexToRemove = toRemove.Pop();
                    result.RemoveAt(indexToRemove);
                }
            }
            return result;
        }

        /// <summary> Returns a collection of actions that are able to produce <c>target </c>  presupposing at most the content files from <c>acceptablePrereqs </c> .
        /// The actions will be initilaized with <c>features </c> . </summary>
        /// <param name="p">The project that requires these actions. This method will use the features of this project.</param>
        /// <param name="target">The target that shall be created by the requested actions.</param>
        /// <param name="acceptablePrereqs">The build products that can be supposed to exist. actions may refer to these products.</param>
        /// <param name="env">An opportunity for tools of the same family to share state.</param>
        public static CollectionOfBuildActions ActionsProducing(BuildProject p, BuildToolFamilyEnv env, ContentFile target, ICollection<IBuildProduct> acceptablePrereqs)
        {
            Dictionary<ContentType, ContentType> prereqType = new Dictionary<ContentType, ContentType>();
            foreach (IBuildProduct acceptablePrereq in acceptablePrereqs)
            {
                if (acceptablePrereq is IFileProducts)
                {
                    foreach (ContentFile contentFile in ((IFileProducts)acceptablePrereq).Files)
                        prereqType[contentFile.Type] = contentFile.Type;
                }
            }
            ICollection<IBuildActionProvider> availableActionProvider=BuildConfig.ActionProvidersProducing(target.Type, prereqType.Values);
            CollectionOfBuildActions result = new CollectionOfBuildActions();
            if (availableActionProvider.Count == 0)
            {
                HandleErrorObject(new ErrorObject(ErrorObject.MessageType.Error, "Can not find applicable tool to create {0}.", target));
                return result;
            }
            CommandLineOptions options = (CommandLineOptions)BuildConfig.GetDefaultParameterOfType(typeof(CommandLineOptions));
            foreach (IBuildActionProvider actionProvider in availableActionProvider)
            {
                IBuildAction action = actionProvider.Create(env, target, acceptablePrereqs);
                if (action == null)
                    continue;
                if (options != null && options.IsDisabled(action.Name))
                    continue;
                action.Project = p;
                if (options != null && options.IsPreferred(action.Name))
                    result.Add(ActionPriority.PreferredByUserInput, action);
                else if (options != null && options.IsPreferred(action.ActionProvider.ToolFamily))
                    result.Add(ActionPriority.PreferredByUserInput, action);
                else
                    result.Add(action);
            }
            return result;
        }

        /// <summary>This will try to produce <c>target</c> presupposing <c>acceptablePrereqs</c>.
        /// This will first try to find ActionsProducing(). Then, they will be executed in order of ActionPriority
        /// until one succeeds.</summary>
        /// <returns>the successfully executed action or \c null in case of errors.</returns>
        /// <param name="acceptablePrereqs">Collection of those biuld products that are considered to be available.</param>
        /// <param name="p">This is the project that requests the actions to produce the targets. This method will use the features of this project.</param>
        /// <param name="target">The file that shall be created by the requested actions.</param>
        /// <param name="env">An opportunity for actions of the same family to share state.</param>
        /// <param name="validityOfBuildSystem">indicates the last change of either this DLL or the assembly defining the project.
        ///  So, all action will be repeated (even if rebuild is specified) if the project definition changes or the implementation
        /// of the build system has been enhanced since the final build. This argument will be computed and propagated by
        /// the project.</param>
        public static IBuildAction ProduceTargetWithPrereqs(BuildProject p, BuildToolFamilyEnv env, DateTime validityOfBuildSystem, ContentFile target, ICollection<IBuildProduct> acceptablePrereqs)
        {
            CollectionOfBuildActions actions = BuildConfig.ActionsProducing(p, env, target, acceptablePrereqs);
            if (actions.Count == 0)
            {
                HandleErrorObject(new ErrorObject(ErrorObject.MessageType.Error, "Could not find an applicable action to create {0}.", target));
                return null;
            }
            return RunOneOfArgumens(env, validityOfBuildSystem, actions);
        }

        /** <summary> Runs one out of the argument actions.</summary><remarks>
        * This will run the <c>actions </c>  from the argument until the first succeeds. This succeeding action will be returned.
        * If all actions fail (or the argument is empty), the result will be <c>null </c> .
        * 
        * Note, that this method will run actions according to the current mode <c>BuildConfig </c> .GetConfig().Mode.
        * If BuildMode.Rebuild is specified, this will test availability and validity of targets before conducting any
        * actions.
        *
        * \param validityOfBuildSystem indicates the last change of either this DLL or the assembly defining the project.
        *  So, all action will be repeated (even if rebuild is specified) if the project definition changes or the implementation
        *  of the build system has been enhanced since the final build. This argument will be computed and propagated by
        * the project. </remarks> */
        public static IBuildAction RunOneOfArgumens(BuildToolFamilyEnv env, DateTime validityOfBuildSystem, CollectionOfBuildActions actions)
        {
            foreach (IBuildAction action in actions)
            {
                try
                {
                    BuildConfig.OpenBuildActionSectionInXmlLogFile(action, false);
                    if (BuildConfig.GetConfig().Mode == BuildMode.BuildMissingTargets && action.TargetsAreConsistent(validityOfBuildSystem))
                    {
                        HandleErrorObject(new ErrorObject(ErrorObject.MessageType.Message, "Targets of action {0} are consistent.", action.ActionProvider.Name, action.ActionProvider.Description));
                        return action;
                    }
                    HandleErrorObject(new ErrorObject(ErrorObject.MessageType.Message, "Running {0}", action.ActionProvider.Name, action.ActionProvider.Description));
                    if (action.Execute(env, validityOfBuildSystem))
                    {
                        HandleErrorObject(new ErrorObject(ErrorObject.MessageType.Message, "Action {0} succeeded.", action.ActionProvider.Name));
                        return action;
                    }
                    HandleErrorObject(new ErrorObject(ErrorObject.MessageType.Message, "Action {0} failed.", action.ActionProvider.Name));
                }
                finally
                {
                    BuildConfig.CloseSectionInXmlLogFile();
                }
            }
            return null;
        }
        #endregion
        #endregion
    }
}
