/** Build system for wx.NET.
 * 
 * This DLL contains basic implementations to build (compile and link) C/C++ programs,
 * compile .NET assemblies written in C#, sign them, and install them.
 * 
 * This file contains the wrappers of the mono-tools.
 * 
 * \file 
 *
 * Copyright 2009-2010 Harald Meyer auf'm Hofe harald_meyer@users.sourceforge.net
 * 
 * Licensed under the wxWidgtes license, see LICENSE.txt for details.
 * 
 * $Id: MonoTools.cs,v 1.18 2010/06/16 18:12:32 harald_meyer Exp $
 */

using System;
using System.Collections.Generic;
using System.IO;
using System.Diagnostics;

/** Contains wrappers of the Mono .NET framework and SDK tools.
 */
namespace wx.Build.Mono
{
    /** <summary>This class contains some methods to load properties of the installed Mono Frameworks from the registry.
     * This will be applied on Windows platforms.</summary>
     */
    public class ToolProperties
    {
        /** <summary> <c>HLM </c> \SOFTWARE\Novel\Mono </summary> */
        static Microsoft.Win32.RegistryKey DotNetBaseKey
        {
            get
            {
                try
                {
                Microsoft.Win32.RegistryKey result=Microsoft.Win32.Registry.LocalMachine.OpenSubKey("SOFTWARE");
                if (result != null)
                    result=result.OpenSubKey("Novell");
                if (result != null)
                    result = result.OpenSubKey("Mono");
                return result;
                }
                catch
                {
                   return null;
                }
            }
        }

        /** <summary> Returns the path to the default framework from the registry database. </summary> */
        static Microsoft.Win32.RegistryKey GetDefaultClrKey()
        {
            Microsoft.Win32.RegistryKey baseKey = DotNetBaseKey;
            if (baseKey == null)
                return null;
            string defaultCLR=(string)baseKey.GetValue("DefaultCLR");
            return baseKey.OpenSubKey(defaultCLR);
        }

        /// <returns> the path to the default framework from the registry database.
        /// Example: <tt> C:\Program Files\Mono-2.2</tt></returns>
        static public string GetDefaultClrDir()
        {
            Microsoft.Win32.RegistryKey defaultClrKey = GetDefaultClrKey();
            if (defaultClrKey == null)
                return null;
            return (string)defaultClrKey.GetValue("SdkInstallRoot");
        }

        /// <returns> Returns the path to the default framework tools from the registry database.
        /// Example: <tt>C:/Program Files/Mono-2.2/bin</tt>
        /// </returns>
        static public string GetDefaultToolDir()
        {
            string defaultClrDir = GetDefaultClrDir();
            if (defaultClrDir == null)
                return null;
            return Path.Combine(defaultClrDir, "bin");
        }

        /** <summary> Looks for the tool in the GetDefaultDir() first, then also in <c>GetDefaultDir()/lib/mono/2 </c> .0
         * </summary> */
        static public string GetPathToFrameworkTool(string toolname)
        {
            string defaultToolDir=GetDefaultToolDir();
            if (defaultToolDir == null)
                return null;
            string path = Path.Combine(defaultToolDir, toolname);
            if (File.Exists(path))
                return path;
            else
            {
                path = Path.Combine(GetDefaultClrDir(), "lib");
                path=Path.Combine(path, "mono");
                path = Path.Combine(path, "2.0");
                path = Path.Combine(path, toolname);
                if (File.Exists(path))
                    return path;
                else
                    return null;
            }
        }

        static public string GmcsPrg
        {
            get
            {
                if (System.Environment.OSVersion.Platform == PlatformID.Unix)
                    return "gmcs";
                else
                    return ToolProperties.GetPathToFrameworkTool("gmcs.exe");
            }
        }

        static public string MonoPrg
        {
            get
            {
                if (System.Environment.OSVersion.Platform == PlatformID.Unix)
                    return "mono";
                else
                    return ToolProperties.GetPathToFrameworkTool("mono.exe");
            }
        }
    }

    /// <summary>Wrapper around the <tt>gmcs</tt> compiler shipped with the Mono.NET framework.
    /// This tool will be the default on platforms others than Windows if available.
    /// There is another more generic tool using the System.CodeDom.Compiler namespace:
    /// wx.Build.Net.NetCodeProvider.
    /// <para>
    /// This tool will add <tt>__MONO_GMCS__</tt> to the defined symbols for conditional compilation.
    /// </para></summary>
    public class Gmcs : BaseAction, IBuildActionProvider, IBuildAction
    {
        #region State
        protected ContentFile _target;
        protected FileProducts _sources = new FileProducts(ContentType.CSharpCode);
        protected FileProducts _references = new FileProducts(ContentType.DotNetDll);
        protected FileProducts _icons = new FileProducts(ContentType.ICO);
        protected FileProducts _signatureFile = new FileProducts(ContentType.SnKeys);

        protected string _mainClass = null;
        #endregion

        #region statics
        /** <summary> Will be used with LINUX to store avilability. </summary> */
        bool? _compilerAvailable = null;
        #endregion

        #region CTor
        /** <summary> This creates an instance without data to be used as <c>IBuildActionClass </c> . </summary> */
        public Gmcs()
        {
            this._target = null;
        }
        #endregion

        #region Overrides
        public override ICollection<IBuildProduct> GetPrerequisites()
        {
            List<IBuildProduct> result = new List<IBuildProduct>();
            if (this._sources.Count>0)
                result.Add(this._sources);
            if (this._references.Count>0)
                result.Add(this._references);
            if (this._icons.Count > 0)
                result.Add(this._icons);
            if (this._signatureFile.Count > 0)
                result.Add(this._signatureFile);
            return result;
        }

        public override bool ContainsPrerequisite(IBuildProduct prereq)
        {
            return this._sources.Contains(prereq)
                || this._references.Contains(prereq)
                || this._icons.Contains(prereq)
                || this._signatureFile.Contains(prereq);
        }

        public override ICollection<IBuildProduct> GetTargets()
        {
            List<IBuildProduct> result = new List<IBuildProduct>();
            result.Add(this._target);
            return result;
        }
        #endregion

        #region IBuildActionProvider Member
        /** <summary> Only available on Windows Systems. </summary> */
        public ICollection<OperatingSystem> ApplicableOSs
        {
            get
            {
                List<OperatingSystem> result = new List<OperatingSystem>();
                result.Add(OperatingSystem.WinXP);
                result.Add(OperatingSystem.Linux);
                result.Add(OperatingSystem.MacOsX);
                return result;
            }
        }

        /// <returns> "gmcs"</returns>
        public string Name
        {
            get { return "gmcs"; }
        }

        /// <summary>
        /// Group is "MONO".
        /// </summary>
        public string ToolFamily
        {
            get { return "MONO"; }
        }

        /// <summary>The filename of the tool.</summary>
        public string FileName
        {
            get
            {
                if (System.Environment.OSVersion.Platform == PlatformID.Unix)
                    return ToolProperties.GetPathToFrameworkTool(this.Name);
                else
                    return ToolProperties.GetPathToFrameworkTool(this.Name + ".exe");
            }
        }

        public string Description
        {
            get { return string.Format("{0}: The C# compiler of the MONO .NET framework.", this.FileName); }
        }

        public bool IsAvailable
        {
            get
            {
                // This is part of the .NET framework.
                if (System.Environment.OSVersion.Platform == PlatformID.Unix)
                {
                    if (_compilerAvailable == null)
                    {
                      try {
                        ProcessStartInfo call = new ProcessStartInfo();
                        call.FileName = "gmcs ";
                        call.Arguments = "--version";
                        Process p=Process.Start(call);
                        p.WaitForExit();
                        _compilerAvailable = true;
                      } catch (Exception exc) {
                        BuildConfig.HandleMessageObject("Failed to run gmcs: {0}.", exc.Message);
                        _compilerAvailable=false;
                      }
                    }
                    return _compilerAvailable.Value;
                }
                else
                {
                    return
                        ToolProperties.GetPathToFrameworkTool("mono.exe") != null
                        && ToolProperties.GetPathToFrameworkTool(this.Name + ".exe") != null;
                }
            }
        }

        /** <summary> This requires a signature key file to produce strong named assemblies. </summary> */
        public bool MayContentFilePrerequisitesSuffice(ContentType target, ICollection<ContentType> prerequisites)
        {
            bool requiresSN = false;
            if (target.Implies(ContentType.SnDotNetDll))
                requiresSN = true;
            bool foundCSharp = false;
            bool foundSN = false;
            foreach (ContentType contentFile in prerequisites)
            {
                if (contentFile.Equals(ContentType.CSharpCode))
                    foundCSharp = true;
                if (contentFile.Equals(ContentType.SnKeys))
                    foundSN = true;
                bool ok = foundCSharp && (!requiresSN || foundSN);
                if (ok)
                    return true;
            }
            return false;
        }

        public ICollection<ContentType> ContentFileTargets
        {
            get { return new ContentType[] { ContentType.DotNetModule, ContentType.DotNetDll, ContentType.DotNetExe, ContentType.SnDotNetDll, ContentType.SnDotNetExe, ContentType.SnDotNetShellExe }; }
        }

        /** <summary> This will create an action from the provided file objects.
         * This will deal with IFileProducts of the </summary> */
        public IBuildAction Create(BuildToolFamilyEnv env, IBuildProduct target, ICollection<IBuildProduct> prerequisites)
        {
            Gmcs result = new Gmcs();
            ContentFile assemblyTarget = target as ContentFile;
            if (assemblyTarget == null
                || (!ContentType.DotNetDll.Contains(assemblyTarget.Type)
                    && !ContentType.DotNetModule.Contains(assemblyTarget.Type)))
            {
                throw new ArgumentException("Gmcs is for building assemblies. Creation with wrong kind of build target.");
            }
            result._target = assemblyTarget;

            foreach (IBuildProduct prerequisite in prerequisites)
            {
                IFileProducts file = prerequisite as IFileProducts;
                if (file != null)
                {
                    if (file.Type.Implies(ContentType.DotNetDll))
                        result._references.Add(file);
                    else if (file.Type.Implies(ContentType.CSharpCode))
                        result._sources.Add(file);
                    else if (file.Type.Implies(ContentType.ICO))
                        result._icons.Add(file);
                    else if (file.Type.Implies(ContentType.SnKeys))
                        result._signatureFile.Add(file);
                }
            }
            if (result._sources.Count == 0)
                throw new ArgumentException(string.Format("Gmcs requires at least on C# source as input."));
            return result;
        }

        #endregion

        #region IBuildAction Member
        /** <summary> <c>this </c>  is its own action provider. </summary> */
        public IBuildActionProvider ActionProvider
        {
            get { return this; }
        }

        public override ICollection<Type> ParameterTypes
        {
            get
            {
                return new Type[] { typeof(wx.Build.Net.NetCompilerParameters) };
            }
        }

        /** <summary> This is default.
         * On windows, we will prefer the MS .NET framework if present. </summary> */
        public ActionPriority Priority
        {
            get
            {
                return ActionPriority.Default;
            }
        }

        #endregion

        #region BOO Export
        public override void AppendToBooPreamble(BuildToolFamilyEnv env, List<string> importModules, List<string> booDeclarations, List<string> booDefinitions)
        {
            #region Declarations
            booDeclarations.Add("# This is the name of the gmcs C# compiler of the MONO project (http://www.go-mono.org)");
            if (Environment.OSVersion.Platform == PlatformID.Unix)
                booDeclarations.Add("GMCS_FILENAME='gmcs'");
            else
                booDeclarations.Add(string.Format("GMCS_FILENAME=\"{0}\"", ContentFile.ConvertFilenameToString( ToolProperties.MonoPrg)));
            booDeclarations.Add("# These are the options for the GMCS Mono C#-Compiler.");
            if (Environment.OSVersion.Platform == PlatformID.Unix)
                booDeclarations.Add("GMCS_OPTIONS=''");
            else
                booDeclarations.Add(string.Format("GMCS_OPTIONS='{0}' # GMCS will be startetusing the mono runtime environement. thus, MONO is the program to start and the GMCS program is the first argument", ContentFile.ConvertFilenameToString(this.FileName)));
            wx.Build.Net.NetCompilerParameters netParameters = (wx.Build.Net.NetCompilerParameters)BuildConfig.GetDefaultParameterOfType(typeof(wx.Build.Net.NetCompilerParameters));
            string debugInfo = "#";
            if (netParameters.IncludeDebugInformation)
                debugInfo = "";
            booDeclarations.Add(debugInfo + "GMCS_OPTIONS+=' -debug' # uncomment this to include debug info");
            string optimization = "#";
            if (netParameters.OptimizeOutput)
                optimization = "";
            booDeclarations.Add(optimization+"GMCS_OPTIONS+=' -optimize+' # uncomment this to produce optimized code");
            string warningLevel = "#";
            if (netParameters.WarningLevel >= 0)
                warningLevel = "";
            booDeclarations.Add(string.Format("{0}GMCS_OPTIONS+=' -warn:{1}' # use this option to define the warning level.", warningLevel, netParameters.WarningLevel));
            booDeclarations.Add("GMCS_OPTIONS+= ' -fullpaths' # use full paths in warnings and errors");
            booDeclarations.Add("GMCS_OPTIONS+= ' -define:__MONO_GMCS__' # this symbol identifies the compiler");

            string warnAsErrorComment = "#";
            if (BuildConfig.GetConfig().AbortOptions == AbortOptions.TreatWarningsAsErrors)
                warnAsErrorComment = "";
            booDeclarations.Add(warnAsErrorComment+"GMCS_OPTION+=' -warnaserror' # Treats warnings as errors");
            string enableTraceLogComment = "#";
            if (netParameters.EnableTraceLog)
                enableTraceLogComment = "";
            booDeclarations.Add(enableTraceLogComment+"GMCS_OPTIONS+=' -define:TRACE' # This enables the trace log");
            #endregion

            #region Definitions
            booDefinitions.Add("def RunMonoGmcs(targettype as string, target as string, sources as (string), references as (string), win32icon as string, signature as string, mainclass as string, features):");
            booDefinitions.Add("\tif not TestForRebuild(target, win32icon, signature, references, sources):");
            booDefinitions.Add("\t\tprint target,\"is up to date\"");
            booDefinitions.Add("\t\treturn");
            booDefinitions.Add("\tprint \"MONO gmcs.exe creates\", target");
            booDefinitions.Add("\targs=\"-out:\\\"${target}\\\" -target:${targettype}\"");
            booDefinitions.Add("\tfor feature in features:");
            booDefinitions.Add("\t\targs+=\" -define:${feature}\"");
            booDefinitions.Add("\tfor reference in references:");
            booDefinitions.Add("\t\targs+=\" -reference:${reference}\"");
            booDefinitions.Add("\tif win32icon != null:");
            booDefinitions.Add("\t\targs+=\" -win32icon:${win32icon}\"");
            booDefinitions.Add("\tif signature != null:");
            booDefinitions.Add("\t\targs+=\" -keyfile:${signature}\"");
            booDefinitions.Add("\tif mainclass != null:");
            booDefinitions.Add("\t\targs+=\" -main:${mainclass}\"");
            booDefinitions.Add("\tfor source in sources:");
            booDefinitions.Add("\t\targs+=\" \\\"${source}\\\"\"");
            booDefinitions.Add("\tstartinfo=System.Diagnostics.ProcessStartInfo()");
            booDefinitions.Add("\tstartinfo.FileName=GMCS_FILENAME");
            booDefinitions.Add("\tstartinfo.Arguments=\"${GMCS_OPTIONS} ${args}\"");
            booDefinitions.Add("\tstartinfo.UseShellExecute=false");
            booDefinitions.Add("\tp=System.Diagnostics.Process.Start(startinfo)");
            booDefinitions.Add("\tp.WaitForExit()");
            booDefinitions.Add("\tif p.ExitCode!=0:");
            booDefinitions.Add("\t\traise System.Exception(\"Build action failed.\")");
            #endregion
        }

        public override void AppendBooCode(List<string> booCodeLines, string indention, BuildToolFamilyEnv env)
        {
            System.Text.StringBuilder line = new System.Text.StringBuilder();
            line.Append(indention);
            line.Append("RunMonoGmcs(");
            if (ContentType.DotNetShellExe.Contains(this._target.Type))
                line.Append("\"exe\", ");
            else if (ContentType.DotNetExe.Contains(this._target.Type))
                line.Append("\"winexe\", ");
            else if (ContentType.DotNetModule.Contains(this._target.Type))
                line.Append("\"module\", ");
            else
                line.Append("\"library\", ");
            line.AppendFormat("\"{0}\", ", this._target.FileNameAsBooString);
            line.Append("(");
            foreach(ContentFile source in this._sources.Files)
                line.AppendFormat("\"{0}\", ", source.FileNameAsBooString);
            line.Append("), ");
            line.Append("(");
            foreach(ContentFile reference in this._references.Files)
                line.AppendFormat("\"{0}\", ", reference.FileNameAsBooString);
            line.Append("), ");
            if (this._icons.Files.Count > 0)
                line.AppendFormat("\"{0}\", ", this._icons.Files.GetOneFile().FileNameAsBooString);
            else
                line.Append("null, ");

            if (this._signatureFile.Files.Count > 0)
                line.AppendFormat("\"{0}\", ", this._signatureFile.Files.GetOneFile().FileNameAsBooString);
            else
                line.Append("null, ");
            if (this._mainClass != null && this._mainClass.Length > 0)
                line.Append("\"" + this._mainClass + "\", ");
            else 
                line.Append("null, ");
            if (this.Project != null && this.Project.Features != null && this.Features.Count > 0)
                line.Append("Features_" + this.Project.NameAsSymbol);
            else
                line.Append("[]");
            line.Append(")");
            booCodeLines.Add(line.ToString());
        }
        #endregion

        #region IBuildProduct Member
        public override ProcessStartInfo GetProgramStartInfo(BuildToolFamilyEnv env)
        {
            ProcessStartInfo result = new ProcessStartInfo();
            System.Text.StringBuilder cmd = new System.Text.StringBuilder();
            if (Environment.OSVersion.Platform == PlatformID.Unix)
            {
               result.FileName = "gmcs";
            }
            else
            {
               result.FileName = ToolProperties.MonoPrg;
               cmd.Append(this.FileName);
            }
            cmd.Append(" -out:" + this._target.FileName);
            if (ContentType.DotNetShellExe.Contains(this._target.Type))
                cmd.Append(" -target:exe");
            else if (ContentType.DotNetExe.Contains(this._target.Type))
                cmd.Append(" -target:winexe");
            else if (ContentType.DotNetModule.Contains(this._target.Type))
                cmd.Append(" -target:module");
            else
                cmd.Append(" -target:library");
            foreach (ContentFile assemblyLink in this._references.Files)
            {
                cmd.Append(" -reference:" + assemblyLink.QuotedFileName);
            }
            foreach (ContentFile file in this._icons.Files)
            {
                if (!file.Type.Implies(ContentType.ICO))
                    throw new Exception(string.Format("Cannot use {0} of type {1} as win32 icon.", file, file.Type));
                cmd.Append(" -win32icon:" + file.QuotedFileName);
            }
            if (this._signatureFile.Count > 0)
            {
                cmd.Append(" -keyfile:" + ContentFile.QuoteFileName(this._signatureFile.Files.GetOneFileName()));
            }
            if (this._mainClass != null && this._mainClass.Length > 0)
                cmd.Append(" -main:" + this._mainClass);

            wx.Build.Net.NetCompilerParameters netParameters = (wx.Build.Net.NetCompilerParameters)BuildConfig.GetDefaultParameterOfType(typeof(wx.Build.Net.NetCompilerParameters));
            if (netParameters.IncludeDebugInformation) 
                cmd.Append(" -debug");
            if (netParameters.OptimizeOutput)
                cmd.Append(" -optimize+");
            if (netParameters.WarningLevel >= 0)
                cmd.Append(" -warn:" + netParameters.WarningLevel);
            cmd.Append(" -fullpaths");

            if (BuildConfig.GetConfig().AbortOptions == AbortOptions.TreatWarningsAsErrors)
                cmd.Append(" -warnaserror");
            cmd.Append(" -define:__MONO_GMCS__");
            if (netParameters.EnableTraceLog)
                cmd.Append(" -define:TRACE");

            foreach (string feature in this.Features.EnabledSymbols)
                cmd.Append(" -define:" + feature);

            foreach (ContentFile file in this._sources.Files)
            {
                cmd.Append(" ");
                cmd.Append(file.QuotedFileName);
            }
            result.Arguments = cmd.ToString();
            return result;
        }

        /** <summary> This will start the <c>gscs </c>  of the newest installed framework. </summary> */
        public bool Execute(BuildToolFamilyEnv env, DateTime validityOfBuildSystem)
        {
            BuildConfig.HandleMessageObject("Start GMCS to build {0}.", this._target.FileName);
            ErrorDataReceiver receiver = new ErrorDataReceiver(this);
            receiver.WarningClassifier = new System.Text.RegularExpressions.Regex(@" warning ",
                System.Text.RegularExpressions.RegexOptions.Compiled
                | System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            receiver.ErrorClassifier = new System.Text.RegularExpressions.Regex(@" error ",
                System.Text.RegularExpressions.RegexOptions.Compiled
                | System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            receiver.FilePosPattern = new System.Text.RegularExpressions.Regex(
                @"^(?<file>[^\(]+)\((?<line>\d+),(?<column>\d+)\)");
            wx.ProcessUtils.ProcessStarter starter=new wx.ProcessUtils.ProcessStarter(this.GetProgramStartInfo(env),
                new wx.ProcessUtils.MsgEventHandler(receiver.OnReceiveMsgEvent));
            Process process = starter.Start();
            return process.ExitCode == 0;
        }

        #endregion
    }
}
