﻿/** Build system for wx.NET.
 * 
 * This DLL contains basic implementations to build (compile and link) C/C++ programs,
 * compile .NET assemblies written in C#, sign them, and install them.
 * 
 * \file 
 *
 * Copyright 2009, 2010 Harald Meyer auf'm Hofe harald_meyer@users.sourceforge.net
 * 
 * Licensed under the wxWidgets license, see LICENSE.txt for details.
 * 
 * $Id: AssemblyInfo.cs,v 1.2 2010/02/21 14:56:38 harald_meyer Exp $
 */


using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("wx.BuildSystem")]
[assembly: AssemblyDescription("wx.NET building and installation utilities")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("wx.NET Project")]
[assembly: AssemblyProduct("wx.NET BuildSystem")]
[assembly: AssemblyCopyright("Copyright Harald Meyer auf'm Hofe © 2009-2010")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: AssemblyVersion("0.1.0.0")]
[assembly: AssemblyFileVersion("0.1.0.0")]
