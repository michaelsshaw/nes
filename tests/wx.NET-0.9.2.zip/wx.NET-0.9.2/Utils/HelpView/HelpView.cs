//------------------------------------------------------------------------
// HelpView.exe - HelpView.cs
// 
// Written by Harald Meyer auf'm Hofe 2006
//
// (C) Harald Meyer auf'm Hofe 2006-2009
//
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: HelpView.cs,v 1.23 2010/05/08 19:58:11 harald_meyer Exp $
//------------------------------------------------------------------------

using System;
using System.Drawing;
using System.IO;
using System.Text;
using System.Collections;
using System.Threading;
using System.Reflection;
using wx;
using wx.FileSys;
using wx.Html;

namespace wx.Html.Help
{
    /** Private class to store a .NET string as client data.
     */
    class TextClientData : ClientData
    {
        public string _text=null;
        public TextClientData(string text)
        {
            this._text = text;
        }
    }

    /** Private helper class for HtmlHelpWindow.
     * */
    internal class HtmlHelpTreeItemData : TreeItemData
    {
        public int m_Id;
        public HtmlHelpTreeItemData(int id)
            : base(null)
        {
            this.m_Id = id;
        }
    }

    /** Private helper class for HtmlHelpWindow.
     * */
    class HtmlHelpHashData
    {
        public int m_Index;
        public TreeItemId m_Id;
        public HtmlHelpHashData(int index, TreeItemId id)
        { m_Index = index; m_Id = id; }
    }

    /** Helper class for HtmlHelpWindow.
     * Holds a list of index items combined with a name and a parent.
     * */
    public class HtmlHelpMergedIndexItem : IEnumerable
    {
        #region State
        IList _Items = new ArrayList();
        #endregion
        public HtmlHelpMergedIndexItem Parent=null;
        public string Name=null;

        public HtmlHelpMergedIndexItem() { }

        public int Count { get { return this._Items.Count; } }
        public HtmlHelpDataItem this[int index]
        {
            get
            {
                return (HtmlHelpDataItem)this._Items[index];
            }
            set
            {
                this._Items[index] = value;
            }
        }
        public IEnumerator GetEnumerator() { return this._Items.GetEnumerator(); }
        public void Add(HtmlHelpDataItem newItem)
        {
            this._Items.Add(newItem);
        }
    }

    /** Merged index of hyper text books.
     */
    public class HtmlHelpMergedIndex
    {
        #region State
        IList _items = new ArrayList();
        #endregion

        public HtmlHelpMergedIndex()
        {
        }
        public void Add(HtmlHelpMergedIndexItem newItem) { this._items.Add(newItem); }
        public HtmlHelpMergedIndexItem this[int index]
        {
            get
            {
                return (HtmlHelpMergedIndexItem)this._items[index];
            }
            set
            {
                this._items[index] = value;
            }
        }

        /** Returns the index of the provided index item or -1 if this is unknown.
         * */
        public int Index(HtmlHelpMergedIndexItem item)
        {
            return this._items.IndexOf(item);
        }

        public int Count { get { return this._items.Count; } }
    }

    /** A small extension of class HtmlWindow used for HtmlHelpFrame.
     * */
    public class HtmlHelpWindow : HtmlWindow
    {
        #region State
        HtmlHelpFrame _frame;
        #endregion

        #region CTor
        public HtmlHelpWindow(HtmlHelpFrame frame, Window parent)
            : base(parent)
        {
            this._frame = frame;
            EVT_CHAR(new EventListener(this.OnChar));
        }
        #endregion

        #region Methods
        void OnChar(object sender, wx.Event evt)
        {
        }

        public override void OnLinkClicked(HtmlLinkInfo link)
        {
            base.OnLinkClicked(link);
            MouseEvent e = link.Event;
            if (e == null || e.LeftUp)
                this._frame.NotifyPageChanged();
        }

        /** Returns full location with anchor (helper)
         */
        static public string GetOpenedPageWithAnchor(HtmlWindow win)
        {
            if (win==null)
                return "";

            string an = win.OpenedAnchor;
            string pg = win.OpenedPage;
            if (an.Length>0)
            {
                pg+="#"+an;
            }
            return pg;
        }
        #endregion
    }

    /** A html help window including some methods for searching text.
     */
    public class HtmlHelpWindowWithSearch : HtmlWindowWithSearch
    {
        HtmlHelpFrame _frame;
        public HtmlHelpWindowWithSearch(HtmlHelpFrame frame, Window parent)
        {
            this._frame = frame;
            base.Create(parent, -1, wxDefaultPosition, wxDefaultSize, WindowStyles.BORDER_NONE | WindowStyles.TAB_TRAVERSAL, "");
        }

        protected override HtmlWindow CreateHtmlWindow()
        {
            return new HtmlHelpWindow(this._frame, this);
        }
    }

    /** Collects all properties that are used to configure the help frame.
     * */
    internal class HtmlHelpFrameCfg
    {
        #region State
        internal Point position = Window.wxDefaultPosition;
        internal Size size = Window.wxDefaultSize;
        internal int sashpos = -1;
        internal bool navig_on = true;
        #endregion

        #region CTor
        internal HtmlHelpFrameCfg()
        {
        }
        #endregion
    }

    /** The main frame for application HelpViewApp.
     * */
    public class HtmlHelpFrame : wx.Frame
    {
        #region Enumerations, Constants
        public enum IMG
        {
            Book = 0,
            Folder,
            Page
        }

        [wx.Globalization.EnumValueTranslations(10000, "Copy", "de", "Kopieren")]
        [wx.Globalization.EnumValueTranslations(10001, "Copy (Bitmap)", "de", "Kopieren (als Graphik)")]
        enum Cmd
        {
            wxID_HTML_PANEL = MenuIDs.wxID_HIGHEST + 2,
            wxID_HTML_BACK,
            wxID_HTML_FORWARD,
            wxID_HTML_UPNODE,
            wxID_HTML_UP,
            wxID_HTML_DOWN,
            wxID_HTML_PRINT,
            wxID_HTML_OPENFILE,
            wxID_HTML_OPTIONS,
            wxID_HTML_BOOKMARKSLIST,
            wxID_HTML_BOOKMARKSADD,
            wxID_HTML_BOOKMARKSREMOVE,
            wxID_HTML_TREECTRL,
            wxID_HTML_INDEXPAGE,
            wxID_HTML_INDEXLIST,
            wxID_HTML_INDEXTEXT,
            wxID_HTML_INDEXBUTTON,
            wxID_HTML_INDEXBUTTONALL,
            wxID_HTML_NOTEBOOK,
            wxID_HTML_SEARCHPAGE,
            wxID_HTML_SEARCHTEXT,
            wxID_HTML_SEARCHLIST,
            wxID_HTML_SEARCHBUTTON,
            wxID_HTML_SEARCHCHOICE,
            wxID_HTML_COUNTINFO,
            wxID_HTML_BOOKMARKSINFO,
            wxID_HTML_EDITBOOKMARK,
            wxID_HTML_SEARCHINPAGE,
            wxID_HTML_TOGGLESEARCHPANEL,

            HTML_WinCopyText = 10000,
            HTML_WinCopyBitmap = 10001,
        }

        public enum Style
        {
            wxHF_TOOLBAR                =0x0001,
            wxHF_CONTENTS               =0x0002,
            wxHF_INDEX                  =0x0004,
            wxHF_SEARCH                 =0x0008,
            wxHF_BOOKMARKS              =0x0010,
            wxHF_OPEN_FILES             =0x0020,
            wxHF_PRINT                  =0x0040,
            wxHF_FLAT_TOOLBAR           =0x0080,
            wxHF_MERGE_BOOKS            =0x0100,
            wxHF_ICONS_BOOK             =0x0200,
            wxHF_ICONS_BOOK_CHAPTER     =0x0400,
            wxHF_ICONS_FOLDER           =0x0000, // this is 0 since it is default
            wxHF_DEFAULT_STYLE          =wxHF_TOOLBAR | wxHF_CONTENTS | 
                                         wxHF_INDEX | wxHF_SEARCH | 
                                         wxHF_BOOKMARKS | wxHF_PRINT
        }

        //! what is considered "small index"?
        /*! A small index will be displayed in the appropriate lists to a full extend without
         * prior search request.
         */
        static int INDEX_IS_SMALL = 100;

        /** These constants define an ordering of the bookmarks in lists.
         */
        public enum BookmarkOrder
        {
            ByName, //!< Sorting by the name of the entry first.
            ByFinalUseDate, //!< Sorting by the time of the final use first. Currently used bookmarks will be first.
            ByUses //!< Sorting by the recorded number of uses. Often used bookmarks will be first.
        }
        #endregion

        #region Nested Classes
        internal static void SetFontsToHtmlWin(HtmlWindow win, string scalf, string fixf, int size)
        {
            int[] f_sizes = new int[7];
            f_sizes[0] = (int)(size * 0.6);
            f_sizes[1] = (int)(size * 0.8);
            f_sizes[2] = size;
            f_sizes[3] = (int)(size * 1.2);
            f_sizes[4] = (int)(size * 1.4);
            f_sizes[5] = (int)(size * 1.6);
            f_sizes[6] = (int)(size * 1.8);

            win.SetFonts(scalf, fixf, f_sizes);
        }
        internal class OptionsDialog : Dialog
        {
            internal ComboBox NormalFont;
            internal ComboBox FixedFont;
            internal SpinCtrl FontSize;
            internal HtmlWindow TestWin;


            internal OptionsDialog(Window parent)
                : base(parent, wxID_ANY, _("Help Browser Options"))
            {
                BoxSizer topsizer = new BoxSizer(Orientation.wxVERTICAL);
                FlexGridSizer sizer = new FlexGridSizer(2, 3, 2, 5);

                sizer.Add(new StaticText(this, wxID_ANY, _("Normal font:")));
                sizer.Add(new StaticText(this, wxID_ANY, _("Fixed font:")));
                sizer.Add(new StaticText(this, wxID_ANY, _("Font size:")));

                this.NormalFont = new ComboBox(this, wxID_ANY, "", wxDefaultPosition, new Size(200, wxDefaultCoord), (string[])null, wx.WindowStyles.CB_DROPDOWN | wx.WindowStyles.CB_READONLY);
                sizer.Add(this.NormalFont);

                this.FixedFont = new ComboBox(this, wxID_ANY, "", wxDefaultPosition, new Size(200, wxDefaultCoord), (string[])null, wx.WindowStyles.CB_DROPDOWN | wx.WindowStyles.CB_READONLY);
                sizer.Add(this.FixedFont);

                this.FontSize = new SpinCtrl(this, wxID_ANY);
                sizer.Add(this.FontSize);
                FontSize.SetRange(2, 100);

                topsizer.Add(sizer, 0, wx.SizerFlag.wxLEFT|wx.SizerFlag.wxRIGHT|wx.SizerFlag.wxTOP, 10);

                topsizer.Add(new StaticText(this, wxID_ANY, _("Preview:")), 0, wx.SizerFlag.wxLEFT | wx.SizerFlag.wxTOP, 10);

                this.TestWin = new HtmlWindow(this, wxID_ANY, wxDefaultPosition, new Size(20, 150), wx.WindowStyles.HW_SCROLLBAR_AUTO | wx.WindowStyles.BORDER_SUNKEN);
                topsizer.Add(this.TestWin, 1, wx.SizerFlag.wxEXPAND | wx.SizerFlag.wxLEFT|wx.SizerFlag.wxTOP|wx.SizerFlag.wxRIGHT, 10);

                BoxSizer sizer2 = new BoxSizer(Orientation.wxHORIZONTAL);
                Button ok = new Button(this, wxID_OK, _("OK"));
                sizer2.Add(ok, 0, wx.SizerFlag.wxALL, 10);
                ok.SetDefault();
                sizer2.Add(new Button(this, wxID_CANCEL, _("Cancel")), 0, wx.SizerFlag.wxALL, 10);
                topsizer.Add(sizer2, 0, wx.SizerFlag.wxALIGN_RIGHT);

                EVT_COMBOBOX(wxID_ANY, new EventListener(OnUpdate));
                EVT_SPINCTRL(wxID_ANY, new EventListener(OnUpdateSpin));

                this.SetSizer(topsizer);
                topsizer.Fit(this);
                Centre(Orientation.wxBOTH);
            }


            internal void UpdateTestWin()
            {
                using (BusyCursor bcur = new BusyCursor())
                {
                    SetFontsToHtmlWin(this.TestWin,
                                      this.NormalFont.StringSelection,
                                      this.FixedFont.StringSelection,
                                      this.FontSize.Value);

                    string content = _("font size");
                    StringBuilder sb = new StringBuilder();
                    sb.AppendFormat("<font size=-2>{0} -2</font><br>", content);
                    sb.AppendFormat("<font size=-1>{0} -1</font><br>", content);
                    sb.AppendFormat("<font size=+0>{0} +0</font><br>", content);
                    sb.AppendFormat("<font size=+1>{0} +1</font><br>", content);
                    sb.AppendFormat("<font size=+2>{0} +2</font><br>", content);
                    sb.AppendFormat("<font size=+3>{0} +3</font><br>", content);
                    sb.AppendFormat("<font size=+4>{0} +4</font><br>", content);
                    content = sb.ToString();

                    sb = new StringBuilder();
                    sb.Append("<html><body><table><tr><td>");
                    sb.Append(_("Normal face<br>and <u>underlined</u>. "));
                    sb.Append(_("<i>Italic face.</i> "));
                    sb.Append(_("<b>Bold face.</b> "));
                    sb.Append(_("<b><i>Bold italic face.</i></b><br>"));
                    sb.Append(content);
                    sb.Append("</td><td><tt>");
                    sb.Append(_("Fixed size face.<br> <b>bold</b> <i>italic</i> "));
                    sb.Append(_("<b><i>bold italic <u>underlined</u></i></b><br>"));
                    sb.Append(content);
                    sb.Append("</tt></td></tr></table></body></html>");

                    this.TestWin.SetPage(sb.ToString());
                }
            }

            internal void OnUpdate(object sender, Event e)
            {
                UpdateTestWin();
            }
            internal void OnUpdateSpin(object sender, Event e)
            {
                UpdateTestWin();
            }
        }

        /** All entries in wx.HelpView._BookmarkSpecs() will be of this class.
         */
        internal class BookmarkEntry
        {
            public string Name;
            public string Page;
            public string Description = "";
            public DateTime GeneratedOn;
            public DateTime LastUse;
            /** This will be incremented on selecting the bookmark to distinguish often used bookmarks from others.
             */
            public uint Uses = 0;

            public bool IsEmpty { get { return this.Name==null || this.Page==null || this.Name.Length == 0 || this.Page.Length == 0; } }

            public BookmarkEntry(string name, string page)
            {
                this.Name = name;
                this.Page = page;
                this.LastUse=this.GeneratedOn = DateTime.Now;
            }

            /** Concludes the name of the book file from the page.
             * The result may be \c null, if the filename of the page does neither contain
             * sharp nor a file extension .htb or .zip.
             */
            public string Bookfile
            {
                get
                {
                    string result=this.Page;
                    int sharppos = result.IndexOf("#");
                    if (sharppos > 0)
                        result = result.Substring(0, sharppos);
                    if (result.ToLower().EndsWith(".htb")
                        || result.ToLower().EndsWith(".zip"))
                        return result;
                    else
                        return null;
                }
            }
        }

        /** This is a helper for sorting the array list of all bookmarks according to a specification as provided to the constructor.
         */
        internal class BookmarkComparer : IComparer
        {
            BookmarkOrder _orderSpecifier;
            /** Generates an instance evaluating the order as specified by the argument.
             */
            public BookmarkComparer(BookmarkOrder orderSpecifier)
            {
                this._orderSpecifier = orderSpecifier;
            }

            public int Compare(object x, object y)
            {
                BookmarkEntry argX = (BookmarkEntry)x;
                BookmarkEntry argY = (BookmarkEntry)y;
                int cmp=0;
                switch (this._orderSpecifier)
                {
                    case BookmarkOrder.ByUses:
                        cmp = argX.Uses.CompareTo(argY.Uses);
                        if (cmp==0)
                            cmp = argX.Name.CompareTo(argY.Name);
                        if (cmp == 0)
                            cmp = argX.GeneratedOn.CompareTo(argY.GeneratedOn);
                        if (cmp == 0)
                            cmp = argX.Page.CompareTo(argY.Page);
                        break;
                    case BookmarkOrder.ByFinalUseDate:
                        if (cmp == 0)
                            cmp = argX.LastUse.CompareTo(argY.LastUse);
                        if (cmp == 0)
                            cmp = argX.Uses.CompareTo(argY.Uses);
                        if (cmp == 0)
                            cmp = argX.GeneratedOn.CompareTo(argY.GeneratedOn);
                        if (cmp == 0)
                            cmp = argX.Name.CompareTo(argY.Name);
                        if (cmp == 0)
                            cmp = argX.Page.CompareTo(argY.Page);
                        break;
                    default:
                        cmp = argX.Name.CompareTo(argY.Name);
                        if (cmp == 0)
                            cmp = argX.Uses.CompareTo(argY.Uses);
                        if (cmp == 0)
                            cmp = argX.LastUse.CompareTo(argY.LastUse);
                        if (cmp == 0)
                            cmp = argX.GeneratedOn.CompareTo(argY.GeneratedOn);
                        if (cmp == 0)
                            cmp = argX.Page.CompareTo(argY.Page);
                        break;
                }
                return cmp;
            }
        }

        internal class BookmarksDialog : Dialog
        {
            enum Id
            {
                BookmarkName=10000,
                BookmarkPage,
                BookmarkDescr,
            }

            BookmarkEntry _model;
            TextCtrl _bookmarkDescr;

            internal BookmarksDialog(Window parent, BookmarkEntry model)
                : base(parent, wxID_ANY, _("Bookmark Properties"), wxDefaultPosition, wxDefaultSize, wx.WindowStyles.RESIZE_BORDER | wx.WindowStyles.DIALOG_DEFAULT_STYLE)
            {
                this._model=model;
                BoxSizer topsizer = new BoxSizer(Orientation.wxVERTICAL);
                TextCtrl bookmarkName = new TextCtrl(this, (int)Id.BookmarkName, this._model.Name, wxDefaultPosition, wxDefaultSize, wx.WindowStyles.TE_READONLY|wx.WindowStyles.TE_LINEWRAP|wx.WindowStyles.TE_MULTILINE);
                bookmarkName.Enabled = false;
                topsizer.Add(bookmarkName, 0, wx.SizerFlag.wxEXPAND, 10);
                TextCtrl bookmarkPage = new TextCtrl(this, (int)Id.BookmarkPage, this._model.Page, wxDefaultPosition, wxDefaultSize, wx.WindowStyles.TE_READONLY);
                bookmarkPage.Enabled = false;
                topsizer.Add(bookmarkPage, 0, wx.SizerFlag.wxEXPAND, 10);
                _bookmarkDescr = new TextCtrl(this, (int)Id.BookmarkDescr, this._model.Description, wxDefaultPosition, new Size(100, 50));
                topsizer.Add(_bookmarkDescr, 1, wx.SizerFlag.wxEXPAND, 10);

                BoxSizer buttonsizer = new BoxSizer(Orientation.wxHORIZONTAL);
                Button ok = new Button(this, wxID_OK, _("OK"));
                buttonsizer.Add(ok, 0, wx.SizerFlag.wxALL, 10);
                ok.SetDefault();
                buttonsizer.Add(new Button(this, wxID_CANCEL, _("Cancel")), 0, wx.SizerFlag.wxALL, 10);
                topsizer.Add(buttonsizer, 0, wx.SizerFlag.wxALIGN_RIGHT);

                this.SetSizer(topsizer);
                this.AutoLayout = true;
                topsizer.Fit(this);
                topsizer.SetSizeHints(this);
                Centre(Orientation.wxBOTH);

                EVT_BUTTON(wxID_OK, new EventListener(OnOK));
            }

            internal void OnOK(object sender, Event evt)
            {
                this._model.Description = _bookmarkDescr.Value;
                evt.Skip();
            }
        }

        /** This class is a file system handler that provides special pages of this control as files.
         * This class exemplifies a method to extend \e wxWidgets HTML dialog with logic: Building
         * HTML pages by the program code that will be made visible through special URLs using protocol "helpview:".
         * This file system handler provides the pages on the management of favourite bookmarks
         * and hyper text books.
         * 
         * Thus, this file system acts somehow like a web server that is tightly integrated into
         * the application to present and maintain data. However, instead of HTML forms or java script
         * this server will use special HTML tags placing \e wxWidgets controls on the page.
         * 
         * Refer to OpenFile() for the defined pages.
         */
        public class SpecialPagesAsFiles : IOStreamFSHandler
        {
            HtmlHelpFrame _dataSource;
            public SpecialPagesAsFiles(HtmlHelpFrame dataSource)
            {
                this._dataSource = dataSource;
            }

            /** This method implements the contents of the virtual file system.
             * \li "bookmarks.html" will list the bookmarks in a table. The anchors "sortByName", "sortByUses", and "sortByLastUse"
             *     define alternative orders for sorting the bookmarks.
             */
            public override FSFile OpenFile(FileSystem fs, string location)
            {
                string leftLocation = this.GetRightLocation(location);
                string protocol = this.GetProtocol(location);
                Stream result = null;
                using (StringWriter sw = new StringWriter())
                {
                    sw.WriteLine("<html>\n<head>");
                    sw.WriteLine("<meta http-equiv=\"content-type\" content=\"text/html; charset=UTF-8\">");
                    if (leftLocation == "artprovider.html")
                    {
                        sw.WriteLine(string.Format("<title>{0}</title>", _("List Of Art Items")));
                        sw.WriteLine("</head>\n<body bgcolour=\"#ffffff\">");

                        sw.WriteLine("<h1>The Bitmaps Of <code>wx.ArtProvider</code> In Different Sizes For Different Clients</h1>");

                        int[] sizes = new int[] { 8, 16, 32, 48 };
                        sw.WriteLine("<table border=\"1\">");
                        sw.Write("<tr><th>wx.ArtID</th>");
                        foreach (int size in sizes)
                            sw.Write("<th><p><code>{1}</code></p><p>{0}x{0}</p></th>", size, wx.ArtClient.wxART_OTHER.ToString());
                        foreach (wx.ArtClient artClient in Enum.GetValues(typeof(wx.ArtClient)))
                        {
                            sw.Write("<th><code>{0}</code></th>", artClient);
                        }
                        sw.WriteLine("</tr>");

                        foreach (int artIndex in Enum.GetValues(typeof(wx.ArtID)))
                        {
                            sw.Write("<tr>");
                            ArtID artId = (ArtID)artIndex;
                            sw.Write("<td><tt>{0}</tt></td>", artId);
                            foreach (int size in sizes)
                                sw.Write("<td><wxart artid=\"{0}\" x=\"{1}\" y=\"{2}\"></td>", artId.ToString(), size, size);
                            foreach (int artClient in Enum.GetValues(typeof(wx.ArtClient)))
                                sw.Write("<td><wxart artid=\"{0}\" client=\"{1}\"></td>", artId.ToString(), ((wx.ArtClient)artClient).ToString());
                            sw.WriteLine("</tr>");
                        }
                        sw.WriteLine("</table>");
                    }
                    else if (leftLocation == "bookmarks.html"
                        || leftLocation == "bookmarksByName.html"
                        || leftLocation == "bookmarksByUses.html"
                        || leftLocation == "bookmarksByLastUse.html")
                    {
                        sw.WriteLine(string.Format("<title>{0}</title>", _("List Of Bookmarks")));
                        sw.WriteLine("</head>\n<body bgcolour=\"#ffffff\" background=\"zrs:helpview.zrs//wxnetbg.png\">");

                        if (leftLocation == "bookmarksByName.html") this._dataSource._BookmarkOrder = BookmarkOrder.ByName;
                        else if (leftLocation == "bookmarksByUses.html") this._dataSource._BookmarkOrder = BookmarkOrder.ByUses;
                        else if (leftLocation == "bookmarksByLastUse.html") this._dataSource._BookmarkOrder = BookmarkOrder.ByFinalUseDate;

                        BookmarkComparer cmp = new BookmarkComparer(this._dataSource._BookmarkOrder);
                        this._dataSource._BookmarkSpecs.Sort(cmp);
                        sw.WriteLine("<table width=\"100%\" border=\"1\">");
                        sw.WriteLine("<tr>");
                        if (this._dataSource._BookmarkOrder == BookmarkOrder.ByName)
                            sw.WriteLine(string.Format("<th bgcolor=\"#A6B3FF\" color=\"#000000\">{0}</th>", _("Title")));
                        else
                            sw.WriteLine(string.Format("<th bgcolor=\"#A6B3FF\" color=\"#000000\"><a href=\"{1}:bookmarksByName.html\">{0}</a></th>", _("Title"), protocol));
                        sw.WriteLine(string.Format("<th bgcolor=\"#A6B3FF\" color=\"#000000\">{0}</th>", _("Descr.")));
                        if (this._dataSource._BookmarkOrder == BookmarkOrder.ByUses)
                            sw.WriteLine(string.Format("<th bgcolor=\"#A6B3FF\" color=\"#000000\">{0}</th>", _("Freq.")));
                        else
                            sw.WriteLine(string.Format("<th bgcolor=\"#A6B3FF\" color=\"#000000\"><a href=\"{1}:bookmarksByUses.html\">{0}</a></th>", _("Freq."), protocol));
                        if (this._dataSource._BookmarkOrder == BookmarkOrder.ByFinalUseDate)
                            sw.WriteLine(string.Format("<th bgcolor=\"#A6B3FF\" color=\"#000000\">{0}</th>", _("Last Use")));
                        else
                            sw.WriteLine(string.Format("<th bgcolor=\"#A6B3FF\" color=\"#000000\"><a href=\"{1}:bookmarksByLastUse.html\">{0}</a></th>", _("Last Use"), protocol));
                        sw.WriteLine("<th>&nbsp;</th></tr>");

                        for (int i = this._dataSource.NumberOfStandardBookmarks; i < this._dataSource._BookmarkSpecs.Count; ++i)
                        {
                            BookmarkEntry entry=(BookmarkEntry)this._dataSource._BookmarkSpecs[i];
                            sw.WriteLine("<tr>");
                            sw.WriteLine(string.Format("<td><a href=\"{1}\">{0}</a></td>", entry.Name, entry.Page));
                            sw.WriteLine(string.Format("<td>{0}</td>", entry.Description));
                            sw.WriteLine(string.Format("<td>{0}</td>", entry.Uses));
                            sw.WriteLine(string.Format("<td>{0}</td>", entry.LastUse.ToString("u")));
                            sw.WriteLine(string.Format("<td><wxbutton labelart=\"{0}\" cmd=\"{1}\" eventstring=\"{2}\"></td>", (int)ArtID.wxART_NORMAL_FILE, (int)Cmd.wxID_HTML_EDITBOOKMARK, entry.Page));
                            sw.WriteLine("</tr>");
                        }

                        sw.WriteLine("</table>");
                    }
                    else
                    {
                        sw.WriteLine(string.Format("<title>{0}</title>", _("Unknown page in virtual file system")));
                        sw.WriteLine("</head>\n<body bgcolour=\"#ffffff\" background=\"zrs:helpview.zrs//wxnetbg.png\">");
                        sw.WriteLine(string.Format(_("The URL \"{0}\" is unknown to this virtual file system."), location));
                    }

                    sw.WriteLine("</body></html>");

                    result = new MemoryStream(Encoding.UTF8.GetBytes(sw.ToString()));
                }
                result.Seek(0, SeekOrigin.Begin);
                return new FSFile(result, leftLocation, "text/html", "", DateTime.Now);
            }

            /** This will implement the protocol "htmlview".
             * The different pages will be distinguished according to the name of the file.
             * Refer to OpenFile().
             */
            public override bool CanOpen(string location)
            {
                string protocol = GetProtocol(location);
                return protocol == "helpview";
            }
        }
        #endregion

        #region State
        HtmlHelpData _Data;
        /** title of the help frame */
        string _TitleFormat;
        /** below are various pointers to GUI components */
        HtmlWindowWithSearch _HtmlSearchWin;
        HtmlWindow _HtmlWin;
        SplitterWindow _Splitter;
        Panel _NavigPan;
        Notebook _NavigNotebook;
        TreeCtrl _ContentsBox;
        TextCtrl _IndexText;
        Button   _IndexButton;
        Button   _IndexButtonAll;
        ListBox  _IndexList;
        TextCtrl _SearchText;
        Button   _SearchButton;
        ListBox  _SearchList;
        Choice   _SearchChoice;
        StaticText _IndexCountInfo;
        CheckBox   _SearchCaseSensitive;
        CheckBox   _SearchWholeWords;

        ComboBox      _Bookmarks;
        ArrayList     _BookmarkSpecs;
        BookmarkOrder _BookmarkOrder=BookmarkOrder.ByName; //!< This defines the default order of bookmarks in the report view/page.
                                                                    //! Since the user may change this, it will be recorded in the configuration.

        HtmlHelpFrameCfg _Cfg;

        Config     _Config;
        wxString   _ConfigRoot;

        /** pagenumbers of controls in notebook (usually 0,1,2) */
        int _ContentsPage;
        int _IndexPage;
        int _SearchPage;

        /** lists of available fonts (used in options dialog) */
        ArrayString _NormalFonts;
        ArrayString _FixedFonts;
        /** 0,1,2 = small,medium,big */
        int _FontSize;
        string _NormalFace;
        string _FixedFace;

        bool _UpdateContents;

        HtmlEasyPrinting _Printer;
        Hashtable _PagesHash;
        HtmlHelpController _helpController;

        Style _hfStyle;

        HtmlHelpMergedIndex _mergedIndex;
        #endregion

        #region CTor, Creation
        public HtmlHelpFrame(HtmlHelpData data) { Init(data); }
        public HtmlHelpFrame() { Init(null); }
        public HtmlHelpFrame(Window parent, int wxWindowID)
            : this(parent, wxWindowID, "", null)
        {
        }
        public HtmlHelpFrame(Window parent, int wxWindowID, string title)
            : this(parent, wxWindowID, title, null)
        {
        }
        public HtmlHelpFrame(Window parent, int id, string title, HtmlHelpData data)
        {
            Init(data);
            Create(parent, id, title);
        }

        /** <summary>Creating a frame in Style.wxHF_DEFAULT_STYLE.</summary>
         * */
        public bool Create(Window parent, int id, string title)
        {
            return this.Create(parent, id, title, Style.wxHF_DEFAULT_STYLE);
        }

        /** Create: builds the GUI components.
         * Refer to Style for the meaning of bits in \c style.
         * */
        public bool Create(Window parent, int id, string title, Style style)
        {
            this._hfStyle = style;

            ImageList ContentsImageList = new ImageList(16, 16);
            ContentsImageList.Add(ArtProvider.GetIcon(ArtID.wxART_HELP_BOOK,
                                                      ArtClient.wxART_TOOLBAR,
                                                      new Size(16, 16)));
            ContentsImageList.Add(ArtProvider.GetIcon(ArtID.wxART_HELP_FOLDER,
                                                      ArtClient.wxART_TOOLBAR,
                                                      new Size(16, 16)));
            ContentsImageList.Add(ArtProvider.GetIcon(ArtID.wxART_HELP_PAGE,
                                                      ArtClient.wxART_TOOLBAR,
                                                      new Size(16, 16)));

            // Do the config in two steps. We read the HtmlWindow customization after we
            // create the window.
            if (this._Config!=null)
                ReadCustomization(this._Config, this._ConfigRoot);

            base.Create(parent, id, _("wx.NET Helpcenter"),
                        this._Cfg.position, this._Cfg.size,
                        wx.WindowStyles.FRAME_DEFAULT_STYLE, "wxNetHtmlHelp");
            this._Cfg.position=this.Position;
            //this.Icon=ArtProvider.GetIcon(ArtID.wxART_HELP_BOOK, ArtClient.wxART_HELP_BROWSER);
            try
            {
                this.Icon = new Icon("helpview.zrs", "helpview.png");
            }
            catch // maybe the resource has not been found. that's not critical
            {
            }

            // The menu bar
            MenuBar menuBar = new MenuBar();
            Menu fileMenu = new Menu();
            fileMenu.Append((int)Cmd.wxID_HTML_OPENFILE, _("&Open..."));
            fileMenu.AppendSeparator();
            fileMenu.Append((int)MenuIDs.wxID_CLOSE, _("&Close\tCtrl+C"));

            Menu editMenu = new Menu();
            editMenu.Append((int)Cmd.wxID_HTML_OPTIONS, _("O&ptions"));
            editMenu.Append((int)Cmd.wxID_HTML_BOOKMARKSINFO, _("&Bookmarks"));

            Menu viewMenu = new Menu();
            viewMenu.Append((int)Cmd.wxID_HTML_SEARCHINPAGE, _("&Find In Page\tCtrl+F"));
            viewMenu.Append((int)Cmd.wxID_HTML_TOGGLESEARCHPANEL, _("&Toggle Search Panel\tCtrl+T"));

            Menu helpMenu = new Menu();
            helpMenu.Append(Window.wxID_ABOUT, _("&About..."));

            menuBar.Append(fileMenu, _("&File"));
            menuBar.Append(editMenu, _("&Edit"));
            menuBar.Append(viewMenu, _("&View"));
            menuBar.Append(helpMenu, _("&Help"));
            this.MenuBar=menuBar;

            int notebook_page = 0;

            // the statusbar
            CreateStatusBar();

            // the toolbar
            ToolBar toolBar = this.CreateToolBar(wx.WindowStyles.BORDER_NONE | wx.WindowStyles.ORIENT_HORIZONTAL |
                                                 wx.WindowStyles.TB_DOCKABLE);
            toolBar.SetMargins( 2, 2 );
            this.AddToolbarButtons(toolBar);
            toolBar.Realize();

            EVT_CLOSE(new EventListener(new EventListener(this.OnCloseWindow)));
            
            this.AddCommandListener(wx.Event.wxEVT_LOAD_HTML_PAGE, -1, new EventListener(this.OnLoadBookEvent));

            EVT_MENU((int)MenuIDs.wxID_CLOSE, new EventListener(this.OnCloseCmd));
            EVT_MENU((int)MenuIDs.wxID_ABOUT, new EventListener(this.OnAboutBox));
            EVT_MENU((int)Cmd.wxID_HTML_OPENFILE,        new EventListener(this.OnOpenFile));
            EVT_MENU((int)Cmd.wxID_HTML_BACK,            new EventListener(this.OnHtmlBack));
            EVT_MENU((int)Cmd.wxID_HTML_BOOKMARKSADD,    new EventListener(this.OnBookmarksAdd));
            EVT_MENU((int)Cmd.wxID_HTML_BOOKMARKSREMOVE, new EventListener(this.OnBookmarksRemove));
            EVT_MENU((int)Cmd.wxID_HTML_BOOKMARKSINFO,   new EventListener(this.OnBookmarksInfo));
            EVT_MENU((int)Cmd.wxID_HTML_DOWN,            new EventListener(this.OnHtmlDown));
            EVT_MENU((int)Cmd.wxID_HTML_FORWARD,         new EventListener(this.OnHtmlForward));
            EVT_MENU((int)Cmd.wxID_HTML_PANEL,           new EventListener(this.OnHtmlPanel));
            EVT_MENU((int)Cmd.wxID_HTML_PRINT,           new EventListener(this.OnPrint));
            EVT_MENU((int)Cmd.wxID_HTML_OPTIONS,         new EventListener(this.OnDisplayOptionsDialog));
            EVT_MENU((int)Cmd.wxID_HTML_SEARCHINPAGE,    new EventListener(this.OnSearchPage));
            EVT_MENU((int)Cmd.wxID_HTML_TOGGLESEARCHPANEL, new EventListener(this.OnToggleSearchPanel));
            EVT_MENU((int)Cmd.HTML_WinCopyText, new EventListener(this.OnCopySelectedHtmlAsText));
            EVT_MENU((int)Cmd.HTML_WinCopyBitmap, new EventListener(this.OnCopySelectedHtmlAsBitmap));

            Sizer navigSizer = null;

            // traditional help controller; splitter window with html page on the
            // right and a notebook containing various pages on the left
            this._Splitter = new SplitterWindow(this);
            this._HtmlSearchWin = new HtmlHelpWindowWithSearch(this, this._Splitter);
            this._HtmlWin = this._HtmlSearchWin.Html;
            this._NavigPan = new Panel(this._Splitter, Window.wxID_ANY);
            this._NavigNotebook = new Notebook(this._NavigPan, (int)Cmd.wxID_HTML_NOTEBOOK,
                                               Window.wxDefaultPosition, Window.wxDefaultSize);

            navigSizer = new BoxSizer(Orientation.wxVERTICAL);
            navigSizer.Add(this._NavigNotebook, 1, wx.SizerFlag.wxEXPAND);
            this._NavigPan.Sizer=navigSizer;

            this._TitleFormat = "HelpView: %s";
            this._HtmlWin.SetRelatedFrame(this, this._TitleFormat);
            this._HtmlWin.RelatedStatusBar=0;

            this._HtmlWin.EVT_KEY_DOWN(new EventListener(this.OnKeyPressHtmlWindow));
            this._HtmlWin.EVT_RIGHT_DOWN(new EventListener(this.OnOpenPopupMenuHtmlWindow));


            PrepareHtmlWindowForHelpOnHelp(this._HtmlWin, new EventListener(this.OnCloseCmd));

            // now also read the saved properties of the HTML control.
            if ( this._Config!=null )
                this._HtmlWin.ReadCustomization(this._Config, this._ConfigRoot);

            Window dummy = new Panel(this._NavigNotebook, (int)Cmd.wxID_HTML_INDEXPAGE);
            Sizer  topsizer = new BoxSizer(Orientation.wxVERTICAL);
            topsizer.Add(0, 10);
            dummy.Sizer=topsizer;
            this._Bookmarks = new ComboBox(dummy, (int)Cmd.wxID_HTML_BOOKMARKSLIST, "",
                                         wxDefaultPosition, wxDefaultSize,
                                         null, wx.WindowStyles.CB_READONLY | wx.WindowStyles.CB_SORT);
            int indexStd=this._Bookmarks.Append(_("(bookmarks)"));
            this.AddStandardBookmarks();
            for (int i = NumberOfStandardBookmarks; i < this._BookmarkSpecs.Count; ++i)
                this._Bookmarks.Append(((BookmarkEntry)this._BookmarkSpecs[i]).Name);
            this._Bookmarks.Select(indexStd);

            EVT_COMBOBOX((int)Cmd.wxID_HTML_BOOKMARKSLIST, new EventListener(this.OnBookmarksSel));

            BitmapButton bmpbt1, bmpbt2, bmpbt3;
            Bitmap stdSizedBitmap=ArtProvider.GetBitmap(ArtID.wxART_ADD_BOOKMARK, ArtClient.wxART_BUTTON);
            bmpbt1 = new BitmapButton(dummy, (int)Cmd.wxID_HTML_BOOKMARKSADD,
                                      stdSizedBitmap,
                                      wxDefaultPosition, wxDefaultSize, wx.WindowStyles.BU_AUTODRAW);
            bmpbt2 = new BitmapButton(dummy, (int)Cmd.wxID_HTML_BOOKMARKSREMOVE,
                                      ArtProvider.GetBitmap(ArtID.wxART_DEL_BOOKMARK, ArtClient.wxART_BUTTON),
                                      wxDefaultPosition, wxDefaultSize, wx.WindowStyles.BU_AUTODRAW);
            bmpbt3 = new BitmapButton(dummy, (int)Cmd.wxID_HTML_BOOKMARKSINFO,
                                      ArtProvider.GetBitmap(ArtID.wxART_REPORT_VIEW, ArtClient.wxART_BUTTON, stdSizedBitmap.Size),
                                      wxDefaultPosition, wxDefaultSize, wx.WindowStyles.BU_AUTODRAW);
            bmpbt1.ToolTip = _("Add current page to bookmarks");
            bmpbt2.ToolTip = _("Remove current page from bookmarks");
            bmpbt3.ToolTip = _("Display and maintain info on the bookmarks.");

            EVT_BUTTON((int)Cmd.wxID_HTML_BOOKMARKSADD, new EventListener(this.OnBookmarksAdd));
            EVT_BUTTON((int)Cmd.wxID_HTML_BOOKMARKSREMOVE, new EventListener(this.OnBookmarksRemove));
            EVT_BUTTON((int)Cmd.wxID_HTML_BOOKMARKSINFO, new EventListener(this.OnBookmarksInfo));
            EVT_BUTTON((int)Cmd.wxID_HTML_EDITBOOKMARK, new EventListener(this.OnEditBookmark));

            Sizer sizer = new BoxSizer(Orientation.wxHORIZONTAL);
            sizer.Add(this._Bookmarks, 1, wx.SizerFlag.wxALIGN_CENTRE_VERTICAL | wx.SizerFlag.wxRIGHT, 5);
            sizer.Add(bmpbt1, 0, wx.SizerFlag.wxALIGN_CENTRE_VERTICAL | wx.SizerFlag.wxRIGHT, 2);
            sizer.Add(bmpbt2, 0, wx.SizerFlag.wxALIGN_CENTRE_VERTICAL, 0);
            sizer.Add(bmpbt3, 0, wx.SizerFlag.wxALIGN_CENTRE_VERTICAL, 0);

            topsizer.Add(sizer, 0, wx.SizerFlag.wxEXPAND
                | wx.SizerFlag.wxLEFT
                | wx.SizerFlag.wxBOTTOM
                | wx.SizerFlag.wxRIGHT,
                10);

            this._ContentsBox = new TreeCtrl(dummy, (int)Cmd.wxID_HTML_TREECTRL,
                                             wxDefaultPosition, wxDefaultSize,
                                             wx.WindowStyles.BORDER_SUNKEN
                                             | wx.WindowStyles.TR_HAS_BUTTONS
                                             | wx.WindowStyles.TR_HIDE_ROOT
                                             | wx.WindowStyles.TR_LINES_AT_ROOT
                                       );

            this._ContentsBox.AssignImageList(ContentsImageList);
            topsizer.Add(this._ContentsBox, 1,
                         wx.SizerFlag.wxEXPAND
                         | wx.SizerFlag.wxLEFT
                         | wx.SizerFlag.wxBOTTOM
                         | wx.SizerFlag.wxRIGHT,
                         2);

            this._NavigNotebook.AddPage(dummy, _("Contents"));
            this._ContentsPage = notebook_page++;

            // index listbox panel?
            dummy = new Panel(this._NavigNotebook, (int)Cmd.wxID_HTML_INDEXPAGE);
            topsizer = new BoxSizer(Orientation.wxVERTICAL);
            dummy.Sizer=topsizer;

            this._IndexText = new TextCtrl(dummy, (int)Cmd.wxID_HTML_INDEXTEXT, "",
                                           wxDefaultPosition, wxDefaultSize,
                                           wx.WindowStyles.TE_PROCESS_ENTER);
            this._IndexButton = new Button(dummy, (int)Cmd.wxID_HTML_INDEXBUTTON, _("Find"));
            this._IndexButtonAll = new Button(dummy, (int)Cmd.wxID_HTML_INDEXBUTTONALL, _("Show all"));
            this._IndexCountInfo = new StaticText(dummy, (int)Cmd.wxID_HTML_COUNTINFO,
                                                  "", wxDefaultPosition, wxDefaultSize,
                                                  wx.WindowStyles.ALIGN_RIGHT | wx.WindowStyles.ST_NO_AUTORESIZE);
            this._IndexList = new ListBox(dummy, (int)Cmd.wxID_HTML_INDEXLIST,
                                          wxDefaultPosition, wxDefaultSize,
                                          null, wx.WindowStyles.LB_SINGLE);

            this._IndexButton.ToolTip = _("Display all index items that contain given substring. Search is case insensitive.");
            this._IndexButtonAll.ToolTip=_("Show all items in index");
            topsizer.Add(this._IndexText, 0, wx.SizerFlag.wxEXPAND | wx.SizerFlag.wxALL, 10);

            EVT_BUTTON((int)Cmd.wxID_HTML_INDEXBUTTONALL, new EventListener(this.OnIndexAll));
            EVT_BUTTON((int)Cmd.wxID_HTML_INDEXBUTTON,    new EventListener(this.OnIndexFind));
            EVT_LISTBOX((int)Cmd.wxID_HTML_INDEXLIST,     new EventListener(this.OnIndexSel));
            EVT_TEXT_ENTER((int)Cmd.wxID_HTML_INDEXTEXT,  new EventListener(this.OnIndexFind));

            Sizer btsizer = new BoxSizer(Orientation.wxHORIZONTAL);
            btsizer.Add(this._IndexButton, 0, wx.SizerFlag.wxRIGHT, 2);
            btsizer.Add(this._IndexButtonAll);
            topsizer.Add(btsizer, 0,
                wx.SizerFlag.wxALIGN_RIGHT
                | wx.SizerFlag.wxLEFT
                | wx.SizerFlag.wxRIGHT
                | wx.SizerFlag.wxBOTTOM,
                10);
            topsizer.Add(this._IndexCountInfo, 0,
                wx.SizerFlag.wxEXPAND
                | wx.SizerFlag.wxLEFT
                | wx.SizerFlag.wxRIGHT,
                2);
            topsizer.Add(this._IndexList, 1,
                wx.SizerFlag.wxEXPAND
                | wx.SizerFlag.wxALL,
                2);

            this._NavigNotebook.AddPage(dummy, _("Index"));
            this._IndexPage = notebook_page++;

            // search list panel?
            dummy = new Panel(this._NavigNotebook, (int)Cmd.wxID_HTML_INDEXPAGE);
            sizer = new BoxSizer(Orientation.wxVERTICAL);
            dummy.Sizer = sizer;

            this._SearchText = new TextCtrl(dummy, (int)Cmd.wxID_HTML_SEARCHTEXT,
                                            "", wxDefaultPosition, wxDefaultSize,
                                            wx.WindowStyles.TE_PROCESS_ENTER);
            this._SearchChoice = new Choice(dummy, (int)Cmd.wxID_HTML_SEARCHCHOICE,
                                            wxDefaultPosition, new Size(125,wxDefaultCoord), null);
            this._SearchCaseSensitive = new CheckBox(dummy, Window.wxID_ANY, _("Case sensitive"));
            this._SearchWholeWords = new CheckBox(dummy, Window.wxID_ANY, _("Whole words only"));
            this._SearchButton = new Button(dummy, (int)Cmd.wxID_HTML_SEARCHBUTTON, _("Search"));

            this._SearchButton.ToolTip = _("Search contents of help book(s) for all occurences of the text you typed above");
            this._SearchList = new ListBox(dummy, (int)Cmd.wxID_HTML_SEARCHLIST,
                                           wxDefaultPosition, wxDefaultSize,
                                           null, wx.WindowStyles.LB_SINGLE);

            EVT_BUTTON((int)Cmd.wxID_HTML_SEARCHBUTTON, new EventListener(this.OnSearch));
            EVT_LISTBOX((int)Cmd.wxID_HTML_SEARCHLIST, new EventListener(this.OnSearchSel));
            EVT_TEXT_ENTER((int)Cmd.wxID_HTML_SEARCHTEXT, new EventListener(this.OnSearch));

            sizer.Add(this._SearchText, 0,
                wx.SizerFlag.wxEXPAND
                | wx.SizerFlag.wxALL,
                10);
            sizer.Add(this._SearchChoice, 0,
                wx.SizerFlag.wxEXPAND
                | wx.SizerFlag.wxLEFT
                | wx.SizerFlag.wxRIGHT
                | wx.SizerFlag.wxBOTTOM,
                10);
            sizer.Add(this._SearchCaseSensitive, 0,
                wx.SizerFlag.wxLEFT
                | wx.SizerFlag.wxRIGHT,
                10);
            sizer.Add(this._SearchWholeWords, 0,
                wx.SizerFlag.wxLEFT
                | wx.SizerFlag.wxRIGHT,
                10);
            sizer.Add(this._SearchButton, 0,
                wx.SizerFlag.wxALL
                | wx.SizerFlag.wxALIGN_RIGHT,
                8);
            sizer.Add(this._SearchList, 1,
                wx.SizerFlag.wxALL
                | wx.SizerFlag.wxEXPAND,
                2);

            this._NavigNotebook.AddPage(dummy, _("Search"));
            this._SearchPage = notebook_page;

            // basic window initialization
            this._HtmlSearchWin.Show();
            this.RefreshLists();

            if ( navigSizer!=null )
            {
                navigSizer.SetSizeHints(this._NavigPan);
                this._NavigPan.Layout();
            }

            // showtime
            if ( this._NavigPan!=null && this._Splitter!=null )
            {
                this._Splitter.MinimumPaneSize=20;
                if ( this._Cfg.navig_on )
                    this._Splitter.SplitVertically(this._NavigPan, this._HtmlSearchWin, this._Cfg.sashpos);

            }
            if ( this._Cfg.navig_on )
            {
                this._NavigPan.Show();
                this._Splitter.SplitVertically(this._NavigPan, this._HtmlSearchWin, this._Cfg.sashpos);
            }
            else
            {
                this._NavigPan.Show(false);
                this._Splitter.Initialize(this._HtmlSearchWin);
            }
    
            // Reduce flicker by updating the splitter pane sizes before the
            // frame is shown
            SizeEvent sizeEvent = new SizeEvent(this.Size, this.ID);
            this.ProcessEvent(sizeEvent);

            this._Splitter.UpdateSize();

            EVT_TREE_SEL_CHANGED((int)Cmd.wxID_HTML_TREECTRL, new EventListener(OnContentsSel));

            this.DisplayHelpOnHelp();
            return true;
        }
        #endregion

        #region Properties
        /** The displayed data.
         * */
        public HtmlHelpData Data { get { return this._Data; } }
        /** The used help controller.
         * You may get and  set the controller here.
         * */
        public HtmlHelpController Controller
        {
            get
            {
                return this._helpController;
            }
            set
            {
                this._helpController = value;
            }
        }

        public string TitleFormat
        {
            get
            {
                return this._TitleFormat;
            }
            set
            {
                if (this._HtmlWin!=null)
                    this._HtmlWin.SetRelatedFrame(this, value);
                this._TitleFormat = value;
            }
        }
        #endregion

        #region Public Methods
        /** Displays page x.
         * If not found it will offer the user a choice of
         * searching books.
         * Looking for the page runs in these steps:
         * \li 1. try to locate file named x (if x is for example "doc/howto.htm")
         * \li 2. try to open starting page of book x
         * \li 3. try to find x in contents (if x is for example "How To ...")
         * \li 4. try to find x in index (if x is for example "How To ...")
         * */
        public bool Display(string x)
        {
            string url = this._Data.FindPageByName(x);
            if (url.Length > 0)
            {
                this._HtmlWin.LoadPage(url);
                this.NotifyPageChanged();
                return true;
            }

            return false;
        }

        /** Alternative version that works with numeric ID.
         */
        public bool Display(int id)
        {
            string url = this._Data.FindPageById(id);
            if (url.Length > 0)
            {
                this.NotifyPageWillChange();
                this._HtmlWin.LoadPage(url);
                this.NotifyPageChanged();
                return true;
            }

            return false;
        }

        /** Displays help window and focuses contents.
         */
        public bool DisplayContents()
        {
            if (this._ContentsBox==null)
                return false;

            if (!this._Splitter.IsSplit)
            {
                this._NavigPan.Show();
                this._HtmlSearchWin.Show();
                this._Splitter.SplitVertically(this._NavigPan, this._HtmlSearchWin, this._Cfg.sashpos);
                this._Cfg.navig_on = true;
            }

            this._NavigNotebook.Selection=this._ContentsPage;

            if (this._Data.BookRecords.Count > 0)
            {
                HtmlBookRecord book = this._Data.BookRecords[0];
                if (book.Start.Length > 0)
                    this._HtmlWin.LoadPage(book.GetFullPath(book.Start));
            }

            return true;
        }

        /** Displays help window and focuses index.
         */
        public bool DisplayIndex()
        {
            if (this._IndexList==null)
                return false;

            if (!this._Splitter.IsSplit)
            {
                this._NavigPan.Show();
                this._HtmlSearchWin.Show();
                this._Splitter.SplitVertically(this._NavigPan, this._HtmlSearchWin, this._Cfg.sashpos);
            }

            this._NavigNotebook.Selection = this._IndexPage;

            if (this._Data.BookRecords.Count > 0)
            {
                HtmlBookRecord book = this._Data.BookRecords[0];
                if (book.Start.Length > 0)
                    this._HtmlWin.LoadPage(book.GetFullPath(book.Start));
            }

            return true;
        }

        /** Searches for keywords. Returns true and display page if found, return false otherwise.
        * Syntax of keyword is Altavista-like:
        * \li words are separated by spaces (but "\"hello world"\" is only one word "hello world")
        * \li word may be pretended by + or - <ul>
        *     <li>+ : page must contain the word
        *     <li>- : page can't contain the word
        *     </ul>
        * \li if there is no + or - before the word, + is default
        */
        public bool KeywordSearch(string keyword, HelpSearchMode mode)
        {
            if (mode == HelpSearchMode.wxHELP_SEARCH_ALL)
            {
                if ( this._SearchList == null
                     || this._SearchButton == null
                     || this._SearchText == null
                     || this._SearchChoice == null )
                    return false;
            }
            else if (mode == HelpSearchMode.wxHELP_SEARCH_INDEX)
            {
                if ( this._IndexList==null
                     || this._IndexButton==null
                     || this._IndexButtonAll==null
                     || this._IndexText==null )
                    return false;
            }

            int foundcnt = 0;
            string foundstr;
            string book = "";

            if (!this._Splitter.IsSplit)
            {
                this._NavigPan.Show();
                this._HtmlSearchWin.Show();
                this._Splitter.SplitVertically(this._NavigPan, this._HtmlSearchWin, this._Cfg.sashpos);
            }

            if (mode == HelpSearchMode.wxHELP_SEARCH_ALL)
            {
                this._NavigNotebook.Selection=this._SearchPage;
                this._SearchList.Clear();
                this._SearchText.Value=keyword;
                this._SearchButton.Disable();

                if (this._SearchChoice.Selection != 0)
                    book = this._SearchChoice.StringSelection;

                HtmlSearchStatus status=new HtmlSearchStatus(this._Data, keyword,
                                                             this._SearchCaseSensitive.Value,
                                                             this._SearchWholeWords.Value,
                                                             book);

                using (ProgressDialog progress=new ProgressDialog(_("Searching..."),
                                                                  _("No matching page found yet"),
                                                                  status.MaxIndex, this,
                                                                  wx.WindowStyles.PD_APP_MODAL
                                                                  | wx.WindowStyles.PD_CAN_ABORT
                                                                  | wx.WindowStyles.PD_AUTO_HIDE))
                {
                    int curi;
                    while (status.IsActive)
                    {
                        curi = status.CurrentIndex;
                        if (curi % 32 == 0
                            && !progress.Update(curi))
                                break;
                        if (status.Search())
                        {
                            foundstr=string.Format(_("Found {0} matches"), ++foundcnt);
                            progress.Update(status.CurrentIndex, foundstr);
                            this._SearchList.Append(status.Name, new SystemObjectClientData(status.Current));
                        }
                    }

                    this._SearchButton.Enabled=true;
                    this._SearchText.SetSelection(0, keyword.Length);
                    this._SearchText.SetFocus();
                }
            }
            else if (mode == HelpSearchMode.wxHELP_SEARCH_INDEX)
            {
                this._NavigNotebook.Selection=this._IndexPage;
                this._IndexList.Clear();
                this._IndexButton.Enabled=false;
                this._IndexButtonAll.Enabled=false;
                this._IndexText.Value=keyword;

                this.StartIndexFind();
                this._IndexButton.Enabled=true;
                this._IndexButtonAll.Enabled=true;
                foundcnt = this._IndexList.Count;
            }

            if (foundcnt > 0)
            {
                switch ( mode )
                {
                    case HelpSearchMode.wxHELP_SEARCH_ALL:
                    {
                        HtmlHelpDataItem it = (HtmlHelpDataItem) ((SystemObjectClientData) this._SearchList.GetClientObject(0)).Data;
                        if (it != null)
                        {
                            this.NotifyPageWillChange();
                            this._HtmlWin.LoadPage(it.FullPath);
                            this.NotifyPageChanged();
                        }
                        break;
                    }

                    case HelpSearchMode.wxHELP_SEARCH_INDEX:
                    {
                        HtmlHelpMergedIndexItem it = (HtmlHelpMergedIndexItem) ((SystemObjectClientData) this._IndexList.GetClientObject(0)).Data;
                        if (it != null)
                            this.DisplayIndexItem(it);
                        break;
                    }
                }
            }
            return foundcnt > 0;
        }

        /** This is a version of this method in mode HelpSearchMode.wxHELP_SEARCH_ALL.
         * */
        public bool KeywordSearch(string keyword)
        {
            return this.KeywordSearch(keyword, HelpSearchMode.wxHELP_SEARCH_ALL);
        }

        public void UseConfig(Config config)
        {
          wxString empty=wxString.SafeNew("");
          this.UseConfig(config, empty);
        }

        public void UseConfig(Config config, string rootpath)
        {
            this._Config = config;
            this._ConfigRoot = wxString.SafeNew(rootpath);
            this.ReadCustomization(config, rootpath);
        }

        /** The number of standard bookmarks.
        * These bookmarks will not be stored in the registry.
        */
        internal int NumberOfStandardBookmarks=0;
        /** Adds the standard bookmarks.
        */
        internal void AddStandardBookmarks()
        {
            // produce standard bookmarks
            string apppath = new Uri(Assembly.GetExecutingAssembly().Location).LocalPath;
            apppath = Path.GetDirectoryName(apppath);

            this.NumberOfStandardBookmarks = 0;

            string filepath = Path.Combine(apppath, Path.Combine("..",
                Path.Combine("Docs", "wx.net.htb")));
            filepath = Path.GetFullPath(filepath);
            if (File.Exists(filepath))
            {
                this.NumberOfStandardBookmarks += 1;
                BookmarkEntry entry = new BookmarkEntry(_("-> wx.NET Manual"), filepath + "#zip:index.html");
                this._BookmarkSpecs.Add(entry);
                this._Bookmarks.Append(entry.Name);
            }
            filepath = Path.Combine(apppath, "../Docs/wx.htb");
            filepath = Path.GetFullPath(filepath);
            if (File.Exists(filepath))
            {
                this.NumberOfStandardBookmarks += 1;
                BookmarkEntry entry = new BookmarkEntry(_("-> wxWidgets Manual"), filepath + "#zip:wx_contents.html");
                this._BookmarkSpecs.Add(entry);
                this._Bookmarks.Append(entry.Name);
            }
            filepath = Path.Combine(apppath, "../Docs/wx.net.samples.htb");
            filepath = Path.GetFullPath(filepath);
            if (File.Exists(filepath))
            {
                this.NumberOfStandardBookmarks += 1;
                BookmarkEntry entry = new BookmarkEntry(_("-> wx.NET Samples"), filepath + "#zip:index.html");
                this._BookmarkSpecs.Add(entry);
                this._Bookmarks.Append(entry.Name);
            }
            filepath = Path.Combine(apppath, Path.Combine("..", Path.Combine("Docs", "wx.Net.Build.htb")));
            filepath = Path.GetFullPath(filepath);
            if (File.Exists(filepath))
            {
                this.NumberOfStandardBookmarks += 1;
                BookmarkEntry entry = new BookmarkEntry(_("-> Manual wx.NET Build System"), filepath + "#zip:index.html");
                this._BookmarkSpecs.Add(entry);
                this._Bookmarks.Append(entry.Name);
            }
            // do not forget to update NumberOfStandardBookmarks
        }

        /** Saves custom settings into \c cfg config.
         * it will use the path \c path if non-empty, otherwise it will save info into currently selected path.
         * saved values : things set by SetFonts(), SetBorders().
         * */
        public void WriteCustomization(Config cfg, string path)
        {
            string oldpath="";
            if (path.Length > 0)
            {
                oldpath = cfg.Path;
                cfg.Path="/" + path;
            }

            cfg.Write("hcNavigPanel", this._Cfg.navig_on);
            cfg.Write("hcSashPos",    this._Cfg.sashpos);
            if (!this.Iconized)
            {
                //  Don't write if iconized as this would make the window
                //  disappear next time it is shown!
                cfg.Write("hcX", this._Cfg.position.X);
                cfg.Write("hcY", this._Cfg.position.Y);
                cfg.Write("hcW", this._Cfg.size.Width);
                cfg.Write("hcH", this._Cfg.size.Height);
            }
            cfg.Write("hcFixedFace",    this._FixedFace);
            cfg.Write("hcNormalFace",   this._NormalFace);
            cfg.Write("hcBaseFontSize", this._FontSize);

            cfg.Write("hcBookmarks_order", (int)this._BookmarkOrder);

            if (this._Bookmarks != null)
            {
                int i;
                int cnt = this._BookmarkSpecs.Count;

                cfg.Write("hcBookmarksCnt", cnt-NumberOfStandardBookmarks);
                for (i = NumberOfStandardBookmarks; i < cnt; ++i)
                {
                    cfg.Write(string.Format("hcBookmark_{0}", i - NumberOfStandardBookmarks),
                        ((BookmarkEntry)this._BookmarkSpecs[i]).Name);
                    cfg.Write(string.Format("hcBookmark_{0}_url", i - NumberOfStandardBookmarks),
                        ((BookmarkEntry)this._BookmarkSpecs[i]).Page);
                    cfg.Write(string.Format("hcBookmark_{0}_remark", i - NumberOfStandardBookmarks),
                        ((BookmarkEntry)this._BookmarkSpecs[i]).Description);
                    cfg.Write(string.Format("hcBookmark_{0}_lastUse", i - NumberOfStandardBookmarks),
                        ((BookmarkEntry)this._BookmarkSpecs[i]).LastUse.ToString());
                    cfg.Write(string.Format("hcBookmark_{0}_generatedOn", i - NumberOfStandardBookmarks),
                        ((BookmarkEntry)this._BookmarkSpecs[i]).GeneratedOn.ToString());
                    cfg.Write(string.Format("hcBookmark_{0}_uses", i - NumberOfStandardBookmarks),
                        (int)((BookmarkEntry)this._BookmarkSpecs[i]).Uses);
                }
            }

            if (this._HtmlWin != null)
                this._HtmlWin.WriteCustomization(cfg, path);

            if (path.Length > 0)
                cfg.Path=oldpath;
        }

        /** Save custom settings into \c cfg config into currently selected path.
         * */
        public void WriteCustomization(Config cfg) { this.WriteCustomization(cfg, ""); }

        /** Reading the content of a configuration file into the properties of this application.
         */
        void ReadCustomization(Config cfg, string path)
        {
            string oldpath="";
            if (path.Length > 0)
            {
                oldpath = cfg.Path;
                cfg.Path="/" + path;
            }

            cfg.Read("hcNavigPanel", this._Cfg.navig_on);
            cfg.Read("hcSashPos", this._Cfg.sashpos);
            cfg.Read("hcX", this._Cfg.position.X);
            cfg.Read("hcY", this._Cfg.position.Y);
            cfg.Read("hcW", this._Cfg.size.Width);
            cfg.Read("hcH", this._Cfg.size.Height);

            cfg.Read("hcFixedFace", this._FixedFace);
            cfg.Read("hcNormalFace", this._NormalFace);
            cfg.Read("hcBaseFontSize", this._FontSize);

            this._BookmarkOrder = (BookmarkOrder)cfg.Read("hcBookmarks_order", (int)BookmarkOrder.ByName);

            {
                int i;
                int cnt = cfg.Read("hcBookmarksCnt", (int)0);
                if (cnt != 0)
                {
                    this._BookmarkSpecs.Clear();
                    int stdSelection = 0;
                    if (this._Bookmarks != null)
                    {
                        this._Bookmarks.Clear();
                        stdSelection = this._Bookmarks.Append(_("(bookmarks)"));
                    }

                    this.AddStandardBookmarks();

                    for (i = 0; i < cnt; i++)
                    {
                        string name = cfg.Read(string.Format("hcBookmark_{0}", i), "");
                        string page = cfg.Read(string.Format("hcBookmark_{0}_url", i), "");
                        BookmarkEntry entry = new BookmarkEntry(name, page);

                        entry.Description = cfg.Read(string.Format("hcBookmark_{0}_remark", i), "");
                        entry.Uses = (uint)cfg.Read(string.Format("hcBookmark_{0}_uses", i), 1);
                        string lastUseString = cfg.Read(string.Format("hcBookmark_{0}_lastUse", i), "");
                        string generatedOnString = cfg.Read(string.Format("hcBookmark_{0}_generatedOn", i), "");
                        entry.LastUse = DateTime.MinValue;
                        try
                        {
                            if (lastUseString.Length > 0)
                                entry.LastUse = DateTime.Parse(lastUseString);
                        }
                        catch (Exception)
                        {
                        }
                        entry.GeneratedOn = DateTime.MinValue;
                        try
                        {
                            if (generatedOnString.Length > 0)
                                entry.GeneratedOn = DateTime.Parse(generatedOnString);
                        }
                        catch (Exception)
                        {
                        }

                        if (!entry.IsEmpty)
                        {
                            this._BookmarkSpecs.Add(entry);
                            if (this._Bookmarks != null) this._Bookmarks.Append(entry.Name);
                        }
                    }
                    this._Bookmarks.Selection = stdSelection;
                }
            }

            if (this._HtmlWin != null)
                this._HtmlWin.ReadCustomization(cfg, path);

            if (path.Length > 0)
                cfg.Path=oldpath;
        }

        /** This will be called immediately before changing the currently displayed page.
         */
        public void NotifyPageWillChange()
        {
            this._HtmlSearchWin.ShowSearchPanel(false);
        }

        /** Call this to let HtmlHelpFrame know page changed.
         */
        public void NotifyPageChanged()
        {
            if (this._UpdateContents && this._PagesHash != null)
            {
                string page = HtmlHelpWindow.GetOpenedPageWithAnchor(this._HtmlWin);
                HtmlHelpHashData ha = null;
                if (page.Length > 0)
                    ha = (HtmlHelpHashData) this._PagesHash[page];

                if (ha != null)
                {
                    this._HtmlSearchWin.ShowSearchPanel(false);
                    bool olduc = this._UpdateContents;
                    this._UpdateContents = false;
                    this._ContentsBox.Selection=ha.m_Id;
                    this._ContentsBox.EnsureVisible(ha.m_Id);
                    this._UpdateContents = olduc;
                }
            }
        }

        /** Refreshes Contents and Index tabs.
         * Refresh all panels. This is necessary if a new book was added.
         * Protected.
         */
        protected void RefreshLists()
        {
            // Update _mergedIndex:
            this.RefreshIndex(null);
            //ThreadPool.QueueUserWorkItem(new WaitCallback(this.RefreshIndex));
            // Update the controls
            this.CreateContents(null);
            //ThreadPool.QueueUserWorkItem(new WaitCallback(this.CreateContents));
            this.CreateSearch();
        }

        /** This will update the merged index and create the index lists in parallel.
         * Reason: The update of the merged index is awfully slow.
         */
        protected void RefreshIndex(object statobject)
        {
            this.UpdateMergedIndex();
            this.CreateIndex();
        }
        #endregion

        #region Helpers
        protected void Init(HtmlHelpData data)
        {
            if (data==null)
            {
                this._Data = new HtmlHelpData();
            }
            else
            {
                this._Data = data;
            }

            this._BookmarkSpecs = new ArrayList();

            this._ContentsPage = 0;
            this._IndexPage = 0;
            this._SearchPage = 0;

            this._ContentsBox = null;
            this._IndexList = null;
            this._IndexButton = null;
            this._IndexButtonAll = null;
            this._IndexText = null;
            this._SearchList = null;
            this._SearchButton = null;
            this._SearchText = null;
            this._SearchChoice = null;
            this._IndexCountInfo = null;
            this._Splitter = null;
            this._NavigPan = null;
            this._NavigNotebook = null;
            this._HtmlWin = null;
            this._Bookmarks = null;
            this._SearchCaseSensitive = null;
            this._SearchWholeWords = null;

            this._mergedIndex = null;

            this._Config = null;
            wxString empty=wxString.SafeNew("");
            this._ConfigRoot = empty;

            this._Cfg = new HtmlHelpFrameCfg();
            this._Cfg.position = wxDefaultPosition;
            this._Cfg.size = new Size(700, 480);
            this._Cfg.sashpos = 240;
            this._Cfg.navig_on = true;

            this._BookmarkOrder = BookmarkOrder.ByName;

            this._NormalFonts = null;
            this._FixedFonts = null;
            this._NormalFace = "";
            this._FixedFace = "";

            if (ReflectConfig.CheckWxMSW())
                this._FontSize = 10;
            else
                this._FontSize = 14;

            this._Printer = null;

            this._PagesHash = null;
            this._UpdateContents = true;
            this._helpController = null;
        }

        /** Adds items to m_Contents tree control.
         * This may also run in parallel.
         * */
        protected void CreateContents(object stateinfo)
        {
            if (this._ContentsBox==null || this._Data.ContentsCount==0)
                return ;

            HtmlHelpDataItems contents = null;
            int cnt=0;
            lock (this)
            {
                contents = this._Data.ContentsArray;
                cnt = contents.Count;
                this._PagesHash = new Hashtable();
            }

            int MAX_ROOTS = 64;
            TreeItemId[] roots=new TreeItemId[MAX_ROOTS];

            // VS: this array holds information about whether we've set item icon at
            //     given level. This is necessary because m_Data has a flat structure
            //     and there's no way of recognizing if some item has subitems or not.
            //     We set the icon later: when we find an item with level=n, we know
            //     that the last item with level=n-1 was afolder with subitems, so we
            //     set its icon accordingly
            bool[] imaged = new bool[MAX_ROOTS];
            lock (this)
            {
                this._ContentsBox.DeleteAllItems();
                roots[0] = this._ContentsBox.AddRoot(_("(Help)"));
                imaged[0] = true;
            }

            for (int i = 0; i < cnt; i++)
            {
                HtmlHelpDataItem it = contents[i];
                // Handle books:
                if (it.Level == 0)
                {
                    if ((this._hfStyle & Style.wxHF_MERGE_BOOKS) > 0)
                        // VS: we don't want book nodes, books' content should
                        //    appear under tree's root. This line will create a "fake"
                        //    record about book node so that the rest of this look
                        //    will believe there really _is_ a book node and will
                        //    behave correctly.
                        roots[1] = roots[0];
                    else
                    {
                        lock (this)
                        {
                            roots[1] = this._ContentsBox.AppendItem(roots[0],
                                                                    it.Name, (int)IMG.Book, -1,
                                                     new HtmlHelpTreeItemData(i));
                            this._ContentsBox.SetItemBold(roots[1], true);
                        }
                    }
                    imaged[1] = true;
                }
                // ...and their contents:
                else
                {
                    lock (this)
                    {
                        roots[it.Level + 1] = this._ContentsBox.AppendItem(
                                                 roots[it.Level], it.Name, (int)IMG.Page,
                                                 -1, new HtmlHelpTreeItemData(i));
                    }
                    imaged[it.Level + 1] = false;
                }

                this._PagesHash[it.FullPath]=new HtmlHelpHashData(i, roots[it.Level + 1]);

                // Set the icon for the node one level up in the hierarchy,
                // unless already done (see comment above imaged[] declaration)
                if (!imaged[it.Level])
                {
                    IMG image = IMG.Folder;
                    if ((this._hfStyle & Style.wxHF_ICONS_BOOK) != 0)
                        image = IMG.Book;
                    else if ((this._hfStyle & Style.wxHF_ICONS_BOOK_CHAPTER) != 0)
                        image = (it.Level == 1) ? IMG.Book : IMG.Folder;
                    lock (this)
                    {
                        this._ContentsBox.SetItemImage(roots[it.Level], (int)image);
                        this._ContentsBox.SetItemImage(roots[it.Level], (int)image, TreeItemIcon.wxTreeItemIcon_Selected);
                    }
                    imaged[it.Level] = true;
                }
            }
        }

        /** Adds items to m_IndexList
         * */
        protected void CreateIndex()
        {
            if (this._IndexList==null || this._mergedIndex==null)
                return;

            lock (this)
            {
                this._IndexList.Clear();
                int cnt = this._mergedIndex.Count;

                string cnttext = "";
                if (cnt > INDEX_IS_SMALL)
                    cnttext = string.Format(_("{0} of {1}"), 0, cnt);
                else
                    cnttext = string.Format(_("{0} of {1}"), cnt, cnt);
                this._IndexCountInfo.Label = cnttext;
                if (cnt > INDEX_IS_SMALL)
                    return;

                for (int i = 0; i < cnt; i++)
                    this._IndexList.Append(this._mergedIndex[i].Name,
                                           new SystemObjectClientData(this._mergedIndex[i]));
            }
        }

        /** Add books to search choice panel
         * */
        protected void CreateSearch()
        {
            if (this._SearchList==null || this._SearchChoice==null)
                return;
            this._SearchList.Clear();
            this._SearchChoice.Clear();
            this._SearchChoice.Append(_("Search in all books"));
            HtmlBookRecords bookrec = this._Data.BookRecords;
            int cnt = bookrec.Count;
            for (int i = 0; i < cnt; ++i)
                this._SearchChoice.Append(bookrec[i].Title);
            this._SearchChoice.Selection=0;
        }

        /** Updates "merged index" structure that combines indexes of all books into better searchable structure.
         * This is called via the thread pool to make this awfully time consuming procedure run
         * in parallel.
         * */
        protected void UpdateMergedIndex()
        {
            int len = 0;
            HtmlHelpDataItems items = null;
            HtmlHelpMergedIndex merged = null;
            lock (this)
            {
                this._mergedIndex = new HtmlHelpMergedIndex();
                merged = this._mergedIndex;
                items = this._Data.IndexArray;
                len = items.Count;
            }

            HtmlHelpMergedIndexItem[] history = new HtmlHelpMergedIndexItem[128];
            for (int i = 0; i < len; ++i)
            {
                HtmlHelpDataItem item = items[i];
                if (item.Level >= 128) continue; // index too deep

                if (history[item.Level] != null &&
                    history[item.Level][0].Name == item.Name)
                {
                    // same index entry as previous one, update list of items
                    history[item.Level].Add(item);
                }
                else
                {
                    // new index entry
                    HtmlHelpMergedIndexItem mi = new HtmlHelpMergedIndexItem();
                    mi.Name = item.IndentedName;
                    //mi.Name=mi.Name.Replace("::", ".");
                    mi.Add(item);
                    if (item.Level > 0)
                        mi.Parent = history[item.Level - 1];
                    history[item.Level] = mi;
                    lock (this)
                    {
                            merged.Add(mi);
                    }
                }
            }
        }

        /** Add custom buttons to toolbar.
         * */
        virtual protected void AddToolbarButtons(ToolBar toolBar)
        {
            Bitmap wpanelBitmap = ArtProvider.GetBitmap(wx.ArtID.wxART_HELP_SIDE_PANEL, wx.ArtClient.wxART_TOOLBAR);
            Bitmap wbackBitmap  = ArtProvider.GetBitmap(wx.ArtID.wxART_GO_BACK, wx.ArtClient.wxART_TOOLBAR);
            Bitmap wforwardBitmap = ArtProvider.GetBitmap(wx.ArtID.wxART_GO_FORWARD, wx.ArtClient.wxART_TOOLBAR);
            Bitmap wupnodeBitmap = ArtProvider.GetBitmap(wx.ArtID.wxART_GO_TO_PARENT, wx.ArtClient.wxART_TOOLBAR);
            Bitmap wupBitmap = ArtProvider.GetBitmap(wx.ArtID.wxART_GO_UP, wx.ArtClient.wxART_TOOLBAR);
            Bitmap wdownBitmap = ArtProvider.GetBitmap(wx.ArtID.wxART_GO_DOWN, wx.ArtClient.wxART_TOOLBAR);
            Bitmap wopenBitmap = ArtProvider.GetBitmap(wx.ArtID.wxART_FILE_OPEN, wx.ArtClient.wxART_TOOLBAR);
            Bitmap wprintBitmap = ArtProvider.GetBitmap(wx.ArtID.wxART_PRINT, wx.ArtClient.wxART_TOOLBAR);
            Bitmap woptionsBitmap = ArtProvider.GetBitmap(wx.ArtID.wxART_HELP_SETTINGS, wx.ArtClient.wxART_TOOLBAR);

            Bitmap nullBitmap = new Bitmap();
            toolBar.AddTool((int)Cmd.wxID_HTML_PANEL, wpanelBitmap, nullBitmap,
                             false, wxDefaultCoord, wxDefaultCoord, null,
                             _("Show/hide navigation panel"), "");
            toolBar.AddSeparator();
            toolBar.AddTool((int) Cmd.wxID_HTML_BACK, wbackBitmap, nullBitmap,
                             false, wxDefaultCoord, wxDefaultCoord, null,
                             _("Go back"), "");
            toolBar.AddTool((int) Cmd.wxID_HTML_FORWARD, wforwardBitmap, nullBitmap,
                            false, wxDefaultCoord, wxDefaultCoord, null,
                            _("Go forward"), "");
            toolBar.AddSeparator();

            toolBar.AddTool((int) Cmd.wxID_HTML_UPNODE, wupnodeBitmap, nullBitmap,
                            false, wxDefaultCoord, wxDefaultCoord, null,
                            _("Go one level up in document hierarchy"), "");
            toolBar.AddTool((int)Cmd.wxID_HTML_UP, wupBitmap, nullBitmap,
                             false, wxDefaultCoord, wxDefaultCoord, null,
                             _("Previous page"), "");
            toolBar.AddTool((int)Cmd.wxID_HTML_DOWN, wdownBitmap, nullBitmap,
                             false, wxDefaultCoord, wxDefaultCoord, null,
                             _("Next page"), "");
            toolBar.AddSeparator();
            toolBar.AddTool((int)Cmd.wxID_HTML_OPENFILE, wopenBitmap, nullBitmap,
                            false, wxDefaultCoord, wxDefaultCoord, null,
                            _("Open HTML document"), "");
            toolBar.AddTool((int) Cmd.wxID_HTML_PRINT, wprintBitmap, nullBitmap,
                            false, wxDefaultCoord, wxDefaultCoord, null,
                            _("Print this page"), "");
            toolBar.AddSeparator();
            toolBar.AddTool((int)Cmd.wxID_HTML_OPTIONS, woptionsBitmap, nullBitmap,
                            false, wxDefaultCoord, wxDefaultCoord, null,
                            _("Display options dialog"), "");
            toolBar.AddSeparator();
            toolBar.AddTool((int)wxID_ABOUT, ArtProvider.GetBitmap(ArtID.wxART_TIP, ArtClient.wxART_TOOLBAR, wpanelBitmap.Size), nullBitmap,
                            false, wxDefaultCoord, wxDefaultCoord, null,
                            _("Display help on help"), "");
        }

        internal void OnDisplayOptionsDialog(object sender, Event evt)
        {
            DisplayOptionsDialog();
        }

        /** Displays options dialog (fonts etc.)
         * */
        virtual protected void DisplayOptionsDialog()
        {
            OptionsDialog dlg=new OptionsDialog(this);

            if (this._NormalFonts == null)
            {
                FontEnumerator enu=new FontEnumerator();
                enu.EnumerateFacenames();
                this._NormalFonts = new ArrayString(enu.Facenames);
                this._NormalFonts.Sort(); // ascending sort
            }
            if (this._FixedFonts == null)
            {
                FontEnumerator enu=new FontEnumerator();
                enu.EnumerateFacenames(FontEncoding.wxFONTENCODING_SYSTEM, true /*enum fixed width only*/);
                this._FixedFonts = new ArrayString();
                this._FixedFonts.Add(enu.Facenames);
                this._FixedFonts.Sort(); // ascending sort
            }

            // VS: We want to show the font that is actually used by wxHtmlWindow.
            //     If customization dialog wasn't used yet, facenames are empty and
            //     wxHtmlWindow uses default fonts -- let's find out what they
            //     are so that we can pass them to the dialog:
            if (this._NormalFace.Length==0)
            {
                Font fnt=FontList.TheFontList.FindOrCreateFont(this._FontSize, FontFamily.wxSWISS, FontStyle.wxNORMAL, FontWeight.wxNORMAL, false);
                this._NormalFace = fnt.FaceName;
            }
            if (this._FixedFace.Length==0)
            {
                Font fnt=FontList.TheFontList.FindOrCreateFont(this._FontSize, FontFamily.wxMODERN, FontStyle.wxNORMAL, FontWeight.wxNORMAL, false);
                this._FixedFace = fnt.FaceName;
            }

            for (int i = 0; i < this._NormalFonts.Count; i++)
                dlg.NormalFont.Append(this._NormalFonts[i]);
            for (int i = 0; i < this._FixedFonts.Count; i++)
                dlg.FixedFont.Append(this._FixedFonts[i]);
            if (this._NormalFace.Length > 0)
                dlg.NormalFont.StringSelection=this._NormalFace;
            else
                dlg.NormalFont.Selection=0;
            if (this._FixedFace.Length > 0)
                dlg.FixedFont.StringSelection=this._FixedFace;
            else
                dlg.FixedFont.Selection=0;
            dlg.FontSize.Value=this._FontSize;
            dlg.UpdateTestWin();

            if (dlg.ShowModal() == wx.ShowModalResult.OK)
            {
                this._NormalFace = dlg.NormalFont.StringSelection;
                this._FixedFace = dlg.FixedFont.StringSelection;
                this._FontSize = dlg.FontSize.Value;
                SetFontsToHtmlWin(this._HtmlWin, this._NormalFace, this._FixedFace, this._FontSize);
            }
        }

        internal void OnCloseCmd(object sender, Event evt)
        {
            this.Close();
        }


        /** This adds the additionally required tag handlers.
         * wx.HtmlButtonTagHandler, wx.HtmlArtProviderTagHandler, and two instances
         * of wx.HtmlChoiceTagHandler.
         */
        static void PrepareHtmlWindowForHelpOnHelp(HtmlWindow html, EventListener closeEvent)
        {
            html.Parser.AddTagHandler(new HtmlButtonTagHandler());
            html.Parser.AddTagHandler(new HtmlArtProviderTagHandler());
            HtmlChoiceTagHandler translationsTag = new HtmlChoiceTagHandler(HtmlChoiceTagHandler.Style.Choice, "translations");
            translationsTag.Append("deutsch", "Info_de.html");
            translationsTag.Append("English", "Info_en.html");
            html.Parser.AddTagHandler(translationsTag);
            HtmlChoiceTagHandler generalChoice = new HtmlChoiceTagHandler(HtmlChoiceTagHandler.Style.Choice, "choice");
            generalChoice.Append("---");
            html.Parser.AddTagHandler(generalChoice);

            html.EVT_BUTTON(Window.wxID_CANCEL, closeEvent);
        }

        /** Presents an HTML Abount Box.
         */
        class AboutBox : Frame
        {
            public enum Cmd
            {
                wxID_CLOSE = 6200
            }
            public AboutBox(Window parent) : base(parent, Window.wxID_ANY, _("About HelpView"), wxDefaultPosition, new Size(600, 400))
            {
                this.Icon = ArtProvider.GetIcon(ArtID.wxART_QUESTION, ArtClient.wxART_FRAME_ICON);
                this.CreateStatusBar();
                //this.Sizer = new wx.BoxSizer(Orientation.wxVERTICAL);
                HtmlWindow html = new HtmlWindow(this, wxDefaultPosition, wxDefaultSize /*, HtmlWindow.wxFULL_REPAINT_ON_RESIZE*/);
                html.RelatedStatusBar = 0;

                PrepareHtmlWindowForHelpOnHelp(html, new EventListener(OnCloseCmd));

                if (Locale.SystemLanguage == Language.wxLANGUAGE_GERMAN
                    || Locale.SystemLanguage == Language.wxLANGUAGE_GERMAN_AUSTRIAN
                    || Locale.SystemLanguage == Language.wxLANGUAGE_GERMAN_BELGIUM
                    || Locale.SystemLanguage == Language.wxLANGUAGE_GERMAN_LIECHTENSTEIN
                    || Locale.SystemLanguage == Language.wxLANGUAGE_GERMAN_LUXEMBOURG
                    || Locale.SystemLanguage == Language.wxLANGUAGE_GERMAN_SWISS)
                {
                    html.SetRelatedFrame(this, "Über HelpView");
                    html.LoadPage("zrs:helpview.zrs//Info_de.html");
                }
                else
                {
                    html.SetRelatedFrame(this, "About HelpView");
                    html.LoadPage("zrs:helpview.zrs//Info_en.html");
                }
                //this.Sizer.Add(html, 1, Direction.wxALL, 5);

                //this.Sizer.Fit(frame);
                this.Centre();
            }

            public void OnCloseCmd(object sender, Event evt)
            {
                this.Close();
            }
        }

        internal void OnAboutBox(object sender, Event evt)
        {
            wx.Frame frame = new AboutBox(this);
            frame.Show(true);
        }

        internal void OnLoadBookEvent(object sender, Event evt)
        {
            if (evt is CommandEvent)
            {
                CommandEvent cevt = (CommandEvent)evt;
                this.LoadBook(cevt.String);
            }
            else
                evt.Skip(true);
        }

        /** This will load a hyper text book or HTML page into the current view.
         * The following file name extensions will be recognized as HTB: \c .zip, \c .htb, and \c .hhp.
         */
        public void LoadBook(string s)
        {
            if (s.Length > 0)
            {
                string extTest = s.ToLower();
                if (extTest.EndsWith(".zip") || extTest.EndsWith(".htb") || extTest.EndsWith(".hhp"))
                {
                    if (File.Exists(s))
                    {
                        s = Path.GetFullPath(s);
                        using (BusyCursor bcur = new BusyCursor())
                        using (BusyInfo info = new BusyInfo(string.Format(_("Reading book {0}."), s), this._HtmlWin))
                        {
                            this._Data.AddBook(s);
                            RefreshLists();
                            DisplayHelpOnHelp();
                        }
                    }
                    else
                        Log.LogWarning(string.Format(_("Cannot find file {0}."), s));
                }
                else
                    this._HtmlWin.LoadPage(s);
            }
            else
                Log.LogWarning(_("Cannot conclude which help book to load from an empty string."));
        }

        internal void OnOpenFile(object sender, Event evt)
        {
            StringBuilder filemask = new StringBuilder();
            filemask.Append(_("Help books (*.htb)|*.htb|Help books (*.zip)|*.zip|"));
            filemask.Append(_("HTML Help Project (*.hhp)|*.hhp|"));
            filemask.Append(_("HTML files (*.html;*.htm)|*.html;*.htm|"));
            filemask.Append(_("All files (*.*)|*"));
            FileSelector fs = new FileSelector(_("Open HTML document"), "", "", "", filemask.ToString(), wx.WindowStyles.FD_OPEN | wx.WindowStyles.FD_FILE_MUST_EXIST, this);
            string s = (string)fs;
            if (s.Length > 0)
                 this.LoadBook(s);
        }

        /** This will display help on help.
         * This will be loaded from "zrs:helpview.zrs//Info_en.html". However, this method will use
         * the system locale to gather whether one of the available translations is more adequate.
         */
        internal void DisplayHelpOnHelp()
        {
            if (Locale.SystemLanguage == Language.wxLANGUAGE_GERMAN
                || Locale.SystemLanguage == Language.wxLANGUAGE_GERMAN_AUSTRIAN
                || Locale.SystemLanguage == Language.wxLANGUAGE_GERMAN_BELGIUM
                || Locale.SystemLanguage == Language.wxLANGUAGE_GERMAN_LIECHTENSTEIN
                || Locale.SystemLanguage == Language.wxLANGUAGE_GERMAN_LUXEMBOURG
                || Locale.SystemLanguage == Language.wxLANGUAGE_GERMAN_SWISS)
            {
                this._HtmlWin.LoadPage("zrs:helpview.zrs//Info_de.html");
            }
            else
            {
                this._HtmlWin.LoadPage("zrs:helpview.zrs//Info_en.html");
            }
        }

        internal void OnSearchPage(object sender, Event evt)
        {
            this._HtmlWin.FindDialog.Show(true);
        }

        internal void OnToggleSearchPanel(object sender, Event evt)
        {
            this._HtmlSearchWin.ToggleSearchPanel();
        }

        internal void OnHtmlBack(object sender, Event evt)
        {
            this.NotifyPageWillChange();
            this._HtmlWin.HistoryBack();
            this.NotifyPageChanged();
        }

        internal void OnHtmlForward(object sender, Event evt)
        {
            this.NotifyPageWillChange();
            this._HtmlWin.HistoryForward();
            this.NotifyPageChanged();
        }

        internal void OnHtmlUp(object sender, Event evt)
        {
            if (this._PagesHash != null)
            {
                string page = HtmlHelpWindow.GetOpenedPageWithAnchor(this._HtmlWin);
                HtmlHelpHashData ha = null;
                if (page.Length > 0)
                    ha = (HtmlHelpHashData)this._PagesHash[page];
                if (ha != null && ha.m_Index > 0)
                {
                    HtmlHelpDataItem it = this._Data.ContentsArray[ha.m_Index - 1];
                    if (it.Page.Length > 0)
                    {
                        this.NotifyPageWillChange();
                        this._HtmlWin.LoadPage(it.FullPath);
                        this.NotifyPageChanged();
                    }
                }
            }
        }

        internal void OnHtmlUpNode(object sender, Event evt)
        {
            if (this._PagesHash != null)
            {
                string page = HtmlHelpWindow.GetOpenedPageWithAnchor(this._HtmlWin);
                HtmlHelpHashData ha = null;
                if (page.Length > 0)
                    ha = (HtmlHelpHashData)this._PagesHash[page];
                if (ha != null && ha.m_Index > 0)
                {
                    int level =
                        this._Data.ContentsArray[ha.m_Index].Level - 1;
                    int ind = ha.m_Index - 1;

                    HtmlHelpDataItem it =
                        this._Data.ContentsArray[ind];
                    while (ind >= 0 && it.Level != level)
                    {
                        ind--;
                        it = this._Data.ContentsArray[ind];
                    }
                    if (ind >= 0)
                    {
                        if (it.Page.Length > 0)
                        {
                            this.NotifyPageWillChange();
                            this._HtmlWin.LoadPage(it.FullPath);
                            this.NotifyPageChanged();
                        }
                    }
                }
            }
        }

        internal void OnHtmlDown(object sender, Event evt)
        {
            if (this._PagesHash != null)
            {
                string page = HtmlHelpWindow.GetOpenedPageWithAnchor(this._HtmlWin);
                HtmlHelpHashData ha = null;
                if (page.Length > 0)
                    ha = (HtmlHelpHashData)this._PagesHash[page];

                using (HtmlHelpDataItems contents = this._Data.ContentsArray)
                {
                    if (ha != null && ha.m_Index < (int)contents.Count - 1)
                    {
                        int idx = ha.m_Index + 1;
                        while (contents[idx].FullPath == page) idx++;

                        if (contents[idx].Page.Length > 0)
                        {
                            this.NotifyPageWillChange();
                            this._HtmlWin.LoadPage(contents[idx].FullPath);
                            this.NotifyPageChanged();
                        }
                    }
                }
            }
        }

        internal void OnHtmlPanel(object sender, Event evt)
        {
            if (this._Splitter == null || this._NavigPan == null)
                return;
            if (this._Splitter.IsSplit)
            {
                this._Cfg.sashpos = this._Splitter.SashPosition;
                this._Splitter.Unsplit(this._NavigPan);
                this._Cfg.navig_on = false;
            }
            else
            {
                this._NavigPan.Show();
                this._HtmlWin.Show();
                this._Splitter.SplitVertically(this._NavigPan, this._HtmlSearchWin, this._Cfg.sashpos);
                this._Cfg.navig_on = true;
            }
        }

        /** Finds the index of the provided page (URL) in the list of bookmarks.
         * This will return -1 if the provided page does not have a bookmark.
         */
        internal int FindPosBookmarkPage(string page)
        {
            int pos = 0;
            foreach (BookmarkEntry entry in this._BookmarkSpecs)
            {
                if (entry.Page == page) return pos;
                ++pos;
            }
            return -1;
        }

        /** Finds the index of the provided name in the list of bookmarks.
         * This will return -1 if the list of bookmarks do not contain the required title.
         */
        internal int FindPosBookmarkName(string name)
        {
            int pos = 0;
            foreach (BookmarkEntry entry in this._BookmarkSpecs)
            {
                if (entry.Name == name) return pos;
                ++pos;
            }
            return -1;
        }

        /** This will open a BookmarksDialog.
         */
        internal void OnEditBookmark(object sender, Event evt)
        {
            BookmarkEntry editEntry = null;
            foreach (BookmarkEntry loopentry in this._BookmarkSpecs)
            {
                if (loopentry.Page == ((CommandEvent)evt).String)
                {
                    editEntry = loopentry;
                    break;
                }
            }
            if (editEntry != null)
            {
                BookmarksDialog dlg = new BookmarksDialog(this, editEntry);
                dlg.ShowModal();
                
                this._HtmlWin.LoadPage("helpview:bookmarks.html");
            }
        }

        /** This will present the list of bookmarks and enable the user to add descriptions.
         * This page makes use of the builtin HTML tag HtmlChoiceTagHandler "BOOKMARKORDER".
         * Make sure that this handler has been added.
         */
        internal void OnBookmarksInfo(object sender, Event evt)
        {
            this._HtmlWin.LoadPage("helpview:bookmarks.html");
        }

        internal void OnBookmarksAdd(object sender, Event evt)
        {
            BookmarkEntry entry = new BookmarkEntry(this._HtmlWin.OpenedPageTitle, this._HtmlWin.OpenedPage);
            if (entry.Name.Length == 0)
            {
                int pos = entry.Page.LastIndexOf('/');
                if (pos >= 0 && pos < entry.Page.Length - 1)
                    entry.Name = entry.Page.Substring(pos + 1);
            }
            int bookmarkIndex = this.FindPosBookmarkPage(entry.Page);
            if (bookmarkIndex < 0)
            {
                int itemIndex=this._Bookmarks.Append(entry.Name);
                this._Bookmarks.Select(itemIndex);
                this._BookmarkSpecs.Add(entry);
            }
            else
            {
                // we already have this bookmark but will mark it as used.
                ((BookmarkEntry)this._BookmarkSpecs[bookmarkIndex]).LastUse = DateTime.Today;
            }
        }

        internal void OnBookmarksRemove(object sender, Event evt)
        {
            string item = this._Bookmarks.StringSelection;
            int pos = this.FindPosBookmarkName(item);
            if (pos >= 0)
            {
                this._BookmarkSpecs.RemoveAt(pos);
                this._Bookmarks.Delete(this._Bookmarks.Selection);
                this._Bookmarks.Select(0);
            }
        }

        internal void OnPrint(object sender, Event evt)
        {
            if (this._Printer == null)
                this._Printer = new HtmlEasyPrinting(_("Help Printing"), this);
            if (this._HtmlWin.OpenedPage.Length == 0)
                Log.LogWarning(_("Cannot print empty page."));
            else
                this._Printer.PrintFile(this._HtmlWin.OpenedPage);
        }

        /** This will be called on selecting a content item.
         */
        protected void OnContentsSel(object sender, Event gevt)
        {
            TreeEvent evt = (TreeEvent)gevt;
            HtmlHelpTreeItemData pg
                = (HtmlHelpTreeItemData) this._ContentsBox.GetItemData(evt.Item);

            if (pg!=null && this._UpdateContents)
            {
                using (HtmlHelpDataItems contents = this._Data.ContentsArray)
                {
                    this._UpdateContents = false;
                    if (contents[pg.m_Id].Page.Length > 0)
                        this._HtmlWin.LoadPage(contents[pg.m_Id].FullPath);
                    this._UpdateContents = true;
                    this._HtmlSearchWin.FindNext("\"" + contents[pg.m_Id].Name + "\"");
                }
            }
        }
        protected void OnIndexSel(object sender, Event evt)
        {
            HtmlHelpMergedIndexItem it = (HtmlHelpMergedIndexItem)
                ((SystemObjectClientData) this._IndexList.GetClientObject(this._IndexList.Selection)).Data;
            if (it != null)
            {
                this.DisplayIndexItem(it);
                this._HtmlSearchWin.FindNext(it.Name);
            }
        }

        /** Simply starts StartIndexFind().
         * Argument is unused.
         * */
        protected void OnIndexFind(object sender, Event evt)
        {
            this.StartIndexFind();
        }

        /** Displays all keyword of the index complying with the current search text.
         * An index is thought to match a search expression of it contains the search expression.
         * */
        protected void StartIndexFind()
        {
            string sr = this._IndexText.GetLineText(0);
            sr=sr.ToLower();
            if (sr.Length==0)
            {
                this.StartIndexAll();
            }
            else
            {
                string[] srwords = sr.Split(' ');
                using (BusyCursor bcur = new BusyCursor())
                {
                    this._IndexList.Clear();
                    HtmlHelpMergedIndex index = this._mergedIndex;
                    int cnt = index.Count;

                    int displ = 0;
                    for (int i = 0; i < cnt; ++i)
                    {
                        bool foundAllWords = true;
                        foreach (string word in srwords)
                        {
                            if (index[i].Name.ToLower().IndexOf(word) < 0)
                            {
                                foundAllWords = false;
                                break;
                            }
                        }
                        if (foundAllWords)
                        {
                            int pos = this._IndexList.Append(index[i].Name, new SystemObjectClientData(index[i]));

                            if (displ++ == 0)
                            {
                                // don't automatically show topic selector if this
                                // item points to multiple pages:
                                if (index[i].Count == 1)
                                {
                                    this._IndexList.Selection=0;
                                    this.DisplayIndexItem(index[i]);
                                }
                            }

                            // if this is nested item of the index, show its parent(s)
                            // as well, otherwise it would not be clear what entry is
                            // shown:
                            HtmlHelpMergedIndexItem parent = index[i].Parent;
                            while (parent != null)
                            {
                                if (pos == 0 ||
                                    (index.Index((HtmlHelpMergedIndexItem) ((SystemObjectClientData) this._IndexList.GetClientObject(pos-1)).Data) < index.Index(parent)))
                                {
                                    this._IndexList.Insert(parent.Name, pos, new SystemObjectClientData(parent));
                                    parent = parent.Parent;
                                }
                                else break;
                            }

                            // finally, it the item we just added is itself a parent for
                            // other items, show them as well, because they are refinements
                            // of the displayed index entry (i.e. it is implicitly contained
                            // in them: "foo" with parent "bar" reads as "bar, foo"):
                            int level = index[i][0].Level;
                            ++i;
                            while (i < cnt && index[i][0].Level > level)
                            {
                                this._IndexList.Append(index[i].Name, new SystemObjectClientData(index[i]));
                                ++i;
                            }
                            --i;
                        }
                    }

                    string cnttext=string.Format(_("{0} of {1}"), displ, cnt);
                    this._IndexCountInfo.Label=cnttext;

                    this._IndexText.SetSelection(0, sr.Length);
                    this._IndexText.SetFocus();
                }
            }
        }
        /** Simply starts StartIndexAll().
         * Argument is unused.
         * */
        protected void OnIndexAll(object sender, Event evt)
        {
            StartIndexAll();
        }
        /** Displays all keyword of the index.
         * */
        protected void StartIndexAll()
        {
            using (BusyCursor bcur = new BusyCursor())
            {
                this._IndexList.Clear();
                HtmlHelpMergedIndex index = this._mergedIndex;
                int cnt = index.Count;
                bool first = true;

                for (int i = 0; i < cnt; ++i)
                {
                    this._IndexList.Append(index[i].Name, new SystemObjectClientData(index[i]));
                    if (first)
                    {
                        // don't automatically show topic selector if this
                        // item points to multiple pages:
                        if (index[i].Count == 1)
                        {
                            this.DisplayIndexItem(index[i]);
                        }
                        first = false;
                    }
                }

                string cnttext = string.Format(_("{0} of {1}"), cnt, cnt);
                this._IndexCountInfo.Label = cnttext;
            }
        }
        protected void OnSearchSel(object sender, Event evt)
        {
            HtmlHelpDataItem it = (HtmlHelpDataItem)((SystemObjectClientData)this._SearchList.GetClientObject(this._SearchList.Selection)).Data;
            if (it!=null)
            {
                this.NotifyPageWillChange();
                if (it.Page.Length > 0)
                    this._HtmlWin.LoadPage(it.FullPath);
                this.NotifyPageChanged();
                this._HtmlSearchWin.FindNext(it.Name);
            }
        }
        protected void OnSearch(object sender, Event evt)
        {
            string sr = this._SearchText.GetLineText(0);
            if (sr.Length > 0)
                this.KeywordSearch(sr, HelpSearchMode.wxHELP_SEARCH_ALL);
        }
        protected void OnBookmarksSel(object sender, Event evt)
        {
            string sr = this._Bookmarks.StringSelection;
            if (sr.Length > 0 && sr != _("(bookmarks)"))
            {
                int pos = this.FindPosBookmarkName(sr);
                if (pos >= 0)
                {
                    BookmarkEntry bookmark=(BookmarkEntry) this._BookmarkSpecs[pos];
                    string bookfile = bookmark.Bookfile;
                    if (bookfile != null && !this._Data.BookRecords.HasFile(bookfile))
                    {
                        this.LoadBook(bookfile);
                    }
                    this.NotifyPageWillChange();
                    this._HtmlWin.LoadPage(bookmark.Page);
                    this.NotifyPageChanged();
                }
            }
        }

        /** Call this only on close events.
         */
        protected void OnCloseWindow(object sender, Event evt)
        {
            this._Cfg.size = this.Size;
            this._Cfg.position = this.Position;

            if (this._Splitter != null && this._Cfg.navig_on)
                this._Cfg.sashpos = this._Splitter.SashPosition;

            if (this._Config != null)
                this.WriteCustomization(this._Config, this._ConfigRoot);

            if (this._helpController != null && this._helpController is HtmlHelpController)
            {
                ((HtmlHelpController) this._helpController).OnCloseFrame((CloseEvent) evt);
            }

            evt.Skip();
        }
        protected void OnActivate(ActivateEvent evt)
        {
            // This saves one mouse click when using the
            // wxHTML for context sensitive help systems
            if (ReflectConfig.CheckWxGTK())
            {
                // NB: wxActivateEvent is a bit broken in wxGTK
                //     and is sometimes sent when it should not be
                if (evt.Active && this._HtmlWin != null)
                    this._HtmlWin.SetFocus();
            }

            evt.Skip();
        }

        void DisplayIndexItem(HtmlHelpMergedIndexItem it)
        {
            if (it.Count == 1)
            {
                if (it[0].Page.Length > 0)
                {
                    this.NotifyPageWillChange();
                    this._HtmlWin.LoadPage(it[0].FullPath);
                    this.NotifyPageChanged();
                }
            }
            else
            {
                // more pages associated with this index item -- let the user choose
                // which one she/he wants from a list:
                int len = it.Count;
                string[] arr = new string[len];
                using (HtmlHelpDataItems contents = this._Data.ContentsArray)
                {
                    for (int i = 0; i < len; ++i)
                    {
                        string page = it[i].Page;
                        // try to find page's title in contents:
                        int clen = contents.Count;
                        for (int j = 0; j < clen; j++)
                        {
                            if (contents[j].Page == page)
                            {
                                page = contents[j].Name;
                                break;
                            }
                        }
                        arr[i] = page;
                    }
                }
                
                SingleChoiceDialog dlg=new SingleChoiceDialog(this,
                                       _("Please choose the page to display:"),
                                       _("Help Topics"),
                                       arr, null, wx.WindowStyles.CHOICEDLG_STYLE & ~wx.WindowStyles.ALIGN_CENTRE);
                if (dlg.ShowModal() == wx.ShowModalResult.OK)
                {
                    this.NotifyPageWillChange();
                    this._HtmlWin.LoadPage(it[dlg.GetSelection()].FullPath);
                    this.NotifyPageChanged();
                }
            }
        }
        #endregion

        #region Events Affecting The HTML Window
        void OnKeyPressHtmlWindow(object sender, Event evt)
        {
            KeyEvent kevt = evt as KeyEvent;
            if (kevt == null)
                evt.Skip();
            else
            {
                if (kevt.ControlDown && kevt.KeyCode == 'c')
                {
                    kevt.Skip();
                    this.OnCopySelectedHtmlAsText(sender, evt);
                }
                else if (kevt.KeyCode == (int)KeyCode.WXK_DOWN
                    || kevt.KeyCode == (int)KeyCode.WXK_NUMPAD_DOWN)
                {
                    this._HtmlWin.ScrollLines(1);
                }
                else if (kevt.KeyCode == (int)KeyCode.WXK_UP
                    || kevt.KeyCode == (int)KeyCode.WXK_NUMPAD_UP)
                {
                    this._HtmlWin.ScrollLines(-1);
                }
                else if (kevt.KeyCode == (int)KeyCode.WXK_PAGEDOWN
                    || kevt.KeyCode == (int)KeyCode.WXK_NUMPAD_PAGEDOWN)
                {
                    this._HtmlWin.ScrollPages(1);
                }
                else if (kevt.KeyCode == (int)KeyCode.WXK_PAGEUP
                    || kevt.KeyCode == (int)KeyCode.WXK_NUMPAD_PAGEUP)
                {
                    this._HtmlWin.ScrollPages(-1);
                }
                else
                    kevt.Skip();
            }
        }

        Point _popupPosition = wxDefaultPosition;
        void OnOpenPopupMenuHtmlWindow(object sender, Event evt)
        {
            Menu popup = new Menu();
            if (this._HtmlWin.HasSelection)
                popup.Append(Cmd.HTML_WinCopyText);
            this._popupPosition = wxDefaultPosition;
            if (evt is MouseEvent)
            {
                this._popupPosition = ((MouseEvent)evt).Position;
                Point viewStart = this._HtmlWin.ViewStart;
                this._popupPosition.X += viewStart.X;
                this._popupPosition.Y += viewStart.Y;
                popup.Append(Cmd.HTML_WinCopyBitmap);
            }
            this.PopupMenu(popup);
        }

        /** Method to draw cells recursive into a \c dc.
        */
        static void DrawHtmlCellRecursive(DC dc, HtmlCell cell, Point nullPosition, int displayHeight, HtmlCell endElement)
        {
            if (cell == null)
                return;
            cell.Draw(dc, -nullPosition.X, -nullPosition.Y, nullPosition.Y, nullPosition.Y+displayHeight);
            HtmlCell firstChild = cell.FirstChild;
            if (firstChild != null)
                DrawHtmlCellRecursive(dc, firstChild, nullPosition, displayHeight, endElement);
            HtmlCell nextCell = cell.Next;
            if (cell != endElement && nextCell != null)
                DrawHtmlCellRecursive(dc, nextCell, nullPosition, displayHeight, endElement);
        }

        void OnCopySelectedHtmlAsBitmap(object sender, Event evt)
        {
            if (this._popupPosition != wxDefaultPosition)
            {
                HtmlCell current = this._HtmlWin.InternalRepresentation.FindCellByPos(this._popupPosition);
                /*
                if (current == null)
                    current = this._HtmlWin.InternalRepresentation;
                */
                if (current != null)
                {
                    Bitmap selectedBitmap = new Bitmap(current.Width, current.Height);
                    using (MemoryDC memDc = new MemoryDC())
                    {
                        if (!memDc.Ok) return;
                        memDc.SelectObject(selectedBitmap);
                        if (!memDc.Ok) return;

                        using (Brush bgBrush = new Brush(this._HtmlWin.BackgroundColour))
                        {
                            memDc.Background = bgBrush;
                            memDc.Font = this._HtmlWin.Font;
                            memDc.TextBackground = bgBrush.Colour;
                            memDc.TextForeground = this._HtmlWin.ForegroundColour;
                            memDc.LogicalFunction = Logic.wxCOPY;
                            memDc.Clear();
                        }

                        DrawHtmlCellRecursive(memDc, current, current.Pos, current.Height, current);
                    }
                    using (Clipboard cb = new Clipboard())
                    {
                        try
                        {
                            cb.Open();
                            cb.AddData(new BitmapDataObject(selectedBitmap));
                        }
                        finally
                        {
                            cb.Close();
                        }
                    }
                }
            }
        }

        void OnCopySelectedHtmlAsText(object sender, Event evt)
        {
            string selected=this._HtmlWin.SelectionText;
            TextDataObject clipBoardData = new TextDataObject(selected);
            Clipboard clipboard = new Clipboard();
            try
            {
                clipboard.Open();
                clipboard.SetData(clipBoardData);
            }
            finally
            {
                clipboard.Close();
            }
            this.SetStatusText(_("Copied {0} characters of text to the clipboard.", selected.Length));
        }
        #endregion
    }

    /** This class implements the help view application \c helpview.exe
     * \c helpview.exe is the \e wx.NET help viewer. This application typically also
     * contains the standard help files \c wx.net.htb and \c wx.htb as compiled in
     * resources.
     * 
     * \image html helpviewsmall.png "The HTML help viewer."
     */
    public class HtmlHelpApp : wx.App
    {
        #region State
        string[] _args=null;
        HtmlHelpFrame _help = null;
        #endregion
        #region CTOR, DTOR
        /** This will set application and vendor name. These are essential inputs to wx.Config.Create().
         */
        public HtmlHelpApp()
        {
            this.AppName = "HelpView";
            this.VendorName = "wx.NET";
        }
        #endregion

        #region Properties
        /** Generates an application loading a number of books as specified in args.
         * */
        public string[] Args
        {
            get { return this._args; }
            set
            {
                // we have to test whether the args are accessable.
                ArrayList list = new ArrayList(value.Length);
                for (int i = 0; i < value.Length; ++i)
                {
                    if (File.Exists(value[i]))
                        list.Add(value[i]);
                }
                if (list.Count > 0)
                {
                    _args = new string[list.Count];
                    for (int i=0; i < list.Count; ++i)
                        _args[i]=(string)list[i];
                }
                else
                    _args = null;
            }
        }
        #endregion

        #region Internals
        internal string[] ResourceDir()
        {
            return null;
        }

        /** This will load the initially required hyperbooks.
         */
        internal void LoadInitFiles(object statobject)
        {
            /*
            Thread.Sleep(200);
            string path = new Uri(Assembly.GetExecutingAssembly().Location).LocalPath;
            path = Path.GetDirectoryName(path);
            string filepath = Path.Combine(path, "../Docs/wx.net.htb");
            filepath = Path.GetFullPath(filepath);
            if (File.Exists(filepath))
            {
                CommandEvent loadPageEvent = new CommandEvent(Event.wxEVT_LOAD_HTML_PAGE);
                loadPageEvent.String = filepath;
                _help.AddPendingEvent(loadPageEvent);
            }
            filepath = Path.Combine(path, "../Docs/wx.htb");
            filepath = Path.GetFullPath(filepath);
            if (File.Exists(filepath))
            {
                CommandEvent loadPageEvent = new CommandEvent(Event.wxEVT_LOAD_HTML_PAGE);
                loadPageEvent.String = filepath;
                _help.AddPendingEvent(loadPageEvent);
            }
            */
        }

        #endregion

        public override bool OnInit()
        {
            using (BusyInfo info = new BusyInfo(_("Starting HelpView and loading hyper text books.")))
            {
                wx.Archive.ZipResource.AddCatalogLookupPrefix(@"../Utils/HelpView");
                wx.Archive.ZipResource.AddCatalogLookupPrefix(@".");
                wx.Archive.ZipResource.AddCatalogLookupPrefix(@"../HelpView");
                wx.Archive.ZipResource.AddCatalogLookupPrefix(@"../../ZRS");
                {
                    _help = new HtmlHelpFrame(null, -1, _("wx.NET help center"));
                    Config config = Config.Get();
                    _help.UseConfig(config);
                    _help.DisplayContents();
                    _help.Show();

                    FileSystem.AddHandler(new HtmlHelpFrame.SpecialPagesAsFiles(_help));

                    string[] args = this.Args;
                    if (args != null && args.Length > 0)
                    {
                        foreach (string helpfile in args)
                            _help.LoadBook(helpfile);
                    }
                    else
                    {
                        ThreadPool.QueueUserWorkItem(new WaitCallback(this.LoadInitFiles));
                    }
                }
            }
            return true;
        }

        public override int OnExit()
        {
            return base.OnExit();
        }

        [STAThread]
        static void Main(string[] args)
        {
            System.Diagnostics.Trace.Listeners.Add(new System.Diagnostics.ConsoleTraceListener());
            FileSystem.AddHandler(new IOStreamFSHandler());
            FileSystem.AddHandler(new ZipFSHandler());

            HtmlHelpApp app = new HtmlHelpApp();
            app.Args = args;
            app.Run();
        }
    }
}
