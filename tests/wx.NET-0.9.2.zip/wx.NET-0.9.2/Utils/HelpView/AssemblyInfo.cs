//------------------------------------------------------------------------
// HelpView.exe - AssemblyInfo.cs
// 
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: AssemblyInfo.cs,v 1.5 2009/08/17 19:35:54 harald_meyer Exp $
//------------------------------------------------------------------------

using System;
using System.Reflection;
using System.Resources;
using System.Security;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyVersion("0.8.0.1")]

[assembly: AssemblyTitle("HelpView.exe")]
[assembly: AssemblyDescription("Viewer for wxWidgets hyper text books (*.htb).")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("wx.NET Development Team")]
[assembly: AssemblyProduct("")]
[assembly: AssemblyCopyright("(C) 2006-2009 Harald Meyer auf'm Hofe")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]	

[assembly: AllowPartiallyTrustedCallers()]
[assembly: ComVisibleAttribute(false)]
