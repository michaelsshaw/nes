//------------------------------------------------------------------------
// ZipRC.exe - ZipRC.cs
// 
// Licensed under the wxWidgets license, see LICENSE.txt for details.
// (c) Dr. Harald Meyer auf'm Hofe
//
// $Id: ZipRC.cs,v 1.10 2010/01/24 13:57:29 harald_meyer Exp $
//------------------------------------------------------------------------

//#define TRACE
using System;
using System.IO;
using System.Collections;
using System.Diagnostics;
using System.Text;
using wx;

/** Namespace containing the compile tool for zipped resource files or hyper text books.
 */
namespace wx.ZipRC
{

    /** Implementation of the ZipRC.exe zipped resource compiler.
     * This is a very simple tool for building and extracting from zipped resource archives that
     * fit for class wx.ZipResource. The arguments provide an action code (\c compile or \c extract),
     * the name of a zipped resource archive, and a list of files optionally interrupted by switches changing the locale.
     * The particular effect of this procedure: The files will be either loaded from the current locale
     * or compressed and inserted into the archive with the name of the current locale mangled into
     * the resource name in such a way, that wx.ZipResource will load it with the current locale.
     * */
    class ZipResourceCompiler
    {
        /** Opens archive named \c archiveFileName and prints out the names of the entries.
         * */
        public static void PrintArchiveContent(TextWriter dest, string archiveFileName)
        {
            wx.Archive.ArchiveInput archive = new wx.Archive.ArchiveInput(archiveFileName);
            int index = 0;
            for (wx.Archive.ArchiveEntry entry = archive.GetNextEntry();
                entry != null;
                entry = archive.GetNextEntry(), ++index)
            {
                dest.WriteLine(string.Format("   {0}: \"{1}\"<=>\"{2}\"\n        {3} size {4} {5} {6}",
                    index + 1,
                    entry.InternalName, entry.Name,
                    entry.DateTime,
                    entry.Size,
                    entry.IsDir ? "is directory" : "",
                    entry.IsReadOnly ? "is read only" : ""));
            }
        }

        public static int Main(string[] args)
    {
        //Trace.Listeners.Add(new TextWriterTraceListener(Console.Out));
        int result = 0;

        Console.Out.WriteLine("ZipRC 0.9.0 (c) 2006-2010 wx.NET Team");
        bool printHelp = (args.Length < 3)
            || (args[0] != "info" && args[0] != "i" && args[0] != "compile" && args[0] != "c" && args[0] != "extract" && args[0] != "e");
        for (int i = 0; !printHelp && i < args.Length; ++i)
        {
            if (args[i] == "-h" || args[i] == "--help")
                printHelp=true;
        }
        if (printHelp)
        {
            Console.WriteLine("Generate ZIP archived resources .zrs or hyper text bools .htb.");
            Console.WriteLine("Synopsis: ZipRC.exe (compile | c | extract | e | info | i) ARCHIVE_FILE {--help | -h | --CANONICAL_NAME | FILE | RCNAME=FILE}*");
            Console.WriteLine("compile/c: Compile archive file ARCHIVE_FILE");
            Console.WriteLine("extract/e: Extract files from ARCHIVE_FILE");
            Console.WriteLine("info/i: Information ARCHIVE_FILE and the specified files (search paths, comparison)");
            Console.WriteLine("--help/-h: PrintData this information.");
            Console.WriteLine("-n=y|n|yes|no|1|0");
            Console.WriteLine("--htmlNormalization=y|n|yes|no|1|0: Turn on/off normalization of HTML for use in HTB (inlining CSS).");
            Console.WriteLine("-d=PATH/--dir=PATH: Process all the files of directory PATH.");
            Console.WriteLine("--CANONCAL_NAME e.g. --en|--de_DE: switch to the specified locale.");
            Console.WriteLine("FILE: compile or extract this file.");
            Console.WriteLine("RCFILE=FILE: compile FILE as RCFILE or extract RCFILE to FILE.");
            Console.WriteLine();
        }
        string canonicalName = "";
        if (args.Length == 0
            || (args[0] != "i" && args[0] != "info" && args[0] != "c" && args[0] != "compile" && args[0] != "e" && args[0] != "extract"))
        {
            Console.WriteLine("Expecting at least action specifyier (c|e|i) and archive as arguments.");
        }
        else if (args.Length < 1)
        {
            Console.WriteLine(string.Format("Recognized action {0} but missing archive name.", args[0]));
        }
        else
        {
            try
            {
                wx.Archive.ArchiveOutput output = null;
                bool htmlNormalizationIsOn = false;
                string archiveName = args[1];
                if (args[0] == "c" || args[0] == "compile")
                    output = new wx.Archive.ArchiveOutput(archiveName);
                else
                {
                    string[] derivates = wx.Archive.ZipResource.GetDerivatedArchiveNames(archiveName, "");
                    //Trace.WriteLine(string.Format("Found derivates {0}", derivates==null?"NULL":derivates.ToString()));
                    int index = 0;
                    foreach(string derivate in derivates)
                    {
                        Console.Write("{1}/{2}: Candidate {0}", derivate, index+1, derivates.Length);
                        if (File.Exists(derivate))
                        {
                            Console.WriteLine(" existing as file containing:");
                            PrintArchiveContent(Console.Out, derivate);
                        }
                        else if (Directory.Exists(derivate))
                            Console.WriteLine(" exists as directory.");
                        else
                            Console.WriteLine(" is unknown.");
                        ++index;
                    }
                    Console.WriteLine();
                }
                for (int i = 2; i < args.Length; ++i)
                {
                    Console.Out.WriteLine();
                    if (output != null && !output.IsOk)
                    {
                        Console.WriteLine("Destination is not OK.");
                        result = 2;
                        break;
                    }
                    if (args[i] == "-h" || args[i] == "--help") continue;

                    if (args[i].StartsWith("-n=") || args[i].StartsWith("--htmlNormalization="))
                    {
                        string value = args[i];
                        if (args[i].StartsWith("-n="))
                            value=value.Substring(3);
                        else
                            value=value.Substring(20);
                        if (value == "y" || value == "Y" || value.ToLower() == "yes" || value == "1")
                            htmlNormalizationIsOn = true;
                        else if (value == "n" || value == "N" || value.ToLower() == "no" || value == "0")
                            htmlNormalizationIsOn = false;
                        else
                            Console.Out.WriteLine("Cannot interpret value {0} for switch htmlNormalization.", value);
                        continue;
                    }
                    else if (args[i].StartsWith("-n") || args[i].StartsWith("--htmlNormalization"))
                    {
                        htmlNormalizationIsOn = true;
                    }

                    if (args[i].StartsWith("--") && !args[i].StartsWith("--dir"))
                    {
                        canonicalName = args[i].Substring(2);
                        if (args[0] == "i" || args[0] == "info")
                        {
                            Console.Out.WriteLine(string.Format("Archive {0} will be searched with locale <{1}> as:", archiveName, canonicalName.Length==0?"neutral":canonicalName));
                            string[] derivates = wx.Archive.ZipResource.GetDerivatedArchiveNames(archiveName, canonicalName);
                            for (int ii = 0; ii < derivates.Length; ++ii)
                            {
                                Console.Out.Write(string.Format("{2}/{3}: {0}. {1}", ii + 1, derivates[ii], ii+1, derivates.Length));
                                if (File.Exists(derivates[ii]))
                                {
                                    Console.Out.WriteLine(" is an existing file containing:");
                                    PrintArchiveContent(Console.Out, derivates[ii]);
                                }
                                else if (Directory.Exists(derivates[ii]))
                                    Console.Out.WriteLine(" is an existing directory.");
                                else
                                    Console.Out.WriteLine(" has not been found.");
                            }
                            Console.WriteLine();
                        }
                    }
                    else
                    {
                        string rsname = args[i];
                        string fsname0 = args[i];
                        if (args[i].StartsWith("-d"))
                        {
                            rsname = "--dir";
                            if (args[i].StartsWith("-d="))
                                fsname0 = args[i].Substring(3);
                            else
                                fsname0 = args[i].Substring(2);
                        }
                        else
                        {
                            int posEq = args[i].IndexOf('=');
                            if (posEq >= 0 && posEq < args[i].Length - 1)
                            {
                                rsname = args[i].Substring(0, posEq);
                                fsname0 = args[i].Substring(posEq + 1);
                            }
                        }
                        if (output != null)
                        {
                            IList files = new ArrayList();
                            files.Add(fsname0);
                            if (Directory.Exists(fsname0)
                                && (rsname == "-d" || rsname == "--dir"))
                            {
                                foreach (string file in Directory.GetFiles(fsname0))
                                {
                                    if (Path.GetFileName(file) != Path.GetFileName(archiveName))
                                        files.Add(file);
                                }
                            }
                            foreach (string fsname in files)
                            {
                                if (files.Count > 1)
                                    rsname = Path.GetFileName(fsname);
                                if (canonicalName.Length > 0)
                                {
                                    rsname = Path.Combine(canonicalName, fsname);
                                }
                                Console.Out.WriteLine(string.Format("File {0} => archive entry {1}, locale {2}.", fsname, rsname, canonicalName.Length == 0 ? "neutral" : canonicalName));
                                if (File.Exists(fsname))
                                {
                                    using (Stream inputStr = new FileStream(fsname, FileMode.Open))
                                    {
                                        bool done = false;
                                        if (htmlNormalizationIsOn
                                            && (fsname.ToLower().EndsWith(".htm") ||
                                                fsname.ToLower().EndsWith(".html")))
                                        {
                                            Console.Out.WriteLine("Normalize {0} on compilation.", fsname);
                                            try
                                            {
                                                TextReader reader = new StreamReader(inputStr);
                                                output.PutNextEntry(rsname);
                                                StreamWriter sw = new StreamWriter(output.Out);
                                                DoxygenHtbConverter inliner = new DoxygenHtbConverter(sw, reader);
                                                inliner.Parse();
                                                sw.Close();
                                                done = true;
                                            }
                                            catch (Exception exc)
                                            {
                                                Console.WriteLine("Error {0}.", exc);
                                            }
                                        }
                                        if (!done)
                                        {
                                            //Trace.WriteLine(string.Format("File {0} to archive entry {1}", fsname, rsname));
                                            output.PutNextEntry(rsname);
                                            int data = inputStr.ReadByte();
                                            while (data >= 0)
                                            {
                                                output.Out.WriteByte((byte)data);
                                                data = inputStr.ReadByte();
                                            }
                                        }
                                    }
                                }
                                else
                                {
                                    Console.WriteLine(string.Format("Cannot open source file {0}.", fsname));
                                }
                            }
                        }
                        else if (rsname!="-d" && rsname!="--dir")
                        {
                            Console.Out.WriteLine(string.Format("Looking for resource {0} <=> file <{1}>, locale {2} in <{3}>.", rsname, fsname0, canonicalName.Length==0?"neutral":canonicalName, archiveName));
                            if (args[0] == "i" || args[0] == "info")
                            {
                                Console.Out.WriteLine("Derivations of the resource name:");
                                string[] derivates = wx.Archive.ZipResource.GetDerivatedResourceNames(rsname, canonicalName);
                                for (int ii = 0; ii < derivates.Length; ++ii)
                                {
                                    Console.Out.WriteLine(string.Format("{0}. {1}", ii + 1, derivates[ii]));
                                }
                            }
                            Stream input = wx.Archive.ZipResource.FindResource(archiveName, rsname, canonicalName);
                            if (input == null)
                            {
                                Console.WriteLine(string.Format("Cannot open resource <{0}> in <{1}>.", rsname, archiveName));
                            }
                            else
                            {
                                Console.Out.WriteLine(string.Format("Found in <{0}> as <{1}>", wx.Archive.ZipResource.LastFoundArchiveName, wx.Archive.ZipResource.LastFoundResourceName));
                                if (args[0] == "i" || args[0] == "info")
                                {
                                    if (input is FileStream &&
                                        Path.GetFullPath(fsname0) == Path.GetFullPath(((FileStream)input).Name))
                                    {
                                        Console.WriteLine(string.Format("Directory as resource and reference refer to the same file {0}.", Path.GetFullPath(fsname0)));
                                    }
                                    else
                                    {
                                        int firstPosDiffer = 0;
                                        int pos = 0;
                                        int diff = 0;
                                        int archiveWordDiffer = 0;
                                        int fileWordDiffer = 0;
                                        int data = 0;
                                        int refData = 0;
                                        using (Stream refStr = new FileStream(fsname0, FileMode.Open))
                                        {
                                            do
                                            {
                                                refData = refStr.ReadByte();
                                                data = input.ReadByte();
                                                //Trace.WriteLine(string.Format("{0}/{1} {2}/{3}", data, (char)data, refData, (char)refData));
                                                if (data >= 0 && refData >= 0 && data != refData)
                                                {
                                                    ++diff;
                                                    firstPosDiffer = pos;
                                                    archiveWordDiffer = data;
                                                    fileWordDiffer = refData;
                                                }
                                                ++pos;
                                            }
                                            while (data >= 0);

                                            if (diff >= 1)
                                            {
                                                Console.WriteLine(string.Format("{0} words differ starting with {1}/{2}!={3}/{4} at {5}.\n", diff, archiveWordDiffer, (char)archiveWordDiffer, fileWordDiffer, (char)fileWordDiffer, firstPosDiffer));
                                            }
                                            else
                                                Console.WriteLine("Both files share the same content.\n");
                                        }
                                    }
                                }
                                else
                                {
                                    using (Stream outputStr = new FileStream(fsname0, FileMode.Create))
                                    {
                                        int data = input.ReadByte();
                                        while (data >= 0)
                                        {
                                            outputStr.WriteByte((byte)data);
                                            data = input.ReadByte();
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                if (output != null)
                {
                    output.Close();
                }
            }
            catch (Exception exc)
            {
                Console.WriteLine(string.Format("Encountered error {0}.", exc));
                result = 1;
            }
        }
        return result;
    }
    }
}
