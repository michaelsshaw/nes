//------------------------------------------------------------------------
// ZipRC.exe - AssemblyInfo.cs
/** \file
  * Licensed under the wxWidgets license, see LICENSE.txt for details.
  * (c) Dr. Harald Meyer auf'm Hofe
  *
  * $Id: AssemblyInfo.cs,v 1.6 2010/01/24 13:57:29 harald_meyer Exp $
 */
//------------------------------------------------------------------------

using System;
using System.Reflection;
using System.Resources;
using System.Security;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyVersion("0.9.0.0")]

[assembly: AssemblyTitle("ZipRC.exe")]
[assembly: AssemblyDescription("Compression and decompression of zipped resources *.zrs.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("wx.NET Development Team")]
[assembly: AssemblyProduct("")]
[assembly: AssemblyCopyright("(C) 2006-2009 Harald Meyer auf'm Hofe")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]	

[assembly: AllowPartiallyTrustedCallers()]
