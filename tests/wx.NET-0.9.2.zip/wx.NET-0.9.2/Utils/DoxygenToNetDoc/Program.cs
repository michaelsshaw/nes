//-----------------------------------------------------------------------------
//
// Convert MS XML documentation of doxygen compliant code into a
// XML documentation that works.
//
// Written by Harald Meyer auf'm Hofe
// (C) 2007 by Harald Meyer auf'm Hofe
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: Program.cs,v 1.5 2010/05/08 19:58:11 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Xml;
using System.Text.RegularExpressions;

namespace NormalizeXmlDoc
{
    class Program
    {
        enum MissingTags
        {
            summary,
            param,
            result
        }

        static void ProcessingXMLDocumentationFile(string arg, string backupfile)
        {
            #region Processing XML documentation
            using (TextWriter destString = new StreamWriter(arg))
            {
                int isMemberTag = 0;
                XmlTextWriter dest = new XmlTextWriter(destString);
                dest.Formatting = Formatting.Indented;
                dest.WriteStartDocument();
                XmlTextReader reader = new XmlTextReader(backupfile);

                bool gotContentForMember = false;
                // Parse the file and display each of the nodes.
                while (reader.Read())
                {
                    switch (reader.NodeType)
                    {
                        case XmlNodeType.Element:
                            string elemName = reader.Name;
                            if (isMemberTag == 0)
                            {
                                dest.WriteStartElement(reader.Name);
                                if (reader.HasAttributes)
                                {
                                    while (reader.MoveToNextAttribute())
                                    {
                                        dest.WriteAttributeString(reader.Name, reader.Value);
                                    }
                                }
                            }
                            if (isMemberTag > 0)
                                gotContentForMember = true;
                            if (elemName == "member")
                            {
                                ++isMemberTag;
                                gotContentForMember = false;
                            }
                            break;
                        case XmlNodeType.Text:
                            if (isMemberTag > 0)
                            {
                                gotContentForMember = true;

                                string text = reader.Value;
                                text = text.Replace("\\verbatim", "\n");
                                text = text.Replace("\\endverbatim", "\n");
                                text = text.Replace("\\code", "\n");
                                text = text.Replace("\\endcode", "\n");
                                text = text.Replace("\\c", "");
                                text = text.Replace("\\e", "");
                                text = text.Replace("\\b", "");
                                text = text.Replace("\\li", "-");

                                string[] lines = text.Split('\n');
                                string summary = "";
                                List<string[]> parameter = new List<string[]>();
                                string result = "";
                                MissingTags mode = MissingTags.summary;
                                int lineIndex = 0;
                                foreach (string originalLine in lines)
                                {
                                    string line = originalLine.Trim();
                                    if (line.Length > 0
                                        && line[0] == '*')
                                    {
                                        line = line.Substring(1);
                                        line = line.TrimStart();
                                    }
                                    if (line.Length == 0)
                                    {
                                        mode = MissingTags.summary;
                                    }
                                    else if (line.StartsWith("\\param"))
                                    {
                                        line = line.Substring(7);
                                        mode = MissingTags.param;
                                    }
                                    else if (line.StartsWith("\\result"))
                                    {
                                        line = line.Substring(8);
                                        mode = MissingTags.result;
                                    }
                                    switch (mode)
                                    {
                                        case MissingTags.summary:
                                            if (lineIndex < 15)
                                                summary += "\n" + line;
                                            ++lineIndex;
                                            break;
                                        case MissingTags.result:
                                            result += "\n" + line;
                                            break;
                                        case MissingTags.param:
                                            {
                                                int nextBlank = line.IndexOf(' ');
                                                string[] newEntry = new string[2];
                                                if (nextBlank > 0)
                                                {
                                                    newEntry[0] = line.Substring(0, nextBlank).Trim();
                                                    newEntry[1] = line.Substring(nextBlank).Trim();
                                                }
                                                else
                                                {
                                                    newEntry[0] = line.Trim();
                                                    newEntry[1] = "";
                                                }
                                                break;
                                            }
                                    }
                                }
                                summary = summary.Trim(' ', '\n', '\r');
                                dest.WriteElementString("summary", summary);
                                result = result.Trim(' ', '\n', '\r');
                                if (result.Length > 0)
                                    dest.WriteElementString("result", result);
                                foreach (string[] paramEntry in parameter)
                                {
                                    dest.WriteStartElement("param");
                                    dest.WriteAttributeString("name", paramEntry[0]);
                                    dest.WriteString(paramEntry[1]);
                                    dest.WriteEndElement();
                                }
                            }
                            else
                                dest.WriteString(reader.Value);
                            break;
                        case XmlNodeType.CDATA:
                            dest.WriteCData(reader.Value);
                            break;
                        case XmlNodeType.ProcessingInstruction:
                            dest.WriteProcessingInstruction(reader.Name, reader.Value);
                            break;
                        case XmlNodeType.Comment:
                            dest.WriteComment(reader.Value);
                            break;
                        case XmlNodeType.XmlDeclaration:
                            break;
                        case XmlNodeType.Document:
                            break;
                        case XmlNodeType.DocumentType:
                            dest.WriteString(string.Format("<!DOCTYPE {0} [{1}]", reader.Name, reader.Value));
                            break;
                        case XmlNodeType.EntityReference:
                            dest.WriteEntityRef(reader.Name);
                            break;
                        case XmlNodeType.EndElement:
                            if (reader.Name == "member")
                            {
                                --isMemberTag;
                                if (!gotContentForMember)
                                    dest.WriteElementString("summary", "");
                            }
                            if (isMemberTag == 0)
                                dest.WriteEndElement();
                            break;
                    }
                }
                dest.WriteEndDocument();
            }
            #endregion
        }

        static void ProcessingCsFile(string filename, string backupfile)
        {
            string prefixSrc = "";
            string srcText="";
            using (TextReader reader = new StreamReader(backupfile))
            {
                string line = reader.ReadLine();
                while (line != null)
                {
                    if (line.Contains("namespace"))
                        srcText = line + Environment.NewLine + reader.ReadToEnd();
                    else
                        prefixSrc = prefixSrc + line+Environment.NewLine;
                    line = reader.ReadLine();
                }
            }
            Regex codeWord=new Regex("\\\\c\\s+(?<word>(\\w|\\+|-|\\*|/|\\(|\\))+)");
            Regex re = new Regex("/\\*\\*(?<remark>((?!\\*/)(.|\\n))+)\\*/");
            Match m=re.Match(srcText);
            int startIndex = 0;
            while(m.Success)
            {
                Group remark = m.Groups["remark"];
                startIndex = remark.Index + remark.Length;
                if (!remark.Value.Contains("<summary>")
                    && !remark.Value.Contains("\\name")
                    && !remark.Value.Contains("\\page")
                    && !remark.Value.Contains("\\mainpage")
                    && !remark.Value.Contains("\\section"))
                {
                    string remarkText = srcText.Substring(remark.Index, remark.Length).Trim();

                    #region Replace \e and \c
                    int origRemarkLength = remarkText.Length;
                    remarkText = remarkText.Replace("\\e ", "");

                    Match codeMatch = codeWord.Match(remarkText);
                    while (codeMatch.Success)
                    {
                        remarkText = remarkText.Substring(0, codeMatch.Index)
                            + "<c>" + remarkText.Substring(codeMatch.Index+2, codeMatch.Length-2).Trim() + " </c> "
                            + remarkText.Substring(codeMatch.Index + codeMatch.Length);
                        codeMatch = codeWord.Match(remarkText, codeMatch.Index + codeMatch.Length);
                    }
                    startIndex = remarkText.Length - origRemarkLength;
                    #endregion

                    #region Only first line is summary if \code or \ref.
                    bool endWithSummary = true;
                    if (remarkText.Contains("\\ref")
                        || remarkText.Contains("\\returns")
                        || remarkText.Contains("\\li")
                        || remarkText.Contains("\\image")
                        || remarkText.Contains("\\param")
                        || remarkText.Contains("\\code")
                        || remarkText.Contains("\\verbatim"))
                    {
                        int firstLine = remarkText.IndexOf('\n');
                        if (firstLine > 0)
                        {
                            remarkText = remarkText.Substring(0, firstLine - 1) + "</summary><remarks>" + remarkText.Substring(firstLine - 1);
                            startIndex += 19;
                            endWithSummary = false;
                        }
                    }
                    #endregion

                    srcText = srcText.Substring(0, remark.Index)
                        +" <summary> "
                        +remarkText
                        +(endWithSummary?" </summary> ":" </remarks> ")
                        +srcText.Substring(remark.Index+remark.Length);
                    startIndex += 19;
                }
                m = re.Match(srcText, startIndex);
            }
            using (StreamWriter oStream = new StreamWriter(filename))
            {
                oStream.Write(prefixSrc);
                oStream.Write(srcText);
            }
        }

        static int Main(string[] args)
        {
            Console.WriteLine("Synopsis: DoxygenToNetDoc.exe Xml.Documentation.Assembly.xml|CSharpSource.cs+");
            int retCode = 0;
            try
            {
                List<string> argList = new List<string>();
                foreach (string arg in args)
                {
                    if (arg.Contains("*") || arg.Contains("?"))
                    {
                        string dir = System.IO.Path.GetDirectoryName(arg);
                        if (dir.Length == 0)
                            dir = ".";
                        string filter = System.IO.Path.GetFileName(arg);
                        foreach (string selectedfile in System.IO.Directory.GetFiles(dir, filter))
                            argList.Add(selectedfile);
                    }
                    else
                        argList.Add(arg);
                }
                foreach (string arg in argList)
                {
                    try
                    {
                        Console.WriteLine("Reading file {0}.", arg);
                        string backupfile = arg + ".bak";
                        if (File.Exists(backupfile))
                        {
                            //Console.WriteLine(string.Format("Removing {0}.", backupfile));
                            //File.Delete(backupfile);
                            Console.WriteLine("Backup file {0}.bak already exists. I will skip {0}.", arg);
                            continue;
                        }
                        Console.WriteLine("{0} -> {1}.", arg, backupfile);
                        File.Move(arg, backupfile);
                        Console.WriteLine("Processing {0}.", arg);
                        string suffix = System.IO.Path.GetExtension(arg);
                        if (suffix.ToLower().Equals(".xml"))
                            ProcessingXMLDocumentationFile(arg, backupfile);
                        else if (suffix.ToLower().Equals(".cs"))
                            ProcessingCsFile(arg, backupfile);
                        else
                            Console.WriteLine("Skip file {0} because of unknown suffix {1}.", arg, suffix);
                    }
                    catch (Exception exc)
                    {
                        Console.WriteLine(exc);
                        retCode += 1;
                    }
                }
            }
            catch (Exception exc)
            {
                retCode = 10;
                System.Console.WriteLine(exc.Message);
            }
            return retCode;
        }
    }
}
