﻿//-----------------------------------------------------------------------------
//
// Convert MS XML documentation of doxygen compliant code into a
// XML documentation that works.
//
// Written by Harald Meyer auf'm Hofe
// (C) 2007 by Harald Meyer auf'm Hofe
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: AssemblyInfo.cs,v 1.3 2009/09/20 14:02:45 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// Allgemeine Informationen über eine Assembly werden über die folgenden 
// Attribute gesteuert. Ändern Sie diese Attributwerte, um die Informationen zu ändern,
// die mit einer Assembly verknüpft sind.
[assembly: AssemblyTitle("NormalizeXmlDoc")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("NormalizeXmldoc")]
[assembly: AssemblyCopyright("Copyright © Harald Meyer auf'm Hofe 2007")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: AssemblyVersion("1.1.0.0")]
[assembly: AssemblyFileVersion("1.1.0.0")]
