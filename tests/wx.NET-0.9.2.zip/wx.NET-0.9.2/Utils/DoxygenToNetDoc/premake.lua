-- Premake script for the wx.NET "TowxNET" util.
-- See http://premake.sourceforge.net/ for more info about Premake.

package.name     = "DoxygenToNetDoc"
package.language = "c#"
package.kind     = "exe"
package.target   = "DoxygenToNetDoc"
project.bindir   = "../../Bin"

package.links    = { "System", "System.Xml" }

package.files    = { "AssemblyInfo.cs", "Program.cs" }
