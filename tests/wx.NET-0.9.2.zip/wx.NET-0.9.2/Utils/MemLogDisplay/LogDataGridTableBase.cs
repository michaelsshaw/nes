//-----------------------------------------------------------------------------
// wx.NET - CSVParser.cs
//
// Parser for the MemLogDisplay
//
// (C) 2007 by Dr. Harald Meyer auf'm Hofe
//
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: LogDataGridTableBase.cs,v 1.2 2008/12/25 17:11:54 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;
using System.Collections;
using System.Text;

namespace wx.MemLogDisplay
{
    /** The data model of the table for allocations/deallocations.
     * This simply is a list of object arrays.
     */
    public class LogDataGridTableBase : wx.GridCtrl.GridTableBase, IEnumerable
    {
        #region Static
        /** This imply declares the standard columns and also provides the column names
         */ 
        public static string[] ColNames = {
            "allocation\ncounter",
            "report type",
            "address (hex)",
            "address (dec)",
            "block size",
            "block type",
            "allocation\nindex",
            "filename",
            "line no.",
            "data type",
            "remarks"
        };
        #endregion

        #region State
        //! If rows are filtered, this is the mapping from the visible row index to the total row index.
        IList _mapping = null;
        IList _filterCols = null;
        IList _rows = new ArrayList();
        IDictionary _associatedError = new Hashtable();
        int _colNumber = 11;
        #endregion

        #region CTor
        public LogDataGridTableBase()
        {
        }
        #endregion

        #region Public Properties
        /** This is to read a particular row.
         * This considers \c index to be a total index.
         */
        public object[] this[int index]
        {
            get
            {
                if (index >= this._rows.Count)
                    return null;
                return (object[]) this._rows[index];
            }
        }

        /** This returns the object in a particular cell or \c null if the cell is unknown.
         * This indexer also provides write access to existing rows.
         * All indices are total.
         */
        public object this[int rowindex, int colindex]
        {
            get
            {
                object[] row = this[rowindex];
                if (row == null)
                    return null;
                if (colindex < 0 || colindex >= row.Length)
                    return null;
                else
                    return row[colindex];
            }
            set
            {
                object[] row = this[rowindex];
                if (colindex >= row.Length)
                {
                    object[] newRow = new object[colindex + 1];
                    row.CopyTo(newRow, 0);
                    row = newRow;
                    this._rows[rowindex] = row;
                }
                row[colindex] = value;
            }
        }

        public bool HasFilter { get { return this._mapping != null; } }
        #endregion

        #region Implementing The Table Base
        public override string GetValue(int row, int col)
        {
            if (this._mapping != null)
                row = (int)this._mapping[row];
            object cellObj = this[row, col];
            if (cellObj == null)
                return "";
            else
                return cellObj.ToString();
        }
        public override void SetValue(int row, int col, string val)
        {
            if (this._mapping != null)
                row = (int)this._mapping[row];
            if (col >= 10)
            {
                this[row, col] = val;
            }
            else
            {
                // does nothing because this is not editable
            }
        }
        public override bool IsEmptyCell(int row, int col)
        {
            if (this._mapping != null)
                row = (int)this._mapping[row];
            return this[row, col] == null;
        }
        public override bool AppendCols(int numCols)
        {
            return base.AppendCols(numCols);
        }

        public override bool AppendRows(int numRows)
        {
            return base.AppendRows(numRows);
        }

        public override bool CanHaveAttributes()
        {
            return true;
        }

        public override void Clear()
        {
            this._rows.Clear();
        }

        public override bool DeleteCols(int pos, int numCols)
        {
            return base.DeleteCols(pos, numCols);
        }

        public override bool DeleteRows(int pos, int numRows)
        {
            this._mapping=null;
            this._filterCols=null;
            if (this._associatedError!= null)
                this._associatedError.Clear();
            for(int i=pos+numRows-1; i >= pos; --i)
                this._rows.RemoveAt(i);
            return true;
        }

        wx.GridCtrl.GridCellAttr s_attrForOddRows;
        //! Display attributes of odd rows (currently read only).
        public wx.GridCtrl.GridCellAttr AttrForOddRows
        {
            get
            {
                if (s_attrForOddRows == null)
                {
                    s_attrForOddRows = new wx.GridCtrl.GridCellAttr();
                    s_attrForOddRows.BackgroundColour = new wx.Colour(240, 240, 240);
                }
                return s_attrForOddRows;
            }
        }

        wx.GridCtrl.GridCellAttr s_attrForEvenRows;
        //! Display attributes of even rows (currently read only).
        public wx.GridCtrl.GridCellAttr AttrForEvenRows
        {
            get
            {
                if (s_attrForEvenRows == null)
                {
                    s_attrForEvenRows = new wx.GridCtrl.GridCellAttr();
                }
                return s_attrForEvenRows;
            }
        }
        wx.GridCtrl.GridCellAttr s_attrForEvenRowsWithError;
        //! Display attributes of even rows (currently read only) with an associated error.
        public wx.GridCtrl.GridCellAttr AttrForEvenRowsWithError
        {
            get
            {
                if (s_attrForEvenRowsWithError == null)
                {
                    s_attrForEvenRowsWithError=new wx.GridCtrl.GridCellAttr();
                    s_attrForEvenRowsWithError.BackgroundColour=new wx.Colour(255, 240, 240);
                }
                return s_attrForEvenRowsWithError;
            }
        }
        wx.GridCtrl.GridCellAttr s_attrForOddRowsWithError;
        //! Display attributes of odd rows (currently read only) with an associated error.
        public wx.GridCtrl.GridCellAttr AttrForOddRowsWithError
        {
            get
            {
                if (s_attrForOddRowsWithError == null)
                {
                    s_attrForOddRowsWithError=new wx.GridCtrl.GridCellAttr();
                    s_attrForOddRowsWithError.BackgroundColour = new wx.Colour(240, 200, 200);
                }
                return s_attrForOddRowsWithError;
            }
        }

        public override wx.GridCtrl.GridCellAttr GetAttr(int row, int col, wx.GridCtrl.GridCellAttr.AttrKind kind)
        {
            int totalRow = row;
            if (this._mapping != null)
                totalRow = (int)this._mapping[row];
            wx.GridCtrl.GridCellAttr attr = base.GetAttr(row, col, kind);
            if (this._associatedError.Contains(totalRow))
            {
                if ((row % 2) > 0)
                {
                    attr = AttrForEvenRowsWithError;
                    attr.IncRef();
                }
                else
                {
                    attr = AttrForOddRowsWithError;
                    attr.IncRef();
                }
            }
            else
            {
                if ((row % 2) > 0)
                {
                    if (attr == null)
                    {
                        attr = AttrForOddRows;
                        attr.IncRef();
                    }
                    else if (!attr.HasBackgroundColour)
                    {
                        wx.GridCtrl.GridCellAttr attrNew = (wx.GridCtrl.GridCellAttr)attr.Clone();
                        attr.DecRef();
                        attr = attrNew;
                        attr.BackgroundColour = AttrForOddRows.BackgroundColour;
                    }
                }
            }
			return attr;
		}

        public override string GetColLabelValue(int col)
        {
            if (col >= 0 && col < ColNames.Length)
            {
                if (this._filterCols != null
                    && this._filterCols.IndexOf(col) >= 0)
                {
                    return "*" + ColNames[col].ToUpper();
                }
                else
                {
                    return ColNames[col];
                }
            }
            else
                return "";
        }

        public override int GetNumberCols()
        {
            return this._colNumber;
        }

        public override int GetNumberRows()
        {
            if (this._mapping == null)
                return this._rows.Count;
            else
                return this._mapping.Count;
        }

        public override string GetRowLabelValue(int row)
        {
            if (this._mapping != null)
                row = (int)this._mapping[row];
            return row.ToString();
        }

        public override bool InsertCols(int pos, int numCols)
        {
            return false;
        }

        public override bool InsertRows(int pos, int numRows)
        {
            return false;
        }
        #endregion

        #region Public Methods
        /** This adds a new row to the table base.
         * \param noOfAssociatedError is -1 or the item index of an associated error.
         */
        public void Add(object[] newRow, int noOfAssociatedError)
        {
            if (noOfAssociatedError >= 0)
                this._associatedError[this._rows.Count] = noOfAssociatedError;
            this._rows.Add(newRow);
            if (newRow.Length > this._colNumber)
                this._colNumber = newRow.Length;
        }

        /** Returns the item index of an associated error or -1 if there is none.
         * \c row is the index referring to the visible rows.
         */
        public int GetAssociatedError(int row)
        {
            if (this._mapping != null)
                row = (int)this._mapping[row];
            if (this._associatedError.Contains(row))
                return (int)this._associatedError[row];
            else
                return -1;
        }

        /** Only those rows will remain visible that have the designated value in the specified column.
         */
        public void FilterRows(int col, string value)
        {
            if (this._filterCols == null)
                this._filterCols = new ArrayList();
            this._filterCols.Add(col);
            if (this._mapping == null)
            {
                wx.GridCtrl.GridTableMessage msg = new wx.GridCtrl.GridTableMessage(this, wx.GridCtrl.GridTableRequest.NOTIFY_ROWS_DELETED, 0, this._rows.Count);
                this.GetView().ProcessTableMessage(msg);

                this._mapping = new ArrayList();
                int rowIndex = 0;
                foreach (object[] row in this._rows)
                {
                    if (row.Length > col && row[col].ToString() == value)
                        this._mapping.Add(rowIndex);
                    ++rowIndex;
                }
            }
            else
            {
                wx.GridCtrl.GridTableMessage msg = new wx.GridCtrl.GridTableMessage(this, wx.GridCtrl.GridTableRequest.NOTIFY_ROWS_DELETED, 0, this._mapping.Count);
                this.GetView().ProcessTableMessage(msg);

                IList oldMapping = this._mapping;
                this._mapping = new ArrayList();
                foreach (int rowIndex in oldMapping)
                {
                    object[] row = (object[])this._rows[rowIndex];
                    if (row.Length > col && row[col].ToString() == value)
                        this._mapping.Add(rowIndex);
                }
            }
            {
                wx.GridCtrl.GridTableMessage msg = new wx.GridCtrl.GridTableMessage(this, wx.GridCtrl.GridTableRequest.NOTIFY_ROWS_INSERTED, 0, this._mapping.Count);
                this.GetView().ProcessTableMessage(msg);
            }
        }

        /** This will filter out all those rows that have \c value1 in \c col1 and \c value2 in \c col2 if \c col2 >= 0.
         */
        public void FilterOutRows(int col1, string value1, int col2, string value2)
        {
            if (value1.Length == 0)
                return;
            if (this._filterCols == null)
                this._filterCols = new ArrayList();
            this._filterCols.Add(col1);
            if (col2 >= 0)
                this._filterCols.Add(col2);
            if (this._mapping == null)
            {
                wx.GridCtrl.GridTableMessage msg = new wx.GridCtrl.GridTableMessage(this, wx.GridCtrl.GridTableRequest.NOTIFY_ROWS_DELETED, 0, this._rows.Count);
                this.GetView().ProcessTableMessage(msg);

                this._mapping = new ArrayList();
                int rowIndex = 0;
                foreach (object[] row in this._rows)
                {
                    if (col1 >= row.Length || row[col1].ToString() != value1
                        && (col2 < 0
                            || col2 >= row.Length
                            || row[col2].ToString() != value2))
                    {
                        this._mapping.Add(rowIndex);
                    }
                    ++rowIndex;
                }
            }
            else
            {
                wx.GridCtrl.GridTableMessage msg = new wx.GridCtrl.GridTableMessage(this, wx.GridCtrl.GridTableRequest.NOTIFY_ROWS_DELETED, 0, this._mapping.Count);
                this.GetView().ProcessTableMessage(msg);

                IList oldMapping = this._mapping;
                this._mapping = new ArrayList();
                foreach (int rowIndex in oldMapping)
                {
                    object[] row = (object[])this._rows[rowIndex];
                    if (col1 >= row.Length || row[col1].ToString() != value1
                        && (col2 < 0
                            || col2 >= row.Length
                            || row[col2].ToString() != value2))
                    {
                        this._mapping.Add(rowIndex);
                    }
                }
            }
            {
                wx.GridCtrl.GridTableMessage msg = new wx.GridCtrl.GridTableMessage(this, wx.GridCtrl.GridTableRequest.NOTIFY_ROWS_INSERTED, 0, this._mapping.Count);
                this.GetView().ProcessTableMessage(msg);
            }
        }

        public void RemoveFilter()
        {
            if (this._mapping != null)
            {
                this._filterCols = null;
                wx.GridCtrl.GridTableMessage msg = new wx.GridCtrl.GridTableMessage(this, wx.GridCtrl.GridTableRequest.NOTIFY_ROWS_DELETED, 0, this._mapping.Count);
                this.GetView().ProcessTableMessage(msg);
                this._mapping = null;
                msg = new wx.GridCtrl.GridTableMessage(this, wx.GridCtrl.GridTableRequest.NOTIFY_ROWS_INSERTED, 0, this._rows.Count);
                this.GetView().ProcessTableMessage(msg);
            }
        }

        public void CondenseVisible()
        {
            if (this._mapping != null)
            {
                IList newRows = new ArrayList();
                foreach (int rowIndex in this._mapping)
                {
                    newRows.Add(this._rows[rowIndex]);
                }
                this._rows = newRows;
                this._mapping = null;
                this._filterCols = null;
            }
        }

        public int TotalToVisibleRowIndex(int totalRow)
        {
            if (this._mapping==null)
                return totalRow;
            int visibleIndex=0;
            foreach (int mappedTotalRow in this._mapping)
            {
                if (mappedTotalRow == totalRow)
                    return visibleIndex;
                ++visibleIndex;
            }
            return -1;
        }

        public void Write(System.IO.TextWriter dest)
        {
            foreach (object[] row in this._rows)
            {
                for (int col = 0; col < row.Length; ++col )
                {
                    if (col > 0)
                        dest.Write(",");
                    if (row[col] is long)
                    {
                        long num = (long)row[col];
                        dest.Write(num);
                    }
                    else if (row[col]==null)
                    {
                    }
                    else if (row[col] is string && ((string)row[col]).Length == 0)
                    {
                    }
                    else
                        dest.Write("\"{0}\"", row[col]);
                }
                dest.WriteLine();
            }
        }
        #endregion

        #region IEnumerable Member
        /** This returns an enumerator of rows (which are object arrays)
         */
        public IEnumerator GetEnumerator()
        {
            return this._rows.GetEnumerator();
        }
        #endregion
    }
}
