﻿//-----------------------------------------------------------------------------
// wx.NET - AssemblyInfo.cs
//
// Info for the MemLogDisplay
//
// (C) 2007 by Dr. Harald Meyer auf'm Hofe
//
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: AssemblyInfo.cs,v 1.3 2008/01/25 20:41:21 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// Allgemeine Informationen über eine Assembly werden über die folgenden 
// Attribute gesteuert. Ändern Sie diese Attributwerte, um die Informationen zu ändern,
// die mit einer Assembly verknüpft sind.
[assembly: AssemblyTitle("MemLogDisplay")]
[assembly: AssemblyDescription("Viewing wx-c.dll memory log information")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("wx.NET Team")]
[assembly: AssemblyProduct("MemLogDisplay")]
[assembly: AssemblyCopyright("Copyright ©  2007-2008, Harald Meyer auf'm Hofe")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Durch Festlegen von ComVisible auf "false" werden die Typen in dieser Assembly unsichtbar 
// für COM-Komponenten. Wenn Sie auf einen Typ in dieser Assembly von 
// COM zugreifen müssen, legen Sie das ComVisible-Attribut für diesen Typ auf "true" fest.
[assembly: ComVisible(false)]

// Die folgende GUID bestimmt die ID der Typbibliothek, wenn dieses Projekt für COM verfügbar gemacht wird
[assembly: Guid("c89062ff-f59a-4554-a47b-a990fedd0d87")]

// Versionsinformationen für eine Assembly bestehen aus den folgenden vier Werten:
//
//      Hauptversion
//      Nebenversion 
//      Buildnummer
//      Revision
//
[assembly: AssemblyVersion("0.8.0.1")]
[assembly: AssemblyFileVersion("0.8.0.1")]


/** \mainpage
 *
 * This application reads and displays log files created when adding \c WXNET_LOG_MEM to the
 * list of defined symbols compiling \c wx-c.dll. The application shows a grid displaying the
 * loaded CSV data. Additionally, the application does some testing on consistency of the
 * logged data and reports its findings in an error list (exemplifying the \e wx.NET list
 * control).
 * 
 * Double click on cells will select only those rows of the same value in that columns.
 * Operations of the main menu offer actions for adding additional filters for rows and for
 * removing those filters (menu "view"). However, if you want to preserve those filters, you
 * can choose "condense" from the "edit" menu and save the result into another file. Menu
 * action "condense" will actually remove all filtered out rows and "save" will save the
 * result into another CSV file. 
 * 
*/