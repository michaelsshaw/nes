//-----------------------------------------------------------------------------
// wx.NET - GetWxText.cs: Program to read PO-entries from enumerations, classes,
// and wx widgets.
//
// Wrapper for wxArchiveInputStream and wxArchiveOutputStream.
//
// Written by Harald Meyer auf'm Hofe
// (C) 2010 by Harald Meyer auf'm Hofe
// Licensed under the wxWidgets license, see LICENSE.txt for details.
//
// $Id: GetWxText.cs,v 1.1 2010/06/28 16:21:06 harald_meyer Exp $
//-----------------------------------------------------------------------------

using System;


namespace wx.Globalization
{
    /// <summary>
    /// Program that runs ExtractTranslationsOfTypesAndEnumValues.
    /// </summary>
    class ExtractTranslationsOfTypesAndEnumValuesPrg
    {
        public static int Main(string[] args)
        {
            Console.WriteLine("Program to extract translations of classes and type into GetText POT files.");
            Console.WriteLine("Example: getwxtext.exe Assembly1.dll Assembly2.dll");
            if (args.Length == 0)
            {
                Console.WriteLine("This will create Assembly1.pot and Assembly2.pot containing translations of type names");
                Console.WriteLine(" and enumeration values.");
                return 1;
            }

            System.Diagnostics.Trace.Listeners.Add(new System.Diagnostics.ConsoleTraceListener());
            foreach (string assemblyFileName in args)
            {
                try
                {
                    string assemblyFullFileName = System.IO.Path.GetFullPath(assemblyFileName);
                    System.Reflection.Assembly a = System.Reflection.Assembly.LoadFile(assemblyFullFileName);
                    wx.Globalization.ExtractTranslationsOfTypesAndEnumValues translator=new ExtractTranslationsOfTypesAndEnumValues();
                    translator.ExtractTranslationsOfType(a);
                }
                catch (Exception e)
                {
                    System.Diagnostics.Trace.WriteLine(string.Format("Error processing assembly {0}. Got error {1}.", assemblyFileName, e.Message));
                }
            }
            return 0;
        }
    }
}
