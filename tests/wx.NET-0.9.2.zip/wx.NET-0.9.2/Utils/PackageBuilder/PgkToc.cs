﻿/** Build and installation system for wx.NET.
 * 
 * Application to build a self-extracting package.
 * 
 * \file 
 *
 * Copyright 2009 Harald Meyer auf'm Hofe harald_meyer@users.sourceforge.net
 * 
 * Licensed under the wxWidgets license, see LICENSE.txt for details.
 * 
 * $Id: PgkToc.cs,v 1.1 2009/10/11 17:03:15 harald_meyer Exp $
 */

using System;
using System.Collections.Generic;
using System.Text;

namespace wx.PackageBuilder
{
    /// <summary>
    /// A class template representing a tree where nodes will be associated with data.
    /// the leafs of this tree are associated with implementations of wx.Build.ISingleFileProduct.
    /// </summary>
    public class TreeOfContentFiles<TreeNodeData, LeafNodeData>
        : System.Xml.Serialization.IXmlSerializable
        where TreeNodeData : System.Xml.Serialization.IXmlSerializable
        where LeafNodeData : System.Xml.Serialization.IXmlSerializable, IComparable, Build.ISingleFileProduct
    {
        #region State
        static int _idCounter = 0;
        class LeafNode
        {
            public int _id;
            public TreeNode _parent = null;
            public LeafNodeData _data=default(LeafNodeData);

            public LeafNode()
            {
                _idCounter += 1;
                this._id = _idCounter;
            }
            public LeafNode(int id)
            {
                if (id > _idCounter)
                    _idCounter = id;
                this._id = id;
            }
        }

        /// <summary>
        /// Tree node data.
        /// The data of a tree node may be <c>null</c>.
        /// </summary>
        class TreeNode
        {
            public int _id;
            public TreeNode _parent = null;
            public List<TreeNode> _treeNodeChildren=new List<TreeNode>();
            public List<LeafNode> _leafNodeChildren=new List<LeafNode>();
            public TreeNodeData _data=default(TreeNodeData);

            public TreeNode()
            {
                _idCounter += 1;
                this._id = _idCounter;
            }
            public TreeNode(int id)
            {
                if (id > _idCounter)
                    _idCounter = id;
                this._id = id;
            }
        }
        Dictionary<int, TreeNode> _treeNodes = new Dictionary<int, TreeNode>();
        Dictionary<int, LeafNode> _leafNodes = new Dictionary<int, LeafNode>();
        SortedDictionary<string, List<int>> _localFilenames = new SortedDictionary<string, List<int>>();
        #endregion

        #region CTor
        public TreeOfContentFiles(TreeNodeData rootData)
        {
            TreeNode root = new TreeNode(0);
            root._data=rootData;
            this._treeNodes[0] = root;
        }
        #endregion

        #region Public Properties
        /// <summary>
        /// Adds a node to the tree.
        /// </summary>
        /// <param name="parentID">ID of the parent. Use 0 to add a node directly to the root.</param>
        /// <param name="nodeData">Data that will be associated with the node. This may be <c>null</c> here.</param>
        /// <returns>The ID of the new node.</returns>
        /// <seealso cref="AddLeafNode"/>
        public int AddNode(int parentID, TreeNodeData nodeData)
        {
            TreeNode newNode=new TreeNode();
            newNode._data=nodeData;
            TreeNode parent = this._treeNodes[parentID];
            parent._treeNodeChildren.Add(newNode);
            newNode._parent = parent;
            this._treeNodes[newNode._id] = newNode;
            return newNode._id;
        }

        /// <summary>
        /// Clears up this instance.
        /// All nodes will be removed. This will create a new root node bearing the provided data.
        /// </summary>
        /// <param name="rootNodeData">The data of the new root node. This may be <c>null</c>.</param>
        public void Clear(TreeNodeData rootNodeData)
        {
            this._leafNodes.Clear();
            this._treeNodes.Clear();
            this._localFilenames.Clear();
            this._treeNodes[0] = new TreeNode(0);
            this._treeNodes[0]._data = rootNodeData;
        }

        /// <summary>
        /// The number of contained leaf nodes.
        /// </summary>
        public int CountLeafNodes
        {
            get
            {
                return this._leafNodes.Count;
            }
        }

        /// <summary>
        /// The number of all nodes.
        /// </summary>
        public int Count
        {
            get
            {
                return this._leafNodes.Count + this._treeNodes.Count;
            }
        }

        /// <summary>
        /// Returns a collection containing all keys of leaf nodes.
        /// </summary>
        public ICollection<int> LeafNodes
        {
            get
            {
                return this._leafNodes.Keys;
            }
        }

        /// <summary>
        /// This is a collection of all IDs of non-leaf nodes.
        /// </summary>
        public ICollection<int> TreeNodes
        {
            get
            {
                return this._treeNodes.Keys;
            }
        }

        /// <summary>
        /// A sorted collection of all local filenames associated with leaf nodes.
        /// </summary>
        public ICollection<string> LeafNodeDataRecords
        {
            get
            {
                return this._localFilenames.Keys;
            }
        }

        /// <summary>
        /// True iff this contains the provided data.
        /// </summary>
        /// <param name="data">The data that will be tested.</param>
        /// <returns>True iff the argument is already associated with at least one leaf node.</returns>
        public bool Contains(string data)
        {
            return this._localFilenames.ContainsKey(data);
        }

        /// <summary>
        /// True iff the argument designates a leaf node.
        /// </summary>
        /// <param name="nodeID">The node ID that will be tested.</param>
        public bool ContainsLeafNode(int nodeID)
        {
            return this._leafNodes.ContainsKey(nodeID);
        }

        /// <summary>
        /// True iff the argument designates a non-leaf node.
        /// </summary>
        /// <param name="nodeID">The node ID that will be tested.</param>
        public bool ContainsTreeNode(int nodeID)
        {
            return this._treeNodes.ContainsKey(nodeID);
        }

        /// <summary>
        /// The ID of the parent of teh designated node or -1 if this does not exist.
        /// </summary>
        /// <param name="nodeID">ID of the node.</param>
        /// <returns>The ID of the parent or -1 if the argument does not exist or is root.</returns>
        public int GetParent(int nodeID)
        {
            if (this._leafNodes.ContainsKey(nodeID))
                return this._leafNodes[nodeID]._parent._id;
            else if (this._treeNodes.ContainsKey(nodeID))
            {
                TreeNode n = this._treeNodes[nodeID];
                if (n._parent == null)
                    return -1;
                else
                    return n._parent._id;
            }
            else
                return -1;
        }

        /// <summary>
        /// If the argument designates a tree node with non-leafs as children, this will return a collection
        /// of the IDs of these children. Otherwise, the result is empty.
        /// </summary>
        /// <param name="nodeID">The ID of a non-leave tree node.</param>
        /// <returns></returns>
        public ICollection<int> GetTreeNodeChildren(int nodeID)
        {
            if (this.ContainsTreeNode(nodeID))
            {
                TreeNode n = this._treeNodes[nodeID];
                List<int> result = new List<int>();
                foreach (TreeNode nn in n._treeNodeChildren)
                    result.Add(nn._id);
                return result;
            }
            else
                return new int[] {};
        }

        /// <summary>
        /// If the argument designates a tree node with leafs as children, this will return a collection
        /// of the IDs of these children. Otherwise, the result is empty.
        /// </summary>
        /// <param name="nodeID">The ID of a non-leave tree node.</param>
        /// <returns></returns>
        public ICollection<int> GetLeafNodeChildren(int nodeID)
        {
            if (this.ContainsTreeNode(nodeID))
            {
                TreeNode n = this._treeNodes[nodeID];
                List<int> result = new List<int>();
                foreach (LeafNode nn in n._leafNodeChildren)
                    result.Add(nn._id);
                return result;
            }
            else
                return new int[] { };
        }

        /// <summary>
        /// Gets the data associated with the designated node.
        /// </summary>
        /// <param name="nodeID">ID of a tree node.</param>
        /// <returns>The data or <c>default(TreeNodeData)</c> if the data does not exist or the node is unknown.</returns>
        public TreeNodeData GetTreeNodeData(int nodeID)
        {
            if (this._treeNodes.ContainsKey(nodeID))
            {
                return this._treeNodes[nodeID]._data;
            }
            else
                return default(TreeNodeData);
        }

        /// <summary>
        /// Gets the data associated with the designated leaf node.
        /// </summary>
        /// <param name="nodeID">ID of a tree node.</param>
        /// <returns>The data or <c>default(TreeNodeData)</c> if the data does not exist or the node is unknown.</returns>
        public LeafNodeData GetLeafNodeData(int nodeID)
        {
            if (this._leafNodes.ContainsKey(nodeID))
            {
                return this._leafNodes[nodeID]._data;
            }
            else
                return default(LeafNodeData);
        }

        /// <summary>
        /// Adds a new leaf node to the node designated by the provided parent ID.
        /// </summary>
        /// <param name="parentID">ID of the parent. Use 0 to add a node directly to the root.</param>
        /// <param name="nodeData">Data that will be associated with the node. This shall not be <c>null</c>.</param>
        /// <returns>The ID of the new node.</returns>
        /// <seealso cref="AddNode"/>
        public int AddLeafNode(int parentID, LeafNodeData nodeData)
        {
            LeafNode newNode = new LeafNode();
            newNode._data = nodeData;
            TreeNode parent = this._treeNodes[parentID];
            parent._leafNodeChildren.Add(newNode);
            newNode._parent = parent;
            this._leafNodes[newNode._id] = newNode;
            if (!this._localFilenames.ContainsKey(nodeData.File.FileName))
                this._localFilenames.Add(nodeData.File.FileName, new List<int>());
            this._localFilenames[nodeData.File.FileName].Add(newNode._id);
            return newNode._id;
        }
        #endregion

        public override string ToString()
        {
            System.Text.StringBuilder sb = new StringBuilder();
            this.SubtreeToString(sb, 0, 0);
            return sb.ToString();
        }

        void SubtreeToString(StringBuilder sb, int id, int depth)
        {
            sb.Append("|");
            if (depth > 0)
                sb.Append(new string('-', depth));

            if (this._leafNodes.ContainsKey(id))
            {
                LeafNode n = this._leafNodes[id];
                sb.Append(n._id);
                sb.Append(": ");
                if (n._data != null)
                    sb.Append(n._data);
                sb.AppendLine();
            }
            else
            {
                TreeNode n = this._treeNodes[id];
                sb.Append(n._id);
                sb.Append(": ");
                if (n._data != null)
                    sb.Append(n._data);
                sb.AppendLine();
                foreach (TreeNode nn in n._treeNodeChildren)
                {
                    this.SubtreeToString(sb, nn._id, depth + 1); 
                }
                foreach (LeafNode nn in n._leafNodeChildren)
                {
                    this.SubtreeToString(sb, nn._id, depth + 1);
                }
            }
        }

        /// <summary>
        /// Clears all content.
        /// </summary>
        public void Clear()
        {
            this._leafNodes.Clear();
            this._localFilenames.Clear();
            this._treeNodes.Clear();
        }

        #region IXmlSerializable Member
        /// <summary>
        /// Returns <c>null</c> as suggested by the framework documentation.
        /// </summary>
        /// <returns>null</returns>
        public System.Xml.Schema.XmlSchema GetSchema()
        {
            return null;
        }

        /// <summary>
        /// Read the data of this instance from a Xml stream.
        /// </summary>
        /// <param name="reader">The data source</param>
        /// <exception cref="FormatException">Raised on unexpected structure of teh Xml code.</exception>
        /// <seealso cref="WriteXml"/>
        public void ReadXml(System.Xml.XmlReader reader)
        {
            this._leafNodes.Clear();
            this._treeNodes.Clear();
            if (!reader.IsStartElement("tree"))
                throw new FormatException("Expecting a <tree/>.");
            if (reader.GetAttribute("node_data") != typeof(TreeNodeData).Namespace + "." + typeof(TreeNodeData).Name)
                throw new FormatException("Unexpected type of node data.");
            if (reader.GetAttribute("leaf_data") != typeof(LeafNodeData).Namespace + "." + typeof(LeafNodeData).Name)
                throw new FormatException("Unexpected type of leaf node data.");
            reader.Read();
            while (reader.IsStartElement())
            {
                string elementName = reader.Name;
                int id = Convert.ToInt32(reader.GetAttribute("id"));
                TreeNode parent = null;
                string parentIdAttr = reader.GetAttribute("parent");
                if (parentIdAttr != null)
                {
                    int parentID = Convert.ToInt32(parentIdAttr);
                    parent = this._treeNodes[parentID];
                }
                bool emptyElement=reader.IsEmptyElement;
                reader.Read();
                if (elementName == "node")
                {
                    TreeNode newNode = new TreeNode(id);
                    if (!emptyElement)
                    {
                        TreeNodeData newNodeData = Activator.CreateInstance<TreeNodeData>();
                        newNodeData.ReadXml(reader);
                        newNode._data = newNodeData;
                    }
                    if (parent != null)
                    {
                        newNode._parent = parent;
                        parent._treeNodeChildren.Add(newNode);
                    }
                    this._treeNodes[newNode._id] = newNode;
                }
                else if (elementName == "leaf")
                {
                    LeafNodeData newNodeData = Activator.CreateInstance<LeafNodeData>();
                    newNodeData.ReadXml(reader);
                    LeafNode newNode = new LeafNode(id);
                    if (!emptyElement)
                    {
                        newNode._data = newNodeData;
                    }
                    newNode._parent = parent;
                    parent._leafNodeChildren.Add(newNode);
                    this._leafNodes[newNode._id] = newNode;
                }
                if (!emptyElement)
                    reader.ReadEndElement();
            }
            reader.ReadEndElement();
        }

        /// <summary>
        /// Write the content to the provided XML destination.
        /// </summary>
        /// <param name="writer">The destination of the output</param>
        /// <seealso cref="ReadXml"/>
        public void WriteXml(System.Xml.XmlWriter writer)
        {
            writer.WriteStartElement("tree");
            writer.WriteAttributeString("node_data", typeof(TreeNodeData).Namespace + "." + typeof(TreeNodeData).Name);
            writer.WriteAttributeString("leaf_data", typeof(LeafNodeData).Namespace + "." + typeof(LeafNodeData).Name);
            foreach (TreeNode n in this._treeNodes.Values)
            {
                writer.WriteStartElement("node");
                writer.WriteAttributeString("id", n._id.ToString());
                if (n._parent != null) // this may be the root.
                    writer.WriteAttributeString("parent", n._parent._id.ToString());
                if (n._data != null)
                    n._data.WriteXml(writer);
                writer.WriteEndElement();
            }
            foreach (LeafNode n in this._leafNodes.Values)
            {
                writer.WriteStartElement("leaf");
                writer.WriteAttributeString("id", n._id.ToString());
                writer.WriteAttributeString("parent", n._parent._id.ToString());
                n._data.WriteXml(writer);
                writer.WriteEndElement();
            }
        }

        #endregion
    }

    /// <summary> Lists the content of a package.
    /// Instances of this class serve as a data model for package builder
    /// and the component that will decompress the contained files and projects.
    /// </summary>
    public class TableOfContents : System.Xml.Serialization.IXmlSerializable
    {
        #region State
        /// <summary>
        /// A collection of source files that provide data to be included into the package.
        /// </summary>
        public TreeOfContentFiles<Build.ContentFile, Build.ContentFile> SrcFiles = new TreeOfContentFiles<Build.ContentFile, Build.ContentFile>(null);
        #endregion

        #region CTor
        /// <summary>
        /// Creates an empty instance.
        /// </summary>
        public TableOfContents()
        {
        }
        #endregion

        #region IXmlSerializable Member
        /// <summary>
        /// Simply returns <c>null</c> as suggested by the framework documentation.
        /// </summary>
        /// <returns></returns>
        public System.Xml.Schema.XmlSchema GetSchema()
        {
            return null;
        }

        public void ReadXml(System.Xml.XmlReader reader)
        {
            reader.ReadStartElement("package_toc");
            reader.ReadStartElement("sources");
            this.SrcFiles.Clear(null);
            this.SrcFiles.ReadXml(reader);
            reader.ReadEndElement();
            reader.ReadEndElement();
        }

        public void WriteXml(System.Xml.XmlWriter writer)
        {
            writer.WriteStartElement("package_toc");
            writer.WriteStartElement("sources");
            this.SrcFiles.WriteXml(writer);
            writer.WriteEndElement();
            writer.WriteEndElement();
        }

        #endregion

        public override string ToString()
        {
            return string.Format("TOC(\nsrc:\n{0})", this.SrcFiles);
        }

        /// <summary>
        /// Clears all data.
        /// </summary>
        public void Clear()
        {
            this.SrcFiles.Clear();
        }
    }
}
