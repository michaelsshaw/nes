/** Build and installation system for wx.NET.
 * 
 * Application to build a self-extracting package.
 * 
 * \file 
 *
 * Copyright 2009, 2010 Harald Meyer auf'm Hofe harald_meyer@users.sourceforge.net
 * 
 * Licensed under the wxWidgets license, see LICENSE.txt for details.
 * 
 * $Id: PkgFrame.cs,v 1.11 2010/06/28 16:22:22 harald_meyer Exp $
 */

using System;
using System.Collections.Generic;
using System.Text;

namespace wx.PackageBuilder
{
    /// <summary>
    /// Drop target for the source tree.
    /// This enables the user to drop files into the source tree.
    /// </summary>
    class SrcTreeDropTarget : FileDropTarget
    {
        PkgFrame _pkgApp;

        public SrcTreeDropTarget(PkgFrame appframe)
        {
            this._pkgApp = appframe;
        }

        public override bool OnDropFiles(int x, int y, string[] filenames)
        {
            this._pkgApp.LoadSrcFiles(filenames);
            return true;
        }
    }

    /// <summary>
    /// Drops 
    /// </summary>
    class TocTreeDropTarget : TextDropTarget
    {
        PkgFrame _appFrame;
        public TocTreeDropTarget(PkgFrame appFrame)
        {
            this._appFrame = appFrame;
        }

        public override bool OnDropText(int x, int y, string text)
        {
            TreeCtrl.HitTestFlags hitTest = TreeCtrl.HitTestFlags.NONE;
            TreeItemId nodeHit = this._appFrame._tocTree.HitTest(new System.Drawing.Point(x, y), out hitTest);
            if ((hitTest & TreeCtrl.HitTestFlags.ONITEM) != TreeCtrl.HitTestFlags.NONE)
            {
                if (nodeHit == this._appFrame._tocTree.RootItem)
                    return false;

                string filename = System.IO.Path.GetFileName(text);
                TreeItemId srcNode = this._appFrame._srcTree.FindFirstWithLabel(filename, TreeCtrl.LabelMatch.Exact);
                if (srcNode != null)
                {
                    this._appFrame._tocTree.Selection = nodeHit;
                    this._appFrame.AddSrcFileToPkg(srcNode);
                    return true;
                }
            }
            return false;
        }
    }

    /// <summary>
    /// This frame will be displayed on executing build processes. This frame prints out
    /// log messages and enables the user to stop the build process. Users may either use
    /// CTRL+C to stop the process or press the "stop" button.
    /// </summary>
    /// <remarks>
    /// 
    /// This frame offers an additional
    /// method <c>KillIfRequested</c> that will test for requests to abort the current process. If
    /// the panel encountered such a demand, <c>KillIfRequested</c> will kill the current process.
    /// 
    /// Users may request the abortion of the current process either using a button or typing CTRL-C.
    /// 
    /// This dialog is a singleton.
    /// </remarks>
    public class PkgBuildExecDialog : Dialog
    {
        #region Enumerations
        enum IDs
        {
            RequestAbortion=10000,
        }

        /// <summary>
        /// Enumeration of modes. Organized as Bit-Vektor of two states:
        /// One 
        /// </summary>
        [Flags]
        enum Mode
        {
            /// <summary>
            /// The panel is inactive.
            /// </summary>
            Inactive = 0,

            /// <summary>
            /// User requested to kill a process.
            /// </summary>
            KillProcess = 0x01,

            /// <summary>
            /// This bit is active iff this is waiting for the end of a process
            /// after a call to wx.Build.BuildConfig.WaitForExit().
            /// </summary>
            WaitingForProcess = 0x10,
        }
        #endregion

        #region State
        Mode _mode = Mode.Inactive;
        ImageList _globberImages = new ImageList(32, 32);
        Bitmap _globberInactive = null;
        int _globberIndex = -1;
        StaticBitmap _bitmapLabel = null;
        Button _startStopButton = null;
        CheckBox _checkPasteLogIntoInfoWindow = null;
        TextCtrl _logWindow = null;
        TreeCtrl _actionTree = null;

        Build.BuildProject _project = null;
        bool _rebuild = false;

        bool _isRunning = false;
        #endregion

        enum ItemImageIndex
        {
            Unchecked,
            Checked,
            FolderOpenUnchecked,
            FolderOpenChecked,
            FolderClosedUnchecked,
            FolderClosedChecked
        }

        #region CTor / Singleton
        /// <summary>
        /// Creates an instance that will be disabled.
        /// </summary>
        /// <param name="parent"></param>
        /// <param name="id"></param>
        PkgBuildExecDialog(PkgFrame parent, int id)
            : base(parent, id, _("wx.NET Build Process"), wxDefaultPosition, wxDefaultSize, WindowStyles.FRAME_FLOAT_ON_PARENT | WindowStyles.FRAME_DEFAULT_STYLE | WindowStyles.FRAME_TOOL_WINDOW)
        {
            ImageList actionTreeImages = new ImageList(16, 16);
            actionTreeImages.Add(new Bitmap(new Bitmap("PkgBuilder.zrs", "unchecked.png").ConvertToImage().Rescale(16, 16)));
            actionTreeImages.Add(new Bitmap(new Bitmap("PkgBuilder.zrs", "checked.png").ConvertToImage().Rescale(16, 16)));
            actionTreeImages.Add(new Bitmap(new Bitmap("PkgBuilder.zrs", "folder_open_unckecked.png").ConvertToImage().Rescale(16, 16)));
            actionTreeImages.Add(new Bitmap(new Bitmap("PkgBuilder.zrs", "folder_open_ckecked.png").ConvertToImage().Rescale(16, 16)));
            actionTreeImages.Add(new Bitmap(new Bitmap("PkgBuilder.zrs", "folder_closed_unckecked.png").ConvertToImage().Rescale(16, 16)));
            actionTreeImages.Add(new Bitmap(new Bitmap("PkgBuilder.zrs", "folder_closed_ckecked.png").ConvertToImage().Rescale(16, 16)));

            this._globberImages.Add(new Bitmap("PkgBuilder.zrs", "globber0.png"));
            this._globberImages.Add(new Bitmap("PkgBuilder.zrs", "globber1.png"));
            this._globberImages.Add(new Bitmap("PkgBuilder.zrs", "globber2.png"));
            this._globberImages.Add(new Bitmap("PkgBuilder.zrs", "globber3.png"));
            this._globberImages.Add(new Bitmap("PkgBuilder.zrs", "globber4.png"));
            this._globberImages.Add(new Bitmap("PkgBuilder.zrs", "globber5.png"));
            this._globberImages.Add(new Bitmap("PkgBuilder.zrs", "globber6.png"));
            this._globberImages.Add(new Bitmap("PkgBuilder.zrs", "globber7.png"));

            this._globberInactive = new Bitmap("PkgBuilder.zrs", "globberinactive.png");

            this.AutoLayout = true;

            this._actionTree = new TreeCtrl(this, -1, wxDefaultPosition, new System.Drawing.Size(400, 100), WindowStyles.TR_HIDE_ROOT | WindowStyles.TR_LINES_AT_ROOT);
            this._actionTree.ImageList = actionTreeImages;
            {
                this._actionTree.AddRoot("Tools");
                Dictionary<string, TreeItemId> knownToolFamilies=new Dictionary<string,TreeItemId>();
                Dictionary<TreeItemId, string> toolTips = new Dictionary<TreeItemId, string>();
                Config.Get().Path = "/Tools";
                foreach (Build.IBuildActionProvider action in Build.BuildConfig.AllActionProviders)
                {
                    string toolFamily = action.ToolFamily;
                    string name = action.Name;

                    bool toolEnabled=Config.Get().Read(action.Name, true);

                    if (knownToolFamilies.ContainsKey(toolFamily))
                    {
                        TreeItemId family = knownToolFamilies[toolFamily];
                        TreeItemId newNode = this._actionTree.AppendItem(family, name, toolEnabled?1:0);
                        this._actionTree.SetItemData(newNode, new TreeItemData(action.Description));

                        toolTips[family] += "\n\n" + action.Name + ":\n"+action.Description;
                    }
                    else
                    {
                        bool toolFamilyEnabled = Config.Get().Read(toolFamily, true);
                        TreeItemId toolFamilyId = this._actionTree.AppendItem(this._actionTree.RootItem, toolFamily, toolFamilyEnabled?5:4);
                        knownToolFamilies.Add(toolFamily, toolFamilyId);
                        TreeItemId newNode = this._actionTree.AppendItem(toolFamilyId, name, toolEnabled ? 1 : 0);
                        this._actionTree.SetItemData(newNode, new TreeItemData(action.Description));
                        toolTips[toolFamilyId] = action.Name + ":\n" + action.Description;
                    }
                }
                foreach (KeyValuePair<TreeItemId, string> toolTipPairs in toolTips)
                {
                    this._actionTree.SetItemData(toolTipPairs.Key, new TreeItemData(toolTipPairs.Value));
                }
            }

            Panel buttonPanel = new Panel(this);
            buttonPanel.AutoLayout = true;
            wx.BoxSizer buttonSizer = new StaticBoxSizer(wx.Orientation.wxHORIZONTAL, buttonPanel);
            this._bitmapLabel = new StaticBitmap(buttonPanel, this._globberInactive, wxDefaultPosition, new System.Drawing.Size(32, 32));
            buttonSizer.Add(5, 32);
            buttonSizer.Add(this._bitmapLabel, 0, SizerFlag.wxNo_FLAG, 5);
            buttonSizer.Add(10, 32);
            this._startStopButton = new Button(buttonPanel, _("Start execution!"));
            buttonSizer.Add(this._startStopButton, 0, SizerFlag.wxALIGN_CENTRE, 5);
            buttonSizer.Add(1, 1, 1, SizerFlag.wxNo_FLAG, 5);
            this._checkPasteLogIntoInfoWindow = new CheckBox(buttonPanel, _("Copy log to main frame."));
            buttonSizer.Add(this._checkPasteLogIntoInfoWindow, 0, SizerFlag.wxALIGN_CENTRE, 5);
            buttonPanel.Sizer = buttonSizer;
            buttonPanel.Fit();

            this._logWindow = new TextCtrl(this, -1, "", wxDefaultPosition, new System.Drawing.Size(400, 220),
                                            WindowStyles.TE_AUTO_SCROLL
                                            | WindowStyles.TE_READONLY
                                            | WindowStyles.TE_MULTILINE
                                            | WindowStyles.TE_LINEWRAP);
            this._logWindow.BackgroundColour = new Colour("#ff9d9b");

            wx.BoxSizer topSizer = new BoxSizer(Orientation.wxVERTICAL);
            topSizer.Add(this._actionTree, 0, SizerFlag.wxEXPAND);
            topSizer.Add(buttonPanel, 0, SizerFlag.wxEXPAND);
            topSizer.Add(this._logWindow, 1, SizerFlag.wxEXPAND);

            this.Sizer = topSizer;
            this.Fit();
            this.CenterOnParent();
            wx.Config appconfig=wx.Config.Get();
            appconfig.Path = "ExeBuild";
            this._checkPasteLogIntoInfoWindow.Value = appconfig.Read("CopyLog", true);

            this._startStopButton.EVT_BUTTON(-1, new EventListener(this.OnStartStopButton));
            this.EVT_KEY_DOWN(new EventListener(this.OnStartStopButton));
            this.EVT_TREE_ITEM_ACTIVATED(-1, new EventListener(this.OnActivatedTreeNode));
            this.EVT_TREE_SEL_CHANGED(-1, new EventListener(this.OnSelectInActionTree));

            wx.ProcessUtils.ProcessStarter.EvtStartedShellProcess += new wx.ProcessUtils.ProcessStarter.HandlerProcessRefersToShellProcess(this.OnStartingShellProcess);
            wx.ProcessUtils.ProcessStarter.EvtRunningShellProcess += new wx.ProcessUtils.ProcessStarter.HandlerProcessRefersToShellProcess(this.OnRunningShellProcess);
            wx.ProcessUtils.ProcessStarter.EvtFinishedShellProcess += new wx.ProcessUtils.ProcessStarter.HandlerProcessRefersToShellProcess(this.OnFinishedShellProcess);
        }

        #region Tool Tree
        bool CheckOrUncheck(TreeItemId id)
        {
            bool nowChecked = false;
            ItemImageIndex itemImage = (ItemImageIndex)this._actionTree.GetItemImage(id);
            switch (itemImage)
            {
                case ItemImageIndex.Checked: itemImage = ItemImageIndex.Unchecked; nowChecked=false; break;
                case ItemImageIndex.Unchecked: itemImage = ItemImageIndex.Checked; nowChecked=true; break;
                case ItemImageIndex.FolderClosedChecked: itemImage = ItemImageIndex.FolderClosedUnchecked; nowChecked=false; break;
                case ItemImageIndex.FolderClosedUnchecked: itemImage = ItemImageIndex.FolderClosedChecked; nowChecked=true; break;
                case ItemImageIndex.FolderOpenChecked: itemImage = ItemImageIndex.FolderOpenUnchecked; nowChecked=false; break;
                case ItemImageIndex.FolderOpenUnchecked: itemImage = ItemImageIndex.FolderOpenChecked; nowChecked=true; break;
            }
            this._actionTree.SetItemImage(id, (int)itemImage);

            string nodeName = this._actionTree.GetItemText(id);
            string nodeDescription = this._actionTree.GetItemData(id).Data as string;
            if (nowChecked)
                this._logWindow.AppendFormat(_("Enabled action {0}: {1}\n"), nodeName, nodeDescription);
            else if (!this._actionTree.HasChildren(id))
                this._logWindow.AppendFormat(_("Disable action in {0}: {1}\n"), nodeName, nodeDescription);
            Config.Get().Path = "/Tools";
            Config.Get().Write(nodeName, nowChecked);
            Config.Get().Flush();
            return nowChecked;
        }

        bool CheckOrUncheck(TreeItemId id, bool check)
        {
            bool nowChecked = false;
            ItemImageIndex itemImage = (ItemImageIndex)this._actionTree.GetItemImage(id);
            if (check)
            {
                switch (itemImage)
                {
                    case ItemImageIndex.Unchecked: itemImage = ItemImageIndex.Checked; nowChecked = true; break;
                    case ItemImageIndex.FolderClosedUnchecked: itemImage = ItemImageIndex.FolderClosedChecked; nowChecked = true; break;
                    case ItemImageIndex.FolderOpenUnchecked: itemImage = ItemImageIndex.FolderOpenChecked; nowChecked = true; break;
                }
            }
            else
            {
                switch (itemImage)
                {
                    case ItemImageIndex.Checked: itemImage = ItemImageIndex.Unchecked; nowChecked = false; break;
                    case ItemImageIndex.FolderClosedChecked: itemImage = ItemImageIndex.FolderClosedUnchecked; nowChecked = false; break;
                    case ItemImageIndex.FolderOpenChecked: itemImage = ItemImageIndex.FolderOpenUnchecked; nowChecked = false; break;
                }
            }
            this._actionTree.SetItemImage(id, (int)itemImage);

            string nodeName=this._actionTree.GetItemText(id);
            string nodeDescription=this._actionTree.GetItemData(id).Data as string;
            if (nowChecked)
                this._logWindow.AppendFormat(_("Enabled action {0}: {1}\n"), nodeName, nodeDescription);
            else if (!this._actionTree.HasChildren(id))
                this._logWindow.AppendFormat(_("disabled action {0}: {1}\n"), nodeName, nodeDescription);
            Config.Get().Path = "/Tools";
            Config.Get().Write(nodeName, nowChecked);
            Config.Get().Flush();
            return nowChecked;
        }

        void OnActivatedTreeNode(object sender, Event evt)
        {
            TreeEvent tevt = evt as TreeEvent;
            if (tevt != null)
            {
                if (this._actionTree.IsExpanded(tevt.Item) || !this._actionTree.HasChildren(tevt.Item))
                {
                    bool checkedItem=this.CheckOrUncheck(tevt.Item);
                    if (this._actionTree.HasChildren(tevt.Item))
                    {
                        foreach (TreeItemId child in this._actionTree.GetChildren(tevt.Item))
                        {
                            if (checkedItem)
                            {
                                if (this._actionTree.GetItemImage(child) == (int)ItemImageIndex.Unchecked)
                                    this._actionTree.SetItemImage(child, (int)ItemImageIndex.Checked);
                            }
                            else
                            {
                                if (this._actionTree.GetItemImage(child) == (int)ItemImageIndex.Checked)
                                    this._actionTree.SetItemImage(child, (int)ItemImageIndex.Unchecked);
                            }
                            Config.Get().Path = "/Tools";
                            Config.Get().Write(this._actionTree.GetItemText(child), checkedItem);
                            Config.Get().Flush();
                        }
                    }
                    else /* no children */
                    {
                        TreeItemId parent = this._actionTree.GetItemParent(tevt.Item);
                        bool updateGroup = parent != this._actionTree.RootItem;
                        if (updateGroup && checkedItem)
                        {
                            // additional condition to check the root: all children have to be checked.
                            foreach (TreeItemId child in this._actionTree.GetChildren(parent))
                            {
                                int childImage = this._actionTree.GetItemImage(child);
                                if (childImage == (int)ItemImageIndex.Unchecked)
                                {
                                    updateGroup = false;
                                    break;
                                }
                            }
                        }
                        if (updateGroup)
                        {
                            this.CheckOrUncheck(parent, checkedItem);
                        }
                    }
                }
                else
                    this._actionTree.Expand(tevt.Item);
            }
        }

        string _currentTooltip = null;
        void OnSelectInActionTree(object sender, Event evt)
        {
            TreeEvent tevt = evt as TreeEvent;
            if (tevt != null)
            {
                TreeItemData data = this._actionTree.GetItemData(tevt.Item);
                if (data != null && data.Data is string)
                {
                    string description = (string)data.Data;
                    if (this._currentTooltip == null || this._currentTooltip != description)
                    {
                        this._currentTooltip = description;
                        this._actionTree.ToolTip = description;
                    }
                }
                else
                    this._actionTree.ToolTip=null;
            }
        }
        #endregion

        static PkgBuildExecDialog _singleton = null; 
        /// <summary>
        /// This dialog is a singleton. Use this method to get the instance and create one if necessary.
        /// </summary>
        /// <param name="parent">Will be passed to the CTor of the new instance if this creates a new instance.</param>
        /// <returns>The singleton instance.</returns>
        public static PkgBuildExecDialog GetAndCreateIfNessecary(PkgFrame parent, Build.BuildProject p, bool rebuild)
        {
            if (_singleton == null)
                _singleton = new PkgBuildExecDialog(parent, -1);
            _singleton._project = p;
            _singleton._rebuild = rebuild;
            _singleton.ReturnCode = ShowModalResult.CANCEL;
            _singleton._actionTree.Enabled = true;
            _singleton._startStopButton.Label = _("Start execution!");
            _singleton._logWindow.Clear();
            return _singleton;
        }
        #endregion

        /// <summary>
        /// Builds the provided project using the settings of this application.
        /// Messages of the build process will be pasted into the log window.
        /// </summary>
        /// <param name="p">The project to be made</param>
        /// <param name="rebuild">Indicates with true that the project shall be rebuilt.</param>
        void RunBuild()
        {
            if (this._rebuild)
                this._logWindow.AppendFormat("Rebuild project {0}.\n", this._project.Name);
            else
                this._logWindow.AppendFormat("Build project {0}.\n", this._project.Name);

            this._isRunning = true;

            bool success = false;
            Build.ErrorHandler handler = delegate(Build.ErrorObject errObj)
            {
                if (!this._logWindow.IsNULL)
                    lock (Object.DllSync)
                    {
                        this._logWindow.AppendText(errObj.ToString() + "\n");
                    }
                wx.App.TheApp.SafeYield(this);
                /*
                if (this._mode == Mode.KillProcess)
                {
                    throw new Exception(_("I am going to stop the build process due to user request."));
                }
                 * */
            };
            if (this._rebuild)
                Build.BuildConfig.GetConfig().Mode = Build.BuildMode.BuildNew;
            try
            {
                this._startStopButton.Enabled = true;
                this.SetFocus();
                this._mode = Mode.Inactive;
                this._globberIndex = 0;
                this._bitmapLabel.Bitmap = this._globberImages.GetBitmap(this._globberIndex);

                #region Read Disabled Tools
                List<string> options = new List<string>();
                options.Add("/prefer:" + this._project.Name);
                foreach (TreeItemId actionTreeNode in this._actionTree.GetAllItems())
                {
                    if (!this._actionTree.HasChildren(actionTreeNode))
                    {
                        if (this._actionTree.GetItemImage(actionTreeNode) == (int)ItemImageIndex.Unchecked)
                            options.Add("/disable:" + this._actionTree.GetItemText(actionTreeNode));
                    }
                }
                #endregion
                try
                {
                    success = wx.Build.BuildProject.Build(handler, null, options.ToArray()) == 0;
                }
                catch (Exception exc)
                {
                    this._mode = Mode.Inactive;
                    Build.BuildConfig.HandleErrorObject(Build.ErrorObject.MessageType.Error, _("Build of project {0} caused exception {1}.", this._project.Name, exc.Message));
                }
                finally
                {
                    this._mode = Mode.Inactive;
                }

                Config appconfig=Config.Get();
                appconfig.Path = "ExeBuild";
                appconfig.Write("CopyLog", this._checkPasteLogIntoInfoWindow.Value);
                appconfig.Flush();
            }
            finally
            {
                this._mode = Mode.Inactive;
                this._globberIndex = -1;
                this._bitmapLabel.Bitmap = this._globberInactive;
                this._isRunning = false;
            }
            this.EndModal(success ? ShowModalResult.OK : ShowModalResult.CANCEL);
        }

        /// <summary>
        /// The log text that has been displayed in the log-window.
        /// </summary>
        public string Logtext { get { return this._logWindow.Value; } }

        /// <summary>
        /// True if the user requests to copy the log text into the info window.
        /// </summary>
        public bool CopyLogText { get { return this._checkPasteLogIntoInfoWindow.Value; } }

        void OnStartingShellProcess(wx.ProcessUtils.ShellProcessEvent evt)
        {
            this.Enabled = true;
            wx.App.TheApp.SafeYield(this);

            if ((this._mode&Mode.KillProcess) == Mode.KillProcess)
            {
                evt.RequestCancellation();
            }
            else
            {
                this._mode = this._mode | Mode.WaitingForProcess;
                lock (Object.DllSync)
                {
                    if (this._globberIndex < 0)
                        this._globberIndex = 0;
                    else
                    {
                        this._globberIndex += 1;
                        if (this._globberIndex >= this._globberImages.ImageCount)
                            this._globberIndex = 0;
                    }
                    this._bitmapLabel.Bitmap = this._globberImages.GetBitmap(this._globberIndex);
                }
            }
        }

        void OnRunningShellProcess(wx.ProcessUtils.ShellProcessEvent evt)
        {
            wx.App.TheApp.SafeYield(this);

            if ((this._mode&Mode.KillProcess) == Mode.KillProcess)
            {
                evt.RequestCancellation();
            }
            else
            {
                lock (Object.DllSync)
                {
                    this._globberIndex += 1;
                    if (this._globberIndex >= this._globberImages.ImageCount)
                        this._globberIndex = 0;
                    this._bitmapLabel.Bitmap = this._globberImages.GetBitmap(this._globberIndex);
                }
            }
        }

        void OnFinishedShellProcess(wx.ProcessUtils.ShellProcessEvent evt)
        {
            lock (Object.DllSync)
            {
                this._mode = this._mode & ~Mode.WaitingForProcess;
                this._bitmapLabel.Bitmap = this._globberInactive;
            }
        }

        void OnStartStopButton(object sender, wx.Event evt)
        {
            KeyEvent kevt = evt as KeyEvent;
            if (kevt == null ||
                (kevt.KeyCode == 'C' && kevt.ControlDown) ||
                (kevt.KeyCode==(int)KeyCode.WXK_ESCAPE)
                )
            {
                if (this._isRunning)
                {
                    this._mode = this._mode | Mode.KillProcess;
                }
                else
                {
                    this._startStopButton.Label = _("Stop execution!");
                    this._actionTree.Enabled = false;
                    App.TheApp.SafeYield();
                    this.RunBuild();
                }
            }
        }
    }

    /** The main frame of the package builder.
     */
    public class PkgFrame : wx.Frame
    {
        #region State
        internal TreeCtrl _srcTree;
        internal TreeCtrl _tocTree;

        SplitterWindow _topSplitter;
        SplitterWindow _treeListSplitter;
        wx.Notebook _infoNotebook;

        Html.HtmlWindow _infoWindow;
        wx.TextCtrl _logWindow;
        wx.StyledText.StyledTextCtrl _stcWindow;

        /// <summary>
        /// the data model of this dialog.
        /// </summary>
        TableOfContents _toc = new TableOfContents();

        string _pkgFileName = null;
        bool _unsavedchanges = false;

        List<string> _lastPkgsInUse = null;

        MenuItem _menuItemCheckedCompactForm = null;
        #endregion

        #region Menu Commands
        [Globalization.EnumValueTranslations(9, "&New Package", "de", "&Neues Installationspaket")]
        [Globalization.EnumValueTranslations(10, "&Open Package", "de", "&Installationspaket öffnen")]

        [Globalization.EnumValueTranslations(4, "Load &File", "de", "&Datei laden")]
        [Globalization.EnumValueTranslations(1, "Load &wx.Build-Projects", "de", "&wx.Build-Projekte laden")]
        [Globalization.EnumValueTranslations(7, "Load &Directory", "de", "Aus &Verzeichnis laden")]
        [Globalization.EnumValueTranslations(2, "&About", "de", "Über...")]
        [Globalization.EnumValueTranslations(3, "E&xit", "de", "Beenden")]
        [Globalization.EnumValueTranslations(5, "&Save", "de", "Paket &Speichern")]
        [Globalization.EnumValueTranslations(6, "&Help", "de", "&Hilfe")]
        [Globalization.EnumValueTranslations(8, "Save Package as", "de", "Paket Speichern als")]
        [Globalization.EnumValueTranslations(11, "Config File Types", "de", "&Dateitypen konfigurieren")]
        [Globalization.EnumValueTranslations(12, "&Remove", "de", "&Löschen")]
        [Globalization.EnumValueTranslations(13, "&Load Files", "de", "&Dateien laden")]
        [Globalization.EnumValueTranslations(14, "&Edit Label", "de", "&Umbenennen")]
        [Globalization.EnumValueTranslations(15, "&Add to Feature", "de", "&Hinzufügen (Installationspaket)")]
        [Globalization.EnumValueTranslations(16, "&Build", "de", "&Erstellen")]
        [Globalization.EnumValueTranslations(17, "&Rebuild", "de", "&Neu erstellen")]
        [Globalization.EnumValueTranslations(18, "Toggle &Info Windows", "de", "&Info-Anzeigen umschalten")]
        [Globalization.EnumValueTranslations(20, "&Select Source File", "de", "&Quelldatei suchen")]
        [Globalization.EnumValueTranslations(21, "&Save Project", "de", "Projekt &speichern")]
        [Globalization.EnumValueTranslations(22, "&Load Project", "de", "Projekt &laden")]
        [Globalization.EnumValueTranslations(23, "&Add Current Platform", "de", "&Erzeugnisse für aktuelle Platform einfügen.")]
        [Globalization.EnumValueTranslations(24, "&Compact Project Files", "de", "Projekte &kompakt speichern.")]
        enum MenuEntries
        {
            LoadBuildProject = 1,
            About = 2,
            ExitApplication = 3,
            LoadFile = 4,
            SavePackage=5,
            Help=6,
            LoadDirectory=7,
            SavePackageAs=8,
            NewPackage = 9,
            OpenPackage = 10,
            ConfigContentTypes=11,
            Remove=12,
            LoadDirectoryFiles=13,
            EditTocLabel=14,
            CopySrcToPkg = 15,

            BuildProjectInSrcTree = 16,
            RebuildProjectInSrcTree = 17,

            ToggleVisibilityInfoWindows=18,

            ExitRunningProcess = 19,

            FindSrcNodeToTocLeaf = 20,
            SavePkgProject = 21,
            LoadPkgProject = 22,

            AddCurrentPlatform = 23,

            CheckCompactProjectFiles = 24,

            LoadLastPkg0 = 100,
            LoadLastPkg1 = 101,
            LoadLastPkg2 = 102,
            LoadLastPkg3 = 103,
        }
        #endregion

        #region Window IDs
        enum WindowIDs
        {
            /// <summary>
            /// The mime type selection in the info window referring to a node in the src tree
            /// </summary>
            MimeTypeSelectionSrcTree=10000,

            /// <summary>
            /// This is the text edit for the resource name in the TOC tree.
            /// </summary>
            EditNameInResourceToc=10001,

            /// <summary>
            /// ID of the button to select the file referring to a TOC leaf node in the source tree.
            /// </summary>
            SelectTocFileInSrcTree=10002,

            /// <summary>
            /// Window to change the compression level.
            /// </summary>
            SelectCompressionLevelTocTree = 10003,

            /// <summary>
            /// Button to build the selected project.
            /// </summary>
            ButtonBuildProjectInSrcTree = 10004,

            /// <summary>
            /// Button to rebuild the selected project.
            /// </summary>
            ButtonRebuildProjectInSrcTree = 10005,

            /// <summary>
            /// This is the text edit for the resource name in the SRC tree.
            /// </summary>
            EditNameInResourceSrcTree = 10006,

            /// <summary>
            /// Window to change the compression level in the SRC tree.
            /// </summary>
            SelectCompressionLevelSrcTree = 10007,
        }
        #endregion

        #region About Box
        /** <summary>Presents an HTML Abount Box.</summary>
         */
        public class AboutBox : wx.Frame
        {
            public AboutBox(wx.Window parent)
                : base(parent, wx.Window.wxID_ANY, _("About Package Builder"), wxDefaultPosition, new System.Drawing.Size(600, 400))
            {
                this.Icon = wx.ArtProvider.GetIcon(wx.ArtID.wxART_QUESTION, wx.ArtClient.wxART_FRAME_ICON, new System.Drawing.Size(16,16));
                this.CreateStatusBar();
                wx.Html.HtmlWindow html = new wx.Html.HtmlWindow(this, wxDefaultPosition, wxDefaultSize /*, HtmlWindow.wxFULL_REPAINT_ON_RESIZE*/);
                html.RelatedStatusBar = 0;

                html.Parser.AddTagHandler(new wx.Html.HtmlButtonTagHandler());
                html.EVT_BUTTON(wx.Window.wxID_CANCEL, new wx.EventListener(OnCloseCmd));

                html.SetRelatedFrame(this, _("About Package Builder"));
                html.LoadPage("zrs:PkgBuilder.zrs//Info.html");

                this.Centre();
            }

            public void OnCloseCmd(object sender, wx.Event evt)
            {
                this.Close();
            }
        }
        #endregion

        #region CTor
        public PkgFrame() :base(_("wx.NET Package Builder"), wxDefaultPosition, new System.Drawing.Size(800, 550), 
            WindowStyles.FRAME_DEFAULT_STYLE | WindowStyles.FULL_REPAINT_ON_RESIZE)
        {
            this.Icon = new Icon("PkgBuilder.zrs", "install.png");

            Config appconfig=Config.Get();

            #region Menu
            #region File Menu
            wx.MenuBar mainMenu = new MenuBar();
            Menu file = new Menu();
            file.Append(MenuEntries.NewPackage, _("Create a new empty package."));
            file.Append(MenuEntries.OpenPackage, _("Open an existing package file."));
            #region Last Files
            PackagerApp app = wx.App.GetApp() as PackagerApp;
            if (app != null)
            {
                this._lastPkgsInUse = app.GetLastPackages();
                if (this._lastPkgsInUse.Count > 0)
                {
                    Menu lastPkgMenu = new Menu();
                    int index = 0;
                    foreach (string lastPkg in this._lastPkgsInUse)
                    {
                        string lastPkgDisplay = lastPkg;
                        if (lastPkgDisplay.ToLower().EndsWith(".pkgproj"))
                            lastPkgDisplay = lastPkgDisplay.Substring(0, lastPkgDisplay.Length - 8);
                        lastPkgMenu.Append(((int)MenuEntries.LoadLastPkg0) + index, lastPkgDisplay);
                        index += 1;
                    }
                    file.Append(((int)MenuEntries.LoadLastPkg0), _("Last packages in use"), lastPkgMenu);
                }
            }
            #endregion
            file.AppendSeparator();
            file.Append(MenuEntries.LoadBuildProject, _("Load the files of a project."));
            file.Append(MenuEntries.LoadFile, _("Load a single file."));
            file.Append(MenuEntries.LoadDirectory, _("Load files from a directory."));
            file.AppendSeparator();
            file.Append(MenuEntries.AddCurrentPlatform, _("Insert all created files specific to the current platform into the tree of available sources."));
            file.AppendSeparator();
            file.Append(MenuEntries.Remove, _("Remove the currently selected node in either the source or the package tree list."));
            file.AppendSeparator();
            file.Append(MenuEntries.SavePkgProject, _("Save package layout / PackageBuilder project."));
            file.Append(MenuEntries.SavePackage, _("Save package."));
            file.Append(MenuEntries.SavePackageAs, _("Save package into another file."));
            file.AppendSeparator();
            file.Append(MenuEntries.ExitApplication, "Alt-X", "Exit the application");
            #endregion

            #region View Menu
            Menu view = new Menu();
            view.Append(MenuEntries.ToggleVisibilityInfoWindows, _("Toggles visibility of the info windows."));
            #endregion

            #region Edit Menu
            Menu edit = new Menu();
            edit.Append(MenuEntries.CopySrcToPkg, _("Copies the selected source to the currently selected feature/directory in the TOC of the package."));
            edit.AppendSeparator();
            edit.Append(MenuEntries.ConfigContentTypes, _("Configure the relevant file types."));
            _menuItemCheckedCompactForm=edit.AppendCheckItem(MenuEntries.CheckCompactProjectFiles, _("If this is checked, project files will be stored in compact form. Otherwise, the project files will be stored as readable XML."));
            appconfig.Path="/";
            _menuItemCheckedCompactForm.Checked = appconfig.Read("CompactProjectFiles", true);
            #endregion

            #region Info Menu
            Menu info = new Menu();
            info.Append(MenuEntries.Help, "F1", "Starts the help browser.");
            info.Append(MenuEntries.About, "Alt-A", "Raises the about box.");
            #endregion
            mainMenu.Append(file, _("File"));
            mainMenu.Append(view, _("View"));
            mainMenu.Append(edit, _("Edit"));
            mainMenu.Append(info, _("Info"));
            this.MenuBar = mainMenu;

            #region Event Declaration
            EVT_MENU(MenuEntries.ExitApplication, new EventListener(this.OnExit));
            EVT_MENU(MenuEntries.LoadFile, new EventListener(this.OnLoadFile));
            EVT_MENU(MenuEntries.LoadPkgProject, new EventListener(this.OnLoadPkgProj));
            EVT_MENU(MenuEntries.LoadBuildProject, new EventListener(this.OnLoadProjects));
            EVT_MENU(MenuEntries.LoadDirectory, new EventListener(this.OnLoadDirectory));
            EVT_MENU(MenuEntries.SavePkgProject, new EventListener(this.OnSaveProject));
            EVT_MENU(MenuEntries.SavePackage, new EventListener(this.OnSavePackage));
            EVT_MENU(MenuEntries.SavePackageAs, new EventListener(this.OnSavePackageAs));
            EVT_MENU(MenuEntries.About, new EventListener(this.OnAbout));
            EVT_MENU(MenuEntries.OpenPackage, new EventListener(this.OnOpenPackage));
            EVT_MENU(MenuEntries.NewPackage, new EventListener(this.OnNewPackage));
            EVT_MENU(MenuEntries.LoadLastPkg0, new EventListener(this.OnLoadOneOfTheLastPackages));
            EVT_MENU(MenuEntries.LoadLastPkg1, new EventListener(this.OnLoadOneOfTheLastPackages));
            EVT_MENU(MenuEntries.LoadLastPkg2, new EventListener(this.OnLoadOneOfTheLastPackages));
            EVT_MENU(MenuEntries.LoadLastPkg3, new EventListener(this.OnLoadOneOfTheLastPackages));
            EVT_MENU(MenuEntries.ConfigContentTypes, new EventListener(this.OnConfigContentTypes));
            EVT_MENU(MenuEntries.Remove, new EventListener(this.OnDeleteCurrentSrcNode));
            EVT_MENU(MenuEntries.LoadDirectoryFiles, new EventListener(this.OnLoadDirectoryFiles));
            EVT_MENU(MenuEntries.EditTocLabel, new EventListener(this.OnEditTocLabel));
            EVT_MENU(MenuEntries.CopySrcToPkg, new EventListener(this.OnCopySrcToPkg));
            EVT_MENU(MenuEntries.RebuildProjectInSrcTree, new EventListener(this.OnRebuildProjectInSrcTree));
            EVT_MENU(MenuEntries.BuildProjectInSrcTree, new EventListener(this.OnBuildProjectInSrcTree));
            EVT_MENU(MenuEntries.ToggleVisibilityInfoWindows, new EventListener(this.OnToggleVisibilityInfo));
            EVT_MENU(MenuEntries.FindSrcNodeToTocLeaf, new EventListener(this.OnSelectSrcFileOfTocLeafNode));
            EVT_MENU(MenuEntries.AddCurrentPlatform, new EventListener(this.OnAddCurrentPlatform));
            EVT_MENU(MenuEntries.CheckCompactProjectFiles, new EventListener(this.OnCheckCompactProjectFiles));
            #endregion

            #endregion

            #region ImageList
            ImageList images = new ImageList(16, 16);
            Image img = new Image("PkgBuilder.zrs", "install.png").Rescale(16, 16); // 0
            images.Add(new Bitmap(img));
            img = new Image("PkgBuilder.zrs", "doc.xpm").Rescale(16, 16); // 1
            images.Add(new Bitmap(img));
            img = new Image("PkgBuilder.zrs", "doc_sel.xpm").Rescale(16, 16); // 2
            images.Add(new Bitmap(img));
            img = new Image("PkgBuilder.zrs", "folder_open.xpm").Rescale(16, 16); // 3
            images.Add(new Bitmap(img));
            img = new Image("PkgBuilder.zrs", "folder_closed.xpm").Rescale(16, 16); // 4
            images.Add(new Bitmap(img));
            img = new Image("PkgBuilder.zrs", "pfolder_open.png").Rescale(16, 16); // 5
            images.Add(new Bitmap(img));
            img = new Image("PkgBuilder.zrs", "pfolder_closed.png").Rescale(16, 16); // 6
            images.Add(new Bitmap(img));
            img = new Image("PkgBuilder.zrs", "save.png").Rescale(16, 16); // 7
            images.Add(new Bitmap(img));
            img = new Image("PkgBuilder.zrs", "help.png").Rescale(16, 16); // 8
            images.Add(new Bitmap(img));
            images.Add(wx.ArtProvider.GetBitmap(ArtID.wxART_DELETE, ArtClient.wxART_TOOLBAR, new System.Drawing.Size(16, 16))); // 9
            img = new Image("PkgBuilder.zrs", "install.png").Rescale(16, 16); // 10
            images.Add(new Bitmap(img));
            img = new Image("PkgBuilder.zrs", "addtopkg.png").Rescale(16, 16); // 11
            images.Add(new Bitmap(img));
            img = new Image("PkgBuilder.zrs", "ptarget.png").Rescale(16, 16); // 12
            images.Add(new Bitmap(img));
            img = new Image("PkgBuilder.zrs", "platform.png").Rescale(16, 16); // 13
            images.Add(new Bitmap(img));
            #endregion

            #region Toolbar
            this.CreateToolBar(WindowStyles.TB_3DBUTTONS | WindowStyles.TB_DOCKABLE | WindowStyles.ORIENT_HORIZONTAL);
            this.ToolBar.AddTool(MenuEntries.NewPackage, images[1], _("Creates a new package."));
            this.ToolBar.AddTool(MenuEntries.LoadFile, images[3], _("Load a file into the package"));
            this.ToolBar.AddTool(MenuEntries.SavePackage, images[7], _("Save the current project and the resulting installation package"));
            this.ToolBar.AddTool(MenuEntries.Remove, images[9], _("Remove the currently selected node either in the source or in the package tree."));
            this.ToolBar.AddTool(MenuEntries.CopySrcToPkg, images[11], _("Copies the currently selected source to the current feature/directory in the TOC of teh package."));
            this.ToolBar.AddTool(MenuEntries.Help, images[8], _("Display help information"));
            this.ToolBar.Realize();
            #endregion

            #region Subwindows
            this._topSplitter = new SplitterWindow(this, wxDefaultPosition, wxDefaultSize,
                wx.WindowStyles.SP_3D | wx.WindowStyles.SP_LIVE_UPDATE | wx.WindowStyles.CLIP_CHILDREN);
            this._treeListSplitter = new SplitterWindow(this._topSplitter, wxDefaultPosition, wxDefaultSize,
                wx.WindowStyles.SP_3D | wx.WindowStyles.SP_LIVE_UPDATE | wx.WindowStyles.CLIP_CHILDREN);
            this._srcTree = new TreeCtrl(this._treeListSplitter);
            this._srcTree.DropTarget = new SrcTreeDropTarget(this);

            this._tocTree = new TreeCtrl(this._treeListSplitter, wxDefaultPosition, wxDefaultSize,
                WindowStyles.TR_EDIT_LABELS | WindowStyles.TR_FULL_ROW_HIGHLIGHT
                | WindowStyles.TR_HAS_BUTTONS | WindowStyles.TR_ROW_LINES | WindowStyles.TR_HIDE_ROOT);
            this._tocTree.DropTarget = new TocTreeDropTarget(this);

            #region Info Notebook
            this._infoNotebook = new Notebook(this._topSplitter);

            #region Info HTML Window
            this._infoWindow = new wx.Html.HtmlWindow(this._infoNotebook);
            this._infoNotebook.AddPage(this._infoWindow, _("Node Info"), true);
            this._infoWindow.Parser.AddTagHandler(new wx.Html.HtmlTextFieldTagHandler());
            this._infoWindow.EVT_TEXT_ENTER(-1, new EventListener(OnEnterTextInInfoWindow));
            this._infoWindow.EVT_CHECKBOX(-1, new EventListener(OnCheckInInfoWindow));
            this._infoWindow.Parser.AddTagHandler(new wx.Html.HtmlArtProviderTagHandler());
            this._infoWindow.Parser.AddTagHandler(new wx.Html.HtmlButtonTagHandler());
            this._infoWindow.Parser.AddTagHandler(new wx.Html.HtmlOptionTagHandler());
            if (app != null)
            {
                // The ID of the created window will be defined by the HTML text.
                wx.Html.HtmlChoiceTagHandler chooseMimeType = new wx.Html.HtmlChoiceTagHandler(wx.Html.HtmlChoiceTagHandler.Style.List, "MIMETYPE");
                foreach (Build.ContentType t in app.GetRelevantContentTypes())
                    chooseMimeType.Append(t.Name, t);
                this._infoWindow.Parser.AddTagHandler(chooseMimeType);
            }
            {
                wx.Html.HtmlChoiceTagHandler chooseCompression = new wx.Html.HtmlChoiceTagHandler(wx.Html.HtmlChoiceTagHandler.Style.Choice, "COMPRESSION", (int)WindowIDs.SelectCompressionLevelTocTree);
                foreach (CompressionMode mode in Enum.GetValues(typeof(CompressionMode)))
                    chooseCompression.Append(_(mode), mode);
                this._infoWindow.Parser.AddTagHandler(chooseCompression);
            }
            #endregion

            #region Log Window
            this._logWindow = new TextCtrl(this._infoNotebook, -1, "", wxDefaultPosition, wxDefaultSize, 
                WindowStyles.TE_AUTO_SCROLL 
                | WindowStyles.TE_READONLY
                | WindowStyles.TE_MULTILINE
                | WindowStyles.TE_LINEWRAP);
            this._logWindow.BackgroundColour = new Colour("#ff9d9b");
            wx.Log.SetActiveTarget(this._logWindow);
            this._infoNotebook.AddPage(this._logWindow, _("Log"));
            #endregion
            #endregion
            this._topSplitter.SplitHorizontally(this._treeListSplitter, this._infoNotebook);
            _treeListSplitter.SplitVertically(this._srcTree, this._tocTree);
            _treeListSplitter.Unsplit(this._tocTree);
            this._tocTree.Show(false); // hide currently because not yet implemented
            #endregion

            #region Display of text files
            this._stcWindow = new wx.StyledText.StyledTextCtrl(this._infoNotebook);
            this._stcWindow.ReadOnly = true;
            this._stcWindow.CallTipUseStyle(50);
            this._infoNotebook.AddPage(this._stcWindow, _("Content"));
            this._infoNotebook.GetPage(2).Disable();
            #endregion

            #region Initial Data of Windows
            this._srcTree.ImageList = images;
            this.InitSrcTreeData();

            this._tocTree.ImageList = images;
            this.InitTocTreeData();
            #endregion

            #region Info Window Events
            this._infoWindow.EVT_LISTBOX((int)WindowIDs.MimeTypeSelectionSrcTree, new EventListener(this.OnSelectMimeTypeSrcTree));
            this._infoWindow.EVT_TEXT((int)WindowIDs.EditNameInResourceToc, new EventListener(this.OnChangeResourceNameInToc));
            this._infoWindow.EVT_TEXT((int)WindowIDs.EditNameInResourceSrcTree, new EventListener(this.OnChangeResourceNameInSrcTree));
            this._infoWindow.EVT_BUTTON((int)WindowIDs.SelectTocFileInSrcTree, new EventListener(this.OnSelectSrcFileOfTocLeafNode));
            this._infoWindow.EVT_CHOICE((int)WindowIDs.SelectCompressionLevelTocTree, new EventListener(this.OnChangeCompressionTocTree));
            this._infoWindow.EVT_CHOICE((int)WindowIDs.SelectCompressionLevelSrcTree, new EventListener(this.OnChangeCompressionSrcTree));
            this._infoWindow.EVT_BUTTON((int)WindowIDs.ButtonRebuildProjectInSrcTree, new EventListener(this.OnRebuildProjectInSrcTree));
            this._infoWindow.EVT_BUTTON((int)WindowIDs.ButtonBuildProjectInSrcTree, new EventListener(this.OnBuildProjectInSrcTree));
            #endregion

            #region SRC TREE Events
            #region Source Tree
            this._srcTree.EVT_TREE_ITEM_EXPANDED(-1, new EventListener(this.OnExpandedSrcNode));
            this._srcTree.EVT_TREE_ITEM_COLLAPSED(-1, new EventListener(this.OnCollapsedSrcNode));
            this._srcTree.EVT_TREE_ITEM_RIGHT_CLICK(-1, new EventListener(this.OnPopupSrcTree));
            this._srcTree.EVT_TREE_BEGIN_DRAG(-1, new EventListener(this.OnBeginDragSrc));
            this._srcTree.EVT_TREE_SEL_CHANGED(-1, new EventListener(this.OnSelectSrcNode));
            #endregion

            #region TOC Tree
            this._tocTree.EVT_TREE_ITEM_RIGHT_CLICK(-1, new EventListener(this.OnPopupTocTree));
            this._tocTree.EVT_TREE_ITEM_EXPANDED(-1, new EventListener(this.OnExpandedTocNode));
            this._tocTree.EVT_TREE_ITEM_COLLAPSED(-1, new EventListener(this.OnCollapsedTocNode));
            this._tocTree.EVT_TREE_SEL_CHANGED(-1, new EventListener(this.OnSelectTocNode));
            #endregion
            #endregion

            #region Key Acceleration and Frame Events
            this.AcceleratorTable = new AcceleratorTable(
                new AcceleratorEntry(AcceleratorEntry.AccelFlags.CTRL, 's', (int)MenuEntries.SavePackage),
                new AcceleratorEntry(AcceleratorEntry.AccelFlags.CTRL, 'x', (int)MenuEntries.ExitApplication),
                new AcceleratorEntry(AcceleratorEntry.AccelFlags.NORMAL, KeyCode.WXK_F1, (int)MenuEntries.Help),
                new AcceleratorEntry(AcceleratorEntry.AccelFlags.NORMAL, KeyCode.WXK_DELETE, (int)MenuEntries.Remove)
                );

            this.AddEventListener(ProjectUpdateEvent.EVT_ID, new EventListener(this.OnPendingUpdateEvent));
            #endregion

            this.EVT_CLOSE(new EventListener(this.OnCloseEvent));

            this.CreateStatusBar(1);
        }

        void InitSrcTreeData()
        {
            this._toc.SrcFiles.Clear(null);
            this._srcTree.DeleteAllItems();
            this._srcTree.AddRoot(_("Files"), 4);
            this._srcTree.SetItemData(this._srcTree.RootItem, new TreeItemData(0));
            this._unsavedchanges = false;
        }

        void InitTocTreeData()
        {
            this._toc.TocFiles.Clear(null);
            this._tocTree.DeleteAllItems();
            string pkgName = this._pkgFileName;
            if (pkgName == null)
                pkgName = _("Feature");
            else
                pkgName = System.IO.Path.GetFileNameWithoutExtension(pkgName);
            TreeItemId rootNode=this._tocTree.AddRoot(_("All Features"), 10);
            this._tocTree.SetItemData(rootNode, new TreeItemData(0));
            TreeItemId featureNode=this._tocTree.AppendItem(this._tocTree.RootItem, pkgName, 10);
            int initFeatureData = this._toc.TocFiles.AddNode(0, new TocNodeData(pkgName));
            this._tocTree.SetItemData(featureNode, new TreeItemData(initFeatureData));
        }

        /// <summary>
        /// The currently used filename for the package.
        /// On setting this property, this will be reported to the application in order to extend the configuration.
        /// </summary>
        string CurrentPackageFile
        {
            get { return this._pkgFileName; }
            set
            {
                if (value != null)
                {
                    PackagerApp app = wx.App.GetApp() as PackagerApp;
                    if (app != null)
                        app.ReportOpenedPackage(value);
                }
                this._pkgFileName = value;
            }
        }
        #endregion

        #region Actions, Services, Utilities

        SortedList<Build.ContentType, wx.StyledText.StcStyleCollection> _stcStyles = new SortedList<wx.Build.ContentType, wx.StyledText.StcStyleCollection>();
        /// <summary>
        /// Returns a collection of STC styles to present data of the provided type in the STC view.
        /// </summary>
        /// <param name="t">The content type of the data to be presented.</param>
        /// <returns></returns>
        public wx.StyledText.StcStyleCollection GetStcStyle(Build.ContentType t)
        {
            if (this._stcStyles.ContainsKey(t))
                return this._stcStyles[t];
            wx.StyledText.StcStyleCollection result = null;
            if (t == Build.ContentType.CSharpCode
                || t == Build.ContentType.CPlusPlusCode
                || t == Build.ContentType.CPlusPlusInclude
                || t == Build.ContentType.CCPlusPlusInclude
                || t == Build.ContentType.CCode
                || t == Build.ContentType.CInclude
                )
                result = new wx.StyledText.StcStyleCollection(t.Name, wx.StyledText.LexerId.CPP);
            else if (t == Build.ContentType.HTML)
                result = new wx.StyledText.StcStyleCollection(t.Name, wx.StyledText.LexerId.HTML);
            else if ((t.Properties & Build.ContentFileProperties.XMLText) == Build.ContentFileProperties.XMLText)
                result = new wx.StyledText.StcStyleCollection(t.Name, wx.StyledText.LexerId.XML);
            else if (t == Build.ContentType.VisualBasic)
                result = new wx.StyledText.StcStyleCollection(t.Name, wx.StyledText.LexerId.VB);
            else if (t == Build.ContentType.NMake || t == Build.ContentType.GMake)
                result = new wx.StyledText.StcStyleCollection(t.Name, wx.StyledText.LexerId.MAKEFILE);
            else if (t == Build.ContentType.Premake)
                result = new wx.StyledText.StcStyleCollection(t.Name, wx.StyledText.LexerId.LUA);
            else if (t == Build.ContentType.RCFile)
                result = new wx.StyledText.StcStyleCollection(t.Name, wx.StyledText.LexerId.CPPNOCASE);
            else
                result = new wx.StyledText.StcStyleCollection(t.Name, wx.StyledText.LexerId.NULL);
            this._stcStyles.Add(t, result);
            return result;
        }

        wx.StyledText.StcStyleCollection _currentStcStyle = null;
        /// <summary>
        /// Displays the content of the provided file in the STC-Window if applicable.
        /// </summary>
        /// <param name="fileDescr">Description of the file that shall be displayed.</param>
        public void DisplayContent(Build.ContentFile fileDescr)
        {
            if (this._currentStcStyle != null)
                this._currentStcStyle.DeactivateFor(this._stcWindow);

            if (fileDescr != null &&
                fileDescr.Exists && 
                (fileDescr.Type.Properties & wx.Build.ContentFileProperties.PlainText) == wx.Build.ContentFileProperties.PlainText)
            {
                this._infoNotebook.GetPage(2).Enabled=true;
                this._stcWindow.ReadOnly = false;
                this._stcWindow.LoadFile(fileDescr.FileName);
                this._currentStcStyle = this.GetStcStyle(fileDescr.Type);
                this._currentStcStyle.Apply(this._stcWindow);
                this._stcWindow.EmptyUndoBuffer();
                this._stcWindow.ReadOnly = true;
                this._infoNotebook.Selection = 2;
            }
            else
            {
                this._stcWindow.ReadOnly = false;
                this._stcWindow.Clear();
                this._stcWindow.EmptyUndoBuffer();
                this._stcWindow.ReadOnly = true;
                this._infoNotebook.GetPage(2).Disable();
                this._infoNotebook.Selection = 0; // Display the HTML window
            }
        }

        /// <summary>
        /// Builds the provided project using the settings of this application.
        /// Messages of the build process will be pasted into the log window.
        /// </summary>
        /// <param name="p">The project to be made</param>
        /// <param name="rebuild">Indicates with true that the project shall be rebuilt.</param>
        /// <returns>True on success</returns>
        public bool Make(Build.BuildProject p, bool rebuild)
        {
            this._infoNotebook.Selection = 1;

            if (rebuild)
                wx.Log.LogMessage("Rebuild project {0}.", p.Name);
            else
                wx.Log.LogMessage("Build project {0}.", p.Name);

            PkgBuildExecDialog buildFrame = PkgBuildExecDialog.GetAndCreateIfNessecary(this, p, rebuild);
            ShowModalResult result=buildFrame.ShowModal();
            if (buildFrame.CopyLogText)
                this._logWindow.AppendText(buildFrame.Logtext);
            if (result==ShowModalResult.OK)
                wx.Log.LogMessage("Built project {0} successfully.", p.Name);
            else
                wx.Log.LogError("Error on building project {0}.", p.Name);
            return result == ShowModalResult.OK;
        }

        #region Management of Tree Node, Input of Files and Packages

        /// <summary>
        /// Adds the data associated with the designated node in the tree of source files to the currently selected
        /// feature or installation directory in the package view.
        /// </summary>
        /// <param name="id">Valid designator if a node in the source tree.</param>
        public void AddSrcFileToPkg(TreeItemId id)
        {
            if (!this._tocTree.Selection.IsOk())
            {
                TreeItemId[] children = this._tocTree.GetChildren(this._tocTree.RootItem);
                if (children != null && children.Length > 0) // unknown target. so, let's get the first feature. features a represented as children of the root.
                {
                    this._tocTree.Selection = children[0];
                }
            }

            TreeItemId newNode = this.AddSrcFileToPkgRecursion(id, this._tocTree.Selection);
            if (newNode != null && newNode.IsOk())
            {
                this._tocTree.EnsureVisible(newNode);
                if (this._tocTree.HasChildren(newNode))
                    this._tocTree.Expand(newNode);
            }
            this._unsavedchanges = true;
        }

        /// <summary>
        /// Helper for <c>AddSrcFileToPkg</c> implementing recursion into directories.
        /// </summary>
        /// <param name="idSrcItem">Valid designator if a node in the source tree.</param>
        /// <param name="idTocTargetItem">identifies the node in the TOC tree where the new node shall be added to as a new child</param>
        /// <returns>Returning the Id of the new node in the toc tree that has been created for the argument node or
        /// <c>null</c> iff the operation failed.</returns>
        TreeItemId AddSrcFileToPkgRecursion(TreeItemId idSrcItem, TreeItemId idTocTargetItem)
        {
            if (idSrcItem.IsOk() && idSrcItem != this._srcTree.RootItem)
            {
                TreeItemData idData = this._srcTree.GetItemData(idSrcItem);
                if (idData.Data is int)
                {
                    int srcNodeIndex = (int)idData.Data;
                    Build.ContentFile file = null;
                    if (this._toc.SrcFiles.ContainsTreeNode(srcNodeIndex))
                        file=this._toc.SrcFiles.GetTreeNodeData(srcNodeIndex).File;
                    else
                        file=this._toc.SrcFiles.GetLeafNodeData(srcNodeIndex).File;

                    bool isLeafNode = true;
                    int imageIndex = 1;
                    int selImageIndex = 2;
                    if (file.Type.Implies(Build.ContentType.Directory))
                    {
                        imageIndex = 4;
                        selImageIndex = 4;
                        isLeafNode = false;
                    }
                    int parentNodeIndex = 0; // default is root node.
                    TreeItemData parentTreeNodeData = this._tocTree.GetItemData(idTocTargetItem);
                    if (parentTreeNodeData != null && parentTreeNodeData.Data is int)
                        parentNodeIndex = (int)parentTreeNodeData.Data; 
                    TocNodeData tocData=new TocNodeData(srcNodeIndex, this._toc.SrcFiles);
                    if (this._toc.TocFiles.ContainsFile(file.FileName))
                    {
                        // refer to the same resource name as all the other installations of this file

                    }
                    else
                    {
                        // ensure that resource name is unique.
                    }
                    int newTreeNode;
                    if (isLeafNode)
                        newTreeNode = this._toc.TocFiles.AddLeafNode(parentNodeIndex, tocData);
                    else
                        newTreeNode = this._toc.TocFiles.AddNode(parentNodeIndex, tocData);
                    TreeItemId newNode = this._tocTree.AppendItem(idTocTargetItem, "*" + file.BaseFileName, imageIndex, selImageIndex);
                    this._tocTree.SetItemData(newNode, new TreeItemData(newTreeNode));
                    if (this._srcTree.HasChildren(idSrcItem))
                    {
                        foreach (TreeItemId childId in this._srcTree.GetChildren(idSrcItem))
                        {
                            this.AddSrcFileToPkgRecursion(childId, newNode);
                        }
                    }
                    return newNode;
                }
            }
            return null;
        }

        /// <summary>
        /// Loads files whose names are listed in the argument into the tree of source files.
        /// </summary>
        /// <param name="filenames">Names of the files to be loaded.</param>
        public void LoadSrcFiles(ICollection<string> filenames)
        {
            this._infoNotebook.Selection = 1;
            List<string> doubleFiles = new List<string>();
            foreach (string filename in filenames)
            {
                wx.Log.LogMessage(_("Loading {0}."), filename);

                if (this._toc.SrcFiles.ContainsFile(filename))
                    doubleFiles.Add(filename);
                else if (System.IO.Directory.Exists(filename))
                {
                    int newNodeIndex = this._toc.SrcFiles.AddNode(0, new SrcNodeData(new Build.ContentFile(Build.ContentType.Directory, filename)));
                    this._srcTree.AppendItem(this._srcTree.RootItem, "*" + System.IO.Path.GetFileName(filename), 4, 4, new TreeItemData(newNodeIndex));
                    this._unsavedchanges = true;
                }
                else
                {
                    Build.ContentType t = Build.ContentType.GetOneMatchingType(filename);
                    if (t == null)
                        t = Build.ContentType.TXT;
                    Build.ContentFile asFile = new wx.Build.ContentFile(t, filename);
                    TreeItemId newNode = this.AddSrcFileNode(this._srcTree.RootItem, null, asFile, null, 1, 2, true);
                    this._srcTree.EnsureVisible(newNode);
                    this._srcTree.Selection = newNode;
                    this._unsavedchanges = true;
                }
            }
            if (doubleFiles.Count > 0)
            {
                string message = _("The following files are already part of the project:");
                int i = 0;
                foreach (string f in doubleFiles)
                {
                    message += "\n " + f;
                    i += 1;
                    if (i > 10)
                        break;
                }
                MessageDialog.ShowModal(this, message, _("Warning"), WindowStyles.ICON_WARNING | WindowStyles.DIALOG_OK);
            }
        }

        /// <summary>
        /// This returns the content file that is associated with the currently selected source node (in the corresponding
        /// tree control). This is <c>null</c> if the node does not have any associated content file.
        /// </summary>
        public Build.ContentFile GetSelectedSrcFile()
        {
            Build.ContentFile result = null;
            TreeItemId currentNode = this._srcTree.Selection;
            if (currentNode.IsOk())
            {
                TreeItemData treeCtrlData = this._srcTree.GetItemData(currentNode);
                if (treeCtrlData != null && treeCtrlData.Data is int)
                {
                    SrcNodeData nodeData = this._toc.SrcFiles.GetTreeNodeData((int)treeCtrlData.Data);
                    if (nodeData != null)
                    {
                        result = nodeData.File;
                        if (result == null)
                        {
                            SrcLeafData leafData=this._toc.SrcFiles.GetLeafNodeData((int)treeCtrlData.Data);
                            if (leafData != null)
                                result = leafData.File;
                        }
                    }
                }
            }
            return result;
        }

        /// <summary>
        /// This returns the data that has been associated with the currently selected source node (in the corresponding
        /// tree control). This is <c>null</c> if the node does not have any associated content file.
        /// </summary>
        public SrcNodeData GetSelectedSrcData()
        {
            TreeItemId currentNode = this._srcTree.Selection;
            if (currentNode.IsOk())
            {
                TreeItemData treeCtrlData = this._srcTree.GetItemData(currentNode);
                if (treeCtrlData != null && treeCtrlData.Data is int)
                {
                    return this._toc.SrcFiles.GetTreeNodeData((int)treeCtrlData.Data);
                }
            }
            return null;
        }

        /// <summary>
        /// removes the current package without warning and loadsa package loaded from the provided file.
        /// </summary>
        /// <param name="filenamePkg">the file that contains the new package. This is either a project or a package.</param>
        /// <param name="destinationDir">the directory where all the data will be written to. If this is <c>null</c>, this will load a project file.</param>
        public void OpenPackageFile(string filenamePkg, string destinationDir)
        {
            try
            {
                if (filenamePkg != null && filenamePkg.Length > 0 && System.IO.File.Exists(filenamePkg)
                    && (destinationDir == null 
                        || (destinationDir.Length > 0 && System.IO.Directory.Exists(destinationDir))))
                {
                    this._infoNotebook.Selection = 1;
                    wx.Log.LogMessage(_("Open package file {0}."), filenamePkg);

                    this.CurrentPackageFile = filenamePkg;
                    this._toc.Clear();
                    this.InitTocTreeData();
                    this.InitSrcTreeData();
                    Build.ErrorHandler errorHandler = delegate(Build.ErrorObject errorObj)
                    {
                        this._logWindow.AppendFormat("{0}\n", errorObj);
                        App.TheApp.SafeYield();
                    };
                    if (destinationDir == null)
                    {
                        string absPkgDir = Build.BuildConfig.GetFullPathname(filenamePkg);
                        absPkgDir = System.IO.Path.GetDirectoryName(absPkgDir);
                        Build.BuildConfig.PathRoot = absPkgDir;
                        using (System.IO.StreamReader s = new System.IO.StreamReader(filenamePkg))
                        using (System.Xml.XmlTextReader r = new System.Xml.XmlTextReader(s))
                        {
                            this._toc.ReadXml(r);
                        }
                        this._toc.NormalizeOriginalFileNames(absPkgDir);
                    }
                    else
                    {
                        this._toc.Load(errorHandler, filenamePkg, destinationDir);
                    }
                    if (this._toc.SrcFiles.Count > 0)
                    {
                        Stack<KeyValuePair<int, TreeItemId>> agenda = new Stack<KeyValuePair<int, TreeItemId>>();
                        #region Fill SrcFiles
                        agenda.Push(new KeyValuePair<int, TreeItemId>(0, this._srcTree.RootItem));
                        while (agenda.Count > 0)
                        {
                            KeyValuePair<int, TreeItemId> current = agenda.Pop();
                            int nodeInModel = current.Key;
                            TreeItemId nodeInDialog = current.Value;
                            foreach (int subnode in this._toc.SrcFiles.GetTreeNodeChildren(nodeInModel))
                            {
                                SrcNodeData subnodeData = this._toc.SrcFiles.GetTreeNodeData(subnode);
                                int imageIndex = 4;
                                string nodeName = "";
                                if (subnodeData.File != null)
                                    nodeName = subnodeData.File.BaseFileName;
                                else if (subnodeData.FolderType != KindOfSrcFolder.NotOneOfTheSupportedFolders)
                                    nodeName = SrcNodeData.FolderTypeToString(subnodeData.FolderType);
                                if (subnodeData.ProjectRef != null)
                                {
                                    imageIndex = 6;
                                    Build.BuildProject.AddKnownProject(subnodeData.ProjectRef.Project);
                                    nodeName = subnodeData.ProjectRef.Project.Name;
                                }
                                if (subnodeData.FolderType == KindOfSrcFolder.Platform
                                    && subnodeData.Platform != null)
                                {
                                    imageIndex = 13;
                                    nodeName = subnodeData.Platform.OsVersion.Platform.ToString();
                                }
                                TreeItemId subnodeInDialog = this._srcTree.AppendItem(nodeInDialog,
                                    nodeName, imageIndex, imageIndex, new TreeItemData(subnode));
                                agenda.Push(new KeyValuePair<int, TreeItemId>(subnode, subnodeInDialog));

                                App.TheApp.SafeYield();
                            }
                            foreach (int leafnode in this._toc.SrcFiles.GetLeafNodeChildren(nodeInModel))
                            {
                                this._srcTree.AppendItem(nodeInDialog,
                                    this._toc.SrcFiles.GetLeafNodeData(leafnode).File.BaseFileName,
                                    1, 2, new TreeItemData(leafnode));

                                App.TheApp.SafeYield();
                            }
                        }
                        this._srcTree.EnsureVisible(this._srcTree.RootItem);
                        #endregion
                    }
                    else
                        this.InitSrcTreeData(); // source tree on file is empty but we do not allow for empty trees
                    if (this._toc.TocFiles.Count > 0) // we allow for empty toc tree.
                    {
                        // we have read the features from file. So, we will remove this features from the control
                        // first, that have been added on initialization.
                        this._tocTree.DeleteChildren(this._tocTree.RootItem); // remove initial feature. we will load it from file.

                        Stack<KeyValuePair<int, TreeItemId>> agenda = new Stack<KeyValuePair<int, TreeItemId>>();
                        #region Fill Package TOC Files
                        agenda.Push(new KeyValuePair<int, TreeItemId>(0, this._tocTree.RootItem));
                        while (agenda.Count > 0)
                        {
                            KeyValuePair<int, TreeItemId> current = agenda.Pop();
                            int nodeInModel = current.Key;
                            TreeItemId nodeInDialog = current.Value;
                            foreach (int subnode in this._toc.TocFiles.GetTreeNodeChildren(nodeInModel))
                            {
                                TocNodeData subnodeData = this._toc.TocFiles.GetTreeNodeData(subnode);
                                string showName;
                                int imageIndex = 4;
                                if (subnodeData.FeatureName == null)
                                    showName = subnodeData.File.BaseFileName;
                                else
                                {
                                    showName = subnodeData.FeatureName;
                                    imageIndex = 10;
                                }
                                TreeItemId subnodeInDialog = this._tocTree.AppendItem(nodeInDialog,
                                    showName, imageIndex, imageIndex, new TreeItemData(subnode));
                                agenda.Push(new KeyValuePair<int, TreeItemId>(subnode, subnodeInDialog));

                                App.TheApp.SafeYield();
                            }
                            foreach (int leafnode in this._toc.TocFiles.GetLeafNodeChildren(nodeInModel))
                            {
                                TreeItemId newNode = this._tocTree.AppendItem(nodeInDialog,
                                    this._toc.TocFiles.GetLeafNodeData(leafnode).File.BaseFileName,
                                    1, 2, new TreeItemData(leafnode));
                                this._tocTree.EnsureVisible(newNode);

                                App.TheApp.SafeYield();
                            }
                        }
                        this._srcTree.EnsureVisible(this._srcTree.RootItem);
                        this._srcTree.Expand(this._srcTree.RootItem);
                        #endregion
                    }
                    else
                        this.InitTocTreeData();
                    this._allUsedEnvVars = null;
                    wx.Log.LogMessage(_("Loaded package {0}.", filenamePkg));
                }
            }
            catch (Exception exc)
            {
                MessageDialog.ShowModal(this, _("Error on loading file {0}.\n{1}", this.CurrentPackageFile, exc.Message),
                    _("Error"), WindowStyles.ICON_ERROR | WindowStyles.DIALOG_OK);
            }
        }

        /// <summary>
        /// This will traverse the complete source tree and search for all platform descriptors containing at least
        /// one file.
        /// </summary>
        /// <returns></returns>
        public ICollection<PlatformDescr> GetPlatformsInSrc()
        {
            return this._toc.GetPlatformsInSrc();
        }

        /// <summary>
        /// This will call AddCurrentPlatform(). Wrpper for events.
        /// </summary>
        /// <param name="sender">Unuesd: The sender of the event.</param>
        /// <param name="evt">The event. also unused.</param>
        /// <see cref="AddCurrentPlatform"/>
        void OnAddCurrentPlatform(object sender, Event evt)
        {
            this.AddCurrentPlatform();
        }

        /// <summary>
        /// Looks for each contained platform specific file whether the local file system contains a version of this file.
        /// If this finds a file, the current platform will be added to the platforms supporting that file.
        /// </summary>
        public void AddCurrentPlatform()
        {
            this.AddCurrentPlatform(this._srcTree.RootItem);
        }

        /// <summary>
        /// Looks for each contained platform specific file whether the local file system contains a version of this file.
        /// If this finds a file, the current platform will be added to the platforms supporting that file.
        /// </summary>
        /// <param name="srcNode">The operation will be applied to this node and all children.</param>
        public void AddCurrentPlatform(TreeItemId srcNode)
        {
            TreeItemData srcItemData = this._srcTree.GetItemData(srcNode);
            if (srcItemData == null)
                return;
            PlatformDescr currentPlatform=PlatformDescr.GetCurrent();
            int srcNodeId = (int)srcItemData.Data;
            SrcLeafData srcNodeData = this._toc.SrcFiles.GetLeafNodeData(srcNodeId);
            if (srcNodeData != null
                && srcNodeData.File != null
                && (srcNodeData.File.Type.Properties & wx.Build.ContentFileProperties.DependsOnOSAndProcessor) == wx.Build.ContentFileProperties.DependsOnOSAndProcessor
                && srcNodeData.File.Exists)
            {
                #region The parent should be a platform
                TreeItemId platformNode = this._srcTree.GetItemParent(srcNode);
                if (!platformNode.IsOk())
                    return;
                TreeItemData platformItemData = this._srcTree.GetItemData(platformNode);
                int platformNodeId = (int)platformItemData.Data;
                SrcNodeData platformData = this._toc.SrcFiles.GetTreeNodeData(platformNodeId);
                if (platformData.FolderType != KindOfSrcFolder.Platform
                    || platformData.Platform == currentPlatform)
                    return; // either this is not a platform (thus we have nothing to add to) or this is the current
                // platform (we do not need to add anything since the file in question already has been added
                // to the current platform).
                #endregion
                #region We have to add the file to the grandparent
                TreeItemId grandparentNode = this._srcTree.GetItemParent(platformNode);
                if (!platformNode.IsOk())
                    return;
                this.AddSrcFileNode(grandparentNode, currentPlatform, srcNodeData.File, srcNodeData.ProjectRef, 1, 2, true);
                #endregion
            }
            else
            {
                // proceed with all children.
                foreach (TreeItemId child in this._srcTree.GetChildren(srcNode))
                    this.AddCurrentPlatform(child);
            }
        }

        /// <summary>
        /// Will be called if the check box to toggle compact mode project files.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="evt"></param>
        void OnCheckCompactProjectFiles(object sender, Event evt)
        {
            Config appconfig=Config.Get();
            appconfig.Path = "/";
            appconfig.Write("CompactProjectFiles", this._menuItemCheckedCompactForm.Checked);
        }

        /// <summary>
        /// This will open a dialog to edit the contained mime types (extensions) and loads or removes the files
        /// in the subtree accordingly.
        /// </summary>
        /// <param name="srcNode">A node in the source tree control representing a directory. This will do nothing if this
        /// node is not associated with a directory.</param>
        public void LoadDirectoryFiles(TreeItemId srcNode)
        {
            TreeItemData treedata=this._srcTree.GetItemData(srcNode);
            if (treedata == null || !(treedata.Data is int))
                return;
            SrcNodeData nodeData=this._toc.SrcFiles.GetTreeNodeData((int) treedata.Data);
            if (nodeData == null || nodeData.File == null
                || !nodeData.File.Type.Implies(Build.ContentType.Directory))
                return;

            ContentTypeConfigDialog d = null;
            if (nodeData.Types == null || nodeData.Types.Count == 0)
                d = new ContentTypeConfigDialog(this, _("Configure the type of those files in the directory, that will be included into the project."),
                    wxDefaultPosition, wxDefaultSize, WindowStyles.DIALOG_DEFAULT_STYLE);
            else
                d = new ContentTypeConfigDialog(nodeData.Types,
                    this, _("Configure the type of those files in the directory, that will be included into the project."),
                    wxDefaultPosition, wxDefaultSize, WindowStyles.DIALOG_DEFAULT_STYLE);
            ShowModalResult result=d.ShowModal();
            if (result != ShowModalResult.CANCEL)
            {
                nodeData.Types = d.Selected;

                // Since we will add new children, we have to removethe existing ones in order
                // to prevent doubles.
                this._srcTree.DeleteChildren(srcNode);
                this._toc.SrcFiles.RemoveChildren((int)treedata.Data);

                bool traverseSubdirs = nodeData.Types.Contains(Build.ContentType.Directory);
                // Collects files to add and traverse (in case of directories).
                // The value is the designator of the parent node that shall be used when extending
                // the source tree control.
                Stack<KeyValuePair<Build.ContentFile, TreeItemId>> agenda = new Stack<KeyValuePair<wx.Build.ContentFile, TreeItemId>>();
                agenda.Push(new KeyValuePair<Build.ContentFile, TreeItemId>(nodeData.File, srcNode));
                while (agenda.Count > 0)
                {
                    App.TheApp.SafeYield();

                    KeyValuePair<Build.ContentFile, TreeItemId> current = agenda.Pop();
                    List<string> filesAndSubdirs = new List<string>();
                    filesAndSubdirs.AddRange(System.IO.Directory.GetDirectories(current.Key.FileName));
                    filesAndSubdirs.AddRange(System.IO.Directory.GetFiles(current.Key.FileName));
                    foreach (string fullFileName in filesAndSubdirs)
                    {
                        string fileName = System.IO.Path.GetFileName(fullFileName);
                        if (fileName.StartsWith("."))
                            continue;
                        ICollection<Build.ContentType> typesOfFile = Build.ContentType.GetMatchingTypes(fullFileName);
                        treedata = this._srcTree.GetItemData(current.Value);
                        if (treedata != null && treedata.Data is int)
                        {
                            if (traverseSubdirs && typesOfFile.Contains(Build.ContentType.Directory))
                            {
                                Build.ContentFile newDir = new wx.Build.ContentFile(Build.ContentType.Directory, fullFileName);
                                int nodeID = this._toc.SrcFiles.AddNode((int)treedata.Data, new SrcNodeData(newDir, nodeData.Types));
                                TreeItemId newDirNode = this._srcTree.AppendItem(current.Value, "*"+fileName, 4, 4, new TreeItemData(nodeID));
                                this._srcTree.EnsureVisible(newDirNode);
                                agenda.Push(new KeyValuePair<Build.ContentFile, TreeItemId>(new Build.ContentFile(Build.ContentType.Directory, fullFileName), newDirNode));
                            }
                            else
                            {
                                Build.ContentType matchingType = null;
                                if (System.IO.Directory.Exists(fullFileName))
                                    matchingType = Build.ContentType.Directory;
                                else
                                {
                                    foreach (Build.ContentType aPossibleTypeOfFile in typesOfFile)
                                    {
                                        if (nodeData.Types.Contains(aPossibleTypeOfFile))
                                        {
                                            matchingType = aPossibleTypeOfFile;
                                            break;
                                        }
                                    }
                                }
                                if (matchingType != null)
                                {
                                    Build.ContentFile newFile = new Build.ContentFile(matchingType, fullFileName);
                                    int nodeID = 0;
                                    if (matchingType == Build.ContentType.Directory)
                                    {
                                        nodeID = this._toc.SrcFiles.AddNode((int)treedata.Data, new SrcNodeData(newFile));
                                        TreeItemId newNode = this._srcTree.AppendItem(current.Value, "*"+fileName, 4, 4, new TreeItemData(nodeID));
                                        agenda.Push(new KeyValuePair<Build.ContentFile, TreeItemId>(newFile, newNode));
                                        this._srcTree.EnsureVisible(newNode);
                                    }
                                    else
                                    {
                                        nodeID = this._toc.SrcFiles.AddLeafNode((int)treedata.Data, new SrcLeafData(newFile));
                                        this._srcTree.AppendItem(current.Value, "*"+fileName, 1, 2, new TreeItemData(nodeID));
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        #endregion

        #region Display Info
        /// <summary>
        /// Array of used environment variables. Lazy generation.
        /// </summary>
        Build.EnvironmentVarInfo[] _allUsedEnvVars=null;

        /// <summary>
        /// This helper method will append HTML code presenting info on environment variables to
        /// the provided string builder. This will print info on all known environment variables
        /// (using the cache <c>_allUsedEnvVars</c>) if the variable filter argument is <c>null</c>.
        /// Otherwise, only those known environment variables will be presented, that also appear
        /// in the filter argument.
        /// </summary>
        /// <param name="htmlCode">The target of the generated HTML code.</param>
        /// <param name="varFilter">This is a filter for the presented variables containing variable names.
        /// This may be <c>null</c> indicating the desire for unconstrained output of all known variables.</param>
        public void AppendEnvVarInfoTable(StringBuilder htmlCode, ICollection<string> varFilter)
        {
            #region Fill Cache If Required
            {
                if (this._allUsedEnvVars == null)
                {
                    ICollection<Build.EnvironmentVarInfo> usedVars = Build.BuildProject.GetUsedVariables(null);
                    this._allUsedEnvVars = new wx.Build.EnvironmentVarInfo[usedVars.Count];
                    int arrayIndex = 0;
                    foreach (Build.EnvironmentVarInfo varInfo in usedVars)
                    {
                        this._allUsedEnvVars[arrayIndex] = varInfo;
                        arrayIndex += 1;
                    }
                }
            }
            #endregion

            #region Title
            htmlCode.AppendLine("<p>");
            htmlCode.AppendLine("<table border=1>");
            htmlCode.Append("<tr><th bgcolor=\"#6e96d8\">Name</th><th bgcolor=\"#6e96d8\">Description</th><th bgcolor=\"#6e96d8\">Value</th><th bgcolor=\"#6e96d8\">Type</th><th bgcolor=\"#6e96d8\">Mandatory</th></tr>");
            #endregion
            #region Creating the table rows
            int id = 20000;
            foreach (Build.EnvironmentVarInfo varInfo in this._allUsedEnvVars)
            {
                if (varFilter == null || varFilter.Contains(varInfo.Varname))
                {
                    if (varInfo.ValueType.IsAssignableFrom(typeof(bool)))
                    {
                        CheckBoxState state = CheckBoxState.UNDETERMINED;
                        object currentState = varInfo.Get();
                        if (true.Equals(currentState))
                            state = CheckBoxState.CHECKED;
                        else if (false.Equals(currentState))
                            state = CheckBoxState.UNCHECKED;
                        htmlCode.AppendFormat("<tr><td>{0}</td><td>{1}</td><td><wxoption styles=\"CHK_3STATE\" tristate={2} id={3}></td><td>{4}</td><td>{5}</td></tr>",
                            varInfo.Varname, varInfo.Description, state,
                            id, varInfo.ValueType.Name, varInfo.IsMandatory);
                    }
                    else
                    {
                        string additionalStyles = "";
                        if (varInfo.ValueType.IsAssignableFrom(typeof(Build.DirectoryName)))
                            additionalStyles = "styles=\"DIRECTORY\"";
                        else if (varInfo.ValueType.IsAssignableFrom(typeof(Build.DirectoryList)))
                            additionalStyles = "styles=\"DIRECTORY_LIST\"";
                        htmlCode.AppendFormat("<tr><td>{0}</td><td>{1}</td><td><wxtext text=\"{2}\" id={3} {6} width=200></td><td>{4}</td><td>{5}</td></tr>",
                            varInfo.Varname, varInfo.Description, varInfo.GetAsString(),
                            id, varInfo.ValueType.Name, varInfo.IsMandatory, additionalStyles);
                    }
                }
                id += 1; // ID counter shall run in all cases in order to producable ID mappings
            }
            #endregion
            htmlCode.AppendLine("</table>");
            htmlCode.AppendLine("</p>");

        }

        public void DisplayInfoSrcNode(SrcNodeData data)
        {
            this._infoNotebook.Selection = 0; // show the HTML window

            StringBuilder htmlCode = new StringBuilder();
            htmlCode.AppendLine("<html><body bgcolor=\"#dee2ff\">");
            if (data == null
                || (data.File==null && data.ProjectRef == null && data.Platform == null))
            {
                #region Root node display
                htmlCode.AppendLine("<img src=\"zrs:PkgBuilder.zrs//wxnetlogo.png\">");
                htmlCode.AppendLine("<p>Operating System:</p>");
                htmlCode.AppendLine("<p>");
                htmlCode.AppendLine("<table border=1>");
                htmlCode.AppendFormat("<tr><td>Platform</td><td>{0}</td></tr>", System.Environment.OSVersion.Platform);
                htmlCode.AppendFormat("<tr><td>OS Version</td><td>{0}</td></tr>", System.Environment.OSVersion.Version);
                htmlCode.AppendFormat("<tr><td>Service Pack</td><td>{0}</td></tr>", System.Environment.OSVersion.ServicePack);
                htmlCode.AppendFormat("<tr><td>Framework</td><td>{0}</td></tr>", System.Environment.Version);
                PackagerApp app=App.TheApp as PackagerApp;
                if (app != null)
                {
                    htmlCode.AppendFormat(_("<tr><td>Comment</td><td><wxtext id=19000 styles=\"wxTE_MULTILINE\" width=250 height=80 text=\"{0}\"></td></tr>"), app.PlatformDescription);
                    htmlCode.AppendFormat(_("<tr><td>ID</td><td>{1}{0:000000}</td></tr>"), app.PlatformID, System.Environment.OSVersion.Platform);
                }
                htmlCode.AppendLine("</table>");
                htmlCode.AppendLine("</p>");
                if (data == null)
                {
                    htmlCode.AppendLine(_("<p>Environment variables:</p>"));
                    this.AppendEnvVarInfoTable(htmlCode, null);
                }
                ICollection<PlatformDescr> platforms = this.GetPlatformsInSrc();
                if (platforms.Count > 0)
                {
                    htmlCode.AppendLine(_("<p>This contains files specific to the current platforms:</p>"));
                    htmlCode.AppendLine("<table border=1>");
                    htmlCode.AppendLine(_("<tr><th bgcolor=\"#6e96d8\">OS</th><th>OS Version</th><th>ID</th><th>Comment</th></tr>"));
                    foreach (PlatformDescr p in platforms)
                    {
                        htmlCode.AppendFormat("<tr><td>{0}</td><td>{1}</td><td>{0}{2:000000}</td><td>{3}</td></tr>\n", p.OsVersion.Platform, p.OsVersion.VersionString, p.ID, p.Description);
                    }
                    htmlCode.AppendLine("</table>");
                }
                #endregion
            }
            else if (data.File != null)
            {
                #region Content file display
                if (data.File.Exists)
                    htmlCode.Append("<wxart ARTID=\"FOLDER_OPEN\" width=16 height=16> ");
                else
                    htmlCode.Append("<wxart ARTID=\"WARNING\" width=16 height=16> ");
                htmlCode.Append(_("<font size=+1> <b>A folder in the local file system.</b></font>"));
                if (!data.File.Exists)
                    htmlCode.Append(_(" (file does not exist in the local file system.)"));
                #endregion
            }
            else if (data.ProjectRef != null)
            {
                #region Displaying nodes on projects
                htmlCode.Append("<img src=\"zrs:PkgBuilder.zrs//pfolder_closed.png\"> ");
                htmlCode.AppendFormat(_("<font size=+1> <b>wx.BuildSystem project {0}.</b></font>", data.Project.Name));
                htmlCode.Append("<p>");
                htmlCode.Append(data.Project.Description);
                htmlCode.Append("</p>");
                if (data.Project.Id != Guid.Empty)
                {
                    htmlCode.AppendLine(string.Format("<p><b>ID:</b>{0}</p>", data.Project.Id));
                }
                #region Find referenced projects and resources
                SortedDictionary<string, Build.BuildProject> referencedProjectSet = new SortedDictionary<string, wx.Build.BuildProject>();
                SortedDictionary<string, Build.ResourceDesignator> resources=new SortedDictionary<string,wx.Build.ResourceDesignator>();
                foreach (Build.IBuildProduct prereq in data.Project.GetPrerequisites())
                {
                    if (prereq is Build.IFileProducts)
                    {
                        ICollection<Build.RefToProject> referencedProjects = ((Build.IFileProducts)prereq).GetProjects();
                        if (referencedProjects != null)
                        {
                            foreach (Build.RefToProject referencedProject in referencedProjects)
                                referencedProjectSet[referencedProject.Project.Name] = referencedProject.Project;
                        }
                    }
                    else if (prereq is Build.ResourceDesignator)
                    {
                        Build.ResourceDesignator rd=(Build.ResourceDesignator) prereq;
                        resources[rd.ResourceFile.FileName] = rd;
                    }
                }
                #endregion

                #region Make TOC
                htmlCode.Append(_("<p><a name=\"top\"><font size=-1><a href=\"#sources\">[Sources]</a><a href=\"#targets\">[Targets]</a>"));
                if (referencedProjectSet.Count > 0)
                    htmlCode.AppendLine(_("<a href=\"#references\">[References]</a>"));
                if (data.Project.Features != null && data.Project.Features.Count > 0)
                    htmlCode.AppendLine(_("<a href=\"#features\">[Features]</a>"));
                if (data.Project.UsedVars != null && data.Project.UsedVars.Count > 0)
                    htmlCode.AppendLine(_("<a href=\"#envvars\">[Variables]</a>"));
                if (data.Platform != null || data.NetFramework != null)
                    htmlCode.AppendLine(_("<a href=\"#platform\">[Platform]</a>"));
                if (resources.Count > 0)
                    htmlCode.AppendLine(_("<a href=\"#resources\">[Resources]</a>"));
                htmlCode.AppendLine("</font></a></p>");
                #endregion

                #region Make Target Table
                htmlCode.Append(_("<p><a name=\"targets\"><b>Targets:</b></a></a><br><table border=1>"));
                htmlCode.Append(_("<tr><th bgcolor=\"#6e96d8\">&nbsp;</th><th bgcolor=\"#6e96d8\">filename</th><th bgcolor=\"#6e96d8\">absolute filename</th><th bgcolor=\"#6e96d8\">content type</th></tr>"));
                foreach (Build.IBuildProduct target in data.Project.GetTargets())
                {
                    if (target is Build.ContentFile)
                    {
                        Build.ContentFile fileTarget = (Build.ContentFile)target;
                        htmlCode.Append("<tr> ");
                        if (fileTarget.Exists)
                            htmlCode.Append("<td><wxart width=16 height=16 ARTID=\"NORMAL_FILE\"></td>");
                        else
                            htmlCode.Append("<td><wxart width=16 height=16 ARTID=\"WARNING\"></td>");
                        htmlCode.Append("<td>");
                        htmlCode.Append(fileTarget.OriginalFileName);
                        htmlCode.Append("</td>");
                        htmlCode.Append("<td>");
                        htmlCode.Append(fileTarget.FileName);
                        htmlCode.Append("</td>");
                        htmlCode.AppendFormat("<td>{0}</td></tr>", fileTarget.Type.Name);
                    }
                }
                htmlCode.Append(_("</table></p><p><font size=-1><a href=\"#top\">[Top]</a></font></p>"));
                if (data.Project.TargetsAreConsistent(DateTime.MinValue))
                {
                    htmlCode.AppendFormat(_("<p>The targets are consistent. <wxbutton bgcolor=\"#295193\" fgcolor=\"#ffffff\" label=\"Rebuild\" id={0}></p>"), (int)WindowIDs.ButtonRebuildProjectInSrcTree);
                }
                else
                {
                    htmlCode.Append(_("<p><wxart ARTID=\"WARNING\" width=16 height=16>The targets have not yet been built or are inconsistent with latest changes.</p>"));
                    htmlCode.AppendFormat(_("<p><wxbutton bgcolor=\"#295193\" fgcolor=\"#ffffff\" label=\"Build\" id={0}>&nbsp;<wxbutton bgcolor=\"#295193\" fgcolor=\"#ffffff\" label=\"Rebuild\" id={1}></p>"), (int)WindowIDs.ButtonBuildProjectInSrcTree, (int)WindowIDs.ButtonRebuildProjectInSrcTree);
                }
                #endregion

                #region Make Table Of Sources
                htmlCode.Append(_("<p><a name=\"sources\"><b>Sources:</b></a><br><table border=1>"));
                htmlCode.Append(_("<tr><th bgcolor=\"#6e96d8\">&nbsp;</th><th bgcolor=\"#6e96d8\">filename</th><th bgcolor=\"#6e96d8\">content type</th></tr>"));
                foreach (Build.IBuildProduct prereq in data.Project.GetPrerequisites())
                {
                    if (prereq is Build.IFileProducts)
                    {
                        if (!(prereq is Build.BuildProject))
                        {
                            Build.ContentFiles prereqFiles = ((Build.IFileProducts)prereq).Files;
                            foreach (Build.ContentFile filePrereq in prereqFiles)
                            {
                                htmlCode.Append("<tr> ");
                                if (filePrereq.Exists)
                                    htmlCode.Append("<td><wxart width=16 height=16 ARTID=\"NORMAL_FILE\"></td>");
                                else
                                    htmlCode.Append("<td><wxart width=16 height=16 ARTID=\"WARNING\"></td>");
                                htmlCode.Append("<td>");
                                htmlCode.Append(filePrereq.OriginalFileName);
                                htmlCode.AppendFormat("</td><td>{0}</td></tr>", filePrereq.Type.Name);
                            }
                        }
                    }
                }
                htmlCode.Append(_("</table><p><font size=-1><a href=\"#top\">[Top]</a></font></p>"));
                #endregion

                #region Make Table Of Project References
                if (referencedProjectSet.Count > 0)
                {
                    htmlCode.Append(_("<p><a name=\"references\"><b>Project References:</b></a><br><table border=1>"));
                    htmlCode.Append(_("<tr><th bgcolor=\"#6e96d8\">Project Name</th><th bgcolor=\"#6e96d8\">Description</th><th bgcolor=\"#6e96d8\">Targets</th></tr>"));
                    foreach (Build.BuildProject p in referencedProjectSet.Values)
                    {
                        htmlCode.AppendFormat("<tr><td>{0}</td><td>{1}</td><td>", p.Name, p.Description);
                        bool first = true;
                        foreach (Build.IBuildProduct target in p.GetTargets())
                        {
                            if (target is Build.IFileProducts)
                            {
                                Build.ContentFiles targetFiles = ((Build.IFileProducts)target).Files;
                                foreach (Build.ContentFile targetFile in targetFiles)
                                {
                                    if (!first)
                                        htmlCode.Append(", ");
                                    htmlCode.Append(targetFile.OriginalFileName);
                                    first = false;
                                }
                            }
                        }
                        htmlCode.Append("</td></tr>");
                    }
                    htmlCode.Append(_("</table><p><font size=-1><a href=\"#top\">[Top]</a></font></p>"));
                }
                #endregion

                #region Make Table Of Features
                if (data.Project.Features != null && data.Project.Features.Count > 0)
                {
                    htmlCode.Append(_("<p><a name=\"features\"><b>Features:</b></a><br><table border=1>"));
                    htmlCode.Append(_("<tr><th bgcolor=\"#6e96d8\">Name</th><th bgcolor=\"#6e96d8\">Description</th><th bgcolor=\"#6e96d8\">Symbol</th><th bgcolor=\"#6e96d8\">Valid</th></tr>"));
                    foreach (KeyValuePair<Build.FeatureEntry, bool> featureValid in data.Project.Features)
                    {
                        Build.FeatureEntry feature = featureValid.Key;
                        htmlCode.AppendFormat("<tr><td>{0}</td><td>{1}</td><td>{2}</td><td>{3}</td></tr>\n", feature.Displayname, feature.Description, feature.Symbol, featureValid.Value);
                    }
                    htmlCode.Append(_("</table></p><p><font size=-1><a href=\"#top\">[Top]</a></font></p>"));
                }
                #endregion

                #region Make Table Of Used Environment Variables
                if (data.Project.UsedVars != null && data.Project.UsedVars.Count > 0)
                {
                    htmlCode.Append(_("<p><a name=\"envvars\"><b>Used Variables:</b></a><br>"));
                    this.AppendEnvVarInfoTable(htmlCode, data.Project.UsedVars.Keys);
                    htmlCode.Append(_("<p><font size=-1><a href=\"#top\">[Top]</a></font></p>"));
                }
                #endregion

                #region Resources
                if (resources.Count > 0)
                {
                    htmlCode.Append(_("<p><a name=\"resources\"><b>Resources:</b></a><br><table border=1>"));
                    htmlCode.Append(_("<tr><th bgcolor=\"#6e96d8\">Name</th><th bgcolor=\"#6e96d8\">File</th><th bgcolor=\"#6e96d8\">original File</th><th bgcolor=\"#6e96d8\">Type</th></tr>"));
                    foreach (KeyValuePair<string, Build.ResourceDesignator> rd in resources)
                    {
                        htmlCode.AppendFormat("<tr><td>{0}</td><td>{1}</td><td>{2}</td><td>{3}</td></tr>\n", rd.Value.Name, rd.Value.ResourceFile.FileName, rd.Value.ResourceFile.OriginalFileName, rd.Value.ResourceFile.Type.ToString());
                    }
                    htmlCode.Append("</table></p>");
                    htmlCode.Append(_("<p><font size=-1><a href=\"#top\">[Top]</a></font></p>"));
                }
                #endregion

                #endregion
            }
            #region Platform and .NET version
            if (data != null
                && (data.NetFramework != null || data.Platform != null))
            {
                htmlCode.Append("<p><a name=\"platform\"><b>Platform:</b></a><br><table border=1>");
                htmlCode.Append("<tr><th bgcolor=\"#6e96d8\">Property</th><th bgcolor=\"#6e96d8\">Value</th></tr>");
                if (data.NetFramework != null)
                    htmlCode.AppendFormat(_("<tr><td valign=\"top\" align=\"left\"><b>Framework:</b></td><td align=\"left\">{0}</td></tr>"), data.NetFramework.Version.ToString());
                if (data.Platform != null)
                {
                    htmlCode.AppendFormat(_("<tr><td valign=\"top\" align=\"left\"><b>Platform:</b></td><td align=\"left\">{0}</td></tr>"), data.Platform.OsVersion.Platform.ToString());
                    htmlCode.AppendFormat(_("<tr><td valign=\"top\" align=\"left\"><b>OS Version:</b></td><td align=\"left\">{0}</td></tr>"), data.Platform.OsVersion.VersionString);
                    htmlCode.AppendFormat(_("<tr><td valign=\"top\" align=\"left\"><b>ID:</b></td><td align=\"left\">{0:000000}</td></tr>"), data.Platform.ID);
                    htmlCode.AppendFormat(_("<tr><td valign=\"top\" align=\"left\"><b>Comment:</b></td><td align=\"left\">{0}</td></tr>"), data.Platform.Description);
                }
                htmlCode.Append("</table></p><p><font size=-1><a href=\"#top\">[Top]</a></font></p>");
            }
            #endregion
            htmlCode.AppendLine("<br>");
            htmlCode.AppendLine("</body></html>");
            this._infoWindow.SetPage(htmlCode.ToString());
        }

        public void DisplayInfoSrcLeaf(SrcLeafData data)
        {
            this._infoNotebook.Selection = 0; // show the HTML window

            StringBuilder htmlCode = new StringBuilder();
            htmlCode.AppendLine("<html><body bgcolor=\"#dee2ff\">");
            if (data.File.Exists)
                htmlCode.Append("<wxart ARTID=\"NORMAL_FILE\" width=16 height=16> ");
            else
                htmlCode.Append("<wxart ARTID=\"WARNING\" width=16 height=16> ");
            htmlCode.Append(_("<font size=+1> <b>A local file.</b></font>"));
            if (!data.File.Exists)
                htmlCode.Append(_(" (file does not exist in the local file system.)"));
            htmlCode.AppendLine("<br>");
            htmlCode.AppendLine("<table>");
            htmlCode.AppendFormat(_("<tr><td valign=\"top\" align=\"left\"><b>File:</b></td><td align=\"left\"><code>{0}</code></td></tr>", data.File.OriginalFileName));
            htmlCode.AppendFormat(_("<tr><td valign=\"top\" align=\"left\">&nbsp;</td><td align=\"left\"><code>{0}</code></td></tr>", data.File.File.FileName));
            if (data.ProjectRef==null)
                htmlCode.AppendFormat(_("<tr><td valign=\"top\" align=\"left\"><b>Type:</b></td><td align=\"left\"><MIMETYPE w=300 id={1}><MIMETYPE_SELECT name=\"{0}\"></MIMETYPE></td></tr>", data.File.File.Type.Name, (int)WindowIDs.MimeTypeSelectionSrcTree));
            else
                htmlCode.AppendFormat(_("<tr><td valign=\"top\" align=\"left\"><b>Type:</b></td><td align=\"left\">{0}</td></tr>", data.File.File.Type.Name));
            if (data.File.Exists)
            {
                htmlCode.AppendFormat(_("<tr><td valign=\"top\" align=\"left\"><b>Creation time:</b></td><td align=\"left\">{0}</td></tr>", System.IO.File.GetCreationTime(data.File.FileName)));
                htmlCode.AppendFormat(_("<tr><td valign=\"top\" align=\"left\"><b>Last access time:</b></td><td align=\"left\">{0}</td></tr>", System.IO.File.GetLastAccessTime(data.File.FileName)));
                htmlCode.AppendFormat(_("<tr><td valign=\"top\" align=\"left\"><b>Last write time:</b></td><td align=\"left\">{0}</td></tr>", System.IO.File.GetLastWriteTime(data.File.FileName)));
            }
            htmlCode.AppendFormat(_("<tr><td valign=\"top\" align=\"left\"><b>Compression:</b></td><td align=\"left\"><COMPRESSION width=300 id=\"{1}\"><COMPRESSION_SELECT name=\"{0}\"></COMPRESSION></td></tr>"), _(data.Compression), (int) WindowIDs.SelectCompressionLevelSrcTree);
            if (data.NameInRes != null)
                htmlCode.AppendFormat(_("<tr><td valign=\"top\" align=\"left\"><b>Resource:</b></td><td align=\"left\"><wxtext text=\"{0}\" id={1} width=300></td></tr>"), data.NameInRes, (int)WindowIDs.EditNameInResourceSrcTree);
            if (data.NetFramework != null)
                htmlCode.AppendFormat(_("<tr><td valign=\"top\" align=\"left\"><b>Framework:</b></td><td align=\"left\">{0}</td></tr>"), data.NetFramework.Version.ToString());
            if (data.Platform != null)
            {
                htmlCode.AppendFormat(_("<tr><td valign=\"top\" align=\"left\"><b>Platform:</b></td><td align=\"left\">{0}</td></tr>"), data.Platform.OsVersion.Platform.ToString());
                htmlCode.AppendFormat(_("<tr><td valign=\"top\" align=\"left\"><b>OS Version:</b></td><td align=\"left\">{0}</td></tr>"), data.Platform.OsVersion.VersionString);
                htmlCode.AppendFormat(_("<tr><td valign=\"top\" align=\"left\"><b>Platform ID:</b></td><td align=\"left\">{0:000000}</td></tr>"), data.Platform.ID);
                htmlCode.AppendFormat(_("<tr><td valign=\"top\" align=\"left\"><b>Platform Comment:</b></td><td align=\"left\">{0}</td></tr>"), data.Platform.Description);
            }
            htmlCode.AppendLine("</table>");
            htmlCode.AppendLine("</body></html>");
            this._infoWindow.SetPage(htmlCode.ToString());

            this.DisplayContent(data.File);
        }

        /// <summary>
        /// Displays data on a node of the TOC tree in the HTML info control.
        /// </summary>
        /// <param name="data">The data to be displayed.</param>
        public void DisplayInfoTocNode(TocNodeData data)
        {
            this._infoNotebook.Selection = 0; // show the HTML window

            StringBuilder htmlCode = new StringBuilder();
            htmlCode.AppendLine("<html><body bgcolor=\"#dee2ff\">");
            if (data.File == null)
            {
                htmlCode.Append("<img src=\"zrs:PkgBuilder.zrs//install.png\"> ");
                htmlCode.Append(_("<font size=+1> <b>A feature of the installation package.</b></font>"));
            }
            else
            {
                htmlCode.Append("<wxart ARTID=\"FOLDER\" width=16 height=16> ");
                htmlCode.Append(_("<font size=+1> <b>A folder in the installation package.</b></font>"));
            }
            htmlCode.AppendLine("<br>");
            htmlCode.AppendLine("</body></html>");
            this._infoWindow.SetPage(htmlCode.ToString());
        }

        /// <summary>
        /// Displays data on a leaf node of the TOC tree in the HTML info control.
        /// </summary>
        /// <param name="data">The data to be displayed.</param>
        public void DisplayInfoTocLeaf(TocNodeData data)
        {
            this._infoNotebook.Selection = 0; // show the HTML window

            StringBuilder htmlCode = new StringBuilder();
            htmlCode.AppendLine("<html><body bgcolor=\"#dee2ff\">");
            htmlCode.Append("<wxart ARTID=\"NORMAL_FILE\"> ");
            htmlCode.Append(_("<font size=+1> <b>A local file in the installation package.</b></font>"));
            htmlCode.AppendLine("<br>");
            htmlCode.AppendLine("<table>");
            Build.ContentFile file=data.File;
            if (file != null)
            {
                htmlCode.AppendFormat(_("<tr><td valign=\"top\" align=\"left\"><b>File:</b></td><td align=\"left\"><code>{0}</code></td></tr>"), data.File.OriginalFileName);
                htmlCode.AppendFormat(_("<tr><td valign=\"top\" align=\"left\"></td><td align=\"left\"><code>{0}</code></td></tr>"), data.File.FileName);
                htmlCode.AppendFormat(_("<tr><td valign=\"top\" align=\"left\"><b>Type:</b></td><td align=\"left\"><code>{0}</code></td></tr>"), data.File.Type.Name);
            }
            htmlCode.AppendFormat(_("<tr><td valign=\"top\" align=\"left\"><b>Compression:</b></td><td align=\"left\"><COMPRESSION width=300><COMPRESSION_SELECT name=\"{0}\"></COMPRESSION></td></tr>"), _(data.Compression));
            if (data.NameInRes != null)
                htmlCode.AppendFormat(_("<tr><td valign=\"top\" align=\"left\"><b>Resource:</b></td><td align=\"left\"><wxtext text=\"{0}\" id={1} width=300></td></tr>"), data.NameInRes, (int) WindowIDs.EditNameInResourceToc);
            htmlCode.AppendLine("</table>");
            htmlCode.AppendLine(_("<wxbutton bgcolor=\"#295193\" fgcolor=\"#ffffff\" label=\"Select file in source tree.\" id={0}>", (int)WindowIDs.SelectTocFileInSrcTree));
            htmlCode.AppendLine("</body></html>");
            this._infoWindow.SetPage(htmlCode.ToString());

            if (file != null)
                this.DisplayContent(file);
        }

        #endregion
        #endregion

        #region Events

        #region Frame Events
        void OnExit(object sender, Event evt)
        {
            this.Close();
        }

        void OnSelectMimeTypeSrcTree(object sender, Event evt)
        {
            CommandEvent cevt = evt as CommandEvent;
            if (cevt != null)
            {
                Build.ContentType newType=(cevt.ClientObject as SystemObjectClientData).Data as Build.ContentType;

                TreeItemId selected = this._srcTree.Selection;
                TreeItemData selectedData = this._srcTree.GetItemData(selected);
                if (selectedData != null && selectedData.Data is int)
                {
                    if (this._toc.SrcFiles.ContainsLeafNode((int)selectedData.Data))
                    {
                        SrcLeafData data = this._toc.SrcFiles.GetLeafNodeData((int)selectedData.Data);
                        Build.ContentType oldType = data.File.Type;
                        data.File = new wx.Build.ContentFile(newType, data.File.OriginalFileName);
                        //this.DisplayInfoSrcLeaf(data); not necessary

                        // maybe the type has been changed from a platform dependent to an independent
                        // type or vice versa.
                        if ((oldType.Properties & wx.Build.ContentFileProperties.DependsOnOSAndProcessor)
                            !=
                            (newType.Properties & wx.Build.ContentFileProperties.DependsOnOSAndProcessor))
                        {
                            TreeItemId addFileToNode = this._srcTree.GetItemParent(selected);
                            if ((oldType.Properties & wx.Build.ContentFileProperties.DependsOnOSAndProcessor) == wx.Build.ContentFileProperties.DependsOnOSAndProcessor)
                            {
                                // The old type is platform dependent. Theat means, that the parent of the file is a platform
                                // description. However, the new node shall be added to the grandparent.
                                addFileToNode = this._srcTree.GetItemParent(addFileToNode);
                            }
                            TreeItemId newItem=this.AddSrcFileNode(addFileToNode, null, data.File, data.ProjectRef, 1, 2, true);
                            this._srcTree.Selection = newItem;
                            this._srcTree.EnsureVisible(newItem);
                            this.DeleteSrcNode(selected);
                        }
                    }
                }
            }
        }

        void OnSelectSrcNode(object sender, Event evt)
        {
            TreeEvent tevt = evt as TreeEvent;
            if (tevt != null)
            {
                TreeItemData data=this._srcTree.GetItemData(tevt.Item);
                if (data != null && data.Data is int)
                {
                    if (this._toc.SrcFiles.ContainsLeafNode((int)data.Data))
                        this.DisplayInfoSrcLeaf(this._toc.SrcFiles.GetLeafNodeData((int)data.Data));
                    else
                        this.DisplayInfoSrcNode(this._toc.SrcFiles.GetTreeNodeData((int)data.Data));
                }
            }
        }

        void OnSelectTocNode(object sender, Event evt)
        {
            TreeEvent tevt = evt as TreeEvent;
            if (tevt != null)
            {
                TreeItemData data = this._tocTree.GetItemData(tevt.Item);
                if (data != null && data.Data is int)
                {
                    if (this._toc.TocFiles.ContainsLeafNode((int)data.Data))
                        this.DisplayInfoTocLeaf(this._toc.TocFiles.GetLeafNodeData((int)data.Data));
                    else
                        this.DisplayInfoTocNode(this._toc.TocFiles.GetTreeNodeData((int)data.Data));
                }
            }
        }

        /// <summary>
        /// Returns the ID of a node in the SRC node that refers to the file of the provided node in the TOC node.
        /// The result is <c>null</c> if the argument does not refer to a file.
        /// </summary>
        /// <param name="tocNodeId">A node in the TOC tree ctrl that shall refer to a file.</param>
        /// <returns></returns>
        /// <seealso cref="TocNodeToSrcLeaf"/>
        TreeItemId SrcNodeToTocLeaf(TreeItemId tocNodeId)
        {
            TreeItemData tocDataId = this._tocTree.GetItemData(tocNodeId);
            if (tocDataId != null && tocDataId.Data is int)
            {
                TocNodeData tocData = this._toc.TocFiles.GetLeafNodeData((int)tocDataId.Data);
                if (tocData != null && tocData.SrcNode >= 0)
                {
                    foreach (TreeItemId srcNodeId in this._srcTree.GetAllItems())
                    {
                        TreeItemData srcDataId = this._srcTree.GetItemData(srcNodeId);
                        if (srcDataId != null && srcDataId.Data is int && ((int)srcDataId.Data) == tocData.SrcNode)
                        {
                            return srcNodeId;
                        }
                    }
                }
            }
            return null;
        }

        /// <summary>
        /// Returns the ID of a node in the TOC node that refers to the file of the provided node in the SRC node.
        /// </summary>
        /// <param name="srcNodeId">A node in the SRC tree ctrl that shall refer to a file.</param>
        /// <returns></returns>
        /// <seealso cref="SrcNodeToTocLeaf"/>
        ICollection<TreeItemId> TocNodeToSrcLeaf(TreeItemId srcNodeId)
        {
            List<TreeItemId> result = new List<TreeItemId>();
            TreeItemData srcDataId = this._srcTree.GetItemData(srcNodeId);
            if (srcDataId != null && srcDataId.Data is int)
            {
                foreach (TreeItemId tocNodeId in this._tocTree.GetAllItems())
                {
                    TreeItemData tocDataId = this._tocTree.GetItemData(tocNodeId);
                    if (tocDataId != null && tocDataId.Data is int)
                    {
                        TocNodeData tocData = this._toc.TocFiles.GetLeafNodeData((int)tocDataId.Data);
                        if (tocData != null && tocData.SrcNode >= 0 && ((int)srcDataId.Data) == tocData.SrcNode)
                            result.Add(tocNodeId);
                    }
                }
            }
            return result;
        }

        /// <summary>
        /// Will be called on selecting the button to select a file referrign to a leaf node in the TOC.
        /// </summary>
        void OnSelectSrcFileOfTocLeafNode(object sender, Event evt)
        {
            TreeItemData tocDataId = this._tocTree.GetItemData(this._tocTree.Selection);
            if (tocDataId != null && tocDataId.Data is int)
            {
                TocNodeData tocData = this._toc.TocFiles.GetLeafNodeData((int)tocDataId.Data);
                if (tocData != null && tocData.SrcNode >= 0)
                {
                    foreach(TreeItemId srcNodeId in this._srcTree.GetAllItems())
                    {
                        TreeItemData srcDataId = this._srcTree.GetItemData(srcNodeId);
                        if (srcDataId != null && srcDataId.Data is int && ((int)srcDataId.Data) == tocData.SrcNode)
                        {
                            this._srcTree.Selection = srcNodeId;
                            break;
                        }
                    }
                }
            }
        }

        /// <summary>
        /// This will be called on changing the compression level in the TOC tree
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="evt"></param>
        void OnChangeCompressionTocTree(object sender, Event evt)
        {
            TreeItemData tocDataId = this._tocTree.GetItemData(this._tocTree.Selection);
            if (tocDataId != null && tocDataId.Data is int)
            {
                TocNodeData tocData = this._toc.TocFiles.GetLeafNodeData((int)tocDataId.Data);
                if (tocData != null && tocData.SrcNode >= 0)
                {
                    tocData.Compression = (CompressionMode) ((SystemObjectClientData)((CommandEvent)evt).ClientObject).Data;
                    TreeItemId srcItemId = this.SrcNodeToTocLeaf(this._tocTree.Selection);
                    if (srcItemId != null)
                    {
                        TreeItemData srcItemData = this._srcTree.GetItemData(srcItemId);
                        if (srcItemData != null && srcItemData.Data is int)
                        {
                            SrcLeafData srcNodeData = this._toc.SrcFiles.GetLeafNodeData((int)srcItemData.Data);
                            srcNodeData.Compression = tocData.Compression;
                        }
                    }
                }
            }
        }

        /// <summary>
        /// This will be called on changing the compression level in the SRC tree
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="evt"></param>
        void OnChangeCompressionSrcTree(object sender, Event evt)
        {
            TreeItemData srcDataId = this._srcTree.GetItemData(this._srcTree.Selection);
            if (srcDataId != null && srcDataId.Data is int)
            {
                SrcLeafData srcData = this._toc.SrcFiles.GetLeafNodeData((int)srcDataId.Data);
                if (srcData != null && srcData.NameInRes != null)
                {
                    srcData.Compression = (CompressionMode) ((SystemObjectClientData)((CommandEvent)evt).ClientObject).Data;
                    foreach (TreeItemId tocItemId in this.TocNodeToSrcLeaf(this._srcTree.Selection))
                    {
                        TreeItemData tocItemData = this._tocTree.GetItemData(tocItemId);
                        if (tocItemData != null && tocItemData.Data is int)
                        {
                            TocNodeData tocNodeData = this._toc.TocFiles.GetLeafNodeData((int)tocItemData.Data);
                            if (tocNodeData != null)
                                tocNodeData.Compression = srcData.Compression;
                        }
                    }
                }
            }
        }

        /// <summary>
        /// This will be called if the text in the text field on resource names in the TOC tree changes.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="evt"></param>
        void OnChangeResourceNameInToc(object sender, Event evt)
        {
            CommandEvent cevt = evt as CommandEvent;
            if (cevt != null && cevt.String.Length > 0)
            {
                TreeItemData tocDataId = this._tocTree.GetItemData(this._tocTree.Selection);
                if (tocDataId != null && tocDataId.Data is int)
                {
                    TocNodeData resData = this._toc.TocFiles.GetLeafNodeData((int)tocDataId.Data);
                    if (resData != null)
                    {
                        resData.NameInRes = cevt.String;
                        TreeItemId srcItemId = this.SrcNodeToTocLeaf(this._tocTree.Selection);
                        if (srcItemId != null)
                        {
                            TreeItemData srcItemData = this._srcTree.GetItemData(srcItemId);
                            if (srcItemData != null && srcItemData.Data is int)
                            {
                                SrcLeafData srcNodeData = this._toc.SrcFiles.GetLeafNodeData((int)srcItemData.Data);
                                srcNodeData.NameInRes = resData.NameInRes;
                            }
                        }
                    }
                }
            }
        }

        /// <summary>
        /// This will be called if the text in the text field on resource names in the SRC tree changes.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="evt"></param>
        void OnChangeResourceNameInSrcTree(object sender, Event evt)
        {
            CommandEvent cevt = evt as CommandEvent;
            if (cevt != null && cevt.String.Length > 0)
            {
                TreeItemData srcDataId = this._srcTree.GetItemData(this._srcTree.Selection);
                if (srcDataId != null && srcDataId.Data is int)
                {
                    SrcLeafData resData = this._toc.SrcFiles.GetLeafNodeData((int)srcDataId.Data);
                    if (resData != null)
                    {
                        resData.NameInRes = cevt.String;
                        foreach (TreeItemId tocItemId in this.TocNodeToSrcLeaf(this._srcTree.Selection))
                        {
                            TreeItemData tocItemData = this._tocTree.GetItemData(tocItemId);
                            if (tocItemData != null && tocItemData.Data is int)
                            {
                                TocNodeData tocNodeData = this._toc.TocFiles.GetLeafNodeData((int)tocItemData.Data);
                                if (tocNodeData != null)
                                    tocNodeData.NameInRes = resData.NameInRes;
                            }
                        }
                    }
                }
            }
        }

        void OnBuildProjectInSrcTree(object sender, Event evt)
        {
            TreeItemId selectedNode = this._srcTree.Selection;
            TreeItemData selectedData = this._srcTree.GetItemData(selectedNode);
            if (selectedData != null && selectedData.Data is int)
            {
                int nodeDataIndex = (int)selectedData.Data;
                SrcNodeData selectedNodeData = this._toc.SrcFiles.GetTreeNodeData(nodeDataIndex);
                if (selectedNodeData != null && selectedNodeData.ProjectRef != null)
                {
                    this.Make(selectedNodeData.Project, false);
                }
            }
        }

        void OnRebuildProjectInSrcTree(object sender, Event evt)
        {
            TreeItemId selectedNode = this._srcTree.Selection;
            TreeItemData selectedData = this._srcTree.GetItemData(selectedNode);
            if (selectedData != null && selectedData.Data is int)
            {
                int nodeDataIndex = (int)selectedData.Data;
                SrcNodeData selectedNodeData = this._toc.SrcFiles.GetTreeNodeData(nodeDataIndex);
                if (selectedNodeData != null && selectedNodeData.ProjectRef != null)
                {
                    this.Make(selectedNodeData.Project, true);
                }
            }
        }

        void NormalizeNamesAfterSave()
        {
            this._unsavedchanges = false;
            #region Normalization of names.
            foreach (TreeItemId id in this._srcTree.GetAllItems())
            {
                TreeItemData data = this._srcTree.GetItemData(id);
                int index = 0;
                if (data != null && data.Data != null)
                    index = (int)data.Data;
                if (this._toc.SrcFiles.ContainsLeafNode(index))
                    this._srcTree.SetItemText(id, this._toc.SrcFiles.GetLeafNodeData(index).File.BaseFileName);
                else if (index == 0)
                {
                    // this is the root node. do nothing here
                }
                else if (this._toc.SrcFiles.ContainsTreeNode(index))
                {
                    SrcNodeData nodeData = this._toc.SrcFiles.GetTreeNodeData(index);
                    if (nodeData.File != null)
                        this._srcTree.SetItemText(id, nodeData.File.BaseFileName);
                    if (nodeData.ProjectRef != null)
                        this._srcTree.SetItemText(id, nodeData.Project.Name);
                }
            }
            foreach (TreeItemId id in this._tocTree.GetAllItems())
            {
                if (id != this._tocTree.RootItem)
                {
                    string label = this._tocTree.GetItemText(id);
                    if (label != null && label.StartsWith("*"))
                        this._tocTree.SetItemText(id, label.Substring(1));
                }
            }
            #endregion
        }

        void OnSaveProject(object sender, Event evt)
        {
            if (this.CurrentPackageFile == null
                || !Build.ContentType.PackageBuilderProject.SuffixComplies(this.CurrentPackageFile))
            {
                FileSelector s = new FileSelector(_("Select the project file"), System.AppDomain.CurrentDomain.BaseDirectory,
                    "wx.NET", ".pkgproj", "PackageBuilder project files (*.pkgproj)|*.pkgproj", WindowStyles.FD_SAVE | WindowStyles.FD_CHANGE_DIR, this);
                if (s.Value.Length == 0)
                    return;
                this.CurrentPackageFile = s.Value;
            }
            string useName=this.CurrentPackageFile;
            if (!Build.ContentType.PackageBuilderProject.SuffixComplies(this.CurrentPackageFile))
            {
                string directory = System.IO.Path.GetDirectoryName(useName);
                useName=System.IO.Path.GetFileNameWithoutExtension(useName)+".pkgproj";
                useName = System.IO.Path.Combine(directory, useName);
            }
            try
            {
                string relativeToDir = System.IO.Path.GetDirectoryName(useName);
                using (wx.BusyInfo info=new wx.BusyInfo(_("Saving project {0}.", useName)))
                {
                  this._toc.NormalizeOriginalFileNames(relativeToDir);
                  using (System.Xml.XmlTextWriter w = new System.Xml.XmlTextWriter(useName, Encoding.UTF8))
                  {
                      if (this._menuItemCheckedCompactForm.Checked)
                          w.Formatting = System.Xml.Formatting.None;
                      else
                          w.Formatting = System.Xml.Formatting.Indented;
                      this._toc.WriteXml(w);
                  }
                  this.NormalizeNamesAfterSave();
                }
                wx.Log.LogMessage("Saved project with {0} source nodes and {1} nodes to install.",
                    this._toc.SrcFiles.CountLeafNodes,
                    this._toc.TocFiles.CountLeafNodes);
            }
            catch (Exception exc)
            {
                MessageDialog.ShowModal(this, _("Error on saving file {0}.\n{1}", this.CurrentPackageFile, exc.Message),
                    _("Error"), WindowStyles.ICON_ERROR | WindowStyles.DIALOG_OK);
            }
        }

        void OnSavePackage(object sender, Event evt)
        {
            if (this.CurrentPackageFile == null ||
                !Build.ContentType.PackageBuilderPackage.SuffixComplies(this.CurrentPackageFile))
            {
                FileSelector s = new FileSelector(_("Select the project file"), System.AppDomain.CurrentDomain.BaseDirectory,
                    "wx.NET", ".package", "PackageBuilder package files (*.package)|*.package", WindowStyles.FD_SAVE | WindowStyles.FD_OVERWRITE_PROMPT, this);
                if (s.Value.Length == 0)
                    return;
                this.CurrentPackageFile = s.Value;
            }
            try
            {
                Build.ErrorHandler errorHandler = delegate(Build.ErrorObject errObj)
                {
                    this._infoNotebook.Selection = 1;
                    this._logWindow.AppendText(errObj.ToString() + "\n");
                    wx.App.TheApp.SafeYield();
                };

                this._toc.Save(errorHandler, this.CurrentPackageFile);
                this.NormalizeNamesAfterSave();
            }
            catch (Exception exc)
            {
                MessageDialog.ShowModal(this, _("Error on saving file {0}.\n{1}", this.CurrentPackageFile, exc.Message),
                    _("Error"), WindowStyles.ICON_ERROR | WindowStyles.DIALOG_OK);
            }
        }

        void OnSavePackageAs(object sender, Event evt)
        {
            this.CurrentPackageFile = null;
            this.OnSavePackage(sender, evt);
        }

        /// <summary>
        /// Handler of the close event. Will ask on unsaved changes.
        /// </summary>
        /// <param name="sender">The sender of the event. Typically, this is a wx.Window.</param>
        /// <param name="evt">The event. In this case, this should be a wx.CloseEvent.</param>
        public void OnCloseEvent(object sender, Event evt)
        {
            CloseEvent cevt = evt as CloseEvent;
            if (cevt != null && cevt.CanVeto && this._unsavedchanges)
            {
                ShowModalResult result = MessageDialog.ShowModal(this,
                    _("Closing the application with unsaved changes.\nPress \"OK\" to exit the application. The application will remain open on \"Cancel\"."),
                    _("Warning"), WindowStyles.DIALOG_OK | WindowStyles.DIALOG_CANCEL | WindowStyles.ICON_WARNING);
                if (result != ShowModalResult.OK)
                    cevt.Veto();
            }
            cevt.Skip(!cevt.GetVeto);
        }

        void OnOpenPackage(object sender, Event evt)
        {
            if (this._unsavedchanges)
            {
                ShowModalResult result = MessageDialog.MessageBox(_("Some changes to the current projects have not yet been safed.\nPress OK if you want to loose these changes.\nCancel the operation otherwise."),
                    _("Warning"),
                    WindowStyles.DIALOG_OK | WindowStyles.DIALOG_CANCEL | WindowStyles.ICON_WARNING,
                    this);
                if (result != ShowModalResult.OK)
                    return;
            }
            FileSelector s = new FileSelector(_("Select the project file"), System.AppDomain.CurrentDomain.BaseDirectory,
                "wx.NET", ".package", _("PackageBuilder projects (*.pkgproj)|*.pkgproj|wx.NET package files (*.package)|*.package"), WindowStyles.FD_OPEN, this);
            if (s.Value.Length == 0)
                return;

            if (Build.ContentType.PackageBuilderProject.SuffixComplies( s.Value ))
            {
                this.OpenPackageFile(s.Value, null);
            }
            else
            {
                Config.Get().Path = "/UnpackedFiles";
                string defaultDestination = Config.Get().Read("lastDestination",
                    System.IO.Path.Combine(System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "wxPackager"));
                if (!System.IO.Directory.Exists(defaultDestination))
                    System.IO.Directory.CreateDirectory(defaultDestination);
                DirSelector d = new DirSelector(_("Select the directory where the package data will be restored."),
                    defaultDestination, WindowStyles.DD_DEFAULT_STYLE);
                if (d.Value.Length == 0)
                    return;
                Config.Get().Write("lastDestination", System.IO.Path.GetDirectoryName(d.Value));
                Config.Get().Flush();
                this.OpenPackageFile(s.Value, d.Value);
            }
        }

        void OnNewPackage(object sender, Event evt)
        {
            if (this._unsavedchanges)
            {
                ShowModalResult result = MessageDialog.MessageBox(_("Some changes to the current projects have not yet been safed.\nPress OK if you want to loose these changes.\nCancel the operation otherwise."),
                    _("Warning"),
                    WindowStyles.DIALOG_OK | WindowStyles.DIALOG_CANCEL | WindowStyles.ICON_WARNING,
                    this);
                if (result != ShowModalResult.OK)
                    return;
            }
            this.CurrentPackageFile = null;
            this.InitSrcTreeData();
        }

        void OnLoadOneOfTheLastPackages(object sender, Event evt)
        {
            try
            {
                int fileindex = evt.ID - ((int)MenuEntries.LoadLastPkg0);
                string loadFile = this._lastPkgsInUse[fileindex];
                if (Build.ContentType.PackageBuilderProject.SuffixComplies(loadFile))
                {
                    this.OpenPackageFile(loadFile, null);
                }
                else
                {
                    Config.Get().Path = "/UnpackedFiles";
                    string defaultDestination = Config.Get().Read("lastDestination",
                        System.IO.Path.Combine(System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "wxPackager"));
                    if (!System.IO.Directory.Exists(defaultDestination))
                        System.IO.Directory.CreateDirectory(defaultDestination);
                    DirSelector d = new DirSelector(_("Select the directory where the package data will be restored."),
                        defaultDestination, WindowStyles.DD_DEFAULT_STYLE);
                    if (d.Value.Length == 0)
                        return;
                    Config.Get().Write("lastDestination", System.IO.Path.GetDirectoryName(d.Value));
                    Config.Get().Flush();
                    this.OpenPackageFile(loadFile, d.Value);
                }
            }
            catch (Exception exc)
            {
                Log.LogError(exc.Message);
                wx.Utils.Bell();
            }
        }

        void OnAbout(object sender, Event evt)
        {
            wx.Frame frame = new AboutBox(this);
            frame.Show(true);
        }
        #endregion

        #region Source Tree
        void OnPopupSrcTree(object sender, Event evt)
        {
            Build.ContentFile current = this.GetSelectedSrcFile();
            Menu popup = new Menu();
            if (current != null && current.Type == Build.ContentType.Directory)
            {
                popup.Append(MenuEntries.LoadDirectoryFiles);
            }
            popup.Append(MenuEntries.CopySrcToPkg);
            popup.Append(MenuEntries.Remove);
            SrcNodeData fullData = this.GetSelectedSrcData();
            if (fullData != null
                && fullData.ProjectRef != null)
            {
                if (!fullData.Project.TargetsAreConsistent(DateTime.MinValue))
                    popup.Append(MenuEntries.BuildProjectInSrcTree);
                popup.Append(MenuEntries.RebuildProjectInSrcTree);
            }
            this._srcTree.PopupMenu(popup);
        }

        void OnLoadDirectoryFiles(object sender, Event evt)
        {
            TreeEvent tevt=evt as TreeEvent;
            if (tevt != null)
                this.LoadDirectoryFiles(tevt.Item);
            else
                this.LoadDirectoryFiles(this._srcTree.Selection);
        }

        /// <summary>
        /// A custom event type that causes an update of all projects after all open events have been handled.
        /// </summary>
        class ProjectUpdateEvent : wx.CommandEvent
        {
            public static readonly int EVT_ID = wx.Event.AddEventType(typeof(ProjectUpdateEvent));

            public ProjectUpdateEvent()
                : base(EVT_ID)
            {
            }

            public ProjectUpdateEvent(IntPtr wxobj)
                : base(wxobj)
            {
            }
        }

        /// <summary>
        /// Adds a pending ProjectUpdateEvent.
        /// </summary>
        void CausePendingUpdateOfAllProjects()
        {
            this.AddPendingEvent(new ProjectUpdateEvent());
        }

        void OnPendingUpdateEvent(object sender, wx.Event evt)
        {
            this._srcTree.Selection = this._srcTree.RootItem;
            this._srcTree.EnsureVisible(this._srcTree.RootItem);
            this.UpdateAllProjects();
        }

        /// <summary>
        /// Recursively searches for projects in the source tree view and calls
        /// UpdateProject() for each node referring to a project.
        /// </summary>
        void UpdateAllProjects()
        {
            this.UpdateAllProjects(this._srcTree.RootItem);
        }

        /// <summary>
        /// Recursively searches for projects in the source tree view and calls
        /// UpdateProject() for each node referring to a project.
        /// </summary>
        /// <param name="rootOfSearch">This method will be search for node referring
        /// to projects among the siblings of this node.</param>
        void UpdateAllProjects(TreeItemId rootOfSearch)
        {
            TreeItemId[] children = this._srcTree.GetChildren(rootOfSearch);
            if (children != null)
            {
                foreach (TreeItemId child in children)
                {
                    if (!this.UpdateProject(child))
                        this.UpdateAllProjects(child);
                }
            }
        }

        /// <summary>
        /// Updates the source tree view and the TOC data of the subtree
        /// with the specified node as root. This root shall be a source
        /// tree node referring to a wx.Build.BuildProject.
        /// The effect will be: Remove the subtree in dialog and data model.
        /// Add the subtree again.
        /// </summary>
        /// <param name="nodeWithProject">Shall designate a node in the source tree
        /// view that is associated with a SrcNodeData referring to a build project.</param>
        /// <returns>True iff node data referring to a build project has been found.</returns>
        bool UpdateProject(TreeItemId nodeWithProject)
        {
            int indexOfTreeData=(int)this._srcTree.GetItemData(nodeWithProject).Data;
            SrcNodeData nodeData = this._toc.SrcFiles.GetTreeNodeData(indexOfTreeData);
            if (nodeData != null && nodeData.ProjectRef != null)
            {
                TreeItemId parent = this._srcTree.GetItemParent(nodeWithProject);

                Build.BuildProject p = nodeData.Project;
                this._srcTree.Delete(nodeWithProject);
                this._toc.SrcFiles.RemoveNode(indexOfTreeData);

                this.AddProject(parent, p);
                return true;
            }
            return false;
        }

        /// <summary>
        /// Finds or creates a subnode of the provided parent node containing all nodes referring to
        /// a certain platform.
        /// </summary>
        /// <param name="parent">The parent node that shall contain files of the provided platform</param>
        /// <param name="platform">The platform</param>
        /// <returns></returns>
        TreeItemId FindOrCreatePlatformSrcNode(TreeItemId parent, PlatformDescr platform)
        {
            foreach (TreeItemId child in this._srcTree.GetChildren(parent))
            {
                TreeItemData childNodeData = this._srcTree.GetItemData(child);
                if (childNodeData != null && childNodeData.Data is int)
                {
                    SrcNodeData childData = this._toc.SrcFiles.GetTreeNodeData((int)childNodeData.Data);
                    if (childData != null
                        && childData.FolderType == KindOfSrcFolder.Platform
                        && childData.Platform != null
                        && childData.Platform.Equals(platform))
                    {
                        return child;
                    }
                }
            }
            // Create a new node.
            SrcNodeData newData = new SrcNodeData(KindOfSrcFolder.Platform);
            newData.Platform = platform;
            TreeItemData parentNodeData = this._srcTree.GetItemData(parent);
            int newDataTreeNode=this._toc.SrcFiles.AddNode((int)parentNodeData.Data, newData);
            TreeItemId newNodeId = this._srcTree.AppendItem(parent, platform.OsVersion.Platform.ToString(), 13, 13);
            this._srcTree.SetItemData(newNodeId, new TreeItemData(newDataTreeNode));
            return newNodeId;
        }

        /// <summary>
        /// Removes the designated SRC tree item from the control and the associated data mode.
        /// </summary>
        /// <param name="srcItemId">Designates a tree item in the SRC tree item list.</param>
        void DeleteSrcNode(TreeItemId srcItemId)
        {
            TreeItemData data = this._srcTree.GetItemData(srcItemId);
            if (data != null && data.Data is int)
            {
                SrcNodeData tocData = this._toc.SrcFiles.GetTreeNodeData((int)data.Data);
                if (tocData != null && tocData.Project != null)
                {
                    this.InitSrcTreeData();
                }
                else
                    this._toc.SrcFiles.RemoveNode((int)data.Data);
            }
            this._srcTree.Delete(srcItemId);
            if (this._srcTree.Count == 0)
                this.InitSrcTreeData();
            this._unsavedchanges = true;
        }

        /// <summary>
        /// This will create a new node referring to a file and add it to the designated control and tree model.
        /// Each file can be added at most once to the same parent. All further calls to this method will return
        /// the designator of the preexisting node referring to the provided source file.
        /// </summary>
        /// <param name="parent">ID of the parent node in the designated control</param>
        /// <param name="platform">describes the platform that the file is assumed to depend on. This will only
        /// be used if the file is presumably platform dependant (type has property wx.Build.ContentFileProperties.DependsOnOSAndProcessor).
        /// This may be <c>null</c>. If <c>null</c> but platform required, this will use the description of the current platform.
        /// </param>
        /// <param name="file">The file that shall be described by the node</param>
        /// <param name="image">Image that shall be displayed in the tree control</param>
        /// <param name="selImage">The image that shall be displayed if the node has been selected.</param>
        /// <param name="p">If the file refers to a project, than this is a reference to this project. Otherwise this is <c>null</c>.</param>
        /// <param name="unsafedChange">True iff this represents an unsafed change.</param>
        TreeItemId AddSrcFileNode(TreeItemId parent, PlatformDescr platform, Build.ContentFile file, Build.RefToProject p, int image, int selImage, bool unsafedChange)
        {
            TreeItemData parentItemData = this._srcTree.GetItemData(parent);
            if (parentItemData == null || !(parentItemData.Data is int))
                return null;

            #region create node for platform dependency if necessary
            if ((file.Type.Properties & wx.Build.ContentFileProperties.DependsOnOSAndProcessor) == wx.Build.ContentFileProperties.DependsOnOSAndProcessor)
            {
                // we need a platform node.
                if (platform == null)
                    platform = PlatformDescr.GetCurrent();
                parent = this.FindOrCreatePlatformSrcNode(parent, platform);
                parentItemData = this._srcTree.GetItemData(parent);
            }
            #endregion

            #region Maybe parent already has a child referring to the file to be added
            foreach (TreeItemId child in this._srcTree.GetChildren(parent))
            {
                TreeItemData childDataId=this._srcTree.GetItemData(child);
                if (childDataId.Data is int)
                {
                    SrcLeafData childData = this._toc.SrcFiles.GetLeafNodeData((int)childDataId.Data);
                    if (childData != null)
                    {
                        if (childData.File != null && childData.File.Equals(file))
                            return child; // file already contained by the tree. return the node that contains
                                         // the file.
                    }
                }
            }
            #endregion

            string prefix = "";
            if (unsafedChange)
                prefix = "*";
            TreeItemId newFileNodeId = this._srcTree.AppendItem(parent, prefix+file.BaseFileName, 1, 2);
            SrcLeafData newdata = new SrcLeafData(file, p);
            if ((file.Type.Properties & wx.Build.ContentFileProperties.NetCodeObj) == wx.Build.ContentFileProperties.NetCodeObj)
                newdata.NetFramework = new NetFrameworkDescr();
            if ((file.Type.Properties & wx.Build.ContentFileProperties.DependsOnOSAndProcessor) == wx.Build.ContentFileProperties.DependsOnOSAndProcessor)
                newdata.Platform = platform;
            int newFileNode = this._toc.SrcFiles.AddLeafNode((int)parentItemData.Data, newdata);
            this._srcTree.SetItemData(newFileNodeId, new TreeItemData(newFileNode));
            return newFileNodeId;
        }

        /// <summary>
        /// Adds the project to the source tree list and the corresponding model in the 
        /// TOC tree.
        /// </summary>
        /// <param name="parentNode">This is the pre-existing node in the source tree list that will
        /// be parent of the new nodes.</param>
        /// <param name="p">The build project whose sources, targets, and eventually shadow projects will be 
        /// added.</param>
        void AddProject(TreeItemId parentNode, Build.BuildProject p)
        {
            // Add this project to the resident projects.
            Build.BuildProject.AddKnownProject(p);
            Build.RefToProject refToP = p.CreateRef();

            int indexOfParentNode = (int)this._srcTree.GetItemData(parentNode).Data;
            TreeItemId newProjectNodeId = this._srcTree.AppendItem(parentNode, p.Name, 6);
            int newProjectNode = this._toc.SrcFiles.AddNode(indexOfParentNode, new SrcNodeData(refToP));
            this._srcTree.SetItemData(newProjectNodeId, new TreeItemData(newProjectNode));
            this._srcTree.EnsureVisible(newProjectNodeId);

            #region Sources
            int newSrcNode = this._toc.SrcFiles.AddNode(newProjectNode, new SrcNodeData(KindOfSrcFolder.Source));
            TreeItemId newSrcNodeId = this._srcTree.AppendItem(newProjectNodeId, SrcNodeData.FolderTypeToString(KindOfSrcFolder.Source), 4);
            this._srcTree.SetItemData(newSrcNodeId, new TreeItemData(newSrcNode));
            foreach (Build.IBuildProduct prereq in p.GetPrerequisites())
            {
                if (prereq is Build.IFileProducts && !(prereq is Build.RefToFileProject))
                {
                    Build.ContentFiles prereqFiles = ((Build.IFileProducts)prereq).Files;
                    foreach (Build.ContentFile prereqFile in prereqFiles)
                    {
                        if (prereqFile.Location == wx.Build.ContentFileLocation.LocalFileSystem)
                        {
                            prereqFile.NormalizeOriginalFileName(this.CurrentPackageFile);
                            this.AddSrcFileNode(newSrcNodeId, null, prereqFile, refToP, 1, 2, true);
                        }
                    }
                }
                else if (prereq is Build.ResourceDesignator)
                {
                    Build.ResourceDesignator rd = prereq as Build.ResourceDesignator;
                    rd.ResourceFile.NormalizeOriginalFileName(this.CurrentPackageFile);
                    this.AddSrcFileNode(newSrcNodeId, null, rd.ResourceFile, refToP, 1, 2, true);
                }
            }
            #endregion
            #region Targets
            int newTargetNode = this._toc.SrcFiles.AddNode(newProjectNode, new SrcNodeData(KindOfSrcFolder.Target));
            TreeItemId newTargetNodeId = this._srcTree.AppendItem(newProjectNodeId, SrcNodeData.FolderTypeToString(KindOfSrcFolder.Target), 4);
            this._srcTree.SetItemData(newTargetNodeId, new TreeItemData(newTargetNode));
            foreach (Build.IBuildProduct target in p.GetTargets())
            {
                if (target is Build.IFileProducts && !(target is Build.RefToFileProject))
                {
                    Build.ContentFiles targetFiles = ((Build.IFileProducts)target).Files;
                    foreach (Build.ContentFile targetFile in targetFiles)
                    {
                        if (targetFile.Location == wx.Build.ContentFileLocation.LocalFileSystem)
                        {
                            
                            targetFile.NormalizeOriginalFileName(this.CurrentPackageFile);
                            this.AddSrcFileNode(newTargetNodeId, null, targetFile, refToP, 1, 2, true);
                        }
                    }
                }
            }
            #endregion
            #region Shadow Projects
            if (p is Build.Release.MakeReleaseProject)
            {
                Build.Release.MakeReleaseProject releaseP = (Build.Release.MakeReleaseProject)p;
                if (releaseP.ShadowCSharpProjects.Count > 0
                    || releaseP.ShadowDllProjects.Count > 0)
                {
                    int newShadowProject = this._toc.SrcFiles.AddNode(newProjectNode, new SrcNodeData(KindOfSrcFolder.ShadowProjects));
                    TreeItemId newShadowProjectId = this._srcTree.AppendItem(newProjectNodeId, SrcNodeData.FolderTypeToString(KindOfSrcFolder.ShadowProjects), 4);
                    this._srcTree.SetItemData(newShadowProjectId, new TreeItemData(newShadowProject));
                    #region CSharp DLL projects
                    if (releaseP.ShadowCSharpProjects.Count > 0)
                    {
                        int newCSharpProject = this._toc.SrcFiles.AddNode(newShadowProject, new SrcNodeData(KindOfSrcFolder.CSharpProjects));
                        TreeItemId newCSharpProjectId = this._srcTree.AppendItem(newShadowProjectId, SrcNodeData.FolderTypeToString(KindOfSrcFolder.CSharpProjects), 4);
                        this._srcTree.SetItemData(newCSharpProjectId, new TreeItemData(newCSharpProject));
                        foreach (KeyValuePair<Build.Net.CSharpAssemblyProject, Build.Net.CSharpAssemblyProject>
                            pPair in releaseP.ShadowCSharpProjects)
                        {
                            this.AddProject(newCSharpProjectId, pPair.Value);
                        }
                    }
                    #endregion
                    #region Native C/C++ DLL project
                    if (releaseP.ShadowDllProjects.Count > 0)
                    {
                        int newCppProject = this._toc.SrcFiles.AddNode(newShadowProject, new SrcNodeData(KindOfSrcFolder.CPlusPlusProjects));
                        TreeItemId newCppProjectId = this._srcTree.AppendItem(newShadowProjectId, SrcNodeData.FolderTypeToString(KindOfSrcFolder.CPlusPlusProjects), 4);
                        this._srcTree.SetItemData(newCppProjectId, new TreeItemData(newCppProject));
                        foreach (KeyValuePair<Build.Cxx.DynamicLibraryProject, Build.Cxx.DynamicLibraryProject>
                            pPair in releaseP.ShadowDllProjects)
                        {
                            this.AddProject(newCppProjectId, pPair.Value);
                        }
                    }
                    #endregion
                }
            }
            #endregion

        }

        /// <summary>
        /// The user selects an assembly containing instances of wx.Build.BuildProject. These projects will
        /// be added to the source tree and the source tree model in the TOC.
        /// </summary>
        /// <param name="sender">The sender of the event.</param>
        /// <param name="evt">The event</param>
        void OnLoadProjects(object sender, Event evt)
        {
            FileSelector s = new FileSelector(_("Select a .NET assembly containing wx.Build projects."), ".", "", "exe", _("Assembly with wx.Build projects (*.dll)|*.dll|Assembly with wx.Build projects (*.exe)|*.exe"));
            try
            {
                if (s.Value.Length > 0)
                {
                    this._infoNotebook.Selection = 1;
                    wx.Log.LogMessage(_("Loading projects from assembly {0}."), s.Value);
                    string oldPathRoot = wx.Build.BuildConfig.PathRoot;
                    try
                    {
                        wx.Utils.BeginBusyCursor();
                        using (BusyInfo info = new BusyInfo(_("Loading projects from assembly {0}", s.Value), this))
                        {
                            this._allUsedEnvVars = null;
                            string newPathRoot = System.IO.Path.GetDirectoryName(s);
                            if (newPathRoot != wx.Build.BuildConfig.PathRoot)
                                wx.Build.BuildConfig.PathRoot = newPathRoot;
                            System.Reflection.Assembly assembly = System.Reflection.Assembly.LoadFrom(s);
                            ICollection<Build.BuildProject> allProjects = wx.Build.BuildProject.GetAllProjectsDeclaredInAssembly(assembly, null);
                            Dictionary<Build.BuildProject, Build.BuildProject> setOfLoadedProject = new Dictionary<wx.Build.BuildProject, wx.Build.BuildProject>();
                            foreach (Build.BuildProject p in allProjects)
                                setOfLoadedProject[p] = p;
                            foreach (Build.BuildProject p in allProjects)
                            {
                                foreach (Build.IBuildProduct prereq in p.GetPrerequisites())
                                {
                                    ICollection<Build.RefToProject> prereqProjects = prereq.GetProjects();
                                    if (prereqProjects != null)
                                    {
                                        foreach (Build.RefToProject prereqProject in prereqProjects)
                                        {
                                            if (!setOfLoadedProject.ContainsKey(prereqProject.Project))
                                            {
                                                wx.Log.LogMessage(_("Also include project \"{0}\" as prerequisite of \"{1}\".", prereqProject.Project.Name, p.Name));
                                                setOfLoadedProject.Add(prereqProject.Project, prereqProject.Project);
                                            }
                                            App.TheApp.SafeYield();
                                        }
                                    }
                                }
                            }

                            foreach (Build.BuildProject p in setOfLoadedProject.Values)
                            {
                                wx.Log.LogMessage(_("Importing project {0}: {1}.", p.Name, p.Description));
                                this.AddProject(this._srcTree.RootItem, p);
                            }
                            this._srcTree.EnsureVisible(this._srcTree.RootItem);
                        }
                    }
                    finally
                    {
                        if (oldPathRoot != wx.Build.BuildConfig.PathRoot)
                            wx.Build.BuildConfig.PathRoot = oldPathRoot;
                        wx.Utils.EndBusyCursor();
                    }
                }
            }
            catch (Exception exc)
            {
                MessageDialog.ShowModal(this, exc.Message, _("Error"), WindowStyles.DIALOG_OK | WindowStyles.ICON_ERROR);
            }
        }

        void OnLoadDirectory(object sender, Event evt)
        {
            DirSelector s = new DirSelector(_("Select a directory"), System.AppDomain.CurrentDomain.BaseDirectory,
                WindowStyles.FD_FILE_MUST_EXIST, this);
            string dir = s.Value;
            if (dir.Length > 0)
            {
                int newNodeIndex = this._toc.SrcFiles.AddNode(0, new SrcNodeData(new Build.ContentFile(Build.ContentType.Directory, dir)));
                TreeItemId newNode=this._srcTree.AppendItem(this._srcTree.RootItem, "*"+System.IO.Path.GetFileName(dir), 4, 4, new TreeItemData(newNodeIndex));
                this._srcTree.EnsureVisible(newNode);
                this._unsavedchanges = true;

                this.LoadDirectoryFiles(newNode);
            }
        }

        void OnLoadPkgProj(object sender, Event evt)
        {
            string wildcard = _("PackageBuilder projects (*.pkgproj)|*.pkgproj");
            FileDialog d = new FileDialog(this, _("Enter the files to be added to the installation package."),
                ".", "", wildcard,
                WindowStyles.FD_MULTIPLE | WindowStyles.FD_OPEN | WindowStyles.FD_FILE_MUST_EXIST);
            ShowModalResult r = d.ShowModal();
            if (r == ShowModalResult.OK)
                this.OpenPackageFile(d.Path, null);
        }

        /// <summary>
        /// Implements the menu action for loading a single file.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="evt"></param>
        void OnLoadFile(object sender, Event evt)
        {
            string wildcard = _("PackageBuilder projects (*.pkgproj)|*.pkgproj|PackageBuilder packages (*.package)|*.package|DLLs (*.dll)|*.dll|Executables (*.exe)|*.exe|LUA files (*.lua)|*.lua|C# files (*.cs)|*.cs|C++ files (*.cxx)|*.cxx|all files (*.*)|*.*");
            PackagerApp app=wx.App.TheApp as PackagerApp;
            if (app != null)
            {
                wildcard = Build.ContentType.CreateFileDialogWildcard(app.GetRelevantContentTypes(),
                    new wx.Build.ContentType.Translator(Object._));
                if (wildcard.Length > 0)
                    wildcard = "|" + wildcard;
                wildcard = _("all files (*.*)|*.*|PackageBuilder projects (*.pkgproj)|*.pkgproj|PackageBuilder packages (*.package)|*.package") + wildcard;
            }
            FileDialog d=new FileDialog(this, _("Enter the files to be added to the installation package."),
                ".", "", wildcard,
                WindowStyles.FD_MULTIPLE | WindowStyles.FD_OPEN | WindowStyles.FD_FILE_MUST_EXIST);
            ShowModalResult r = d.ShowModal();
            if (r == ShowModalResult.OK)
            {
                if (d.Paths.Length == 1
                    && Build.ContentType.PackageBuilderProject.SuffixComplies(d.Path))
                {
                    this.OpenPackageFile(d.Path, null);
                }
                else if (d.Paths.Length == 1
                    && Build.ContentType.PackageBuilderPackage.SuffixComplies(d.Path))
                {
                    Config.Get().Path = "/UnpackedFiles";
                    string defaultDestination = Config.Get().Read("lastDestination",
                        System.IO.Path.Combine(System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "wxPackager"));
                    if (!System.IO.Directory.Exists(defaultDestination))
                        System.IO.Directory.CreateDirectory(defaultDestination);
                    DirSelector target = new DirSelector(_("Select the directory where the package data will be restored."),
                        defaultDestination, WindowStyles.DD_DEFAULT_STYLE);
                    if (target.Value.Length == 0)
                        return;
                    Config.Get().Write("lastDestination", System.IO.Path.GetDirectoryName(target.Value));
                    Config.Get().Flush();
                    this.OpenPackageFile(d.Path, target.Value);
                }
                else
                    this.LoadSrcFiles(d.Paths);
            }
        }

        void OnDeleteCurrentSrcNode(object sender, Event evt)
        {
            if (this._srcTree.Count > 0 && Window.FindFocus() == this._srcTree)
            {
                this.DeleteSrcNode(this._srcTree.Selection);
            }
            else if (this._tocTree.Count > 0 && Window.FindFocus() == this._tocTree)
            {
                TreeItemId selection = this._tocTree.Selection;
                TreeItemData data = this._tocTree.GetItemData(selection);
                if (data != null && data.Data is int)
                {
                    this._toc.TocFiles.RemoveNode((int)data.Data);
                }
                this._tocTree.Delete(selection);
                if (this._tocTree.Count == 0)
                    this.InitTocTreeData();
                this._unsavedchanges = true;
            }
        }

        void OnExpandedSrcNode(object sender, Event evt)
        {
            TreeEvent tevt = evt as TreeEvent;
            if (tevt != null)
            {
                int currentImage=this._srcTree.GetItemImage(tevt.Item);
                if (currentImage == 4)
                    this._srcTree.SetItemImage(tevt.Item, 3);
                else if (currentImage == 6)
                    this._srcTree.SetItemImage(tevt.Item, 5);
            }
        }

        void OnCollapsedSrcNode(object sender, Event evt)
        {
            TreeEvent tevt = evt as TreeEvent;
            if (tevt != null)
            {
                int currentImage = this._srcTree.GetItemImage(tevt.Item);
                if (currentImage == 3)
                    this._srcTree.SetItemImage(tevt.Item, 4);
                else if (currentImage == 5)
                    this._srcTree.SetItemImage(tevt.Item, 6);
            }
        }

        void OnConfigContentTypes(object sender, Event evt)
        {
            ContentTypeConfigDialog d = new ContentTypeConfigDialog(this, _("Configure relevant file types"), wxDefaultPosition, wxDefaultSize, WindowStyles.DIALOG_DEFAULT_STYLE);
            ShowModalResult result= d.ShowModal();
            if (result == ShowModalResult.OK)
                d.SaveResults();
        }

        /// <summary>
        /// Toggles visibility of the info window
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="evt"></param>
        void OnToggleVisibilityInfo(object sender, Event evt)
        {
            if (this._topSplitter.IsSplit)
                this._topSplitter.Unsplit();
            else
                this._topSplitter.SplitHorizontally(this._treeListSplitter, this._infoNotebook);
        }
        #endregion

        #region TOC Tree
        void OnPopupTocTree(object sender, Event evt)
        {
            Menu popup = new Menu();
            TreeItemData selectionDataNode = this._tocTree.GetItemData(this._tocTree.Selection);
            if (selectionDataNode != null && selectionDataNode.Data is int)
            {
                TocNodeData selectionDataRecord = this._toc.TocFiles.GetTreeNodeData((int)selectionDataNode.Data);
                if (selectionDataRecord == null)
                    selectionDataRecord = this._toc.TocFiles.GetLeafNodeData((int)selectionDataNode.Data);
                if (selectionDataRecord.FeatureName != null)
                    popup.Append(MenuEntries.EditTocLabel);
                if (selectionDataRecord.SrcNode >= 0)
                    popup.Append(MenuEntries.FindSrcNodeToTocLeaf);
            }
            popup.Append(MenuEntries.Remove);
            this._tocTree.PopupMenu(popup);
        }

        void OnEditTocLabel(object sender, Event evt)
        {
            TreeItemData selectionDataNode = this._tocTree.GetItemData(this._tocTree.Selection);
            if (selectionDataNode != null && selectionDataNode.Data is int)
            {
                TocNodeData selectionDataRecord = this._toc.TocFiles.GetTreeNodeData((int)selectionDataNode.Data);
                if (selectionDataRecord == null)
                    selectionDataRecord = this._toc.TocFiles.GetLeafNodeData((int)selectionDataNode.Data);
                if (selectionDataRecord.FeatureName != null)
                {
                    this._tocTree.EditLabel(this._tocTree.Selection);
                    selectionDataRecord.FeatureName = this._tocTree.GetItemText(this._tocTree.Selection);
                }
            }
        }

        void OnCopySrcToPkg(object sender, Event evt)
        {
            this.AddSrcFileToPkg(this._srcTree.Selection);
        }
        #endregion

        #region Drag From src And Drop Into TOC Tree

        void OnBeginDragSrc(object sender, Event evt)
        {
            TreeItemId selectedNode = this._srcTree.Selection;
            TreeItemData selectedData = this._srcTree.GetItemData(selectedNode);
            if (selectedNode != this._srcTree.RootItem && selectedData.Data is int) // You cannot drag the root node.
            {
                SrcNodeData nodedata=this._toc.SrcFiles.GetTreeNodeData((int)selectedData.Data);
                Build.ContentFile draggedFile=null;
                if (nodedata == null)
                    draggedFile = this._toc.SrcFiles.GetLeafNodeData((int)selectedData.Data).File;
                else
                    draggedFile = nodedata.File;

                /*
                Cursor cursor = new Cursor(StockCursor.wxCURSOR_HAND);
                if (this._stdCursor == null)
                    this._stdCursor = this.Cursor;
                this.Cursor = cursor;
                */
                TextDataObject dragData = new TextDataObject(draggedFile.FileName);
                DropSource dropSrc = new DropSource(dragData, this);
                dropSrc.DoDragDrop(Drag.wxDrag_CopyOnly);
                // in fact, the result is not interesting here, since we will not react
                // on dragging here.
            }
        }

        void OnCollapsedTocNode(object sender, Event evt)
        {
            TreeEvent tevt = evt as TreeEvent;
            if (tevt != null)
            {
                int currentImage = this._tocTree.GetItemImage(tevt.Item);
                if (currentImage == 3)
                    this._tocTree.SetItemImage(tevt.Item, 4);
                else if (currentImage == 5)
                    this._tocTree.SetItemImage(tevt.Item, 6);
            }
        }

        void OnExpandedTocNode(object sender, Event evt)
        {
            TreeEvent tevt = evt as TreeEvent;
            if (tevt != null)
            {
                int currentImage = this._tocTree.GetItemImage(tevt.Item);
                if (currentImage == 4)
                    this._tocTree.SetItemImage(tevt.Item, 3);
                else if (currentImage == 6)
                    this._tocTree.SetItemImage(tevt.Item, 5);
            }
        }
        #endregion

        #region Info Window
        void OnCheckInInfoWindow(object sender, Event evt)
        {
            CommandEvent cevt = evt as CommandEvent;
            wx.Window senderWindow = this.FindWindow(cevt.ID);
            wx.CheckBox checkBox = senderWindow as wx.CheckBox;
            if (cevt != null)
            {
                if (this._allUsedEnvVars != null
                        && cevt.ID >= 20000
                        && cevt.ID < 20000 + this._allUsedEnvVars.Length)
                {
                    Build.EnvironmentVarInfo var = this._allUsedEnvVars[cevt.ID - 20000];
                    bool changed = false;
                    if (checkBox.Is3State())
                    {
                        changed = true;
                        if (checkBox.ThreeStateValue == CheckBoxState.CHECKED)
                            var.Set(true.ToString());
                        else if (checkBox.ThreeStateValue == CheckBoxState.UNCHECKED)
                            var.Set(false.ToString());
                        else
                            changed = false;
                    }
                    else
                    {
                        var.Set(checkBox.Value.ToString());
                        changed = true;
                    }
                    if (changed)
                    {
                        ((PackagerApp)App.TheApp).SetEnvVariable(var.Varname, var.GetAsString());
                        this.CausePendingUpdateOfAllProjects();
                    }
                }
            }
        }

        void OnEnterTextInInfoWindow(object sender, Event evt)
        {
            CommandEvent cevt = evt as CommandEvent;
            if (cevt != null)
            {
                wx.Window senderWindow = this.FindWindow(cevt.ID);
                wx.TextCtrl textCtrl = senderWindow as TextCtrl;
                if (cevt.ID == 19000)
                {
                    PackagerApp app = App.TheApp as PackagerApp;
                    if (app != null)
                        app.PlatformDescription = textCtrl.Value;
                }
                else if (this._allUsedEnvVars != null
                    && cevt.ID >= 20000
                    && cevt.ID < 20000 + this._allUsedEnvVars.Length)
                {
                    Build.EnvironmentVarInfo var = this._allUsedEnvVars[cevt.ID - 20000];
                    string oldValue = var.GetAsString();
                    try
                    {
                        var.Set(textCtrl.Value.Trim());
                        //this._toc.EnvVarAssignments[var.Varname] = textCtrl.Value;
                        ((PackagerApp)App.TheApp).SetEnvVariable(var.Varname, var.GetAsString());
                        this.CausePendingUpdateOfAllProjects();
                    }
                    catch (Exception exc)
                    {
                        MessageDialog.ShowModal(exc.Message, _("Error"), WindowStyles.ICON_ERROR | WindowStyles.DIALOG_OK);
                        var.SafeSet(oldValue);
                    }
                }
            }
        }
        #endregion

        #endregion
    }
}
