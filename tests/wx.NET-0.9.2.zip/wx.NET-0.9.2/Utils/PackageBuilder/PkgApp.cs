/** Build system for wx.NET.
 * 
 * Application to build a self-extracting package.
 * 
 * \file 
 *
 * Copyright 2009 Harald Meyer auf'm Hofe harald_meyer@users.sourceforge.net
 * 
 * Licensed under the wxWidgets license, see LICENSE.txt for details.
 * 
 * $Id: PkgApp.cs,v 1.7 2010/04/23 17:37:17 harald_meyer Exp $
 */

using System;
using System.Collections.Generic;
using System.Resources;

/** An application to create self-extracting and installing packages.
 * \image html pkgbuilder.JPG
 */
namespace wx.PackageBuilder
{
    /// <summary>
    /// The application.
    /// </summary>
    public class PackagerApp : wx.App
    {
        #region State
        wx.Locale _locale=null;
        string _initialPkgFile = null;
        #endregion

        public PackagerApp(string packageFile)
        {
            if (packageFile != null)
                this._initialPkgFile = System.IO.Path.GetFullPath(packageFile);
        }

        /// <summary>
        /// Initializes the application.
        /// </summary>
        /// <returns>True on success to tell the application to proceed</returns>
        public override bool OnInit()
        {
            this.AppName = "PackageBuilder";
            this.VendorName = "wx.NET";

            this.RestoreEnvVariables();
            System.Diagnostics.Trace.Listeners.Add(new wx.LogTraceListener());

            this.GetLocale();
            wx.FileSys.FileSystem.AddHandler(new FileSys.IOStreamFSHandler());

            PkgFrame frame = new PkgFrame();
            frame.Show(true);
            if (this._initialPkgFile != null)
            {
                if (System.IO.File.Exists(this._initialPkgFile))
                    frame.OpenPackageFile(this._initialPkgFile, null);
                else
                    MessageDialog.ShowModal(frame, _("File {0} does not exist.", this._initialPkgFile), _("Error"), WindowStyles.ICON_ERROR | WindowStyles.DIALOG_OK);
            }
            return true;
        }

        /// <summary>
        /// The locale that shall be used within this application.
        /// </summary>
        /// <remarks>
        /// Use something like the following to extract English text strings from the program code:
        /// <code>xgettext.exe -C --force -po -k_ -k__ -o PkgBuilder.pot PgkToc.cs PkgFrame.cs PkgApp.cs</code>
        /// </remarks>
        public Locale GetLocale()
        {
            if (this._locale == null)
            {
                #region Locale
                this._locale = new Locale(Language.wxLANGUAGE_DEFAULT);
                this._locale.AddCatalogLookupPathPrefix("ZRS");
                this._locale.AddCatalogLookupPathPrefix("../ZRS");
                this._locale.AddCatalog("PkgBuilder");
                #endregion
            }
            return this._locale;
        }

        public Config GetConfig()
        {
            return wx.Config.Get();
        }

        /// <summary>
        /// This is the platform description that users may add in the HTML
        /// info to describe the platform that they used to compile projects.
        /// </summary>
        public string PlatformDescription
        {
            get
            {
                this.GetConfig().Path = "/";
                return this.GetConfig().Read("PlatformDescription", "");
            }
            set
            {
                this.GetConfig().Path = "/";
                this.GetConfig().Write("PlatformDescription", value);
                this.GetConfig().Flush();
            }
        }

        /// <summary>
        /// A typically unique identifier of the machine rangind from 0 to 999.999.
        /// Use this to create indices for the platform descriptor.
        /// </summary>
        /// <remarks>
        /// This will be created using a randomizer. Thus, this is not really guaranteed to
        /// be unique.
        /// </remarks>
        public int PlatformID
        {
            get
            {
                this.GetConfig().Path = "/";
                if (this.GetConfig().HasEntry("PlatformID"))
                    return this.GetConfig().Read("PlatformID", 0);
                else
                {
                    System.Random rand=new Random((int)DateTime.Now.Ticks);
                    int newID = rand.Next(1000000);
                    this.GetConfig().Write("PlatformID", newID);
                    this.GetConfig().Flush();
                    return newID;
                }
            }
        }

        /// <summary>
        /// Updates the provided value for the provided environment variable.
        /// The values assigned to variables here will be restored on restarting
        /// the application.
        /// </summary>
        /// <param name="varName">The name of the variable, e.g. INCLUDE</param>
        /// <param name="value">The assigned value like e.g. "c:\MinGW\include".</param>
        public void SetEnvVariable(string varName, string value)
        {
            this.GetConfig().Path = "/EnvVars";
            this.GetConfig().Write(varName, value);
            this.GetConfig().Flush();
        }


        /// <summary>
        /// This will reassign all assignments to environment variables that have been saved
        /// by SetEnvVariable().
        /// </summary>
        public void RestoreEnvVariables()
        {
            this.GetConfig().Path = "/EnvVars";
            foreach (string varName in this.GetConfig().GetEnumerableEntries())
            {
                System.Environment.SetEnvironmentVariable(varName, this.GetConfig().Read(varName, ""));
            }
        }

        /// <summary>
        /// Reads from the configuration the last packages that have been used.
        /// This will for instance be used to set up the corsponding menu entries.
        /// </summary>
        /// <returns>A possibly empty list of file names.</returns>
        public List<string> GetLastPackages()
        {
            this.GetConfig().Path = "/LastPackageFiles";
            List<string> result = new List<string>();
            bool proceed = true;
            if (proceed)
            {
                string pkgname="";
                proceed = this.GetConfig().ReadString("0", ref pkgname);
                if (proceed && System.IO.File.Exists(pkgname))
                    result.Add(pkgname);
            }
            if (proceed)
            {
                string pkgname="";
                proceed = this.GetConfig().ReadString("1", ref pkgname);
                if (proceed && System.IO.File.Exists(pkgname))
                    result.Add(pkgname);
            }
            if (proceed)
            {
                string pkgname="";
                proceed = this.GetConfig().ReadString("2", ref pkgname);
                if (proceed && System.IO.File.Exists(pkgname))
                    result.Add(pkgname);
            }
            if (proceed)
            {
                string pkgname="";
                proceed = this.GetConfig().ReadString("3", ref pkgname);
                if (proceed && System.IO.File.Exists(pkgname))
                    result.Add(pkgname);
            }
            return result;
        }

        /// <summary>
        /// Reads the collection of relevant content types from the configuration.
        /// 
        /// </summary>
        /// <returns></returns>
        public ICollection<Build.ContentType> GetRelevantContentTypes()
        {
            List<Build.ContentType> result = new List<wx.Build.ContentType>();
            GetConfig().Path = "/ContentTypes";
            // In this path we will have some group entries representing the primary
            // type of content types.
            foreach (string group in GetConfig().GetEnumerableGroups())
            {
                GetConfig().Path = group;
                foreach (string entryname in GetConfig().GetEnumerableEntries())
                {
                    if (this.GetConfig().Read(entryname, false))
                        result.Add(Build.ContentType.FindOrCreate(group, entryname));
                }
                GetConfig().Path = "/ContentTypes";
            }
            return result;
        }

        /// <summary>
        /// This will report the use of the designated package file to the used configuration.
        /// </summary>
        /// <param name="filename">the name of the currently used configuration file.</param>
        public void ReportOpenedPackage(string filename)
        {
            this.GetConfig().Path = "/LastPackageFiles";
            List<string> knownLastPackages = this.GetLastPackages();
            knownLastPackages.Remove(filename);
            knownLastPackages.Insert(0, filename);

            if (knownLastPackages.Count > 0)
                this.GetConfig().Write("0", knownLastPackages[0]);
            if (knownLastPackages.Count > 1)
                this.GetConfig().Write("1", knownLastPackages[1]);
            if (knownLastPackages.Count > 2)
                this.GetConfig().Write("2", knownLastPackages[2]);
            if (knownLastPackages.Count > 3)
                this.GetConfig().Write("3", knownLastPackages[3]);
            this.GetConfig().Flush();
        }

        /// <summary>
        /// The main program.
        /// </summary>
        /// <param name="args">Command line arguments</param>
        /// <returns>Error code</returns>
        [STAThread]
        public static int Main(string[] args)
        {
            wx.Archive.ZipResource.AddCatalogLookupPrefix("..");
            wx.Archive.ZipResource.AddCatalogLookupPrefix("../Utils/PackageBuilder");
            /*
            using (System.Xml.XmlTextWriter dest=new System.Xml.XmlTextWriter("test.xml", System.Text.Encoding.UTF8))
            {
                dest.Formatting = System.Xml.Formatting.Indented;
                TableOfContents toc = new TableOfContents();
                int id=toc.SrcFiles.AddNode(0, new wx.Build.ContentFile(Build.ContentType.Directory, "."));
                toc.SrcFiles.AddLeaveNode(id, new wx.Build.ContentFile(Build.ContentType.DotNetExe, "PackageBuilder.exe"));
                toc.WriteXml(dest);
            }
            using (System.Xml.XmlReader reader = System.Xml.XmlReader.Create("test.xml"))
            {
                TableOfContents toc = new TableOfContents();
                toc.ReadXml(reader);
                string result = toc.ToString();
                Console.WriteLine(result);
            }
            */
            PackagerApp app = new PackagerApp(args.Length > 0 ? args[0] : null);
            app.Run();
            return 0;
        }
    }
}
