﻿/** Build system for wx.NET.
 * 
 * Application to build a self-extracting package.
 * 
 * \file 
 *
 * Copyright 2009 Harald Meyer auf'm Hofe harald_meyer@users.sourceforge.net
 * 
 * Licensed under the wxWidgets license, see LICENSE.txt for details.
 * 
 * $Id: ContentTypeConfig.cs,v 1.2 2009/12/12 11:45:44 harald_meyer Exp $
 */

using System;
using System.Collections.Generic;
using System.Drawing;

namespace wx.PackageBuilder
{
    /// <summary>
    /// Table containing the data of the config grid.
    /// </summary>
    public class ContentTypeConfigTable : wx.GridCtrl.GridTableBase
    {
        #region CTor
        Build.ContentType[] _allTypes;
        bool[] _acceptedOrNot;
        #endregion

        #region CTor
        /// <summary>
        /// This creates a tree model where all content types contained by the argument will be
        /// selected initially.
        /// </summary>
        /// <param name="validTypes">A collection of types that will be selected initially.</param>
        public ContentTypeConfigTable(ICollection<Build.ContentType> validTypes)
        {
            ICollection<Build.ContentType> allTypes = Build.ContentType.AllContentTypes;
            this._allTypes = new wx.Build.ContentType[allTypes.Count];
            this._acceptedOrNot = new bool[allTypes.Count];
            int index = 0;
            foreach (Build.ContentType t in allTypes)
            {
                this._allTypes[index] = t;
                this._acceptedOrNot[index] = validTypes.Contains(t);
                index += 1;
            }
        }

        /// <summary>
        /// Creates an instance displaying all known content types.
        /// This will also read the configuration in order to display the current configuration.
        /// </summary>
        /// <seealso cref="wx.Build.ContentType.AllContentTypes"/>
        public ContentTypeConfigTable()
        {
            Config useConfig = null;            
            PackagerApp app = App.TheApp as PackagerApp;
            if (app != null)
            {
                if (app.GetConfig().HasGroup("/ContentTypes"))
                {
                    app.GetConfig().Path = "/ContentTypes";
                    useConfig = app.GetConfig();
                }
            }

            ICollection<Build.ContentType> allTypes=Build.ContentType.AllContentTypes;
            this._allTypes = new wx.Build.ContentType[allTypes.Count];
            this._acceptedOrNot=new bool[allTypes.Count];
            int index=0;
            foreach (Build.ContentType t in allTypes)
            {
                this._allTypes[index] = t;
                if (useConfig == null)
                    this._acceptedOrNot[index] = true;
                else
                {
                    this._acceptedOrNot[index]=useConfig.Read(t.Name, false);
                }
                index += 1;
            }
        }
        #endregion

        #region Actions and Results
        /// <summary>
        /// This is a collection of all types that have been selected by the user.
        /// </summary>
        public ICollection<Build.ContentType> Results
        {
            get
            {
                List<Build.ContentType> result=new List<wx.Build.ContentType>();
                for(int index=0; index < this._allTypes.Length; ++index)
                {
                    if (this._acceptedOrNot[index])
                        result.Add(this._allTypes[index]);
                }
                return result;
            }
        }

        /// <summary>
        /// This will safe the results in the configuration of the application.
        /// </summary>
        public void SaveResults()
        {
            PackagerApp app = App.TheApp as PackagerApp;
            if (app != null)
            {
                app.GetConfig().Path = "/";
                app.GetConfig().DeleteGroup("ContentTypes");
                app.GetConfig().Path = "/ContentTypes";
                for (int i = 0; i < this._allTypes.Length; ++i)
                {
                    if (this._acceptedOrNot[i])
                    {
                        app.GetConfig().Write(this._allTypes[i].Name, true);
                    }
                }
            }
        }
        #endregion

        #region Configure the Table
        public override string GetColLabelValue(int col)
        {
            switch (col)
            {
                case 0: return _("Rel.");
                case 1: return _("Name");
                case 2: return _("Extensions");
                case 3: return _("Description");
                default: return "";
            }
        }

        public override int GetNumberCols()
        {
            return 4;
        }

        public override int GetNumberRows()
        {
            return this._allTypes.Length;
        }

        public override bool IsEmptyCell(int row, int col)
        {
            return row>= this._allTypes.Length || col >= 4;
        }

        public override bool CanHaveAttributes()
        {
            return true;
        }

        GridCtrl.GridCellAttr _readonlyAttr = null;
        GridCtrl.GridCellAttr _col0Attr = null;
        public override wx.GridCtrl.GridCellAttr GetAttr(int row, int col, wx.GridCtrl.GridCellAttr.AttrKind kind)
        {
            if (col > 0)
            {
                // readonly value with light grey background
                if (this._readonlyAttr == null)
                {
                    this._readonlyAttr = new wx.GridCtrl.GridCellAttr(
                        wx.Colour.wxBLACK,
                        new wx.Colour(250, 250, 250),
                        null,
                        Alignment.wxALIGN_LEFT, Alignment.wxALIGN_CENTRE);
                    this._readonlyAttr.ReadOnly = true;
                }
                this._readonlyAttr.IncRef();
                return this._readonlyAttr;
            }
            else
            {
                // set boolean editor and renderer.
                if (this._col0Attr == null)
                {
                    this._col0Attr = new wx.GridCtrl.GridCellAttr();
                    this._col0Attr.SetRenderer(new GridCtrl.Renderers.GridCellBoolRenderer());
                    this._col0Attr.SetEditor(new GridCtrl.Editors.GridCellBoolEditor());
                    this._col0Attr.SetAlignment(Alignment.wxALIGN_CENTRE, Alignment.wxALIGN_CENTRE);
                }
                this._col0Attr.IncRef();
                return this._col0Attr;
            }
        }

        public override string GetValue(int row, int col)
        {
            if (col == 0)
                return this._acceptedOrNot[row]?"1":"";
            else if (col == 1)
                return this._allTypes[row].Name;
            else if (col == 2)
                return this._allTypes[row].SuffixString;
            else if (col == 3)
                return this._allTypes[row].Description;
            else
                return "";
        }

        public override void SetValue(int row, int col, string val)
        {
            throw new NotSupportedException("This is read only.");
        }

        public override void SetValueAsBool(int row, int col, bool val)
        {
            if (col == 0)
            {
                this._acceptedOrNot[row] = val;
            }
            else
                throw new NotSupportedException("This is read only.");
        }

        public override bool GetValueAsBool(int row, int col)
        {
            if (col == 0)
                return this._acceptedOrNot[row];
            else
                return base.GetValueAsBool(row, col);
        }

        public override bool CanGetValueAs(int row, int col, string typeName)
        {
            if (typeName == "string")
                return true;
            if (col == 0 && typeName == "bool")
                return true;
            return false;
        }

        public override bool CanSetValueAs(int row, int col, string typeName)
        {
            if (col == 0 && typeName == "bool")
                return true;
            return false;
        }
        #endregion
    }

    /// <summary>
    /// This is a dialog that configures relevant config types.
    /// </summary>
    public class ContentTypeConfigDialog : wx.Dialog
    {
        #region State
        wx.GridCtrl.Grid _grid;
        #endregion

        #region CTor
        /// <summary>
        /// CTor if the dialog. After calling <c>ShowModal</c> refer to <c>Selected</c>.
        /// </summary>
        /// <param name="parent">Parent dialog or <c>null</c></param>
        /// <param name="title">Title of the dialog</param>
        /// <param name="pos">Initial position</param>
        /// <param name="size">Initial size</param>
        /// <param name="styles">Style. Use e.g. wx.WindowStyles.DIALOG_DEFAULT_STYLE.</param>
        /// <param name="initiallyValidTypes">A collection of initially valid types that will be selected on starting the dialog.</param>
        public ContentTypeConfigDialog(ICollection<Build.ContentType> initiallyValidTypes,
            Window parent, string title, Point pos, Size size, WindowStyles styles)
            : base(parent, title, pos, size, styles | WindowStyles.RESIZE_BORDER)
        {
            Sizer topSizer = new BoxSizer(Orientation.wxVERTICAL);
            this._grid = new wx.GridCtrl.Grid(this);
            this._grid.SetTable(new ContentTypeConfigTable(initiallyValidTypes));
            this._grid.SetColLabelAlignment(Alignment.wxALIGN_LEFT, Alignment.wxALIGN_CENTRE);
            this._grid.RowLabelSize = 0;
            this._grid.AutoSizeColumns(false);
            topSizer.Add(this._grid, 1, SizerFlag.wxGROW);
            Sizer buttons = this.CreateStdDialogButtonSizer(ButtonFlags.OK | ButtonFlags.CANCEL);
            if (buttons != null)
                topSizer.Add(buttons);
            this.Sizer = topSizer;
        }

        /// <summary>
        /// CTor if the dialog. After calling <c>ShowModal</c> refer to <c>Selected</c>.
        /// </summary>
        /// <param name="parent">Parent dialog or <c>null</c></param>
        /// <param name="title">Title of the dialog</param>
        /// <param name="pos">Initial position</param>
        /// <param name="size">Initial size</param>
        /// <param name="styles">Style. Use e.g. wx.WindowStyles.DIALOG_DEFAULT_STYLE.</param>
        public ContentTypeConfigDialog(Window parent, string title, Point pos, Size size, WindowStyles styles)
            : base(parent, title, pos, size, styles | WindowStyles.RESIZE_BORDER)
        {
            Sizer topSizer = new BoxSizer(Orientation.wxVERTICAL);
            this._grid = new wx.GridCtrl.Grid(this);
            this._grid.SetTable(new ContentTypeConfigTable());
            this._grid.SetColLabelAlignment(Alignment.wxALIGN_LEFT, Alignment.wxALIGN_CENTRE);
            this._grid.RowLabelSize = 0;
            this._grid.AutoSizeColumns(false);
            topSizer.Add(this._grid, 1, SizerFlag.wxGROW);
            Sizer buttons=this.CreateStdDialogButtonSizer(ButtonFlags.OK | ButtonFlags.CANCEL);
            if (buttons != null)
                topSizer.Add(buttons);
            this.Sizer = topSizer;
        }
        #endregion

        #region Results and Actions
        public void SaveResults()
        {
            ((ContentTypeConfigTable)this._grid.Table).SaveResults();
        }

        public ICollection<Build.ContentType> Selected
        {
            get
            {
                return ((ContentTypeConfigTable)this._grid.Table).Results;
            }
        }
        #endregion
    }
}
