/** Build and installation system for wx.NET.
 * 
 * Application to build a self-extracting package.
 * 
 * \file 
 *
 * Copyright 2009 Harald Meyer auf'm Hofe harald_meyer@users.sourceforge.net
 * 
 * Licensed under the wxWidgets license, see LICENSE.txt for details.
 * 
 * $Id: PkgToc.cs,v 1.6 2010/04/19 19:35:10 harald_meyer Exp $
 */

using System;
using System.Collections.Generic;
using System.Text;

namespace wx.PackageBuilder
{
    public class NetFrameworkDescr : IComparable, System.Xml.Serialization.IXmlSerializable
    {
        public Version Version = System.Environment.Version;

        #region IComparable Member

        public int CompareTo(object obj)
        {
            if (obj is NetFrameworkDescr)
                return this.Version.CompareTo(((NetFrameworkDescr)obj).Version);
            else
                return this.GetType().FullName.CompareTo(obj.GetType().FullName);
        }


        public override bool Equals(object obj)
        {
            if (obj is NetFrameworkDescr)
                return ((NetFrameworkDescr)obj).Version.Equals(this.Version);
            return false;
        }

        public override int GetHashCode()
        {
            return this.Version.GetHashCode();
        }

        public override string ToString()
        {
            return string.Format(".NET Version {0}", this.Version);
        }
        #endregion

        #region IXmlSerializable Member

        public System.Xml.Schema.XmlSchema GetSchema()
        {
            return null;
        }

        public void ReadXml(System.Xml.XmlReader reader)
        {
            reader.ReadStartElement("net-framework");
            string versionString = reader.ReadElementString("version");
            this.Version = new Version(versionString);
            reader.ReadEndElement();
        }

        public void WriteXml(System.Xml.XmlWriter writer)
        {
            writer.WriteStartElement("net-framework");
            writer.WriteElementString("version", this.Version.ToString());
            writer.WriteEndElement();
        }

        #endregion
    }

    /// <summary>
    /// Descriptor of a platform.
    /// Nodes containing data of this kind are required when dealing with platform specific files.
    /// Use this to group files with wx.Build.ContentFileProperties.DependsOnOSAndProcessor.
    /// </summary>
    public class PlatformDescr : IComparable, System.Xml.Serialization.IXmlSerializable
    {
        /// <summary>
        /// The operating system.
        /// </summary>
        public System.OperatingSystem OsVersion = System.Environment.OSVersion;
        /// <summary>
        /// The user provided description of the system environment.
        /// </summary>
        public string Description = "";
        public int ID=0;

        /// <summary>
        /// The current platform.
        /// </summary>
        public static PlatformDescr GetCurrent()
        {
            PlatformDescr result = new PlatformDescr();
            PackagerApp app = App.TheApp as PackagerApp;
            if (app != null)
            {
                result.Description = app.PlatformDescription;
                result.ID = app.PlatformID;
            }
            return result;
        }

        #region IComparable Member

        public int CompareTo(object obj)
        {
            if (obj is PlatformDescr)
            {
                PlatformDescr arg=obj as PlatformDescr;
                int cmp = 0;
                if (cmp == 0)
                    cmp = this.ID.CompareTo(arg.ID);
                if (cmp == 0)
                    cmp = this.OsVersion.Platform.CompareTo(arg.OsVersion.Platform);
                if (cmp == 0)
                    cmp = this.OsVersion.Version.CompareTo(arg.OsVersion.Version);
                if (cmp == 0)
                    cmp = this.OsVersion.ServicePack.CompareTo(arg.OsVersion.ServicePack);
                if (cmp == 0)
                    cmp = this.Description.CompareTo(arg.Description);
                return cmp;
            }
            else
                return this.GetType().FullName.CompareTo(obj.GetType().FullName);
        }

        public override bool Equals(object obj)
        {
            return this.CompareTo(obj) == 0;
        }

        public override int GetHashCode()
        {
            return this.ID.GetHashCode()
                ^ this.OsVersion.Platform.GetHashCode()
                ^ this.OsVersion.Version.GetHashCode()
                ^ this.Description.GetHashCode();
        }
        #endregion

        #region IXmlSerializable Member

        public System.Xml.Schema.XmlSchema GetSchema()
        {
            return null;
        }

        public void ReadXml(System.Xml.XmlReader reader)
        {
            reader.ReadStartElement("os");
            string platformString=reader.ReadElementString("platform");
            PlatformID platform = (PlatformID)Enum.Parse(typeof(PlatformID), platformString);
            string versionString = reader.ReadElementString("version");
            Version osversion = new Version(versionString);
            this.ID = Convert.ToInt32(reader.ReadElementString("id"));
            this.Description = reader.ReadElementString("description");
            this.OsVersion = new OperatingSystem(platform, osversion);
            reader.ReadEndElement();
        }

        public void WriteXml(System.Xml.XmlWriter writer)
        {
            writer.WriteStartElement("os");
            writer.WriteElementString("platform", this.OsVersion.Platform.ToString());
            writer.WriteElementString("version", this.OsVersion.Version.ToString());
            writer.WriteElementString("id", this.ID.ToString("000000"));
            writer.WriteElementString("description", this.Description);
            writer.WriteEndElement();
        }

        #endregion
    }

    /// <summary>
    /// This is the interface of all classes that can be used to implement data of nodes
    /// in trees on features and source files.
    /// 
    /// Of course, the data needs to be serializable.
    /// </summary>
    public interface IDataReferringToFiles : System.Xml.Serialization.IXmlSerializable
    {
        /// <summary>
        /// You may use this method to control the form of the file name that will be used to
        /// serialize this (the original filename). The argument is a path to an existing
        /// file or directory. This will strip a directory information from this path. After
        /// that, the original file name will change to something equivalent to the absolute
        /// filename (referring to the same file) but now relative to the directory as specified
        /// by the argument.
        /// 
        /// Use this method to prepare content file instance for serialization in such a way
        /// that all file names become relative to the same directory.
        /// </summary>
        /// <param name="nameOfAValidDirOrFile">The name of an existing file or directory. This name
        /// will - if relative - be expanded using the BuildConfig.</param>
        /// <seealso cref="OriginalFileName"/>
        /// <exception cref="System.ArgumentException">Will be raised if the argument is neither the path
        /// to an existing file nor directory.</exception>
        void NormalizeOriginalFileNames(string nameOfAValidDirOrFile);
    }

    /// <summary>
    /// A class template representing a tree where nodes will be associated with data.
    /// the leafs of this tree are associated with implementations of wx.Build.ISingleFileProduct.
    /// </summary>
    public class TreeOfContentFiles<TreeNodeData, LeafNodeData>
        : IDataReferringToFiles
        where TreeNodeData : IDataReferringToFiles
        where LeafNodeData : IDataReferringToFiles
    {
        #region State
        int _idCounter = 0;
        class LeafNode
        {
            public int _id=-1;
            public TreeNode _parent = null;
            public LeafNodeData _data=default(LeafNodeData);

            public LeafNode()
            {
            }
        }

        /// <summary>
        /// Tree node data.
        /// The data of a tree node may be <c>null</c>.
        /// </summary>
        class TreeNode
        {
            public int _id=-1;
            public TreeNode _parent = null;
            public List<TreeNode> _treeNodeChildren=new List<TreeNode>();
            public List<LeafNode> _leafNodeChildren=new List<LeafNode>();
            public TreeNodeData _data=default(TreeNodeData);

            public TreeNode()
            {
            }
        }
        Dictionary<int, TreeNode> _treeNodes = new Dictionary<int, TreeNode>();
        Dictionary<int, LeafNode> _leafNodes = new Dictionary<int, LeafNode>();
        SortedDictionary<string, List<int>> _localFilenames = new SortedDictionary<string, List<int>>();
        SortedDictionary<string, List<int>> _nodeStrings = new SortedDictionary<string, List<int>>();
        #endregion

        #region CTor
        public TreeOfContentFiles(TreeNodeData rootData)
        {
            TreeNode root = new TreeNode();
            root._id = 0;
            root._data=rootData;
            this._treeNodes[0] = root;
        }
        #endregion

        #region Public Properties
        /// <summary>
        /// Adds a node to the tree.
        /// </summary>
        /// <param name="parentID">ID of the parent. Use 0 to add a node directly to the root.</param>
        /// <param name="nodeData">Data that will be associated with the node. This may be <c>null</c> here.</param>
        /// <returns>The ID of the new node.</returns>
        /// <seealso cref="AddLeafNode"/>
        public int AddNode(int parentID, TreeNodeData nodeData)
        {
            TreeNode newNode=new TreeNode();
            this._idCounter+=1;
            newNode._id = this._idCounter;
            newNode._data=nodeData;
            TreeNode parent = this._treeNodes[parentID];
            parent._treeNodeChildren.Add(newNode);
            newNode._parent = parent;
            this._treeNodes[newNode._id] = newNode;
            return newNode._id;
        }

        /// <summary>
        /// Clears up this instance.
        /// All nodes will be removed. This will create a new root node bearing the provided data.
        /// </summary>
        /// <param name="rootNodeData">The data of the new root node. This may be <c>null</c>.</param>
        public void Clear(TreeNodeData rootNodeData)
        {
            this._idCounter = 0;
            this._leafNodes.Clear();
            this._treeNodes.Clear();
            this._localFilenames.Clear();
            this._nodeStrings.Clear();
            this._treeNodes[0] = new TreeNode();
            this._treeNodes[0]._id = 0;
            this._treeNodes[0]._data = rootNodeData;
        }

        /// <summary>
        /// The number of contained leaf nodes.
        /// </summary>
        public int CountLeafNodes
        {
            get
            {
                return this._leafNodes.Count;
            }
        }

        /// <summary>
        /// The number of all nodes.
        /// </summary>
        public int Count
        {
            get
            {
                return this._leafNodes.Count + this._treeNodes.Count;
            }
        }

        /// <summary>
        /// Returns a collection containing all keys of leaf nodes.
        /// </summary>
        public ICollection<int> LeafNodes
        {
            get
            {
                return this._leafNodes.Keys;
            }
        }

        /// <summary>
        /// A collection of the data instances attached to leaf nodes.
        /// </summary>
        public ICollection<LeafNodeData> LeafNodeDataCollection
        {
            get
            {
                List<LeafNodeData> result = new List<LeafNodeData>();
                foreach (LeafNode node in this._leafNodes.Values)
                    if (node._data != null)
                        result.Add(node._data);
                return result;
            }
        }

        /// <summary>
        /// This is a collection of all IDs of non-leaf nodes.
        /// </summary>
        public ICollection<int> TreeNodes
        {
            get
            {
                return this._treeNodes.Keys;
            }
        }

        /// <summary>
        /// A collection of the data instances attached to non-leaf nodes.
        /// </summary>
        public ICollection<TreeNodeData> TreeNodeDataCollection
        {
            get
            {
                List<TreeNodeData> result = new List<TreeNodeData>();
                foreach (TreeNode node in this._treeNodes.Values)
                    if (node._data != null)
                        result.Add(node._data);
                return result;
            }
        }

        /// <summary>
        /// A sorted collection of all local filenames associated with leaf nodes.
        /// Operates on a dictionary that will be filled if adding  leaf node data implementing wx.Build.ISingleFleProduct.
        /// </summary>
        public ICollection<string> ReferredFiles
        {
            get
            {
                return this._localFilenames.Keys;
            }
        }

        /// <summary>
        /// True iff this contains data referring to a local file of the provided name.
        /// Operates on a dictionary that will be filled if adding  leaf node data implementing wx.Build.ISingleFleProduct.
        /// </summary>
        /// <param name="filename">The filename that will be tested.</param>
        /// <returns>True iff the argument is already associated with at least one leaf node.</returns>
        public bool ContainsFile(string filename)
        {
            return this._localFilenames.ContainsKey(filename) && this._localFilenames[filename].Count > 0;
        }

        /// <summary>
        /// Returns an optionally empty collection of node indices designating those nodes referring to
        /// a file of the provided file name.
        /// </summary>
        /// <param name="filename">name of the file</param>
        /// <returns>A collection of leaf nodes referring to this file. Do not edit this collection.</returns>
        public ICollection<int> NodesReferringToFile(string filename)
        {
            if (!this._localFilenames.ContainsKey(filename))
                return new int[0]{};
            return this._localFilenames[filename];
        }

        /// <summary>
        /// True iff the argument designates a leaf node.
        /// </summary>
        /// <param name="nodeID">The node ID that will be tested.</param>
        public bool ContainsLeafNode(int nodeID)
        {
            return this._leafNodes.ContainsKey(nodeID);
        }

        /// <summary>
        /// True iff the argument designates a non-leaf node.
        /// </summary>
        /// <param name="nodeID">The node ID that will be tested.</param>
        public bool ContainsTreeNode(int nodeID)
        {
            return this._treeNodes.ContainsKey(nodeID);
        }

        /// <summary>
        /// The ID of the parent of the designated node or -1 if this does not exist.
        /// </summary>
        /// <param name="nodeID">ID of the node.</param>
        /// <returns>The ID of the parent or -1 if the argument does not exist or is root.</returns>
        public int GetParent(int nodeID)
        {
            if (this._leafNodes.ContainsKey(nodeID))
                return this._leafNodes[nodeID]._parent._id;
            else if (this._treeNodes.ContainsKey(nodeID))
            {
                TreeNode n = this._treeNodes[nodeID];
                if (n._parent == null)
                    return -1;
                else
                    return n._parent._id;
            }
            else
                return -1;
        }

        /// <summary>
        /// If the argument designates a tree node with non-leafs as children, this will return a collection
        /// of the IDs of these children. Otherwise, the result is empty.
        /// </summary>
        /// <param name="nodeID">The ID of a non-leave tree node.</param>
        /// <returns></returns>
        public ICollection<int> GetTreeNodeChildren(int nodeID)
        {
            if (this.ContainsTreeNode(nodeID))
            {
                TreeNode n = this._treeNodes[nodeID];
                List<int> result = new List<int>();
                foreach (TreeNode nn in n._treeNodeChildren)
                    result.Add(nn._id);
                return result;
            }
            else
                return new int[] {};
        }

        /// <summary>
        /// If the argument designates a tree node with leafs as children, this will return a collection
        /// of the IDs of these children. Otherwise, the result is empty.
        /// </summary>
        /// <param name="nodeID">The ID of a non-leave tree node.</param>
        /// <returns></returns>
        public ICollection<int> GetLeafNodeChildren(int nodeID)
        {
            if (this.ContainsTreeNode(nodeID))
            {
                TreeNode n = this._treeNodes[nodeID];
                List<int> result = new List<int>();
                foreach (LeafNode nn in n._leafNodeChildren)
                    result.Add(nn._id);
                return result;
            }
            else
                return new int[] { };
        }

        /// <summary>
        /// Gets the data associated with the designated node.
        /// </summary>
        /// <param name="nodeID">ID of a tree node. Use 0 to access data of the root node.</param>
        /// <returns>The data or <c>default(TreeNodeData)</c> if the data does not exist or the node is unknown.</returns>
        public TreeNodeData GetTreeNodeData(int nodeID)
        {
            if (this._treeNodes.ContainsKey(nodeID))
            {
                return this._treeNodes[nodeID]._data;
            }
            else
                return default(TreeNodeData);
        }

        /// <summary>
        /// Gets the data associated with the designated leaf node.
        /// </summary>
        /// <param name="nodeID">ID of a tree node.</param>
        /// <returns>The data or <c>default(TreeNodeData)</c> if the data does not exist or the node is unknown.</returns>
        public LeafNodeData GetLeafNodeData(int nodeID)
        {
            if (this._leafNodes.ContainsKey(nodeID))
            {
                return this._leafNodes[nodeID]._data;
            }
            else
                return default(LeafNodeData);
        }

        /// <summary>
        /// Adds a new leaf node to the node designated by the provided parent ID.
        /// </summary>
        /// <param name="parentID">ID of the parent. Use 0 to add a node directly to the root.</param>
        /// <param name="nodeData">Data that will be associated with the node. This shall not be <c>null</c>.</param>
        /// <returns>The ID of the new node.</returns>
        /// <seealso cref="AddNode"/>
        public int AddLeafNode(int parentID, LeafNodeData nodeData)
        {
            LeafNode newNode = new LeafNode();
            this._idCounter += 1;
            newNode._id = this._idCounter;
            newNode._data = nodeData;
            TreeNode parent = this._treeNodes[parentID];
            parent._leafNodeChildren.Add(newNode);
            newNode._parent = parent;
            this._leafNodes[newNode._id] = newNode;
            if (nodeData is Build.ISingleFileProduct)
            {
                if (!this._localFilenames.ContainsKey(((Build.ISingleFileProduct)nodeData).File.FileName))
                    this._localFilenames.Add(((Build.ISingleFileProduct)nodeData).File.FileName, new List<int>());
                this._localFilenames[((Build.ISingleFileProduct)nodeData).File.FileName].Add(newNode._id);
            }
            string nodeDataString = nodeData.ToString();
            if (!this._nodeStrings.ContainsKey(nodeDataString))
                this._nodeStrings.Add(nodeDataString, new List<int>());
            this._nodeStrings[nodeDataString].Add(newNode._id);
            return newNode._id;
        }

        /// <summary>
        /// Removes the children of the designated node, tree nodes as well as leaf nodes.
        /// </summary>
        /// <param name="nodeid">The root to remove.</param>
        /// <returns>The number of removed nodes including the nodes of the removed subtree.</returns>
        public int RemoveChildren(int nodeid)
        {
            if (this._treeNodes.ContainsKey(nodeid))
            {
                int result = 0;
                TreeNode node = this._treeNodes[nodeid];
                if (node._leafNodeChildren != null)
                {
                    foreach (LeafNode leaf in new List<LeafNode>(node._leafNodeChildren))
                    {
                        result += this.RemoveNode(leaf._id);
                    }
                }
                if (node._treeNodeChildren != null)
                {
                    List<TreeNode> copyOfTreeNodeChildren
                        = new List<TreeOfContentFiles<TreeNodeData, LeafNodeData>.TreeNode>(node._treeNodeChildren);
                    foreach (TreeNode subnode in copyOfTreeNodeChildren)
                    {
                        result += this.RemoveNode(subnode._id);
                    }
                }
                node._treeNodeChildren.Clear();
                node._leafNodeChildren.Clear();
                return result;
            }
            else
                return 0;
        }

        /// <summary>
        /// Removes the designated node and the subtree beneath this node (if this is not a leaf).
        /// </summary>
        /// <param name="nodeid">The root to remove. This may also be a leaf node.</param>
        /// <returns>The number of removed nodes including the nodes of the removed subtree.</returns>
        public int RemoveNode(int nodeid)
        {
            if (this._treeNodes.ContainsKey(nodeid))
            {
                int result = 0;
                TreeNode node = this._treeNodes[nodeid];
                if (node._parent != null)
                    node._parent._treeNodeChildren.Remove(node);
                if (node._leafNodeChildren != null)
                {
                    foreach (LeafNode leaf in new List<LeafNode>( node._leafNodeChildren))
                    {
                        result += this.RemoveNode(leaf._id);
                    }
                }
                if (node._treeNodeChildren != null)
                {
                    List<TreeNode> copyOfTreeNodeChildren
                        = new List<TreeOfContentFiles<TreeNodeData, LeafNodeData>.TreeNode>(node._treeNodeChildren);
                    foreach (TreeNode subnode in copyOfTreeNodeChildren)
                    {
                        result += this.RemoveNode(subnode._id);
                    }
                }
                this._treeNodes.Remove(nodeid);
                if (this._nodeStrings.ContainsKey(node._data.ToString()))
                    this._nodeStrings[node._data.ToString()].Remove(node._id);
                result += 1;
                return result;
            }
            else if (this._leafNodes.ContainsKey(nodeid))
            {
                LeafNode node = this._leafNodes[nodeid];
                if (node._parent != null)
                    node._parent._leafNodeChildren.Remove(node);
                this._leafNodes.Remove(nodeid);
                if (node._data is Build.ISingleFileProduct 
                    && this._localFilenames.ContainsKey((node._data as Build.ISingleFileProduct).File.FileName))
                {
                    this._localFilenames[(node._data as Build.ISingleFileProduct).File.FileName].Remove(node._id);
                }
                if (this._nodeStrings.ContainsKey(node._data.ToString()))
                    this._nodeStrings[node._data.ToString()].Remove(node._id);
                return 1;
            }
            else
                return 0;
        }
        #endregion

        public override string ToString()
        {
            System.Text.StringBuilder sb = new StringBuilder();
            this.SubtreeToString(sb, 0, 0);
            return sb.ToString();
        }

        void SubtreeToString(StringBuilder sb, int id, int depth)
        {
            sb.Append("|");
            if (depth > 0)
                sb.Append(new string('-', depth));

            if (this._leafNodes.ContainsKey(id))
            {
                LeafNode n = this._leafNodes[id];
                sb.Append(n._id);
                sb.Append(": ");
                if (n._data != null)
                    sb.Append(n._data);
                sb.AppendLine();
            }
            else
            {
                TreeNode n = this._treeNodes[id];
                sb.Append(n._id);
                sb.Append(": ");
                if (n._data != null)
                    sb.Append(n._data);
                sb.AppendLine();
                foreach (TreeNode nn in n._treeNodeChildren)
                {
                    this.SubtreeToString(sb, nn._id, depth + 1); 
                }
                foreach (LeafNode nn in n._leafNodeChildren)
                {
                    this.SubtreeToString(sb, nn._id, depth + 1);
                }
            }
        }

        #region IXmlSerializable Member
        /// <summary>
        /// Returns <c>null</c> as suggested by the framework documentation.
        /// </summary>
        /// <returns>null</returns>
        public System.Xml.Schema.XmlSchema GetSchema()
        {
            return null;
        }

        /// <summary>
        /// Read the data of this instance from a Xml stream.
        /// </summary>
        /// <param name="reader">The data source</param>
        /// <exception cref="FormatException">Raised on unexpected structure of teh Xml code.</exception>
        /// <seealso cref="WriteXml"/>
        public void ReadXml(System.Xml.XmlReader reader)
        {
            this._leafNodes.Clear();
            this._treeNodes.Clear();
            reader.MoveToContent();
            if (reader.IsEmptyElement && reader.Name == "tree")
            {
                reader.Read();
                return; // we allow for empty trees.
            }
            if (!reader.IsStartElement("tree"))
                reader.ReadStartElement("tree"); // produces an exception
            if (reader.GetAttribute("node_data") != typeof(TreeNodeData).Namespace + "." + typeof(TreeNodeData).Name)
                throw new FormatException("Unexpected type of node data.");
            if (reader.GetAttribute("leaf_data") != typeof(LeafNodeData).Namespace + "." + typeof(LeafNodeData).Name)
                throw new FormatException("Unexpected type of leaf node data.");
            reader.Read();
            while (reader.IsStartElement())
            {
                string elementName = reader.Name;
                int id = Convert.ToInt32(reader.GetAttribute("id"));
                TreeNode parent = null;
                string parentIdAttr = reader.GetAttribute("parent");
                if (parentIdAttr != null)
                {
                    int parentID = Convert.ToInt32(parentIdAttr);
                    parent = this._treeNodes[parentID];
                }
                bool emptyElement=reader.IsEmptyElement;
                reader.Read();
                if (elementName == "node")
                {
                    TreeNode newNode = new TreeNode();
                    newNode._id = id;
                    if (!emptyElement)
                    {
                        TreeNodeData newNodeData = Activator.CreateInstance<TreeNodeData>();
                        newNodeData.ReadXml(reader);
                        newNode._data = newNodeData;
                    }
                    if (parent != null)
                    {
                        newNode._parent = parent;
                        parent._treeNodeChildren.Add(newNode);
                    }
                    this._treeNodes[newNode._id] = newNode;
                }
                else if (elementName == "leaf")
                {
                    LeafNodeData newNodeData = Activator.CreateInstance<LeafNodeData>();
                    newNodeData.ReadXml(reader);
                    LeafNode newNode = new LeafNode();
                    newNode._id = id;
                    if (!emptyElement)
                    {
                        newNode._data = newNodeData;
                    }
                    newNode._parent = parent;
                    parent._leafNodeChildren.Add(newNode);
                    this._leafNodes[newNode._id] = newNode;
                }
                if (!emptyElement)
                    reader.ReadEndElement();
            }
            reader.ReadEndElement();
        }

        /// <summary>
        /// Write the content to the provided XML destination.
        /// </summary>
        /// <param name="writer">The destination of the output</param>
        /// <seealso cref="ReadXml"/>
        public void WriteXml(System.Xml.XmlWriter writer)
        {
            writer.WriteStartElement("tree");
            writer.WriteAttributeString("node_data", typeof(TreeNodeData).Namespace + "." + typeof(TreeNodeData).Name);
            writer.WriteAttributeString("leaf_data", typeof(LeafNodeData).Namespace + "." + typeof(LeafNodeData).Name);
            foreach (TreeNode n in this._treeNodes.Values)
            {
                writer.WriteStartElement("node");
                writer.WriteAttributeString("id", n._id.ToString());
                if (n._parent != null) // this may be the root.
                    writer.WriteAttributeString("parent", n._parent._id.ToString());
                if (n._data != null)
                    n._data.WriteXml(writer);
                writer.WriteEndElement();
            }
            foreach (LeafNode n in this._leafNodes.Values)
            {
                writer.WriteStartElement("leaf");
                writer.WriteAttributeString("id", n._id.ToString());
                writer.WriteAttributeString("parent", n._parent._id.ToString());
                n._data.WriteXml(writer);
                writer.WriteEndElement();
            }
            writer.WriteEndElement();
        }

        #endregion

        #region IDataReferringToFiles Member

        public void NormalizeOriginalFileNames(string nameOfAValidDirOrFile)
        {
            foreach (LeafNode node in this._leafNodes.Values)
                if (node._data != null)
                    node._data.NormalizeOriginalFileNames(nameOfAValidDirOrFile);
            foreach (TreeNode node in this._treeNodes.Values)
                if (node._data != null)
                    node._data.NormalizeOriginalFileNames(nameOfAValidDirOrFile);
        }

        #endregion
    }

    /// <summary>
    /// Types of folders in the source tree.
    /// These folders typically structure the properties of a build project.
    /// 
    /// FolderTypeToString.ToString defines a readable name for the elements of this enumeration.
    /// </summary>
    public enum KindOfSrcFolder
    {
        /// <summary>
        /// This symbol will be used in source tree nodes that do not represent one
        /// of the supported folders.
        /// </summary>
        NotOneOfTheSupportedFolders,
        Source,
        Target,
        ShadowProjects,
        CSharpProjects,
        CPlusPlusProjects,
        Platform,
    }

    /// <summary>
    /// Class of data associated with tree nodes in the source tree.
    /// This contains a file of teh node represents a file and some additional information.
    /// </summary>
    public class SrcNodeData : System.Xml.Serialization.IXmlSerializable, IDataReferringToFiles
    {
        public static string FolderTypeToString(KindOfSrcFolder value)
        {
            switch (value)
            {
                case KindOfSrcFolder.CPlusPlusProjects: return "C++ Projects";
                case KindOfSrcFolder.CSharpProjects: return "C# Projects";
                case KindOfSrcFolder.ShadowProjects: return "Shadow Projects";
                default:
                    return value.ToString();
            }
        }

        /// <summary>
        /// The platform, that has been used to build the file.
        /// </summary>
        public PlatformDescr Platform = null;

        /// <summary>
        /// The .NET version, that has been used to build the file.
        /// </summary>
        public NetFrameworkDescr NetFramework = null;

        public KindOfSrcFolder FolderType = KindOfSrcFolder.NotOneOfTheSupportedFolders;

        /// <summary>
        /// This will be non-null iff this node refers to a file or directory.
        /// </summary>
        public Build.ContentFile File=null;

        /// <summary>
        /// This member will be set if this node contains a project.
        /// </summary>
        public Build.RefToProject ProjectRef = null;

        /// <summary>
        /// Read only access to the project of <c>ProjectRef</c>.
        /// </summary>
        public Build.BuildProject Project
        {
            get
            {
                if (this.ProjectRef == null)
                    return null;
                return this.ProjectRef.Project;
            }
        }



        /// <summary>
        /// If this refers to a directory, this slot will hold a collection of content types of files
        /// that are also part of the sources. If this also contains wx.Build.ContentType.Directory,
        /// all subdirs will be included into the relevant sources. If this is <c>null</c> although 
        /// <c>File</c> is a directory, then the source tree has nt been expanded to refer also to
        /// contents of the directory.
        /// </summary>
        public ICollection<Build.ContentType> Types = new List<Build.ContentType>();

        /// <summary>
        /// Creates empty data.
        /// </summary>
        public SrcNodeData()
        {
        }

        /// <summary>
        /// Creates a tree node representing a certain kind of folder.
        /// </summary>
        /// <param name="folderType">Defines the kind of  this node.</param>
        public SrcNodeData(KindOfSrcFolder folderType)
        {
            this.FolderType = folderType;
        }

        /// <summary>
        /// Creates an instance referring to the provided file.
        /// </summary>
        /// <param name="file"></param>
        public SrcNodeData(Build.ContentFile file)
        {
            this.File = file;
        }

        /// <summary>
        /// Call this to produce a node that is about a project.
        /// </summary>
        /// <param name="project">The project that shall be the data attached to this node.</param>
        public SrcNodeData(Build.BuildProject project)
        {
            this.ProjectRef = project.CreateRef();
            Build.BuildProject.AddKnownProject(project);
        }

        /// <summary>
        /// Call this to produce a node that is about a project.
        /// </summary>
        /// <param name="project">The project that shall be the data attached to this node.</param>
        public SrcNodeData(Build.RefToProject project)
        {
            this.ProjectRef = project;
            Build.BuildProject.AddKnownProject(project.Project);
        }

        /// <summary>
        /// Creates an instance affecting the provided file (that must be a directory) and
        /// the provided content types.
        /// </summary>
        /// <param name="file">The descriptor of a directory</param>
        /// <param name="types">The collection of those content types describing the files that shall
        /// be included into the project.</param>
        public SrcNodeData(Build.ContentFile file, ICollection<Build.ContentType> types)
        {
            this.File = file;
            this.Types = types;
        }
        #region IXmlSerializable Member
        /// <summary>
        /// Returns <c>null</c> as suggested by the framework docu.
        /// </summary>
        public System.Xml.Schema.XmlSchema GetSchema()
        {
            return null;
        }

        /// <summary>
        /// Reads the date from the provided stream.
        /// </summary>
        /// <param name="reader">The XML stream</param>
        /// <exception cref="System.FormatException">Raised on illegal XML format.</exception>
        public void ReadXml(System.Xml.XmlReader reader)
        {
            this.ProjectRef = null;
            this.File = null;
            this.Types = null;
            this.FolderType=KindOfSrcFolder.NotOneOfTheSupportedFolders;
            reader.MoveToContent();
            bool isEmptyElement = reader.IsEmptyElement;
            reader.ReadStartElement("src-data");
            if (!isEmptyElement)
            {
                while (reader.IsStartElement())
                {
                    string name = reader.Name;
                    if (name == "file")
                    {
                        reader.Read();
                        this.File = new wx.Build.ContentFile();
                        this.File.ReadXml(reader);
                        reader.ReadEndElement();
                    }
                    else if (name == "include-type")
                    {
                        reader.Read();
                        Build.ContentType newT = Build.ContentType.FromXml(reader);
                        this.Types.Add(newT);
                        reader.ReadEndElement();
                    }
                    else if (name == "project")
                    {
                        this.ProjectRef = new wx.Build.RefToProject();
                        this.ProjectRef.ReadXml(reader);
                    }
                    else if (name == "folder")
                    {
                        this.FolderType = (KindOfSrcFolder)Enum.Parse(typeof(KindOfSrcFolder), reader.GetAttribute("name"));
                        reader.Read();
                        reader.MoveToContent();
                    }
                    if (reader.IsStartElement("os"))
                    {
                        this.Platform = new PlatformDescr();
                        this.Platform.ReadXml(reader);
                    }
                    else
                        this.Platform = null;
                    if (reader.IsStartElement("net-framework"))
                    {
                        this.NetFramework = new NetFrameworkDescr();
                        this.NetFramework.ReadXml(reader);
                    }
                    else
                        this.NetFramework = null;
                }
                reader.ReadEndElement();
            }
        }

        public void WriteXml(System.Xml.XmlWriter writer)
        {
            writer.WriteStartElement("src-data");
            if (this.File != null)
            {
                writer.WriteStartElement("file");
                this.File.WriteXml(writer);
                writer.WriteEndElement();
            }
            if (this.ProjectRef != null)
            {
                this.ProjectRef.WriteXml(writer);
            }
            if (this.Types != null)
            {
                foreach (Build.ContentType t in this.Types)
                {
                    writer.WriteStartElement("include-type");
                    t.WriteRefXml(writer);
                    writer.WriteEndElement();
                }
            }
            if (this.FolderType != KindOfSrcFolder.NotOneOfTheSupportedFolders)
            {
                writer.WriteStartElement("folder");
                writer.WriteAttributeString("name", this.FolderType.ToString());
                writer.WriteEndElement();
            }
            if (this.Platform != null)
                this.Platform.WriteXml(writer);
            if (this.NetFramework != null)
                this.NetFramework.WriteXml(writer);
            writer.WriteEndElement();
        }

        #endregion

        #region INodeData Member

        public void NormalizeOriginalFileNames(string nameOfAValidDirOrFile)
        {
            if (this.File != null)
                this.File.NormalizeOriginalFileName(nameOfAValidDirOrFile);
        }

        #endregion
    }

    /// <summary>
    /// Describes how the file content in a package are compressed.
    /// </summary>
    public enum CompressionMode
    {
        /// <summary>
        /// No compression used.
        /// </summary>
        NoCompression,
        /// <summary>
        /// Used System.IO.Compression.GZipStream.
        /// </summary>
        GZip,
    }

    /// <summary>
    /// Class representing the data on a leaf node in the tree of sources.
    /// </summary>
    public class SrcLeafData : IDataReferringToFiles
    {
        #region State
        public CompressionMode Compression = CompressionMode.GZip;
        /// <summary>
        /// The name of the file in the resource stream.
        /// This is <c>null</c> if this represents a feature and not a resource.
        /// </summary>
        public string NameInRes = null;

        /// <summary>
        /// The platform, that has been used to build the file.
        /// </summary>
        public PlatformDescr Platform = null;

        /// <summary>
        /// The .NET version, that has been used to build the file.
        /// </summary>
        public NetFrameworkDescr NetFramework = null;

        public Build.ContentFile File;
        /// <summary>
        /// This is the project that contains the file (if known) or <c>null</c>.
        /// </summary>
        public Build.RefToProject ProjectRef = null;
        /// <summary>
        /// This is the project that contains the file (if known) or <c>null</c>.
        /// </summary>
        public Build.BuildProject Project
        {
            get
            {
                if (this.ProjectRef == null)
                    return null;
                else
                    return this.ProjectRef.Project;
            }
        }
        #endregion

        #region CTor
        /// <summary>
        /// CTor without arguments. Use only in the context of serialization.
        /// </summary>
        public SrcLeafData()
            : this(new Build.ContentFile())
        {
        }

        public SrcLeafData(Build.ContentFile file)
        {
            this.File = file;
            if (file.FileName != null)
            {
                this.NameInRes = System.IO.Path.GetFileNameWithoutExtension(file.FileName);
                this.NameInRes.Replace(' ', '_');
            }
        }

        /// <summary>
        /// Is a node about a file in a project.
        /// </summary>
        /// <param name="file">The file</param>
        /// <param name="inProject">The project that refers to file.</param>
        public SrcLeafData(Build.ContentFile file, Build.RefToProject inProject)
        {
            this.File = file;
            this.ProjectRef = inProject;
            if (this.ProjectRef != null)
                Build.BuildProject.AddKnownProject(this.Project);
            this.NameInRes = System.IO.Path.GetFileNameWithoutExtension(file.FileName);
            this.NameInRes.Replace(' ', '_');
        }
        #endregion

        #region IDataReferringToFiles Member

        public void NormalizeOriginalFileNames(string nameOfAValidDirOrFile)
        {
            this.File.NormalizeOriginalFileName(nameOfAValidDirOrFile);
        }

        #endregion

        #region Resource Name

        /// <summary>
        /// Support to set unique resource names.
        /// </summary>
        /// <param name="basenname">basename of the resource</param>
        /// <param name="index">an index to produce a unique name extending the base name. shall be larger than or equal to 0.</param>
        public void SetResourceName(string basenname, int index)
        {
            this.NameInRes = basenname;
            this.NameInRes.Replace(' ', '_');
            if (index > 0)
                this.NameInRes = basenname + index.ToString("0000");
        }

        #endregion

        #region IXmlSerializable Member
        /// <summary>
        /// Returns <c>null</c> as suggested by the framework docu.
        /// </summary>
        public System.Xml.Schema.XmlSchema GetSchema()
        {
            return null;
        }

        public void ReadXml(System.Xml.XmlReader reader)
        {
            reader.ReadStartElement("source");
            this.File.ReadXml(reader);
            this.ProjectRef = null;
            this.Compression = CompressionMode.NoCompression;
            this.NameInRes = null;
            if (reader.IsStartElement("resource-name"))
                this.NameInRes = reader.ReadElementString("resource-name");
            if (reader.IsStartElement("compression"))
                this.Compression = (CompressionMode)Enum.Parse(typeof(CompressionMode), reader.ReadElementString("compression"));
            if (reader.IsStartElement("project"))
            {
                this.ProjectRef = new wx.Build.RefToProject();
                this.ProjectRef.ReadXml(reader);
            }
            if (reader.IsStartElement("os"))
            {
                this.Platform = new PlatformDescr();
                this.Platform.ReadXml(reader);
            }
            else
                this.Platform = null;
            if (reader.IsStartElement("net-framework"))
            {
                this.NetFramework = new NetFrameworkDescr();
                this.NetFramework.ReadXml(reader);
            }
            else
                this.NetFramework = null;
            reader.ReadEndElement();
        }

        public void WriteXml(System.Xml.XmlWriter writer)
        {
            writer.WriteStartElement("source");
            this.File.WriteXml(writer);
            if (this.NameInRes != null)
                writer.WriteElementString("resource-name", this.NameInRes);
            if (this.Compression != CompressionMode.NoCompression)
                writer.WriteElementString("compression", this.Compression.ToString());
            if (this.ProjectRef != null)
                this.ProjectRef.WriteXml(writer);
            if (this.Platform != null)
                this.Platform.WriteXml(writer);
            if (this.NetFramework != null)
                this.NetFramework.WriteXml(writer);
            writer.WriteEndElement();
        }

        #endregion

        #region Overrides
        public override bool Equals(object obj)
        {
            if (obj is SrcLeafData)
                return this.File.Equals(((SrcLeafData)obj).File);
            else
                return false;
        }

        public override int GetHashCode()
        {
            return this.File.GetHashCode();
        }

        public override string ToString()
        {
            return ">"+this.File.ToString();
        }
        #endregion
    }

    /// <summary>
    /// Data class for nodes in the TOC representing those files that can actually be installed.
    /// </summary>
    public class TocNodeData : System.Xml.Serialization.IXmlSerializable, IDataReferringToFiles
    {
        /// <summary>
        /// This is the id of the corresponding node in the source tree.
        /// If this node has not been derived from a source file, this is -1.
        /// </summary>
        public int SrcNode=-1;
        /// <summary>
        /// The source tree. necessary to infer the node designated by SrcNode.
        /// </summary>
        public TreeOfContentFiles<SrcNodeData, SrcLeafData> SrcTree = null;
        public CompressionMode Compression = CompressionMode.GZip;
        /// <summary>
        /// The name of the file in the resource stream.
        /// This is <c>null</c> if this represents a feature and not a resource.
        /// </summary>
        public string NameInRes = null;

        /// <summary>
        /// This is the name of a feature.
        /// This is <c>null</c> if this data represents a resource file and not a feature.
        /// </summary>
        public string FeatureName = null;

        /// <summary>
        /// Reference to a project if this node represents a project.
        /// </summary>
        public Build.RefToProject ProjectRef = null;

        /// <summary>
        /// The project that refers to this node if such a project exists. <c>null</c> otherwise.
        /// </summary>
        /// <see cref="ProjectRef"/>
        public Build.BuildProject Project
        {
            get
            {
                if (this.ProjectRef == null)
                    return null;
                else
                    return this.ProjectRef.Project;
            }
        }

        /// <summary>
        /// The platform, that has been used to build the file.
        /// </summary>
        public PlatformDescr Platform = null;

        /// <summary>
        /// The .NET version, that has been used to build the file.
        /// </summary>
        public NetFrameworkDescr NetFramework = null;

        /// <summary>
        /// Use this when reading from XML stream.
        /// </summary>
        public TocNodeData()
        {
        }

        /// <summary>
        /// Creates an instance representing a feature.
        /// </summary>
        /// <param name="featurename">The name of the represented feature.</param>
        public TocNodeData(string featurename)
        {
            this.FeatureName = featurename;
        }

        /// <summary>
        /// Creates an instance referring to a file.
        /// Please note, that this will not guarantee that the resource name is unique.
        /// </summary>
        /// <param name="srcNode"> The ID of the node in the source tree.</param>
        /// <param name="srcTree">The instance of the data associated with the source file tree.</param>
        public TocNodeData(int srcNode, TreeOfContentFiles<SrcNodeData, SrcLeafData> srcTree)
        {
            this.SrcNode = srcNode;
            this.SrcTree = srcTree;
            SrcLeafData leafData = this.SrcLeafData;
            if (leafData != null)
            {
                this.NameInRes = leafData.NameInRes;
                this.Compression = leafData.Compression;
            }
        }

        /// <summary>
        /// Support to set unique resource names.
        /// </summary>
        /// <param name="basenname">basename of the resource</param>
        /// <param name="index">an index to produce a unique name extending the base name. shall be larger than or equal to 0.</param>
        public void SetResourceName(string basenname, int index)
        {
            this.FeatureName = null;
            this.NameInRes=basenname;
            this.NameInRes.Replace(' ', '_');
            if (index > 0)
                this.NameInRes = basenname + index.ToString("0000");
        }

        #region References to the source tree
        /// <summary>
        /// If this refers to a leaf node in the tree of source files, this is the instance
        /// of the data associated with that node. This will be <c>null</c> if this does not refer
        /// to a leaf node.
        /// </summary>
        public SrcLeafData SrcLeafData
        {
            get
            {
                if (this.SrcTree != null && this.SrcTree.ContainsLeafNode(this.SrcNode))
                    return this.SrcTree.GetLeafNodeData(this.SrcNode);
                else
                    return null;
            }
        }
        /// <summary>
        /// If this refers to a non-leaf node in the tree of source files, this is the instance
        /// of the data associated with that node. This will be <c>null</c> if this does not refer
        /// to a leaf node.
        /// </summary>
        public SrcNodeData SrcNodeData
        {
            get
            {
                if (this.SrcTree != null && this.SrcTree.ContainsTreeNode(this.SrcNode))
                    return this.SrcTree.GetTreeNodeData(this.SrcNode);
                else
                    return null;
            }
        }

        /// <summary>
        /// Returns a description of the source file that refers to this content of the package.
        /// This will be <c>null</c> if this does not refer to a file, e.g. if this is a feature
        /// of the package.
        /// </summary>
        public Build.ContentFile File
        {
            get
            {
                SrcLeafData leafData = this.SrcLeafData;
                if (leafData != null)
                    return leafData.File;
                SrcNodeData nodeData = this.SrcNodeData;
                if (nodeData != null)
                    return nodeData.File;
                return null;
            }
        }

        #endregion

        #region IXmlSerializable Member

        /// <summary>
        /// Returns <c>null</c> as suggested by the framework documentation.
        /// </summary>
        /// <returns></returns>
        public System.Xml.Schema.XmlSchema GetSchema()
        {
 	        return null;
        }

        public void ReadXml(System.Xml.XmlReader reader)
        {
            if (reader.IsStartElement())
            {
                string name = reader.Name;
                if (name == "pkg-content")
                {
                    this.FeatureName = null;
                    if (reader.MoveToAttribute("name"))
                        this.NameInRes = reader.GetAttribute("name");
                    reader.Read();
                    reader.Read();
                    if (!reader.IsStartElement("file"))
                        throw new FormatException("Expecting tag file in pkg-content.");
                    this.SrcNode = Convert.ToInt32(reader.GetAttribute("id"));
                    if (reader.MoveToAttribute("compression"))
                    {
                        this.Compression = (CompressionMode)Enum.Parse(typeof(CompressionMode), reader.GetAttribute("compression"));
                    }
                    reader.Read();
                    //reader.ReadEndElement();//current "file" does not contain any other nodes than attributes. 
                    reader.MoveToContent();
                    if (reader.IsStartElement("os"))
                    {
                        this.Platform = new PlatformDescr();
                        this.Platform.ReadXml(reader);
                    }
                    else
                        this.Platform = null;
                    if (reader.IsStartElement("net-framework"))
                    {
                        this.NetFramework = new NetFrameworkDescr();
                        this.NetFramework.ReadXml(reader);
                    }
                    else
                        this.NetFramework = null;
                    reader.ReadEndElement();
                }
                else if (name == "pkg-feature")
                {
                    this.NameInRes = null;
                    this.SrcNode = -1;
                    this.FeatureName = reader.GetAttribute("name");
                    reader.Read();
                }
            }
            else
                throw new FormatException("Missing start of either pkg-content or pkg-feature element.");
        }

        /// <summary>
        /// Creates either a "pkg-content" element or a "pkg-feature" element.
        /// </summary>
        /// <param name="writer">The destination of the serialization.</param>
        public void  WriteXml(System.Xml.XmlWriter writer)
        {
            if (this.NameInRes != null || this.SrcNode >= 0)
            {
                writer.WriteStartElement("pkg-content");
                if (this.NameInRes != null)
                    writer.WriteAttributeString("name", this.NameInRes);
                writer.WriteStartElement("file");
                if (this.Compression != CompressionMode.NoCompression)
                    writer.WriteAttributeString("compression", this.Compression.ToString());
                writer.WriteAttributeString("id", this.SrcNode.ToString());
                writer.WriteEndElement();
                if (this.Platform != null)
                    this.Platform.WriteXml(writer);
                if (this.NetFramework != null)
                    this.NetFramework.WriteXml(writer);
                writer.WriteEndElement();
            }
            else if (this.FeatureName != null)
            {
                writer.WriteStartElement("pkg-feature");
                writer.WriteAttributeString("name", this.FeatureName);
                writer.WriteEndElement();
            }
        }

        #endregion

        /// <summary>
        /// String representation indicating either feature or resource name.
        /// </summary>
        public override string ToString()
        {
            if (this.NameInRes == null && this.SrcNode < 0)
                return string.Format("Feature:{0}", this.FeatureName);
            else if (this.NameInRes == null)
                return this.StringForResource("Directory");
            else
                return this.StringForResource(this.NameInRes);
        }

        /// <summary>
        /// Returns a string equivalent to the result of the ToString() method on a resource of the name provided to this method.
        /// </summary>
        /// <param name="resourceName">The resource name that will appear in the resulting string.</param>
        /// <returns></returns>
        public string StringForResource(string resourceName)
        {
            return string.Format("Resource:{0}", resourceName);
        }

        #region INodeData Member

        public void NormalizeOriginalFileNames(string nameOfAValidDirOrFile)
        {
            if (this.File != null)
                this.File.NormalizeOriginalFileName(nameOfAValidDirOrFile);
        }

        #endregion
    }

    /// <summary> Lists the content of a package.
    /// Instances of this class serve as a data model for package builder
    /// and the component that will decompress the contained files and projects.
    /// </summary>
    public class TableOfContents : System.Xml.Serialization.IXmlSerializable, IDataReferringToFiles
    {
        #region State
        /// <summary>
        /// A collection of source files that provide data to be included into the package.
        /// </summary>
        public TreeOfContentFiles<SrcNodeData, SrcLeafData> SrcFiles = new TreeOfContentFiles<SrcNodeData, SrcLeafData>(null);

        /// <summary>
        /// Collection of files that will be installed.
        /// </summary>
        public TreeOfContentFiles<TocNodeData, TocNodeData> TocFiles = new TreeOfContentFiles<TocNodeData, TocNodeData>(null);

        /// <summary>
        /// Key is the name of a variable. The value is the assigned value.
        /// This will only contain those assignments that differ from the default values.
        /// 
        /// Currently not used.
        /// </summary>
        public SortedList<string, string> EnvVarAssignments = new SortedList<string, string>();
        #endregion

        #region CTor
        /// <summary>
        /// Creates an empty instance.
        /// </summary>
        public TableOfContents()
        {
        }
        #endregion

        #region IXmlSerializable Member
        /// <summary>
        /// Simply returns <c>null</c> as suggested by the framework documentation.
        /// </summary>
        /// <returns></returns>
        public System.Xml.Schema.XmlSchema GetSchema()
        {
            return null;
        }

        public void ReadXml(System.Xml.XmlReader reader)
        {
            reader.ReadStartElement("package-toc");
            if (reader.IsStartElement("projects"))
            {
                reader.ReadStartElement();
                while (reader.IsStartElement("project"))
                {
                    Build.BuildProject.AddKnownProject((Build.BuildProject) Build.BuildProject.ReadSerializable(reader, "project"));
                }
                reader.Read();
            }
            #region Assignment of environment variables
            this.EnvVarAssignments.Clear();
            if (reader.IsStartElement("env-vars"))
            {
                reader.Read();
                while (reader.IsStartElement("var-assign"))
                {
                    string name = reader.GetAttribute("name");
                    string value = reader.GetAttribute("value");
                    this.EnvVarAssignments[name] = value;
                }
            }
            #endregion
            if (reader.IsStartElement("sources"))
            {
                reader.Read();
                this.SrcFiles.Clear(null);
                this.SrcFiles.ReadXml(reader);
                reader.ReadEndElement();
            }
            if (reader.IsStartElement("features"))
            {
                reader.Read();
                this.TocFiles.Clear(null);
                this.TocFiles.ReadXml(reader);
                foreach (TocNodeData data in this.TocFiles.LeafNodeDataCollection)
                    data.SrcTree = this.SrcFiles;
                foreach (TocNodeData data in this.TocFiles.TreeNodeDataCollection)
                    data.SrcTree = this.SrcFiles;
                reader.ReadEndElement();
            }
            reader.ReadEndElement();
        }

        public void WriteXml(System.Xml.XmlWriter writer)
        {
            writer.WriteStartElement("package-toc");
            #region Collect referred projects
            Dictionary<Guid, Build.BuildProject> projects = new Dictionary<Guid, wx.Build.BuildProject>();
            foreach (SrcNodeData nodeData in this.SrcFiles.TreeNodeDataCollection)
            {
                if (nodeData.ProjectRef != null)
                    projects[nodeData.Project.GetGuid()] = nodeData.Project;
                if (nodeData.Project is Build.Release.MakeReleaseProject)
                {
                    Build.Release.MakeReleaseProject releaseProject=(Build.Release.MakeReleaseProject) nodeData.Project;
                    foreach (KeyValuePair<Build.Net.CSharpAssemblyProject, Build.Net.CSharpAssemblyProject> pPair in releaseProject.ShadowCSharpProjects)
                        projects[pPair.Value.GetGuid()] = pPair.Value;
                    foreach (KeyValuePair<Build.Cxx.DynamicLibraryProject, Build.Cxx.DynamicLibraryProject> pPair in releaseProject.ShadowDllProjects)
                        projects[pPair.Value.GetGuid()] = pPair.Value;
                }
            }
            #endregion

            #region Assignment of environment variables
            if (this.EnvVarAssignments.Count > 0)
            {
                writer.WriteStartElement("env-vars");
                foreach (KeyValuePair<string, string> assignment in this.EnvVarAssignments)
                {
                    writer.WriteStartElement("var-assign");
                    writer.WriteAttributeString("name", assignment.Key);
                    writer.WriteAttributeString("value", assignment.Value);
                    writer.WriteEndElement();
                }
                writer.WriteEndElement();
            }
            #endregion

            #region Serialize referred projects. Put them in an order according to their dependencies.
            if (projects.Count > 0)
            {
                writer.WriteStartElement("projects");
                foreach (Build.BuildProject project in Build.BuildProject.ScheduleProjects(projects.Values))
                    Build.BuildProject.WriteSerializable(writer, project, "project");
                writer.WriteEndElement();
            }
            #endregion
            writer.WriteStartElement("sources");
            this.SrcFiles.WriteXml(writer);
            writer.WriteEndElement();
            writer.WriteStartElement("features");
            this.TocFiles.WriteXml(writer);
            writer.WriteEndElement();
            writer.WriteEndElement();
        }

        #endregion

        #region Loading And Saving
        /// <summary>
        /// This will load a TOC and the listed files from the designated file.
        /// All files that have been attached to the data source will be saved relatively
        /// to the provided directory name.
        /// </summary>
        /// <param name="errorHandler">This method will write errors to this.</param>
        /// <param name="filename">The filenmae of the data source</param>
        /// <param name="destination"></param>
        /// <seealso cref="Save"/>
        public void Load(Build.ErrorHandler errorHandler, string filename, string destination)
        {
            if (!System.IO.Directory.Exists(destination))
                System.IO.Directory.CreateDirectory(destination);
            this.Clear();
            Build.BuildConfig.PathRoot = destination;
            using (System.Resources.ResourceReader src = new System.Resources.ResourceReader(filename))
            {
                foreach (System.Collections.DictionaryEntry resource in src)
                {
                    if (resource.Key.Equals("TOC"))
                    {
                        string newPkgProjFile = System.IO.Path.GetFileNameWithoutExtension(filename);
                        newPkgProjFile = System.IO.Path.Combine(destination, newPkgProjFile + ".pkgproj");
                        using (System.IO.MemoryStream bstream = new System.IO.MemoryStream((byte[])resource.Value))
                        using (System.IO.Compression.GZipStream zipStream = new System.IO.Compression.GZipStream(bstream, System.IO.Compression.CompressionMode.Decompress))
                        using (System.IO.StreamReader reader = new System.IO.StreamReader(zipStream, Encoding.UTF8))
                        using (System.IO.StreamWriter writer = new System.IO.StreamWriter(newPkgProjFile, false, Encoding.UTF8))
                        {
                            writer.Write(reader.ReadToEnd());
                        }

                        using (System.IO.MemoryStream bstream = new System.IO.MemoryStream((byte[])resource.Value))
                        using (System.IO.Compression.GZipStream zipStream = new System.IO.Compression.GZipStream(bstream, System.IO.Compression.CompressionMode.Decompress))
                        using (System.Xml.XmlTextReader r = new System.Xml.XmlTextReader(new System.IO.StreamReader(zipStream, Encoding.UTF8)))
                        {
                            this.ReadXml(r);
                        }
                        break;
                    }
                }
            }
            SortedDictionary<string, string> resNameToFileName = new SortedDictionary<string, string>();
            SortedDictionary<string, CompressionMode> resNameToCompressionMode = new SortedDictionary<string, CompressionMode>();
            foreach (int leafNodeId in this.SrcFiles.LeafNodes)
            {
                SrcLeafData leafNodeData = this.SrcFiles.GetLeafNodeData(leafNodeId);
                if (leafNodeData.NameInRes != null && leafNodeData.File != null)
                {
                    Build.ContentFile saveFile = leafNodeData.File;
                    if ((saveFile.Type.Properties & wx.Build.ContentFileProperties.DependsOnOSAndProcessor) == wx.Build.ContentFileProperties.DependsOnOSAndProcessor)
                    {
                        // This file is platform dependent and ma<y not refer to the current platform. We have to investigate the parent whether
                        // we have to adopt the filename referring to the platform node.
                        SrcNodeData parentData = this.SrcFiles.GetTreeNodeData(this.SrcFiles.GetParent(leafNodeId));
                        if (parentData.FolderType == KindOfSrcFolder.Platform
                            && parentData.Platform != null
                            && (!saveFile.Exists
                                || (wx.App.TheApp is PackagerApp
                                    && parentData.Platform.ID != ((PackagerApp)wx.App.TheApp).PlatformID)))
                        {
                            // refer to the filename but within a subdir relative to the platform ID.
                            saveFile = new wx.Build.ContentFile(
                                saveFile.Type, System.IO.Path.Combine(
                                                 System.IO.Path.Combine(
                                                    saveFile.DirectoryName,
                                                    string.Format("{0}{1:000000}", parentData.Platform.OsVersion.Platform, parentData.Platform.ID)),
                                                 saveFile.BaseFileName));
                        }
                    }                    
                    resNameToFileName[leafNodeData.NameInRes] = saveFile.FileName;
                    resNameToCompressionMode[leafNodeData.NameInRes] = leafNodeData.Compression;
                }
            }
            foreach (TocNodeData leafNodeData in this.TocFiles.LeafNodeDataCollection)
            {
                if (leafNodeData.NameInRes != null)
                {
                    resNameToFileName[leafNodeData.NameInRes] = leafNodeData.File.FileName;
                    resNameToCompressionMode[leafNodeData.NameInRes] = leafNodeData.Compression;
                }
            }
            using (System.Resources.ResourceReader src = new System.Resources.ResourceReader(filename))
            {
                foreach (System.Collections.DictionaryEntry resource in src)
                {
                    string resName = (string)resource.Key;
                    if (!"TOC".Equals(resource.Key) && resNameToFileName.ContainsKey(resName))
                    {
                        string resFileName = resNameToFileName[resName];
                        string resFileDir = System.IO.Path.GetDirectoryName(resFileName);
                        byte[] resData = (byte[])resource.Value;
                        CompressionMode compression = resNameToCompressionMode[resName];
                        if (!System.IO.Directory.Exists(resFileDir))
                            System.IO.Directory.CreateDirectory(resFileDir);
                        if (compression == CompressionMode.GZip)
                        {
                            using (System.IO.MemoryStream bstream = new System.IO.MemoryStream(resData))
                            using (System.IO.Compression.GZipStream zipStream = new System.IO.Compression.GZipStream(bstream, System.IO.Compression.CompressionMode.Decompress))
                            using (System.IO.FileStream fstream = System.IO.File.OpenWrite(resFileName))
                            {
                                int bytesread = 0;
                                byte[] buffer = new byte[1024];
                                do
                                {
                                    bytesread = zipStream.Read(buffer, 0, buffer.Length);
                                    if (bytesread == 0)
                                        break;
                                    fstream.Write(buffer, 0, bytesread);
                                }
                                while (bytesread == buffer.Length);
                                if (errorHandler != null)
                                    errorHandler(new wx.Build.ErrorObject(wx.Build.ErrorObject.MessageType.Message, "Created file {0} from gzipped resource {1}.", resFileName, resName));
                            }
                        }
                        else
                        {
                            // no compression used.
                            using (System.IO.FileStream fstream = System.IO.File.OpenWrite(resFileName))
                            {
                                fstream.Write(resData, 0, resData.Length);
                            }
                            if (errorHandler != null)
                                errorHandler(new wx.Build.ErrorObject(wx.Build.ErrorObject.MessageType.Message, "Created file {0} from uncompressed resource {1}.", resFileName, resName));
                        }
                    }
                    else
                        errorHandler(new wx.Build.ErrorObject(wx.Build.ErrorObject.MessageType.Warning, "Ignore resource {0}.", resName));
                }
            }
        }

        /// <summary>
        /// Returns the longest path that is common to all contained source files.
        /// </summary>
        /// <returns></returns>
        public string GetSrcBasePath()
        {
            string result = null;
            foreach (SrcLeafData data in this.SrcFiles.LeafNodeDataCollection)
            {
                Build.ContentFile f = data.File;
                if (f != null)
                {
                    if (result == null)
                        result = f.FileName;
                    else
                        result = Build.ContentFile.GetCommonBasePath(result, f.FileName);
                }
            }
            return result;
        }

        /// <summary>
        /// Saves the serialization of this tree and all the designated files into a resource file of the
        /// provided name.
        /// </summary>
        /// <param name="errorHandler">This method will write errors to this.</param>
        /// <param name="filename">Filename of the destination.</param>
        /// <seealso cref="Load"/>
        public void Save(Build.ErrorHandler errorHandler, string filename)
        {
            string newRootPath=this.GetSrcBasePath();
            this.NormalizeOriginalFileNames(newRootPath);
            #region Make Resource Names Unique
            SortedDictionary<string, string> usedResourceNames = new SortedDictionary<string, string>();
            SortedDictionary<string, string> filenameToResName = new SortedDictionary<string, string>();
            usedResourceNames.Add("toc", "toc");
            foreach (int leafNodeId in this.SrcFiles.LeafNodes)
            {
                SrcLeafData data = this.SrcFiles.GetLeafNodeData(leafNodeId);
                if (data.File != null)
                {
                    if (filenameToResName.ContainsKey(data.File.FileName))
                        data.NameInRes = filenameToResName[data.File.FileName];
                    else
                    {
                        if (data.NameInRes == null
                            || data.NameInRes.Trim().Length == 0)
                            data.NameInRes = System.IO.Path.GetFileNameWithoutExtension(data.File.FileName);
                        data.NameInRes = data.NameInRes.ToLower();
                        data.NameInRes.Replace(" ", "_");
                        if (usedResourceNames.ContainsKey(data.NameInRes))
                        {
                            int index = 1;
                            string baseName = data.NameInRes;
                            if (baseName.Length > 7)
                                baseName = baseName.Substring(0, 7);
                            for (; ; )
                            {
                                data.NameInRes = baseName + index.ToString("00");
                                if (usedResourceNames.ContainsKey(data.NameInRes))
                                    index += 1;
                                else
                                {
                                    break;
                                }
                            }
                        }
                        usedResourceNames.Add(data.NameInRes, data.NameInRes);
                    }
                }
            }
            #endregion

            using (System.Resources.ResourceWriter dest = new System.Resources.ResourceWriter(filename))
            {
                using (System.IO.MemoryStream bstream = new System.IO.MemoryStream())
                {
                    using (System.IO.Compression.GZipStream zipStream = new System.IO.Compression.GZipStream(bstream, System.IO.Compression.CompressionMode.Compress))
                    using (System.Xml.XmlTextWriter xmlw = new System.Xml.XmlTextWriter(zipStream, Encoding.UTF8))
                    {
                        //w.Formatting = System.Xml.Formatting.Indented;
                        xmlw.WriteStartDocument();
                        this.WriteXml(xmlw);
                        xmlw.WriteEndDocument();
                    }
                    bstream.Close();
                    dest.AddResource("TOC", bstream.ToArray());
                }

                foreach(int leafNodeId in this.SrcFiles.LeafNodes)
                {
                    SrcLeafData data=this.SrcFiles.GetLeafNodeData(leafNodeId);
                    if (data.File != null)
                    {
                        Build.ContentFile saveFile = data.File;
                        if ((saveFile.Type.Properties & wx.Build.ContentFileProperties.DependsOnOSAndProcessor) == wx.Build.ContentFileProperties.DependsOnOSAndProcessor)
                        {
                            // This file is platform dependent and ma<y not refer to the current platform. We have to investigate the parent whether
                            // we have to adopt the filename referring to the platform node.
                            SrcNodeData parentData = this.SrcFiles.GetTreeNodeData(this.SrcFiles.GetParent(leafNodeId));
                            if (parentData.FolderType == KindOfSrcFolder.Platform
                                && parentData.Platform != null
                                && (!saveFile.Exists
                                    || (wx.App.TheApp is PackagerApp
                                        && parentData.Platform.ID != ((PackagerApp)wx.App.TheApp).PlatformID)))
                            {
                                // refer to the filename but within a subdir relative to the platform ID.
                                saveFile = new wx.Build.ContentFile(
                                    saveFile.Type, System.IO.Path.Combine(
                                                     System.IO.Path.Combine(
                                                        saveFile.DirectoryName,
                                                        string.Format("{0}{1:000000}", parentData.Platform.OsVersion.Platform, parentData.Platform.ID)),
                                                     saveFile.BaseFileName));
                            }
                        }
                        if (saveFile.Exists && !filenameToResName.ContainsKey(saveFile.FileName))
                        {
                            byte[] filedata;
                            if (data.Compression==CompressionMode.GZip)
                            {
                                using (System.IO.MemoryStream memDest = new System.IO.MemoryStream())
                                {
                                    using (System.IO.Compression.GZipStream zipStream
                                            = new System.IO.Compression.GZipStream(memDest, System.IO.Compression.CompressionMode.Compress))
                                    using (System.IO.FileStream s = System.IO.File.OpenRead(saveFile.FileName))
                                    {
                                        byte[] buffer = new byte[1000];
                                        for (; ; )
                                        {
                                            int numOfBytesRead = s.Read(buffer, 0, 1000);
                                            if (numOfBytesRead > 0)
                                                zipStream.Write(buffer, 0, numOfBytesRead);
                                            else
                                                break;
                                        }
                                        s.Close();
                                        zipStream.Close();
                                    }
                                    memDest.Close();
                                    filedata = memDest.ToArray();
                                }
                            }
                            else
                            {
                                filedata = System.IO.File.ReadAllBytes(saveFile.FileName);
                            }
                            dest.AddResource(data.NameInRes, filedata);
                            if (errorHandler != null)
                                errorHandler(new wx.Build.ErrorObject(wx.Build.ErrorObject.MessageType.Message,
                                    "Save file {0} in package using resource name {1}.", saveFile.FileName, data.NameInRes));
                            filenameToResName.Add(saveFile.FileName, data.NameInRes);
                        }
                        else
                        {
                            if (errorHandler != null)
                                errorHandler(new wx.Build.ErrorObject(wx.Build.ErrorObject.MessageType.Warning,
                                    "File {0} in the tree of source files does not exist.", data.File.FileName));
                        }
                    }
                }
                dest.Generate();
                dest.Close();
                if (errorHandler != null)
                    errorHandler(new wx.Build.ErrorObject(wx.Build.ErrorObject.MessageType.Message,
                        "Task accomplished. Saved {0} files.", filenameToResName.Count));
            }
        }
        #endregion

        #region Selectors

        /// <summary>
        /// This will traverse the complete source tree and search for all platform descriptors containing at least
        /// one file.
        /// </summary>
        /// <returns></returns>
        public ICollection<PlatformDescr> GetPlatformsInSrc()
        {
            Dictionary<PlatformDescr, PlatformDescr> result=new Dictionary<PlatformDescr, PlatformDescr>();
            Queue<int> agenda = new Queue<int>();
            agenda.Enqueue(0);
            while (agenda.Count > 0)
            {
                int current = agenda.Dequeue();
                foreach (int child in this.SrcFiles.GetTreeNodeChildren(current))
                    agenda.Enqueue(child);
                SrcNodeData data = this.SrcFiles.GetTreeNodeData(current);
                if (data != null
                    && data.FolderType == KindOfSrcFolder.Platform
                    && data.Platform != null)
                {
                    result[data.Platform] = data.Platform;
                }
            }
            return result.Values;
        }
        #endregion

        #region Overrides
        public override string ToString()
        {
            return string.Format("TOC(\nsrc:\n{0})", this.SrcFiles);
        }
        #endregion

        #region Modifiers
        /// <summary>
        /// Clears all data.
        /// </summary>
        public void Clear()
        {
            this.SrcFiles.Clear(null);
            this.TocFiles.Clear(null);
            Build.BuildProject.ClearKnownProjects();
        }
        #endregion

        #region INodeData Member
        /// <summary>
        /// All internal "original" filenames will be changed to denote the file designated by the absolute
        /// filename but relative to the directory provided as argument to this method.
        /// This will also set the Build.BuildConfig.PathRoot.
        /// </summary>
        /// <param name="nameOfAValidDirOrFile"></param>
        public void NormalizeOriginalFileNames(string nameOfAValidDirOrFile)
        {
            Build.BuildConfig.PathRoot = nameOfAValidDirOrFile;
            this.SrcFiles.NormalizeOriginalFileNames(nameOfAValidDirOrFile);
            this.TocFiles.NormalizeOriginalFileNames(nameOfAValidDirOrFile);
        }

        #endregion
    }
}
