-- Premake script for the wx.NET utility package viewer
-- See http://premake.sourceforge.net/ for more info about Premake.


package.name     = "PackageBuilder.exe"
package.language = "c#"
package.kind     = "winexe"
package.target   = "PackageBuilder.exe"
project.bindir   = "../../Bin"

package.links    = { "System", "System.Drawing", "wx.NET", "wx.BuildSystem" }

package.files    = { "Properties/AssemblyInfo.cs", "ContentTypeConfig.cs", "PkgApp.cs", "PkgFrame.cs", "PkgToc.cs" }
