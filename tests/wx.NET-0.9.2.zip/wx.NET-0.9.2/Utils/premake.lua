-- Premake script for the wx.NET project.
-- See http://premake.sourceforge.net/ for more info about Premake.

project.name   = "wx.NET"
project.bindir = "Bin"

-----------------------------------------------------------------------
-- Additional packages

addoption("enable-stc", "Enable StyledTextCtrl (wxStyledTextCtrl)")

-----------------------------------------------------------------------

dopackage("Src/wx-c/premake.lua")
dopackage("Src/wx.NET/premake.lua")
dopackage("Utils/premake.lua")
dopackage("Samples/premake.lua")

project.name   = "wx.NET"
